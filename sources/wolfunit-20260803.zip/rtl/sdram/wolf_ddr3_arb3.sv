// ============================================================================
// wolf_ddr3_arb3.sv — 3-way DDR3 arbitration by COMPOSING two proven 2-way arbiters
// ============================================================================
//
// WHY NOT JUST MAKE wolf_ddr3_arb 3-WAY
//   Its grant-release logic carries two documented failed attempts in its own
//   comments -- releasing on the first accepted beat corrupted burst writes
//   (tail-zeroed beats, desynced counters, caught only by tb_wolf_replay_contend
//   because the isolation gate has no arb seam), and counting !busy beats came
//   up one short and wedged the grant. That module is load-bearing in a SHIPPED,
//   CAB-CONFIRMED core.
//
//   Editing it to add a third port would put that hard-won logic back in play
//   for a feature that is not even on silicon yet. Instantiating it TWICE does
//   not touch a line of it: VRAM and GFX see byte-identical arbitration to the
//   image already running on the cabinet, and the new requester is isolated
//   behind a second copy of the same proven behaviour.
//
// PRIORITY, AND WHY THE FRAMEBUFFER IS LAST
//     VRAM  >  GFX  >  CRT framebuffer
//
//   Counter-intuitive at first glance -- the framebuffer feeds the display, so
//   surely it is urgent? No: it has by far the MOST SLACK of the three.
//     VRAM : per-scanline deadline, microseconds, missing it corrupts the raster
//     GFX  : blit-time reads; starving it stalls the blitter, and on MK3 the
//            blitter is already the suspected bottleneck (Motaro)
//     FB   : a line fetch has an ENTIRE LINE TIME (~63 us) to complete, and the
//            write side stages a full line before asking for the bus at all
//
//   Giving the framebuffer priority over GFX would take bandwidth away from the
//   blitter to serve a consumer that can wait ~63 us. A late line is counted on
//   dbg_late_lines and costs one repeated line; a starved blit costs game
//   content. So the slack ordering IS the priority ordering.
//
`default_nettype none

module wolf_ddr3_arb3 (
    input  logic         clk,
    input  logic         b_allow,

    // A = VRAM (highest priority, unchanged behaviour)
    input  logic [28:0]  a_addr,  input logic [7:0] a_burstcnt,
    input  logic         a_rd,    input logic       a_we,
    input  logic [63:0]  a_din,   input logic [7:0] a_be,
    output logic         a_busy,  output logic [63:0] a_dout,
    output logic         a_dout_ready,

    // B = GFX (unchanged behaviour relative to VRAM)
    input  logic [28:0]  b_addr,  input logic [7:0] b_burstcnt,
    input  logic         b_rd,    input logic       b_we,
    input  logic [63:0]  b_din,   input logic [7:0] b_be,
    output logic         b_busy,  output logic [63:0] b_dout,
    output logic         b_dout_ready,

    // C = CRT framebuffer (lowest priority -- most slack)
    input  logic [28:0]  c_addr,  input logic [7:0] c_burstcnt,
    input  logic         c_rd,    input logic       c_we,
    input  logic [63:0]  c_din,   input logic [7:0] c_be,
    output logic         c_busy,  output logic [63:0] c_dout,
    output logic         c_dout_ready,

    // physical Avalon master
    output logic [28:0]  ddram_addr,
    output logic [7:0]   ddram_burstcnt,
    output logic         ddram_rd,
    output logic         ddram_we,
    output logic [63:0]  ddram_din,
    output logic [7:0]   ddram_be,
    input  logic         ddram_busy,
    input  logic [63:0]  ddram_dout,
    input  logic         ddram_dout_ready
);

    // ---- inner arbiter: GFX (priority) vs framebuffer --------------------
    wire [28:0] s_addr;  wire [7:0] s_burstcnt;
    wire        s_rd, s_we;
    wire [63:0] s_din;   wire [7:0] s_be;
    wire        s_busy;  wire [63:0] s_dout;  wire s_dout_ready;

    wolf_ddr3_arb u_inner (
        .clk(clk), .b_allow(1'b1),
        .a_addr(b_addr), .a_burstcnt(b_burstcnt), .a_rd(b_rd), .a_we(b_we),
        .a_din(b_din), .a_be(b_be),
        .a_busy(b_busy), .a_dout(b_dout), .a_dout_ready(b_dout_ready),

        .b_addr(c_addr), .b_burstcnt(c_burstcnt), .b_rd(c_rd), .b_we(c_we),
        .b_din(c_din), .b_be(c_be),
        .b_busy(c_busy), .b_dout(c_dout), .b_dout_ready(c_dout_ready),

        .ddram_addr(s_addr), .ddram_burstcnt(s_burstcnt),
        .ddram_rd(s_rd), .ddram_we(s_we), .ddram_din(s_din), .ddram_be(s_be),
        .ddram_busy(s_busy), .ddram_dout(s_dout), .ddram_dout_ready(s_dout_ready)
    );

    // ---- outer arbiter: VRAM (priority) vs the inner pair ----------------
    // VRAM's port is wired EXACTLY as before, so its arbitration against
    // everything else is unchanged from the shipped core.
    wolf_ddr3_arb u_outer (
        .clk(clk), .b_allow(b_allow),
        .a_addr(a_addr), .a_burstcnt(a_burstcnt), .a_rd(a_rd), .a_we(a_we),
        .a_din(a_din), .a_be(a_be),
        .a_busy(a_busy), .a_dout(a_dout), .a_dout_ready(a_dout_ready),

        .b_addr(s_addr), .b_burstcnt(s_burstcnt), .b_rd(s_rd), .b_we(s_we),
        .b_din(s_din), .b_be(s_be),
        .b_busy(s_busy), .b_dout(s_dout), .b_dout_ready(s_dout_ready),

        .ddram_addr(ddram_addr), .ddram_burstcnt(ddram_burstcnt),
        .ddram_rd(ddram_rd), .ddram_we(ddram_we),
        .ddram_din(ddram_din), .ddram_be(ddram_be),
        .ddram_busy(ddram_busy), .ddram_dout(ddram_dout),
        .ddram_dout_ready(ddram_dout_ready)
    );

endmodule

`default_nettype wire
