// ============================================================================
// crt_fb_ddr.sv — DDR3-backed frame store for crt_retime
// ============================================================================
//
// WHY THIS EXISTS
//   crt_retime needs a whole frame of storage to decouple core timing from
//   display timing. On a 5CSEBA6 that frame does NOT fit on-chip:
//
//     400x254 @ 12bpp, double buffered = 2,438,400 bits = 239 M10K blocks
//     the Wolf core already uses 414 of 553 -> 139 free
//
//   Not tight. Impossible. And a 12-bit-wide array lands in M10K's 512x20 mode
//   wasting 8 bits of every 20, so even ONE buffer wants ~199 blocks.
//
//   Putting the frame in DDR3 changes the on-chip cost from a frame to a LINE:
//
//     DDR3 + 2 line buffers = 400*16*2 = 12,800 bits = 2 M10K blocks
//
//   That is a 100x reduction in block RAM, it leaves the remaining M10K free
//   for the blitter work, and it makes double buffering trivial because DDR3
//   has gigabytes.
//
// MEASURED BANDWIDTH BUDGET (16 bits stored per pixel)
//     write, core at 54.7 Hz : 11.1 MB/s
//     read,  out at 59.94 Hz : 12.2 MB/s
//     combined               : 23.3 MB/s
//   Vertical scaling does NOT increase read bandwidth: a source line is fetched
//   ONCE and replayed N times from the line buffer.
//
// CLOCKING — ONE CROSSING, AND IT IS A DUAL-CLOCK RAM
//   Everything that touches DDR3 runs on `clk` (the core/DDR3 domain), which is
//   also where core video arrives. The ONLY thing crossing into the display
//   domain is the line buffer itself, which is a proper dual-clock BRAM rather
//   than an ad-hoc handshake. That is deliberate: this project has been bitten
//   by hand-rolled CDC before (P0019), and a dual-clock RAM is the one crossing
//   the toolchain will actually time.
//
// TEARING
//   Two frame buffers in DDR3, swapped at the writer's frame end and consumed
//   from the display's vblank, so a half-written frame is never fetched. Costs
//   nothing on-chip -- the second buffer is just another DDR3 address.
//
// PIXEL PACKING
//   16 bits stored per pixel (RGB444 in the low 12), 4 pixels per 64-bit beat.
//   The 4 spare bits are deliberate: they keep the address arithmetic a shift
//   instead of a multiply, and DDR3 has the room. A 12-bit pack would save 25%
//   of a budget that is not the constraint.
//
`default_nettype none

module crt_fb_ddr #(
    parameter int HACT     = 400,        // source pixels per line
    parameter int VACT     = 254,        // source lines per frame
    parameter int CDEPTH   = 4,          // bits per colour channel
    parameter [28:0] FB_BASE = 29'h1000000,  // DDR3 BEAT base of buffer 0 (64-bit beats)
    parameter int BUFSTRIDE = 32'h100000     // bytes between the two buffers
)(
    input  wire        clk,               // core + DDR3 domain
    input  wire        rst,

    // ---- write side: core video, NEVER back-pressured --------------------
    input  wire        capture_en,         // 0 = native bypass; consume no CRT write bandwidth
    input  wire        ce_in,
    input  wire [CDEPTH-1:0] r_in, g_in, b_in,
    input  wire        de_in,
    input  wire        vs_in,
    output logic       frame_done,        // 1-clk pulse: a frame finished

    // ---- read side: line requests from the display domain ----------------
    // The display asks for a SOURCE line; this module fetches it into one of
    // the line buffers and raises line_ready. Requests are per SOURCE line, so
    // vertical scaling costs no extra fetches.
    input  wire        line_req,          // pulse: fetch line_num
    input  wire        line_frame_start,  // this is the first fetch of an output frame
    input  wire [11:0] line_num,
    input  wire        line_buf_sel,      // which line buffer to fill
    output logic       line_ready,        // pulse: fill complete

    // line buffer read port (display domain)
    input  wire        clk_rd,
    input  wire [11:0] rd_x,
    input  wire        rd_buf_sel,
    output logic [15:0] rd_data,

    // ---- DDR3 Avalon master (-> wolf_ddr3_arb) ---------------------------
    output logic [28:0] ddr_addr,
    output logic [7:0]  ddr_burstcnt,
    output logic        ddr_rd,
    output logic        ddr_we,
    output logic [63:0] ddr_din,
    output logic [7:0]  ddr_be,
    input  wire         ddr_busy,
    input  wire [63:0]  ddr_dout,
    input  wire         ddr_dout_ready,

    // ---- observability ----------------------------------------------------
    output logic [15:0] dbg_wr_lines,
    output logic [15:0] dbg_rd_lines,
    output logic [15:0] dbg_late_lines   // fetch not done before it was needed
);

    localparam int BEATS_PER_LINE = (HACT + 3) / 4;   // 4 px per 64-bit beat
    localparam int LINE_BYTES     = BEATS_PER_LINE * 8;
    localparam int LINE_RAM_DEPTH = 2 * BEATS_PER_LINE;
    localparam int LINE_RAM_AW    = $clog2(LINE_RAM_DEPTH);
    localparam logic [LINE_RAM_AW-1:0] LINE1_BASE = BEATS_PER_LINE;

    // ======================================================================
    // WRITE SIDE — pack 4 pixels into a beat, buffer one line, burst it out.
    // No back-pressure reaches the core: the line staging RAM always accepts.
    // ======================================================================
    // PING-PONG STAGING. A single staging line is not enough: if the DDR3 burst
    // for line N has not drained when line N+1's de_fall arrives, line_pending
    // is re-asserted while incoming pixels are ALREADY overwriting the array,
    // and line N is lost. The round-trip gate caught exactly that -- 4 of 8
    // lines staged. With two buffers the writer fills one while the sequencer
    // drains the other, which is the same reason the READ side has two.
    // *** SYNCHRONOUS BRAM, NOT FLOPS. READ THE COMMENT BEFORE CHANGING IT. ***
    //
    // This array was originally read ASYNCHRONOUSLY (a_wdata = wline[...]) to
    // satisfy the agent's FWFT contract, which needs the current beat presented
    // combinationally. An async read CANNOT infer M10K, so Quartus built it in
    // logic: at HACT=400 that is 2*100 entries x 64 bits = 12,800 FLIP-FLOPS.
    // MEASURED consequence in the first CRT fit: block memory bits UNCHANGED
    // from baseline (the DDR3 design worked exactly as intended) while logic
    // went 75% -> 99% (41,483 of 41,910 ALMs) and BOTH pll_hdmi and the CORE
    // clock missed timing (-0.100 / -0.283). No RBF was produced.
    //
    // The architecture was right and the implementation spent the savings in a
    // different currency. Fixed by making the read SYNCHRONOUS and prefetching
    // one beat ahead, so the agent still sees its beat combinationally (from
    // wbeat_q) while the array itself infers block RAM.
    (* ramstyle = "no_rw_check, M10K" *) logic [63:0] wline [0:LINE_RAM_DEPTH-1];
    logic [LINE_RAM_AW-1:0] wline_raddr;  // beat currently held in wbeat_q
    logic [63:0] wbeat_q;                 // registered BRAM output / FWFT head
    logic        wstage;          // buffer the pixel writer is filling
    logic        dstage;          // buffer the DDR3 sequencer is draining
    logic [11:0] wx;
    logic [11:0] wy;
    logic [1:0]  wsub;                  // pixel within the beat
    logic [63:0] wacc;
    logic        wbuf;                  // DDR3 frame buffer being written
    logic        capture_armed;         // wait for a clean source-frame boundary on enable
    logic        de_q, vs_q;
    // SINGLE OWNER. line_pending is set by the write side and cleared only in
    // response to line_taken from the sequencer. Driving it from both blocks is
    // legal in simulation (last write wins) and ILLEGAL in synthesis --
    // "Can't resolve multiple constant drivers", which is exactly what Quartus
    // rejected. No iverilog gate can catch this class; only synthesis can.
    logic        line_pending;          // a staged line is waiting to burst
    logic        line_taken;            // sequencer -> writer: I have it
    logic [11:0] pending_y;

    wire [15:0] px_packed = {4'd0, r_in, g_in, b_in};
    wire de_fall = ~de_in & de_q;
    wire vs_rise = vs_in & ~vs_q;
    wire wline_full_we = capture_en && ce_in && capture_armed &&
                         de_in && (wsub == 2'd3);
    wire wline_tail_we = capture_en && ce_in && capture_armed &&
                         de_fall && (wsub != 2'd0);
    wire wline_we = wline_full_we || wline_tail_we;
    wire [LINE_RAM_AW-1:0] wline_waddr =
        (wstage ? LINE1_BASE : '0) + wx[LINE_RAM_AW+1:2];
    wire [63:0] wline_wdata =
        wline_full_we ? {px_packed, wacc[47:0]} : wacc;

    // Canonical Quartus simple-dual-port write port: exactly one write address
    // and one word per clock. Keep all array access out of the control block;
    // multiple syntactic writes prevent the Quartus 17 RAM matcher firing.
    always_ff @(posedge clk)
        if (wline_we) wline[wline_waddr] <= wline_wdata;

    always_ff @(posedge clk) begin
        if (rst) begin
            wx <= '0; wy <= '0; wsub <= '0; wacc <= '0; wbuf <= 1'b0;
            capture_armed <= capture_en;
            wstage <= 1'b0; dstage <= 1'b0;
            de_q <= 1'b0; vs_q <= 1'b0; line_pending <= 1'b0; pending_y <= '0;
            frame_done <= 1'b0; dbg_wr_lines <= '0;
        end else begin
            frame_done <= 1'b0;
            if (!capture_en) begin
                // Native mode must not spend DDR bandwidth or publish a
                // half-captured line if the user enables PVM mode mid-frame.
                wx <= '0; wy <= '0; wsub <= '0; wacc <= '0;
                wstage <= 1'b0; dstage <= 1'b0;
                de_q <= 1'b0; vs_q <= vs_in;
                line_pending <= 1'b0;
                capture_armed <= 1'b0;
            end else if (ce_in) begin
                de_q <= de_in; vs_q <= vs_in;

                if (!capture_armed) begin
                    // Begin only after a source VS edge, so the first buffer
                    // published after a runtime enable is a complete frame.
                    if (vs_rise) begin
                        capture_armed <= 1'b1;
                        wx <= '0; wy <= '0; wsub <= '0; wacc <= '0;
                    end
                end else if (de_in) begin
                    // pack little-endian within the beat
                    case (wsub)
                        2'd0: wacc[15:0]  <= px_packed;
                        2'd1: wacc[31:16] <= px_packed;
                        2'd2: wacc[47:32] <= px_packed;
                        2'd3: wacc[63:48] <= px_packed;
                    endcase
                    if (wsub == 2'd3) begin
                        wsub <= 2'd0;
                    end else begin
                        wsub <= wsub + 2'd1;
                    end
                    wx <= wx + 12'd1;
                end

                if (capture_armed && line_taken) line_pending <= 1'b0;
                if (capture_armed && de_fall) begin
                    // flush a partial final beat, hand this buffer to the
                    // sequencer, and start filling the OTHER one.
                    line_pending <= 1'b1;
                    pending_y    <= wy;
                    dstage       <= wstage;
                    wstage       <= ~wstage;
                    dbg_wr_lines <= dbg_wr_lines + 16'd1;
                    wx <= '0; wsub <= '0;
                    if (wy < VACT[11:0]) wy <= wy + 12'd1;
                end

                if (capture_armed && vs_rise) begin
                    wy <= '0; wx <= '0; wsub <= '0;
                    wbuf <= ~wbuf;              // swap the DDR3 frame buffer
                    frame_done <= 1'b1;
                end
            end
        end
    end

    // ======================================================================
    // LINE BUFFERS — the ONLY clock crossing, and it is a dual-clock RAM.
    // Two buffers so line N+1 is fetched while line N is being displayed.
    // ======================================================================
    // Pack four pixels per word here too. The old 16-bit arrays wrote four
    // different addresses on every DDR beat, which is a four-write-port RAM
    // and therefore cannot map to M10K. One combined ping/pong array gives
    // Quartus exactly one write port and one independent display-clock read.
    (* ramstyle = "no_rw_check, M10K" *) logic [63:0] lbuf [0:LINE_RAM_DEPTH-1];
    logic [63:0] lbuf_q;
    logic [1:0]  rd_lane_q;
    wire [LINE_RAM_AW-1:0] lbuf_raddr =
        (rd_buf_sel ? LINE1_BASE : '0) + rd_x[LINE_RAM_AW+1:2];
    always_ff @(posedge clk_rd) begin
        lbuf_q    <= lbuf[lbuf_raddr];
        rd_lane_q <= rd_x[1:0];
    end
    always_comb begin
        case (rd_lane_q)
            2'd0: rd_data = lbuf_q[15:0];
            2'd1: rd_data = lbuf_q[31:16];
            2'd2: rd_data = lbuf_q[47:32];
            default: rd_data = lbuf_q[63:48];
        endcase
    end

    // ======================================================================
    // DDR3 via stv_vram_ddr_agent — the PROVEN pattern in this codebase.
    //
    // My first cut hand-rolled the Avalon burst protocol and got exactly one
    // beat committed per line: the round-trip gate showed 8 beats returning
    // with only beat 0 carrying data, the rest X. Rather than debug a protocol
    // that is already solved here, use what stv_vram_ddr_top and
    // wolf_gfx_ddr_top both use -- each embeds its OWN agent instance and the
    // arbiter sits behind them. The agent handles burst streaming (FWFT via
    // tst_wnext), read draining (tst_rd_valid per beat) and the held-request
    // contract the arbiter's grant logic depends on.
    //
    // WRITES WIN over reads when both are pending: a dropped write loses game
    // content permanently, a late read costs one repeated line and is counted.
    // ======================================================================
    logic        a_wr_req, a_rd_req;
    logic [25:0] a_addr;
    logic [7:0]  a_burst;
    wire  [63:0] a_rdata;
    wire         a_rd_valid, a_busy, a_wnext;

    // FWFT write source: present the current beat, advance on each wnext.
    logic [9:0]  wbeat;

    // Synchronous read: one clock of latency, which is what makes it a BRAM.
    //
    // The agent consumes wbeat_q on an a_wnext edge. Select the NEXT address
    // for that same BRAM clock edge, so the next registered word is visible
    // immediately after the edge. This sustains one beat/clock without adding
    // a second output register (the old wline_q -> wbeat_q pipeline repeated
    // every other beat because the agent can consume faster than that pipe).
    wire [LINE_RAM_AW-1:0] wline_fetch_addr =
        wline_raddr + (a_wnext ? 1'b1 : 1'b0);
    always_ff @(posedge clk)
        wbeat_q <= wline[wline_fetch_addr];

    // The agent sees a REGISTER, so its FWFT contract is unchanged.
    wire [63:0] a_wdata = wbeat_q;

    logic [1:0]  wr_arm;                  // write burst lead-in state
    logic        rd_pending;
    logic [11:0] rd_y, fill_x;
    logic        rd_buf;
    logic        rd_frame;              // frame selected for this line request
    logic        rframe;                 // held for one complete output frame
    logic        rd_active;

    wire [25:0] wr_beat_addr = (wbuf ? BUFSTRIDE[25:0] >> 3 : 26'd0)
                             + (pending_y * BEATS_PER_LINE[25:0]);
    wire [25:0] rd_beat_addr = (rd_frame ? BUFSTRIDE[25:0] >> 3 : 26'd0)
                             + (rd_y * BEATS_PER_LINE[25:0]);
    wire lbuf_we = rd_active && a_rd_valid;
    wire [LINE_RAM_AW-1:0] lbuf_waddr =
        (rd_buf ? LINE1_BASE : '0) + fill_x[LINE_RAM_AW+1:2];

    // Canonical mixed-clock simple-dual-port write port. Packing the complete
    // Avalon beat is both cheaper and preserves every pixel lane verbatim.
    always_ff @(posedge clk)
        if (lbuf_we) lbuf[lbuf_waddr] <= a_rdata;

    always_ff @(posedge clk) begin
        if (rst) begin
            a_wr_req <= 1'b0; a_rd_req <= 1'b0; a_addr <= '0; a_burst <= 8'd1;
            line_taken <= 1'b0; wr_arm <= 2'd0; wline_raddr <= '0;
            wbeat <= '0; rd_pending <= 1'b0; rd_active <= 1'b0; fill_x <= '0;
            rframe <= 1'b1; rd_frame <= 1'b1;
            line_ready <= 1'b0; dbg_rd_lines <= '0; dbg_late_lines <= '0;
        end else begin
            a_wr_req   <= 1'b0;
            a_rd_req   <= 1'b0;
            line_ready <= 1'b0;
            line_taken <= 1'b0;

            if (line_req) begin
                if (rd_pending || rd_active) dbg_late_lines <= dbg_late_lines + 16'd1;
                rd_pending <= 1'b1; rd_y <= line_num; rd_buf <= line_buf_sel;
                // Never follow the writer's live buffer bit during an output
                // frame: that would splice two source frames at an arbitrary
                // scanline. The retimer explicitly marks its first prefetch.
                if (line_frame_start) rframe <= ~wbuf;
                rd_frame <= line_frame_start ? ~wbuf : rframe;
            end

            // Step the registered BRAM output only when the agent accepts its
            // current FWFT head. If Avalon stalls, both address and data hold.
            if (a_wnext) begin
                wbeat       <= wbeat + 10'd1;
                wline_raddr <= wline_raddr + 1'b1;
            end

            if (!a_busy && !a_wr_req && !a_rd_req) begin
                if (line_pending) begin
                    if (wr_arm == 2'd0) begin
                        // Point at beat 0 and spend one clock filling the
                        // synchronous BRAM output before exposing the request.
                        wline_raddr <= dstage ? LINE1_BASE : '0;
                        wbeat       <= '0;
                        wr_arm      <= 2'd1;
                    end else begin
                        a_addr       <= wr_beat_addr;
                        a_burst      <= BEATS_PER_LINE[7:0];
                        a_wr_req     <= 1'b1;
                        line_taken   <= 1'b1; // writer clears line_pending
                        wr_arm       <= 2'd0;
                    end
                end else if (rd_pending) begin
                    a_addr    <= rd_beat_addr;
                    a_burst   <= BEATS_PER_LINE[7:0];
                    fill_x    <= '0;
                    rd_active <= 1'b1;
                    a_rd_req  <= 1'b1;
                    rd_pending<= 1'b0;
                end
            end

            if (!capture_en && !a_busy && !line_pending)
                wr_arm <= 2'd0;

            if (rd_active && a_rd_valid) begin
                if (fill_x + 12'd4 >= HACT[11:0]) begin
                    rd_active    <= 1'b0;
                    line_ready   <= 1'b1;
                    dbg_rd_lines <= dbg_rd_lines + 16'd1;
                end
                fill_x <= fill_x + 12'd4;
            end
        end
    end

    stv_vram_ddr_agent #(.VRAM_DDR_BASE(FB_BASE)) u_agent (
        .clk(clk), .sdram_por(rst),
        .tst_wr_req(a_wr_req), .tst_rd_req(a_rd_req), .tst_addr(a_addr),
        .tst_wdata(a_wdata), .tst_be(8'hFF), .tst_burstcnt(a_burst),
        .tst_rdata(a_rdata), .tst_rd_valid(a_rd_valid), .tst_busy(a_busy),
        .tst_wnext(a_wnext),
        .ddram_addr(ddr_addr), .ddram_burstcnt(ddr_burstcnt),
        .ddram_rd(ddr_rd), .ddram_we(ddr_we), .ddram_din(ddr_din), .ddram_be(ddr_be),
        .ddram_busy(ddr_busy), .ddram_dout(ddr_dout), .ddram_dout_ready(ddr_dout_ready));

endmodule

`default_nettype wire
