#!/usr/bin/env bash
# Gate stamp: record that the licence-free release gates PASSED for an exact
# source state, so they need not be re-run on the shared Quartus box.
#
# WHY (queue defect D8, measured on wolf-crt 2026-08-03): the release build runs
# its 17-gate iverilog suite AFTER acquiring the box. On one attempt the box was
# held 16+ minutes with NO quartus_* process alive at all -- the machine was
# executing licence-free simulation while three sessions waited. Pre-validating
# the same suite offline saved nothing, because the build re-ran it regardless.
# Worse than squatting, because squatting shows an IDLE machine and this shows a
# BUSY one. Principle: THE BOX IS FOR THE FIT. If a step does not need the
# licence, it must not be on the box.
#
# WHAT THE STAMP BINDS. A stamp that does not name what it covers silently
# under-tests (NARC's parallel case: a gitignored sv2v blob can be NEWER than the
# rtl/ it came from, so a stamp asserting "a blob exists" is worthless). This one
# binds all three axes and refuses on any mismatch:
#   1. HEAD commit          -- source moved  -> invalid
#   2. tracked tree clean   -- uncommitted   -> invalid (never stamp a dirty tree)
#   3. gate-set digest      -- the LIST and CONTENT of every gate script, so
#                              adding, removing or editing a gate invalidates it
#
# THIS DOES NOT WEAKEN ANYTHING. The gates still run in full; they run OFF the
# box, before the turn. Skipping is permitted only when the stamp proves the
# identical suite already passed on the identical source.
#
# Usage:
#   gate_stamp.sh id       print the stamp id for the current state
#   gate_stamp.sh write    record the current state as PASSED
#   gate_stamp.sh valid    exit 0 if a stamp matches the current state
#   gate_stamp.sh explain  say why it is or is not valid (for logs)
set -uo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
STAMP="${GATE_STAMP_FILE:-$ROOT/build_syn/.release_gate_stamp}"
GATES="${GATE_SCRIPT:-$ROOT/quartus/run_wolfunit_release_gates.sh}"

gate_set_digest() {
  # The gate runner itself, plus every script it invokes. Content-hashed, so an
  # edit to any gate invalidates the stamp even at the same commit (gates are
  # frequently edited without committing while iterating).
  {
    cat "$GATES" 2>/dev/null
    sed -n 's|^bash "\$ROOT/\(.*\)"$|\1|p; s|^python "\$ROOT/\(.*\)"$|\1|p' "$GATES" 2>/dev/null |
      while IFS= read -r g; do
        printf '%s\n' "$g"
        cat "$ROOT/$g" 2>/dev/null
      done
  } | sha256sum | cut -d' ' -f1
}

current_id() {
  local head dirty
  head=$(git -C "$ROOT" rev-parse HEAD 2>/dev/null)
  dirty=$(git -C "$ROOT" status --porcelain --untracked-files=no 2>/dev/null)
  # A dirty tree can never produce a valid stamp: the gates would have run
  # against source that is not what the build will consume.
  if [ -n "$dirty" ]; then echo "DIRTY"; return; fi
  # Y-unit's constraint: keying on the commit alone is NOT sufficient. Their
  # audit_release_constraints.tcl sits inside release_gate.py's build-input
  # digest, so editing an audit script must invalidate the stamp even though the
  # RTL is untouched -- gate_set_digest covers that. The DEFINE SET is the other
  # axis: identical source at the identical commit gates DIFFERENTLY under a
  # different macro set, because build_hw.sh forwards every feature define to
  # BOTH sv2v and quartus_map. A stamp taken under one define set must not
  # license a skip under another.
  printf '%s:%s:%s\n' "$head" "$(gate_set_digest)" \
    "$(printf '%s' "${SV2V_EXTRA:-}|${WOLF_DEFINES:-}" | sha256sum | cut -c1-16)"
}

case "${1:-}" in
  id)
    current_id
    ;;
  write)
    id=$(current_id)
    if [ "$id" = "DIRTY" ]; then
      echo "gate_stamp: refusing to stamp a dirty tree" >&2; exit 1
    fi
    mkdir -p "$(dirname "$STAMP")"
    printf '%s\n' "$id" > "$STAMP"
    echo "gate_stamp: recorded PASS for ${id%%:*}"
    ;;
  valid)
    id=$(current_id)
    [ "$id" != "DIRTY" ] || exit 1
    [ -f "$STAMP" ] || exit 1
    [ "$(cat "$STAMP" 2>/dev/null)" = "$id" ] || exit 1
    ;;
  explain)
    id=$(current_id)
    if [ "$id" = "DIRTY" ]; then
      echo "gate stamp INVALID: tracked tree is dirty"
    elif [ ! -f "$STAMP" ]; then
      echo "gate stamp INVALID: no stamp recorded"
    elif [ "$(cat "$STAMP" 2>/dev/null)" != "$id" ]; then
      old=$(cat "$STAMP" 2>/dev/null)
      if [ "${old%%:*}" != "${id%%:*}" ]; then
        echo "gate stamp INVALID: commit moved ${old%%:*} -> ${id%%:*}"
      else
        echo "gate stamp INVALID: gate set changed at the same commit"
      fi
    else
      echo "gate stamp VALID for ${id%%:*} (suite already passed off-box)"
    fi
    ;;
  *)
    echo "usage: $0 {id|write|valid|explain}" >&2; exit 2
    ;;
esac
