#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/sim/build/tb_yunit_sdram_adapter_startup.vvp"
LOG="$ROOT/sim/build/tb_yunit_sdram_adapter_startup.log"
mkdir -p "$ROOT/sim/build"
/c/iverilog/bin/iverilog -g2012 -s tb_yunit_sdram_adapter_startup -o "$OUT" \
  "$ROOT/rtl/sdram/yunit_sdram_adapter.sv" "$ROOT/sim/tb_yunit_sdram_adapter_startup.sv"
/c/iverilog/bin/vvp -n "$OUT" | tee "$LOG"
grep -Fq 'PASS: tb_yunit_sdram_adapter_startup' "$LOG"
