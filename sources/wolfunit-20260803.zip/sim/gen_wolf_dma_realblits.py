#!/usr/bin/env python3
"""
gen_wolf_dma_realblits.py -- convert REAL captured umk3 blit register sets
(mame-gospel/trace/wolfblits.txt, produced by trace/wolfblits_capture.lua
running MAME 0.280 umk3 with a dma_w write tap) into contract vector cases:
sim/wolf_dma_realblits.json.

Capture line format: 'BLIT r0 r1 ... r17' (18 x %04X) = the full
m_dma_register file at the instant of a bit15 COMMAND write, decoded with
the exact register_map/bank logic of midtunit_v.cpp:695-717.

Replay: each case reconstructs the register STATE via bank-aware writes
(bank1 for TOP/BOTCLIP r12/13, bank0 for LEFT/RIGHTCLIP r16/17,
midtunit_v.cpp:697-702), then triggers with the captured COMMAND word.
Since the blit depends only on the register file (dma_w:721-796), this is
an exact replay of the real blit's parameters.

OFFSET FOLD (documented transformation): the real gfxoffset points into the
~25MB game gfx ROM; the pinned contract stub is 64KB. A pure replay would
read all-0x00 source -> most copy-mode blits (e.g. mode 2 P1) would draw
NOTHING and validate nothing. We therefore fold the source offset into the
stub: OFFSETHI := 0, OFFSETLO := captured OFFSETLO (keeps the bit-level
alignment o&7 and the low-bit spread; max 65535 bits = 8KB < stub).
Addressing/clip/scale/skip behavior is unaffected -- both sides compute
from the SAME folded register set, and the parameters (command word, w/h,
clips, skips, scale, palette) remain the real ones.

Dedupe: representative selection keyed on the parameter SHAPE:
(command, w, h, lrskip, scalex, scaley, clip-tuple). First N distinct
shapes kept (task target 20-50).
"""

import json
import os
import sys

TRACE = "D:/deck/fpga/umk3/mame-gospel/trace/wolfblits.txt"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                   "wolf_dma_realblits.json")
MAX_CASES = 50


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else TRACE
    shapes = {}
    order = []
    with open(path) as f:
        for ln in f:
            parts = ln.split()
            if not parts or parts[0] != "BLIT" or len(parts) != 19:
                continue
            r = [int(x, 16) for x in parts[1:]]
            key = (r[1], r[6], r[7], r[0], r[10], r[11],
                   r[12], r[13], r[16], r[17])
            if key in shapes:
                continue
            shapes[key] = r
            order.append(key)

    cases = []
    for i, key in enumerate(order[:MAX_CASES]):
        r = shapes[key]
        writes = [
            [15, 0x0020],       # bank1 (:702): offsets 12/13 -> TOP/BOTCLIP
            [12, r[12]],
            [13, r[13]],
            [15, 0x0000],       # bank0: offsets 12/13 -> LEFT/RIGHTCLIP
            [12, r[16]],
            [13, r[17]],
            [0, r[0]],          # LRSKIP
            [2, r[2] & 0xffff], # OFFSETLO (kept: bit alignment)
            [3, 0x0000],        # OFFSETHI folded to 0 (see header)
            [4, r[4]], [5, r[5]], [6, r[6]], [7, r[7]],
            [8, r[8]], [9, r[9]],
            [10, r[10]], [11, r[11]],
            [14, r[14]],
            [15, r[15]],        # final CONFIG = captured value
            [1, r[1]],          # captured COMMAND (bit15 set)
        ]
        cases.append({"name": "real_%03d_cmd%04X_w%d_h%d"
                              % (i, r[1], r[6], r[7]),
                      "writes": writes})

    with open(OUT, "w", newline="\n") as f:
        json.dump(cases, f, indent=1)
        f.write("\n")
    print("%d distinct shapes (of %d capture lines scanned) -> %d cases -> %s"
          % (len(order), sum(1 for _ in open(path)), len(cases), OUT))


if __name__ == "__main__":
    sys.exit(main())
