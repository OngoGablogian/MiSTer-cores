#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."
IVERILOG="${IVERILOG:-/c/iverilog/bin/iverilog}"
VVP="${VVP:-/c/iverilog/bin/vvp}"
OUT="sim/build/tb_wolf_fight_budget.vvp"
LOG="sim/build/tb_wolf_fight_budget.log"

test -f sim/build/umk3_gfx.hex || {
  echo "sim/build/umk3_gfx.hex missing; run: python sim/make_wolf_gfx_hex.py"
  exit 1
}

"$IVERILOG" -g2012 -s tb_wolf_fight_budget -o "$OUT" \
  rtl/pkg/wolf_pkg.sv \
  rtl/wolf/wolf_dma.sv \
  rtl/yunit/vram_sdram.sv \
  rtl/yunit/vram_sdram_top.sv \
  rtl/sdram/stv_vram_ddr_agent.sv \
  rtl/sdram/stv_vram_ddr_top.sv \
  rtl/sdram/wolf_gfx_ddr_top.sv \
  rtl/sdram/wolf_ddr3_arb.sv \
  sim/ddr3_avalon_model.sv \
  sim/tb_wolf_fight_budget.sv

"$VVP" "$OUT" | tee "$LOG"
grep -q '^PASS: live-fight frame retires' "$LOG"
