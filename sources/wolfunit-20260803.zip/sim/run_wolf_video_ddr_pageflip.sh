#!/usr/bin/env bash
# Release gate for Wolf DPYSTRT, line-prefetch, and DDR row-cache coherence.
set -eo pipefail

export PATH="/c/iverilog/bin:/usr/local/bin:/usr/bin:/bin"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
IVERILOG=${IVERILOG:-/c/iverilog/bin/iverilog}
VVP=${VVP:-/c/iverilog/bin/vvp}
OUTDIR="$ROOT/sim/build/video_ddr_pageflip"
LOG="$ROOT/sim/build/tb_wolf_video_ddr_pageflip.log"
mkdir -p "$OUTDIR"
: > "$LOG"

run_test() {
  local tb="$1"
  shift
  "$IVERILOG" -g2012 -s "$tb" -o "$OUTDIR/$tb.vvp" "$@" "$ROOT/sim/$tb.sv"
  "$VVP" "$OUTDIR/$tb.vvp" 2>&1 | tee -a "$LOG"
}

run_test tb_wolf_video_pageflip_seam \
  "$ROOT/rtl/pkg/wolf_pkg.sv" \
  "$ROOT/rtl/wolf/wolf_video.sv" \
  "$ROOT/rtl/yunit/yunit_scanline.sv" \
  "$ROOT/rtl/wolf/wolf_video_top.sv" \
  "$ROOT/sim/sdram_model.sv"

run_test tb_wolf_video_blit_guard \
  "$ROOT/rtl/pkg/wolf_pkg.sv" \
  "$ROOT/rtl/wolf/wolf_dma.sv" \
  "$ROOT/rtl/wolf/wolf_video.sv" \
  "$ROOT/rtl/yunit/yunit_scanline.sv" \
  "$ROOT/rtl/wolf/wolf_video_top.sv"

run_test tb_wolf_video_flip_guard \
  "$ROOT/rtl/pkg/wolf_pkg.sv" \
  "$ROOT/rtl/wolf/wolf_video.sv"

run_test tb_tms_dpyadr_load \
  "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" \
  "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv" \
  "$ROOT/rtl/tms34010/rtl/io/tms34010_io_regs.sv"

run_test tb_wolf_video_tms_lock \
  "$ROOT/rtl/pkg/wolf_pkg.sv" \
  "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" \
  "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv" \
  "$ROOT/rtl/wolf/wolf_video.sv"

run_video_mutant() {
  local name="$1"
  local sed_expr="$2"
  local expect="$3"
  local tb="${4:-tb_wolf_video_flip_guard}"
  local mut_video="$OUTDIR/wolf_video_${name}.sv"
  local mut_log="$OUTDIR/${tb}_${name}.log"
  cp "$ROOT/rtl/wolf/wolf_video.sv" "$mut_video"
  sed -i "$sed_expr" "$mut_video"
  "$IVERILOG" -g2012 -s "$tb" -o "$OUTDIR/${tb}_${name}.vvp" \
    "$ROOT/rtl/pkg/wolf_pkg.sv" "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" \
    "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv" "$mut_video" "$ROOT/sim/$tb.sv"
  set +e
  "$VVP" "$OUTDIR/${tb}_${name}.vvp" > "$mut_log" 2>&1
  local status=$?
  set -e
  if [ "$status" -eq 0 ] || ! grep -Fq "$expect" "$mut_log"; then
    cat "$mut_log"
    echo "FAIL: $name mutation survived or failed for the wrong reason" >&2
    exit 1
  fi
  echo "PASS: $name mutant killed"
}

echo "== Mutations: first-line/tail gates, busy barrier, and raster lock =="
run_video_mutant first_line \
  's/else if (s0_vb && (vc < FLIP_COMMIT_LIMIT)) begin/else if (s0_vb \&\& (vc == V_ACT)) begin/' \
  'RESULT: FAIL -- timeout'
run_video_mutant any_vblank \
  's/else if (s0_vb && (vc < FLIP_COMMIT_LIMIT)) begin/else if (s0_vb) begin/' \
  'FAIL: final-line settle stole the scanline prefetch reserve'
run_video_mutant repeating_busy \
  's/if (flip_wait_drain) begin/if (wr_busy_i) begin flip_wait_drain <= 1\x27b1; flip_settle <= FLIP_SETTLE; end else if (flip_wait_drain) begin/' \
  'RESULT: FAIL -- timeout'
run_video_mutant tms_drain_bypass \
  '0,/flip_wait_drain <= wr_busy_i;/s//flip_wait_drain <= 1\x27b0;/' \
  'FAIL: TMS page published before the initial write drain' tb_wolf_video_tms_lock
run_video_mutant raster_unlocked \
  's/wire raster_sync_i = USE_TMS_RASTER_SYNC.*/wire raster_sync_i = 1\x27b0;/' \
  'FAIL: raster did not lock at TMS VSBLNK' tb_wolf_video_tms_lock

echo "== Mutation: omit DMA generation from the publication barrier =="
MUT_TOP="$OUTDIR/wolf_video_top_no_blit_busy.sv"
MUT_TOP_LOG="$OUTDIR/tb_wolf_video_blit_guard_mutant.log"
cp "$ROOT/rtl/wolf/wolf_video_top.sv" "$MUT_TOP"
sed -i 's/wire render_busy = .*/wire render_busy = (wr_busy === 1\x27b1);/' "$MUT_TOP"
grep -Fq "wire render_busy = (wr_busy === 1'b1);" "$MUT_TOP" || {
  echo "FAIL: blit-busy mutation did not apply" >&2
  exit 1
}
"$IVERILOG" -g2012 -s tb_wolf_video_blit_guard -o "$OUTDIR/tb_wolf_video_blit_guard_mutant.vvp" \
  "$ROOT/rtl/pkg/wolf_pkg.sv" "$ROOT/rtl/wolf/wolf_dma.sv" \
  "$ROOT/rtl/wolf/wolf_video.sv" "$ROOT/rtl/yunit/yunit_scanline.sv" \
  "$MUT_TOP" "$ROOT/sim/tb_wolf_video_blit_guard.sv"
set +e
"$VVP" "$OUTDIR/tb_wolf_video_blit_guard_mutant.vvp" > "$MUT_TOP_LOG" 2>&1
mut_status=$?
set -e
if [ "$mut_status" -eq 0 ] || ! grep -Fq 'FAIL: page published while blitter still busy' "$MUT_TOP_LOG"; then
  cat "$MUT_TOP_LOG"
  echo "FAIL: missing blit-busy barrier mutation survived or failed for the wrong reason" >&2
  exit 1
fi
echo "PASS: missing blit-busy barrier mutant killed"

echo "== Mutation: remove the automatic DPYADR load =="
MUT_IO="$OUTDIR/tms34010_io_regs_no_dpyload.sv"
MUT_IO_LOG="$OUTDIR/tb_tms_dpyadr_load_mutant.log"
cp "$ROOT/rtl/tms34010/rtl/io/tms34010_io_regs.sv" "$MUT_IO"
sed -i 's/if (vblank_start_o &&/if (1\x27b0 \&\&/' "$MUT_IO"
grep -q "if (1'b0" "$MUT_IO" || { echo "FAIL: DPYADR-load mutation did not apply" >&2; exit 1; }
"$IVERILOG" -g2012 -s tb_tms_dpyadr_load -o "$OUTDIR/tb_tms_dpyadr_load_mutant.vvp" \
  "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" \
  "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv" "$MUT_IO" \
  "$ROOT/sim/tb_tms_dpyadr_load.sv"
set +e
"$VVP" "$OUTDIR/tb_tms_dpyadr_load_mutant.vvp" > "$MUT_IO_LOG" 2>&1
mut_status=$?
set -e
if [ "$mut_status" -eq 0 ] || ! grep -Fq 'FAIL: VSBLNK loaded DPYADR=' "$MUT_IO_LOG"; then
  cat "$MUT_IO_LOG"
  echo "FAIL: DPYADR-load mutation survived or failed for the wrong reason" >&2
  exit 1
fi
echo "PASS: missing DPYADR-load mutant killed"

run_test tb_wolf_video_ddr_pageflip \
  "$ROOT/rtl/pkg/wolf_pkg.sv" \
  "$ROOT/rtl/yunit/vram_sdram.sv" \
  "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/rtl/wolf/wolf_video.sv" \
  "$ROOT/rtl/yunit/yunit_scanline.sv" \
  "$ROOT/rtl/wolf/wolf_video_top.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv"

grep -Fq 'RESULT: PASS -- page-256 scanout seam matched' "$LOG"
grep -Fq 'RESULT: PASS -- page publication waited for transparent blit completion' "$LOG"
grep -Fq 'RESULT: PASS -- mid-blank page commit preserved prefetch margin' "$LOG"
grep -Fq 'RESULT: PASS -- TMS DPYADR load and software override matched' "$LOG"
grep -Fq 'RESULT: PASS -- scanout phase-locked to TMS DPYADR boundary' "$LOG"
grep -Fq 'RESULT: PASS -- full DDR page-flip chain matched' "$LOG"
echo "PASS: Wolf DDR page-flip release gate"
