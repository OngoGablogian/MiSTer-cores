#!/usr/bin/env python3
# Generate the unpacked gfx-ROM hex for integrated sims (blit source + the CPU
# gfx window @0x02000000). Reproduces MAME init_gfxrom(6bpp) EXACTLY
# (midyunit_m.cpp:269-282): the "gfx" region (0x800000) holds three 2-bit planes
# at 0x000000/0x200000/0x400000 (chunk = region/4 = 0x200000); each unpacked
# pixel byte = plane0 | plane1<<2 | plane2<<4, where planeN(p) =
# (region[N*chunk + p/4] >> (2*(p%4))) & 3.
#
# Output: one hex byte per line (6-bit pixel value 0x00..0x3f) — a byte array
# indexed by *pixel*, matching yunit_mem's gfx[] / yunit_dma src_addr.
# Only the first 0x180000 pixels carry real ROM data (planes loaded 0x000000..
# 0x05FFFF within each 0x200000 chunk); the rest of the region is 0x00 fill.
#
# Usage:  python3 sim/make_gfx_hex.py [/path/to/smashtv.zip]   (run from repo root)
import sys, zipfile
ZIP = sys.argv[1] if len(sys.argv) > 1 else r"D:/deck/fpga/smash tv/roms/smashtv.zip"
DST = "sim/build/smashtv_gfx.hex"
NPIX = 0x180000               # real-data pixels (3 planes x 0x60000 bytes x 4 px/byte)

z = zipfile.ZipFile(ZIP)
region = bytearray(0x800000)  # ROM_REGION(0x800000,"gfx",0) -> 0x00 default fill
loads = [("la1_smash_tv_game_rom_u111.u111", 0x000000),
         ("la1_smash_tv_game_rom_u112.u112", 0x020000),
         ("la1_smash_tv_game_rom_u113.u113", 0x040000),
         ("la1_smash_tv_game_rom_u95.u95",   0x200000),
         ("la1_smash_tv_game_rom_u96.u96",   0x220000),
         ("la1_smash_tv_game_rom_u97.u97",   0x240000),
         ("la1_smash_tv_game_rom_u106.u106", 0x400000),
         ("la1_smash_tv_game_rom_u107.u107", 0x420000),
         ("la1_smash_tv_game_rom_u108.u108", 0x440000)]
for name, off in loads:
    d = z.read(name); region[off:off+len(d)] = d

chunk = 0x200000
out = bytearray(NPIX)
for p in range(NPIX):
    b = p >> 2; sh = 2 * (p & 3)
    d1 = (region[0*chunk + b] >> sh) & 3
    d2 = (region[1*chunk + b] >> sh) & 3
    d3 = (region[2*chunk + b] >> sh) & 3
    out[p] = d1 | (d2 << 2) | (d3 << 4)

with open(DST, "w", newline="\n") as f:
    f.write("\n".join(f"{v:02x}" for v in out) + "\n")
print(f"wrote {DST}: {NPIX} pixels ({NPIX*3} bytes of hex)")
