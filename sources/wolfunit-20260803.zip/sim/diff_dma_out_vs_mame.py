#!/usr/bin/env python3
# diff_dma_out_vs_mame.py -- shared comparator: diff a wolf_dma framebuffer-write stream
# (contract format "%05X %04X" per line, sy*512+sx = addr) against MAME's real captured
# post-blit VRAM (mame-gospel/trace/nearblit/vram_postblit.hex), for the real first blit
# window (X=346 Y=80 W=10 H=12). Used by both the RTL run (run_wolf_dma_realgfx_rtl.sh) and
# can be pointed at the Python model's stream too -- one comparator, one oracle decode.
#
# Usage: python sim/diff_dma_out_vs_mame.py <out_stream_file>
import sys, os

X, Y, W, H = 346, 80, 10, 12
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VRAM_PRE = os.path.join(ROOT, "..", "mame-gospel", "trace", "nearblit", "vram.hex")
VRAM_POST = os.path.join(ROOT, "..", "mame-gospel", "trace", "nearblit", "vram_postblit.hex")

def load_vram(path):
    with open(path) as f:
        return [int(l, 16) for l in f if l.strip()]

def cpu_view_pixel_byte(vram_words, row, col):
    # midtunit_vram_r (mame-gospel/midway/midtunit_v.cpp:299-305): row-stride 256 CPU
    # words (2 scanout pixels/word), low byte only (palette-select byte discarded).
    wi = row * 256 + (col >> 1)
    w = vram_words[wi]
    return (w & 0xff) if (col & 1) == 0 else ((w >> 8) & 0xff)

def main():
    if len(sys.argv) != 2:
        print("usage: diff_dma_out_vs_mame.py <out_stream_file>")
        sys.exit(2)
    predicted = {}
    with open(sys.argv[1]) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            a, d = line.split()
            predicted[int(a, 16)] = int(d, 16)

    vram_post = load_vram(VRAM_POST)
    vram_pre = load_vram(VRAM_PRE)

    mism = 0
    checked = 0
    for row in range(Y, Y + H):
        row_pred, row_mame = [], []
        for col in range(X, X + W):
            e = row * 512 + col
            mame_byte = cpu_view_pixel_byte(vram_post, row, col)
            pre_byte = cpu_view_pixel_byte(vram_pre, row, col)
            val = predicted.get(e)
            pred_byte = (val & 0xff) if val is not None else pre_byte
            checked += 1
            row_pred.append(f"{pred_byte:02x}")
            row_mame.append(f"{mame_byte:02x}")
            if pred_byte != mame_byte:
                mism += 1
        marker = "" if row_pred == row_mame else "  <-- MISMATCH"
        print(f"row={row}: predicted=[{' '.join(row_pred)}] mame=[{' '.join(row_mame)}]{marker}")

    print(f"\nchecked={checked} mismatches={mism}")
    if mism == 0:
        print("RESULT: PASS -- bit-exact vs MAME's real captured post-blit VRAM")
        sys.exit(0)
    else:
        print("RESULT: FAIL -- divergence from MAME ground truth")
        sys.exit(1)

if __name__ == "__main__":
    main()
