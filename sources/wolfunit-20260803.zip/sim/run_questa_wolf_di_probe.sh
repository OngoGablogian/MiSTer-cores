#!/usr/bin/env bash
# Run the Wolf boot smoke (real TMS34010 core + wolf_memsys) under Questa FSE.
set -e
TB="tb_wolf_boot_di_probe"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"

# --- single-instance lock + orphan reaper + real pass/fail (nodelocked FSE) ---
. "$(dirname "$0")/questa_lock.sh"

find_bin() {
  local name="$1"; local env="$2"
  if [ -n "$env" ] && [ -x "$env" ]; then echo "$env"; return; fi
  for d in \
    /c/altera_pro/*/questa_fse/win64 /c/intelFPGA_pro/*/questa_fse/win64 \
    /c/altera/*/questa_fse/win64     /c/intelFPGA/*/questa_fse/win64 ; do
    [ -x "$d/$name.exe" ] && { echo "$d/$name"; return; }
    [ -x "$d/$name" ]     && { echo "$d/$name"; return; }
  done
  local p; p="$(command -v "$name" 2>/dev/null || true)"
  case "$p" in *modelsim_ase*) p="";; esac
  [ -n "$p" ] && echo "$p"
}
VLIB="$(find_bin vlib "$VLIB")"; VLOG="$(find_bin vlog "$VLOG")"; VSIM="$(find_bin vsim "$VSIM")"
if [ -z "$VLOG" ] || [ -z "$VSIM" ]; then
  echo "ERROR: Questa (vlog/vsim) not found. Use Questa FPGA Starter Edition."; exit 1
fi
echo "using: $VLOG"
unset LM_LICENSE_FILE MGLS_LICENSE_FILE
: "${SALT_LICENSE_SERVER:=C:\\altera\\LR-175212_License.dat;C:\\altera\\LR-175213_License.dat}"
export SALT_LICENSE_SERVER

# Acquire the single nodelocked-license slot BEFORE any vlib/vlog/vsim, and make
# sure we release it (and reap our own vsim) on ANY exit — timeout, kill, error.
trap questa_release EXIT
if ! questa_acquire; then
  echo "BLOCKED: could not acquire the Questa nodelocked license (orphan vsim?)."
  exit 75   # EX_TEMPFAIL — BLOCKED, distinct from a real test FAIL. Never a fake pass.
fi

VLOG_FLAGS="-sv -quiet -svinputport=var ${EXTRA_VLOG:-}"

cd "$ROOT/sim"
rm -rf work; "$VLIB" work >/dev/null

SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SRC+=( "$ROOT/rtl/pkg/wolf_pkg.sv" \
       "$ROOT/rtl/wolf/ram_sdram.sv" "$ROOT/sim/sdram_model.sv" \
       "$ROOT/rtl/wolf/wolf_mem.sv" "$ROOT/rtl/wolf/wolf_dma.sv" \
       "$ROOT/rtl/wolf/wolf_pic.sv" "$ROOT/rtl/wolf/wolf_memsys.sv" \
       "$ROOT/sim/$TB.sv" )

echo "compiling ${#SRC[@]} sources ..."
"$VLOG" $VLOG_FLAGS "${SRC[@]}"

echo "simulating $TB ..."
# Capture the FULL vsim output to a log for questa_check_result, while still
# showing the filtered lines. set +e so a vsim/grep failure does not abort
# before we inspect the log.
LOG="$ROOT/sim/build/${TB}.vsim.log"
mkdir -p "$ROOT/sim/build"
set +e
"$VSIM" -c -quiet -do "run -all; quit" "$TB" 2>&1 | tee "$LOG" | grep -iE "PASS|FAIL|FRONTIER|DIPROBE|DERAIL|DIVERGE|golden|NOTE|----|Error|license"
set -e

# Propagate vsim's REAL pass/fail. exit code reflects the true outcome; a
# license error / elaboration error / FAIL / missing PASS is NON-zero.
questa_check_result "$LOG" "PASS"
exit $?
