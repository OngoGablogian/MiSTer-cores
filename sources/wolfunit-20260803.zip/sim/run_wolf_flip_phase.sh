#!/usr/bin/env bash
# Raster-phase capture of the Wolf VRAM-write burst for one title.
# Derived from sim/run_wolf_write_pressure.sh (Lens C) -- same MAME, same NVRAM seeding.
# usage: run_wolf_flip_phase.sh <setname> <romzip-dir> [warm] [span]
set -euo pipefail

SET="$1"
ROMS="$2"
WARM="${3:-6}"
SPAN="${4:-60}"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/sim/build"
MAME="${MAME:-D:/deck/fpga/starwars/sw/starwars-mister/.tools/mame0287/mame.exe}"
SCRIPT="$ROOT/sim/capture_wolf_flip_phase.lua"
OUT="$BUILD/wolf_flipphase_raw_${SET}.txt"
SEED="${WOLF_NVRAM_SEED:-D:/deck/fpga/wolf-nvram-80/by-setname/${SET}.nvm}"

mkdir -p "$BUILD"
NVDIR="$(mktemp -d "$BUILD/wolf_phase_nv.XXXXXX")"
trap 'rm -rf "$NVDIR"' EXIT
mkdir -p "$NVDIR/$SET"
[ -f "$SEED" ] && cp "$SEED" "$NVDIR/$SET/nvram"
rm -f "$OUT"

export WOLF_PHASE_OUT="$OUT"
export WOLF_PHASE_WARM="$WARM"
export WOLF_PHASE_SPAN="$SPAN"
"$MAME" "$SET" -rompath "$ROMS" -nvram_directory "$NVDIR" \
  -nowindow -video none -sound none \
  -seconds_to_run $((WARM + SPAN + 5)) -autoboot_delay 0 \
  -nothrottle -autoboot_script "$SCRIPT"

grep -q '^DONE$' "$OUT"
echo "wrote $OUT ($(grep -c '^B ' "$OUT") blit triggers)"
