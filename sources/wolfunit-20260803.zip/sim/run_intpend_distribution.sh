#!/usr/bin/env bash
# INTPEND (SHARED-P0016) distribution comparison across the Wolf profiles.
#
# Runs tb_wolf_intpend_distribution twice per title with IDENTICAL stimulus,
# varying ONLY rtl/tms34010/rtl/io/tms34010_io_regs.sv:
#   base = git HEAD  (no INTPEND write-zero-to-clear)
#   fix  = working tree (SHARED-P0016 applied)
# and prints the paired distributions. This is a RISK INSTRUMENT, not a gate:
# a pass/fail suite cannot see under-servicing.
#
# License-free: ModelSim ASE only. NEVER touches Questa FSE or Quartus.
#
#   ./sim/run_intpend_distribution.sh                 # all titles
#   TITLES="OPEN_ICE MK3" ./sim/run_intpend_distribution.sh
#   CYCLES=1000000 ./sim/run_intpend_distribution.sh
set -euo pipefail

MS="${MS:-/c/intelFPGA_lite/17.0/modelsim_ase/win32aloem}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"
OUT="$ROOT/sim/build/intpend_dist"
CYCLES="${CYCLES:-3000000}"
TITLES="${TITLES:-OPEN_ICE WWF_MANIA MK3 UMK3 HANGTIME NBAMAX RWT}"

mkdir -p "$OUT"
cd "$ROOT/sim"

# Baseline copy of the ONE file under test, straight from HEAD.
BASE_IO="$OUT/base_io/tms34010_io_regs.sv"
mkdir -p "$OUT/base_io"
( cd "$ROOT" && git show HEAD:rtl/tms34010/rtl/io/tms34010_io_regs.sv ) > "$BASE_IO"
# The package carries the mask parameter the fixed file needs; the baseline file
# never references it, so the SAME (working-tree) package is used for both runs.
# That keeps the package out of the comparison: the only delta is the io_regs body.

collect_srcs() {
  local io_override="$1"
  SRC=( "$CORE/rtl/tms34010_pkg.sv" )
  while IFS= read -r f; do
    case "$f" in
      */tms34010_pkg.sv) continue;;
      */io/tms34010_io_regs.sv) [ -n "$io_override" ] && continue;;
    esac
    SRC+=( "$f" )
  done < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
  [ -n "$io_override" ] && SRC+=( "$io_override" )
  SRC+=( "$ROOT/rtl/pkg/wolf_pkg.sv"
         "$ROOT/rtl/wolf/ram_sdram.sv" "$ROOT/sim/sdram_model.sv"
         "$ROOT/rtl/wolf/wolf_mem.sv" "$ROOT/rtl/wolf/wolf_dma.sv"
         "$ROOT/rtl/wolf/wolf_pic.sv" "$ROOT/rtl/wolf/wolf_dcs_stub.sv"
         "$ROOT/rtl/wolf/wolf_memsys.sv"
         "$ROOT/sim/tb_wolf_intpend_distribution.sv" )
}

run_one() {
  local title="$1" variant="$2" io_override="$3"
  local log="$OUT/${title,,}_${variant}.log"
  local wl="$OUT/work_${title,,}_${variant}"
  collect_srcs "$io_override"
  rm -rf "$wl"; "$MS/vlib.exe" "$wl" >/dev/null

  "$MS/vlog.exe" -sv -quiet -svinputport=var -work "$wl" \
    "+define+${title}_PROF" \
    "+define+RUN_CYCLES=${CYCLES}" \
    "+define+VARIANT_NAME=\"${variant}\"" \
    "${SRC[@]}" > "$OUT/${title,,}_${variant}.vlog.log" 2>&1 || {
      echo "COMPILE FAILED ($title/$variant) -- see $OUT/${title,,}_${variant}.vlog.log" >&2
      tail -20 "$OUT/${title,,}_${variant}.vlog.log" >&2; return 1; }
  "$MS/vsim.exe" -c -quiet -lib "$wl" -do "run -all; quit -f" \
    tb_wolf_intpend_distribution > "$log" 2>&1 || true
  if ! grep -q "DIST_END" "$log"; then
    echo "RUN INCOMPLETE ($title/$variant) -- see $log" >&2
    tail -15 "$log" >&2; return 1
  fi
  sed -n 's/^# //p' "$log" | grep '^DIST'
}

for t in $TITLES; do
  echo "================ $t  (${CYCLES} cycles) ================"
  echo "---- base (HEAD, no INTPEND w0c) ----"
  run_one "$t" base "$BASE_IO" || echo "(base run failed)"
  echo "---- fix (SHARED-P0016 applied) ----"
  run_one "$t" fix  "" || echo "(fix run failed)"
done
