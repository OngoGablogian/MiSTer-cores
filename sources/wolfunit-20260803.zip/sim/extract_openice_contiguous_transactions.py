#!/usr/bin/env python3
"""Normalize contiguous Open Ice MAME capture into DISPLAY transactions."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path


CAPTURE_HZ = Decimal(80_000_000)


@dataclass(frozen=True)
class Blit:
    screen: int
    cycle: int
    registers: tuple[int, ...]


def is_dummy(blit: Blit) -> bool:
    regs = blit.registers
    return (
        regs[1] == 0x8000
        and (regs[6] & 0x3FF) == 400
        and (regs[7] & 0x3FF) == 2
    )


def read_capture(path: Path) -> list[Blit]:
    result: list[Blit] = []
    for line_number, raw_line in enumerate(
        path.read_text(encoding="ascii").splitlines(), 1
    ):
        fields = raw_line.split()
        if not fields or fields[0] != "BLIT":
            continue
        if len(fields) not in (22, 23):
            raise ValueError(
                f"{path}:{line_number}: expected 22 or 23 fields, got {len(fields)}"
            )
        result.append(
            Blit(
                screen=int(fields[2]),
                cycle=int(
                    (Decimal(fields[3]) * CAPTURE_HZ).to_integral_value(
                        rounding=ROUND_HALF_UP
                    )
                ),
                registers=tuple(int(word, 16) for word in fields[4:22]),
            )
        )
    if not result:
        raise ValueError(f"{path}: no BLIT records")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capture", type=Path)
    parser.add_argument("--output", "-o", type=Path, required=True)
    parser.add_argument("--base-rank", type=int, default=301)
    args = parser.parse_args()

    blits = read_capture(args.capture)
    starts = [index for index, blit in enumerate(blits) if is_dummy(blit)]
    if len(starts) < 2:
        raise ValueError("capture has fewer than two DISPLAY dummy commands")

    lines: list[str] = []
    for transaction_index, (start, end) in enumerate(zip(starts, starts[1:])):
        rank = args.base_rank + transaction_index
        transaction = blits[start:end]
        first_cycle = transaction[0].cycle
        lines.append(
            f"CANDIDATE {rank} screen={transaction[0].screen} "
            f"blits={len(transaction)}"
        )
        for ordinal, blit in enumerate(transaction, 1):
            words = " ".join(f"{word:04X}" for word in blit.registers)
            lines.append(
                f"BLIT {rank} {blit.screen} {ordinal} {words} "
                f"{blit.cycle - first_cycle}"
            )
    lines.append("DONE")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(lines) + "\n", encoding="ascii", newline="\n")
    print(
        f"OPENICE_CONTIG_TRANSACTIONS count={len(starts)-1} "
        f"ranks={args.base_rank}..{args.base_rank+len(starts)-2} "
        f"output={args.output}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
