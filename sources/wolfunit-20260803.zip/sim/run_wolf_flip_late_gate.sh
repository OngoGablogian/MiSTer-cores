#!/usr/bin/env bash
# HUD-flash regression: how many scanlines of render drain can overrun the frame
# boundary before the page flip MISSES its blanking commit window and slips a
# whole frame (showing the previous page's HUD -- the cabinet symptom)?
#
# The flip may only commit while (vc >= V_ACT) && (vc < V_TOTAL-FLIP_PREFETCH_LINES),
# so every line reserved for scanline priming comes straight out of the drain
# budget. Production reserves 1 line (MEASURED need: 2 rows x NCOL(456) x 2 clk
# = 1,824 cycles = 0.36 of a 5,060-cycle line, i.e. 2.8x headroom).
#
# FAST MODE (default; cheap enough for the release suite): two runs.
#   - production MUST still commit at PASS_AT scanlines of drain
#   - production MUST still MISS at FAIL_AT scanlines
# The second assertion is what stops this passing vacuously. A gate that only
# checked "it works at 33" would also pass if the flip were made unconditional,
# which would reintroduce mid-frame tearing -- a worse bug than the one fixed.
#
# FULL=1 additionally re-measures the A/B threshold against the old 4-line
# reserve (~30 sims). Use that when the parameter itself is changed.
set -uo pipefail
cd "$(dirname "$0")"
IVERILOG=${IVERILOG:-/c/iverilog/bin/iverilog}
VVP=${VVP:-/c/iverilog/bin/vvp}
B=build/flip_late; mkdir -p "$B"
PASS_AT=${PASS_AT:-33}
FAIL_AT=${FAIL_AT:-35}

SRC="../rtl/pkg/wolf_pkg.sv ../rtl/wolf/wolf_video.sv ../rtl/yunit/yunit_scanline.sv ../rtl/wolf/wolf_video_top.sv tb_wolf_flip_late.sv"

build()     { $IVERILOG -g2012 -Ptb_wolf_flip_late.PREFETCH=$1 -o "$B/fl_$1.vvp" $SRC 2>/dev/null; }
shows_new() { $VVP "$B/fl_$1.vvp" +BUSYLINES=$2 2>/dev/null | grep -q "new page (ok)"; }

# Read the shipped value rather than hardcoding it, so the gate tracks the RTL.
PROD=$(sed -n 's/.*parameter int FLIP_PREFETCH_LINES *= *\([0-9]*\).*/\1/p' \
        ../rtl/wolf/wolf_video.sv | head -1)
[ -n "$PROD" ] || { echo "FAIL: could not read FLIP_PREFETCH_LINES from wolf_video.sv"; exit 1; }
echo "production FLIP_PREFETCH_LINES = $PROD"
build "$PROD" || { echo "FAIL: build error"; exit 1; }

if shows_new "$PROD" "$PASS_AT"; then
  echo "  ok   commits with $PASS_AT scanlines of drain"
else
  echo "FAIL: production misses the commit window at $PASS_AT scanlines of drain"
  exit 1
fi

if shows_new "$PROD" "$FAIL_AT"; then
  echo "FAIL: production still commits at $FAIL_AT scanlines -- the commit window"
  echo "      is no longer bounded by blanking; mid-frame tearing would return."
  exit 1
else
  echo "  ok   correctly misses at $FAIL_AT scanlines (proves the gate CAN fail)"
fi

if [ "${FULL:-0}" = "1" ]; then
  measure() {
    build "$1"
    local ok=0
    for N in $(seq 26 40); do shows_new "$1" "$N" && ok=$N; done
    echo "$ok"
  }
  OLD=$(measure 4)
  NEW=$(measure "$PROD")
  echo "A/B: reserve=4 -> $OLD lines ; reserve=$PROD (production) -> $NEW lines"
  [ "$NEW" -gt "$OLD" ] || { echo "FAIL: production does not beat the old 4-line reserve"; exit 1; }
fi

echo "PASS: page-flip commit window holds ($PASS_AT ok / $FAIL_AT correctly missed)"
