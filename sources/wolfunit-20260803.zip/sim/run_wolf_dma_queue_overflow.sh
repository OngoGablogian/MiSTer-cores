#!/usr/bin/env bash
set -euo pipefail

export PATH="/c/iverilog/bin:/usr/local/bin:/usr/bin:/bin"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/sim/build/tb_wolf_dma_queue_overflow.vvp"
LOG="$ROOT/sim/build/tb_wolf_dma_queue_overflow.log"

cd "$ROOT"
mkdir -p sim/build
/c/iverilog/bin/iverilog -g2012 -s tb_wolf_dma_queue_overflow -o "$OUT" \
  rtl/pkg/wolf_pkg.sv rtl/wolf/wolf_dma.sv sim/tb_wolf_dma_queue_overflow.sv
/c/iverilog/bin/vvp "$OUT" | tee "$LOG"
grep -q '^PASS:' "$LOG"
! grep -q '^FAIL:' "$LOG"
