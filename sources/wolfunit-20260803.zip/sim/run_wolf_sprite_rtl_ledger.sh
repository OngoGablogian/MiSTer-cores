#!/usr/bin/env bash
# Emit a command-by-command RTL source/read and committed-write ledger for one
# captured UMK3 frame. This is simulation-only and uses untimed replay so each
# command boundary is unambiguous.
set -euo pipefail

export PATH="/c/iverilog/bin:/usr/local/bin:/usr/bin:/bin"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
IVERILOG="${IVERILOG:-/c/iverilog/bin/iverilog}"
VVP="${VVP:-/c/iverilog/bin/vvp}"
TRACE="${TRACE:-sim/traces/umk3_peak_bio_regs.txt}"
RANK="${RANK:-4}"
LEDGER="${LEDGER:-sim/build/sprite_rtl_ledger.txt}"
OUT="$ROOT/sim/build/tb_wolf_sprite_rtl_ledger.vvp"
LOG="$ROOT/sim/build/tb_wolf_sprite_rtl_ledger.log"

cd "$ROOT"
test -f sim/build/umk3_gfx.hex
test -f "$TRACE"
mkdir -p sim/build

"$IVERILOG" -g2012 -s tb_wolf_peak_fight_budget -o "$OUT" \
  rtl/pkg/wolf_pkg.sv \
  rtl/wolf/wolf_dma.sv \
  rtl/yunit/vram_sdram.sv \
  rtl/yunit/vram_sdram_top.sv \
  rtl/sdram/stv_vram_ddr_agent.sv \
  rtl/sdram/stv_vram_ddr_top.sv \
  rtl/sdram/wolf_gfx_ddr_top.sv \
  rtl/sdram/wolf_ddr3_arb.sv \
  sim/ddr3_avalon_model.sv \
  sim/tb_wolf_peak_fight_budget.sv

"$VVP" "$OUT" "+TRACE=$TRACE" "+RANK=$RANK" "+LEDGER=$LEDGER" | tee "$LOG"
grep -q '^PASS: live-fight frame retires' "$LOG"
test -s "$LEDGER"
echo "ledger: $ROOT/$LEDGER"
