#!/usr/bin/env bash
# End-to-end sim: TMS34010 game system + Williams CVSD sound board (mixed lang).
#   ./run_questa_e2e.sh [tb_yunit_sound] [+ARGS...]
set -e
TB="${1:-tb_yunit_sound}"; shift || true
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"
SND="$ROOT/rtl/sound"

# --- single-instance lock + orphan reaper + real pass/fail (nodelocked FSE) ---
. "$(dirname "$0")/questa_lock.sh"

for d in /c/altera/*/questa_fse/win64 /c/altera_pro/*/questa_fse/win64; do
  [ -x "$d/vlog.exe" ] && { VLOG="$d/vlog"; VCOM="$d/vcom"; VSIM="$d/vsim"; VLIB="$d/vlib"; break; }
done
[ -n "$VLOG" ] || { echo "Questa not found"; exit 1; }
unset LM_LICENSE_FILE MGLS_LICENSE_FILE

# Acquire the single nodelocked-license slot BEFORE any vlib/vlog/vsim, and make
# sure we release it (and reap our own vsim) on ANY exit — timeout, kill, error.
trap questa_release EXIT
if ! questa_acquire; then
  echo "BLOCKED: could not acquire the Questa nodelocked license (orphan vsim?)."
  exit 75   # EX_TEMPFAIL — BLOCKED, distinct from a real test FAIL. Never a fake pass.
fi

cd "$ROOT/sim"
rm -rf work_e2e; "$VLIB" work_e2e >/dev/null

SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SRC+=( "$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/yunit/yunit_mem.sv" "$ROOT/rtl/yunit/yunit_dma.sv" "$ROOT/rtl/yunit/yunit_memsys.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$SND/jt51/hdl" -maxdepth 1 -name '*.v' | sort)
SRC+=( "$SND/williams_cvsd/mc6809is.v" "$SND/smashtv_snd_rom.sv" "$ROOT/sim/$TB.sv" )

"$VLOG" -sv -quiet -svinputport=var -work work_e2e "${SRC[@]}"

"$VCOM" -2008 -quiet -work work_e2e \
  "$SND/williams_cvsd/gen_ram.vhd" \
  "$SND/williams_cvsd/hc55564.vhd" \
  "$SND/williams_cvsd/pia6821.vhd" \
  "$SND/williams_cvsd/williams_cvsd_board.vhd"

echo "running $TB ..."
# Capture the FULL vsim output to a log for questa_check_result, while still
# showing the filtered lines. set +e so a vsim/grep failure does not abort
# before we inspect the log.
LOG="$ROOT/sim/build/${TB}.vsim.log"
mkdir -p "$ROOT/sim/build"
set +e
"$VSIM" -c -quiet -work work_e2e -do "run -all; quit -f" "$TB" "$@" 2>&1 | tee "$LOG" | grep -vE "^# (Loading|//|\*\* Note)"
set -e

# Propagate vsim's REAL pass/fail. exit code reflects the true outcome; a
# license error / elaboration error / FAIL / missing PASS is NON-zero.
questa_check_result "$LOG" "PASS"
exit $?
