#!/usr/bin/env bash
# Motaro flip-phase capture: navigate to the Winner-Fights-Motaro fight
# (Kombat Kode 969-141) and record the phase anchor (VSBLNK / DPYADR /
# DPYSTRT / DPYCTL / DMA GOs) plus full replayable register images for a
# window of live-fight frames.  MAME only -- no Quartus, no RTL.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/sim/build"
MAME="${MAME:-C:/tools/mame/mame.exe}"
ROMS="${UMK3_ROMS:-D:/deck/fpga/umk3/roms}"
SCRIPT="$ROOT/sim/capture_umk3_motaro_flip_phase.lua"
OUT="${OUT:-$BUILD/umk3_motaro_flipphase.txt}"
SNAPDIR="${SNAPDIR:-$BUILD/motaro_phase_snaps}"

mkdir -p "$BUILD" "$SNAPDIR"
NVDIR="$(mktemp -d "$BUILD/umk3_motaro_phase_nv.XXXXXX")"
trap 'rm -rf "$NVDIR"' EXIT
rm -f "$OUT"

export WOLF_MOTARO_PHASE_OUT="$OUT"
export WOLF_MOTARO_PHASE_FRAMES="${WOLF_MOTARO_PHASE_FRAMES:-12}"
"$MAME" umk3 -rompath "$ROMS" -nvram_directory "$NVDIR" \
  -snapshot_directory "$SNAPDIR" \
  -nowindow -video none -sound none -seconds_to_run 210 -autoboot_delay 0 \
  -nothrottle -autoboot_script "$SCRIPT"

grep -q '^DONE$' "$OUT"
echo "phase lines: VS=$(grep -c '^VS ' "$OUT") DPYADR=$(grep -c '^DPYADR ' "$OUT") RBLIT=$(grep -c '^RBLIT ' "$OUT")"
grep '^PHASE ' "$OUT"
grep '^NBLITS ' "$OUT"
