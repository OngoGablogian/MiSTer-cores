#!/usr/bin/env python3
# diff_scaled.py -- diff the DUT framebuffer-write stream for the captured SCALED blit against
# MAME's real pre/post VRAM (mame-gospel/trace/scaled/vram_{pre,post}.hex, full CPU-view, 262144
# words). Finds MAME's actual drawn footprint (post!=pre bbox), compares the DUT there, prints a
# per-row diff, and renders a side-by-side PNG (MAME | DUT | mismatch) for visual evidence.
# Usage: python sim/diff_scaled.py <dut_out_stream_file>
import sys, os, re
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SC = os.path.join(ROOT, "..", "mame-gospel", "trace", "scaled")

def load(p): return [int(l, 16) for l in open(p) if l.strip()]
def px(vram, row, col):
    w = vram[row * 256 + (col >> 1)]
    return (w & 0xff) if (col & 1) == 0 else ((w >> 8) & 0xff)

def main():
    pre = load(os.path.join(SC, "vram_pre.hex"))
    post = load(os.path.join(SC, "vram_post.hex"))
    dut = {}
    for line in open(sys.argv[1]):
        line = line.strip()
        if not line: continue
        a, d = line.split(); dut[int(a, 16)] = int(d, 16)

    info = open(os.path.join(SC, "scaled_blit.txt")).read()
    m = dict(re.findall(r'(\w+)=([0-9A-Fa-f]+)', info))
    X, Y, W, H = int(m['X']), int(m['Y']), int(m['W']), int(m['H'])
    print("blit: X=%d Y=%d srcW=%d srcH=%d SCALEX=%s SCALEY=%s cmd=%s"
          % (X, Y, W, H, m.get('SCALEX'), m.get('SCALEY'), m.get('cmd')))

    # MAME's actual drawn footprint = bbox of changed pixels in a generous search box
    sx0, sx1 = max(0, X - 8), min(511, X + 260)
    sy0, sy1 = max(0, Y - 8), min(1023, Y + 260)
    chg = [(r, c) for r in range(sy0, sy1 + 1) for c in range(sx0, sx1 + 1) if px(post, r, c) != px(pre, r, c)]
    if not chg:
        print("MAME drew NOTHING changed in the search box -- check capture"); sys.exit(2)
    rmin = min(r for r, c in chg); rmax = max(r for r, c in chg)
    cmin = min(c for r, c in chg); cmax = max(c for r, c in chg)
    print("MAME drawn footprint: cols %d..%d (%d) rows %d..%d (%d), %d pixels changed"
          % (cmin, cmax, cmax - cmin + 1, rmin, rmax, rmax - rmin + 1, len(chg)))

    def dut_byte(row, col):
        e = row * 512 + col
        v = dut.get(e)
        return (v & 0xff) if v is not None else px(pre, row, col)

    mism = 0; checked = 0; rows_out = []
    for row in range(rmin, rmax + 1):
        rp, rm = [], []
        for col in range(cmin, cmax + 1):
            mb = px(post, row, col); db = dut_byte(row, col)
            rp.append(db); rm.append(mb); checked += 1
            if db != mb: mism += 1
        rows_out.append((row, rp, rm))
    for row, rp, rm in rows_out[:24]:
        bad = sum(1 for a, b in zip(rp, rm) if a != b)
        mark = "" if bad == 0 else "  <-- %d MISMATCH" % bad
        print("row=%d dut=[%s] mame=[%s]%s" % (row, ' '.join('%02x' % b for b in rp),
              ' '.join('%02x' % b for b in rm), mark))
    print("\nchecked=%d mismatches=%d (%.1f%%)" % (checked, mism, 100.0 * mism / max(1, checked)))

    try:
        from PIL import Image
        w = cmax - cmin + 1; h = rmax - rmin + 1
        img = Image.new("RGB", (w * 3 + 8, h), (30, 30, 30))
        pxs = img.load()
        for row in range(rmin, rmax + 1):
            for col in range(cmin, cmax + 1):
                mb = px(post, row, col); db = dut_byte(row, col)
                y = row - rmin; xb = col - cmin
                pxs[xb, y] = (mb, mb, mb)
                pxs[w + 4 + xb, y] = (db, db, db)
                pxs[2 * w + 8 + xb, y] = (200, 30, 30) if db != mb else (20, 60, 20)
        outp = os.path.join(SC, "scaled_diff.png")
        img.save(outp)
        print("visual: %s (MAME | DUT | mismatch-map, %dx%d each)" % (outp, w, h))
    except Exception as e:
        print("PNG skipped: %s" % e)

    print("RESULT: %s" % ("PASS -- bit-exact scaled blit" if mism == 0 else "FAIL -- scale-path divergence"))
    sys.exit(0 if mism == 0 else 1)

if __name__ == "__main__":
    main()
