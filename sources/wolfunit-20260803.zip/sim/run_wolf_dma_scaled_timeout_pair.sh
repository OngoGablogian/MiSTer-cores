#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP_ROOT="${TMPDIR:-/tmp}"
TMP="$(mktemp -d "$TMP_ROOT/wolf_dma_scaled_timeout_pair.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT

IVERILOG="${IVERILOG:-/c/iverilog/bin/iverilog}"
VVP="${VVP:-/c/iverilog/bin/vvp}"

cd "$ROOT"
"$IVERILOG" -g2012 -s tb_wolf_dma_scaled_timeout_pair \
  -o "$TMP/tb.vvp" \
  rtl/pkg/wolf_pkg.sv \
  rtl/wolf/wolf_dma.sv \
  sim/tb_wolf_dma_scaled_timeout_pair.sv

"$VVP" -n "$TMP/tb.vvp" | tee "$TMP/tb.log"
grep -q '^PASS: scaled timeout pair preserves' "$TMP/tb.log"
