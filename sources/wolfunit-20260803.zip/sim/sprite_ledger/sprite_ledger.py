#!/usr/bin/env python3
"""Build a normalized per-blit ledger from a captured Wolf-unit DMA frame.

The pixel oracle remains sim/wolf_dma_model.py. This utility only adds trace
parsing, source-read instrumentation, controlled clipping/skip counterfactuals,
and stable JSON Lines output for a later MAME-vs-RTL comparison.
"""

from __future__ import annotations

import argparse
import io
import json
import mmap
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable, TextIO


SIM_DIR = Path(__file__).resolve().parents[1]
REPO_ROOT = SIM_DIR.parent
if str(SIM_DIR) not in sys.path:
    sys.path.insert(0, str(SIM_DIR))

import wolf_dma_model as dma_model  # noqa: E402


SCHEMA = "wolf-sprite-ledger-v1"
FNV64_OFFSET = 0xCBF29CE484222325
FNV64_PRIME = 0x00000100000001B3
FNV64_MASK = (1 << 64) - 1
FB_ADDR_MASK = (1 << 19) - 1

REGISTER_NAMES = (
    "lrskip",
    "command",
    "offset_lo",
    "offset_hi",
    "x_start",
    "y_start",
    "width",
    "height",
    "palette",
    "color",
    "scale_x",
    "scale_y",
    "top_clip",
    "bottom_clip",
    "unknown_e",
    "config",
    "left_clip",
    "right_clip",
)

OP_NAMES = {
    dma_model.PIXEL_SKIP: "skip",
    dma_model.PIXEL_COLOR: "color",
    dma_model.PIXEL_COPY: "copy",
}

CANDIDATE_RE = re.compile(r"^(?:RINK_)?CANDIDATE\s+(\d+)\s+(.*)$")
KEY_VALUE_RE = re.compile(r"([A-Za-z_]+)=([^\s]+)")


class LedgerError(RuntimeError):
    """Input or ledger-generation error with a user-facing message."""


@dataclass(frozen=True)
class CapturedBlit:
    capture_rank: int
    mame_frame: int
    capture_index: int
    registers: tuple[int, ...]


@dataclass(frozen=True)
class CapturedFrame:
    capture_rank: int
    metadata: dict[str, int]
    blits: tuple[CapturedBlit, ...]


def _parse_int(text: str, *, base: int = 10) -> int:
    try:
        return int(text, base)
    except ValueError as exc:
        raise LedgerError(f"invalid integer {text!r}") from exc


def parse_trace_lines(lines: Iterable[str]) -> dict[int, CapturedFrame]:
    """Parse CANDIDATE/BLIT records emitted by capture_umk3_peak_fight_regs.lua."""

    metadata_by_rank: dict[int, dict[str, int]] = {}
    blits_by_rank: dict[int, list[CapturedBlit]] = {}

    for line_number, raw_line in enumerate(lines, 1):
        line = raw_line.strip()
        if not line or line == "DONE":
            continue
        if line.startswith("ERROR "):
            raise LedgerError(f"capture reports an error at line {line_number}: {line[6:]}")

        candidate_match = CANDIDATE_RE.match(line)
        if candidate_match:
            rank = _parse_int(candidate_match.group(1))
            if rank in metadata_by_rank:
                raise LedgerError(f"duplicate CANDIDATE {rank} at line {line_number}")
            metadata: dict[str, int] = {}
            for key, value in KEY_VALUE_RE.findall(candidate_match.group(2)):
                try:
                    metadata[key] = _parse_int(value, base=0)
                except LedgerError:
                    # Newer captures also carry decimal timing/phase metadata.
                    # The pixel ledger needs only the integer geometry fields.
                    pass
            metadata_by_rank[rank] = metadata
            blits_by_rank[rank] = []
            continue

        if line.startswith("BLIT "):
            fields = line.split()
            if len(fields) not in (22, 23):
                raise LedgerError(
                    f"line {line_number}: expected BLIT plus 3 ids, 18 registers, "
                    f"and an optional capture-cycle field; "
                    f"found {len(fields) - 1} fields"
                )
            rank = _parse_int(fields[1])
            if rank not in blits_by_rank:
                raise LedgerError(f"line {line_number}: BLIT precedes CANDIDATE {rank}")
            mame_frame = _parse_int(fields[2])
            capture_index = _parse_int(fields[3])
            try:
                registers = tuple(int(token, 16) & 0xFFFF for token in fields[4:22])
            except ValueError as exc:
                raise LedgerError(f"line {line_number}: invalid hexadecimal register") from exc
            blits_by_rank[rank].append(
                CapturedBlit(rank, mame_frame, capture_index, registers)
            )
            continue

        if line.startswith("FRAME_EDGES "):
            continue

        raise LedgerError(f"line {line_number}: unrecognized capture record {line!r}")

    frames: dict[int, CapturedFrame] = {}
    for rank, metadata in metadata_by_rank.items():
        blits = tuple(blits_by_rank[rank])
        expected = metadata.get("blits")
        if expected is not None and expected != len(blits):
            raise LedgerError(
                f"CANDIDATE {rank} declares {expected} blits but contains {len(blits)}"
            )
        for ordinal, blit in enumerate(blits, 1):
            if blit.capture_index != ordinal:
                raise LedgerError(
                    f"CANDIDATE {rank} has capture index {blit.capture_index} "
                    f"where ordinal {ordinal} was expected"
                )
            screen = metadata.get("screen")
            if screen is not None and screen != blit.mame_frame:
                raise LedgerError(
                    f"CANDIDATE {rank} header screen {screen} disagrees with "
                    f"BLIT frame {blit.mame_frame}"
                )
        frames[rank] = CapturedFrame(rank, metadata, blits)

    if not frames:
        raise LedgerError("capture contains no CANDIDATE records")
    return frames


def parse_trace(path: Path) -> dict[int, CapturedFrame]:
    with path.open("r", encoding="ascii") as trace_file:
        return parse_trace_lines(trace_file)


class ReadmemhByteRom:
    """Random-access reader for the one-two-digit-byte-per-line GFX hex image.

    The checked-in generator emits a 32 MiB image as fixed-width ``xx\n``
    records. mmap avoids materializing a second 32 MiB Python byte string and
    makes the many counterfactual model passes cheap.
    """

    def __init__(self, path: Path):
        self.path = path
        self._file = path.open("rb")
        self._map = mmap.mmap(self._file.fileno(), 0, access=mmap.ACCESS_READ)
        newline = self._map.find(b"\n")
        if newline < 0:
            self.close()
            raise LedgerError(f"{path}: expected readmemh byte lines")
        self._stride = newline + 1
        token = self._map[:newline].rstrip(b"\r")
        if len(token) != 2 or len(self._map) % self._stride != 0:
            self.close()
            raise LedgerError(
                f"{path}: expected fixed-width two-hex-digit byte records"
            )
        self.size = len(self._map) // self._stride
        # Validate both ends so a malformed file fails before a long ledger run.
        self._decode_at(0)
        self._decode_at(self.size - 1)

    @staticmethod
    def _nibble(value: int) -> int:
        if 48 <= value <= 57:
            return value - 48
        if 65 <= value <= 70:
            return value - 55
        if 97 <= value <= 102:
            return value - 87
        raise LedgerError(f"invalid hex digit byte 0x{value:02X}")

    def _decode_at(self, address: int) -> int:
        position = address * self._stride
        return (self._nibble(self._map[position]) << 4) | self._nibble(
            self._map[position + 1]
        )

    def __call__(self, address: int) -> int:
        if 0 <= address < self.size:
            return self._decode_at(address)
        return 0

    def close(self) -> None:
        mapped = getattr(self, "_map", None)
        if mapped is not None:
            mapped.close()
            self._map = None
        opened = getattr(self, "_file", None)
        if opened is not None:
            opened.close()
            self._file = None

    def __enter__(self) -> "ReadmemhByteRom":
        return self

    def __exit__(self, _exc_type, _exc, _traceback) -> None:
        self.close()


class SourceReadTracer:
    """Count MAME portable-EXTRACTGEN byte reads without storing the stream."""

    def __init__(self, reader: Callable[[int], int], size: int):
        self.reader = reader
        self.size = size
        self.read_calls = 0
        self.out_of_range = 0
        self.minimum: int | None = None
        self.maximum: int | None = None
        self.unique: set[int] = set()

    def __call__(self, address: int) -> int:
        self.read_calls += 1
        self.minimum = address if self.minimum is None else min(self.minimum, address)
        self.maximum = address if self.maximum is None else max(self.maximum, address)
        self.unique.add(address)
        if not (0 <= address < self.size):
            self.out_of_range += 1
        return self.reader(address)

    def as_dict(self) -> dict[str, int | None]:
        return {
            "semantic_extract_count": self.read_calls // 2,
            "portable_byte_read_count": self.read_calls,
            "unique_byte_address_count": len(self.unique),
            "byte_address_min": self.minimum,
            "byte_address_max": self.maximum,
            "out_of_range_byte_read_count": self.out_of_range,
        }


def replay_writes(registers: tuple[int, ...] | list[int]) -> list[tuple[int, int]]:
    """Recreate tb_wolf_peak_fight_budget.sv's bank-aware register load."""

    r = list(registers)
    if len(r) != 18:
        raise LedgerError(f"expected 18 logical DMA registers, found {len(r)}")
    return [
        (15, r[15] & 0xFFDF),
        (12, r[16]),
        (13, r[17]),
        (15, r[15] | 0x0020),
        (12, r[12]),
        (13, r[13]),
        (0, r[0]),
        (2, r[2]),
        (3, r[3]),
        (4, r[4]),
        (5, r[5]),
        (6, r[6]),
        (7, r[7]),
        (8, r[8]),
        (9, r[9]),
        (10, r[10]),
        (11, r[11]),
        (14, r[14]),
        (15, r[15] | 0x0020),
        (1, r[1]),
    ]


def execute_model(
    registers: tuple[int, ...] | list[int],
    rom_reader: Callable[[int], int],
    rom_size: int,
    *,
    trace_source: bool = False,
) -> tuple[list[tuple[int, int]], SourceReadTracer | None]:
    """Run one complete captured register image through the existing oracle."""

    tracer = SourceReadTracer(rom_reader, rom_size) if trace_source else None
    active_reader = tracer if tracer is not None else rom_reader
    original_reader = dma_model.gfx_byte
    dma_model.gfx_byte = active_reader
    try:
        dma = dma_model.WolfDMA()
        for offset, value in replay_writes(registers):
            dma.dma_w(offset, value, 0xFFFF)
        return list(dma.stream), tracer
    finally:
        dma_model.gfx_byte = original_reader


def variant_registers(
    original: tuple[int, ...],
    *,
    full_x_clip: bool = False,
    full_y_clip: bool = False,
    force_copy_all: bool = False,
    disable_compressed_skip: bool = False,
    disable_lrskip: bool = False,
) -> tuple[int, ...]:
    """Build one controlled counterfactual without changing draw geometry."""

    registers = list(original)
    original_command = registers[1]
    if full_x_clip:
        registers[16] = 0
        registers[17] = 0x03FF
    if full_y_clip:
        registers[12] = 0
        registers[13] = 0x01FF
    if force_copy_all:
        # P0P1 writes both zero and nonzero pixels and preserves X flip.
        registers[1] = (registers[1] & ~0x000F) | 0x0003
        # MAME forces mode-C's source bit offset to zero before drawing. Keep
        # that same compressed-row geometry after changing its pixel op mode.
        if (original_command & 0x000F) == 0x000C:
            registers[2] = 0
            registers[3] = 0
    if disable_compressed_skip:
        registers[1] &= ~0x0080
    if disable_lrskip:
        registers[0] = 0
    return tuple(value & 0xFFFF for value in registers)


def fnv64_writes(
    writes: Iterable[tuple[int, int]], initial: int = FNV64_OFFSET
) -> int:
    """Hash ``{fb_addr[18:0], fb_data[15:0]}`` exactly like the RTL testbench."""

    result = initial
    for address, data in writes:
        token = ((address & FB_ADDR_MASK) << 16) | (data & 0xFFFF)
        result = ((result ^ token) * FNV64_PRIME) & FNV64_MASK
    return result


def fnv_text(value: int) -> str:
    return f"0x{value:016X}"


def destination_summary(
    writes: list[tuple[int, int]], frame_prefix_initial: int
) -> tuple[dict[str, object], int]:
    per_blit_hash = fnv64_writes(writes)
    frame_prefix_hash = fnv64_writes(writes, frame_prefix_initial)
    if writes:
        addresses = [address for address, _data in writes]
        xs = [address & 0x1FF for address in addresses]
        ys = [address >> 9 for address in addresses]
        bbox: dict[str, int] | None = {
            "x_min": min(xs),
            "x_max": max(xs),
            "y_min": min(ys),
            "y_max": max(ys),
        }
        first_write: dict[str, int] | None = {
            "address": writes[0][0],
            "data": writes[0][1],
        }
        last_write: dict[str, int] | None = {
            "address": writes[-1][0],
            "data": writes[-1][1],
        }
        address_min: int | None = min(addresses)
        address_max: int | None = max(addresses)
    else:
        bbox = None
        first_write = None
        last_write = None
        address_min = None
        address_max = None

    return (
        {
            "ordered_write_count": len(writes),
            "per_blit_fnv64": fnv_text(per_blit_hash),
            "frame_prefix_fnv64": fnv_text(frame_prefix_hash),
            "linear_address_min": address_min,
            "linear_address_max": address_max,
            "bbox": bbox,
            "first_write": first_write,
            "last_write": last_write,
        },
        frame_prefix_hash,
    )


def source_offset(registers: tuple[int, ...]) -> tuple[int, int | None]:
    raw = registers[2] | (registers[3] << 16)
    normalized = 0 if (registers[1] & 0x000F) == 0x000C else raw
    if normalized >= 0xF8000000:
        normalized -= 0xF8000000
    if normalized >= 0x10000000:
        return raw, None
    return raw, normalized


def decode_command(registers: tuple[int, ...]) -> dict[str, object]:
    command = registers[1]
    bpp_field = (command >> 12) & 0x7
    mode = command & 0x1F
    mode_entry = dma_model.MODE_TABLE[mode]
    xstep = registers[10] or 0x0100
    ystep = registers[11] or 0x0100
    if command & 0x0040:
        startskip = registers[0] & 0x00FF
        endskip = registers[0] >> 8
    else:
        startskip = 0
        endskip = registers[0]
    raw_offset, normalized_offset = source_offset(registers)

    if mode_entry is None:
        operations: dict[str, str] | None = None
    else:
        _xflip, zero_op, nonzero_op = mode_entry
        operations = {
            "zero_pixel": OP_NAMES[zero_op],
            "nonzero_pixel": OP_NAMES[nonzero_op],
        }

    return {
        "raw_u16": command,
        "trigger": bool(command & 0x8000),
        "bits_per_pixel": 8 if bpp_field == 0 else bpp_field,
        "mode_index": mode,
        "operations": operations,
        "draw_none": mode_entry is None,
        "x_flip": bool(command & 0x0010),
        "y_flip": bool(command & 0x0020),
        "lrskip_split": bool(command & 0x0040),
        "compressed_row_skip": bool(command & 0x0080),
        "preskip_shift": (command >> 8) & 0x3,
        "postskip_shift": (command >> 10) & 0x3,
        "x_step_effective": xstep,
        "y_step_effective": ystep,
        "scaled": xstep != 0x0100 or ystep != 0x0100,
        "lrskip_start": startskip,
        "lrskip_end": endskip,
        "source_bit_offset_raw": raw_offset,
        "source_bit_offset_normalized": normalized_offset,
    }


def _nonnegative_delta(
    larger: int, smaller: int, name: str, warnings: list[str]
) -> int | None:
    result = larger - smaller
    if result < 0:
        warnings.append(
            f"counterfactual {name} was non-monotonic ({larger} - {smaller})"
        )
        return None
    return result


def build_record(
    frame: CapturedFrame,
    blit: CapturedBlit,
    ordinal: int,
    rom_reader: Callable[[int], int],
    rom_size: int,
    frame_prefix_initial: int,
) -> tuple[dict[str, object], int]:
    registers = blit.registers
    warnings: list[str] = []

    actual_writes, source_tracer = execute_model(
        registers, rom_reader, rom_size, trace_source=True
    )
    assert source_tracer is not None

    original_x_full, _ = execute_model(
        variant_registers(registers, full_x_clip=True), rom_reader, rom_size
    )
    original_full_clip, _ = execute_model(
        variant_registers(registers, full_x_clip=True, full_y_clip=True),
        rom_reader,
        rom_size,
    )
    copy_actual, _ = execute_model(
        variant_registers(registers, force_copy_all=True), rom_reader, rom_size
    )
    copy_x_full, _ = execute_model(
        variant_registers(registers, full_x_clip=True, force_copy_all=True),
        rom_reader,
        rom_size,
    )
    copy_full_clip, _ = execute_model(
        variant_registers(
            registers,
            full_x_clip=True,
            full_y_clip=True,
            force_copy_all=True,
        ),
        rom_reader,
        rom_size,
    )
    copy_no_compression, _ = execute_model(
        variant_registers(
            registers,
            full_x_clip=True,
            full_y_clip=True,
            force_copy_all=True,
            disable_compressed_skip=True,
        ),
        rom_reader,
        rom_size,
    )
    copy_no_skips, _ = execute_model(
        variant_registers(
            registers,
            full_x_clip=True,
            full_y_clip=True,
            force_copy_all=True,
            disable_compressed_skip=True,
            disable_lrskip=True,
        ),
        rom_reader,
        rom_size,
    )

    destination, frame_prefix_hash = destination_summary(
        actual_writes, frame_prefix_initial
    )
    total_blits = len(frame.blits)
    order_fraction = 0.0 if total_blits <= 1 else round((ordinal - 1) / (total_blits - 1), 6)

    clipping_and_skips = {
        "scaled_sample_slots_before_skips": len(copy_no_skips),
        "samples_removed_by_lrskip": _nonnegative_delta(
            len(copy_no_skips),
            len(copy_no_compression),
            "lrskip removal",
            warnings,
        ),
        "samples_removed_by_compressed_row_skip": _nonnegative_delta(
            len(copy_no_compression),
            len(copy_full_clip),
            "compressed-row skip removal",
            warnings,
        ),
        "candidate_samples_after_skips_full_clip": len(copy_full_clip),
        "candidate_samples_y_clipped": _nonnegative_delta(
            len(copy_full_clip), len(copy_x_full), "Y clipping", warnings
        ),
        "candidate_samples_x_clipped": _nonnegative_delta(
            len(copy_x_full), len(copy_actual), "X clipping", warnings
        ),
        "candidate_samples_inside_clip": len(copy_actual),
        "visible_samples_skipped_by_pixel_operation": _nonnegative_delta(
            len(copy_actual),
            len(actual_writes),
            "visible pixel operation",
            warnings,
        ),
        "full_clip_samples_skipped_by_pixel_operation": _nonnegative_delta(
            len(copy_full_clip),
            len(original_full_clip),
            "full-clip pixel operation",
            warnings,
        ),
        "writes_suppressed_by_x_clip": _nonnegative_delta(
            len(original_x_full), len(actual_writes), "X-clipped writes", warnings
        ),
        "writes_suppressed_by_y_clip": _nonnegative_delta(
            len(original_full_clip),
            len(original_x_full),
            "Y-clipped writes",
            warnings,
        ),
    }

    record: dict[str, object] = {
        "schema": SCHEMA,
        "frame": {
            "capture_rank": frame.capture_rank,
            "mame_frame": blit.mame_frame,
            "blit_count": total_blits,
        },
        "ordinal": ordinal,
        "capture_index": blit.capture_index,
        "order_fraction": order_fraction,
        "registers_u16": dict(zip(REGISTER_NAMES, registers)),
        "command": decode_command(registers),
        "source_reads": source_tracer.as_dict(),
        "framebuffer": destination,
        "clipping_and_skips": clipping_and_skips,
        "warnings": warnings,
    }
    return record, frame_prefix_hash


def emit_frame(
    frame: CapturedFrame,
    rom_reader: Callable[[int], int],
    rom_size: int,
    output: TextIO,
) -> int:
    frame_prefix_hash = FNV64_OFFSET
    for ordinal, blit in enumerate(frame.blits, 1):
        record, frame_prefix_hash = build_record(
            frame,
            blit,
            ordinal,
            rom_reader,
            rom_size,
            frame_prefix_hash,
        )
        output.write(json.dumps(record, sort_keys=True, separators=(",", ":")))
        output.write("\n")
    return frame_prefix_hash


def _capture_line(rank: int, frame: int, index: int, registers: list[int]) -> str:
    words = " ".join(f"{value:04X}" for value in registers)
    return f"BLIT {rank} {frame} {index} {words}\n"


def run_self_check() -> int:
    """Check parsing, source accounting, ordered hashing, bbox, and clipping."""

    copy_regs = [
        0x0000,
        0x8003,
        0x0100,
        0x0000,
        0x000A,
        0x0007,
        0x0003,
        0x0001,
        0x1200,
        0x0000,
        0x0000,
        0x0000,
        0x0000,
        0x01FF,
        0x0000,
        0x0000,
        0x0000,
        0x03FF,
    ]
    clipped_regs = copy_regs.copy()
    clipped_regs[7] = 0x0002
    clipped_regs[12] = 0x0008
    clipped_regs[16] = 0x000B

    synthetic = io.StringIO(
        "CANDIDATE 7 screen=123 pixels=9 gfxbits=72 charblits=0 maxgfx=6 blits=2\n"
        + _capture_line(7, 123, 1, copy_regs)
        + _capture_line(7, 123, 2, clipped_regs)
        + "DONE\n"
    )
    frames = parse_trace_lines(synthetic)
    frame = frames[7]
    stub_reader = dma_model.gfx_byte
    prefix = FNV64_OFFSET
    first, prefix = build_record(
        frame, frame.blits[0], 1, stub_reader, dma_model.GFX_SIZE, prefix
    )
    second, _prefix = build_record(
        frame, frame.blits[1], 2, stub_reader, dma_model.GFX_SIZE, prefix
    )

    failures: list[str] = []
    first_fb = first["framebuffer"]
    first_src = first["source_reads"]
    first_cs = first["clipping_and_skips"]
    second_fb = second["framebuffer"]
    second_cs = second["clipping_and_skips"]

    checks = [
        (first_fb["ordered_write_count"] == 3, "copy write count"),
        (first_fb["per_blit_fnv64"] == "0x4402AC8838DA7F5B", "copy FNV64"),
        (
            first_fb["bbox"] == {"x_min": 10, "x_max": 12, "y_min": 7, "y_max": 7},
            "copy bbox",
        ),
        (first_src["portable_byte_read_count"] == 6, "copy source reads"),
        (first_src["unique_byte_address_count"] == 4, "copy unique source bytes"),
        (first_src["byte_address_min"] == 0x20, "copy source minimum"),
        (first_src["byte_address_max"] == 0x23, "copy source maximum"),
        (first_cs["candidate_samples_x_clipped"] == 0, "copy X clipping"),
        (first_cs["candidate_samples_y_clipped"] == 0, "copy Y clipping"),
        (second_fb["ordered_write_count"] == 2, "clipped write count"),
        (second_cs["candidate_samples_x_clipped"] == 1, "clipped X samples"),
        (second_cs["candidate_samples_y_clipped"] == 3, "clipped Y samples"),
        (second_cs["writes_suppressed_by_x_clip"] == 1, "clipped X writes"),
        (second_cs["writes_suppressed_by_y_clip"] == 3, "clipped Y writes"),
        (not first["warnings"] and not second["warnings"], "counterfactual monotonicity"),
    ]
    for passed, name in checks:
        if not passed:
            failures.append(name)

    if failures:
        print("SELF-CHECK FAIL: " + ", ".join(failures), file=sys.stderr)
        return 1
    print("SELF-CHECK PASS: parser, source reads, clipping, bbox, and FNV64")
    return 0


def print_candidates(frames: dict[int, CapturedFrame]) -> None:
    print("rank\tscreen\tblits\tpixels\tgfxbits")
    for rank in sorted(frames):
        frame = frames[rank]
        metadata = frame.metadata
        print(
            f"{rank}\t{metadata.get('screen', '-')}\t{len(frame.blits)}\t"
            f"{metadata.get('pixels', '-')}\t{metadata.get('gfxbits', '-')}"
        )


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Normalize one MAME-captured Wolf DMA frame into a JSONL blit ledger."
    )
    parser.add_argument("trace", nargs="?", type=Path, help="captured CANDIDATE/BLIT trace")
    parser.add_argument("--rank", type=int, help="CANDIDATE rank to emit")
    parser.add_argument(
        "--gfx",
        type=Path,
        default=REPO_ROOT / "sim" / "build" / "umk3_gfx.hex",
        help="two-hex-digit-per-line packed GFX ROM image",
    )
    parser.add_argument("--output", "-o", type=Path, help="JSONL output (default: stdout)")
    parser.add_argument("--list", action="store_true", help="list candidate frames and stop")
    parser.add_argument("--self-check", action="store_true", help="run the embedded micro-check")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    if args.self_check:
        return run_self_check()
    if args.trace is None:
        raise LedgerError("a capture trace is required unless --self-check is used")

    frames = parse_trace(args.trace)
    if args.list:
        print_candidates(frames)
        return 0
    if args.rank is None:
        raise LedgerError("--rank is required; use --list to inspect available frames")
    if args.rank not in frames:
        available = ", ".join(str(rank) for rank in sorted(frames))
        raise LedgerError(f"capture rank {args.rank} is absent; available ranks: {available}")

    frame = frames[args.rank]
    with ReadmemhByteRom(args.gfx) as rom:
        if args.output is None:
            final_hash = emit_frame(frame, rom, rom.size, sys.stdout)
        else:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            with args.output.open("w", encoding="ascii", newline="\n") as output:
                final_hash = emit_frame(frame, rom, rom.size, output)

    destination = str(args.output) if args.output is not None else "stdout"
    print(
        f"ledger: rank={args.rank} blits={len(frame.blits)} "
        f"frame_fnv64={fnv_text(final_hash)} output={destination}",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (LedgerError, OSError) as exc:
        print(f"sprite_ledger: {exc}", file=sys.stderr)
        sys.exit(2)
