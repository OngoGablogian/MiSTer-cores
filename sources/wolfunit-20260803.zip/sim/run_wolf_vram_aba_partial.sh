#!/usr/bin/env bash
# Focused framebuffer A/B/A posted-write oracle and mutation proof.
# Only temp copies under sim/build are mutated; repository RTL is never edited.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
IVERILOG=${IVERILOG:-/c/iverilog/bin/iverilog}
VVP=${VVP:-/c/iverilog/bin/vvp}
BUILD="$ROOT/sim/build/wolf_vram_aba_partial"
TB="$ROOT/sim/tb_wolf_vram_aba_partial.sv"
RTL_TOP="$ROOT/rtl/sdram/stv_vram_ddr_top.sv"
mkdir -p "$BUILD"

compile_case() {
  local tag="$1"
  local top="$2"
  local model="${3:-$ROOT/sim/ddr3_avalon_model.sv}"
  "$IVERILOG" -g2012 -s tb_wolf_vram_aba_partial -o "$BUILD/$tag.vvp" \
    "$ROOT/rtl/yunit/vram_sdram.sv" \
    "$ROOT/rtl/yunit/vram_sdram_top.sv" \
    "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
    "$top" \
    "$ROOT/rtl/sdram/wolf_ddr3_arb.sv" \
    "$model" \
    "$TB"
}

run_case() {
  local tag="$1"
  "$VVP" "$BUILD/$tag.vvp" > "$BUILD/$tag.log" 2>&1
  grep -E '^\[case\]|^\[window\]|^\[oracle\]|^\[coverage\]|^\[stats\]|^RESULT:' "$BUILD/$tag.log" || true
}

echo "== RTL snapshot =="
for file in \
  rtl/sdram/stv_vram_ddr_top.sv \
  rtl/sdram/stv_vram_ddr_agent.sv \
  rtl/sdram/wolf_ddr3_arb.sv \
  sim/ddr3_avalon_model.sv; do
  printf '%s  %s\n' "$(git -C "$ROOT" hash-object "$ROOT/$file")" "$file"
done

echo
echo "== Baseline: real RTL, delayed posted writes, scanout + arb contention =="
compile_case baseline "$RTL_TOP"
run_case baseline
grep -q '^RESULT: PASS' "$BUILD/baseline.log" || {
  echo "GATE: FAIL -- baseline did not pass (see $BUILD/baseline.log)"
  exit 1
}
grep -Eq '^\[stats\] tail_forward_hits=[1-9][0-9]* tail_guard_waits=0 tail_stale_reads=0 ' "$BUILD/baseline.log" || {
  echo "GATE: FAIL -- baseline did not traverse the posted-tail forwarding branch"
  exit 1
}

echo
echo "== M1: remove C-lane one-beat forwarding (range guard must cover) =="
MUTANT="$BUILD/stv_vram_ddr_top_no_c_fwd.sv"
cp "$RTL_TOP" "$MUTANT"
sed -i \
  's/wire c_own_fwd_hit = c_fwd_v && (c_fwd_beat == hd_beat);/wire c_own_fwd_hit = 1'"'"'b0;/' \
  "$MUTANT"
sed -i \
  's/wire a_to_c_fwd_hit = fwd_valid && (fwd_addr\[16:0\] == hd_beat);/wire a_to_c_fwd_hit = 1'"'"'b0;/' \
  "$MUTANT"
if [ "$(grep -c "wire c_own_fwd_hit = 1'b0;" "$MUTANT")" != "1" ]; then
  echo "GATE: FAIL -- forwarding mutation did not apply exactly once"
  exit 1
fi
if [ "$(grep -c "wire a_to_c_fwd_hit = 1'b0;" "$MUTANT")" != "1" ]; then
  echo "GATE: FAIL -- shared A/C forwarding mutation did not apply exactly once"
  exit 1
fi
compile_case no_c_fwd "$MUTANT"
run_case no_c_fwd
grep -q '^RESULT: PASS' "$BUILD/no_c_fwd.log" || {
  echo "GATE: FAIL -- no-forward mutant was not preserved by the range guard"
  exit 1
}
grep -Eq '^\[stats\] tail_forward_hits=0 tail_guard_waits=[1-9][0-9]* tail_stale_reads=0 ' "$BUILD/no_c_fwd.log" || {
  echo "GATE: FAIL -- no-forward mutant did not exercise the surviving range guard"
  exit 1
}

echo
echo "== M2: remove C-lane posted-range guard (one-beat forward must cover) =="
NO_GUARD="$BUILD/stv_vram_ddr_top_no_c_guard.sv"
cp "$RTL_TOP" "$NO_GUARD"
sed -i \
  's/else if (c_start && (c_wr || !c_posted_hazard)) begin/else if (c_start) begin/' \
  "$NO_GUARD"
if [ "$(grep -c 'else if (c_start) begin' "$NO_GUARD")" != "1" ]; then
  echo "GATE: FAIL -- C posted-range mutation did not apply exactly once"
  exit 1
fi
compile_case no_c_guard "$NO_GUARD"
run_case no_c_guard
grep -q '^RESULT: PASS' "$BUILD/no_c_guard.log" || {
  echo "GATE: FAIL -- no-guard mutant was not preserved by one-beat forwarding"
  exit 1
}
grep -Eq '^\[stats\] tail_forward_hits=[1-9][0-9]* tail_guard_waits=0 tail_stale_reads=0 ' "$BUILD/no_c_guard.log" || {
  echo "GATE: FAIL -- no-guard mutant did not exercise the surviving forward path"
  exit 1
}

echo
echo "== M3: remove BOTH forwarding and range guard (must expose stale merge) =="
DOUBLE_MUTANT="$BUILD/stv_vram_ddr_top_no_c_fwd_no_guard.sv"
cp "$MUTANT" "$DOUBLE_MUTANT"
sed -i \
  's/else if (c_start && (c_wr || !c_posted_hazard)) begin/else if (c_start) begin/' \
  "$DOUBLE_MUTANT"
sed -i \
  's/wire b_publication_pending = scan_dirty\[b_fill_row\[9:8\]\];/wire b_publication_pending = 1\x27b0;/' \
  "$DOUBLE_MUTANT"
if [ "$(grep -c 'else if (c_start) begin' "$DOUBLE_MUTANT")" != "1" ]; then
  echo "GATE: FAIL -- double mutation did not remove the C posted-range guard"
  exit 1
fi
grep -Fq "wire b_publication_pending = 1'b0;" "$DOUBLE_MUTANT" || {
  echo "GATE: FAIL -- double mutation did not isolate the C paths from the independent scan fence"
  exit 1
}
UNORDERED_RAW_MODEL="$BUILD/ddr3_avalon_model_unordered_raw.sv"
cp "$ROOT/sim/ddr3_avalon_model.sv" "$UNORDERED_RAW_MODEL"
sed -i \
  's/if (cB <= 8\x27d1 && pw_v && (pw_i == (cA - BASE))) begin/if (1\x27b0 \&\& cB <= 8\x27d1 \&\& pw_v \&\& (pw_i == (cA - BASE))) begin/' \
  "$UNORDERED_RAW_MODEL"
grep -Fq "if (1'b0 && cB <= 8'd1 && pw_v && (pw_i == (cA - BASE))) begin" "$UNORDERED_RAW_MODEL" || {
  echo "GATE: FAIL -- unordered-RAW model mutation did not apply"
  exit 1
}
compile_case no_c_fwd_no_guard "$DOUBLE_MUTANT" "$UNORDERED_RAW_MODEL"
run_case no_c_fwd_no_guard
grep -q '^RESULT: FAIL' "$BUILD/no_c_fwd_no_guard.log" || {
  echo "GATE: FAIL -- double mutant survived (see $BUILD/no_c_fwd_no_guard.log)"
  exit 1
}
grep -q '^\[oracle\] STALE-MERGE' "$BUILD/no_c_fwd_no_guard.log" || {
  echo "GATE: FAIL -- double mutant failed without the expected stale-merge signature"
  exit 1
}
grep -Eq '^\[stats\] tail_forward_hits=0 tail_guard_waits=[0-9]+ tail_stale_reads=[1-9][0-9]* ' "$BUILD/no_c_fwd_no_guard.log" || {
  echo "GATE: FAIL -- double mutant did not receive stale DDR data while A was posted"
  exit 1
}

echo
echo "GATE: PASS -- forward and guard each cover the posted tail; removing both is killed by the A/B/A stale merge"
echo "Logs: $BUILD/baseline.log  $BUILD/no_c_fwd.log  $BUILD/no_c_guard.log  $BUILD/no_c_fwd_no_guard.log"
