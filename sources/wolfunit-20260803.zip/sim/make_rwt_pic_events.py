#!/usr/bin/env python3
# Convert the captured Rampage World Tour host<->PIC exchange gospel
# (D:/deck/fpga/rampageworldtour/gospel/rmpgwt_pic_exchange_run1.txt, MAME 0.280
# rmpgwt fresh NVRAM, wunit_picemu serial 465) into a flat event list the
# tb_wolf_pic RWT replay section consumes with $fscanf:
#
#   <op> <val>      op 0 = security_w (host write, val = written byte)
#                   op 1 = security_r (host read,  val = EXPECTED response byte)
#
# Events are emitted in captured file order (the capture logs same-cycle
# read-before-write in the order MAME serviced them). Expected totals for the
# run1 gospel: 37 writes, 17 reads (SEC_R #1 = 00 pre-advance, then the 16-byte
# 465 table 5B 08 03 10 10 41 0D D7 61 7F 19 25 CD 69 09 8C).
#
# Usage: python sim/make_rwt_pic_events.py <exchange_txt> <out_events>
import re
import sys


def main():
    src, out = sys.argv[1], sys.argv[2]
    w_re = re.compile(r"^PIC_W\s+#\d+\s+cyc=\d+\s+off=01600000\s+val=([0-9A-Fa-f]{4})")
    r_re = re.compile(r"^SEC_R\s+#\d+\s+cyc=\d+\s+off=01600000\s+val=([0-9A-Fa-f]{4})")
    events = []
    for line in open(src):
        m = w_re.match(line)
        if m:
            events.append((0, int(m.group(1), 16) & 0xFF))
            continue
        m = r_re.match(line)
        if m:
            events.append((1, int(m.group(1), 16) & 0xFF))
    nw = sum(1 for op, _ in events if op == 0)
    nr = sum(1 for op, _ in events if op == 1)
    with open(out, "w", newline="\n") as f:
        for op, val in events:
            f.write(f"{op} {val:02x}\n")
    print(f"wrote {out}: {len(events)} events ({nw} writes, {nr} reads)")
    assert nw == 37 and nr == 17, f"unexpected exchange shape: {nw}W/{nr}R (gospel is 37W/17R)"


if __name__ == "__main__":
    main()
