#!/usr/bin/env python3
# make_wolf_gfx_hex.py -- assemble UMK3's "video" (gfx) ROM region for sim/HW loading.
#
# Gospel: mame-gospel/midway/midwunit.cpp ROM_START(umk3):848-903 (fetched from MAME 0.280
# mame0280 tag, src/mame/midway/midwunit.cpp). ROM_REGION(0x2000000,"video",0), populated via
# ROM_LOAD32_BYTE in 5 groups of 4 chips (each chip supplies one byte lane of every 32-bit
# word -- NOT a bit-packed/planar format):
#   group0 @0x0000000: u133=byte0 u132=byte1 u131=byte2 u130=byte3
#   group1 @0x0400000: u129=byte0 u128=byte1 u127=byte2 u126=byte3
#   group2 @0x0800000: u125=byte0 u124=byte1 u123=byte2 u122=byte3
#   group3 @0x0C00000: u121=byte0 u120=byte1 u119=byte2 u118=byte3
#   [gap   0x1000000-0x13FFFFF: sockets U114-U117 empty for this revision -> 0x00 fill]
#   group4 @0x1400000: u113=byte0 u112=byte1 u111=byte2 u110=byte3
# Total populated: 5*4MB = 20MB of the 32MB region; the gap + tail (0x1800000-0x1FFFFFF,
# unpopulated on this board) are left 0x00.
#
# Unlike Y-unit (make_gfx_hex.py, which pre-unpacks 6bpp planes into one pixel-value byte
# per output byte), Wolf-unit's blitter (wolf_dma.sv, gospel-cited to midtunit_v.cpp dma_draw)
# does its OWN bit-level pixel unpack from this PACKED byte stream at blit time -- confirmed by
# midwunit_video_device::midwunit_gfxrom_r (midtunit_v.cpp:244-249): a flat byte-linear index
# into m_gfxrom (offset*=2 for the 16-bit CPU read; no bit-unpack at the ROM-read layer). So
# this script does NO pixel transform -- it just assembles the raw interleaved byte stream,
# matching what src_data must return for a given src_addr in wolf_dma's real-source-data mode.
#
# Usage: python3 sim/make_wolf_gfx_hex.py [/path/to/umk3.zip]   (run from repo root)
import sys, zipfile

ZIP = sys.argv[1] if len(sys.argv) > 1 else r"D:/deck/fpga/umk3/roms/umk3.zip"
DST = "sim/build/umk3_gfx.hex"
REGION_SIZE = 0x2000000   # ROM_REGION(0x2000000,"video",0)

# (chip filename, group base offset, byte lane 0..3) -- byte lane = ROM_LOAD32_BYTE's own offset
GROUPS = [
    (0x0000000, ["l1_mortal_kombat_3_u133_game_rom.u133", "l1_mortal_kombat_3_u132_game_rom.u132",
                 "l1_mortal_kombat_3_u131_game_rom.u131", "l1_mortal_kombat_3_u130_game_rom.u130"]),
    (0x0400000, ["l1_mortal_kombat_3_u129_game_rom.u129", "l1_mortal_kombat_3_u128_game_rom.u128",
                 "l1_mortal_kombat_3_u127_game_rom.u127", "l1_mortal_kombat_3_u126_game_rom.u126"]),
    (0x0800000, ["l1_mortal_kombat_3_u125_game_rom.u125", "l1_mortal_kombat_3_u124_game_rom.u124",
                 "l1_mortal_kombat_3_u123_game_rom.u123", "l1_mortal_kombat_3_u122_game_rom.u122"]),
    (0x0C00000, ["umk-u121.bin", "umk-u120.bin", "umk-u119.bin", "umk-u118.bin"]),
    # 0x1000000-0x13FFFFF: U114-U117 empty for this revision -- left 0x00
    (0x1400000, ["umk-u113.bin", "umk-u112.bin", "umk-u111.bin", "umk-u110.bin"]),
]
CHIP_SIZE = 0x100000   # 1MB EPROMs

def main():
    z = zipfile.ZipFile(ZIP)
    region = bytearray(REGION_SIZE)   # 0x00 default fill (unpopulated gap + tail)
    for base, chips in GROUPS:
        for lane, name in enumerate(chips):
            d = z.read(name)
            assert len(d) == CHIP_SIZE, f"{name}: expected {CHIP_SIZE} bytes, got {len(d)}"
            region[base + lane : base + lane + 4 * CHIP_SIZE : 4] = d
    with open(DST, "w", newline="\n") as f:
        f.write("\n".join(f"{b:02x}" for b in region) + "\n")
    print(f"wrote {DST}: {REGION_SIZE} bytes ({REGION_SIZE/(1024*1024):.0f} MB), "
          f"{sum(1 for b in region if b != 0)} non-zero bytes")

if __name__ == "__main__":
    main()
