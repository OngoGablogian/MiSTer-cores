#!/usr/bin/env bash
# SHARED-P0030 gate: C on SUB/SUBB/CMP must be a pure unsigned operand compare.
# Bench transcribed from gospel by Y-unit, ported by T-unit; run here against Wolf.
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TB=tb_tms34010_sub_cflag
TBSRC="${TBSRC:-/d/deck/fpga/tunit/Arcade-TUnit_MiSTer/sim/monitors/tb_tms34010_sub_cflag.sv}"
ALU="${ALU:-$ROOT/rtl/tms34010/rtl/core/tms34010_alu.sv}"
RUN="$ROOT/sim/build/alu_cflag"
. "$(dirname "$0")/questa_lock.sh"
fb(){ local n="$1"; for d in /c/altera_pro/*/questa_fse/win64 /c/altera/*/questa_fse/win64 \
      /c/intelFPGA_pro/*/questa_fse/win64 /c/intelFPGA/*/questa_fse/win64; do
      [ -x "$d/$n.exe" ] && { echo "$d/$n"; return; }; done; command -v "$n" 2>/dev/null||true; }
VLIB=$(fb vlib); VLOG=$(fb vlog); VSIM=$(fb vsim)
unset LM_LICENSE_FILE MGLS_LICENSE_FILE
: "${SALT_LICENSE_SERVER:=C:\altera\LR-175212_License.dat;C:\altera\LR-175213_License.dat}"
export SALT_LICENSE_SERVER
trap questa_release EXIT
questa_acquire || { echo "BLOCKED: no licence"; exit 3; }
rm -rf "$RUN"; mkdir -p "$RUN"; cd "$RUN"; "$VLIB" work >/dev/null
"$VLOG" -sv -quiet -svinputport=var "${PKG:-$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv}" "$ALU" "$TBSRC"
LOG="$ROOT/sim/build/${TB}.vsim.log"
set +e; "$VSIM" -c -quiet -do "run -all; quit" "$TB" 2>&1 | tee "$LOG"; set -e
grep -qE "Exiting VSIM license process|lost connection" "$LOG" && { echo "INCONCLUSIVE: licence death"; exit 2; }
grep -qE "^# ?PASS: tb_tms34010_sub_cflag" "$LOG" && echo "GATE PASSED" || { echo "GATE FAILED"; exit 1; }
