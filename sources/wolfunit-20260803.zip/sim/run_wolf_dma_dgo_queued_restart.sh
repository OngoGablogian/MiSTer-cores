#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP_ROOT="${TMPDIR:-/tmp}"
TMP="$(mktemp -d "$TMP_ROOT/wolf_dma_dgo_queued_restart.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT

IVERILOG="${IVERILOG:-/c/iverilog/bin/iverilog}"
VVP="${VVP:-/c/iverilog/bin/vvp}"

cd "$ROOT"
"$IVERILOG" -g2012 -s tb_wolf_dma_dgo_queued_restart \
  -o "$TMP/tb.vvp" \
  rtl/pkg/wolf_pkg.sv \
  rtl/wolf/wolf_dma.sv \
  sim/tb_wolf_dma_dgo_queued_restart.sv
"$VVP" -n "$TMP/tb.vvp" | tee "$TMP/tb.log"
grep -q '^PASS: tb_wolf_dma_dgo_queued_restart' "$TMP/tb.log"

run_mutant() {
  local name="$1"
  local expression="$2"
  local changed_text="$3"
  local expected_failure="$4"
  local mutant="$TMP/wolf_dma_${name}.sv"
  local mutant_tb="$TMP/tb_${name}.vvp"
  local mutant_log="$TMP/tb_${name}.log"

  cp rtl/wolf/wolf_dma.sv "$mutant"
  sed -i "$expression" "$mutant"
  grep -Fq "$changed_text" "$mutant" || {
    echo "FATAL: $name mutation did not apply"
    exit 1
  }
  "$IVERILOG" -g2012 -s tb_wolf_dma_dgo_queued_restart \
    -o "$mutant_tb" \
    rtl/pkg/wolf_pkg.sv "$mutant" sim/tb_wolf_dma_dgo_queued_restart.sv

  set +e
  "$VVP" -n "$mutant_tb" >"$mutant_log" 2>&1
  local mutant_status=$?
  set -e
  if [ "$mutant_status" -eq 0 ] || ! grep -Fq "$expected_failure" "$mutant_log"; then
    cat "$mutant_log"
    echo "FATAL: $name mutant survived or failed for the wrong reason"
    exit 1
  fi
  echo "PASS: $name mutant killed by $expected_failure"
}

run_mutant busy_readback \
  "/assign reg_rdata = regf/c\\  assign reg_rdata = (eff_raddr == 4'd1) ? {busy_r, cmd_lo15} : regf[{1'b0, eff_raddr}];" \
  "assign reg_rdata = (eff_raddr == 4'd1) ? {busy_r, cmd_lo15}" \
  "COMMAND readback remained busy"

run_mutant no_restart_capture \
  "s/if (trig_w && kill_pending_r && !restart_pending_r) begin/if (1'b0 \&\& trig_w \&\& kill_pending_r \&\& !restart_pending_r) begin/" \
  "if (1'b0 && trig_w && kill_pending_r && !restart_pending_r) begin" \
  "GO written during the pending kill was dropped"

run_mutant latest_go_wins \
  "s/if (trig_w && kill_pending_r && !restart_pending_r) begin/if (trig_w \&\& kill_pending_r) begin/" \
  "if (trig_w && kill_pending_r) begin" \
  "queued transfer wrote 2 pixels, expected 4"

run_mutant stale_command \
  "s/restart_regf\[DMA_COMMAND\] <= reg_wdata;/restart_regf[DMA_COMMAND] <= regf[DMA_COMMAND];/" \
  "restart_regf[DMA_COMMAND] <= regf[DMA_COMMAND];" \
  "queued transfer wrote 3 pixels, expected 4"

run_mutant lost_done_clear \
  "s/if (done_clear_w) regf\[done_idx_w\] <= done_val_w;/if (done_clear_w \&\& !reg_we) regf[done_idx_w] <= done_val_w;/" \
  "if (done_clear_w && !reg_we) regf[done_idx_w] <= done_val_w;" \
  "completion lost the stored DGO clear"
