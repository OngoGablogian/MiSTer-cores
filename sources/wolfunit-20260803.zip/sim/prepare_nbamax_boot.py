#!/usr/bin/env python3
"""Prepare NBA Maximum Hangtime program and PC-reference files for simulation."""

from pathlib import Path
import re
import sys
import zipfile


def main() -> int:
    if len(sys.argv) != 4:
        print(
            "usage: prepare_nbamax_boot.py NBAMHT.ZIP MAME.TR OUTPUT_DIR",
            file=sys.stderr,
        )
        return 2

    zip_path = Path(sys.argv[1])
    trace_path = Path(sys.argv[2])
    output_dir = Path(sys.argv[3])
    output_dir.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(zip_path) as archive:
        even = archive.read("mhtu54_v103.bin")
        odd = archive.read("mhtu63_v103.bin")

    if len(even) != 0x80000 or len(odd) != 0x80000:
        raise ValueError("NBA Maximum Hangtime program ROM lane size is not 0x80000")

    with (output_dir / "nbamax_maindata.hex").open("w", newline="\n") as out:
        for lo, hi in zip(even, odd):
            out.write(f"{hi:02x}{lo:02x}\n")

    pc_pattern = re.compile(r"^([0-9A-Fa-f]{8}):")
    pcs: list[str] = []
    with trace_path.open(errors="replace") as trace:
        for line in trace:
            match = pc_pattern.match(line)
            if match:
                pcs.append(match.group(1))
                if len(pcs) == 8000:
                    break

    if len(pcs) != 8000:
        raise ValueError(f"expected 8000 trace PCs, found {len(pcs)}")

    (output_dir / "nbamax_l103_main_pc.ref").write_text(
        "\n".join(pcs) + "\n", newline="\n"
    )
    print(
        "prepared NBA Maximum Hangtime: "
        f"{len(even) + len(odd)} program bytes, {len(pcs)} trace PCs"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
