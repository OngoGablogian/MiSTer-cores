#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
split_and_diff.py -- split the TB's single OUT stream (one line per emitted pixel,
all cases concatenated in JSON order) into per-case slices by npix, and ORDER-
SENSITIVE diff each slice against the model's per-case golden (<goldendir>/<name>
.golden.txt). Per-case PASS/FAIL + totals; exit!=0 on any fail or short capture.

Usage: python split_and_diff.py <manifest.txt> <out.txt> <goldendir>
"""
import sys, os

def main(argv):
    manifest, outp, goldendir = argv[1], argv[2], argv[3]
    man = []
    for line in open(manifest):
        line = line.rstrip("\n")
        if not line: continue
        name, npix = line.rsplit(" ", 1)
        man.append((name, int(npix)))

    out_lines = open(outp, "r", newline="").read().split("\n")
    # trailing empty from final LF
    if out_lines and out_lines[-1] == "": out_lines.pop()

    total_expected = sum(n for _, n in man)
    if len(out_lines) != total_expected:
        sys.stderr.write("NOTE: OUT has %d lines, manifest expects %d total pixels\n"
                         % (len(out_lines), total_expected))

    idx = 0
    npass = 0; nfail = 0
    fails = []
    for name, npix in man:
        got = out_lines[idx:idx+npix]
        idx += npix
        gp = os.path.join(goldendir, name + ".golden.txt")
        gold = open(gp, "r", newline="").read().split("\n")
        if gold and gold[-1] == "": gold.pop()

        ok = (len(got) == npix) and (len(gold) == npix) and (got == gold)
        if ok:
            npass += 1
            print("PASS %-34s (%d px)" % (name, npix))
        else:
            nfail += 1
            print("FAIL %-34s got %d / gold %d / npix %d"
                  % (name, len(got), len(gold), npix))
            # first divergent line
            for k in range(min(len(got), len(gold))):
                if got[k] != gold[k]:
                    print("     px %d: got '%s'  gold '%s'" % (k, got[k], gold[k]))
                    break
            else:
                if len(got) != len(gold):
                    print("     length mismatch: got %d gold %d" % (len(got), len(gold)))
            fails.append(name)

    print("-" * 50)
    print("TOTAL %d cases: %d PASS, %d FAIL" % (len(man), npass, nfail))
    if idx != len(out_lines):
        print("WARN: %d trailing OUT lines unconsumed" % (len(out_lines) - idx))
    return 1 if nfail else 0

if __name__ == "__main__":
    sys.exit(main(sys.argv))
