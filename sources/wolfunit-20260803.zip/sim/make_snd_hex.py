#!/usr/bin/env python3
# Extract the Smash T.V. CVSD sound ROMs (sl2 u4/u19/u20, 64KB each) from the
# user's smashtv.zip into $readmemh hex files for the sound-board sim.
# Chip map (MAME williamssound.cpp device_start): bank D0/D1 -> 0=U4 1=U19 2=U20,
# D2 -> A15, D3 -> A16 (64KB chips -> A16 mirrors, matching the ROM_RELOADs).
import zipfile, os
Z = "D:/deck/fpga/smash tv/roms/smashtv.zip"
OUT = "sim/build"
ROMS = {
    "sl2_smash_tv_sound_rom_u4.u4":  "snd_u4.hex",
    "sl2_smash_tv_sound_rom_u19.u19": "snd_u19.hex",
    "sl2_smash_tv_sound_rom_u20.u20": "snd_u20.hex",
}
os.makedirs(OUT, exist_ok=True)
z = zipfile.ZipFile(Z)
for src, dst in ROMS.items():
    data = z.read(src)
    assert len(data) == 0x10000, f"{src}: expected 64KB, got {len(data)}"
    with open(f"{OUT}/{dst}", "w") as f:
        f.write("\n".join(f"{b:02x}" for b in data))
    print(f"{src} ({len(data)} bytes) -> {OUT}/{dst}")
print("done")
