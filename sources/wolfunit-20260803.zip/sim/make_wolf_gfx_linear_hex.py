#!/usr/bin/env python3
# make_wolf_gfx_linear_hex.py -- the RAW linear concatenation of the 20 gfx chips in MRA
# <rom index="1"> part order (u133,u132,u131,u130, u129,...,u110) -- i.e. exactly the byte
# stream that arrives via ioctl_download BEFORE wolf_gfx_interleave transforms it. Used only
# to verify the RTL transform against the already-verified interleaved sim/build/umk3_gfx.hex
# (make_wolf_gfx_hex.py); NOT used at runtime (the real ioctl_download stream comes from the
# MRA directly).
import sys, zipfile, zlib

ZIP = sys.argv[1] if len(sys.argv) > 1 else r"D:/deck/fpga/umk3/roms/umk3.zip"
DST_HEX = "sim/build/umk3_gfx_linear.hex"
DST_BIN = "sim/build/umk3_gfx_linear.bin"
CHIP_SIZE = 0x100000

CHIPS = [
    "l1_mortal_kombat_3_u133_game_rom.u133", "l1_mortal_kombat_3_u132_game_rom.u132",
    "l1_mortal_kombat_3_u131_game_rom.u131", "l1_mortal_kombat_3_u130_game_rom.u130",
    "l1_mortal_kombat_3_u129_game_rom.u129", "l1_mortal_kombat_3_u128_game_rom.u128",
    "l1_mortal_kombat_3_u127_game_rom.u127", "l1_mortal_kombat_3_u126_game_rom.u126",
    "l1_mortal_kombat_3_u125_game_rom.u125", "l1_mortal_kombat_3_u124_game_rom.u124",
    "l1_mortal_kombat_3_u123_game_rom.u123", "l1_mortal_kombat_3_u122_game_rom.u122",
    "umk-u121.bin", "umk-u120.bin", "umk-u119.bin", "umk-u118.bin",
    "umk-u113.bin", "umk-u112.bin", "umk-u111.bin", "umk-u110.bin",
]
CRCS = [
    0x79B94667, 0x13E95228, 0x41001E30, 0x49379DD7,
    0xA8B41803, 0xB410D72F, 0xBD985BE7, 0xE7C32CF4,
    0x9A52227E, 0x5C750EBC, 0xF0AB88A8, 0x9B87CDAC,
    0xCC4B95DB, 0x1C8144CD, 0x5F10C543, 0xDE0C4488,
    0x99D74A1E, 0xB5A46488, 0xA87523C8, 0x0038F205,
]

def main():
    z = zipfile.ZipFile(ZIP)
    out = bytearray(len(CHIPS) * CHIP_SIZE)
    for i, name in enumerate(CHIPS):
        d = z.read(name)
        assert len(d) == CHIP_SIZE, f"{name}: expected {CHIP_SIZE}, got {len(d)}"
        assert zlib.crc32(d) & 0xFFFFFFFF == CRCS[i], f"{name}: CRC mismatch"
        out[i*CHIP_SIZE:(i+1)*CHIP_SIZE] = d
    with open(DST_BIN, "wb") as f:
        f.write(out)
    with open(DST_HEX, "w", newline="\n") as f:
        f.write("\n".join(f"{b:02x}" for b in out) + "\n")
    print(f"wrote {DST_BIN} and {DST_HEX}: "
          f"{len(out)} bytes ({len(CHIPS)} chips x {CHIP_SIZE})")

if __name__ == "__main__":
    main()
