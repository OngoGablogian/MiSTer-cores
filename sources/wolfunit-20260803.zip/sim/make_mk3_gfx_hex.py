#!/usr/bin/env python3
"""Assemble MK3's MAME `video` region for the real-data RTL replays.

The first four 4 MiB groups are shared with UMK3.  MK3's final group is the
four 512 KiB U117..U114 devices interleaved at 0x1000000 (2 MiB populated).
Unpopulated bytes in the 32 MiB region remain zero, matching ROMREGION_ERASE00.
"""
from pathlib import Path
import sys
import zipfile

ZIP = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("D:/deck/fpga/mk3/mk3.zip")
DST = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("sim/build/mk3_gfx.hex")
REGION_SIZE = 0x2000000

GROUPS = [
    (0x0000000, 0x100000, [133, 132, 131, 130]),
    (0x0400000, 0x100000, [129, 128, 127, 126]),
    (0x0800000, 0x100000, [125, 124, 123, 122]),
    (0x0C00000, 0x100000, [121, 120, 119, 118]),
    (0x1000000, 0x080000, [117, 116, 115, 114]),
]


def name(socket: int) -> str:
    return f"l1_mortal_kombat_3_u{socket}_game_rom.u{socket}"


def main() -> int:
    region = bytearray(REGION_SIZE)
    with zipfile.ZipFile(ZIP) as zf:
        for base, size, sockets in GROUPS:
            for lane, socket in enumerate(sockets):
                data = zf.read(name(socket))
                if len(data) != size:
                    raise ValueError(f"U{socket}: expected {size} bytes, got {len(data)}")
                region[base + lane:base + lane + 4 * size:4] = data
    DST.parent.mkdir(parents=True, exist_ok=True)
    with DST.open("w", newline="\n") as out:
        out.write("\n".join(f"{byte:02x}" for byte in region))
        out.write("\n")
    print(f"wrote {DST}: {REGION_SIZE} bytes, {sum(b != 0 for b in region)} nonzero")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
