#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/sim/build"
MAME="${MAME:-D:/deck/fpga/starwars/sw/starwars-mister/.tools/mame0287/mame.exe}"
ROMS="${OPENICE_ROMS:-D:/deck/fpga/openice}"
SCRIPT="$ROOT/sim/probe_openice_dpy.lua"
OUT="$BUILD/openice_dpy_probe.txt"
SEED="${OPENICE_NVRAM_SEED:-D:/deck/fpga/wolf-nvram-80/by-setname/openice.nvm}"

mkdir -p "$BUILD"
NVDIR="$(mktemp -d "$BUILD/openice_dpy_nv.XXXXXX")"
trap 'rm -rf "$NVDIR"' EXIT
mkdir -p "$NVDIR/openice"
cp "$SEED" "$NVDIR/openice/nvram"
rm -f "$OUT"

export OPENICE_DPY_OUT="$OUT"
"$MAME" openice -rompath "$ROMS" -nvram_directory "$NVDIR" \
  -nowindow -video none -sound none -seconds_to_run 45 -autoboot_delay 0 \
  -nothrottle -autoboot_script "$SCRIPT"
echo "wrote $OUT"
