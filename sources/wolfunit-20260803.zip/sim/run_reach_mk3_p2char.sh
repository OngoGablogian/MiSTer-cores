#!/usr/bin/env bash
# Reach a live MK3 1P fight against a chosen opponent and save a MAME state.
#   MK3_P2CHAR=0x0F ./run_reach_mk3_p2char.sh      # Motaro
# See sim/reach_mk3_p2char.lua for the roster indices.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/sim/build"
MAME="${MAME:-D:/deck/fpga/starwars/sw/starwars-mister/.tools/mame0287/mame.exe}"
ROMS="${MK3_ROMS:-D:/deck/fpga/mk3}"
SCRIPT="$ROOT/sim/reach_mk3_p2char.lua"

CHAR="${MK3_P2CHAR:-0x0F}"
NAME="${MK3_STATE:-mk3_$(printf '%02X' $((CHAR)))}"
STATEDIR="$BUILD/mk3_p2char_states"
OUT="${MK3_REACH_OUT:-$BUILD/mk3_reach_$(printf '%02X' $((CHAR))).txt}"
SECS="${MK3_REACH_SECONDS:-90}"

mkdir -p "$BUILD" "$STATEDIR"
rm -f "$OUT"

export MK3_P2CHAR="$CHAR"
export MK3_STATE="$NAME"
export MK3_REACH_OUT="$OUT"

"$MAME" mk3 -rompath "$ROMS" \
  -statename "mk3_p2char_states" \
  -nowindow -video none -sound none -nothrottle \
  -seconds_to_run "$SECS" -autoboot_delay 0 -autoboot_script "$SCRIPT"

grep -q '^DONE ' "$OUT" || { echo "FAIL: harness did not complete"; exit 1; }
# A saved state alone is NOT success -- it must be a LIVE fight, or the capture
# downstream is HUD-free and silently useless.
if ! grep -q '^RESULT .* live=true' "$OUT"; then
  echo "FAIL: never reached a live fight for char $CHAR"; sed -n '1,40p' "$OUT"; exit 1
fi
grep -q '^SAVESTATE ' "$OUT" || { echo "FAIL: no state saved"; exit 1; }
grep -E '^(PHASE fight_live|SAVESTATE|RESULT|DONE)' "$OUT"
