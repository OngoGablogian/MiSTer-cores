#!/usr/bin/env bash
# Production-default 1024-sample DCS startup envelope regression. No Quartus.
set -euo pipefail

export PATH="/c/iverilog/bin:/usr/local/bin:/usr/bin:/bin"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TB=tb_wolf_dcs_online_pop
OUT="$ROOT/sim/build/$TB.vvp"
LOG="$ROOT/sim/build/$TB.log"

mkdir -p "$ROOT/sim/build"
iverilog -g2012 -I "$ROOT/rtl/dcs" -s "$TB" -o "$OUT" \
  "$ROOT/rtl/dcs/adsp2105.sv" \
  "$ROOT/rtl/wolf/wolf_dcs_board.sv" \
  "$ROOT/sim/$TB.sv"

cd "$ROOT"
vvp -n "$OUT" | tee "$LOG"
grep -q '^PASS: onset de-clicked' "$LOG"

GUARD_TB=tb_wolf_audio_guard
GUARD_OUT="$ROOT/sim/build/$GUARD_TB.vvp"
GUARD_LOG="$ROOT/sim/build/$GUARD_TB.log"
iverilog -g2012 -s "$GUARD_TB" -o "$GUARD_OUT" \
  "$ROOT/rtl/wolf/wolf_audio_guard.sv" \
  "$ROOT/sim/$GUARD_TB.sv"
vvp -n "$GUARD_OUT" | tee "$GUARD_LOG"
grep -q '^PASS tb_wolf_audio_guard$' "$GUARD_LOG"
