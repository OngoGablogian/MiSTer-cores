#!/bin/bash
# run_wolf_dma_matrix.sh -- one-command cross-validation of the Wolf-unit DMA
# blitter: Python golden model (sim/wolf_dma_model.py) vs RTL
# (rtl/wolf/wolf_dma.sv via sim/tb_wolf_dma.sv), over the vector matrix
# sim/wolf_dma_vectors.json (authored by sim/gen_wolf_dma_vectors.py).
#
# Usage:  bash sim/run_wolf_dma_matrix.sh            # full matrix
#         bash sim/run_wolf_dma_matrix.sh <case...>  # only named cases
#
# Per case: model -> golden/<name>.golden.txt, vvp -> rtl/<name>.out.txt,
# order-sensitive diff (plain byte diff; contract format '%05X %04X' + LF).
# Exit 0 iff every case matches.

set -u
cd "$(dirname "$0")/.." || exit 1     # repo root (Arcade-UMK3_MiSTer)

IVERILOG=/c/iverilog/bin/iverilog
VVP=/c/iverilog/bin/vvp
PY=python

VEC=sim/wolf_dma_vectors.json
OUTDIR=sim/wolf_dma_matrix
GOLD=$OUTDIR/golden
RTLO=$OUTDIR/rtl
STIM=$OUTDIR/stim

mkdir -p "$GOLD" "$RTLO" "$STIM"

# --- 0. (re)generate the vector matrix ------------------------------------
$PY sim/gen_wolf_dma_vectors.py || { echo "FATAL: vector generation failed"; exit 1; }

# optional second matrix: replayed REAL captured umk3 blits (present only if
# sim/gen_wolf_dma_realblits.py has been run on a wolfblits.txt capture)
REALVEC=sim/wolf_dma_realblits.json
VECS="$VEC"
[ -f "$REALVEC" ] && VECS="$VEC $REALVEC"

# --- 1. golden model over the whole matrix ---------------------------------
: > "$OUTDIR/model.log"
for v in $VECS; do
  $PY sim/wolf_dma_model.py "$v" "$GOLD" >> "$OUTDIR/model.log" 2>&1 \
    || { echo "FATAL: golden model failed on $v"; tail -5 "$OUTDIR/model.log"; exit 1; }
done

# --- 2. vectors.json -> per-case .stim ('W <off_hex> <data_hex>') -----------
$PY - $VECS "$STIM" <<'PYEOF' || { echo "FATAL: stim conversion failed"; exit 1; }
import json, os, sys
stim_dir = sys.argv[-1]
os.makedirs(stim_dir, exist_ok=True)
names = []
for vec in sys.argv[1:-1]:
    for c in json.load(open(vec)):
        with open(os.path.join(stim_dir, c["name"] + ".stim"), "w",
                  newline="\n") as f:
            for off, val in c["writes"]:
                f.write("W %x %04x\n" % (off & 0xf, val & 0xffff))
        names.append(c["name"])
assert len(names) == len(set(names)), "duplicate case names across matrices"
with open(os.path.join(stim_dir, "_cases.txt"), "w", newline="\n") as f:
    f.write("\n".join(names) + "\n")
PYEOF

# --- 3. compile the TB once -------------------------------------------------
$IVERILOG -g2012 -o "$OUTDIR/tb_wolf_dma.vvp" \
    rtl/pkg/wolf_pkg.sv rtl/wolf/wolf_dma.sv sim/tb_wolf_dma.sv \
  || { echo "FATAL: iverilog compile failed"; exit 1; }

# --- 4. run + diff each case -------------------------------------------------
if [ $# -gt 0 ]; then
    CASES="$*"
else
    CASES=$(cat "$STIM/_cases.txt")
fi

pass=0; fail=0; failed=""
for name in $CASES; do
    "$VVP" -n "$OUTDIR/tb_wolf_dma.vvp" \
        "+STIM=$STIM/$name.stim" "+OUT=$RTLO/$name.out.txt" \
        > "$RTLO/$name.sim.log" 2>&1
    if grep -q "TB TIMEOUT" "$RTLO/$name.sim.log"; then
        fail=$((fail+1)); failed="$failed $name"
        printf 'FAIL %-28s (TB TIMEOUT)\n' "$name"
        continue
    fi
    if diff -q "$GOLD/$name.golden.txt" "$RTLO/$name.out.txt" >/dev/null 2>&1; then
        pass=$((pass+1))
        printf 'PASS %-28s (%d writes)\n' "$name" \
               "$(wc -l < "$GOLD/$name.golden.txt")"
    else
        fail=$((fail+1)); failed="$failed $name"
        printf 'FAIL %-28s (golden %s lines / rtl %s lines; first diff:)\n' \
               "$name" \
               "$(wc -l < "$GOLD/$name.golden.txt" 2>/dev/null || echo '?')" \
               "$(wc -l < "$RTLO/$name.out.txt"    2>/dev/null || echo '?')"
        diff "$GOLD/$name.golden.txt" "$RTLO/$name.out.txt" 2>&1 | head -6 | sed 's/^/       /'
    fi
done

echo "----------------------------------------------------------------------"
echo "TOTAL: $((pass+fail))  PASS: $pass  FAIL: $fail"
[ -n "$failed" ] && echo "FAILED:$failed"
[ "$fail" -eq 0 ]
