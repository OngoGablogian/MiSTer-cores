#!/usr/bin/env bash
# run_wolf_dma_realpixels.sh -- the strongest available GFX oracle: replay UMK3's real,
# MAME-captured first content blit (mame-gospel/trace/wolfblits.txt line 1) through the
# proven wolf_dma_model.py using the REAL, CRC-verified umk3 gfx ROM (sim/build/umk3_gfx.hex),
# and diff pixel-for-pixel against MAME's own captured post-blit VRAM
# (mame-gospel/trace/nearblit/vram_postblit.hex). Regenerate either input via:
#   python sim/make_wolf_gfx_hex.py
#   bash-run mame-gospel/trace/postblit_dump.lua against the nearblit/ nvram (see its header)
set -e
cd "$(dirname "$0")/.."
if [ ! -f sim/build/umk3_gfx.hex ]; then
  echo "sim/build/umk3_gfx.hex missing -- run: python sim/make_wolf_gfx_hex.py"
  exit 1
fi
python sim/run_wolf_dma_realblit.py
