#!/usr/bin/env bash
# Run the CPU-vs-MAME replay debugger under Questa FSE (real tms34010_core + lean mem model).
set -e
TB="tb_wolf_cpu_build"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"
. "$(dirname "$0")/questa_lock.sh"
find_bin() { local name="$1" env="$2"; if [ -n "$env" ] && [ -x "$env" ]; then echo "$env"; return; fi
  for d in /c/altera_pro/*/questa_fse/win64 /c/intelFPGA_pro/*/questa_fse/win64 /c/altera/*/questa_fse/win64 /c/intelFPGA/*/questa_fse/win64; do
    [ -x "$d/$name.exe" ] && { echo "$d/$name"; return; }; [ -x "$d/$name" ] && { echo "$d/$name"; return; }; done
  local p; p="$(command -v "$name" 2>/dev/null||true)"; case "$p" in *modelsim_ase*) p="";; esac; [ -n "$p" ] && echo "$p"; }
VLIB="$(find_bin vlib "$VLIB")"; VLOG="$(find_bin vlog "$VLOG")"; VSIM="$(find_bin vsim "$VSIM")"
[ -z "$VLOG" ] && { echo "ERROR: Questa not found"; exit 1; }
unset LM_LICENSE_FILE MGLS_LICENSE_FILE
: "${SALT_LICENSE_SERVER:=C:\altera\LR-175212_License.dat;C:\altera\LR-175213_License.dat}"; export SALT_LICENSE_SERVER
trap questa_release EXIT
questa_acquire || { echo "BLOCKED: no Questa license"; exit 75; }
cd "$ROOT/sim"; rm -rf work; "$VLIB" work >/dev/null
SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SRC+=( "$ROOT/sim/$TB.sv" )
echo "compiling ${#SRC[@]} sources ..."
"$VLOG" -sv -quiet -svinputport=var "${SRC[@]}" 2>&1 | grep -iE "error|\*\*" | head -20 || true
LOG="$ROOT/sim/build/${TB}.vsim.log"; mkdir -p "$ROOT/sim/build"
echo "simulating $TB ..."
set +e
"$VSIM" -c -quiet -do "run -all; quit" "$TB" 2>&1 | tee "$LOG" | grep -iE "loaded|DIVERGENCE|RESULT|matched|FAITHFUL|read #|Error|Fatal|license" | head -40
set -e
