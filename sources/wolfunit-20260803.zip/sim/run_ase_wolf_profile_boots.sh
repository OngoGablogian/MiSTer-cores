#!/usr/bin/env bash
# License-free exact-ROM boot gates for the Wolf master profiles with captured
# 8,000-PC MAME references.
set -euo pipefail

MS="${MS:-/c/intelFPGA_lite/17.0/modelsim_ase/win32aloem}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"
RUN_DIR="$ROOT/sim/build/game_profiles/ase"
NBAMAX_ZIP="${NBAMAX_ZIP:-D:/deck/fpga/nba maximum hangtime/nbamht.zip}"
NBAMAX_TRACE="${NBAMAX_TRACE:-$ROOT/sim/build/wolf_profile_mame_boot.tr}"
PROFILE_ROM_DIR="${WOLF_PROFILE_ROM_DIR:-$ROOT/sim/build/game_profiles/roms}"

mkdir -p "$RUN_DIR"
cd "$ROOT/sim"

for profile in openice wwfmania mk3; do
  u54="$PROFILE_ROM_DIR/$profile/u54.bin"
  u63="$PROFILE_ROM_DIR/$profile/u63.bin"
  [ -f "$u54" ] && [ -f "$u63" ] || {
    echo "missing exact-ROM boot lanes: $u54 / $u63" >&2
    exit 2
  }
  python make_maindata_hex.py \
    "$u54" "$u63" "$ROOT/sim/build/game_profiles/${profile}_maindata.hex"
done

python prepare_nbamax_boot.py \
  "$NBAMAX_ZIP" "$NBAMAX_TRACE" "$ROOT/sim/build/game_profiles"

SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done \
  < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SRC+=( "$ROOT/rtl/pkg/wolf_pkg.sv"
       "$ROOT/rtl/wolf/ram_sdram.sv" "$ROOT/sim/sdram_model.sv"
       "$ROOT/rtl/wolf/wolf_mem.sv" "$ROOT/rtl/wolf/wolf_dma.sv"
       "$ROOT/rtl/wolf/wolf_pic.sv" "$ROOT/rtl/wolf/wolf_dcs_stub.sv"
       "$ROOT/rtl/wolf/wolf_memsys.sv"
       "$ROOT/sim/tb_wolf_profile_boot.sv" )

for profile in OPEN_ICE WWF_MANIA MK3 NBAMAX; do
  rm -rf work
  "$MS/vlib.exe" work >/dev/null
  "$MS/vlog.exe" -sv -quiet -svinputport=var \
    "+define+${profile}_BOOT" "${SRC[@]}"
  log="$RUN_DIR/${profile,,}.log"
  "$MS/vsim.exe" -c -quiet -do "run -all; quit -f" \
    work.tb_wolf_profile_boot >"$log" 2>&1
  grep -E "^# (PASS|FAIL)" "$log"
  grep -q "^# PASS" "$log"
  ! grep -q "^# FAIL" "$log"
done

echo "PASS: all exact-ROM Wolf profile boot gates"
