#!/usr/bin/env bash
# TIER-2 SRT integration gate (RTL side): real tms34010_core + wolf_memsys (wolf_mem +
# real wolf_dma) + stv_vram_ddr_top (D-lane) + ddr3_avalon_model, compiled with the
# shipping VRAM macros (+define+USE_SDRAM_VRAM+USE_DDR3_VRAM) under ModelSim ASE 17.0
# (license-free — NEVER Questa FSE; a foreign NARC vsim may hold that license).
# Dumps the T2CONTRACT outputs to sim/build/srt2_tb/ for the external cross-diff.
set -euo pipefail

MS=${MS:-/c/intelFPGA_lite/17.0/modelsim_ase/win32aloem}
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"
OUT="$ROOT/sim/build/srt2_tb"
WORK="$ROOT/sim/build/srt2_work"
mkdir -p "$OUT" "$WORK"

# empty ROM hex so wolf_mem's $readmemh preload has a real file (program is poked
# hierarchically by the TB)
printf '0000\n' > "$ROOT/sim/build/srt2_empty_rom.hex"

cd "$WORK"
rm -rf work
"$MS/vlib.exe" work >/dev/null

SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SRC+=( "$ROOT/rtl/pkg/wolf_pkg.sv"
       "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv"
       "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv"
       "$ROOT/rtl/wolf/ram_sdram.sv"
       "$ROOT/rtl/wolf/wolf_mem.sv" "$ROOT/rtl/wolf/wolf_dma.sv"
       "$ROOT/rtl/wolf/wolf_pic.sv" "$ROOT/rtl/wolf/wolf_memsys.sv"
       "$ROOT/sim/ddr3_avalon_model.sv"
       "$ROOT/sim/tb_wolf_srt2_contract.sv" )

echo "compiling ${#SRC[@]} sources (USE_SDRAM_VRAM + USE_DDR3_VRAM) ..."
"$MS/vlog.exe" -sv -quiet -svinputport=var +define+USE_SDRAM_VRAM +define+USE_DDR3_VRAM "${SRC[@]}" \
  > "$WORK/compile.log" 2>&1 || { echo "COMPILE FAIL"; tail -40 "$WORK/compile.log"; exit 1; }
echo "COMPILE OK"

# vsim runs with CWD=$WORK; the TB's default out dir is sim/build/srt2_tb relative
# to the repo — pass the absolute path via plusarg instead.
LOG="$WORK/sim.log"
"$MS/vsim.exe" -c -do "run -all; quit -f" work.tb_wolf_srt2_contract \
  "+SRT2_OUT_DIR=$OUT" > "$LOG" 2>&1 || true

grep -E "LIVENESS|WARNING|TEST_RESULT" "$LOG" || true
if grep -q "TEST_RESULT: PASS" "$LOG"; then
  echo "SRT2 TB: PASS (liveness) — outputs in $OUT ; verdict = external cross-diff"
  exit 0
else
  echo "SRT2 TB: FAIL (see $LOG)"
  exit 1
fi
