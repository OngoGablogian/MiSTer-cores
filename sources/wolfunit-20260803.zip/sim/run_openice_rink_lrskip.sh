#!/usr/bin/env bash
# Gospel value of DMA_LRSKIP for the Open Ice rink blits (cmd 0x8023).
# See sim/probe_openice_rink_lrskip.lua for why this is the deciding measurement.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/sim/build"
MAME="${MAME:-D:/deck/fpga/starwars/sw/starwars-mister/.tools/mame0287/mame.exe}"
ROMS="${OPENICE_ROMS:-D:/deck/fpga/openice}"
SCRIPT="$ROOT/sim/probe_openice_rink_lrskip.lua"
OUT="$BUILD/openice_rink_lrskip.txt"
SEED="${OPENICE_NVRAM_SEED:-D:/deck/fpga/wolf-nvram-80/by-setname/openice.nvm}"
SECS="${OPENICE_SECONDS:-90}"

mkdir -p "$BUILD"
NVDIR="$(mktemp -d "$BUILD/openice_rink_nv.XXXXXX")"
trap 'rm -rf "$NVDIR"' EXIT INT TERM
mkdir -p "$NVDIR/openice"
cp "$SEED" "$NVDIR/openice/nvram"
rm -f "$OUT"

export OPENICE_RINK_OUT="$OUT"
"$MAME" openice -rompath "$ROMS" -nvram_directory "$NVDIR" \
  -nowindow -video none -sound none -seconds_to_run "$SECS" -autoboot_delay 0 \
  -nothrottle -autoboot_script "$SCRIPT"

# LIVENESS, not existence: an empty or missing file is INCONCLUSIVE, never a
# clean result. This is the zero-byte-log trap the group hit five times today.
if [ ! -s "$OUT" ]; then
  echo "INCONCLUSIVE: $OUT is missing or empty -- MAME produced no probe output." >&2
  exit 3
fi
if grep -q "TEST-INVALID-DISABLED" "$OUT"; then
  echo "TEST-INVALID -- see $OUT:" >&2
  grep "TEST-INVALID" "$OUT" >&2
  exit 4
fi

echo "=== $OUT ==="
head -12 "$OUT"
echo "..."
grep -E "^DONE|^LRSKIP_HISTOGRAM" "$OUT"
