#!/usr/bin/env python3
"""Stitch one complete Open Ice DISPLAY DMA transaction from a MAME capture.

capture_openice_peak_regs.lua groups commands by MAME screen frame.  Open
Ice's HHD.ASM:DISPLAY transaction is not aligned to that boundary: do_rink
starts with a 400x2 draw-none dummy and the interrupt-driven rink/foreground
queue can continue into the next screen frame.  This utility sorts the
captured commands by absolute MAME time and emits one normalized trace from a
selected dummy through (but excluding) the following dummy.
"""

from __future__ import annotations

import argparse
import re
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path


CAPTURE_HZ = 80_000_000
HEADER_RE = re.compile(
    r"^(?:RINK_)?CANDIDATE\s+(\d+)\s+screen=(\d+).*?"
    r"time=([0-9.]+)\.\."
)


@dataclass(frozen=True)
class CapturedBlit:
    rank: int
    screen: int
    index: int
    registers: tuple[int, ...]
    absolute_cycle: int


def parse_capture(path: Path) -> list[CapturedBlit]:
    headers: dict[int, tuple[int, int]] = {}
    blits: list[CapturedBlit] = []

    for line_number, raw_line in enumerate(
        path.read_text(encoding="ascii").splitlines(), 1
    ):
        header = HEADER_RE.match(raw_line)
        if header:
            rank = int(header.group(1))
            screen = int(header.group(2))
            first_cycle = int(
                (Decimal(header.group(3)) * CAPTURE_HZ).to_integral_value(
                    rounding=ROUND_HALF_UP
                )
            )
            headers[rank] = (screen, first_cycle)
            continue

        fields = raw_line.split()
        if not fields or fields[0] != "BLIT":
            continue
        if len(fields) != 23:
            raise ValueError(
                f"{path}:{line_number}: expected 23 BLIT fields, got {len(fields)}"
            )

        rank = int(fields[1])
        if rank not in headers:
            raise ValueError(
                f"{path}:{line_number}: BLIT rank {rank} has no preceding header"
            )
        screen, first_cycle = headers[rank]
        registers = tuple(int(word, 16) & 0xFFFF for word in fields[4:22])
        blits.append(
            CapturedBlit(
                rank=rank,
                screen=screen,
                index=int(fields[3]),
                registers=registers,
                absolute_cycle=first_cycle + int(fields[22]),
            )
        )

    if not blits:
        raise ValueError(f"{path}: no BLIT records")
    return sorted(blits, key=lambda blit: (blit.absolute_cycle, blit.rank, blit.index))


def is_display_dummy(blit: CapturedBlit) -> bool:
    regs = blit.registers
    return regs[1] == 0x8000 and (regs[6] & 0x3FF) == 400 and (regs[7] & 0x3FF) == 2


def modeled_pixels(registers: tuple[int, ...]) -> int:
    width = registers[6] & 0x3FF
    height = registers[7] & 0x3FF
    xstep = registers[10] or 0x100
    ystep = registers[11] or 0x100
    if xstep == 0x100 and ystep == 0x100:
        return width * height
    return ((width << 8) // xstep) * ((height << 8) // ystep)


def emit_display(
    blits: list[CapturedBlit],
    start_rank: int,
    start_index: int,
    output: Path,
    output_rank: int,
) -> None:
    try:
        start_position = next(
            position
            for position, blit in enumerate(blits)
            if blit.rank == start_rank and blit.index == start_index
        )
    except StopIteration as exc:
        raise ValueError(
            f"start BLIT rank={start_rank} index={start_index} is absent"
        ) from exc

    start = blits[start_position]
    if not is_display_dummy(start):
        raise ValueError(
            f"start BLIT rank={start.rank} index={start.index} is not "
            "the HHD.ASM do_rink 400x2 dummy"
        )

    end_position = next(
        (
            position
            for position in range(start_position + 1, len(blits))
            if is_display_dummy(blits[position])
        ),
        None,
    )
    if end_position is None:
        raise ValueError("capture ends before the next DISPLAY dummy")

    transaction = blits[start_position:end_position]
    first_cycle = transaction[0].absolute_cycle
    pixels = sum(modeled_pixels(blit.registers) for blit in transaction)
    rink_blits = sum(
        1
        for blit in transaction
        if blit.registers[1] == 0x8023
        and (blit.registers[6] & 0x3FF) == 860
        and 1 <= (blit.registers[7] & 0x3FF) <= 4
    )
    next_dummy_delta = blits[end_position].absolute_cycle - first_cycle

    lines = [
        (
            f"CANDIDATE {output_rank} screen={start.screen} pixels={pixels} "
            f"rinkblits={rink_blits} blits={len(transaction)} "
            f"next_dummy_cycle={next_dummy_delta}"
        )
    ]
    for ordinal, blit in enumerate(transaction, 1):
        words = " ".join(f"{register:04X}" for register in blit.registers)
        relative_cycle = blit.absolute_cycle - first_cycle
        lines.append(
            f"BLIT {output_rank} {start.screen} {ordinal} {words} {relative_cycle}"
        )
    lines.append("DONE")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(lines) + "\n", encoding="ascii", newline="\n")

    print(
        f"display trace: blits={len(transaction)} rink={rink_blits} "
        f"pixels={pixels} next_dummy_cycle={next_dummy_delta} output={output}"
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capture", type=Path)
    parser.add_argument("--start-rank", type=int, required=True)
    parser.add_argument("--start-index", type=int, required=True)
    parser.add_argument("--output-rank", type=int, default=201)
    parser.add_argument("--output", "-o", type=Path, required=True)
    args = parser.parse_args()

    emit_display(
        parse_capture(args.capture),
        args.start_rank,
        args.start_index,
        args.output,
        args.output_rank,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
