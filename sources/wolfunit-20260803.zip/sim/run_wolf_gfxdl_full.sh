#!/usr/bin/env bash
# Full-scale 20 MB graphics boot-copy integration gate.
set -euo pipefail

# --- shared Questa mutex (cross-session contract: /tmp/umk3_questa.lock) -------
# Y-unit 2026-07-27: "it is the runner you DON'T think of as a test that gets
# missed." An unlocked vsim collides with the sibling core sessions and the
# collision surfaces as an ELABORATION or RTL failure, never as a licence error.
# NOTE: this MUST fail loudly if the lock helper is missing. An earlier version
# used a relative path and SILENTLY ran unlocked when it did not resolve --
# a guard that cannot fire is not a guard.
_QL=/d/deck/fpga/umk3/wolf-game-profiles/sim/questa_lock.sh
if [ ! -f "$_QL" ]; then echo "FATAL: questa_lock.sh missing at $_QL" >&2; exit 4; fi
. "$_QL"; trap questa_release EXIT INT TERM
questa_acquire || { echo "BLOCKED: Questa licence unavailable"; exit 3; }
# ------------------------------------------------------------------------------

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TB=tb_wolf_gfxdl_full
BIN="$ROOT/sim/build/umk3_gfx_linear.bin"
LOG="$ROOT/sim/build/$TB.log"
mkdir -p "$ROOT/sim/build"
[ -f "$BIN" ] || { echo "missing umk3_gfx_linear.bin (run make_wolf_gfx_linear_hex.py)"; exit 2; }

# Prove the simulation payload is the exact MRA index-1 stream, not merely 20 MB
# of data that happens to exercise the address path.
python - "$BIN" <<'PY'
import pathlib
import sys
import zlib

expected = [
    0x79B94667, 0x13E95228, 0x41001E30, 0x49379DD7,
    0xA8B41803, 0xB410D72F, 0xBD985BE7, 0xE7C32CF4,
    0x9A52227E, 0x5C750EBC, 0xF0AB88A8, 0x9B87CDAC,
    0xCC4B95DB, 0x1C8144CD, 0x5F10C543, 0xDE0C4488,
    0x99D74A1E, 0xB5A46488, 0xA87523C8, 0x0038F205,
]
data = pathlib.Path(sys.argv[1]).read_bytes()
size = 0x100000
if len(data) != len(expected) * size:
    raise SystemExit(f"FAIL: gfx binary is {len(data)} bytes; expected {len(expected) * size}")
actual = [zlib.crc32(data[i*size:(i+1)*size]) & 0xFFFFFFFF for i in range(len(expected))]
if actual != expected:
    bad = [str(i) for i, (got, want) in enumerate(zip(actual, expected)) if got != want]
    raise SystemExit("FAIL: gfx binary CRC mismatch in MRA part(s): " + ", ".join(bad))
print("PASS: full-test binary matches all 20 MRA gfx CRCs")
PY

rm -f "$LOG"
QUESTA_BIN="${QUESTA_BIN:-}"
if [ -z "$QUESTA_BIN" ] && [ -x /c/altera/25.1std/questa_fse/win64/vsim.exe ]; then
  QUESTA_BIN=/c/altera/25.1std/questa_fse/win64
fi

if [ -n "$QUESTA_BIN" ]; then
  VLIB="$QUESTA_BIN/vlib"; VLOG="$QUESTA_BIN/vlog"; VSIM="$QUESTA_BIN/vsim"
  [ -x "$VLIB" ] || VLIB="$VLIB.exe"
  [ -x "$VLOG" ] || VLOG="$VLOG.exe"
  [ -x "$VSIM" ] || VSIM="$VSIM.exe"
  [ -x "$VSIM" ] || { echo "FAIL: QUESTA_BIN has no executable vsim"; exit 2; }

  cd "$ROOT/sim"
  QWORK="build/questa_full/work_$$"
  mkdir -p "$(dirname "$QWORK")"
  "$VLIB" "$QWORK"
  echo "compiling: $TB (Questa)"
  # ModelSim ASE 10.5b misclassifies typed SystemVerilog input ports under
  # `default_nettype none` unless their port kind is selected explicitly.
  # Modern Questa's relaxed default already chooses var for these ports, so
  # spelling it out is behavior-preserving and keeps the license-free fallback usable.
  "$VLOG" -sv -svinputport=var -work "$QWORK" \
    ../rtl/wolf/wolf_gfx_interleave.sv \
    ../rtl/wolf/wolf_gfxdl_fifo.sv \
    ../rtl/sdram/stv_vram_ddr_agent.sv \
    ../rtl/sdram/wolf_gfx_ddr_top.sv \
    ../rtl/sdram/wolf_ddr3_arb.sv \
    ddr3_avalon_model.sv "$TB.sv"
  echo "running:   $TB +PACED=1 (Questa, full 20 MB stream)"
  "$VSIM" -c -lib "$QWORK" "$TB" +PACED=1 -do 'run -all; quit -f' 2>&1 | tee "$LOG"
else
  export PATH="/c/iverilog/bin:$PATH"
  OUT="$ROOT/sim/build/$TB.vvp"
  echo "compiling: $TB (Icarus fallback)"
  iverilog -g2012 -s "$TB" -o "$OUT" \
    "$ROOT/rtl/wolf/wolf_gfx_interleave.sv" \
    "$ROOT/rtl/wolf/wolf_gfxdl_fifo.sv" \
    "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
    "$ROOT/rtl/sdram/wolf_gfx_ddr_top.sv" \
    "$ROOT/rtl/sdram/wolf_ddr3_arb.sv" \
    "$ROOT/sim/ddr3_avalon_model.sv" \
    "$ROOT/sim/$TB.sv"
  echo "running:   $TB +PACED=1 (Icarus fallback, full 20 MB stream)"
  cd "$ROOT/sim"
  vvp "$OUT" +PACED=1 2>&1 | tee "$LOG"
fi

LC_ALL=C grep -aEq '^(# )?PASS: tb_wolf_gfxdl_full .*model_err=0\)' "$LOG"
