#!/usr/bin/env python3
"""Analyze a HUD-band pixel capture (capture_mk3_hud.lua / capture_umk3_hud_pixels.lua).

The MK3 HUD-flash bug has repeatedly been "fixed" against hypotheses that were
never measured.  This tool answers the one discriminating question the captures
already contain the data for:

    when the emitted HUD pixels change frame-to-frame, is it because the
    FRAMEBUFFER DATA changed, or because the PALETTE changed underneath
    unchanged framebuffer data?

Those two point at completely different subsystems (scanline refill/arbitration
vs. palette mirror transients), so nothing should be built until this is settled.

Capture record format:
    FRAME <f> DPYADR=<h> DPYSTRT=<h> CONTROL=<h>
    VRAM <f> <page> <y> <400 hex entries>      # {pal-index,pixel} entries
    PALETTE <f> <idx>:<val> ...                # every palette word referenced
    SCREEN <f> <y> <400 hex RGB>               # MAME's final scanout
    FRAME_END <f> pixel_ok=<bool> pal_events=<n>
    PALW <f> <t> <off> <data> <mask> <pc>      # timestamped palette writes

Usage:
    python analyze_hud_flash_capture.py <capture.txt> [<capture.txt> ...]
"""

import sys
import collections

PAL_BASE = 0x01880000


def parse(path):
    """Parse a capture into per-frame records. Tolerates truncated captures."""
    frames = collections.OrderedDict()
    palw = []
    cur = None

    def frame(f):
        if f not in frames:
            frames[f] = {
                "regs": {}, "vram": {}, "palette": {},
                "screen": {}, "pixel_ok": None,
            }
        return frames[f]

    with open(path, "r") as fh:
        for line in fh:
            parts = line.split()
            if not parts:
                continue
            tag = parts[0]

            if tag == "FRAME":
                cur = int(parts[1])
                rec = frame(cur)
                for kv in parts[2:]:
                    if "=" in kv:
                        k, v = kv.split("=", 1)
                        rec["regs"][k] = int(v, 16)

            elif tag == "VRAM":
                f, page, y = int(parts[1]), int(parts[2]), int(parts[3])
                frame(f)["vram"][(page, y)] = tuple(
                    int(v, 16) for v in parts[4:]
                )

            elif tag == "PALETTE":
                f = int(parts[1])
                pal = frame(f)["palette"]
                for kv in parts[2:]:
                    idx, val = kv.split(":")
                    pal[int(idx, 16)] = int(val, 16)

            elif tag == "SCREEN":
                f, y = int(parts[1]), int(parts[2])
                frame(f)["screen"][y] = tuple(
                    int(v, 16) for v in parts[3:]
                )

            elif tag == "FRAME_END":
                f = int(parts[1])
                for kv in parts[2:]:
                    if kv.startswith("pixel_ok="):
                        frame(f)["pixel_ok"] = kv.split("=", 1)[1] == "true"

            elif tag == "PALW":
                palw.append({
                    "f": int(parts[1]), "t": float(parts[2]),
                    "off": int(parts[3], 16), "data": int(parts[4], 16),
                    "mask": int(parts[5], 16), "pc": int(parts[6], 16),
                })

    return frames, palw


def visible_page(rec):
    """Which physical page scanout is showing.

    Wolf-unit VRAM is 2 pages of 256 rows; the capture dumps both.  DPYSTRT's
    high nibble selects the page in the same way the core's scanout does.
    Reported as a best-effort hint -- the data-vs-palette verdict below does not
    depend on it, because unchanged-on-BOTH-pages is already conclusive.
    """
    strt = rec["regs"].get("DPYSTRT")
    if strt is None:
        return None
    return (strt >> 12) & 1


def changed_rows(frames, key):
    """Rows whose content differs from the first frame, per frame."""
    order = list(frames)
    base = frames[order[0]][key]
    out = collections.OrderedDict()
    for f in order[1:]:
        cur = frames[f][key]
        diff = sorted(k for k in base if k in cur and base[k] != cur[k])
        if diff:
            out[f] = diff
    return out


def analyze(path):
    frames, palw = parse(path)
    order = list(frames)
    print("=" * 78)
    print(f"{path}")
    print("=" * 78)
    if not order:
        print("  EMPTY capture -- nothing to analyze")
        return

    print(f"frames        : {order[0]}..{order[-1]}  ({len(order)} captured)")
    bad = [f for f in order if frames[f]["pixel_ok"] is False]
    print(f"pixel_ok      : {'ALL TRUE' if not bad else f'FALSE on {bad}'}")

    rows = sorted({y for (_, y) in frames[order[0]]["vram"]})
    print(f"HUD band rows : y={rows[0]}..{rows[-1]} ({len(rows)} rows)")
    pages = sorted({p for (p, _) in frames[order[0]]["vram"]})
    print(f"pages dumped  : {pages}")

    # ---- display registers -------------------------------------------------
    reg_names = sorted(frames[order[0]]["regs"])
    for name in reg_names:
        vals = [frames[f]["regs"].get(name) for f in order]
        uniq = sorted(set(v for v in vals if v is not None))
        if len(uniq) == 1:
            print(f"  {name:<8}= {uniq[0]:04X} (constant)")
        else:
            print(f"  {name:<8}= {' '.join(f'{v:04X}' for v in vals)}")
    vp = [visible_page(frames[f]) for f in order]
    print(f"  visible page (DPYSTRT hint): {vp}")

    # ---- 1. does the EMITTED pixel change? ---------------------------------
    scr_delta = changed_rows(frames, "screen")
    print("\n[1] emitted RGB (MAME scanout) across the window")
    if not scr_delta:
        print("    STEADY -- no HUD row changed vs the first frame")
    else:
        print(f"    UNSTABLE -- {len(scr_delta)}/{len(order)-1} frames differ")
        for f, ys in scr_delta.items():
            print(f"      frame {f}: {len(ys)} rows change  y={ys[0]}..{ys[-1]}")

    # ---- 2. does the FRAMEBUFFER DATA change? ------------------------------
    vram_delta = changed_rows(frames, "vram")
    print("\n[2] framebuffer entries (both pages) across the window")
    if not vram_delta:
        print("    STEADY -- no HUD framebuffer entry changed on either page")
    else:
        print(f"    CHANGING -- {len(vram_delta)}/{len(order)-1} frames differ")
        for f, keys in list(vram_delta.items())[:8]:
            per_page = collections.Counter(p for (p, _) in keys)
            desc = ", ".join(f"page{p}:{n} rows" for p, n in sorted(per_page.items()))
            print(f"      frame {f}: {desc}")

    # ---- 3. does the PALETTE change? ---------------------------------------
    pal_delta = collections.OrderedDict()
    base_pal = frames[order[0]]["palette"]
    for f in order[1:]:
        cur = frames[f]["palette"]
        diff = sorted(i for i in base_pal if i in cur and base_pal[i] != cur[i])
        if diff:
            pal_delta[f] = diff
    print("\n[3] palette words referenced by the HUD band")
    print(f"    {len(base_pal)} distinct pens referenced")
    if not pal_delta:
        print("    STEADY at frame boundaries -- no referenced pen changed value")
    else:
        print(f"    CHANGING -- {len(pal_delta)}/{len(order)-1} frames differ")
        for f, idx in list(pal_delta.items())[:8]:
            print(f"      frame {f}: pens {[f'{i:04X}' for i in idx[:12]]}")

    # ---- 4. mid-frame palette writes ---------------------------------------
    print("\n[4] palette WRITES during the window (sub-frame events)")
    if not palw:
        print("    none")
    else:
        by_pen = collections.Counter((w["off"] - PAL_BASE) // 0x10 for w in palw)
        print(f"    {len(palw)} writes across {len(order)} frames")
        for pen, n in by_pen.most_common(12):
            vals = sorted({w["data"] for w in palw
                           if (w["off"] - PAL_BASE) // 0x10 == pen})
            pcs = sorted({w["pc"] for w in palw
                          if (w["off"] - PAL_BASE) // 0x10 == pen})
            used = "USED-BY-HUD" if pen in base_pal else "not-referenced"
            print(f"      pen {pen:04X}: {n} writes  data={[f'{v:04X}' for v in vals]}"
                  f"  pc={[f'{p:08X}' for p in pcs]}  [{used}]")

    # ---- 5. transient reversion (the actual flash signature) ---------------
    # A flash is a pixel that comes BACK: value[f-1] == value[f+1] != value[f].
    # Ordinary animation almost never reverts exactly, so this is animation-
    # immune in a way "differs from frame 0" is not.  Classify each transient
    # by whether the framebuffer entry behind it also reverted.
    print("\n[5] transient reversions (flash signature, animation-immune)")
    tr_by_frame = collections.Counter()
    tr_by_row = collections.Counter()
    tr_to_black = 0
    tr_total = 0
    tr_examples = []
    tr_data_backed = 0
    tr_palette_only = 0

    for i in range(1, len(order) - 1):
        fp, f, fn = order[i - 1], order[i], order[i + 1]
        for y in rows:
            a = frames[fp]["screen"].get(y)
            b = frames[f]["screen"].get(y)
            c = frames[fn]["screen"].get(y)
            if not (a and b and c):
                continue
            for x in range(min(len(a), len(b), len(c))):
                if a[x] == c[x] and a[x] != b[x]:
                    tr_total += 1
                    tr_by_frame[f] += 1
                    tr_by_row[y] += 1
                    if (b[x] & 0xFFFFFF) == 0:
                        tr_to_black += 1
                    # did the framebuffer entry behind this pixel also revert?
                    ent = None
                    for page in pages:
                        va = frames[fp]["vram"].get((page, y))
                        vb = frames[f]["vram"].get((page, y))
                        vc = frames[fn]["vram"].get((page, y))
                        if va and vb and vc and x < len(va):
                            if va[x] == vc[x] and va[x] != vb[x]:
                                ent = page
                                break
                    if ent is None:
                        tr_palette_only += 1
                    else:
                        tr_data_backed += 1
                    if len(tr_examples) < 6:
                        tr_examples.append(
                            (f, y, x, a[x] & 0xFFFFFF, b[x] & 0xFFFFFF, ent))

    if not tr_total:
        print("    NONE -- no pixel in the HUD band reverted anywhere in the")
        print("    window. This capture contains no flash.")
    else:
        npix = len(rows) * 400 * max(1, len(order) - 2)
        print(f"    {tr_total} reverting pixel-samples "
              f"({100.0*tr_total/npix:.3f}% of the band)")
        print(f"      to black          : {tr_to_black}")
        print(f"      framebuffer-backed: {tr_data_backed}")
        print(f"      palette-only      : {tr_palette_only}")
        worst = tr_by_frame.most_common(5)
        print(f"      worst frames      : "
              f"{[f'{f}:{n}' for f, n in worst]}")
        hot = sorted(tr_by_row)
        print(f"      rows affected     : y={hot[0]}..{hot[-1]} "
              f"({len(hot)} of {len(rows)})")
        for (f, y, x, was, now, ent) in tr_examples:
            src = f"page{ent} data" if ent is not None else "PALETTE-ONLY"
            print(f"        f{f} y{y:3d} x{x:3d}: {was:06X} -> {now:06X} "
                  f"-> {was:06X}  [{src}]")

    # ---- verdict -----------------------------------------------------------
    print("\n[VERDICT]")
    if tr_total:
        print(f"    FLASH PRESENT: {tr_total} reverting samples.")
        if tr_palette_only and not tr_data_backed:
            print("    All reversions are PALETTE-ONLY -> palette-side.")
        elif tr_data_backed and not tr_palette_only:
            print("    All reversions are FRAMEBUFFER-BACKED -> data-side.")
        else:
            print(f"    MIXED: {tr_data_backed} data-backed / "
                  f"{tr_palette_only} palette-only.")
        print("    ^ this is the discriminator; the [1]/[2] passes below")
        print("      cannot separate flash from animation.")
    if not scr_delta:
        print("    HUD is STEADY in this capture window.")
        print("    -> this window does NOT contain the flash; it cannot serve")
        print("       as the failing regression. Recapture a flashing scene.")
    elif vram_delta:
        print("    Emitted pixels change AND framebuffer data changes.")
        print("    -> DATA-SIDE. Look at blit/refill/arbitration, not palette.")
    else:
        print("    Emitted pixels change while framebuffer data is IDENTICAL")
        print("    on both pages.")
        print("    -> PALETTE-SIDE. The bars change color with no new pixel")
        print("       data written. Look at palette mirror/scanout timing.")


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    for path in argv[1:]:
        analyze(path)
        print()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
