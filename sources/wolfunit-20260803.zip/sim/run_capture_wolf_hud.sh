#!/usr/bin/env bash
# Self-validating HUD-band pixel capture, reaching the opponent via the ladder.
#   WOLF_SET=mk3 WOLF_TARGET_WIN=41 WOLF_TAG=motaro ./run_capture_wolf_hud.sh
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/sim/build"
MAME="${MAME:-D:/deck/fpga/starwars/sw/starwars-mister/.tools/mame0287/mame.exe}"
SET="${WOLF_SET:-mk3}"
ROMS="${WOLF_ROMS:-D:/deck/fpga/$SET}"
TAG="${WOLF_TAG:-op${WOLF_TARGET_WIN:-41}}"
SCRIPT="$ROOT/sim/capture_wolf_hud_pixels.lua"
OUT="${WOLF_HUD_OUT:-$BUILD/hud_${SET}_${TAG}.txt}"
SECS="${WOLF_HUD_SECONDS:-900}"
mkdir -p "$BUILD"; rm -f "$OUT"
export WOLF_HUD_OUT="$OUT"
export WOLF_REACH="${WOLF_REACH:-ladder}"
export WOLF_TARGET_WIN="${WOLF_TARGET_WIN:-41}"
export WOLF_HUD_FRAMES="${WOLF_HUD_FRAMES:-16}"
export WOLF_HUD_ROWS="${WOLF_HUD_ROWS:-64}"
"$MAME" "$SET" -rompath "$ROMS" \
  -nowindow -video none -sound none -nothrottle \
  -seconds_to_run "$SECS" -autoboot_delay 0 -autoboot_script "$SCRIPT"
grep -q '^DONE ' "$OUT" || { echo "FAIL: capture did not complete"; tail -5 "$OUT"; exit 1; }
grep -E '^(PHASE armed|SUMMARY)' "$OUT"
PCT=$(grep '^SUMMARY ' "$OUT" | sed -n 's/.*worst_best_pct=\([0-9.]*\).*/\1/p')
NCOL=$(grep '^SUMMARY ' "$OUT" | sed -n 's/.*best_cols=\(.*\)$/\1/p' | tr ',' '\n' | grep -c .)
[ "$NCOL" = "1" ] || { echo "FAIL: column offset not stable across frames"; exit 1; }
awk -v p="$PCT" 'BEGIN{ if (p+0 < 99.0) { print "FAIL: capture does not reproduce MAME scanout ("p"%)"; exit 1 } print "OK: capture reproduces MAME scanout ("p"%)" }'
