#!/usr/bin/env bash
# run_wolf_gfxdl_e2e.sh -- gfx-ROM download END-TO-END integration gate (iverilog):
#   interleave -> gfxdl FIFO -> wolf_gfx_ddr_top -> wolf_ddr3_arb -> faithful DDR3 model,
#   with REAL reset semantics (core rst HIGH through the whole download) + the PLL-lock
#   idle gap. Primary model config = MEASURED bridge behavior (cfg_ignore_be=1,
#   cfg_write_lat=255).
#
# MUTATION COVERAGE (each variant is a sed-edited TEMP COPY in sim/build/ -- the real
# rtl/ files are never touched):
#   M1  P0022 regate: write front-end reset sdram_por -> (sdram_por || rst)
#       expected FAIL: HANG (wait_o stuck -- download freezes while rst is high)
#   M2  partial-BE bypass (cab-refuted STV P1.5): skip the RMW read, direct write with
#       tst_be = wl_mask.  expected FAIL: MISMATCH under cfg_ignore_be=1 (the model
#       writes all 8 lanes, clobbering the beat's other lanes with stale data) --
#       proves the RMW is load-bearing against the measured bridge behavior
#   M3  interleave break: group-4 base 0x1400000 -> 0x1000000
#       expected FAIL: MISMATCH concentrated in the chip-17 window (w3_chip17>0)
#   M4  same-beat write forwarding disabled. expected PASS: the current faithful model's
#       exact single-beat RAW ordering publishes the pending same-address write before
#       returning data, so forwarding is a redundant fast path under that contract.
#   M5  quiet guard reduced 512 -> 1 cycle. expected PASS for the same reason: the
#       immediate final-byte read is an ordered single-beat RAW publication point.
# M4/M5 used to expect stale-read failures before the model gained exact single-beat
# RAW ordering. Keeping them as explicit resilience variants prevents that historical
# expectation from silently becoming stale again; the production RTL remains unchanged.
# Then the REAL RTL runs under ignore_be=1 AND ignore_be=0: both must PASS.
set -e
cd "$(dirname "$0")/.."
IVERILOG=${IVERILOG:-/c/iverilog/bin/iverilog}
VVP=${VVP:-/c/iverilog/bin/vvp}
B="sim/build/gfxdl_e2e"
mkdir -p "$B"
GATE_MARKER="$B/gate.pass"
rm -f "$GATE_MARKER"

MODEL="sim/ddr3_avalon_model.sv"
TB="sim/tb_wolf_gfxdl_e2e.sv"
R_IL="rtl/wolf/wolf_gfx_interleave.sv"
R_FIFO="rtl/wolf/wolf_gfxdl_fifo.sv"
R_GUARD="rtl/wolf/wolf_gfxdl_guard.sv"
R_TOP="rtl/sdram/wolf_gfx_ddr_top.sv"
R_ARB="rtl/sdram/wolf_ddr3_arb.sv"
R_AGENT="rtl/sdram/stv_vram_ddr_agent.sv"

fails=0

# run_case tag plusargs expect guard_source sources...
#   expect: PASS | FAIL_HANG | FAIL_MM | FAIL_MM_W3
run_case() {
  local tag="$1" plus="$2" expect="$3" guard="$4"; shift 4
  "$IVERILOG" -g2012 -o "$B/$tag.vvp" "$@" "$guard" "$MODEL" "$TB"
  set +e
  "$VVP" "$B/$tag.vvp" $plus > "$B/$tag.log" 2>&1
  set -e
  local res
  res=$(grep -E "^RESULT:" "$B/$tag.log" | tail -1)
  local ok=0
  case "$expect" in
    PASS)       echo "$res" | grep -q "RESULT: PASS" && ok=1 ;;
    FAIL_HANG)  echo "$res" | grep -q "RESULT: FAIL -- HANG" && ok=1 ;;
    FAIL_MM)    echo "$res" | grep -qE "RESULT: FAIL -- [1-9][0-9]* mismatches" && ok=1 ;;
    FAIL_MM_W3) echo "$res" | grep -qE "RESULT: FAIL -- [1-9][0-9]* mismatches" \
                && echo "$res" | grep -qE "w3_chip17=[1-9]" && ok=1 ;;
  esac
  if [ "$ok" = "1" ]; then
    echo "[$tag] OK (expected $expect): $res"
  else
    echo "[$tag] *** UNEXPECTED (wanted $expect): ${res:-<no RESULT line>}  (log: $B/$tag.log)"
    fails=$((fails+1))
  fi
}

# ---- mutants (temp copies only; expect FAIL for the right reason) ----------------------
echo "== M1: P0022 regate (write front-end reset on sdram_por || rst) -> expect HANG =="
cp "$R_TOP" "$B/m1_wolf_gfx_ddr_top.sv"
sed -i '0,/if (sdram_por) begin/s//if (sdram_por || rst) begin/' "$B/m1_wolf_gfx_ddr_top.sv"
grep -q "sdram_por || rst" "$B/m1_wolf_gfx_ddr_top.sv" || { echo "M1 sed did not apply"; exit 1; }
run_case m1_regate "+ignore_be=1" FAIL_HANG "$R_GUARD" "$R_IL" "$R_FIFO" "$B/m1_wolf_gfx_ddr_top.sv" "$R_ARB" "$R_AGENT"

echo "== M2: partial-BE direct write, RMW bypassed (STV P1.5) -> expect MISMATCH =="
cp "$R_TOP" "$B/m2_wolf_gfx_ddr_top.sv"
sed -i "s/\.tst_be(8'hFF)/.tst_be(wl_mask)/" "$B/m2_wolf_gfx_ddr_top.sv"
sed -i 's/ost <= O_FRD;/ost <= O_FWR;/'      "$B/m2_wolf_gfx_ddr_top.sv"
grep -q "tst_be(wl_mask)" "$B/m2_wolf_gfx_ddr_top.sv" || { echo "M2 sed(be) did not apply"; exit 1; }
# 3 occurrences after the sed: forwarding-hit branch + O_FRDW + the rewritten O_FRD line
grep -c "ost <= O_FWR;" "$B/m2_wolf_gfx_ddr_top.sv" | grep -q "^3$" || { echo "M2 sed(bypass) did not apply"; exit 1; }
run_case m2_partial_be "+ignore_be=1" FAIL_MM "$R_GUARD" "$R_IL" "$R_FIFO" "$B/m2_wolf_gfx_ddr_top.sv" "$R_ARB" "$R_AGENT"

echo "== M3: interleave group-4 base 0x1400000 -> 0x1000000 -> expect chip-17 MISMATCH =="
cp "$R_IL" "$B/m3_wolf_gfx_interleave.sv"
sed -i "s/25'h1400000/25'h1000000/" "$B/m3_wolf_gfx_interleave.sv"
grep -q "25'h1000000" "$B/m3_wolf_gfx_interleave.sv" || { echo "M3 sed did not apply"; exit 1; }
run_case m3_interleave "+ignore_be=1" FAIL_MM_W3 "$R_GUARD" "$B/m3_wolf_gfx_interleave.sv" "$R_FIFO" "$R_TOP" "$R_ARB" "$R_AGENT"

echo "== M4: same-beat write forwarding DISABLED -> expect PASS via ordered single-beat RAW =="
cp "$R_TOP" "$B/m4_wolf_gfx_ddr_top.sv"
sed -i 's/if (fwd_valid && (wc_beat == fwd_beat)) begin/if (1'"'"'b0) begin/' "$B/m4_wolf_gfx_ddr_top.sv"
grep -q "if (1'b0) begin" "$B/m4_wolf_gfx_ddr_top.sv" || { echo "M4 sed did not apply"; exit 1; }
run_case m4_no_fwd_ordered_raw "+ignore_be=1" PASS "$R_GUARD" "$R_IL" "$R_FIFO" "$B/m4_wolf_gfx_ddr_top.sv" "$R_ARB" "$R_AGENT"

echo "== M5: post-acceptance quiet guard 512 -> 1 cycle -> expect PASS via ordered final-byte RAW =="
cp "$TB" "$B/m5_tb_wolf_gfxdl_e2e.sv"
sed -i 's/QUIET_CYCLES(512)/QUIET_CYCLES(1)/' "$B/m5_tb_wolf_gfxdl_e2e.sv"
grep -q "QUIET_CYCLES(1)" "$B/m5_tb_wolf_gfxdl_e2e.sv" || { echo "M5 sed did not apply"; exit 1; }
TB_SAVE="$TB"; TB="$B/m5_tb_wolf_gfxdl_e2e.sv"
run_case m5_short_guard_ordered_raw "+ignore_be=1" PASS "$R_GUARD" "$R_IL" "$R_FIFO" "$R_TOP" "$R_ARB" "$R_AGENT"
TB="$TB_SAVE"

# ---- real RTL (both model configs must PASS) --------------------------------------------
echo "== REAL RTL, cfg_ignore_be=1 + cfg_write_lat=255 (measured f2h_sdram1) =="
run_case real_ib1 "+ignore_be=1" PASS "$R_GUARD" "$R_IL" "$R_FIFO" "$R_TOP" "$R_ARB" "$R_AGENT"

echo "== REAL RTL, cfg_ignore_be=0 (BE-honoring DDR; equivalent for a be=FF-only design) =="
run_case real_ib0 "+ignore_be=0" PASS "$R_GUARD" "$R_IL" "$R_FIFO" "$R_TOP" "$R_ARB" "$R_AGENT"

echo
if [ "$fails" = "0" ]; then
  echo "GATE: PASS -- real RTL green; 3 corruption/hang mutants killed; 2 ordered-RAW resilience variants green"
  : > "$GATE_MARKER"
else
  echo "GATE: FAIL -- $fails case(s) did not meet expectation"
  exit 1
fi
