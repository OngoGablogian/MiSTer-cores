#!/usr/bin/env python3
"""
Tier-2 SRT entry-level golden model -- BLIND-AUTHORED from the MAME gospel only.

Sources (the ONLY implementation references used; no RTL, no Tier-2 TB):
  D:/deck/fpga/umk3/mame-gospel/midway/midtunit_v.cpp
  D:/deck/fpga/umk3/mame-gospel/midway/midtunit_v.h
  D:/deck/fpga/umk3/mame-gospel/midway/midtunit_v.ipp
  TI TMS34010 UG extracts in the session scratchpad (FILL/PIXT/DPTCH semantics)

Model space: VRAM = 512 rows x 512 u16 ENTRIES, entry index E = row*512 + col
             = bitaddr >> 3 (each entry is one 8-bit pixel + 8-bit palette-high).

Gospel semantics implemented:
  * SRT latch     (to_shiftreg,   midtunit_v.cpp:330-333): copy 2*512 = 1024 FULL
    u16 entries starting at entry index (bitaddr >> 3) into the shift register.
    Palette-high bytes INCLUDED (memcpy of uint16_t).
  * SRT transfer  (from_shiftreg, midtunit_v.cpp:336-339): copy the 1024-entry
    shift register back to entry index (bitaddr >> 3). Full entries.
  * CPU 16-bit word <-> entry mapping (midtunit_v.cpp:259-320): CPU word index W
    covers entries 2W and 2W+1; byte routing depends on videobank_select.
    Used only by the --no-srt mutation (plain-word-op fallback).
  * DMA sprite, command 0x8002 (midtunit_v.cpp:695-836 dma_w + :431-610 dma_draw
    + midtunit_v.ipp:31-65 mode table):
      - (command & 0x1f) == 2 -> TEMPLATED_DMA_DRAW_P1 (.ipp:32, .ipp:52):
        Zero = PIXEL_SKIP, NonZero = PIXEL_COPY.
      - bpp field (command >> 12) & 7 == 0 -> 8 bpp (.ipp:12, dma_w:722).
      - pal = DMA_PALETTE & 0x7f00 (dma_w:729) = 0x0900.
      - nonzero source byte: d[sx] = pixel | pal (dma_draw:527) where
        d = &videoram[sy * 512] (dma_draw:499)  => entry = {0x09, pixel byte}.
      - zero source byte: skipped (dest untouched).
      - sy/sx wrap with YPOSMASK=0x1ff / XPOSMASK=0x3ff (midtunit_v.h:76-77);
        noskip/noscale/noflip; clip registers modeled full-open
        (top=0 bot=0x1ff left=0 right=0x3ff, LRSKIP=0, SCALE_X/Y=0 -> 0x100).
  * Scanout (scanline_update, midtunit_v.cpp:846-855):
        dest[x] = src[coladdr++ & 0x1ff] & 0x7fff, src = &videoram[row * 512].
    Projection per the Tier-2 contract: 254 lines x 400 columns, palette index
    at pixcol (56 + x) & 0x1ff; page 0 = rows 0..253, page 1 = rows 256..509.

Interchange conventions chosen where the contract text is ambiguous (DOCUMENTED
so the cross-diff adjudicator can rule on any TB mismatch):
  1. Sprite source byte src(i, j): i = ROW (0..35), j = COLUMN (0..341),
     matrix (row, col) order; gfx-ROM backing is row-major, byte k = i*342 + j.
     Matches dma_draw source consumption: offset += width*bpp per row
     (midtunit_v.cpp:580).
  2. --no-srt plain-word-op fallback: the 34010 FILL L pixel writes become
     normal 16-bit VRAM word writes of COLOR1's low word (B9 = 0xDEADDEAD ->
     0xDEAD).  The sequence never writes the wolf control register, so
     videobank_select keeps the MAME power-on default 0 (midtunit_v.cpp:53
     member init) -> the select==0 branch of midtunit_vram_w (:269-275):
     data bytes land in the PALETTE-HIGH bytes of entries 2W / 2W+1, pixel
     bytes preserved.  The PIXT *A2,A2 latch trigger degrades to a plain pixel
     READ (register destination) -> no memory effect.

Outputs (text, LF newlines, lowercase hex):
  vram_entries.hex : 512 lines x 512 entries, %04x, space-separated
  scan_p0.hex      : 254 lines x 400 values, %04x, space-separated (rows 0..253)
  scan_p1.hex      : 254 lines x 400 values, %04x, space-separated (rows 256..509)
Baseline  -> sim/build/srt2_golden/
Mutations -> sim/build/srt2_golden_<flag>/  (no-srt, pixel-only-copy, sr512,
                                             wrong-page)

stdlib only.  Does NOT touch the committed Tier-1 golden_srt_page_erase.py.
"""

import argparse
import os
import sys

# ---------------------------------------------------------------- constants
ROWS, COLS = 512, 512
PAGE_ROWS = 254
SCAN_W, SCAN_COL0 = 400, 56

LATCH_BITADDR = 0x1FE000          # PIXT *A2,A2 with A2 = 0x1FE000 (rows 510/511)
DPTCH_BITS = 0x2000               # DPTCH register
FILL_ROWS = 127                   # DYDX = 0x007F0001 -> DY=127 rows, DX=1 pixel
DADDR_FRAMES = (0x00100000, 0x00000000)
PAGE_BIT = 0x00100000
FILL_COLOR16 = 0xDEAD             # B9 (COLOR1) = 0xDEADDEAD, low 16 bits @16bpp

SPRITE_W, SPRITE_H = 342, 36
SPRITE_X = 87
SPRITE_Y_ABS = (303, 47)          # page-relative Y=47: frame1 abs 303, frame2 abs 47
SPRITE_PAL = 0x0900               # DMA_PALETTE word 0x0900 & 0x7f00 (dma_w:729)

XPOSMASK, YPOSMASK = 0x3FF, 0x1FF  # midtunit_v.h:76-77

SR_FULL = 1024                    # 2*512 entries (midtunit_v.cpp:332)
SR_HALF = 512                     # --sr512 mutation

MUTATIONS = ("no-srt", "pixel-only-copy", "sr512", "wrong-page")


# ---------------------------------------------------------------- preseed
def preseed():
    """Tier-2 contract preseed, identical on both sides."""
    vram = [0] * (ROWS * COLS)
    for r in range(510):
        base = r * COLS
        for c in range(COLS):
            e = 0x8000 | ((r * 13 + c * 5) & 0x7FFF)
            if e == 0:            # contract: force nonzero (unreachable: bit15 set)
                e = 1
            vram[base + c] = e
    for c in range(COLS):
        vram[510 * COLS + c] = (0x1500 ^ c) & 0xFFFF
        vram[511 * COLS + c] = (0x2600 ^ c) & 0xFFFF
    return vram


# ---------------------------------------------------------------- sprite source
def src_byte(i, j):
    """Sprite source byte, i = row 0..35, j = col 0..341 (convention #1)."""
    if (i * 7 + j * 13) % 5 == 0:
        return 0
    return 0x40 | ((i + j) & 0x3F)


# ---------------------------------------------------------------- model
class Model:
    def __init__(self, mutation=None):
        assert mutation in (None,) + MUTATIONS
        self.mut = mutation
        self.vram = preseed()
        self.sr = None
        self.touched_rows = []    # one set per frame (SRT-erase-touched rows)

    # --- SRT ops --------------------------------------------------------
    def srt_latch(self, bitaddr):
        """to_shiftreg: 1024 (or 512 for --sr512) full entries at bitaddr>>3.
        midtunit_v.cpp:330-333."""
        if self.mut == "no-srt":
            return                # plain pixel READ: no memory/state effect
        n = SR_HALF if self.mut == "sr512" else SR_FULL
        base = bitaddr >> 3
        self.sr = self.vram[base:base + n]

    def srt_transfer(self, bitaddr, touched):
        """from_shiftreg: write the SR back at bitaddr>>3.
        midtunit_v.cpp:336-339."""
        if self.mut == "no-srt":
            self._plain_word_write(bitaddr, FILL_COLOR16, touched)
            return
        base = bitaddr >> 3
        if self.mut == "pixel-only-copy":
            # MUTANT: only pixel low bytes copied, palette-highs left stale
            for k, e in enumerate(self.sr):
                idx = base + k
                self.vram[idx] = (self.vram[idx] & 0xFF00) | (e & 0xFF)
                touched.add(idx // COLS)
        else:
            for k, e in enumerate(self.sr):
                idx = base + k
                self.vram[idx] = e
                touched.add(idx // COLS)

    def _plain_word_write(self, bitaddr, data16, touched):
        """--no-srt fallback: 16-bit CPU word write via midtunit_vram_w with
        videobank_select = 0 (MAME default; :269-275): data bytes -> palette-high
        bytes of entries 2W, 2W+1; pixel bytes preserved."""
        w = bitaddr >> 4
        e0, e1 = 2 * w, 2 * w + 1
        self.vram[e0] = (self.vram[e0] & 0x00FF) | ((data16 & 0x00FF) << 8)
        self.vram[e1] = (self.vram[e1] & 0x00FF) | (data16 & 0xFF00)
        touched.add(e0 // COLS)

    # --- one DIRQ frame -------------------------------------------------
    def dirq_frame(self, daddr):
        """DPYCTL=0x6810 (SRT on, bit 11); PIXT *A2,A2 A2=0x1FE000 -> latch;
        FILL L: DYDX=0x007F0001, DPTCH=0x2000 -> 127 one-pixel rows, each pixel
        access converted to an SRT row transfer at DADDR + r*DPTCH."""
        if self.mut == "wrong-page":
            daddr ^= PAGE_BIT
        touched = set()
        self.srt_latch(LATCH_BITADDR)
        for r in range(FILL_ROWS):
            self.srt_transfer(daddr + r * DPTCH_BITS, touched)
        self.touched_rows.append(touched)

    # --- DMA sprite (command 0x8002) ------------------------------------
    def dma_sprite(self, ypos):
        """midtunit dma_draw<8, noflip, noskip, noscale, SKIP, COPY>
        (midtunit_v.cpp:431-560; mode 2 per midtunit_v.ipp:32,:52).
        zero=skip, nonzero: d[sx] = pixel | pal (:527)."""
        pal = SPRITE_PAL & 0x7F00
        for i in range(SPRITE_H):
            sy = (ypos + i) & YPOSMASK
            base = sy * COLS
            for j in range(SPRITE_W):
                sx = (SPRITE_X + j) & XPOSMASK
                pix = src_byte(i, j)
                if pix:
                    self.vram[base + sx] = pix | pal

    # --- full Tier-2 sequence -------------------------------------------
    def run(self):
        for frame in range(2):
            self.dirq_frame(DADDR_FRAMES[frame])
            self.dma_sprite(SPRITE_Y_ABS[frame])
        return self


# ---------------------------------------------------------------- scanout
def scanout(vram, page):
    """midtunit scanline_update projection (midtunit_v.cpp:846-855):
    value = entry(row, (56+x) & 0x1ff) & 0x7fff."""
    lines = []
    for l in range(PAGE_ROWS):
        row = page * 256 + l
        base = row * COLS
        lines.append([vram[base + ((SCAN_COL0 + x) & 0x1FF)] & 0x7FFF
                      for x in range(SCAN_W)])
    return lines


# ---------------------------------------------------------------- output
def fmt_lines(rows_of_vals):
    return ["".join("%04x " % v for v in row).rstrip() for row in rows_of_vals]


def write_set(outdir, vram):
    os.makedirs(outdir, exist_ok=True)
    files = {}
    vram_rows = [vram[r * COLS:(r + 1) * COLS] for r in range(ROWS)]
    files["vram_entries.hex"] = fmt_lines(vram_rows)
    files["scan_p0.hex"] = fmt_lines(scanout(vram, 0))
    files["scan_p1.hex"] = fmt_lines(scanout(vram, 1))
    for name, lines in files.items():
        with open(os.path.join(outdir, name), "w", newline="\n") as f:
            f.write("\n".join(lines) + "\n")
    return files


# ---------------------------------------------------------------- verification
def verify_baseline(model):
    vram = model.vram
    pre = preseed()
    errors = []

    # 1. erase footprint: exactly rows 256..509 (frame1) and 0..253 (frame2)
    want = [set(range(256, 510)), set(range(0, 254))]
    for f in range(2):
        if model.touched_rows[f] != want[f]:
            errors.append("frame%d erase rows %s != expected %s"
                          % (f + 1, sorted(model.touched_rows[f])[:4],
                             [min(want[f]), max(want[f])]))

    # sprite footprints (absolute rows / cols)
    sprite_rows = {0: range(SPRITE_Y_ABS[1], SPRITE_Y_ABS[1] + SPRITE_H),
                   1: range(SPRITE_Y_ABS[0], SPRITE_Y_ABS[0] + SPRITE_H)}
    sr_all = set(sprite_rows[0]) | set(sprite_rows[1])
    sprite_cols = range(SPRITE_X, SPRITE_X + SPRITE_W)

    # 2. rows 254/255/510/511 preseed-intact
    for r in (254, 255, 510, 511):
        if vram[r * COLS:(r + 1) * COLS] != pre[r * COLS:(r + 1) * COLS]:
            errors.append("row %d not preseed-intact" % r)

    # 3. erased-row background = latched row-510/511 pattern; sprite overlay OK
    def erase_expect(r, c):
        # even rows got SR[0..511] = preseed row 510, odd rows SR[512..1023] = row 511
        return ((0x1500 ^ c) if (r % 2 == 0) else (0x2600 ^ c)) & 0xFFFF

    bad_bg = bad_hi = bad_sprite = 0
    for r in list(range(0, 254)) + list(range(256, 510)):
        base = r * COLS
        in_sprite_row = r in sr_all
        yrel = None
        if in_sprite_row:
            yrel = r - (SPRITE_Y_ABS[1] if r < 256 else SPRITE_Y_ABS[0])
        for c in range(COLS):
            got = vram[base + c]
            if in_sprite_row and c in sprite_cols:
                pix = src_byte(yrel, c - SPRITE_X)
                exp = (pix | SPRITE_PAL) if pix else erase_expect(r, c)
                if got != exp:
                    bad_sprite += 1
            else:
                exp = erase_expect(r, c)
                if got != exp:
                    bad_bg += 1
                if (got >> 8) & 0x80:       # preseed high bytes all have bit15
                    bad_hi += 1
    if bad_bg:
        errors.append("%d erased-background entries != row510/511 pattern" % bad_bg)
    if bad_hi:
        errors.append("%d erased entries still carry 0x8000-preseed highs" % bad_hi)
    if bad_sprite:
        errors.append("%d sprite-region entries wrong" % bad_sprite)
    return errors


def diff_counts(set_a, set_b):
    out = {}
    for name in ("vram_entries.hex", "scan_p0.hex", "scan_p1.hex"):
        out[name] = sum(1 for a, b in zip(set_a[name], set_b[name]) if a != b)
    return out


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description="Tier-2 SRT entry-level golden")
    ap.add_argument("--out-base", default=None,
                    help="output base dir (default: <script>/build)")
    for m in MUTATIONS:
        ap.add_argument("--" + m, action="store_true",
                        help="produce ONLY the %s mutation set" % m)
    args = ap.parse_args()

    out_base = args.out_base or os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "build")

    picked = [m for m in MUTATIONS if getattr(args, m.replace("-", "_"))]
    if len(picked) > 1:
        ap.error("pick at most one mutation flag")

    if picked:
        m = picked[0]
        model = Model(m).run()
        outdir = os.path.join(out_base, "srt2_golden_" + m)
        write_set(outdir, model.vram)
        print("[golden-t2] wrote %s" % outdir)
        return 0

    # full run: baseline + all mutations + verification + diff report
    print("[golden-t2] baseline ...")
    base_model = Model(None).run()
    base_dir = os.path.join(out_base, "srt2_golden")
    base_files = write_set(base_dir, base_model.vram)
    print("[golden-t2] wrote %s" % base_dir)

    errors = verify_baseline(base_model)
    for e in errors:
        print("[golden-t2] VERIFY-FAIL: %s" % e)
    if not errors:
        print("[golden-t2] baseline VERIFY OK: erase rows f1=256..509 f2=0..253; "
              "rows 254/255/510/511 preseed-intact; erased highs = 0x14/0x15/"
              "0x26/0x27 pattern (no 0x80xx preseed highs); sprites exact")

    zero_diff = False
    for m in MUTATIONS:
        model = Model(m).run()
        outdir = os.path.join(out_base, "srt2_golden_" + m)
        files = write_set(outdir, model.vram)
        d = diff_counts(base_files, files)
        total = sum(d.values())
        print("[golden-t2] mutation %-16s diff lines: vram=%d scan_p0=%d "
              "scan_p1=%d (total %d)" % (m, d["vram_entries.hex"],
                                         d["scan_p0.hex"], d["scan_p1.hex"], total))
        if total == 0:
            zero_diff = True
            print("[golden-t2] VERIFY-FAIL: mutation %s identical to baseline" % m)

    if errors or zero_diff:
        print("[golden-t2] RESULT: FAIL")
        return 1
    print("[golden-t2] RESULT: PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
