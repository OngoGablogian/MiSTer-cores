#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
wolf_video_model.py -- Python GOLDEN MODEL of the UMK3 (T / Wolf-unit) wolf_video
pixel scanout path: VRAM 16-bit word -> 15-bit palette INDEX -> palette lookup
(xRGB-1555) -> RGB888 via pal5bit replicate.

This is a faithful transcription of MAME 0.280 (vendored gospel) scanline_update
plus the standard MAME palette_device conversion. It validates the cleanly
specifiable core of wolf_video (the pixel path); free-running raster / sync /
completion is validated separately from the measured geometry, NOT here.

=====================================================================
GOSPEL (vendored MAME; cite file:line)
=====================================================================
Pixel/scanout -- midway/midtunit_v.cpp:846-855
    TMS340X0_SCANLINE_IND16_CB_MEMBER(midtunit_video_device::scanline_update)
    {
        uint16_t const *const src = &m_local_videoram[(params->rowaddr << 9) & 0x3fe00];  // :848
        uint16_t *const dest = &bitmap.pix(scanline);                                     // :849
        int coladdr = params->coladdr << 1;                                               // :850
        // copy the non-blanked portions of this scanline
        for (int x = params->heblnk; x < params->hsblnk; x++)                             // :853
            dest[x] = src[coladdr++ & 0x1ff] & 0x7fff;                                    // :854
    }
  So per visible pixel i (i = x - heblnk, in [0, hsblnk-heblnk) ):
    base   = (rowaddr << 9) & 0x3fe00          (:848; FB_ROWSHIFT=9 => 512 words/row)
    ca     = coladdr << 1                       (:850)
    idx15  = m_local_videoram[ base + ((ca + i) & 0x1ff) ] & 0x7fff   (:854)
  The IND16 bitmap value written is the 15-bit PALETTE INDEX (masked & 0x7fff).
  m_local_videoram is uint16_t[0x80000] (16-bit words), default 0.
  NOTE the `& 0x1ff` wraps the COLUMN within the 512-word row window ONLY; the row
  `base` is added AFTER the wrap, so the read address is base + (col & 0x1ff).
  Copy MAME verbatim: the wrap is on the column index, not on base+col.

Palette -- midwunit.cpp:122 (and midwunit.cpp:643 PALETTE xRGB_555, 32768 entries)
    map(0x01880000,0x018fffff).ram().w(m_palette, palette_device::write16).share("palette");
  A standard MAME palette_device, format xRGB-1555, 32768 entries. The IND16 index
  idx15 selects palette[idx15]; the palette entry is the xRGB-1555 color word.
  Conversion (standard MAME palette_device xRGB_555 -> rgb888) uses pal5bit on each
  5-bit channel:
    c    = palette[idx15]  (16-bit; only low 15 bits meaningful, bit15 = x/ignored)
    R5   = (c >> 10) & 0x1f     (c[14:10])
    G5   = (c >>  5) & 0x1f     (c[9:5])
    B5   = (c >>  0) & 0x1f     (c[4:0])
    R8   = pal5bit(R5); G8 = pal5bit(G5); B8 = pal5bit(B5)
  pal5bit(v5) replicate: R8 = (v5 << 3) | (v5 >> 2)   (5 bits, then top-3 replicated
  into the low 3 bits -> 8 bits). This is MAME emupal's pal5bit.

Display timing / geometry (MEASURED; midwunit.cpp:625,647) -- NOT exercised by this
  pixel-path model, retained here as documentation only:
    PIXEL_CLOCK = 8 MHz; screen.set_raw(8e6, 506, 101, 501, 289, 20, 274)
    htotal=506, hbend(active start)=101, hbstart(active end)=501  => 400 active px
    vtotal=289, vbend=20, vbstart=274                             => 254 visible lines
  Double-buffer: DPYSTRT toggles {0xFFFC,0xEFFC} => rowaddr base {0x000,0x100}={0,256}
  per frame; rowaddr = base_row + scanline (+1 per visible line). Here we take rowaddr
  and coladdr directly as inputs (params->rowaddr / params->coladdr), matching the CB.

=====================================================================
SHARED CONTRACT (pinned; do NOT deviate)
=====================================================================
Test case JSON = array of objects:
  { "name", "vram":[[idx,val],...], "palette":[[idx,xrgb1555],...],
    "rowaddr":<int 0..0x3fff>, "coladdr":<int params->coladdr>, "npix":<visible count> }
  vram sparse into 0x80000 16-bit entries (default 0);
  palette sparse into 32768 16-bit entries (default 0); all decimal in canonical vectors.
Golden per pixel i in [0,npix):
  base=(rowaddr<<9)&0x3fe00; ca=coladdr<<1; idx15=vram[base+((ca+i)&0x1ff)]&0x7fff;
  c=palette[idx15]; R8=rep5to8(c[14:10]); G8=rep5to8(c[9:5]); B8=rep5to8(c[4:0]);
  rep5to8(v5)=(v5<<3)|(v5>>2).
Output stream: npix lines, uppercase hex '%04X %02X%02X%02X' = (idx15, R8, G8, B8), LF.

CLI: python wolf_video_model.py <vectors.json> <outdir>
  -> writes <outdir>/<name>.golden.txt per test case, contract stream format.
"""

import sys
import os
import json

VRAM_WORDS = 0x80000      # m_local_videoram[0x80000], 16-bit  (midtunit_v.cpp)
PAL_ENTRIES = 32768       # palette_device 32768 entries       (midwunit.cpp:643)


def rep5to8(v5):
    """pal5bit: 5-bit -> 8-bit replicate. R8 = (v5<<3)|(v5>>2). (MAME emupal pal5bit)"""
    v5 &= 0x1f
    return ((v5 << 3) | (v5 >> 2)) & 0xff


def scanline_pixels(vram, palette, rowaddr, coladdr, npix):
    """
    Transcription of midtunit_v.cpp:846-854 per-pixel, plus the palette_device
    xRGB-1555 -> RGB888 conversion (midwunit.cpp:122,643).

    vram    : dict {word_index:int -> value:int}, default 0 (0x80000 space)
    palette : dict {index:int -> xrgb1555:int}, default 0 (32768 space)
    rowaddr : params->rowaddr
    coladdr : params->coladdr
    npix    : number of visible pixels (= hsblnk - heblnk in the CB)
    Returns list of (idx15, R8, G8, B8) tuples in scan order.
    """
    # midtunit_v.cpp:848  src = &videoram[(rowaddr << 9) & 0x3fe00]
    base = (rowaddr << 9) & 0x3fe00
    # midtunit_v.cpp:850  coladdr = params->coladdr << 1
    ca = coladdr << 1

    out = []
    for i in range(npix):
        # midtunit_v.cpp:854  dest[x] = src[coladdr++ & 0x1ff] & 0x7fff;
        #   src is base-relative; coladdr post-increments; & 0x1ff wraps the COLUMN.
        col = (ca + i) & 0x1ff
        word = vram.get(base + col, 0) & 0xffff
        idx15 = word & 0x7fff                       # 15-bit palette INDEX

        # palette lookup (midwunit.cpp:122) then xRGB-1555 -> RGB888 (pal5bit)
        c = palette.get(idx15, 0) & 0xffff
        r8 = rep5to8((c >> 10) & 0x1f)              # c[14:10]
        g8 = rep5to8((c >> 5) & 0x1f)               # c[9:5]
        b8 = rep5to8((c >> 0) & 0x1f)               # c[4:0]
        out.append((idx15, r8, g8, b8))
    return out


def format_stream(pixels):
    """Contract stream: '%04X %02X%02X%02X' per pixel, LF-terminated."""
    lines = []
    for (idx15, r8, g8, b8) in pixels:
        lines.append("%04X %02X%02X%02X" % (idx15 & 0xffff, r8 & 0xff, g8 & 0xff, b8 & 0xff))
    return "\n".join(lines) + ("\n" if lines else "")


def load_sparse(pairs, size):
    """Load [[idx,val],...] into a dict; assert in range (mirrors gospel array bounds)."""
    d = {}
    for idx, val in pairs:
        idx = int(idx)
        # In MAME the wrap keeps the read in [base, base+0x1ff]; base<=0x3fe00 so
        # max read index = 0x3fe00 + 0x1ff = 0x3ffff < 0x80000. Vectors may place
        # values anywhere in [0,0x80000)/[0,32768); just store them.
        d[idx] = int(val) & 0xffff
    return d


def run_case(case):
    vram = load_sparse(case.get("vram", []), VRAM_WORDS)
    palette = load_sparse(case.get("palette", []), PAL_ENTRIES)
    rowaddr = int(case["rowaddr"])
    coladdr = int(case["coladdr"])
    npix = int(case["npix"])
    pixels = scanline_pixels(vram, palette, rowaddr, coladdr, npix)
    return format_stream(pixels)


def main(argv):
    if len(argv) != 3:
        sys.stderr.write("usage: python wolf_video_model.py <vectors.json> <outdir>\n")
        return 2
    vectors_path, outdir = argv[1], argv[2]
    with open(vectors_path, "r") as f:
        cases = json.load(f)
    if not os.path.isdir(outdir):
        os.makedirs(outdir)
    for case in cases:
        name = case["name"]
        stream = run_case(case)
        out_path = os.path.join(outdir, name + ".golden.txt")
        with open(out_path, "w", newline="") as f:   # newline="" => keep our LF, no CRLF
            f.write(stream)
        sys.stderr.write("wrote %s (%d px)\n" % (out_path, int(case["npix"])))
    return 0


# =====================================================================
# SELF-TEST -- hand-walked micro cases (run: python wolf_video_model.py --selftest)
# =====================================================================
#
# CASE 1 -- simple copy at rowaddr 0.
#   rowaddr=0 -> base=(0<<9)&0x3fe00 = 0.  coladdr=0 -> ca=0.  npix=3.
#   i=0: col=(0+0)&0x1ff=0 ; vram[0+0]=0x1234 ; idx15=0x1234&0x7fff=0x1234
#        palette[0x1234]=0x7FFF -> R5=G5=B5=0x1f -> rep5to8(0x1f)=(0x1f<<3)|(0x1f>>2)
#           =0xF8|0x07=0xFF. => "1234 FFFFFF"
#   i=1: col=1 ; vram[1]=0x0001 ; idx15=1 ; palette[1]=0x0400 ->
#        R5=(0x0400>>10)&0x1f=1 -> rep5to8(1)=(1<<3)|(1>>2)=8|0=0x08 ; G5=0 ; B5=0
#        => "0001 080000"
#   i=2: col=2 ; vram[2] absent =>0 ; idx15=0 ; palette[0] absent =>0 => "0000 000000"
#   EXPECT:
#     1234 FFFFFF
#     0001 080000
#     0000 000000
#
# CASE 2 -- column wrap (ca+i wraps at 0x1ff, base still 0).
#   rowaddr=0 -> base=0.  coladdr=0xFF -> ca=0xFF<<1=0x1FE.  npix=3.
#   i=0: col=(0x1FE+0)&0x1ff=0x1FE ; vram[0x1FE]=0x0002 ; idx15=2 ; palette[2]=0x001F ->
#        R5=0,G5=0,B5=0x1f -> B8=0xFF => "0002 0000FF"
#   i=1: col=(0x1FE+1)&0x1ff=0x1FF ; vram[0x1FF]=0x0003 ; idx15=3 ; palette[3]=0x03E0 ->
#        G5=(0x03E0>>5)&0x1f=0x1f -> G8=0xFF => "0003 00FF00"
#   i=2: col=(0x1FE+2)&0x1ff=0x000 (WRAP) ; vram[0]=0x0004 ; idx15=4 ; palette[4]=0x7C00 ->
#        R5=(0x7C00>>10)&0x1f=0x1f -> R8=0xFF => "0004 FF0000"
#   EXPECT:
#     0002 0000FF
#     0003 00FF00
#     0004 FF0000
#
# CASE 3 -- rowaddr != 0 double-buffer base (buffer B, rowaddr base = 0x100=256).
#   rowaddr=0x100 -> base=(0x100<<9)&0x3fe00 = 0x20000 & 0x3fe00 = 0x20000.
#   coladdr=0 -> ca=0.  npix=2.
#   i=0: col=0 ; vram[0x20000+0]=0x5678 ; idx15=0x5678&0x7fff=0x5678 ;
#        palette[0x5678]=0x0421 -> R5=(0x0421>>10)&0x1f=1 -> R8=0x08 ;
#           G5=(0x0421>>5)&0x1f=1 -> G8=0x08 ; B5=0x0421&0x1f=1 -> B8=0x08
#        => "5678 080808"
#   i=1: col=1 ; vram[0x20001] absent =>0 ; idx15=0 ; palette[0] absent =>0 => "0000 000000"
#   EXPECT:
#     5678 080808
#     0000 000000

def _selftest():
    cases = [
        {
            "name": "case1_copy_row0",
            "vram": [[0, 0x1234], [1, 0x0001], [2, 0x0000]],
            "palette": [[0x1234, 0x7FFF], [1, 0x0400]],
            "rowaddr": 0, "coladdr": 0, "npix": 3,
            "_expect": "1234 FFFFFF\n0001 080000\n0000 000000\n",
        },
        {
            "name": "case2_colwrap",
            "vram": [[0x1FE, 0x0002], [0x1FF, 0x0003], [0, 0x0004]],
            "palette": [[2, 0x001F], [3, 0x03E0], [4, 0x7C00]],
            "rowaddr": 0, "coladdr": 0xFF, "npix": 3,
            "_expect": "0002 0000FF\n0003 00FF00\n0004 FF0000\n",
        },
        {
            "name": "case3_bufferB_row256",
            "vram": [[0x20000, 0x5678]],
            "palette": [[0x5678, 0x0421]],
            "rowaddr": 0x100, "coladdr": 0, "npix": 2,
            "_expect": "5678 080808\n0000 000000\n",
        },
    ]
    ok = True
    for c in cases:
        got = run_case(c)
        exp = c["_expect"]
        status = "PASS" if got == exp else "FAIL"
        if got != exp:
            ok = False
        sys.stderr.write("[%s] %s\n" % (status, c["name"]))
        if got != exp:
            sys.stderr.write("  expected:\n%s\n  got:\n%s\n" % (exp, got))
    sys.stderr.write("SELFTEST %s\n" % ("PASS" if ok else "FAIL"))
    return 0 if ok else 1


if __name__ == "__main__":
    if len(sys.argv) == 2 and sys.argv[1] == "--selftest":
        sys.exit(_selftest())
    sys.exit(main(sys.argv))
