#!/usr/bin/env bash
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; BUILD="$ROOT/sim/build"
MAME="${MAME:-C:/tools/mame/mame.exe}"; ROMS="${UMK3_ROMS:-D:/deck/fpga/umk3/roms}"
SCRIPT="$ROOT/sim/reach_and_capture_motaro.lua"
OUT="${OUT:-$BUILD/umk3_motaro_live.txt}"; SNAPDIR="${SNAPDIR:-$BUILD/motaro_live_snaps}"
STATEDIR="${STATEDIR:-$BUILD/motaro_live_states}"
mkdir -p "$BUILD" "$SNAPDIR" "$STATEDIR"
NVDIR="$(mktemp -d "$BUILD/motaro_live_nv.XXXXXX")"; trap 'rm -rf "$NVDIR"' EXIT
NVSEED="${NVSEED:-D:/deck/fpga/wolf-nvram-80/by-setname/umk3.nvm}"
[ -f "$NVSEED" ] && { mkdir -p "$NVDIR/umk3"; cp "$NVSEED" "$NVDIR/umk3/nvram"; }
rm -f "$OUT"
export MOTARO_REACH_OUT="$OUT"
"$MAME" umk3 -rompath "$ROMS" -nvram_directory "$NVDIR" \
  -snapshot_directory "$SNAPDIR" -state_directory "$STATEDIR" \
  -nowindow -video none -sound none -seconds_to_run "${SECS:-260}" \
  -autoboot_delay 0 -nothrottle -autoboot_script "$SCRIPT"
grep -E '^CAPTURE_ARM|^NBLITS|^DONE|^ERROR' "$OUT"
