#!/usr/bin/env bash
# run_wolf_mem_cgfx_isrom.sh — discriminating gate for the cgfx_is_rom demux key that
# routes CPU program-ROM reads to SDRAM and gfx-image reads to DDR3 under USE_DDR3_GFX.
#
#   ./run_wolf_mem_cgfx_isrom.sh            normal gate: MUST print PASS (exit 0)
#   MUTATE=1 ./run_wolf_mem_cgfx_isrom.sh   coverage proof: compiles a temp copy of
#                                           wolf_mem.sv with the demux key forced to
#                                           `cgfx_is_rom <= 1'b0` (the exact cab bug:
#                                           every read looks like gfx -> all reads to
#                                           DDR3 -> reset vector reads 0); the TB MUST
#                                           FAIL -> script exits 0 iff it failed.
#
# iverilog only. Compiles wolf_mem standalone with -DUSE_EXT_GFX -DUSE_EXT_ROM
# -DUSE_DDR3_GFX so BOTH regions route through the shared external-fetch port and the
# demux is load-bearing. Keep every path quoted (the repo tree may contain spaces).
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export PATH="/c/iverilog/bin:$PATH"

TB=tb_wolf_mem_cgfx_isrom
WOLF_MEM="$ROOT/rtl/wolf/wolf_mem.sv"
mkdir -p "$ROOT/sim/build"

if [ "${MUTATE:-0}" = "1" ]; then
  WOLF_MEM="$ROOT/sim/build/wolf_mem_cgfx_mutant.sv"
  sed "s/cgfx_is_rom <= (region == R_ROM);/cgfx_is_rom <= 1'b0;/" \
      "$ROOT/rtl/wolf/wolf_mem.sv" > "$WOLF_MEM"
  if cmp -s "$ROOT/rtl/wolf/wolf_mem.sv" "$WOLF_MEM"; then
    echo "MUTATION ERROR: sed did not change wolf_mem.sv (pattern drifted?)"; exit 2
  fi
  echo "== MUTATION RUN: cgfx_is_rom forced to 0 (all-gfx); the TB must FAIL =="
fi

OUT="$ROOT/sim/build/$TB.vvp"
echo "compiling: $TB  (defs: -DUSE_EXT_GFX -DUSE_EXT_ROM -DUSE_DDR3_GFX; wolf_mem: $WOLF_MEM)"
iverilog -g2012 -DUSE_EXT_GFX -DUSE_EXT_ROM -DUSE_DDR3_GFX -s "$TB" -o "$OUT" \
  "$ROOT/rtl/pkg/wolf_pkg.sv" "$WOLF_MEM" "$ROOT/sim/$TB.sv"

echo "running:   $TB"
cd "$ROOT/sim"
LOG="$ROOT/sim/build/$TB.log"
vvp "$OUT" | tee "$LOG"

if [ "${MUTATE:-0}" = "1" ]; then
  if grep -q "^PASS:" "$LOG"; then
    echo "MUTATION GATE FAIL: TB PASSED with the demux key broken (gate does not cover the fix)"; exit 1
  else
    echo "MUTATION GATE OK: TB correctly FAILED with the demux key broken"; exit 0
  fi
else
  if grep -q "^PASS:" "$LOG"; then exit 0; else echo "GATE FAIL"; exit 1; fi
fi
