#!/usr/bin/env bash
# MAME invocation copied verbatim from sim/run_openice_dpy_probe.sh.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/sim/build"
MAME="${MAME:-D:/deck/fpga/starwars/sw/starwars-mister/.tools/mame0287/mame.exe}"
ROMS="${OPENICE_ROMS:-D:/deck/fpga/openice}"
SCRIPT="$ROOT/sim/probe_openice_pageb.lua"
OUT="$BUILD/openice_pageb_probe.txt"
SEED="${OPENICE_NVRAM_SEED:-D:/deck/fpga/wolf-nvram-80/by-setname/openice.nvm}"

mkdir -p "$BUILD"
NVDIR="$(mktemp -d "$BUILD/openice_pageb_nv.XXXXXX")"
trap 'rm -rf "$NVDIR"' EXIT
mkdir -p "$NVDIR/openice"
cp "$SEED" "$NVDIR/openice/nvram"
rm -f "$OUT"

export OPENICE_PAGEB_OUT="$OUT"
"$MAME" openice -rompath "$ROMS" -nvram_directory "$NVDIR" \
  -nowindow -video none -sound none -seconds_to_run 45 -autoboot_delay 0 \
  -nothrottle -autoboot_script "$SCRIPT"
echo "wrote $OUT"
