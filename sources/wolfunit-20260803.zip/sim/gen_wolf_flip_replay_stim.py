#!/usr/bin/env python3
"""Build the flip-replay stimulus from two MEASURED sources, on ONE 80 MHz timebase.

  source 1 (phase anchor) : sim/build/openice_flipphase.txt
        produced by sim/capture_openice_flip_phase.lua -- exact TMS34010 VSBLNK
        edges (screen:time_until_vblank_start), every DPYADR/DPYSTRT write, and
        every DMA blit trigger, all in 80 MHz cycles from T0 = first VSBLNK.

  source 2 (render_busy shape) : sim/build/rb_openice_rank11c.txt
        produced by sim/tb_render_busy_probe.sv -- a run-length encoding of the
        REAL wolf_video_top.sv:58 predicate  render_busy = wr_busy || blit_busy
        read hierarchically from stv_vram_ddr_top.wr_busy and wolf_dma.busy in
        tb_wolf_peak_fight_budget.  NOT a home-grown quiescence predicate
        (NARC correction (C)).

ALIGNMENT (the whole point of this step).  The rb probe's cycle 0 is the start of
the EXACT_REPLAY command stream: tb_wolf_peak_fight_budget.sv:711-713 sets
frame_start = sim_cycles+40 at the first GO edge, and the probe emits its 'F'
marker at the clk it first sees frame_start != 0.  So

    rb cycle (F_cyc + 40)  <->  the MAME cycle of the frame's FIRST blit trigger.

and that MAME cycle is measured here, per frame, as (first BLIT) - (preceding VS).
The rb trace is therefore laid down once per frame at
    VS[n] + first_blit_offset[n]
so its cycle-0 sits exactly where the real command stream starts relative to the
real VSBLNK edge.  No origin sweep.

Outputs (packed hex, one 64-bit word per line, for $readmemh):
    fp_vs.hex   : cycle
    fp_rb.hex   : (cycle << 1) | render_busy_level
    fp_dpy.hex  : (cycle << 20) | base_row      (base = (DPYADR ^ 0xfffc) >> 4)
"""
import os
import sys

CLK_FRAME_NOM = 1462340

HERE = os.path.dirname(os.path.abspath(__file__))
BUILD = os.path.join(HERE, 'build')


def load_phase(path):
    vs, blits, dpy = [], [], []
    for ln in open(path):
        p = ln.split()
        if not p:
            continue
        if p[0] == 'VS':
            vs.append(int(p[2]))
        elif p[0] == 'BLIT':
            blits.append(int(p[2]))
        elif p[0] == 'RBLIT':
            # Full-register captures place the 80 MHz timestamp in the final
            # field (RBLIT ordinal mame_frame r0..r17 cycle).
            blits.append(int(p[-1]))
        elif p[0] == 'DPYADR':
            dpy.append((int(p[2]), int(p[3], 16)))
    vs.sort()
    blits.sort()
    return vs, blits, dpy


def load_rb(path):
    """-> (runs, F_cyc, total).  runs = [(start, len, 'B'|'I')] sorted."""
    runs = []
    f_cyc = None
    for ln in open(path):
        if ln.startswith('#'):
            continue
        k, s, l = ln.split()
        if k == 'F':
            f_cyc = int(s)
            continue
        if k == 'E':
            continue
        runs.append((int(s), int(l), k))
    runs.sort()
    total = runs[-1][0] + runs[-1][1]
    return runs, (0 if f_cyc is None else f_cyc), total


def main():
    phase = sys.argv[1] if len(sys.argv) > 1 else os.path.join(BUILD, 'openice_flipphase.txt')
    rbp = sys.argv[2] if len(sys.argv) > 2 else os.path.join(BUILD, 'rb_openice_rank11c.txt')
    outdir = sys.argv[3] if len(sys.argv) > 3 else os.path.join(BUILD, 'flipreplay')
    os.makedirs(outdir, exist_ok=True)

    vs, blits, dpy = load_phase(phase)
    runs, f_cyc, rb_total = load_rb(rbp)
    rb_zero = f_cyc + 40          # rb cycle that maps to the frame's first blit

    if len(vs) < 3:
        print('FAIL: only %d VSBLNK edges captured' % len(vs))
        return 2

    # ---- per-frame first-blit offset (the measured phase) -------------------
    windows = []
    for i in range(len(vs) - 1):
        seg = [c for c in blits if vs[i] <= c < vs[i + 1]]
        if seg:
            windows.append((vs[i], seg[0] - vs[i], len(seg)))
    if len(windows) < 8:
        print('FAIL: only %d frame windows carry blits (need >=8)' % len(windows))
        return 2

    offs = [w[1] for w in windows]
    print('PHASE ANCHOR (measured, %d frame windows):' % len(windows))
    print('  VS period          : %s clk (nominal %d)' %
          (sorted({vs[i + 1] - vs[i] for i in range(len(vs) - 1)}), CLK_FRAME_NOM))
    print('  first blit after VS: min=%d max=%d spread=%d clk' %
          (min(offs), max(offs), max(offs) - min(offs)))
    print('  blits per frame    : %s' % [w[2] for w in windows])
    print('RB SHAPE: %s  total=%d clk  F=%d  rb_zero=%d' %
          (os.path.basename(rbp), rb_total, f_cyc, rb_zero))

    # ---- lay the rb shape down once per frame at its measured origin --------
    nf = len(windows)
    sim_end = vs[nf] + 200000
    level = [0] * 0
    events = []   # (cycle, value)
    for (v, off, _n) in windows:
        origin = v + off - rb_zero
        for (s, l, k) in runs:
            if k != 'B':
                continue
            a, b = origin + s, origin + s + l
            if b <= 0:
                continue
            events.append((max(a, 0), 1))
            events.append((b, 0))

    # flatten overlapping busy intervals into a level waveform
    events.sort()
    rb_out, depth, cur = [], 0, 0
    for (c, v) in events:
        depth += 1 if v else -1
        nv = 1 if depth > 0 else 0
        if nv != cur:
            rb_out.append((c, nv))
            cur = nv
    if rb_out and rb_out[0][0] != 0:
        rb_out.insert(0, (0, 0))

    # ---- DPYADR -> base_row -------------------------------------------------
    dpy_out = []
    for (c, d) in sorted(dpy):
        dpy_out.append((c, ((d ^ 0xfffc) >> 4) & 0x7ffff))

    def wr(name, rows):
        p = os.path.join(outdir, name)
        with open(p, 'w') as fh:
            for r in rows:
                fh.write('%016x\n' % r)
        return p, len(rows)

    p1, n1 = wr('fp_vs.hex', [v for v in vs])
    p2, n2 = wr('fp_rb.hex', [(c << 1) | v for (c, v) in rb_out])
    p3, n3 = wr('fp_dpy.hex', [(c << 20) | r for (c, r) in dpy_out])

    with open(os.path.join(outdir, 'fp_meta.txt'), 'w') as fh:
        fh.write('nvs=%d nrb=%d ndpy=%d nframes=%d sim_end=%d rb_zero=%d\n'
                 % (n1, n2, n3, nf, sim_end, rb_zero))
        fh.write('first_blit_off_min=%d max=%d\n' % (min(offs), max(offs)))
    print('wrote %s (%d), %s (%d), %s (%d)  sim_end=%d' % (p1, n1, p2, n2, p3, n3, sim_end))

    # ---- offline restatement of the FSM criterion (cross-check) -------------
    # commit needs the FIRST ce tick with render_busy==0 at-or-after frame_start
    # to land at tick d <= 15658  (see the TB header for the derivation).
    def busy_at(c):
        lo, hi = 0, len(rb_out) - 1
        if not rb_out or c < rb_out[0][0]:
            return 0
        while lo < hi:
            m = (lo + hi + 1) // 2
            if rb_out[m][0] <= c:
                lo = m
            else:
                hi = m - 1
        return rb_out[lo][1]

    print('OFFLINE CROSS-CHECK (deadline d<=15658 ce ticks):')
    for i in range(nf):
        v = vs[i]
        d = 0
        c = v
        while busy_at(c) and d < 20000:
            c += 10
            d += 1
        print('  frame %d VS=%9d : first render_busy==0 at ce tick %5d -> %s'
              % (i, v, d, 'COMMIT' if d <= 15658 else 'STARVED'))
    return 0


if __name__ == '__main__':
    sys.exit(main())
