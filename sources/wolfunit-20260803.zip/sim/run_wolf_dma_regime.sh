#!/usr/bin/env bash
# Capture the blitter REGIMES a Wolf title actually uses, from MAME.
#
#   bash sim/run_wolf_dma_regime.sh            # all seven titles
#   bash sim/run_wolf_dma_regime.sh openice    # one title
#
# Feeds sim/gen_wolf_dma_vectors.py: cases derived from the ROM's own register
# writes rather than hand-authored sweeps. See probe_wolf_dma_regime.lua for why.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/sim/build/regimes"
MAME="${MAME:-D:/deck/fpga/starwars/sw/starwars-mister/.tools/mame0287/mame.exe}"
NVSRC="${WOLF_NVRAM_DIR:-D:/deck/fpga/wolf-nvram-80/by-setname}"
SECS="${WOLF_REGIME_SECONDS:-120}"

# setname -> rompath. Each title's zip lives in its own core tree.
declare -A ROMDIR=(
  [openice]="D:/deck/fpga/openice"
  [wwfmania]="D:/deck/fpga/wrestlemania"
  [mk3]="D:/deck/fpga/mk3"
  [umk3]="D:/deck/fpga/umk3/roms"
  [nbahangt]="D:/deck/fpga/umk3/nba-hangtime"
  [nbamht]="D:/deck/fpga/nba maximum hangtime;D:/deck/fpga/umk3/nba-hangtime"
  [rmpgwt]="D:/deck/fpga/rampageworldtour/roms"
)

TITLES=("$@")
if [ ${#TITLES[@]} -eq 0 ]; then
  TITLES=(openice wwfmania mk3 umk3 nbahangt nbamht rmpgwt)
fi

mkdir -p "$BUILD"
rc_all=0
for t in "${TITLES[@]}"; do
  rd="${ROMDIR[$t]:-}"
  if [ -z "$rd" ]; then echo "SKIP $t (no rompath configured)"; continue; fi
  out="$BUILD/$t.regimes.txt"
  nv="$(mktemp -d "$BUILD/nv.$t.XXXXXX")"
  trap 'rm -rf "$nv"' EXIT INT TERM
  mkdir -p "$nv/$t"
  [ -f "$NVSRC/$t.nvm" ] && cp "$NVSRC/$t.nvm" "$nv/$t/nvram"
  rm -f "$out"

  # TWO-PHASE NVRAM BOOT. The Hangtime titles reach ZERO blits on a first run:
  # they initialise NVRAM, then require a RESTART to boot into attract/gameplay.
  # A single run therefore produces an empty regime list that reads exactly like
  # "this title uses no regimes". Phase 1 is a throwaway warm-up whose NVRAM the
  # capture run inherits, because the nvram_directory persists between them.
  case "$t" in
    nbahangt|nbamht)
      "$MAME" "$t" -rompath "$rd" -nvram_directory "$nv" \
        -nowindow -video none -sound none -seconds_to_run 25 \
        -autoboot_delay 0 -nothrottle >/dev/null 2>&1 || true
      ;;
  esac

  # The Lua wait budget MUST end before MAME does. If the coroutine is still
  # waiting when the machine tears down, MAME SEGFAULTS and writes nothing --
  # which reads as INCONCLUSIVE rather than as the crash it is. Derived from
  # SECS here so the two can never drift apart.
  WAIT_MS=$(( (SECS - 20) * 1000 ))
  WOLF_REGIME_OUT="$out" WOLF_REGIME_TITLE="$t" WOLF_REGIME_WAIT_MS="$WAIT_MS" \
  "$MAME" "$t" -rompath "$rd" -nvram_directory "$nv" \
    -nowindow -video none -sound none -seconds_to_run "$SECS" \
    -autoboot_delay 0 -nothrottle \
    -autoboot_script "$ROOT/sim/probe_wolf_dma_regime.lua" >/dev/null 2>&1
  rm -rf "$nv"; trap - EXIT INT TERM

  # LIVENESS, not existence. An empty file is INCONCLUSIVE, never "no regimes".
  if [ ! -s "$out" ]; then
    echo "INCONCLUSIVE $t -- no probe output (MAME failed to run?)"; rc_all=3; continue
  fi
  if grep -q "TEST-INVALID" "$out"; then
    echo "TEST-INVALID $t -- $(grep -m1 TEST-INVALID "$out")"; rc_all=4; continue
  fi
  n=$(grep -c "^REGIME" "$out")
  tr_=$(grep -m1 "^DONE" "$out")
  printf "OK   %-9s %2d distinct regimes  (%s)\n" "$t" "$n" "$tr_"
done
exit $rc_all
