#!/usr/bin/env bash
# Stress the complete MAME-derived frame at the documented upper DDR read
# latency. The software timer cadence remains reported, but this diagnostic
# requires exact command/write output before the physical display deadline.
set -euo pipefail

cd "$(dirname "$0")/.."
IVERILOG="${IVERILOG:-/c/iverilog/bin/iverilog}"
VVP="${VVP:-/c/iverilog/bin/vvp}"
OUT="sim/build/tb_wolf_peak_fight_silicon_latency.vvp"
LOG="${LOG:-sim/build/tb_wolf_peak_fight_silicon_latency.log}"
TRACE="${TRACE:-sim/traces/umk3_peak_attract_regs.txt}"
RANK="${RANK:-1}"

test -f sim/build/umk3_gfx.hex || {
  echo "sim/build/umk3_gfx.hex missing; run: python sim/make_wolf_gfx_hex.py" >&2
  exit 1
}
test -f "$TRACE" || {
  echo "trace missing: $TRACE" >&2
  exit 1
}

"$IVERILOG" -g2012 -s tb_wolf_peak_fight_budget -o "$OUT" \
  rtl/pkg/wolf_pkg.sv \
  rtl/wolf/wolf_dma.sv \
  rtl/yunit/vram_sdram.sv \
  rtl/yunit/vram_sdram_top.sv \
  rtl/sdram/stv_vram_ddr_agent.sv \
  rtl/sdram/stv_vram_ddr_top.sv \
  rtl/sdram/wolf_gfx_ddr_top.sv \
  rtl/sdram/wolf_ddr3_arb.sv \
  sim/ddr3_avalon_model.sv \
  sim/tb_wolf_peak_fight_budget.sv

"$VVP" "$OUT" "+TRACE=$TRACE" "+RANK=$RANK" +TIMED_REPLAY=1 \
  +CBUSY=2 +CRLAT=30 +CGAP=7 +ALLOW_TIMER_OVERRUN=1 \
  +EXPECT_BLITS=198 +EXPECT_WRITES=150546 +EXPECT_HASH=0bc2983e86e3a0ea | tee "$LOG"

grep -Eq '^REPLAY: timed=1 .*trigger_pulses=198 trig_entries=198 setup_entries=198 ' "$LOG"
grep -q '^WRITE ORACLE: blits=198 writes=150546 fnv64=0bc2983e86e3a0ea' "$LOG"
grep -Eq '^QUEUE TELEMETRY: highwater=[0-9]+ overflow=0' "$LOG"
grep -q '^PASS: live-fight frame retires' "$LOG"
! grep -q '^RESULT: FAIL' "$LOG"
