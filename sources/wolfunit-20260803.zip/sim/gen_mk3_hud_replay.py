#!/usr/bin/env python3
"""Convert RBLIT capture records to peak-fight RTL replay input.

The default output keeps one selectable replay rank per captured frame.  With
--continuous, every command is assigned to rank 1 and retains its position in
the complete capture window.  That mode is used to expose renderer backlog
which an isolated heaviest-frame replay necessarily resets away.
"""
from collections import OrderedDict
from pathlib import Path
import argparse


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("capture", nargs="?", default="sim/build/mk3_hud.txt")
    ap.add_argument("output", nargs="?", default="sim/build/mk3_hud_replay.txt")
    ap.add_argument(
        "--continuous",
        action="store_true",
        help="emit the complete capture as rank 1 with global relative timing",
    )
    args = ap.parse_args()

    frames: OrderedDict[int, list[tuple[int, list[str], int]]] = OrderedDict()
    for line in Path(args.capture).read_text().splitlines():
        fields = line.split()
        if len(fields) != 22 or fields[0] != "RBLIT":
            continue
        ordinal = int(fields[1])
        mame_frame = int(fields[2])
        regs = fields[3:21]
        cycle = int(fields[21])
        frames.setdefault(mame_frame, []).append((ordinal, regs, cycle))

    if not frames:
        raise SystemExit("no RBLIT records found")
    t0 = min(cycle for rows in frames.values() for _, _, cycle in rows)
    with Path(args.output).open("w", newline="\n") as out:
        if args.continuous:
            index = 0
            for mame_frame, rows in frames.items():
                for _ordinal, regs, cycle in rows:
                    index += 1
                    out.write("BLIT 1 %d %d %s %d\n" %
                              (mame_frame, index, " ".join(regs), cycle - t0))
            print(f"rank=01 frames={len(frames)} blits={index} "
                  f"window_cycles={max(c for rows in frames.values() for _, _, c in rows)-t0}")
            print(f"wrote {args.output}: continuous capture")
            return 0
        for rank, (mame_frame, rows) in enumerate(frames.items(), 1):
            frame_t0 = min(cycle for _, _, cycle in rows)
            for index, (_ordinal, regs, cycle) in enumerate(rows, 1):
                out.write("BLIT %d %d %d %s %d\n" %
                          (rank, mame_frame, index, " ".join(regs), cycle - frame_t0))
            print(f"rank={rank:02d} mame_frame={mame_frame} blits={len(rows)} "
                  f"first_global_cycle={frame_t0-t0}")
    print(f"wrote {args.output}: {len(frames)} frames")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
