#!/usr/bin/env bash
# run_wolf_flip_replay_gate.sh -- ANCHORED flip gate. iverilog only, NO Questa,
# NO Quartus, no RTL edits.
#
#   [0] (optional) re-capture the phase anchor from MAME  (CAPTURE=1)
#   [1] build the stimulus from the captured anchor + the REAL render_busy RLE
#   [2] compile wolf_pkg + rtl/wolf/wolf_video.sv + tb_wolf_video_flip_replay.sv
#   [3] run the anchored case                       -> must not be STARVED/INVALID
#   [4] coverage/mutation case (+mut=N stretches every busy run) -> MUST be STARVED
#
# Exit codes: 0 pass, 90.. build/stim failures, 2 INVALID, 3 anchored verdict
# STARVED (= cause CONFIRMED, reported as such), 4 mutation did not kill.
set -u
cd "$(dirname "$0")"

IVERILOG=${IVERILOG:-/c/iverilog/bin/iverilog}
VVP=${VVP:-/c/iverilog/bin/vvp}
PY=${PY:-python}

BUILD=build/flipreplay
PHASE=${PHASE:-build/openice_flipphase.txt}
RB=${RB:-build/rb_openice_rank11c.txt}
FRAMES=${FRAMES:-9}
MUT=${MUT:-2000000}

mkdir -p "$BUILD"

if [ "${CAPTURE:-0}" = "1" ]; then
  echo "=== [0] MAME phase capture ==="
  bash ./run_openice_flip_phase_capture.sh || exit 89
fi

[ -f "$PHASE" ] || { echo "MISSING phase capture $PHASE (run with CAPTURE=1)"; exit 90; }
[ -f "$RB" ]    || { echo "MISSING render_busy RLE $RB"; exit 90; }

echo "=== [1] stimulus ==="
$PY gen_wolf_flip_replay_stim.py "$PHASE" "$RB" "$BUILD" || exit 91

echo "=== [2] compile ==="
rm -f "$BUILD/tb.vvp"
$IVERILOG -g2012 -o "$BUILD/tb.vvp" \
  ../rtl/pkg/wolf_pkg.sv ../rtl/wolf/wolf_video.sv tb_wolf_video_flip_replay.sv \
  2>"$BUILD/compile.log"
rc=$?
[ $rc -ne 0 ] && { echo "iverilog rc=$rc"; cat "$BUILD/compile.log"; exit 92; }
[ -s "$BUILD/compile.log" ] && cat "$BUILD/compile.log"

echo "=== [3] ANCHORED case (real VSBLNK phase, real render_busy) ==="
$VVP "$BUILD/tb.vvp" +dir="$BUILD" +frames=$FRAMES +tag=anchored | tee "$BUILD/anchored.log"
grep -q "VERDICT anchored: INVALID" "$BUILD/anchored.log" && { echo "GATE INVALID"; exit 2; }

echo "=== [4] COVERAGE/MUTATION case (+mut=$MUT : every busy run stretched, drain can never land) ==="
$VVP "$BUILD/tb.vvp" +dir="$BUILD" +frames=$FRAMES +mut=$MUT +tag=mutstretch | tee "$BUILD/mut.log"
if ! grep -q "VERDICT mutstretch: STARVED" "$BUILD/mut.log"; then
  echo "GATE BROKEN: the mutation did NOT produce STARVED -- this bench cannot detect pinning"
  exit 4
fi
echo "COVERAGE OK: the bench CAN report STARVED; the anchored verdict is therefore discriminating."

if grep -q "VERDICT anchored: STARVED" "$BUILD/anchored.log"; then
  echo "RESULT: flip starvation CONFIRMED at the measured phase"
  exit 3
fi
if grep -q "VERDICT anchored: HEALTHY" "$BUILD/anchored.log"; then
  echo "RESULT: FALSIFIED -- the real trace commits on every frame at the measured phase"
  exit 0
fi
echo "RESULT: PARTIAL -- see $BUILD/anchored.log"
exit 0
