#!/usr/bin/env python3
"""Set or verify the packaged Wolf-unit cabinet volume at full scale.

Wolf CMOS is stored as 0x6000 little-endian, byte-valued u16 entries.  The
games keep the master volume in their adjustment block and protect that block
with a 16-bit one's-complement checksum.  Raising 0xCC to 0xFF adds 0x3300 to
the adjustment sum, so the high checksum byte decreases by 0x33.
"""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path


NVRAM_BYTES = 0xC000
OLD_VOLUME = 0xCC
FULL_VOLUME = 0xFF

# filename: (volume byte offset, adjustment-checksum high-byte offset,
#            checksum at 0xCC, SHA-256 of the original 80% seed)
SEEDS = {
    "Mortal Kombat 3 (rev 2.1).nvm": (
        0x107E, 0x1162, 0xFA,
        "d68b71c2c99949a4ca66fc953983bfd6a92d27b38e95b630b5d94ab8b46b2075",
    ),
    "NBA Hangtime (L1.3).nvm": (
        0x08F6, 0x09DA, 0xB7,
        "874d51973d57e6ea1600175886c44eb07f2b20ed482c3e9e704c1035b64f6b52",
    ),
    "NBA Maximum Hangtime (L1.03 06-09-97).nvm": (
        0x08F6, 0x09DA, 0xB7,
        "d47e922d81b0af98997c2a16c33b4be0120c84abeebc8ad176d668ac006dbd3b",
    ),
    "NHL Open Ice - 2 on 2 Challenge (rev 1.21).nvm": (
        0x10E6, 0x119A, 0xAE,
        "8736f2bb3bbbef3047f9a5fce30e472e391285ff93da3147037b893081b78db2",
    ),
    "Rampage World Tour.nvm": (
        0x10E6, 0x119A, 0xAE,
        "9f85a2266b6426cfcbe64d0ddaf3aadc12af802fa78d73417d8721078f399bed",
    ),
    "Ultimate Mortal Kombat 3.nvm": (
        0x107E, 0x1162, 0xFA,
        "b5cdbfd4f3fe00e8c0fd0abe96656f7e8156d163845abc6e71546204b07e681f",
    ),
    "WWF WrestleMania (rev 1.30 08-10-95).nvm": (
        0x08E6, 0x09BA, 0xD4,
        "c7d70efbd8c666a8ab782d96b1bdc4f48597069fe25795e38f0abf004e3ae3a4",
    ),
}

# WWF maintains an additional adjustment-integrity byte.  This exact change
# was produced by the game's own volume-control path and is required for the
# full-volume adjustment block to survive the next boot.
EXTRA_FULL_BYTES = {
    "WWF WrestleMania (rev 1.30 08-10-95).nvm": ((0x09FC, 0x9D, 0xFB),),
}

FULL_HASHES = {
    "Mortal Kombat 3 (rev 2.1).nvm":
        "945a45d256c8cf73b0d27423ef720df738a29086562ffa260577131e4c5e4d3a",
    "NBA Hangtime (L1.3).nvm":
        "893fcf47b37958f6fffff5138c50f9e10f20b92f97fdf511d7a0d67ede0cf21d",
    "NBA Maximum Hangtime (L1.03 06-09-97).nvm":
        "f498e5bb6edfcb26136ead1411ee9c50ec7856611220cffdc943aca59456b197",
    "NHL Open Ice - 2 on 2 Challenge (rev 1.21).nvm":
        "b881bb0390e96932750b063acccf8028b73f567ae7e8e33473bd55c097823aa9",
    "Rampage World Tour.nvm":
        "6f13bce1d282a1ba5a35fbbdbd5e4553eb8fde4ea3c9415912bf09a40d99bd98",
    "Ultimate Mortal Kombat 3.nvm":
        "6d761a3e3d0d5810e2d20d11d7187d68e4664f4ef8e919dd56dce675c80dfc85",
    "WWF WrestleMania (rev 1.30 08-10-95).nvm":
        "af99f70cb1f5b3b2c5fa546884a6c52b7a6bc4fef47c4a3e7d1598ef823bd99d",
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def check_u16_packing(data: bytes, name: str) -> None:
    if len(data) != NVRAM_BYTES:
        raise ValueError(f"{name}: size {len(data)} != {NVRAM_BYTES}")
    nonzero_high = [offset for offset in range(1, len(data), 2) if data[offset]]
    if nonzero_high:
        raise ValueError(
            f"{name}: non-zero high lane at 0x{nonzero_high[0]:04X}"
        )


def process(directory: Path, apply: bool) -> None:
    actual_names = {path.name for path in directory.glob("*.nvm")}
    expected_names = set(SEEDS)
    if actual_names != expected_names:
        missing = sorted(expected_names - actual_names)
        extra = sorted(actual_names - expected_names)
        raise ValueError(f"seed set mismatch: missing={missing}, extra={extra}")

    for name, (volume_offset, checksum_offset, old_checksum, old_hash) in SEEDS.items():
        path = directory / name
        original = path.read_bytes()
        check_u16_packing(original, name)
        data = bytearray(original)
        full_checksum = (old_checksum - (FULL_VOLUME - OLD_VOLUME)) & 0xFF
        extra_bytes = EXTRA_FULL_BYTES.get(name, ())

        if apply:
            if sha256(original) == old_hash:
                if data[volume_offset] != OLD_VOLUME:
                    raise ValueError(
                        f"{name}: expected old volume 0x{OLD_VOLUME:02X}, "
                        f"got 0x{data[volume_offset]:02X}"
                    )
                if data[checksum_offset] != old_checksum:
                    raise ValueError(
                        f"{name}: expected old checksum 0x{old_checksum:02X}, "
                        f"got 0x{data[checksum_offset]:02X}"
                    )
                data[volume_offset] = FULL_VOLUME
                data[checksum_offset] = full_checksum
            elif not (
                data[volume_offset] == FULL_VOLUME
                and data[checksum_offset] == full_checksum
            ):
                raise ValueError(
                    f"{name}: source hash is not the audited 80% seed and "
                    "the full-volume record is invalid"
                )
            for offset, old_value, full_value in extra_bytes:
                if data[offset] == old_value:
                    data[offset] = full_value
                elif data[offset] != full_value:
                    raise ValueError(
                        f"{name}: integrity byte 0x{offset:04X} is "
                        f"0x{data[offset]:02X}, expected "
                        f"0x{old_value:02X} or 0x{full_value:02X}"
                    )
            path.write_bytes(data)

        if data[volume_offset] != FULL_VOLUME:
            raise ValueError(
                f"{name}: volume is 0x{data[volume_offset]:02X}, expected 0xFF"
            )
        if data[checksum_offset] != full_checksum:
            raise ValueError(
                f"{name}: adjustment checksum byte is "
                f"0x{data[checksum_offset]:02X}, expected 0x{full_checksum:02X}"
            )
        for offset, _, full_value in extra_bytes:
            if data[offset] != full_value:
                raise ValueError(
                    f"{name}: integrity byte 0x{offset:04X} is "
                    f"0x{data[offset]:02X}, expected 0x{full_value:02X}"
                )
        actual_hash = sha256(data)
        if actual_hash != FULL_HASHES[name]:
            raise ValueError(
                f"{name}: unexpected full-volume image hash {actual_hash}"
            )
        print(
            f"PASS {name}: volume=0xFF checksum=0x{full_checksum:02X} "
            f"sha256={actual_hash}"
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--directory",
        type=Path,
        default=Path(__file__).resolve().parents[1]
        / "releases"
        / "WolfUnit-Master"
        / "nvram",
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        help="convert the exact audited 80%% seeds to checksum-valid 100%% seeds",
    )
    args = parser.parse_args()
    process(args.directory, args.apply)


if __name__ == "__main__":
    main()
