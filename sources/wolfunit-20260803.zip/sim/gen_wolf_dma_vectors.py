#!/usr/bin/env python3
"""
gen_wolf_dma_vectors.py -- authors sim/wolf_dma_vectors.json, the cross-
validation vector matrix for the Wolf-unit DMA blitter (UMK3).

The JSON follows the PINNED SHARED CONTRACT:
  [{"name": "<snake_case>", "writes": [[offset, value], ...]}, ...]
  offset = CPU-visible dma_w register offset 0..15 (decimal), value = 16-bit
  write data (decimal), applied strictly in order, mem_mask always 0xffff,
  all 18 internal registers reset to 0 at the start of every case.

COMMAND word layout (midtunit_v.cpp doc :656-693 + decode):
  bit15 trigger (:713-716) | bpp[14:12] (:722, 0=8bpp per .ipp:12) |
  postskip[11:10] (:735) | preskip[9:8] (:734) | skip bit7 (:813/:822) |
  lrsplit bit6 (:787) | yflip bit5 (:733) | xflip bit4 (dispatch group
  (command&0x1f)*8+bpp, .ipp:40-47/66-81) | mode[3:0] (Zero/NonZero pair,
  .ipp:49-65).

Clip discipline: registers reset to 0 per case, and an untouched botclip=0
Y-clips everything except sy==0 (:480) while leftclip=rightclip=0 X-clips
everything except sx==0 (:506) -- faithful. Therefore EVERY case deliberately
writes the clip registers (permissive unless the case tests clipping):
  CONFIG=0x0020 (bank1, :702) -> offsets 12/13 = TOP/BOTCLIP (:700)
  CONFIG=0x0000 (bank0)       -> offsets 12/13 = LEFT/RIGHTCLIP (:699)

gfx stub landmarks (gfx[i] = (i*7+3)&0xff, contract):
  gfx[0x22]=0xF1 (byte with F high nibble? no: 0xF1 -> pre=1, post=0xF)
  gfx[34]=0xF1 -> at bit offset 34*8=0x110, post nibble = 0xF (max postskip)
  gfx[219]=0x00 -> zero byte (zero pixels for 8bpp) at bit offset 0x6D8
  gfx[128]=0x83 -> generic nonzero at bit offset 0x400
"""

import json
import os
import sys

XF = 0x10
YF = 0x20
LRSPLIT = 0x40
SKIP = 0x80


def cmd(mode, bpp=0, xflip=0, yflip=0, skip=0, lrsplit=0, preskip=0,
        postskip=0, go=1):
    assert bpp in (0, 1, 2, 3, 4, 5, 6, 7)
    c = (go << 15) | ((bpp & 7) << 12) | ((postskip & 3) << 10) | \
        ((preskip & 3) << 8) | (SKIP if skip else 0) | \
        (LRSPLIT if lrsplit else 0) | (YF if yflip else 0) | \
        (XF if xflip else 0) | (mode & 0xf)
    return c


def clip_writes(top=0, bot=0x1FF, left=0, right=0x3FF):
    """Deliberate clip setup via both register banks (:697-702)."""
    return [
        [15, 0x0020],   # CONFIG bit5=1 -> bank 1: offsets 12/13 = TOP/BOT
        [12, top],
        [13, bot],
        [15, 0x0000],   # bank 0: offsets 12/13 = LEFT/RIGHTCLIP (pseudo 16/17)
        [12, left],
        [13, right],
    ]


def case(name, mode=3, bpp=0, xflip=0, yflip=0, skip=0, lrsplit=0,
         preskip=0, postskip=0, x=20, y=10, w=8, h=2,
         offlo=0x0400, offhi=0x0000, pal=0x2100, col=0x55, lrskip=0,
         scalex=0, scaley=0, top=0, bot=0x1FF, left=0, right=0x3FF,
         clips=True):
    writes = []
    if clips:
        writes += clip_writes(top, bot, left, right)
    writes += [
        [2, offlo], [3, offhi],
        [4, x], [5, y], [6, w], [7, h],
        [8, pal], [9, col],
        [0, lrskip],
        [10, scalex], [11, scaley],
        [1, cmd(mode, bpp, xflip, yflip, skip, lrsplit, preskip, postskip)],
    ]
    return {"name": name, "writes": writes}


def main():
    cases = []

    # =====================================================================
    # A. All 16 pixel modes x {noflip, xflip}, bpp=1 (plenty of both zero
    #    and nonzero pixels), noscale. Mode 0 / 0x10 = dma_draw_none
    #    (.ipp:50/66) -> empty stream but blit must complete.
    # =====================================================================
    for mode in range(16):
        for xflip in (0, 1):
            cases.append(case(
                "mode%X_%s_bpp1" % (mode, "xf" if xflip else "nf"),
                mode=mode, bpp=1, xflip=xflip,
                x=20, y=10, w=12, h=2, offlo=0x0400, pal=0x2100, col=0x55))

    # =====================================================================
    # B. bpp sweep (1,2,4,6,0=8) with an ODD bit offset (o&7 != 0 exercises
    #    the EXTRACTGEN 2-byte window shift, :427). mode 3 = P0P1 copy.
    # =====================================================================
    for bpp in (1, 2, 4, 6, 0):
        cases.append(case(
            "bpp%d_copy_oddoff" % bpp, mode=3, bpp=bpp,
            x=40, y=20, w=9, h=2, offlo=0x0321, pal=0x0A00, col=0x11))
    # zero-byte source region (gfx[219]=0x00): zero pixels at 8bpp, mode 2
    # (P1: zero pixels NOT written, :522/:530 with NonZero=COPY, Zero=SKIP)
    cases.append(case("bpp8_zerosrc_mode2", mode=2, bpp=0,
                      x=8, y=4, w=6, h=1, offlo=219 * 8, pal=0x0300))

    # =====================================================================
    # C. Scale variants (:811 Scale iff xstep!=0x100 || ystep!=0x100;
    #    :736-737 reg==0 -> 0x100). Writing reg=0 on one axis while the
    #    other scales tests the 0->0x100 default INSIDE a scale blit.
    # =====================================================================
    sc = [
        ("zoom_x",       0x080, 0x000),
        ("shrink_x",     0x180, 0x000),
        ("zoom_y",       0x000, 0x080),
        ("shrink_y",     0x000, 0x180),
        ("zoom_both",    0x080, 0x080),
        ("shrink_both",  0x180, 0x180),
        ("zoom_x4",      0x040, 0x100),
        ("huge_xstep",   0x2000, 0x100),   # :736 UNMASKED (13-bit doc :684 ignored)
        ("huge_ystep",   0x100, 0x2000),
    ]
    for nm, sx_, sy_ in sc:
        cases.append(case("scale_%s" % nm, mode=3, bpp=4,
                          x=30, y=15, w=8, h=4, offlo=0x0400,
                          scalex=sx_, scaley=sy_, pal=0x1500, col=0x22))
    cases.append(case("scale_zoomx_xflip", mode=3, bpp=4, xflip=1,
                      x=30, y=15, w=8, h=4, scalex=0x080, scaley=0x100,
                      pal=0x1500))
    cases.append(case("scale_shrinkx_xflip", mode=3, bpp=4, xflip=1,
                      x=30, y=15, w=8, h=4, scalex=0x180, scaley=0x100,
                      pal=0x1500))
    cases.append(case("scale_shrinky_yflip", mode=3, bpp=4, yflip=1,
                      x=30, y=15, w=8, h=4, scalex=0x100, scaley=0x180,
                      pal=0x1500))
    # mode 8 (C1) under scale: nonzero -> color, zero -> skip
    cases.append(case("scale_mode8_zoom", mode=8, bpp=1,
                      x=30, y=15, w=10, h=3, scalex=0x080, scaley=0x080,
                      pal=0x0800, col=0x77))

    # =====================================================================
    # D. Skip on, NOSCALE: preskip/postskip field variants (:465/:474 shift
    #    amounts) + flips + lrsplit interaction. Source at byte 2
    #    (gfx[2]=0x11: pre nibble 1, post nibble 1 -> rows always draw).
    #    Subsequent rows read other bytes (nibbles up to 15); widths are
    #    sized so even 15<<(3+8) pre+post cannot wipe a row (>=241 px):
    #    matrix rule -- w > 2*15*2^max(preskip,postskip) keeps rows live.
    # =====================================================================
    for p in range(4):
        cases.append(case("skip_pre%d_post%d" % (p, p), mode=3, bpp=4,
                          skip=1, preskip=p, postskip=p,
                          x=100, y=50, w=260, h=3, offlo=0x0010, pal=0x0400))
    cases.append(case("skip_pre0_post3", mode=3, bpp=4,
                      skip=1, preskip=0, postskip=3,
                      x=100, y=50, w=260, h=3, offlo=0x0010, pal=0x0400))
    cases.append(case("skip_pre3_post0", mode=3, bpp=4,
                      skip=1, preskip=3, postskip=0,
                      x=100, y=50, w=260, h=3, offlo=0x0010, pal=0x0400))
    cases.append(case("skip_xflip", mode=3, bpp=4, skip=1, xflip=1,
                      preskip=0, postskip=0,
                      x=100, y=50, w=40, h=3, offlo=0x0010, pal=0x0400))
    cases.append(case("skip_yflip", mode=3, bpp=4, skip=1, yflip=1,
                      preskip=1, postskip=1,
                      x=100, y=50, w=70, h=3, offlo=0x0010, pal=0x0400))
    # postskip drives the local row width NEGATIVE (:475; gfx[34]=0xF1 post
    # nibble F, postskip=3 -> post=15<<11=30720 > 24<<8): 0-pixel rows, and
    # the noscale+skip row advance width goes negative too (:575-576).
    cases.append(case("skip_negwidth", mode=3, bpp=4, skip=1,
                      preskip=0, postskip=3,
                      x=100, y=50, w=24, h=2, offlo=34 * 8, pal=0x0400))
    # negative-width row FOLLOWED by a drawing row: gfx[36]=0xFF wipes row 0
    # (pre=post=15 px > w=12) but the :574 'offset += 8' (and NO :576 advance,
    # width<0) lands row 1 on gfx[37]=0x06 (pre 6, post 0) -> 6 px drawn.
    # Verifies the negative-width row's offset bookkeeping is observable.
    cases.append(case("skip_negwidth_recover", mode=3, bpp=4, skip=1,
                      preskip=0, postskip=0,
                      x=100, y=50, w=12, h=2, offlo=36 * 8, pal=0x0400))
    # skip + lrsplit (startskip/endskip from split byte halves :789-790)
    cases.append(case("skip_lrsplit", mode=3, bpp=4, skip=1, lrsplit=1,
                      preskip=1, postskip=0, lrskip=0x0203,
                      x=100, y=50, w=40, h=3, offlo=0x0010, pal=0x0400))
    # skip + full-word endskip (:794-795); also exercises the :492 clamp
    # reading m_dma_state.endskip (NOT the post-adjusted local from :476)
    cases.append(case("skip_lrfull", mode=3, bpp=4, skip=1, lrskip=5,
                      x=100, y=50, w=40, h=3, offlo=0x0010, pal=0x0400))

    # =====================================================================
    # E. Skip + Scale: the multi-row source skip-ahead (:592-607) with BOTH
    #    preskip shift forms in play (row head '<<(preskip+8)' :465 vs
    #    skip-ahead '<<preskip' :601 -- gospel inconsistency, transcribed
    #    exactly on both sides).
    # =====================================================================
    cases.append(case("skipscale_ty1", mode=3, bpp=4, skip=1,
                      preskip=1, postskip=1,
                      x=60, y=30, w=64, h=6, offlo=0x0010,
                      scalex=0x100, scaley=0x200, pal=0x0900))
    cases.append(case("skipscale_ty3", mode=3, bpp=4, skip=1,
                      preskip=1, postskip=0,
                      x=60, y=30, w=64, h=8, offlo=0x0010,
                      scalex=0x100, scaley=0x300, pal=0x0900))
    # y upscale: ystep < 0x100 -> ty==0 rows re-blit the SAME source row
    # (:592 'else if (ty--)' non-advance)
    cases.append(case("skipscale_yzoom_repeat", mode=3, bpp=4, skip=1,
                      preskip=0, postskip=0,
                      x=60, y=30, w=24, h=2, offlo=0x0010,
                      scalex=0x100, scaley=0x080, pal=0x0900))
    cases.append(case("skipscale_xzoom", mode=3, bpp=4, skip=1,
                      preskip=1, postskip=0,
                      x=60, y=30, w=40, h=3, offlo=0x0010,
                      scalex=0x080, scaley=0x100, pal=0x0900))
    cases.append(case("skipscale_xshrink", mode=3, bpp=4, skip=1,
                      preskip=0, postskip=1,
                      x=60, y=30, w=40, h=3, offlo=0x0010,
                      scalex=0x180, scaley=0x100, pal=0x0900))
    cases.append(case("skipscale_both", mode=3, bpp=4, skip=1,
                      preskip=1, postskip=1,
                      x=60, y=30, w=64, h=6, offlo=0x0010,
                      scalex=0x180, scaley=0x280, pal=0x0900))
    cases.append(case("skipscale_hugestep", mode=3, bpp=4, skip=1,
                      preskip=3, postskip=3,
                      x=60, y=30, w=300, h=4, offlo=0x0010,
                      scalex=0x100, scaley=0x2000, pal=0x0900))

    # =====================================================================
    # F. LRSKIP both interpretations WITHOUT the Skip bit (startskip :484-489
    #    and endskip clamp :491-493 apply to every path).
    # =====================================================================
    cases.append(case("lr_split_s3_e2", mode=3, bpp=4, lrsplit=1,
                      lrskip=0x0203, x=200, y=100, w=10, h=2, offlo=0x0400,
                      pal=0x0C00))
    cases.append(case("lr_full_e4", mode=3, bpp=4, lrsplit=0,
                      lrskip=4, x=200, y=100, w=10, h=2, offlo=0x0400,
                      pal=0x0C00))
    # endskip > width: :492-493 clamps the row width NEGATIVE -> 0 pixels
    cases.append(case("lr_full_bigend", mode=3, bpp=4, lrsplit=0,
                      lrskip=0x0200, x=200, y=100, w=8, h=2, offlo=0x0400,
                      pal=0x0C00))
    # startskip beyond width: ix jumps past width -> 0 pixels (:484-489)
    cases.append(case("lr_split_bigstart", mode=3, bpp=4, lrsplit=1,
                      lrskip=0x00FF, x=200, y=100, w=8, h=2, offlo=0x0400,
                      pal=0x0C00))
    # startskip under X-zoom: :486 tx=((startskip-ix)/xstep)*xstep rounding
    cases.append(case("lr_split_scale", mode=3, bpp=4, lrsplit=1,
                      lrskip=0x0102, x=200, y=100, w=10, h=2, offlo=0x0400,
                      scalex=0x080, scaley=0x100, pal=0x0C00))
    # startskip + xflip (sx runs DOWN from xpos while ix jumps :467-470)
    cases.append(case("lr_split_xflip", mode=3, bpp=4, lrsplit=1, xflip=1,
                      lrskip=0x0002, x=200, y=100, w=10, h=2, offlo=0x0400,
                      pal=0x0C00))

    # =====================================================================
    # G. Clip configurations.
    # =====================================================================
    cases.append(case("clip_tight_1px", mode=0xC, x=50, y=25, w=6, h=4,
                      top=26, bot=26, left=52, right=52, pal=0x1000,
                      col=0x99))
    # left > right: every pixel X-clipped (:506 can never pass)
    cases.append(case("clip_x_all", mode=0xC, x=50, y=25, w=6, h=3,
                      left=5, right=4, pal=0x1000, col=0x99))
    cases.append(case("clip_top2rows", mode=0xC, x=50, y=25, w=4, h=5,
                      top=27, bot=0x1FF, pal=0x1000, col=0x99))
    cases.append(case("clip_bot", mode=0xC, x=50, y=25, w=4, h=5,
                      top=0, bot=26, pal=0x1000, col=0x99))
    # NO clip writes at all: regs reset to 0 -> top=bot=0, left=right=0;
    # only the (sy==0, sx==0) pixel survives. Faithful reset semantics.
    cases.append(case("clip_default_zero", mode=0xC, x=0, y=0, w=3, h=2,
                      pal=0x1000, col=0x99, clips=False))
    # Y-clip under Skip: clipped rows still consume their skip byte and
    # advance offset by the skip-adjusted width (:459-477 before :480)
    cases.append(case("clip_top_skip", mode=3, bpp=4, skip=1,
                      x=50, y=25, w=40, h=4, offlo=0x0010,
                      top=27, bot=0x1FF, pal=0x1000))
    # Cab-observed class: large moving pieces can begin outside the visible
    # clip window. The blitter must still walk every clipped pixel/row so the
    # visible remainder keeps the correct source alignment when it enters.
    cases.append(case("clip_left_wrap_skip_visible", mode=3, bpp=4, skip=1,
                      preskip=0, postskip=0,
                      x=0x3F0, y=40, w=64, h=3, offlo=0x0010,
                      left=0, right=399, pal=0x1200))
    cases.append(case("clip_left_wrap_xflip_visible", mode=3, bpp=4, xflip=1,
                      x=15, y=44, w=48, h=2, offlo=0x0400,
                      left=0, right=399, pal=0x1300))
    cases.append(case("clip_top_wrap_skipscale_visible", mode=3, bpp=4, skip=1,
                      preskip=1, postskip=0,
                      x=80, y=0x1F8, w=48, h=16, offlo=0x0010,
                      scalex=0x100, scaley=0x180,
                      top=0, bot=253, pal=0x1400))

    # =====================================================================
    # H. Position wraps (sx &0x3ff :543-545, sy &0x1ff :565-567; addresses
    #    printed UNMASKED as sy*512+sx per the contract / :499).
    # =====================================================================
    cases.append(case("wrap_x_right", mode=0xC, x=0x3FC, y=8, w=8, h=2,
                      pal=0x1100, col=0x44))
    cases.append(case("wrap_x_xflip", mode=0xC, xflip=1, x=2, y=8, w=6, h=2,
                      pal=0x1100, col=0x44))
    cases.append(case("wrap_y_down", mode=0xC, x=16, y=0x1FE, w=3, h=4,
                      pal=0x1100, col=0x44))
    cases.append(case("wrap_y_yflip_at0", mode=0xC, yflip=1, x=16, y=1,
                      w=3, h=4, pal=0x1100, col=0x44))
    cases.append(case("wrap_y_scale", mode=0xC, x=16, y=0x1FE, w=3, h=6,
                      scalex=0x100, scaley=0x200, pal=0x1100, col=0x44))
    cases.append(case("wrap_xpos_reg_mask", mode=0xC, x=0x7FF, y=8, w=4, h=1,
                      pal=0x1100, col=0x44))  # XSTART & 0x3ff = 0x3FF (:725)

    # =====================================================================
    # I. Register-bank steering (:697-702) beyond the standard prologue.
    # =====================================================================
    # Re-steer mid-case: write TOPCLIP via bank1, then REwrite it after
    # flipping CONFIG back and forth; last write wins.
    cases.append({"name": "bank_resteer_mid", "writes": [
        [15, 0x0020], [12, 0x0000], [13, 0x01FF],   # bank1: top=0 bot=511
        [15, 0x0000], [12, 0x0000], [13, 0x03FF],   # bank0: left/right
        [15, 0x0020], [12, 26],                     # bank1 again: top=26
        [15, 0x0000],
        [2, 0x0400], [3, 0], [4, 50], [5, 25], [6, 4], [7, 4],
        [8, 0x1000], [9, 0x66], [1, cmd(0xC)],
    ]})
    # bank0 only: offsets 12/13 hit LEFT/RIGHTCLIP; top/bot stay 0 ->
    # only the sy==0 row draws.
    cases.append({"name": "bank0_only_toprow", "writes": [
        [12, 0x0000], [13, 0x03FF],                 # CONFIG=0 (reset) = bank0
        [2, 0x0400], [3, 0], [4, 10], [5, 0], [6, 5], [7, 3],
        [8, 0x1000], [9, 0x66], [1, cmd(0xC)],
    ]})
    # bank1 only: offsets 12/13 hit TOP/BOTCLIP; left/right stay 0 ->
    # only the sx==0 column draws (xpos wraps through 0).
    cases.append({"name": "bank1_only_col0", "writes": [
        [15, 0x0020], [12, 0x0000], [13, 0x01FF],
        [2, 0x0400], [3, 0], [4, 0x3FE], [5, 6], [6, 5], [7, 2],
        [8, 0x1000], [9, 0x66], [1, cmd(0xC)],
    ]})
    # CONFIG written with all bits except bit5: still bank0
    cases.append({"name": "bank_config_otherbits", "writes": [
        [15, 0x0020], [12, 0x0000], [13, 0x01FF],
        [15, 0xFFDF],                                # bit5=0 -> bank0
        [12, 0x0000], [13, 0x03FF],
        [2, 0x0400], [3, 0], [4, 12], [5, 7], [6, 4], [7, 2],
        [8, 0x1000], [9, 0x66], [1, cmd(0xC)],
    ]})

    # =====================================================================
    # J. Width/height edges.
    # =====================================================================
    cases.append(case("edge_w0", mode=3, bpp=4, x=10, y=5, w=0, h=3,
                      offlo=0x0400, pal=0x0200))
    cases.append(case("edge_h0", mode=3, bpp=4, x=10, y=5, w=5, h=0,
                      offlo=0x0400, pal=0x0200))
    cases.append(case("edge_w1h1", mode=3, bpp=4, x=10, y=5, w=1, h=1,
                      offlo=0x0400, pal=0x0200))
    cases.append(case("edge_w1h1_zoom", mode=3, bpp=4, x=10, y=5, w=1, h=1,
                      offlo=0x0400, scalex=0x080, scaley=0x080, pal=0x0200))
    cases.append(case("edge_wmax_row", mode=0xC, x=0, y=5, w=0x3FF, h=1,
                      pal=0x0200, col=0x3C))
    # register masks: WIDTH/HEIGHT & 0x3ff (:727-728), X/YSTART masks (:725-726)
    cases.append(case("edge_regmasks", mode=0xC, x=0x405, y=0x203, w=0x403,
                      h=0x402, pal=0x0200, col=0x3C))

    # =====================================================================
    # K. gfxoffset normalization (:745-763).
    # =====================================================================
    # mode C ignores the source offset entirely (:749-750) even if the raw
    # offset would be out of range
    cases.append(case("off_modeC_garbage", mode=0xC, x=7, y=3, w=4, h=2,
                      offlo=0xFFFF, offhi=0x7FFF, pal=0x1F00, col=0xAB))
    # mode D does NOT get the mode-C zeroing -> 0x10000000 -> skipdma (:757-762):
    # empty stream, blit still completes
    cases.append(case("off_modeD_skipdma", mode=0xD, x=7, y=3, w=4, h=2,
                      offlo=0x0000, offhi=0x1000, pal=0x1F00, col=0xAB))
    cases.append(case("off_skipdma_mode3", mode=3, bpp=4, x=7, y=3, w=4, h=2,
                      offlo=0x5678, offhi=0x1234, pal=0x1F00))
    # 0xF8000000 fixup (:755-756): 0xF8000000+0x100 -> offset 0x100
    cases.append(case("off_f8_fixup", mode=3, bpp=0, x=10, y=7, w=3, h=1,
                      offlo=0x0100, offhi=0xF800, pal=0x1200))
    # in-range offset far beyond the 64KB stub: OOB bytes read 0x00 ->
    # mode 3 zero pixels write pal (:536 via :513-514 same-op path | pal)
    cases.append(case("off_oob_zeros", mode=3, bpp=0, x=10, y=7, w=4, h=1,
                      offlo=0xFFFF, offhi=0x0FFF, pal=0x1200))
    # boundary: last in-stub byte then cross into OOB
    cases.append(case("off_stub_boundary", mode=3, bpp=0, x=10, y=7, w=4,
                      h=1, offlo=(65534 * 8) & 0xFFFF,
                      offhi=(65534 * 8) >> 16, pal=0x1200))

    # =====================================================================
    # L. Data-path masks + multi-blit register persistence.
    # =====================================================================
    cases.append(case("pal_color_masks", mode=0xC, x=5, y=3, w=4, h=2,
                      pal=0xFFFF, col=0x1FF))     # :729 &0x7f00, :730 &0xff
    cases.append(case("copy_pal_or", mode=3, bpp=0, x=5, y=3, w=4, h=1,
                      offlo=0x0400, pal=0x0100, col=0))  # :514 pixel|pal OR
    # two blits in one case: second rewrites ONLY XSTART + COMMAND; all other
    # registers persist (contract resets per CASE, not per blit)
    two = case("two_blits_persist", mode=0xC, x=5, y=3, w=4, h=2,
               pal=0x1000, col=0x21)
    two["writes"] += [[4, 300], [1, cmd(0xC)]]
    cases.append(two)
    # COMMAND write without bit15: no blit (:716-717); then with bit15
    nb = case("cmd_no_bit15_then_go", mode=0xC, x=5, y=3, w=4, h=1,
              pal=0x1000, col=0x21)
    nb["writes"].insert(len(nb["writes"]) - 1, [1, cmd(0xC, go=0)])
    cases.append(nb)
    # yflip + noscale + skip together (row advance :564-576 under yflip)
    cases.append(case("yflip_skip_copy", mode=3, bpp=4, skip=1, yflip=1,
                      preskip=2, postskip=2, x=80, y=40, w=130, h=3,
                      offlo=0x0010, pal=0x0700))
    # 6bpp shifted window: bit offset with o&7=5 exercising the 2-byte join
    cases.append(case("bpp6_bitshift5", mode=3, bpp=6, x=80, y=40, w=7, h=2,
                      offlo=0x0405, pal=0x0700))

    # --- Open Ice RINK regime -------------------------------------------
    # MEASURED from MAME 0.287 (sim/build/openice_rink_lrskip.txt):
    #   cmd=0x8023, WIDTH=860, HEIGHT=192, LRSKIP=0x01CC(460), unscaled.
    # bpp field = (0x8023>>12)&7 = 0 => 8 bpp (midtunit_v.cpp:665). The rink is
    # the ONLY 8-bpp blit in Open Ice -- every sprite is 4-bpp -- so it is the
    # sole exerciser of the bpp==8 fast source prefetch (wolf_dma.sv:1087) and
    # of src_stream (:847). Before these cases the matrix had ONE 8-bpp case, a
    # 6x1 blit with lrskip=0, which touches neither the wide-run prefetch nor
    # the endskip clamp. cmd bit6=0 => startskip=0, endskip=FULL LRSKIP
    # (:794-795), so we_lim = 860-460 = +400 visible.
    cases.append(case("rink_8bpp_endskip460_w860_h8", mode=3, bpp=0,
                      x=8, y=4, w=860, h=8, lrskip=460,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rink_8bpp_endskip460_w860_h192", mode=3, bpp=0,
                      x=8, y=4, w=860, h=192, lrskip=460,
                      offlo=0x0010, pal=0x0700))
    # Controls that isolate WHICH ingredient matters if the rink case diverges.
    cases.append(case("rink_ctl_8bpp_noendskip_w860_h8", mode=3, bpp=0,
                      x=8, y=4, w=860, h=8, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rink_ctl_8bpp_w400_h8", mode=3, bpp=0,
                      x=8, y=4, w=400, h=8, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    # Same geometry at 4 bpp: if THIS passes while the 8-bpp one fails, the
    # defect is bpp-gated (i.e. rink-only) rather than geometry-related.
    cases.append(case("rink_ctl_4bpp_endskip460_w860_h8", mode=3, bpp=4,
                      x=8, y=4, w=860, h=8, lrskip=460,
                      offlo=0x0010, pal=0x0700))
    # Bit-offset shifted 8-bpp run: o&7 != 0 forces the 2-byte join on every
    # pixel, which is the prefetch's straddle branch (:1085).
    cases.append(case("rink_ctl_8bpp_bitshift5_w860_h4", mode=3, bpp=0,
                      x=8, y=4, w=860, h=4, lrskip=460,
                      offlo=0x0015, pal=0x0700))

    # --- REGIMES DERIVED FROM THE ROMS THEMSELVES (2026-07-27) ------------
    # sim/run_wolf_dma_regime.sh tapped all SEVEN Wolf titles in MAME and
    # histogrammed every blit by (bpp, mode, skip, lrsplit, yflip, scaled,
    # endskip). Result: 87 distinct regimes in use, of which the 119
    # hand-authored cases covered SIX. 91.8% of all real blits (5,162,004 of
    # 5,625,294) sat in regimes the cross-diff had NEVER exercised -- the
    # matrix and the ROMs occupied almost disjoint spaces. The black ice bug
    # was one visible symptom of that, not an unlucky one-off gap.
    # Extents come from the WIDEST blit measured in each (bpp, endskip)
    # class: the ice defect needed w=860 AND endskip!=0 TOGETHER, so a narrow
    # case in the right regime would still have missed it.
    # Regenerate: bash sim/run_wolf_dma_regime.sh && python sim/gen_regime_cases.py
    cases.append(case("rom_b4_m02_s0_l0_y0_c0_e0", mode=2, bpp=4, skip=0, lrsplit=0,
                      yflip=0, x=8, y=4, w=402, h=6, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b6_m02_s0_l0_y0_c0_e0", mode=2, bpp=6, skip=0, lrsplit=0,
                      yflip=0, x=8, y=4, w=400, h=2, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b5_m02_s0_l0_y0_c0_e0", mode=2, bpp=5, skip=0, lrsplit=0,
                      yflip=0, x=8, y=4, w=400, h=6, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b2_m02_s0_l0_y0_c0_e0", mode=2, bpp=2, skip=0, lrsplit=0,
                      yflip=0, x=8, y=4, w=236, h=6, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b4_m02_s1_l0_y0_c0_e0", mode=2, bpp=4, skip=1, lrsplit=0,
                      yflip=0, x=8, y=4, w=402, h=6, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b7_m02_s0_l0_y0_c0_e0", mode=2, bpp=7, skip=0, lrsplit=0,
                      yflip=0, x=8, y=4, w=400, h=6, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b6_m08_s1_l0_y0_c0_e0", mode=8, bpp=6, skip=1, lrsplit=0,
                      yflip=0, x=8, y=4, w=400, h=2, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b6_m18_s1_l0_y0_c0_e0", mode=24, bpp=6, skip=1, lrsplit=0,
                      yflip=0, x=8, y=4, w=400, h=2, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b8_m02_s1_l0_y0_c0_e0", mode=2, bpp=0, skip=1, lrsplit=0,
                      yflip=0, x=8, y=4, w=400, h=2, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b8_m03_s0_l0_y1_c0_e1", mode=3, bpp=0, skip=0, lrsplit=0,
                      yflip=1, x=8, y=4, w=860, h=6, lrskip=460,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b6_m02_s1_l0_y0_c0_e0", mode=2, bpp=6, skip=1, lrsplit=0,
                      yflip=0, x=8, y=4, w=400, h=2, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b6_m02_s0_l0_y0_c1_e0", mode=2, bpp=6, skip=0, lrsplit=0,
                      yflip=0, x=8, y=4, w=400, h=2, lrskip=0,
                      scalex=0x80, scaley=0x80, offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b3_m02_s0_l0_y0_c0_e0", mode=2, bpp=3, skip=0, lrsplit=0,
                      yflip=0, x=8, y=4, w=194, h=6, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b5_m12_s0_l0_y0_c0_e0", mode=18, bpp=5, skip=0, lrsplit=0,
                      yflip=0, x=8, y=4, w=400, h=6, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b5_m02_s1_l0_y0_c0_e0", mode=2, bpp=5, skip=1, lrsplit=0,
                      yflip=0, x=8, y=4, w=400, h=6, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b6_m12_s0_l0_y0_c0_e0", mode=18, bpp=6, skip=0, lrsplit=0,
                      yflip=0, x=8, y=4, w=400, h=2, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b6_m12_s1_l0_y0_c0_e0", mode=18, bpp=6, skip=1, lrsplit=0,
                      yflip=0, x=8, y=4, w=400, h=2, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b8_m02_s0_l0_y0_c0_e1", mode=2, bpp=0, skip=0, lrsplit=0,
                      yflip=0, x=8, y=4, w=860, h=6, lrskip=460,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b8_m02_s0_l1_y0_c0_e1", mode=2, bpp=0, skip=0, lrsplit=1,
                      yflip=0, x=8, y=4, w=860, h=6, lrskip=52226,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b7_m02_s0_l0_y0_c1_e0", mode=2, bpp=7, skip=0, lrsplit=0,
                      yflip=0, x=8, y=4, w=400, h=6, lrskip=0,
                      scalex=0x80, scaley=0x80, offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b7_m02_s1_l0_y0_c0_e0", mode=2, bpp=7, skip=1, lrsplit=0,
                      yflip=0, x=8, y=4, w=400, h=6, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b6_m02_s0_l0_y0_c0_e1", mode=2, bpp=6, skip=0, lrsplit=0,
                      yflip=0, x=8, y=4, w=232, h=6, lrskip=50,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b2_m0C_s0_l0_y0_c0_e0", mode=12, bpp=2, skip=0, lrsplit=0,
                      yflip=0, x=8, y=4, w=236, h=6, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b4_m12_s0_l0_y0_c0_e0", mode=18, bpp=4, skip=0, lrsplit=0,
                      yflip=0, x=8, y=4, w=402, h=6, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b6_m02_s0_l1_y0_c0_e0", mode=2, bpp=6, skip=0, lrsplit=1,
                      yflip=0, x=8, y=4, w=400, h=2, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b7_m12_s0_l0_y0_c1_e0", mode=18, bpp=7, skip=0, lrsplit=0,
                      yflip=0, x=8, y=4, w=400, h=6, lrskip=0,
                      scalex=0x80, scaley=0x80, offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b8_m12_s1_l0_y0_c0_e0", mode=18, bpp=0, skip=1, lrsplit=0,
                      yflip=0, x=8, y=4, w=400, h=2, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b8_m02_s0_l1_y0_c0_e0", mode=2, bpp=0, skip=0, lrsplit=1,
                      yflip=0, x=8, y=4, w=400, h=2, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b6_m00_s0_l0_y0_c0_e0", mode=0, bpp=6, skip=0, lrsplit=0,
                      yflip=0, x=8, y=4, w=400, h=2, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b4_m02_s0_l0_y0_c0_e1", mode=2, bpp=4, skip=0, lrsplit=0,
                      yflip=0, x=8, y=4, w=302, h=3, lrskip=67,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b8_m00_s0_l0_y0_c0_e0", mode=0, bpp=0, skip=0, lrsplit=0,
                      yflip=0, x=8, y=4, w=400, h=2, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b4_m12_s1_l0_y0_c0_e0", mode=18, bpp=4, skip=1, lrsplit=0,
                      yflip=0, x=8, y=4, w=402, h=6, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b3_m00_s0_l0_y0_c0_e0", mode=0, bpp=3, skip=0, lrsplit=0,
                      yflip=0, x=8, y=4, w=194, h=6, lrskip=0,
                      offlo=0x0010, pal=0x0700))
    cases.append(case("rom_b7_m12_s1_l0_y0_c0_e0", mode=18, bpp=7, skip=1, lrsplit=0,
                      yflip=0, x=8, y=4, w=400, h=6, lrskip=0,
                      offlo=0x0010, pal=0x0700))

    out = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       "wolf_dma_vectors.json")
    names = [c["name"] for c in cases]
    assert len(names) == len(set(names)), "duplicate case names"
    with open(out, "w", newline="\n") as f:
        json.dump(cases, f, indent=1)
        f.write("\n")
    print("%d cases -> %s" % (len(cases), out))


if __name__ == "__main__":
    sys.exit(main())
