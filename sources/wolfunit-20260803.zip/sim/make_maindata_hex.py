#!/usr/bin/env python3
# Build the UMK3 (Wolf-unit) main-CPU 34010 program-ROM $readmemh hex.
#
# MAME gospel (mame-gospel/midway/midwunit.cpp:877-879, ROM_START(umk3)):
#   ROM_REGION16_LE( 0x100000, "maincpu", 0 )   // 34010 code
#   ROM_LOAD16_BYTE( "...u54_ultimate.u54", 0x00000, 0x80000, ... )  // EVEN bytes
#   ROM_LOAD16_BYTE( "...u63_ultimate.u63", 0x00001, 0x80000, ... )  // ODD  bytes
#
# ROM_LOAD16_BYTE with even/odd start offsets interleaves the two 0x80000-byte
# EPROMs into a 0x100000-byte little-endian region: byte 2*i = u54[i] (low),
# byte 2*i+1 = u63[i] (high). Each 16-bit word i = (u63[i]<<8) | u54[i].
#
# Output = one 16-bit word per line, hex, 0x80000 words. Identical format to the
# Smash-TV maindata hex the wolf/yunit TBs load (word = (odd<<8)|even). See
# sim/tb_rom_load.sv:62-63 (u105 even -> low byte, u89 odd -> high byte).
#
# The 34010 program window 0xFF800000-0xFFFFFFFF is EXACTLY 0x80000 words (window
# bits 0x800000 / 16), matching the region size 1:1 -> NO mirror. So the whole
# region maps directly: wolf_mem ROM_PROG_OFF = 0x0, ROM_WORDS = 0x80000. The
# 34010 reset vector at bit-addr 0xFFFFFFE0 -> rom index 0x7FFFE (low)/0x7FFFF (hi).
#
# Usage:  python sim/make_maindata_hex.py <u54_path> <u63_path> <out_hex>
import sys, struct

def main():
    u54_path, u63_path, out = sys.argv[1], sys.argv[2], sys.argv[3]
    even = open(u54_path, "rb").read()   # u54 -> even bytes (low)
    odd  = open(u63_path, "rb").read()   # u63 -> odd  bytes (high)
    assert len(even) == 0x80000, f"u54 size {len(even):#x} != 0x80000"
    assert len(odd)  == 0x80000, f"u63 size {len(odd):#x} != 0x80000"
    words = len(even)   # 0x80000
    with open(out, "w", newline="\n") as f:
        for i in range(words):
            w = (odd[i] << 8) | even[i]
            f.write(f"{w:04x}\n")
    print(f"wrote {out}: {words:#x} words ({words} = 0x{words:x})")
    # echo the reset-vector words for the cross-check
    rv_lo = (odd[0x7FFFE] << 8) | even[0x7FFFE]
    rv_hi = (odd[0x7FFFF] << 8) | even[0x7FFFF]
    print(f"reset-vector words: rom[0x7FFFE]={rv_lo:04x} rom[0x7FFFF]={rv_hi:04x}"
          f" -> vector 0x{(rv_hi<<16)|rv_lo:08X}")

if __name__ == "__main__":
    main()
