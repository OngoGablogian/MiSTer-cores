#!/usr/bin/env bash
# run_ase_rwt_boot.sh — Rampage World Tour boot smoke under ModelSim ASE 17.0.
# Fork of run_ase_wolf_boot.sh (the UMK3/Hangtime-proven ASE boot smoke): real
# TMS34010 core + wolf_memsys (internal wolf_pic, 465 table) + wolf_dcs_stub,
# strict PC-diff vs the MAME 0.280 rmpgwt fresh-NVRAM golden (first 8000 PCs of
# D:/deck/fpga/rampageworldtour/gospel/rmpgwt_boot_pc.trace).
# License-free; NEVER launches Questa FSE or Quartus.
set -euo pipefail

MS=${MS:-/c/intelFPGA_lite/17.0/modelsim_ase/win32aloem}
TB="tb_wolf_rwt_boot"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"
STAGING="${RWT_STAGING:-D:/deck/fpga/rampageworldtour}"

cd "$ROOT/sim"
mkdir -p build

# ---- input prep -------------------------------------------------------------
# Program-ROM hex: u54 even / u63 odd byte lanes (midwunit.cpp:1496-1498), via
# the existing make_maindata_hex.py (sizes match UMK3's 2 x 0x80000 exactly).
if [ ! -f build/rmpgwt_maindata.hex ]; then
  python - <<EOF
import zipfile, os
z = zipfile.ZipFile(r"$STAGING/roms/rmpgwt.zip")
os.makedirs("build/rwt_roms", exist_ok=True)
for n in ["1.3_rampage_world_u54_game.u54", "1.3_rampage_world_u63_game.u63"]:
    open("build/rwt_roms/" + n, "wb").write(z.read(n))
EOF
  python make_maindata_hex.py \
    "build/rwt_roms/1.3_rampage_world_u54_game.u54" \
    "build/rwt_roms/1.3_rampage_world_u63_game.u63" \
    build/rmpgwt_maindata.hex
fi

# Golden: first 8000 PCs of the 200k-PC fresh-NVRAM boot trace (read-only
# gospel stays untouched; $readmemh needs the array-sized slice).
head -8000 "$STAGING/gospel/rmpgwt_boot_pc.trace" > build/rmpgwt_boot_pc_8000.hex

# ---- compile + run ----------------------------------------------------------
rm -rf work
"$MS/vlib.exe" work >/dev/null

SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SRC+=( "$ROOT/rtl/pkg/wolf_pkg.sv" \
       "$ROOT/rtl/wolf/ram_sdram.sv" "$ROOT/sim/sdram_model.sv" \
       "$ROOT/rtl/wolf/wolf_mem.sv" "$ROOT/rtl/wolf/wolf_dma.sv" \
       "$ROOT/rtl/wolf/wolf_pic.sv" "$ROOT/rtl/wolf/wolf_dcs_stub.sv" \
       "$ROOT/rtl/wolf/wolf_memsys.sv" \
       "$ROOT/sim/$TB.sv" )

echo "compiling ${#SRC[@]} sources ..."
"$MS/vlog.exe" -sv -quiet -svinputport=var ${EXTRA_VLOG:-} "${SRC[@]}"

LOG="$ROOT/sim/build/${TB}.ase.log"
set +e
"$MS/vsim.exe" -c -quiet -do "run -all; quit -f" "work.$TB" > "$LOG" 2>&1
set -e
grep -iE "PASS|FAIL|FRONTIER|golden|Error" "$LOG" | head -20 || true
if grep -q "^# PASS" "$LOG" && ! grep -q "FAIL" "$LOG"; then
  echo "RWT BOOT SMOKE (ASE): PASS"
else
  echo "RWT BOOT SMOKE (ASE): FAIL (see $LOG)"
  exit 1
fi
