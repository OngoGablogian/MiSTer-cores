#!/usr/bin/env python3
# Build the UMK3 (Wolf-unit) WARM-CMOS $readmemh seed hex from a MINIMAL OVERLAY
# (no external nvram .bak needed — deterministic + committable).
#
# WHY an overlay (not the full nvram.warm.bak via make_cmos_hex.py):
#   The CMOS-valid gate at FFB91A60 (MOVB *A7,A0 / ANDI FFh,A0) reads the factory-
#   signature window and takes the game path iff the signature is PRESENT. The
#   MEASURED boot-2 GATE-READ values (mame-gospel/trace/reboot_blit.txt "Read
#   stream @ gate PC FFB91A60", and boot2_warm.txt) are:
#       byteidx 0x11D = 00 -> 01   (runtime counter, 01 by the 2nd pass)
#       byteidx 0x11E = FF          (the CMOS-valid signature marker)
#       byteidx 0x11F = FF          (signature high byte)
#   The persisted nvram.warm.bak instead holds 0x11F=D7 and 0x11D=28 (battery
#   runtime state at EXIT, reboot_blit.txt), NOT the gate-read values. So the
#   minimal 3-entry overlay {0x11D=01, 0x11E=FF, 0x11F=FF} is the FAITHFUL
#   gate-read seed; the full-bak dump would seed the wrong signature bytes.
#
# PACKING (identical to make_cmos_hex.py): one 16-bit word per line, hex, 0x6000
# words, $readmemh index order (line k -> nvram[k]); CMOS word i = {8'h00, byte}
# (byte-valued MAME m_nvram entry; midwunit_m.cpp:48 cmos_r -> m_nvram[offset];
# wolf_mem.sv:416 read_word R_CMOS: nvram[gw-WB_CMOS]).
#
# Usage:  python sim/make_cmos_seed.py <out_hex>
import sys

CMOS_WORDS = 0x6000   # wolf_mem.sv CMOS_WORDS

# MEASURED boot-2 warm gate-read signature (reboot_blit.txt / boot2_warm.txt).
OVERLAY = {
    0x11D: 0x01,   # runtime counter (00 on b1, 01 on b2 gate pass)
    0x11E: 0xFF,   # CMOS-valid signature marker
    0x11F: 0xFF,   # signature high byte
}

def main():
    out = sys.argv[1]
    with open(out, "w", newline="\n") as f:
        for i in range(CMOS_WORDS):
            f.write(f"{OVERLAY.get(i, 0) & 0xff:04x}\n")
    print(f"wrote {out}: {CMOS_WORDS:#x} words (overlay entries: "
          + ", ".join(f"0x{k:03X}=0x{v:02X}" for k, v in sorted(OVERLAY.items())) + ")")

if __name__ == "__main__":
    main()
