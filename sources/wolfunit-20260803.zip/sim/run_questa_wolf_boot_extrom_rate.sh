#!/usr/bin/env bash
set -e
TB="tb_wolf_boot_extrom_rate"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"
. "$(dirname "$0")/questa_lock.sh"

find_bin() {
  local name="$1"; local env="$2"
  if [ -n "$env" ] && [ -x "$env" ]; then echo "$env"; return; fi
  for d in /c/altera/*/questa_fse/win64 /c/intelFPGA/*/questa_fse/win64; do
    [ -x "$d/$name.exe" ] && { echo "$d/$name"; return; }
  done
}
VLIB="$(find_bin vlib "$VLIB")"; VLOG="$(find_bin vlog "$VLOG")"; VSIM="$(find_bin vsim "$VSIM")"
[ -n "$VLOG" ] && [ -n "$VSIM" ] || { echo "ERROR: Questa not found"; exit 1; }
unset LM_LICENSE_FILE MGLS_LICENSE_FILE
: "${SALT_LICENSE_SERVER:=C:\\altera\\LR-175212_License.dat;C:\\altera\\LR-175213_License.dat}"
export SALT_LICENSE_SERVER
trap questa_release EXIT
questa_acquire || exit 75

cd "$ROOT/sim"
rm -rf work
"$VLIB" work >/dev/null
SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SRC+=( "$ROOT/rtl/pkg/wolf_pkg.sv"
       "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv"
       "$ROOT/rtl/wolf/ram_sdram.sv" "$ROOT/rtl/wolf/wolf_mem.sv"
       "$ROOT/rtl/wolf/wolf_dma.sv" "$ROOT/rtl/wolf/wolf_pic.sv"
       "$ROOT/rtl/wolf/wolf_memsys.sv" "$ROOT/rtl/wolf/wolf_dcs_stub.sv"
       "$ROOT/rtl/yunit/yunit_mem_cdc.sv" "$ROOT/rtl/sdram/yunit_sdram_arb.sv"
       "$ROOT/sim/sdram_model.sv" "$ROOT/sim/$TB.sv" )

DEFS="+define+USE_EXT_ROM+USE_EXT_GFX+USE_DDR3_GFX+USE_SDRAM_RAM+USE_SDRAM_VRAM+USE_HW_RAM"
"$VLOG" -sv -quiet -svinputport=var $DEFS "${SRC[@]}"
LOG="$ROOT/sim/build/${TB}.vsim.log"
mkdir -p "$ROOT/sim/build"
set +e
"$VSIM" -c -quiet -do "run -all; quit" "$TB" 2>&1 | tee "$LOG" | grep -iE "PASS|FAIL|RATE|Fatal|Error|license"
set -e
questa_check_result "$LOG" "PASS: $TB"
