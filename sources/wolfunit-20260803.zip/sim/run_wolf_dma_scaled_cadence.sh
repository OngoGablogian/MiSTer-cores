#!/usr/bin/env bash
set -euo pipefail

export PATH="/c/iverilog/bin:/usr/local/bin:/usr/bin:/bin"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TB=tb_wolf_dma_scaled_cadence
OUT="$ROOT/sim/build/$TB.vvp"
LOG="$ROOT/sim/build/$TB.log"

mkdir -p "$ROOT/sim/build"
iverilog -g2012 -s "$TB" -o "$OUT" \
  "$ROOT/rtl/pkg/wolf_pkg.sv" \
  "$ROOT/rtl/wolf/wolf_dma.sv" \
  "$ROOT/sim/$TB.sv"

cd "$ROOT"
vvp -n "$OUT" | tee "$LOG"
grep -q '^PASS wolf_dma_scaled_cadence$' "$LOG"
