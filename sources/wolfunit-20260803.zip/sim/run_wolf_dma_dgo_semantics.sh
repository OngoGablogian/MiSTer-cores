#!/bin/bash
# Compile and run the documented Wolf DMA2 DGO halt/resume/kill oracle.

set -uo pipefail
cd "$(dirname "$0")/.." || exit 1

IVERILOG=${IVERILOG:-/c/iverilog/bin/iverilog}
VVP=${VVP:-/c/iverilog/bin/vvp}

if [ ! -x "$IVERILOG" ]; then
    IVERILOG=$(command -v iverilog) || {
        echo "FATAL: iverilog not found (set IVERILOG)"
        exit 1
    }
fi
if [ ! -x "$VVP" ]; then
    VVP=$(command -v vvp) || {
        echo "FATAL: vvp not found (set VVP)"
        exit 1
    }
fi

TMP_ROOT=${TMPDIR:-/tmp}
TMP=$(mktemp -d "$TMP_ROOT/wolf_dma_dgo_semantics.XXXXXX") || exit 1
trap 'rm -rf "$TMP"' EXIT

TB="$TMP/tb_wolf_dma_dgo_semantics.vvp"
LOG="$TMP/tb_wolf_dma_dgo_semantics.log"

"$IVERILOG" -g2012 -s tb_wolf_dma_dgo_semantics -o "$TB" \
    rtl/pkg/wolf_pkg.sv \
    rtl/wolf/wolf_dma.sv \
    sim/tb_wolf_dma_dgo_semantics.sv \
  || {
      echo "FATAL: tb_wolf_dma_dgo_semantics compile failed"
      exit 1
  }

"$VVP" -n "$TB" 2>&1 | tee "$LOG"
sim_status=${PIPESTATUS[0]}

if [ "$sim_status" -ne 0 ]; then
    exit "$sim_status"
fi

grep -q '^PASS: tb_wolf_dma_dgo_semantics' "$LOG" || {
    echo "FATAL: simulation ended without the oracle PASS marker"
    exit 1
}

run_mutant() {
    name=$1
    expression=$2
    changed_text=$3
    expected_failure=$4
    mutant="$TMP/wolf_dma_${name}.sv"
    mutant_tb="$TMP/tb_wolf_dma_dgo_${name}.vvp"
    mutant_log="$TMP/tb_wolf_dma_dgo_${name}.log"

    cp rtl/wolf/wolf_dma.sv "$mutant"
    sed -i "$expression" "$mutant"
    grep -Fq "$changed_text" "$mutant" || {
        echo "FATAL: $name mutation did not apply"
        exit 1
    }
    "$IVERILOG" -g2012 -s tb_wolf_dma_dgo_semantics -o "$mutant_tb" \
        rtl/pkg/wolf_pkg.sv "$mutant" sim/tb_wolf_dma_dgo_semantics.sv || exit 1

    "$VVP" -n "$mutant_tb" >"$mutant_log" 2>&1
    mutant_status=$?
    if [ "$mutant_status" -eq 0 ] || ! grep -Fq "$expected_failure" "$mutant_log"; then
        cat "$mutant_log"
        echo "FATAL: $name mutant survived or failed for the wrong reason"
        exit 1
    fi
    echo "PASS: $name mutant killed by $expected_failure"
}

run_mutant no_pause \
    "s/paused_r       <= 1'b1;/paused_r       <= 1'b0;/" \
    "paused_r       <= 1'b0;" \
    "FAIL[halt]"

run_mutant no_kill \
    "s/wire kill_enter_w = !resume_w/wire kill_enter_w = 1'b0 \&\& !resume_w/" \
    "wire kill_enter_w = 1'b0 && !resume_w" \
    "FAIL[kill]"

run_mutant no_loaded_discard \
    "s/wire fbq_discard_w = kill_request_w;/wire fbq_discard_w = 1'b0 \&\& kill_request_w;/" \
    "wire fbq_discard_w = 1'b0 && kill_request_w;" \
    "FAIL[loaded-kill-discard]"
