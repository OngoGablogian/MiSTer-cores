#!/usr/bin/env python3
# run_wolf_dma_realblit.py -- run the proven wolf_dma_model.py against the REAL first blit
# (mame-gospel/trace/wolfblits.txt line 1, MAME-captured full 18-register state, matching
# postblit_dump.lua's independently-captured trigger: CMD=C002 W=10 H=12 OFFLO=AFE6 OFFHI=0BD9
# XPOS=346 YPOS=80) using the REAL assembled gfx ROM (sim/build/umk3_gfx.hex, 32MB, CRC-verified
# against mame-gospel/midway/midwunit.cpp ROM_START(umk3)) at the REAL (unfolded) source offset
# -- not the 64KB-stub fold gen_wolf_dma_realblits.py uses for register-shape-only testing.
#
# Compares the model's predicted framebuffer writes against MAME's own post-blit VRAM capture
# (mame-gospel/trace/nearblit/vram_postblit.hex, produced by postblit_dump.lua) for the affected
# window -- the strongest available oracle (actual MAME pixel output, not just parameter shape).
import sys, os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import wolf_dma_model as M

GFX_HEX = "sim/build/umk3_gfx.hex"
VRAM_PRE = "../mame-gospel/trace/nearblit/vram.hex"
VRAM_POST = "../mame-gospel/trace/nearblit/vram_postblit.hex"

def load_gfx_hex(path):
    with open(path) as f:
        return bytes(int(l, 16) for l in f if l.strip())

def load_vram_hex(path):
    with open(path) as f:
        return [int(l, 16) for l in f if l.strip()]

def cpu_view_pixel_byte(vram_words, row, col):
    # midtunit_vram_r (mame-gospel/midway/midtunit_v.cpp:299-305): offset*=2, then
    # (videobank=1) returns (local_videoram[2i]&0xff) | (local_videoram[2i+1]<<8) --
    # i.e. CPU word-index i packs the LOW BYTE (pixel value, not the DMA_PALETTE-derived
    # high byte) of TWO adjacent scanout pixels [2i,2i+1] into one 16-bit word. Row stride
    # in CPU-word terms is therefore 256 (512 scanout pixels / 2 per word), NOT 512.
    wi = row * 256 + (col >> 1)
    w = vram_words[wi]
    return (w & 0xff) if (col & 1) == 0 else ((w >> 8) & 0xff)

def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    gfx = load_gfx_hex(os.path.join(root, GFX_HEX))
    print(f"loaded real gfx ROM: {len(gfx)} bytes")

    # monkey-patch the model's gfx source (module globals gfx_byte() reads)
    M.GFX_SIZE = len(gfx)
    M._GFX = gfx

    # wolfblits.txt line 1 -- the real captured first blit (18 regs, r0..r17)
    r = [0x0000, 0xC002, 0xAFE6, 0x0BD9, 0x015A, 0x0050, 0x000A, 0x000C,
         0x0303, 0x0000, 0x0100, 0x0100, 0x0000, 0x00FD, 0x0000, 0x0030,
         0x0000, 0x01FF]

    # SAME bank-aware write sequence as gen_wolf_dma_realblits.py, EXCEPT r[3] (OFFSETHI)
    # is the REAL captured value, not folded to 0 -- we have the real 32MB gfx now.
    writes = [
        [15, 0x0020], [12, r[12]], [13, r[13]],
        [15, 0x0000], [12, r[16]], [13, r[17]],
        [0, r[0]],
        [2, r[2]], [3, r[3]],          # REAL offset, unfolded
        [4, r[4]], [5, r[5]], [6, r[6]], [7, r[7]],
        [8, r[8]], [9, r[9]],
        [10, r[10]], [11, r[11]],
        [14, r[14]],
        [15, r[15]],
        [1, r[1]],
    ]

    lines = M.run_case(writes)
    print(f"model predicted {len(lines)} framebuffer writes")

    X, Y, W, H = r[4], r[5], r[6], r[7]
    predicted = {}
    for line in lines:
        addr_s, data_s = line.split()
        addr = int(addr_s, 16)
        predicted[addr] = int(data_s, 16)

    vram_post = load_vram_hex(os.path.join(root, VRAM_POST))
    vram_pre = load_vram_hex(os.path.join(root, VRAM_PRE))

    # model's stream value is (pixel | pal); pal = DMA_PALETTE&0x7f00 occupies the HIGH
    # byte only, so the LOW BYTE of the stream value is the raw pixel -- exactly what the
    # CPU-facing vram_r exposes (it discards the palette-derived high byte entirely).
    print(f"\n=== window X={X} Y={Y} W={W} H={H} (comparing LOW BYTE = raw pixel) ===")
    mism = 0
    checked = 0
    for row in range(Y, Y + H):
        row_model, row_mame = [], []
        for col in range(X, X + W):
            e = row * 512 + col
            mame_byte = cpu_view_pixel_byte(vram_post, row, col)
            pre_byte = cpu_view_pixel_byte(vram_pre, row, col)
            model_val = predicted.get(e)
            model_byte = (model_val & 0xff) if model_val is not None else pre_byte
            checked += 1
            row_model.append(f"{model_byte:02x}")
            row_mame.append(f"{mame_byte:02x}")
            if model_byte != mame_byte:
                mism += 1
        marker = "" if row_model == row_mame else "  <-- MISMATCH"
        print(f"row={row}: model=[{' '.join(row_model)}] mame=[{' '.join(row_mame)}]{marker}")
    print(f"\nchecked={checked} mismatches={mism}")
    if mism == 0:
        print("RESULT: PASS -- model (real gfx ROM + real offset) bit-exact vs MAME's real captured post-blit VRAM")
    else:
        print("RESULT: FAIL -- divergence from MAME ground truth")

if __name__ == "__main__":
    main()
