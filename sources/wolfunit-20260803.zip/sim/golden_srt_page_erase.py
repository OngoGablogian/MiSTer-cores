#!/usr/bin/env python3
# -----------------------------------------------------------------------------
# golden_srt_page_erase.py -- GOLDEN model of the DIRQ page-erase via
# TMS34010 VRAM shift-register-transfer (SRT) FILL, per the interchange
# contract (flat 16-bit-word VRAM, 512 rows x 256 words).
#
# DUAL-TRANSCRIPTION DISCIPLINE: this model is derived ONLY from the MAME
# gospel sources + TI TMS34010 User's Guide extracts cited below.  It was
# written WITHOUT looking at any RTL or SystemVerilog testbench.
#
# Gospel citations (file:line refer to the repo copies under docs/mame-ref/
# and mame-gospel/):
#   [G1] 34010gfx.hxx:1797-1834   FILL core entry: SRT branch selects
#        shiftreg_w / dummy_shiftreg_r when IOREG(REG_DPYCTL) & 0x0800
#        (:1809-1813), else memory_w / memory_r (:1816-1817); linear daddr
#        = DADDR() (:1833); daddr &= ~(BITS_PER_PIXEL-1) (:1834).
#   [G2] 34010gfx.hxx:1853-1860   left/right partials + full_words math.
#   [G3] 34010gfx.hxx:1866-1955   per-row loop: dwordaddr = daddr >> 4 each
#        row (:1873); left-partial / full-word / right-partial phases, each
#        ending in (this->*word_write)(dwordaddr++ << 4, dstword)
#        (:1899, :1926, :1950); per-row advance daddr += DPTCH() (:1954).
#   [G4] 34010gfx.hxx:1971-1972   after completion (linear dst):
#        DADDR() += DYDX_Y() * DPTCH().
#   [G5] 34010gfx.hxx:223-244     shiftreg_w invokes from_shiftreg callback
#        (write DATA OPERAND IS DISCARDED, :223-230); shiftreg_r /
#        dummy_shiftreg_r return m_shiftreg[0] (:232-244); dummy_shiftreg_r
#        does NOT re-latch.
#   [G6] 34010ops.hxx:242-251     PIXT_IR: temp = RPIXEL(Rs); Rd = temp
#        (a plain pixel read into a register -- no memory write).
#   [G7] tms34010.cpp:937-947     set_pixel_function: DPYCTL & 0x0800 ->
#        pixel read/write become read/write_pixel_shiftreg; else PSIZE
#        selects (0x10 -> read_pixel_16).
#   [G8] tms34010.cpp:413-420     read_pixel_shiftreg: invokes to_shiftreg
#        callback with the pixel bit-address, returns m_shiftreg[0].
#   [G9] tms34010.cpp:401-405     read_pixel_16: 16-bit word read at
#        offset & 0xfffffff0 (used only by the --no-srt mutation).
#   [G10] midtunit_v.cpp:330-339  to_shiftreg/from_shiftreg = memcpy of
#        2*512 uint16 ENTRIES at entry index = bitaddr >> 3.  Each midtunit
#        local_videoram entry is one 8bpp pixel (+palette high byte), i.e.
#        TWO entries per flat 16-bit CPU word -> in the flat CPU-word space
#        of the contract this is 512 16-bit WORDS at word index
#        W = bitaddr >> 4.
#   [UG-p114] (ug_s06_io_registers) DPYCTL.SRT bit 11: SRT=1 converts
#        ordinary pixel accesses into VRAM serial-register-transfer cycles;
#        write cycle -> register-to-memory, read cycle -> memory-to-register.
#   [UG-p252] (ug_s11_local_memory) PSIZE should contain 16 during the SRT
#        write so the write cycle is not preceded by a read cycle.
#   [UG-p217/218] (ug_s09_screen_refresh) bulk init: latch SR with a PIXT
#        memory-to-register while SRT=1, then FILL a region "precisely 16
#        bits wide", transparency off, replace op -> each pixel write
#        generates one whole-row register-to-memory transfer.
#
# Interchange contract (fixed; both golden and TB implement exactly this):
#   flat 16-bit words, W = TMS34010 bit-address >> 4; 512 rows x 256 words
#   (512 px x 8bpp / row); page0 rows 0..255, page1 rows 256..511;
#   rows 510/511 = erase-source rows.
#
# Baseline: FAITHFUL SRT semantics.
# Mutations (each -> sim/build/srt_golden_<flag>/):
#   --no-srt     DPYCTL bit 11 ignored: PIXT = plain 16-bit read [G9], FILL
#                writes COLOR1 low word (PSIZE=16 replace) at each fill
#                address.  (Models the current FPGA core.)
#   --sr512      SRT transfers 256 words (1 row) instead of 512 (2 rows).
#   --wrong-page erase FILL DADDR page bit (bit 20 of the bit-address)
#                flipped -> erase lands on the other page.
#   --zero-fill  register-to-memory transfer writes 0x0000 words instead of
#                the latched SR content.
# -----------------------------------------------------------------------------

import argparse
import os
import sys

WORDS_PER_ROW = 256
ROWS = 512
VRAM_WORDS = ROWS * WORDS_PER_ROW          # 131072 flat 16-bit words
SR_WORDS_FULL = 512                        # [G10] 2*512 entries = 512 CPU words
PAGE_BIT = 0x00100000                      # bit-address of row 256 (word 0x10000)

# ---------------------------------------------------------------- preseed ----
def preseed_vram():
    """Contract PRESEED: nonzero everywhere; rows 510/511 distinct patterns."""
    v = [0] * VRAM_WORDS
    for r in range(510):
        base = r * WORDS_PER_ROW
        for c in range(WORDS_PER_ROW):
            v[base + c] = 0xA000 | ((r * 7 + c * 3) & 0x0FFF)
    for c in range(WORDS_PER_ROW):
        v[510 * WORDS_PER_ROW + c] = 0x0500 | (c & 0xFF)
        v[511 * WORDS_PER_ROW + c] = 0x0600 | (c & 0xFF)
    return v


def sign16(x):
    x &= 0xFFFF
    return x - 0x10000 if x & 0x8000 else x


# ------------------------------------------------------------------ model ----
class Tms34010SrtModel:
    def __init__(self, no_srt=False, sr512=False, wrong_page=False,
                 zero_fill=False):
        self.no_srt = no_srt
        self.sr512 = sr512
        self.wrong_page = wrong_page
        self.zero_fill = zero_fill
        self.vram = preseed_vram()
        self.shiftreg = [0] * SR_WORDS_FULL    # m_shiftreg, persists [G5]
        self.io = {"DPYCTL": 0x0000, "CONTROL": 0x0000, "PSIZE": 0x0008}
        self.B = {}                            # B-file: 2=DADDR 3=DPTCH 7=DYDX 9=COLOR1
        self.touched_rows = set()              # rows written by the current FILL

    # -- SRT active? [G7]: set_pixel_function keys on IOREG(REG_DPYCTL)&0x0800;
    #    [G1]:1809 the FILL core re-tests the same bit at execution time.
    def _srt_active(self):
        if self.no_srt:                        # mutation: bit 11 ignored
            return False
        return (self.io["DPYCTL"] & 0x0800) != 0

    def _sr_len(self):
        return 256 if self.sr512 else SR_WORDS_FULL   # mutation --sr512

    # -- to_shiftreg: memory -> SR latch [G8]+[G10].
    #    midtunit entry index = bitaddr>>3; flat CPU-word index = bitaddr>>4.
    def to_shiftreg(self, bitaddr):
        widx = (bitaddr >> 4) & 0xFFFFFFF
        n = self._sr_len()
        assert widx + n <= VRAM_WORDS, "SR latch out of VRAM range"
        for k in range(n):
            self.shiftreg[k] = self.vram[widx + k]

    # -- from_shiftreg: SR -> memory row transfer [G5]+[G10]; write data
    #    operand is discarded [G5]:223-230 (callback gets only the address).
    def from_shiftreg(self, bitaddr):
        widx = (bitaddr >> 4) & 0xFFFFFFF
        n = self._sr_len()
        assert widx + n <= VRAM_WORDS, "SR transfer out of VRAM range"
        for k in range(n):
            self.vram[widx + k] = 0x0000 if self.zero_fill else self.shiftreg[k]
            self.touched_rows.add((widx + k) // WORDS_PER_ROW)

    # -- shiftreg_w [G5]:223-230: write DATA operand discarded, only the
    #    address reaches the from_shiftreg callback --
    def shiftreg_w(self, bitaddr, data):
        self.from_shiftreg(bitaddr)

    # -- plain memory word write (memory_w path, [G1]:1816) --
    def memory_w(self, bitaddr, data):
        widx = (bitaddr >> 4) & 0xFFFFFFF
        assert widx < VRAM_WORDS
        self.vram[widx] = data & 0xFFFF
        self.touched_rows.add(widx // WORDS_PER_ROW)

    def memory_r(self, bitaddr):
        return self.vram[(bitaddr >> 4) & 0xFFFFFFF]

    def dummy_shiftreg_r(self, bitaddr):       # [G5]:241-244, no re-latch
        return self.shiftreg[0]

    # -- PIXT *Rs, Rd (indirect -> register) [G6] --
    def pixt_ir(self, srcval):
        if self._srt_active():
            # RPIXEL -> read_pixel_shiftreg [G7]:941-946, [G8]: latch SR at the
            # source bit-address, return m_shiftreg[0].
            self.to_shiftreg(srcval)
            return self.shiftreg[0]
        # mutation --no-srt: plain 16-bit read, read_pixel_16 [G9]
        return self.vram[((srcval & 0xFFFFFFF0) >> 4) & 0xFFFFFFF]

    # -- FILL L core, transcribed from [G1][G2][G3][G4] --
    def fill_l(self):
        srt = self._srt_active()
        if srt:                                  # [G1]:1809-1813
            word_write = self.shiftreg_w         # discards data [G5]
            word_read = self.dummy_shiftreg_r
        else:                                    # [G1]:1816-1817
            word_write = self.memory_w
            word_read = self.memory_r

        bpp = self.io["PSIZE"]                   # 0x10 -> 16 bpp [G7]:949-958
        ppw = 16 // bpp                          # PIXELS_PER_WORD
        pixel_mask = (1 << bpp) - 1

        dx = sign16(self.B[7] & 0xFFFF)          # DYDX_X [G1]:1821
        dy = sign16((self.B[7] >> 16) & 0xFFFF)  # DYDX_Y [G1]:1822
        daddr = self.B[2] & ~(bpp - 1) & 0xFFFFFFFF   # word-align [G1]:1834
        if dx <= 0 or dy <= 0:                   # [G1]:1838-1839
            return

        # [G2]:1853-1860 (with PSIZE=16: ppw=1 -> left=right=0, full_words=dx)
        left_partials = (ppw - ((daddr & 15) // bpp)) & (ppw - 1)
        right_partials = ((daddr + dx * bpp) & 15) // bpp
        full_words = dx - left_partials - right_partials
        if full_words < 0:
            left_partials, right_partials, full_words = dx, 0, 0
        else:
            full_words //= ppw

        # CONTROL: T = bit 5 (0x20) [tms34010.cpp:960]; PP bits 14:10 = 0 ->
        # replace (pixel_op00: return srcpix).  DIRQ CONTROL=0x000C -> T=0,
        # replace -- exactly the UG bulk-init recipe [UG-p218].
        transparency = (self.io["CONTROL"] & 0x20) != 0
        color1 = self.B[9]

        dptch = self.B[3]
        for _y in range(dy):                     # [G3]:1867
            dwordaddr = daddr >> 4               # [G3]:1873
            if left_partials != 0:               # [G3]:1879-1900
                dstword = word_read(dwordaddr << 4)
                dstmask = (pixel_mask << (daddr & 15)) & 0xFFFF
                for _x in range(left_partials):
                    pixel = color1 & dstmask
                    if (not transparency) or pixel != 0:
                        dstword = ((dstword & ~dstmask) | pixel) & 0xFFFF
                    dstmask = (dstmask << bpp) & 0xFFFF
                word_write(dwordaddr << 4, dstword)
                dwordaddr += 1
            for _w in range(full_words):         # [G3]:1903-1927
                dstword = 0                      # replace op needs no source
                dstmask = pixel_mask
                for _x in range(ppw):
                    pixel = color1 & dstmask
                    if (not transparency) or pixel != 0:
                        dstword = ((dstword & ~dstmask) | pixel) & 0xFFFF
                    dstmask = (dstmask << bpp) & 0xFFFF
                word_write(dwordaddr << 4, dstword)
                dwordaddr += 1
            if right_partials != 0:              # [G3]:1930-1951
                dstword = word_read(dwordaddr << 4)
                dstmask = pixel_mask
                for _x in range(right_partials):
                    pixel = color1 & dstmask
                    if (not transparency) or pixel != 0:
                        dstword = ((dstword & ~dstmask) | pixel) & 0xFFFF
                    dstmask = (dstmask << bpp) & 0xFFFF
                word_write(dwordaddr << 4, dstword)
                dwordaddr += 1
            daddr = (daddr + dptch) & 0xFFFFFFFF  # [G3]:1954
        # [G4]:1971-1972 linear dst: DADDR += DYDX_Y * DPTCH
        self.B[2] = (self.B[2] + dy * dptch) & 0xFFFFFFFF

    # -- one DIRQ frame (NBA Hangtime MAIN.ASM:632-735 transcription) --
    def run_frame(self, daddr_bits):
        self.io["DPYCTL"] = 0x6810               # SRT (bit 11) set
        a2 = 0x001FE000                          # -> word 0x1FE00 = row 510 w0
        a2 = self.pixt_ir(a2)                    # PIXT *A2,A2: latch SR [G6][G8]
        self.io["CONTROL"] = 0x000C
        self.io["PSIZE"] = 0x0010                # [UG-p252]
        b2 = daddr_bits
        if self.wrong_page:                      # mutation: erase other page
            b2 ^= PAGE_BIT
        self.B = {2: b2, 3: 0x00002000, 7: 0x007F0001, 9: 0xDEADDEAD}
        self.touched_rows = set()
        self.fill_l()
        frame_rows = set(self.touched_rows)
        # restore (no memory side effects at this tier)
        self.io["DPYCTL"] = 0xF010
        self.io["PSIZE"] = 0x0008
        self.io["CONTROL"] = 0x002C
        return frame_rows

    # -- DMA overlay (contract-fixed geometry; a TB poke, not a DUT path) --
    def apply_overlay(self, page_base_row):
        drawn = 0
        skipped = 0
        for j in range(36):                      # rows j=0..35, page-rel Y=47..82
            r = page_base_row + 47 + j
            base = r * WORDS_PER_ROW
            for i in range(342):                 # cols X=87..428
                src = 0 if ((i * 7 + j * 13) % 5) == 0 else (0x40 | ((i + j) & 0x3F))
                if src == 0:
                    skipped += 1
                    continue
                x = 87 + i
                w = base + (x >> 1)
                if x & 1:                        # odd X -> bits[15:8]
                    self.vram[w] = (self.vram[w] & 0x00FF) | ((src & 0xFF) << 8)
                else:                            # even X -> bits[7:0]
                    self.vram[w] = (self.vram[w] & 0xFF00) | (src & 0xFF)
                drawn += 1
        return drawn, skipped


# ------------------------------------------------------------- outputs -------
def write_vram_final(vram, path):
    with open(path, "w", newline="\n") as f:
        for r in range(ROWS):
            base = r * WORDS_PER_ROW
            f.write(" ".join("%04x" % vram[base + c]
                             for c in range(WORDS_PER_ROW)) + "\n")


def write_scan(vram, page, path):
    """scanline s of page P: row = P*256+s; pixel x: pixcol=(56+x)&0x1FF;
    word = row*256 + (pixcol>>1); even pixcol -> bits[7:0], odd -> [15:8]."""
    with open(path, "w", newline="\n") as f:
        for s in range(254):
            row = page * 256 + s
            base = row * WORDS_PER_ROW
            px = []
            for x in range(400):
                pixcol = (56 + x) & 0x1FF
                wv = vram[base + (pixcol >> 1)]
                px.append("%02x" % ((wv >> 8) & 0xFF if (pixcol & 1)
                                    else wv & 0xFF))
            f.write(" ".join(px) + "\n")


# ---------------------------------------------------- baseline self-check ----
def expected_baseline_vram():
    """Closed-form INDEPENDENT reconstruction of the baseline final state
    (does not reuse the operational model): preseed for rows 254/255/510/511;
    erased rows carry the row-510 pattern (even row) / row-511 pattern (odd
    row) because the SR holds [row510 | row511] and every transfer base row is
    even; overlay bytes on top."""
    v = preseed_vram()
    for r in list(range(0, 254)) + list(range(256, 510)):
        base = r * WORDS_PER_ROW
        hi = 0x0500 if (r & 1) == 0 else 0x0600
        for c in range(WORDS_PER_ROW):
            v[base + c] = hi | (c & 0xFF)
    for page_base in (256, 0):                   # frame1 -> page1, frame2 -> page0
        for j in range(36):
            r = page_base + 47 + j
            base = r * WORDS_PER_ROW
            for i in range(342):
                if ((i * 7 + j * 13) % 5) == 0:
                    continue
                src = 0x40 | ((i + j) & 0x3F)
                x = 87 + i
                w = base + (x >> 1)
                if x & 1:
                    v[w] = (v[w] & 0x00FF) | (src << 8)
                else:
                    v[w] = (v[w] & 0xFF00) | src
    return v


def self_check_baseline(model, f1_rows, f2_rows):
    ok = True
    rpt = []

    exp_f1 = set(range(256, 510))
    exp_f2 = set(range(0, 254))
    rpt.append("frame1 FILL touched rows: %d (min %d, max %d) expect 254 rows 256..509 -> %s"
               % (len(f1_rows), min(f1_rows), max(f1_rows),
                  "PASS" if f1_rows == exp_f1 else "FAIL"))
    rpt.append("frame2 FILL touched rows: %d (min %d, max %d) expect 254 rows 0..253 -> %s"
               % (len(f2_rows), min(f2_rows), max(f2_rows),
                  "PASS" if f2_rows == exp_f2 else "FAIL"))
    ok &= (f1_rows == exp_f1) and (f2_rows == exp_f2)

    pre = preseed_vram()
    for r in (254, 255, 510, 511):
        base = r * WORDS_PER_ROW
        same = all(model.vram[base + c] == pre[base + c]
                   for c in range(WORDS_PER_ROW))
        rpt.append("row %d untouched (preseed intact): %s"
                   % (r, "PASS" if same else "FAIL"))
        ok &= same

    exp = expected_baseline_vram()
    mism = sum(1 for i in range(VRAM_WORDS) if model.vram[i] != exp[i])
    rpt.append("closed-form full-VRAM cross-check mismatching words: %d -> %s"
               % (mism, "PASS" if mism == 0 else "FAIL"))
    ok &= (mism == 0)
    return ok, rpt


# ----------------------------------------------------------------- main ------
def main():
    ap = argparse.ArgumentParser(description="Golden model: DIRQ SRT page erase")
    ap.add_argument("--no-srt", dest="no_srt", action="store_true")
    ap.add_argument("--sr512", dest="sr512", action="store_true")
    ap.add_argument("--wrong-page", dest="wrong_page", action="store_true")
    ap.add_argument("--zero-fill", dest="zero_fill", action="store_true")
    args = ap.parse_args()

    flags = [n for n, v in (("no-srt", args.no_srt), ("sr512", args.sr512),
                            ("wrong-page", args.wrong_page),
                            ("zero-fill", args.zero_fill)) if v]
    if len(flags) > 1:
        ap.error("mutation flags are mutually exclusive")

    here = os.path.dirname(os.path.abspath(__file__))
    outname = "srt_golden" if not flags else "srt_golden_" + flags[0]
    outdir = os.path.join(here, "build", outname)
    os.makedirs(outdir, exist_ok=True)

    m = Tms34010SrtModel(no_srt=args.no_srt, sr512=args.sr512,
                         wrong_page=args.wrong_page, zero_fill=args.zero_fill)

    # FRAME 1: erase page 1 (DADDR=0x00100000), overlay at abs rows 303..338
    f1_rows = m.run_frame(0x00100000)
    d1, s1 = m.apply_overlay(256)
    # FRAME 2: erase page 0 (DADDR=0x00000000), overlay at abs rows 47..82
    f2_rows = m.run_frame(0x00000000)
    d2, s2 = m.apply_overlay(0)

    write_vram_final(m.vram, os.path.join(outdir, "vram_final.hex"))
    write_scan(m.vram, 0, os.path.join(outdir, "scan_p0.hex"))
    write_scan(m.vram, 1, os.path.join(outdir, "scan_p1.hex"))

    mode = flags[0] if flags else "baseline"
    print("[golden_srt_page_erase] mode=%s outdir=%s" % (mode, outdir))
    print("  frame1: FILL rows touched=%d overlay drawn=%d skipped=%d"
          % (len(f1_rows), d1, s1))
    print("  frame2: FILL rows touched=%d overlay drawn=%d skipped=%d"
          % (len(f2_rows), d2, s2))

    if not flags:
        ok, rpt = self_check_baseline(m, f1_rows, f2_rows)
        for line in rpt:
            print("  [check] " + line)
        if not ok:
            print("[golden_srt_page_erase] BASELINE SELF-CHECK FAILED")
            sys.exit(1)
        print("[golden_srt_page_erase] baseline self-check PASS")


if __name__ == "__main__":
    main()
