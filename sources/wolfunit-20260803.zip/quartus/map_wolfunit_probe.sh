#!/usr/bin/env bash
# Queue-safe Wolf synthesis probe.  This intentionally runs only sv2v +
# quartus_map: use it to verify RAM inference/resource shape before spending a
# full release-gate run and 20+ minute fit on an experimental encoding.
set -u

TAG="${1:-wolf:map-probe}"
ROOT=/d/deck/fpga/wolf-crt
Q=/tmp/fpga_quartus.queue
LOCK=/tmp/fpga_quartus.lock
QBIN=/c/intelFPGA_lite/17.0/quartus/bin64
REV=Arcade-SmashTV
LOG=/tmp/${TAG//[:\/]/_}_quartus-map.log

cd "$ROOT" || exit 2
"$Q/_notify.sh" enqueue "$TAG" $$ || true

release() {
  local rc="${1:-}"
  if [ -d "$LOCK" ] && grep -q "session=$TAG" "$LOCK/owner" 2>/dev/null; then
    rm -f "$LOCK/owner"
    rmdir "$LOCK" 2>/dev/null || true
    "$Q/_notify.sh" release "$TAG" "$rc" "synthesis-only inference probe" || true
  fi
  "$Q/_notify.sh" dequeue "$TAG" || true
}
trap 'release' EXIT

while :; do
  if "$Q/_notify.sh" myturn "$TAG" >/dev/null 2>&1; then
    "$Q/_notify.sh" holds "$TAG" >/dev/null 2>&1 || {
      "$Q/_notify.sh" enqueue "$TAG" $$ || true
      sleep 5
      continue
    }
    if [ ! -d "$LOCK" ] &&
       ! tasklist 2>/dev/null | grep -qiE '^quartus_(map|fit|sta|asm|sh|cdb)'; then
      if mkdir "$LOCK" 2>/dev/null; then
        {
          echo "$$"
          echo "session=$TAG"
          echo "started=$(date -Is)"
          echo "cmd=Wolf sv2v + quartus_map inference probe"
        } > "$LOCK/owner"
        "$Q/_notify.sh" acquire "$TAG" || true
        break
      fi
    fi
  fi
  sleep 20
done

export SV2V_EXTRA="-DWOLF_MASTER=1 -DCRT_ADJUST=1 -DUSE_DDR3_GFX=1 -DUSE_DDR3_VRAM=1"
bash quartus/build_sv2v.sh > "$LOG" 2>&1 &&
  "$QBIN/quartus_map" "$REV" -c "$REV" \
    --verilog_macro=WOLF_MASTER=1 \
    --verilog_macro=CRT_ADJUST=1 \
    --verilog_macro=USE_DDR3_GFX=1 \
    --verilog_macro=USE_DDR3_VRAM=1 >> "$LOG" 2>&1
RC=$?
"$Q/_notify.sh" note "$TAG" "quartus_map exit=$RC (log $LOG)" || true
release "$RC"
exit "$RC"
