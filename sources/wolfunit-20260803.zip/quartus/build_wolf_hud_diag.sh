#!/usr/bin/env bash
# HUD-flash cabinet instrument (+define+DIAG_HUD). OBSERVATION ONLY -- it adds a
# hex panel and counters; it changes no DMA, no framebuffer write, no page
# publication, no scanout address.
#
# Built on the WOLF_MASTER profile (not build_mk3.sh) because the cabinet runs
# the master RBF and the flash is reported in BOTH MK3 and UMK3, so one diag
# core must serve both via their MRAs.
#
# Panel (top-left, over the live game), 3 hex digits each, per frame:
#   row0 YELLOW  VPW  writes into the VISIBLE page's HUD rows WHILE the raster
#                     is inside the HUD band          <- the measurement
#   row1 CYAN    VPF  writes into the VISIBLE page's HUD rows, anywhere in frame
#   row2 GREEN   HWR  writes into EITHER page's HUD rows  (instrument-alive)
#   row3 WHITE   TWR  total framebuffer writes >>8       (load context)
#
# Reading it: VPW nonzero and tracking the flashing characters => visible-page
# repaint during scanout is the mechanism. VPW staying 0 while the bars flash
# => the write side is excluded too. HWR==0 means the INSTRUMENT is broken --
# do not read a panel of zeros as a clean core.
#
# DEFINE SEAM (this bit is load-bearing): the overlay is instantiated inside
# wolf_top, which is sv2v'd before Quartus sees it, so DIAG_HUD must reach sv2v.
# build_hw.sh already forwards every feature define to BOTH sv2v and quartus_map,
# so DIAG_HUD is passed as a normal feature. DIAG_FLIP is different: it only
# needs to reach SV2V (it declares the dbg_fb_* taps inside the core), and if it
# also reached Quartus it would light up Arcade-SmashTV.sv's DIAG_FLIP overlay,
# which composites over the top and would HIDE this panel. So DIAG_FLIP is
# injected via SV2V_EXTRA only -- build_hw.sh prepends any pre-existing
# SV2V_EXTRA to its own defines.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

: "${PRODUCTION_RELEASE:=0}"
if [ "$PRODUCTION_RELEASE" != "0" ]; then
  echo "FAIL: this is a diagnostic build; do not run it as a production release" >&2
  exit 2
fi

SHA="$(cd "$ROOT" && git rev-parse --short HEAD)"
OUTNAME="${OUTNAME:-Arcade-WolfUnit-HudDiag-$SHA}"

# ---- fitter seed, applied SAFELY ------------------------------------------
# Run 2 of this instrument closed emu|pll (my own 96 MHz cone: -0.847 -> clean
# after pipelining) but still missed by -0.070 on pll_hdmi|...|divclk -- the
# shared sys/ ascal-HDMI cone, TNS -0.110, one occurrence. That cone is
# independent of this instrument's logic and is the chronic ±50 ps cone the
# T-unit session also lands on; the recorded remedy is a fitter-only reseed.
#
# NOT via `quartus_fit --seed=N`: the T-unit session measured that the
# command-line override is PERSISTED back into the .qsf (SEED 10 -> SEED 3), so
# the project file stops hashing to what preflight recorded and every artifact
# built from it -- including images built earlier that the seeded fit never
# touched -- fails its provenance check. Instead: snapshot the QSF, edit the
# existing SEED assignment in place, and restore unconditionally on exit.
QSF="$ROOT/Arcade-SmashTV.qsf"
HUDDIAG_SEED="${HUDDIAG_SEED:-3}"
QSF_BAK="$(mktemp "${TMPDIR:-/tmp}/huddiag_qsf.XXXXXX")"
cp -p "$QSF" "$QSF_BAK"
restore_qsf() {
  cp -p "$QSF_BAK" "$QSF"
  rm -f "$QSF_BAK"
  if [ -n "$(cd "$ROOT" && git status --porcelain -- Arcade-SmashTV.qsf)" ]; then
    echo "WARNING: QSF did not restore cleanly -- check it before any release build" >&2
  fi
}
trap restore_qsf EXIT INT TERM

OLD_SEED="$(sed -n 's/^set_global_assignment -name SEED \([0-9]*\).*/\1/p' "$QSF" | head -1)"
sed -i "s/^set_global_assignment -name SEED .*/set_global_assignment -name SEED $HUDDIAG_SEED/" "$QSF"
echo "fitter seed: $OLD_SEED -> $HUDDIAG_SEED (QSF restored on exit; diagnostic build only)"

# sv2v-only define (see DEFINE SEAM above).
export SV2V_EXTRA="${SV2V_EXTRA:+$SV2V_EXTRA }-DDIAG_FLIP"

bash "$ROOT/quartus/build_hw.sh" \
  WOLF_MASTER=1,CRT_ADJUST=1,USE_DDR3_GFX=1,USE_DDR3_VRAM=1,DIAG_HUD=1 \
  "$OUTNAME"

echo "HUD diag RBF: $ROOT/releases/$OUTNAME.rbf"
