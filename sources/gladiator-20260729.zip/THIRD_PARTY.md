# Third-party components

The project as a combined work is distributed under GPL-3.0-or-later.
Individual components retain their original notices and licenses.

| Component | Local source snapshot | Upstream revision | License |
|---|---|---|---|
| MiSTer `sys` framework | `Template_MiSTer/sys` | `69b8a2acc6d84dd313b5abcba6a17155287ed3d8` | GPL-2.0-or-later; see file headers |
| T80 Z80 | `Arcade-Cave_MiSTer/rtl/t80` | CAVE snapshot `ffb8e109df8fee69ab0fd9bdfe246609ef25375d` | BSD-3-Clause; see VHDL headers |
| JT03/JT12/JT49 | `Arcade-Cave_MiSTer/rtl/jt03` | CAVE snapshot `ffb8e109df8fee69ab0fd9bdfe246609ef25375d` | GPL-3.0-or-later |
| T48 UPI-41 core | JTCores/JTFRAME | `20d6496dd9daefcf04367c71dc0f886820f8304e` | GPL-3.0 |
| `mc6809i` | JTCores/JTFRAME | `20d6496dd9daefcf04367c71dc0f886820f8304e` | Copyright Greg Miller; distributed by the pinned GPL-3.0 JTFRAME tree |
| JT5205 arithmetic | `vis/tecmo-reference/lib/jt5205` | `6ec489c6d9ca05f66f9983414f87c361c9efe7ea` | GPL-3.0-or-later |
| PLL wrapper | `Arcade-Cave_MiSTer/rtl/pll` | CAVE snapshot `ffb8e109df8fee69ab0fd9bdfe246609ef25375d` | Intel-generated IP terms plus project license |
| MiSTer SDRAM controller | `Arcade-IremM72_MiSTer/rtl/sdram.sv` | local Irem M72 reference snapshot | GPL-3.0-or-later; see source header |
| MiSTer CRT Adjust | `rmonic79/MiSTer-CRT-Adjust` `rtl/crt_adjust.sv` | retrieved 2026-07-28, SHA-256 `39e35d90db5ff3866b1d52464bb00806ef1f4482716069f8ea9aef9095e68554` | GPL-3.0-or-later |

The MAME source is not copied into synthesis sources. Regression tools refer to
MAME commit `f094f93c1b948ecdcc88eb8af4995c9a1f6fa4c6`, whose relevant driver files
are BSD-3-Clause.

Local integration change: `jt12_top.v` exposes the existing JT49 `IOA_out` and
`IOB_out` signals instead of discarding them. No synthesis or sound-generation
logic is changed.

Local integration change: `sdram.sv` declares the SDRAM data port as a portable
net and drives it through an internal registered value. The controller state
machine, commands, arbitration, and timing are unchanged.
