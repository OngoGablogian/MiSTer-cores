// revx_guns.sv -- Revolution X three-gun input + on-screen overlay.
//
// Three player guns.  Gun N X/Y come from joystick_l_analog_{N-1} (MiSTer signed
// 8-bit per axis, 0 = centre); they feed the ADC0848 as AN0..AN5 (midxunit.cpp:
// 683-688 ch1..ch6 <- AN0..AN5).
//
// ADC conversion (DONOR-DECISION s.3 / HANDOFF "Sinden / guns"):
//   AN_x = 0x80 - x   AN_y = 0x80 + y
// WHY: MAME declares AN0/AN2/AN4 (the X axes) with PORT_REVERSE and centre 0x80
// (midxunit.cpp:621,627,633) and the game itself inverts X again in READ_ALL_POTS
// (GXCONTRL.ASM:3184-3188 BTST 0 -> NOT A1 on even/X channels).  The Y axes have no
// PORT_REVERSE (midxunit.cpp:624,630,636) => AN_y = 0x80 + y.
//
// AIM SOURCE (per player, OSD P2O[37:36]/[39:38]/[41:40]):
//   0 = L-Analog/USB Gun/Sinden : the absolute stick (default, unchanged path)
//   1 = Mouse                   : the MiSTer relative mouse (hps_io ps2_mouse), ported
//                                 from the Y-unit T2 gun lane (yunit_term2_gun_controls.sv,
//                                 cabinet-confirmed): half-scale signed deltas integrated
//                                 into a clamped screen position by revx_lightgun_position,
//                                 left button = Trigger, right button = Action.  One mouse
//                                 exists; the lowest-numbered gun that selects it owns it and
//                                 any other gun set to Mouse holds centre (never falls back).
//   2 = D-Pad                   : JOYSTICK AIM MODE -- revx_gun_aim integrates an ADC
//                                 position at a fixed per-frame rate from the d-pad and
//                                 HOLDS it when the stick is neutral (no centre snap),
//                                 clamped to the ADC range.  Modelled on chiller_gun.sv.
// Sources 0/2/3 produce ADC bytes and crosshairs bit-identical to the pre-mouse RTL.
//
// MOUSE ADC: the mouse screen position p (0..W-1 / 0..H-1) maps onto the full ADC range with
// the X axis reversed, AN_x = 255 - floor(p_x*255/(W-1)), AN_y = floor(p_y*255/(H-1)): the
// same directions and endpoints as the absolute path (MAME midxunit.cpp:620-636: X ports are
// PORT_REVERSE, left edge = 0xFF; Y ports are not, top edge = 0x00).  revx_lightgun_position's
// own adc_x/adc_y outputs are NOT usable here: its position_to_adc only knows T2's 410/256
// geometry and returns 0x80 for RevX's 400 x 254 (inherited donor constant).
//
// The crosshair/border presentation reuses the Y-unit gun stack ported here
// (revx_lightgun_position x3 for the absolute/mouse screen coords, revx_lightgun_overlay
// extended to three guns).  In D-Pad mode the crosshair coordinate is derived directly
// from the integrated ADC position (single source of truth) via a constant multiply
// that reproduces the absolute mapping exactly, so the overlay tracks the game aim.
// Border width is a parameter (default 4; the cabinet Sinden setup may want ~20).
// Screen geometry defaults to GXSYS.H:32,35 (400 x 254).

`default_nettype none

// ---------------------------------------------------------------------------
// revx_gun_aim -- one gun's ADC byte pair.  Absolute passthrough or, in D-Pad
// mode, a per-frame integrator with anti-snap hold + range clamp.
//
//   joy_dir : raw MiSTer joystick[3:0] = {up, down, left, right} (bit3..bit0);
//             right/left move X, up/down move Y.
//   Polarity matches the absolute AN mapping so the cursor moves the same visual
//   direction in either mode: right decreases adc_x (clamp 0), left increases it
//   (clamp 255); up decreases adc_y (clamp 0), down increases it (clamp 255).
//   "Faster when held": the per-frame step is RATE_SLOW until a direction has been
//   held for RAMP_FRAMES frames, then RATE_FAST (fine aim on a tap, fast traversal
//   on a sustained push).  A neutral stick leaves the position untouched.
// ---------------------------------------------------------------------------
module revx_gun_aim #(
    parameter [7:0] RATE_SLOW   = 8'd2,
    parameter [7:0] RATE_FAST   = 8'd6,
    parameter [7:0] RAMP_FRAMES = 8'd20
)(
    input  logic        clk,
    input  logic        rst,
    input  logic [1:0]  source,        // 0/1/3 = absolute, 2 = D-Pad integrate
    input  logic [15:0] analog,        // {Y, X} signed, 0 = centre
    input  logic [3:0]  joy_dir,       // {up, down, left, right} raw MiSTer joystick[3:0]
    input  logic        frame_tick,    // one pulse per frame
    output logic [7:0]  adc_x,
    output logic [7:0]  adc_y,
    // Preselection D-Pad coordinates keep the OSD selector out of scaling.
    output wire  [7:0]  dpad_adc_x,
    output wire  [7:0]  dpad_adc_y
);
    logic [7:0] jx = 8'h80, jy = 8'h80;   // integrated ADC position, centre on reset
    logic [7:0] hold_cnt = 8'd0;          // frames a direction has been held

    wire        any_dir = |joy_dir;
    wire [7:0]  rate     = (hold_cnt >= RAMP_FRAMES) ? RATE_FAST : RATE_SLOW;

    always_ff @(posedge clk) begin
        if (rst) begin
            jx <= 8'h80; jy <= 8'h80; hold_cnt <= 8'd0;
        end else if (frame_tick) begin
            hold_cnt <= any_dir ? ((hold_cnt >= RAMP_FRAMES) ? RAMP_FRAMES
                                                             : hold_cnt + 8'd1)
                                : 8'd0;
            // X axis: right decreases (clamp 0), left increases (clamp 255)
            if (joy_dir[0] && !joy_dir[1])
                jx <= (jx <= rate)             ? 8'd0   : (jx - rate);
            else if (joy_dir[1] && !joy_dir[0])
                jx <= (jx >= (8'd255 - rate))  ? 8'd255 : (jx + rate);
            // Y axis: up decreases (clamp 0), down increases (clamp 255)
            if (joy_dir[3] && !joy_dir[2])
                jy <= (jy <= rate)             ? 8'd0   : (jy - rate);
            else if (joy_dir[2] && !joy_dir[3])
                jy <= (jy >= (8'd255 - rate))  ? 8'd255 : (jy + rate);
        end
        // frame_tick low: HOLD (jx/jy retain their value) -- the anti-snap property.
    end

`ifdef MUT_GUN_JOY_ABSOLUTE
    // MUTANT (gate-only): D-Pad mode follows the stick's ABSOLUTE value, so a
    // neutral stick snaps the aim back to centre -- the behaviour the user
    // rejected.  tb_revx_gun_aim's release-holds check MUST kill this.
    wire [7:0] joy_sel_x = 8'h80 - analog[7:0];
    wire [7:0] joy_sel_y = 8'h80 + analog[15:8];
`else
    wire [7:0] joy_sel_x = jx;
    wire [7:0] joy_sel_y = jy;
`endif

    assign dpad_adc_x = joy_sel_x;
    assign dpad_adc_y = joy_sel_y;
    assign adc_x = (source == 2'd2) ? joy_sel_x : (8'h80 - analog[7:0]);
    assign adc_y = (source == 2'd2) ? joy_sel_y : (8'h80 + analog[15:8]);
endmodule

module revx_guns #(
    parameter [8:0] BORDER_WIDTH = 9'd4,    // Sinden border (cab may raise to ~20)
    parameter [8:0] SCREEN_W     = 9'd400,  // GXSYS.H:32 SCREEN_WIDTH
    parameter [8:0] SCREEN_H     = 9'd254   // GXSYS.H:35 SCREEN_HEIGHT
)(
    input  logic        clk,
    input  logic        rst,

    // analog sticks: [7:0]=X (signed), [15:8]=Y (signed), 0 = centre
    input  logic [15:0] joystick_l_analog_0,   // gun1
    input  logic [15:0] joystick_l_analog_1,   // gun2
    input  logic [15:0] joystick_l_analog_2,   // gun3

    // per-player aim source + d-pad (OSD P2O[37:36]/[39:38]/[41:40]).
    // gunN_joy = raw MiSTer joystick[3:0] = {up, down, left, right}.
    input  logic [1:0]  gun1_src,
    input  logic [1:0]  gun2_src,
    input  logic [1:0]  gun3_src,
    input  logic [3:0]  gun1_joy,
    input  logic [3:0]  gun2_joy,
    input  logic [3:0]  gun3_joy,

    // MiSTer hps_io relative mouse (sys/hps_io.sv:101): [24] toggles once per packet after
    // its bytes land (:298-299); [23:16] dy, [15:8] dx; [5]/[4] their 9th (sign) bits;
    // [2:0] = middle/right/left buttons.  Main sends dy positive = UP (user_io.cpp y = -y).
    input  logic [24:0] ps2_mouse,

    // ---- ADC feed (-> revx_adc0848 an0..an5) --------------------------------
    output logic [7:0]  an0,  // gun1 X = 0x80 - x
    output logic [7:0]  an1,  // gun1 Y = 0x80 + y
    output logic [7:0]  an2,  // gun2 X
    output logic [7:0]  an3,  // gun2 Y
    output logic [7:0]  an4,  // gun3 X
    output logic [7:0]  an5,  // gun3 Y

    // ---- mouse buttons of the gun that owns the mouse (active high) ---------
    output logic [2:0]  mouse_trigger,  // left button  -> that player's Trigger (BUTTON1)
    output logic [2:0]  mouse_action,   // right button -> that player's Action  (BUTTON2)

    // ---- overlay video path -------------------------------------------------
    input  logic        pxl_cen,
    input  logic        hs,
    input  logic        vs,
    input  logic        de,
    input  logic [2:0]  gun_en,        // per-gun crosshair enable
    input  logic        border_en,
    input  logic        crosshair_en,
    input  logic [23:0] rgb_in,
    output logic [23:0] rgb_out,

    // observability: raster + gun screen coords
    output logic [8:0]  raster_x,
    output logic [8:0]  raster_y
);
    // ---- one frame tick per vsync rising edge (clk domain) -------------------
    logic vs_d;
    always_ff @(posedge clk) if (rst) vs_d <= vs; else vs_d <= vs;
    wire  frame_tick = vs & ~vs_d;

    // ---- ADC bytes: absolute (0x80-x / 0x80+y) or integrated D-Pad aim -------
    wire [7:0] dpad_x1, dpad_y1, dpad_x2, dpad_y2, dpad_x3, dpad_y3;
    wire [7:0] aim_x1, aim_y1, aim_x2, aim_y2, aim_x3, aim_y3;
    revx_gun_aim u_aim1 (.clk(clk), .rst(rst), .source(gun1_src),
        .analog(joystick_l_analog_0), .joy_dir(gun1_joy), .frame_tick(frame_tick),
        .adc_x(aim_x1), .adc_y(aim_y1),
        .dpad_adc_x(dpad_x1), .dpad_adc_y(dpad_y1));
    revx_gun_aim u_aim2 (.clk(clk), .rst(rst), .source(gun2_src),
        .analog(joystick_l_analog_1), .joy_dir(gun2_joy), .frame_tick(frame_tick),
        .adc_x(aim_x2), .adc_y(aim_y2),
        .dpad_adc_x(dpad_x2), .dpad_adc_y(dpad_y2));
    revx_gun_aim u_aim3 (.clk(clk), .rst(rst), .source(gun3_src),
        .analog(joystick_l_analog_2), .joy_dir(gun3_joy), .frame_tick(frame_tick),
        .adc_x(aim_x3), .adc_y(aim_y3),
        .dpad_adc_x(dpad_x3), .dpad_adc_y(dpad_y3));

    // ---- relative mouse (yunit_term2_gun_controls.sv:17-28, the T2 contract) --
`ifdef MUT_MOUSE_UNWIRED
    // MUTANT (gate-only): the shipped defect -- hps_io's mouse never reaches the guns.
    wire [24:0] mouse_pkt = 25'd0;
`else
    wire [24:0] mouse_pkt = ps2_mouse;
`endif
    logic mouse_toggle_d = 1'b0;
    always_ff @(posedge clk) mouse_toggle_d <= mouse_pkt[24];
    wire mouse_event = mouse_pkt[24] ^ mouse_toggle_d;
    // 9-bit signed deltas (Main clamps to -255..255 and puts the 9th bit in [4]/[5],
    // user_io.cpp:4034-4073), arithmetic half-scale as in the T2 lane.
`ifdef MUT_MOUSE_SIGN8
    // MUTANT (gate-only): read the delta bytes as signed 8-bit and drop the 9th bit.
    wire signed [8:0] mouse_dx9 = $signed({mouse_pkt[15], mouse_pkt[15:8]}) >>> 1;
    wire signed [8:0] mouse_dy9 = $signed({mouse_pkt[23], mouse_pkt[23:16]}) >>> 1;
`elsif MUT_MOUSE_Y_UNINVERTED
    // MUTANT (gate-only): treat positive dy as DOWN.
    wire signed [8:0] mouse_dx9 = $signed({mouse_pkt[4], mouse_pkt[15:8]}) >>> 1;
    wire signed [8:0] mouse_dy9 = -($signed({mouse_pkt[5], mouse_pkt[23:16]}) >>> 1);
`else
    wire signed [8:0] mouse_dx9 = $signed({mouse_pkt[4], mouse_pkt[15:8]}) >>> 1;
    wire signed [8:0] mouse_dy9 = $signed({mouse_pkt[5], mouse_pkt[23:16]}) >>> 1;
`endif
    // One mouse: the lowest-numbered gun set to Mouse owns it (T2: "P1 owns it").
    wire mouse_sel1 = (gun1_src == 2'd1);
    wire mouse_sel2 = (gun2_src == 2'd1);
    wire mouse_sel3 = (gun3_src == 2'd1);
`ifdef MUT_MOUSE_OWNER_REVERSED
    // MUTANT (gate-only): the highest-numbered gun wins the mouse.
    wire mouse_own3 = mouse_sel3;
    wire mouse_own2 = mouse_sel2 && !mouse_sel3;
    wire mouse_own1 = mouse_sel1 && !mouse_sel2 && !mouse_sel3;
`else
    wire mouse_own1 = mouse_sel1;
    wire mouse_own2 = mouse_sel2 && !mouse_sel1;
    wire mouse_own3 = mouse_sel3 && !mouse_sel1 && !mouse_sel2;
`endif

    // ---- absolute/mouse crosshair screen coordinates (source 0/1) ------------
    // Mouse-selected guns run the position integrator in its mouse mode (source 1); every
    // other source keeps the absolute mode this instance always had (source 0), so the
    // absolute crosshair is unchanged.  A selected gun that does not own the mouse gets no
    // strobe and holds its reset centre.  The adc_x/adc_y outputs stay unused (see header).
    logic [8:0] g1x,g1y,g2x,g2y,g3x,g3y;
    logic [7:0] unused_ax[0:2], unused_ay[0:2];
    logic       unused_gs[0:2];

    revx_lightgun_position #(.DEFAULT_WIDTH(SCREEN_W), .DEFAULT_HEIGHT(SCREEN_H)) u_p1 (
        .clk(clk),.rst(rst),.vs(vs),.screen_width(SCREEN_W),.screen_height(SCREEN_H),
        .rotate(2'd0),.sensitivity(2'd0),.source(mouse_sel1 ? 2'd1 : 2'd0),
        .joyana(joystick_l_analog_0),.joy_dir(4'd0),
        .mouse_dx(mouse_dx9[7:0]),.mouse_dy(mouse_dy9[7:0]),.mouse_strobe(mouse_event && mouse_own1),
        .gun_x(g1x),.gun_y(g1y),.adc_x(unused_ax[0]),.adc_y(unused_ay[0]),.gun_strobe(unused_gs[0]));
    revx_lightgun_position #(.DEFAULT_WIDTH(SCREEN_W), .DEFAULT_HEIGHT(SCREEN_H)) u_p2 (
        .clk(clk),.rst(rst),.vs(vs),.screen_width(SCREEN_W),.screen_height(SCREEN_H),
        .rotate(2'd0),.sensitivity(2'd0),.source(mouse_sel2 ? 2'd1 : 2'd0),
        .joyana(joystick_l_analog_1),.joy_dir(4'd0),
        .mouse_dx(mouse_dx9[7:0]),.mouse_dy(mouse_dy9[7:0]),.mouse_strobe(mouse_event && mouse_own2),
        .gun_x(g2x),.gun_y(g2y),.adc_x(unused_ax[1]),.adc_y(unused_ay[1]),.gun_strobe(unused_gs[1]));
    revx_lightgun_position #(.DEFAULT_WIDTH(SCREEN_W), .DEFAULT_HEIGHT(SCREEN_H)) u_p3 (
        .clk(clk),.rst(rst),.vs(vs),.screen_width(SCREEN_W),.screen_height(SCREEN_H),
        .rotate(2'd0),.sensitivity(2'd0),.source(mouse_sel3 ? 2'd1 : 2'd0),
        .joyana(joystick_l_analog_2),.joy_dir(4'd0),
        .mouse_dx(mouse_dx9[7:0]),.mouse_dy(mouse_dy9[7:0]),.mouse_strobe(mouse_event && mouse_own3),
        .gun_x(g3x),.gun_y(g3y),.adc_x(unused_ax[2]),.adc_y(unused_ay[2]),.gun_strobe(unused_gs[2]));

    // ---- mouse screen position -> ADC byte (full range, X reversed) ----------
    // floor(p*255/(D-1)) by a constant reciprocal R = ceil(255*2^S/(D-1)): the excess
    // p*(R - 255*2^S/(D-1))/2^S stays below 1/(D-1) for every p <= D-1 while (D-1)^2 < 2^S,
    // so it never crosses an integer and the floor is exact for any D <= 512 at S = 18.
    localparam int MOUSE_SHIFT = 18;
`ifdef MUT_MOUSE_SCALE_W
    // MUTANT (gate-only): divide by D instead of D-1 (the far edge never reaches the end code).
    localparam int MOUSE_RX = ((255 << MOUSE_SHIFT) + SCREEN_W - 1) / SCREEN_W;
    localparam int MOUSE_RY = ((255 << MOUSE_SHIFT) + SCREEN_H - 1) / SCREEN_H;
`else
    localparam int MOUSE_RX = ((255 << MOUSE_SHIFT) + SCREEN_W - 2) / (SCREEN_W - 1);
    localparam int MOUSE_RY = ((255 << MOUSE_SHIFT) + SCREEN_H - 2) / (SCREEN_H - 1);
`endif
    function automatic [7:0] mouse_pos_to_adc(input [8:0] p, input [31:0] recip);
        logic [40:0] prod;
        begin
            prod = {32'd0, p} * {9'd0, recip};
            mouse_pos_to_adc = (|prod[40:MOUSE_SHIFT+8]) ? 8'hff : prod[MOUSE_SHIFT +: 8];
        end
    endfunction
`ifdef MUT_MOUSE_X_UNREVERSED
    // MUTANT (gate-only): left edge = ADC 0x00 (MAME's X PORT_REVERSE ignored).
    function automatic [7:0] mouse_adc_x(input [8:0] p);
        mouse_adc_x = mouse_pos_to_adc(p, MOUSE_RX);
    endfunction
`else
    function automatic [7:0] mouse_adc_x(input [8:0] p);
        mouse_adc_x = 8'd255 - mouse_pos_to_adc(p, MOUSE_RX);
    endfunction
`endif

    // Registered: the multiply launches from the integrator's registered position and the
    // ADC mux sees a flop.  One clk of latency on a value that moves once per mouse packet.
    logic [7:0] mouse_ax1 = 8'h80, mouse_ay1 = 8'h80, mouse_ax2 = 8'h80, mouse_ay2 = 8'h80,
                mouse_ax3 = 8'h80, mouse_ay3 = 8'h80;
    always_ff @(posedge clk) begin
        mouse_ax1 <= mouse_adc_x(g1x);  mouse_ay1 <= mouse_pos_to_adc(g1y, MOUSE_RY);
        mouse_ax2 <= mouse_adc_x(g2x);  mouse_ay2 <= mouse_pos_to_adc(g2y, MOUSE_RY);
        mouse_ax3 <= mouse_adc_x(g3x);  mouse_ay3 <= mouse_pos_to_adc(g3y, MOUSE_RY);
    end

    assign an0 = mouse_sel1 ? mouse_ax1 : aim_x1;
    assign an1 = mouse_sel1 ? mouse_ay1 : aim_y1;
    assign an2 = mouse_sel2 ? mouse_ax2 : aim_x2;
    assign an3 = mouse_sel2 ? mouse_ay2 : aim_y2;
    assign an4 = mouse_sel3 ? mouse_ax3 : aim_x3;
    assign an5 = mouse_sel3 ? mouse_ay3 : aim_y3;

    // ---- mouse buttons -> the owning player's Trigger / Action ---------------
    // T2: "left=Trigger/right=Bomb, never Start/Coin" (yunit_term2_gun_controls.sv:54-57).
    // MAME midxunit.cpp:541-552: BUTTON1/BUTTON2 per player; the emu ORs these in.
    wire [2:0] mouse_own = {mouse_own3, mouse_own2, mouse_own1};
    logic [2:0] mouse_trigger_q = 3'd0, mouse_action_q = 3'd0;
    always_ff @(posedge clk) begin
        if (rst) begin
            mouse_trigger_q <= 3'd0;
            mouse_action_q  <= 3'd0;
        end else begin
`ifdef MUT_MOUSE_BUTTONS_SWAPPED
            // MUTANT (gate-only): right button fires, left button is Action.
            mouse_trigger_q <= mouse_own & {3{mouse_pkt[1]}};
            mouse_action_q  <= mouse_own & {3{mouse_pkt[0]}};
`else
            mouse_trigger_q <= mouse_own & {3{mouse_pkt[0]}};
            mouse_action_q  <= mouse_own & {3{mouse_pkt[1]}};
`endif
        end
    end
    assign mouse_trigger = mouse_trigger_q;
    assign mouse_action  = mouse_action_q;

    // ---- crosshair coordinate: D-Pad mode tracks the integrated aim ----------
    // (256-adc_x)*W>>8 and adc_y*H>>8 reproduce the absolute crosshair mapping
    // exactly (analog_x = 256-AN_x, analog_y = AN_y), so there is no discontinuity
    // when the source switches and the overlay follows the game aim in D-Pad mode.
    function automatic [8:0] adc_to_scr_x(input [7:0] ax, input [8:0] w);
        logic [17:0] p; logic [8:0] r;
        begin
            p = (9'd256 - {1'b0, ax}) * w;
            r = p[16:8];
            adc_to_scr_x = (r >= w) ? (w - 9'd1) : r;
        end
    endfunction
    function automatic [8:0] adc_to_scr_y(input [7:0] ay, input [8:0] h);
        logic [17:0] p; logic [8:0] r;
        begin
            p = {1'b0, ay} * h;
            r = p[16:8];
            adc_to_scr_y = (r >= h) ? (h - 9'd1) : r;
        end
    endfunction

    // Source==2 already selects the D-Pad bytes in the ADC path. Use those
    // same bytes directly here, then select the finished screen coordinate.
    // This removes status -> ADC mux -> multiply/clamp -> coordinate register.
    // ADC output, mapping, integrator and coordinate capture edge are unchanged.
    wire [8:0] cx1 = (gun1_src == 2'd2) ? adc_to_scr_x(dpad_x1, SCREEN_W) : g1x;
    wire [8:0] cy1 = (gun1_src == 2'd2) ? adc_to_scr_y(dpad_y1, SCREEN_H) : g1y;
    wire [8:0] cx2 = (gun2_src == 2'd2) ? adc_to_scr_x(dpad_x2, SCREEN_W) : g2x;
    wire [8:0] cy2 = (gun2_src == 2'd2) ? adc_to_scr_y(dpad_y2, SCREEN_H) : g2y;
    wire [8:0] cx3 = (gun3_src == 2'd2) ? adc_to_scr_x(dpad_x3, SCREEN_W) : g3x;
    wire [8:0] cy3 = (gun3_src == 2'd2) ? adc_to_scr_y(dpad_y3, SCREEN_H) : g3y;

    // ---- register the crosshair coordinates before the overlay ---------------
    // The aim position is a per-frame value (jx/jy update only on frame_tick, and the
    // an* ADC bytes only follow them), so this one-clock pipeline is invisible to the
    // displayed crosshair.  It BREAKS the long single-cycle cone the fitter had built:
    // aim integrator (u_aim3 Add5) -> ADC byte -> adc_to_scr DSP multiply + clamp ->
    // overlay -> rgb_out -> the DIAG game-video delay RAM data-in (revx_diag_boot
    // gvb_d1 M10K), which was the 4b413b96 slow-100C setup -3.45 ns path.  The RAM data
    // input now launches from these registers, not from the aim adder through the DSP.
    logic [8:0] cx1_q, cy1_q, cx2_q, cy2_q, cx3_q, cy3_q;
    always_ff @(posedge clk) begin
        if (rst) begin cx1_q<=9'd0; cy1_q<=9'd0; cx2_q<=9'd0; cy2_q<=9'd0; cx3_q<=9'd0; cy3_q<=9'd0; end
        else     begin cx1_q<=cx1;  cy1_q<=cy1;  cx2_q<=cx2;  cy2_q<=cy2;  cx3_q<=cx3;  cy3_q<=cy3;  end
    end

    revx_lightgun_overlay #(.BORDER_WIDTH(BORDER_WIDTH)) u_ovl (
        .clk(clk),.rst(rst),.pxl_cen(pxl_cen),.hs(hs),.vs(vs),.de(de),
        .screen_width(SCREEN_W),.screen_height(SCREEN_H),
        .gun1_x(cx1_q),.gun1_y(cy1_q),.gun2_x(cx2_q),.gun2_y(cy2_q),.gun3_x(cx3_q),.gun3_y(cy3_q),
        .gun1_en(gun_en[0]),.gun2_en(gun_en[1]),.gun3_en(gun_en[2]),
        .border_en(border_en),.crosshair_en(crosshair_en),
        .rgb_in(rgb_in),.rgb_out(rgb_out),.raster_x(raster_x),.raster_y(raster_y));

endmodule

`default_nettype wire
