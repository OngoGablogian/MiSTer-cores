// revx_backends.sv -- Midway X-unit real memory backends behind the RevX 32-bit CPU
// bus.  This is the HARDWARE counterpart of revx_mem's behavioral RAM/VRAM/CMOS/gfx/
// ROM arrays: same 32-bit byte-enable contract in, but every memory region is served
// by a real backend over a real physical channel:
//
//   main RAM  0x20000000  -> revx_word_sdram (rw) --\
//   prog ROM  0xff000000  -> revx_word_sdram (ro) ---+-> revx_sdram_arb -> ONE MT48 SDRAM
//   boot-load (ioctl dl)  ------------------------- /   (HANDOFF: RAM+ROM on the SDRAM path)
//   VRAM data 0x00000000 + colour 0x00800000 -> byte views of ONE canonical
//   0x80000 x16 pixel store on VD. Raw DMA/scan requests address full pixels.
//   gfx ROM   0xf8000000  -> wolf_gfx_ddr_top      -> DDR3 gfx (flat, no bank)
//   CMOS      0xa0440000  -> wolf_nvram_bridge + internal 8 KiB byte store
//
// Region decode is the SAME as revx_mem.sv:144-169 (midxunit.cpp:508-527 bit-addressed
// map); the difference is the multi-cycle req/done handshake: revx_backends holds the
// CPU access until the launched backend completes, then pulses mem_ack.  I/O regions are
// NOT handled here (they stay in revx_mem); this module owns the five memory backends
// and program ROM only, so the CPU<->backend contract can be gated end-to-end
// (tb_revx_backends) against an independent byte-array reference.
//
// ============================ PERF: sequential instruction-fetch line buffer ===========
// A 32-bit CPU word in the RAM/ROM (shared-MT48) regions costs TWO sequential 16-bit
// SDRAM reads through revx_word_sdram (S_LO then S_HI) plus this FSM's C_IDLE/C_WAIT/
// C_ACK, and there is NO instruction cache on the 34020 model -- so a boot self-test
// loop (RAM-test / "CHECKING ROMS" checksum) RE-FETCHES its body from SDRAM every
// iteration.  A small read line buffer over the RAM+ROM regions serves those re-fetches
// as fast M10K hits.  It is a fit-driven alternative that holds the SAME behaviour
// (DESIGN-RULES.md s.3): the byte returned is bit-identical to a direct SDRAM read; it only
// changes timing.  MEASURED: sim/tb_revx_fetch_profile (warm boot, LATENCY=2 sd model)
// -- see the commit body for before/after clk/instr.
//
//   Organization: 2-way set-associative, 8 sets, 8 CPU-words/line (32 B) = 512 bytes,
//   data in ONE M10K (revx_linebuf_ram, AW=7 DW=32); tags(14b)/valid/LRU in flops.
//   The RAM (cwa 0..0x7FFFF) and ROM (cwa 0x80000..0xFFFFF) CPU-word address spaces are
//   packed into one 20-bit line-buffer address (cwa), so RAM and ROM never alias; 2 ways
//   let a hot RAM loop and a streaming ROM/RAM line coexist in one set (LRU keeps the
//   re-used way).  Reads only; a covered line is FILLED on a miss by LINE_CW consecutive
//   revx_word_sdram reads (the cab-proven single-word transaction shape, unchanged).
//
//   INVALIDATION RULE (why it is byte-exact): the RAM/ROM windows are FLAT and FIXED --
//   the region decode below is purely address-based, no bank/control register remaps what
//   RAM or ROM maps to (gfx is the only banked window and is NOT cached here; it has its
//   own beat cache in wolf_gfx_ddr_top).  So the ONLY way a covered word's value changes
//   is a WRITE to that word.  Every write to the RAM region passes through THIS FSM (the
//   CPU/DMA masters are muxed onto mem_* upstream; scanout only reads VRAM; the boot dl
//   port runs under reset with the buffer cleared) and is the sole writer of the RAM SDRAM
//   words, so invalidating the covered line on any RAM write is COMPLETE.  ROM is
//   read-only (u_rom drops writes) so ROM lines never need invalidation after boot.
//   Ordering is safe: this engine serves one CPU access at a time, so a write's SDRAM
//   commit (C_WAIT->done) fully precedes any later read's refill -> the refill reads the
//   just-written value.  MUTANT REVX_FETCH_LB_NOINVAL removes the write invalidation ->
//   a write to a cached address is masked by stale cache data on the next read -> the new
//   directed gate (and tb_revx_backends' write-then-read checks) MUST FAIL.
//   REVX_FETCH_LB_DISABLE compiles the ORIGINAL direct RAM/ROM path (measurement BEFORE
//   profile + fallback); the disabled build is byte-identical to the pre-buffer backend.
// =======================================================================================
//
// GFX read: the X-unit CPU gfx window (midtunit_v.cpp:246-251, FLAT, no bank) returns a
// 32-bit value = 4 consecutive gfx bytes little-endian.  The DDR3 gfx agent's natural unit
// is a 64-bit beat (8 bytes), so instead of four one-byte cg round trips this backend uses
// wolf_gfx_ddr_top's WIDE beat port (cgw_*): ONE handshake fetches the whole beat and the
// 32-bit LE word {b3,b2,b1,b0} is sliced out here (byte lane k = beat[k*8 +: 8], identical
// to the cg byte mapping).  A 4-byte read whose byte offset spans a beat boundary (offset
// 5/6/7) fetches the next beat too and slices across the 128-bit {beat1,beat0} window; a
// beat-aligned/4-aligned read (the ROM-check pattern) never crosses -> one beat, sequential
// reads hit the agent's beat cache.  (PERF: 4 cg handshakes -> 1 wide handshake; measured
// clk/32-bit-read in sim/tb_revx_gfx_wide.sv.)  The Wolf byte cg port is tied off here.
//
// MUTANT REVX_SDRAM_INTERLEAVE_MUTANT is defined in revx_word_sdram (read halves swapped);
// the program-ROM interleave check in tb_revx_backends KILLS it.

`timescale 1ns/1ps
`default_nettype none
module revx_backends #(
  parameter int SD_AW   = 21,               // shared RAM/ROM SDRAM word-addr width
  parameter int VSD_AW  = 19,               // canonical 0x80000 full-pixel entries
  parameter bit SRT_WRITE_CHUNKS = 1'b0,
  // SDRAM word bases within the ONE shared chip
  parameter [SD_AW-1:0] RAM_SDBASE = 21'h000000,
  parameter [SD_AW-1:0] ROM_SDBASE = 21'h100000   // after 0x80000 RAM words *2 = 0x100000 (2 MiB RAM, midxunit.cpp:511)
)(
  input  logic        clk,
  input  logic        rst,          // core reset (CPU-side FSM + read front-ends)
  input  logic        rst_pon,      // power-on reset (backends/agents, P0022)

  // ---- CPU (TMS34020) 32-bit request/valid bus, bit-addressed ----
  input  logic        mem_req,
  input  logic        mem_we,
  input  logic [31:0] mem_addr,
  input  logic  [3:0] mem_be,
  input  logic [31:0] mem_wdata,
  input  logic        mem_raw_vram,  // DMA/diagnostic full-pixel view; CPU byte views otherwise
  input  logic        mem_srt,       // CPU graphics callback: full 1024-entry row pair
  input  logic        mem_fetch,     // PERF: 1 = instruction-stream read (route to the fetch LB)
  input  logic [15:0] dma_palette,   // snapshot for CPU VRAM-data writes
  input  logic        dma_vram_snoop_we,
  input  logic [18:0] dma_vram_snoop_addr,
  output logic [31:0] mem_rdata,
  output logic        mem_ack,
`ifdef REVX_BLMOVE_BURST
  // Full-rate BLMOVE write request, held through physical commit. A chunk
  // touches at most two 32-byte RAM cache lines; snoop both cached views.
  input logic bulk_ram_wr,
  input logic [31:0] bulk_ram_addr,
`endif

  // ---- boot-load (ioctl download) into program-ROM SDRAM (word-packed by caller) ----
  input  logic        dl_wr,
  input  logic [SD_AW-1:0] dl_addr,      // SDRAM word address (already ROM_SDBASE-relative+base)
  input  logic [15:0] dl_din,
  input  logic  [1:0] dl_be,
  output logic        dl_ack,

  // ---- shared RAM/ROM SDRAM physical channel (to sdram_model) ----
  output logic [SD_AW-1:0] sd_addr,
  output logic [15:0] sd_din,
  output logic  [1:0] sd_be,
  output logic        sd_rd,
  output logic        sd_wr,
  input  logic [15:0] sd_dout,
  input  logic        sd_ack,

  // ---- VRAM data SDRAM channel ----
  output logic [VSD_AW-1:0] vd_addr,
  output logic [15:0] vd_din,
  output logic  [1:0] vd_be,
  output logic        vd_rd,
  output logic        vd_wr,
  input  logic [15:0] vd_dout,
  input  logic        vd_ack,
  output logic        wb_req,
  output logic [VSD_AW-1:0] wb_addr,
  output logic [6:0] wb_count,
  output logic [1023:0] wb_data,
  input logic wb_ack,
`ifdef REVX_VRAM_LB
  // VRAM line-buffer fill passthrough (revx_vram_view's vlb_rb_* -> the top's
  // rb mux; SD-space canonical pixel words, 16-word chunks).
  output logic        vlb_rb_req,
  output logic [VSD_AW-1:0] vlb_rb_addr,
  output logic [4:0]  vlb_rb_count,
  input  logic [255:0] vlb_rb_dout,
  input  logic        vlb_rb_ack,
`endif

  // PERF: line-fill burst READ (one ACTIVE + 16 consecutive reads in the PHY).
  // Bypasses the inner word engines and the inner arb: goes straight out to the
  // outer unified arbiter (revx_top -> revx_sdram_phys).  Safe: this FSM is the
  // sole RAM writer and no other in-module master runs during a fill.
  output logic        rb_req,
  output logic [SD_AW-1:0] rb_addr,
  output logic [4:0]  rb_count,
  input  logic [255:0] rb_dout,
  input  logic        rb_ack,

  // ---- VRAM colour SDRAM channel ----
  output logic [VSD_AW-1:0] vc_addr,
  output logic [15:0] vc_din,
  output logic  [1:0] vc_be,
  output logic        vc_rd,
  output logic        vc_wr,
  input  logic [15:0] vc_dout,
  input  logic        vc_ack,

  // ---- gfx DDR3 Avalon master (to ddr3_avalon_model) ----
  output logic [28:0] gfx_ddram_addr,
  output logic  [7:0] gfx_ddram_burstcnt,
  output logic        gfx_ddram_rd,
  output logic        gfx_ddram_we,
  output logic [63:0] gfx_ddram_din,
  output logic  [7:0] gfx_ddram_be,
  input  logic        gfx_ddram_busy,
  input  logic [63:0] gfx_ddram_dout,
  input  logic        gfx_ddram_dout_ready,

  // ---- gfx DDR3 boot-copy write port (ioctl gfx download) ----
  input  logic        gfx_dl_wr,
  input  logic [24:0] gfx_dl_addr,
  input  logic  [7:0] gfx_dl_data,
  output logic        gfx_dl_ack,
  output logic        gfx_dl_idle,

  // ---- CMOS persistence (hps_io index 4) ----
  input  logic        ioctl_download,
  input  logic        ioctl_upload,
  input  logic        ioctl_wr,
  input  logic  [7:0] ioctl_index,
  input  logic [24:0] ioctl_addr,
  input  logic  [7:0] ioctl_dout,
  output logic  [7:0] ioctl_din,
  output logic        ioctl_upload_req,
  input  logic        manual_save,
  input  logic        clear_nvram
);
  // ---------------------------------------------------------------- region decode
  // (identical constants to revx_mem.sv:144-169, midxunit.cpp:508-527)
  localparam logic [2:0] R_NONE=0,R_VRAMD=1,R_VRAMC=2,R_RAM=3,R_CMOS=4,R_GFX=5,R_ROM=6;
  logic [2:0] region;
  always_comb begin
    region = R_NONE;
    if      (q_raw_vram && q_addr[31:23] == 9'd0)               region = R_VRAMD;
    else if (q_addr[31:22] == 10'd0)                           region = R_VRAMD;
    else if (q_addr[31:22] == 10'd2)                           region = R_VRAMC;
    else if (q_addr[31:24] == 8'h20)                           region = R_RAM;
    else if (q_addr[31:18] == (32'ha0440000 >> 18))            region = R_CMOS;
    else if (q_addr[31:24] >= 8'hf8 && q_addr[31:24] <= 8'hfe) region = R_GFX;
    else if (q_addr[31:24] == 8'hff)                           region = R_ROM;
  end

  // Latched CPU request.  The CPU bus presents mem_we/mem_wdata/mem_be valid with
  // mem_req; the multi-cycle backends capture on their own req pulse ONE cycle later,
  // so the request MUST be latched at C_IDLE (a master that drops mem_we with mem_req
  // would otherwise be seen by the backend as a read -- the bug tb_revx_backends caught).
  logic        q_we;
  logic [31:0] q_addr, q_wdata;
  logic  [3:0] q_be;
  logic q_raw_vram, q_srt, q_fetch;
  logic [15:0] q_dma_palette;

  // region-relative 32-bit word indices from the LATCHED address (stable for the
  // whole multi-cycle backend access)
  wire [12:0] cmos_idx  = q_addr[17:5];
  // gfx flat byte address = (addr - 0xf8000000)>>3  (revx_mem.sv:222-224), latched
  wire [26:0] gfx_off   = {(q_addr[31:24] - 8'hf8), q_addr[23:0]};
  wire [23:0] gfx_baddr = gfx_off[26:3];

  // ---------------------------------------------------------------- word engines
  logic        ram_req, rom_req, vd_req;
  logic        ram_done, rom_done, vd_done;
  logic [31:0] ram_rdata, rom_rdata, vd_rdata;

  // ------ line-buffer geometry (2-way, 128 sets, 8 CPU-words/line = 8 KiB) ------
  // PERF (RevX wide fetch lane, 2026-09-09): grown from 8 sets (512 B) to 128 sets
  // (8 KiB, 8 M10Ks) so the ~5 KiB boot/self-test working set stays fully resident --
  // measured on silicon the 512 B buffer thrashed (105 clk/instr, handoff 2026-09-08).
  // Same associativity/LRU structure; only the set count and tag width scale.
  // The lookup/serve/fill machinery below is unchanged in shape (byte-exact behavior).
  localparam int LB_LINE_CW = 8;                 // CPU words per line
  localparam int LB_OFF_BITS = 3;                // log2(LB_LINE_CW)
  localparam int LB_SET_BITS = 7;                // log2(128 sets) -> 8 KiB
  // cwa: unified 20-bit CPU-word address (RAM 0..0x7FFFF, ROM 0x80000..0xFFFFF)
  localparam [19:0] LB_ROM_CWA_BASE = 20'h80000;
  localparam int LB_TAG_BITS = 20 - LB_OFF_BITS - LB_SET_BITS;   // 10
`ifdef REVX_BLMOVE_BURST
  logic bulk_invalidate_q;
  logic [LB_SET_BITS-1:0] bulk_set_q, bulk_next_set_q;
  always_ff @(posedge clk) begin
    if (rst) begin bulk_invalidate_q <= 0; bulk_set_q <= '0; bulk_next_set_q <= '0; end
    else begin
      bulk_invalidate_q <= (bulk_ram_wr === 1'b1);
      bulk_set_q <= bulk_ram_addr[14:8];
      bulk_next_set_q <= bulk_ram_addr[14:8] + 7'd1;
    end
  end
`endif

  // fill-address plumbing for u_ram/u_rom.  During a line fill the backend drives the
  // region engine's word index from the fill address; otherwise from the latched q_addr.
`ifndef REVX_FETCH_LB_DISABLE
  logic [19:0] lb_line_cwa;                       // line base (offset bits zero)
  logic [LB_OFF_BITS-1:0] fill_k;                 // fill word counter
  logic        lb_is_rom;                         // line region
  logic        lb_filling;
`ifdef REVX_FETCH_LB_BURST
  logic [255:0] rb_shift;                         // burst payload drain (32b/clock into the M10K)
`endif
  wire [19:0]  fill_cwa     = lb_line_cwa + {{(20-LB_OFF_BITS){1'b0}}, fill_k};
  wire [19:0]  fill_rom_cwa = fill_cwa - LB_ROM_CWA_BASE;              // ROM word index (0..0x7FFFF)
  wire [26:0]  ram_waddr = lb_filling ? {8'd0, fill_cwa[18:0]}
                                      : {8'd0, q_addr[23:5]};          // 0x80000 words (2 MiB, midxunit.cpp:511)
  wire [26:0]  rom_waddr = lb_filling ? {8'd0, fill_rom_cwa[18:0]}
                                      : {8'd0, q_addr[23:5]};          // 0x80000 words
`else
  // ORIGINAL direct path (byte-identical to the pre-buffer backend)
  wire [26:0]  ram_waddr = {8'd0, q_addr[23:5]};                       // 0x80000 words (2 MiB, midxunit.cpp:511)
  wire [26:0]  rom_waddr = {8'd0, q_addr[23:5]};                       // 0x80000 words
`endif

  // RAM/ROM masters -> arb -> shared SDRAM
  logic [SD_AW-1:0] a_addr, b_addr; logic [15:0] a_din, b_din; logic [1:0] a_be, b_be;
  logic a_rd, a_wr, b_rd, b_wr; logic [15:0] a_dout, b_dout; logic a_ack, b_ack;

  revx_word_sdram #(.WORDS(32'h80000), .SD_AW(SD_AW), .BASE(RAM_SDBASE), .READ_ONLY(1'b0)) u_ram (
    .clk(clk), .rst(rst), .req(ram_req), .we(q_we), .waddr(ram_waddr), .be(q_be),
    .wd(q_wdata), .rdata(ram_rdata), .done(ram_done), .active(),
    .sd_addr(a_addr), .sd_din(a_din), .sd_be(a_be), .sd_rd(a_rd), .sd_wr(a_wr),
    .sd_dout(a_dout), .sd_ack(a_ack));

  revx_word_sdram #(.WORDS(32'h80000), .SD_AW(SD_AW), .BASE(ROM_SDBASE), .READ_ONLY(1'b1)) u_rom (
    .clk(clk), .rst(rst), .req(rom_req), .we(1'b0), .waddr(rom_waddr), .be(4'hf),
    .wd(32'd0), .rdata(rom_rdata), .done(rom_done), .active(),
    .sd_addr(b_addr), .sd_din(b_din), .sd_be(b_be), .sd_rd(b_rd), .sd_wr(b_wr),
    .sd_dout(b_dout), .sd_ack(b_ack));

  // P0022 (DESIGN-RULES.md s.6): the SDRAM capture path (arb + the boot-load dl_* port) is domained
  // on the POWER-ON reset, NOT the core reset, so an ioctl download lands even while the core
  // reset is held high across the whole download.  The CPU-side word engines stay on core rst.
  // This inner arb folds RAM/ROM and the loader onto sd_*. Canonical u_vram
  // uses VD while VC is idle. revx_sdram_phys merges sd_* and VD with the
  // autonomous scanout master onto the single MT48, retaining scan priority.
  // The unused S/VD/VC inputs here remain explicit zeroes; the capture arb
  // stays on power-on reset independently of the CPU-side engines' core rst.
  revx_sdram_arb #(.SD_AW(SD_AW)) u_arb (
    .clk(clk), .rst(rst_pon),
    .s_addr({SD_AW{1'b0}}), .s_rd(1'b0), .s_dout(), .s_ack(),
    .a_addr(a_addr), .a_din(a_din), .a_be(a_be), .a_rd(a_rd), .a_wr(a_wr), .a_dout(a_dout), .a_ack(a_ack),
    .b_addr(b_addr), .b_din(b_din), .b_be(b_be), .b_rd(b_rd), .b_wr(b_wr), .b_dout(b_dout), .b_ack(b_ack),
    .vd_addr({SD_AW{1'b0}}), .vd_din(16'd0), .vd_be(2'd0), .vd_rd(1'b0), .vd_wr(1'b0), .vd_dout(), .vd_ack(),
    .vc_addr({SD_AW{1'b0}}), .vc_din(16'd0), .vc_be(2'd0), .vc_rd(1'b0), .vc_wr(1'b0), .vc_dout(), .vc_ack(),
    .dl_addr(dl_addr), .dl_din(dl_din), .dl_be(dl_be), .dl_wr(dl_wr), .dl_ack(dl_ack),
    // PERF rb burst bypasses this inner arb (goes direct to the outer unified arb);
    // the inner channel keeps scalar single words only.
    .wb_req(1'b0), .wb_addr({SD_AW{1'b0}}), .wb_count(7'd0), .wb_data(1024'd0), .wb_ack(),
    .rb_req(1'b0), .rb_addr({SD_AW{1'b0}}), .rb_count(5'd0), .rb_dout(), .rb_ack(),
    .sd_addr(sd_addr), .sd_din(sd_din), .sd_be(sd_be), .sd_rd(sd_rd), .sd_wr(sd_wr),
    .sd_dout(sd_dout), .sd_ack(sd_ack), .sd_write_chunk(), .sd_read_chunk(),
    .sd_chunk_count(), .sd_chunk_data(), .sd_chunk_dout(256'd0));

  revx_vram_view #(.SD_AW(VSD_AW), .SRT_WRITE_CHUNKS(SRT_WRITE_CHUNKS)) u_vram (
    .clk(clk), .rst(rst), .req(vd_req), .we(q_we), .addr(q_addr), .be(q_be),
    .raw_mode(q_raw_vram), .srt_mode(q_srt), .color_mode(q_addr[23]), .palette(q_dma_palette),
    .dma_snoop_we(dma_vram_snoop_we), .dma_snoop_addr(dma_vram_snoop_addr),
    .wdata(q_wdata), .rdata(vd_rdata), .done(vd_done), .active(),
    .sd_addr(vd_addr), .sd_din(vd_din), .sd_be(vd_be), .sd_rd(vd_rd), .sd_wr(vd_wr),
    .sd_dout(vd_dout), .sd_ack(vd_ack),
    .wb_req(wb_req), .wb_addr(wb_addr), .wb_count(wb_count), .wb_data(wb_data), .wb_ack(wb_ack)
`ifdef REVX_VRAM_LB
    ,.vlb_rb_req(vlb_rb_req), .vlb_rb_addr(vlb_rb_addr), .vlb_rb_count(vlb_rb_count)
    ,.vlb_rb_dout(vlb_rb_dout), .vlb_rb_ack(vlb_rb_ack)
`endif
);

  // The former independent colour plane is the upper half of canonical VD
  // storage. Its external channel remains idle; scanout sees full pixels.
  assign vc_addr = '0;
  assign vc_din = '0;
  assign vc_be = '0;
  assign vc_rd = 1'b0;
  assign vc_wr = 1'b0;

  // ---------------------------------------------------------------- gfx DDR3 backend
  logic        cg_ack; logic [7:0] cg_data;                 // Wolf byte port -- TIED OFF here
  logic        cgw_req, cgw_ack; logic [21:0] cgw_beat; logic [63:0] cgw_data;  // wide beat port
  // Blitter sprite reads arrive on the wide cgw port; serve them from a 128 KB L2 (MAME
  // blit-stream cache model: pan-down misses 9.1k -> 4.1k lines/frame vs the uncached path).
  wolf_gfx_ddr_top #(.USE_STREAM_HINT(1'b0), .L2_ENABLE(1'b1), .L2_LINES(16384), .CGW_L2(1'b1)) u_gfx (
    .clk(clk), .rst(rst), .sdram_por(rst_pon),
    .src_req(1'b0), .src_addr(32'd0), .src_active(1'b0), .src_stream(1'b0),
    .src_data(), .src_ack(), .dcs_safe(),
    .cg_req(1'b0), .cg_addr(26'd0), .cg_data(cg_data), .cg_ack(cg_ack),
    .cgw_req(cgw_req), .cgw_beat(cgw_beat), .cgw_data(cgw_data), .cgw_ack(cgw_ack),
    .dl_wr(gfx_dl_wr), .dl_addr(gfx_dl_addr), .dl_data(gfx_dl_data),
    .dl_ack(gfx_dl_ack), .dl_idle(gfx_dl_idle),
    .dbg_wbeats(), .dbg_srd(), .dbg_cgrd(),
    .ddram_addr(gfx_ddram_addr), .ddram_burstcnt(gfx_ddram_burstcnt),
    .ddram_rd(gfx_ddram_rd), .ddram_we(gfx_ddram_we), .ddram_din(gfx_ddram_din),
    .ddram_be(gfx_ddram_be), .ddram_busy(gfx_ddram_busy),
    .ddram_dout(gfx_ddram_dout), .ddram_dout_ready(gfx_ddram_dout_ready));

  // ---------------------------------------------------------------- CMOS + nvram bridge
  // 8 KiB byte store, dual access: CPU (this FSM) and the persistence bridge.
  logic       nvram_ext_en, nvram_ext_wr; logic [15:0] nvram_ext_addr;
  logic [7:0] nvram_ext_wdata, nvram_ext_rdata;
  logic       nvram_busy, nvram_dirty, cmos_quiesce;
  logic       cpu_cmos_wr;                 // CPU CMOS write strobe this access
  logic [12:0] cmos_wa; logic [7:0] cmos_wd; // latched CPU CMOS write addr/data
  logic [7:0] cpu_cmos_rdata;

  wolf_nvram_bridge #(.NVRAM_BYTES(8192), .NVRAM_INDEX(8'd4)) u_nv (  // RevX CMOS = ioctl idx 4 (AUDIT s.3 + MRA; Wolf convention; idx 2 is the emu's dcs_download)
    .clk(clk), .rst_pon(rst_pon),
    .ioctl_download(ioctl_download), .ioctl_upload(ioctl_upload), .ioctl_wr(ioctl_wr),
    .ioctl_index(ioctl_index), .ioctl_addr(ioctl_addr), .ioctl_dout(ioctl_dout),
    .ioctl_din(ioctl_din), .ioctl_upload_req(ioctl_upload_req),
    .manual_save(manual_save), .clear_nvram(clear_nvram),
    .cpu_write_pulse(cpu_cmos_wr), .cmos_cpu_busy(1'b0), .cmos_quiesce(cmos_quiesce),
    .nvram_ext_en(nvram_ext_en), .nvram_ext_wr(nvram_ext_wr), .nvram_ext_addr(nvram_ext_addr),
    .nvram_ext_wdata(nvram_ext_wdata), .nvram_ext_rdata(nvram_ext_rdata),
    .nvram_busy(nvram_busy), .nvram_dirty(nvram_dirty));

  // Port A serves bridge upload reads and both mutually arbitrated writers.
  // Port B always serves CPU reads, including while restore/clear owns port A.
  // Preserve bridge-write priority and the existing cmos_quiesce write freeze.
  // Cross-port collisions return the newly committed byte through the bypass.
  wire cmos_bwr = nvram_ext_en && nvram_ext_wr;
  wire cmos_awe = cmos_bwr || cpu_cmos_wr;
  wire [12:0] cmos_aaddr = cmos_bwr ? nvram_ext_addr[12:0] :
                            cpu_cmos_wr ? cmos_wa : nvram_ext_addr[12:0];
  wire [7:0] cmos_awd = cmos_bwr ? nvram_ext_wdata : cmos_wd;
  revx_palram #(.DW(8), .AW(13)) u_cmos (
    .clk(clk), .we_a(cmos_awe), .addr_a(cmos_aaddr), .wd_a(cmos_awd),
    .rd_a(nvram_ext_rdata), .addr_b(cmos_idx), .rd_b(cpu_cmos_rdata));

  // ---------------------------------------------------------------- CPU-side handshake FSM
  typedef enum logic [3:0] { C_IDLE, C_WAIT, C_GFX, C_GFX2, C_CMOS, C_ACK,
                             C_LBFILL, C_LBFWAIT, C_LBWRITE, C_LBSERVE, C_LBSERVE2, C_LBDONE,
                             C_DISPATCH } cst_t;
  cst_t cs;
  logic        gfx_phase;                  // 0 = beat0, 1 = beat1 (crossing access)
  logic [63:0] gfx_b0_q;                   // captured beat0 (for a crossing assembly)
  logic [31:0] rdata_q;
  assign mem_rdata = rdata_q;

  // wide-beat address: beat0 = gfx_baddr[23:3]; +1 for the crossing beat.  Held stable
  // through the access (gfx_baddr is derived from the latched q_addr).
  assign cgw_beat = {1'b0, gfx_baddr[23:3]} + {21'd0, gfx_phase};
  wire         gfx_cross = (gfx_baddr[2:0] > 3'd4);   // 4-byte word spans two beats

  // Slice the 32-bit LE word {b3,b2,b1,b0} from the 128-bit {beat1,beat0} window at the
  // byte offset.  Byte lane k of the window = win[k*8 +: 8] (== wolf_gfx_ddr_top's beat byte
  // mapping), so win[off*8 +: 32] is exactly {mem[B+3],mem[B+2],mem[B+1],mem[B+0]}.
  function automatic [31:0] gfx_assemble(input [127:0] win, input [3:0] off);
    logic [31:0] w;
    begin
      w = win[off*8 +: 32];
`ifdef REVX_GFX_BYTE_MUTANT
      // Deliberate gospel-misread the gfx gate must KILL: big-endian byte order.
      gfx_assemble = {w[7:0], w[15:8], w[23:16], w[31:24]};
`else
      gfx_assemble = w;
`endif
    end
  endfunction

`ifndef REVX_FETCH_LB_DISABLE
  // ================= line-buffer store (2-way set-assoc, tags/valid/LRU in flops) =========
  logic [LB_TAG_BITS-1:0] lb_tag_st [0:1][0:(1<<LB_SET_BITS)-1];
  logic        lb_valid  [0:1][0:(1<<LB_SET_BITS)-1];
  logic        lb_lru    [0:(1<<LB_SET_BITS)-1];      // way to EVICT next per set
  logic        lb_way;                                 // way selected for this access
  logic        lb_which;                               // 0=instruction LB, 1=data LB (REVX_DATA_LB only)
  logic [LB_SET_BITS-1:0] lb_set;                      // latched set
  logic [LB_OFF_BITS-1:0] lb_off;                      // latched requested word offset
  logic [LB_TAG_BITS-1:0] lb_tag;                      // latched tag
  // Separate lookup (128-set mux + tag compare) from valid-bit update.
  // The CPU cannot issue its next read before this write is acknowledged.
  logic w_lv_hit0, w_lv_hit1;

  // C_IDLE captures payload only. Decode/lookup starts at these LOCAL full-rate
  // registers, cutting the u_mif -> owner mux -> cache-control timing cone.
  wire         lv_is_rom = (q_addr[31:24]==8'hff);
  wire [19:0]  lv_cwa = {lv_is_rom, q_addr[23:5]};
  wire [LB_OFF_BITS-1:0] lv_off = lv_cwa[LB_OFF_BITS-1:0];
  wire [LB_SET_BITS-1:0] lv_set = lv_cwa[LB_OFF_BITS+LB_SET_BITS-1:LB_OFF_BITS];
  wire [LB_TAG_BITS-1:0] lv_tag = lv_cwa[19:LB_OFF_BITS+LB_SET_BITS];
  wire         lv_hit0  = lb_valid[0][lv_set] && (lb_tag_st[0][lv_set]==lv_tag);
  wire         lv_hit1  = lb_valid[1][lv_set] && (lb_tag_st[1][lv_set]==lv_tag);
  wire         lv_victim = (!lb_valid[0][lv_set]) ? 1'b0
                         : (!lb_valid[1][lv_set]) ? 1'b1
                         : lb_lru[lv_set];

  // line-buffer data: 2048 x 32b = 8 KiB = 8 M10Ks, simple dual-port (fill write /
  // serve read), registered read (lb_rdata valid one clock after lb_raddr).  Inlined --
  // not a separate module -- so no external source list (gates or quartus/**) needs a
  // new file.  Same proven inference as revx_palram (no_rw_check, M10K); fill and serve
  // are never same-address same-cycle, so no read-during-write data is relied upon.
  logic        lb_we; logic [31:0] lb_wdata;
  logic [LB_OFF_BITS-1:0] lb_wslot;              // captured fill slot for the delayed write
  wire  [1+LB_SET_BITS+LB_OFF_BITS-1:0] lb_waddr = {lb_way, lb_set, lb_wslot};
  wire  [1+LB_SET_BITS+LB_OFF_BITS-1:0] lb_raddr = {lb_way, lb_set, lb_off};
  logic [31:0] lb_rdata;
  (* ramstyle = "no_rw_check, M10K" *) logic [31:0] lb_mem [0:2047];
  always_ff @(posedge clk) begin
    if (lb_we) lb_mem[lb_waddr] <= lb_wdata;
    lb_rdata <= lb_mem[lb_raddr];
  end
`endif

`ifdef REVX_DATA_LB
  // ================ DATA line buffer (PERF, 2026-09-10) =========================
  // A SECOND 2-way set-associative line buffer, same geometry as the instruction
  // LB above, serving RAM/ROM DATA reads (mem_fetch=0).  The per-frame data
  // stream and the instruction stream no longer share one LRU, so neither can
  // evict the other (the measured stall gap: ~7.3 CE/instr vs ~1.3 ideal).
  // COHERENCE (same proof as the instruction LB, header lines 40-48): every
  // writer of the RAM region passes through THIS FSM, so a RAM write updates
  // the resident data-LB word (write-through update; read-after-write hits) and
  // invalidates the instruction LB's line (existing rule).  ROM is read-only,
  // so ROM lines need no invalidation after boot.  Bytes served are bit-
  // identical to a direct SDRAM read -- both buffers fill from the same SDRAM
  // (DESIGN-RULES.md s.3: this only changes timing).
  // MUTANTS: REVX_DATA_LB_NOUPDATE skips the write-through update -> a
  //   write-then-read to a cached word serves STALE data (the gate MUST fail).
  //   REVX_DATA_LB_NOSPLIT routes all reads to the instruction LB (today's
  //   behavior) -- the byte-exact A/B fallback.
  logic [LB_TAG_BITS-1:0] dlb_tag_st [0:1][0:(1<<LB_SET_BITS)-1];
  logic        dlb_valid  [0:1][0:(1<<LB_SET_BITS)-1];
  logic        dlb_lru    [0:(1<<LB_SET_BITS)-1];
  logic        dlb_way;                          // selected way (latched at accept)
  logic [31:0] dlb_rdata;                        // registered serve read
  // write-through update latches (RAM write -> update the resident data-LB word)
  logic        dlb_we;                          // fill-drain write strobe (C_LBWRITE)
  logic        dlb_upd_valid, dlb_upd_way, dlb_upd_we;
  logic [LB_SET_BITS-1:0] dlb_upd_set;
  logic [LB_OFF_BITS-1:0] dlb_upd_off;
  // REGISTERED-DECISION latches (2026-09-11, signoff TNS -118 fix): the write's
  // hit context is latched at dispatch (reusing the existing lb_set/lb_off
  // latches); update actions happen
  // in C_WAIT from the latched values -- the accept cone (a 12.5 ns full-rate
  // path) must never grow the dlv-hit compares.
  logic        q_full_word;                     // accept: mem_be == 4'b1111
  logic        w_dlv_hit0, w_dlv_hit1;          // accept: DLB hits for the write's word

  wire         dlv_hit0   = dlb_valid[0][lv_set] && (dlb_tag_st[0][lv_set]==lv_tag);
  wire         dlv_hit1   = dlb_valid[1][lv_set] && (dlb_tag_st[1][lv_set]==lv_tag);
  wire         dlv_victim = (!dlb_valid[0][lv_set]) ? 1'b0
                          : (!dlb_valid[1][lv_set]) ? 1'b1
                          : dlb_lru[lv_set];

  // data-LB store: 2048 x 32b = 8 KiB = 8 M10Ks, simple dual-port.  The ONE
  // write port is shared by the burst-fill drain (C_LBWRITE, data = lb_wdata,
  // addr = {dlb_way, lb_set, lb_wslot}) and the write-through update (C_ACK,
  // data = q_wdata, addr = {dlb_upd_way, dlb_upd_set, dlb_upd_off}); the two
  // never overlap (one FSM).  Port B is the always-on registered serve read.
  wire [1+LB_SET_BITS+LB_OFF_BITS-1:0] dlb_waddr = dlb_upd_we
      ? {dlb_upd_way, dlb_upd_set, dlb_upd_off} : {dlb_way, lb_set, lb_wslot};
  wire [31:0] dlb_wdata_eff = dlb_upd_we ? q_wdata : lb_wdata;
  wire        dlb_we_eff    = dlb_we | dlb_upd_we;
`ifdef REVX_DATA_LB_FULLUPD
  // Negative control: corrupt disabled bytes as the retired full-slot update did.
  wire [3:0] dlb_wbe_eff = 4'hf;
`else
  // q_be remains stable through C_ACK. A refill writes all lanes; a committed
  // scalar write updates only its selected lanes in a resident cache word.
  wire [3:0] dlb_wbe_eff = dlb_upd_we ? q_be : 4'hf;
`endif
  wire [1+LB_SET_BITS+LB_OFF_BITS-1:0] dlb_raddr = {dlb_way, lb_set, lb_off};
  (* ramstyle = "no_rw_check, M10K" *) logic [31:0] dlb_mem [0:2047];
  always_ff @(posedge clk) begin
    for (integer byte_lane=0; byte_lane<4; byte_lane=byte_lane+1)
      if (dlb_we_eff && dlb_wbe_eff[byte_lane])
        dlb_mem[dlb_waddr][byte_lane*8 +: 8] <= dlb_wdata_eff[byte_lane*8 +: 8];
    dlb_rdata <= dlb_mem[dlb_raddr];
  end
`endif

`ifdef REVX_DATA_LB
  // PERF: data reads route to the DATA LB; instruction fetches to the fetch LB.
`ifdef REVX_DATA_LB_NOSPLIT
  wire use_dlb = 1'b0;    // MUTANT/A-B fallback: everything through the fetch LB
`else
  wire use_dlb = !q_fetch; // open legacy mem_fetch is captured as instruction traffic
`endif
`endif

  always_ff @(posedge clk) begin
    if (rst) begin
      cs <= C_IDLE; mem_ack <= 1'b0;
      ram_req <= 1'b0; rom_req <= 1'b0; vd_req <= 1'b0;
      rb_req <= 1'b0;
      q_raw_vram <= 1'b0; q_srt <= 1'b0; q_dma_palette <= '0;
      q_we <= 1'b0; q_addr <= '0; q_be <= '0; q_wdata <= '0; q_fetch <= 1'b1;
      cgw_req <= 1'b0; cpu_cmos_wr <= 1'b0; gfx_phase <= 1'b0; gfx_b0_q <= 64'd0; rdata_q <= 32'd0;
`ifndef REVX_FETCH_LB_DISABLE
      lb_filling <= 1'b0; lb_we <= 1'b0; fill_k <= '0; lb_wslot <= '0; lb_way <= 1'b0;
      lb_is_rom <= 1'b0; lb_line_cwa <= 20'd0;
      w_lv_hit0 <= 1'b0; w_lv_hit1 <= 1'b0;
      for (int w=0; w<2; w++)
        for (int s=0; s<(1<<LB_SET_BITS); s++) begin lb_valid[w][s] <= 1'b0; end
      for (int s=0; s<(1<<LB_SET_BITS); s++) lb_lru[s] <= 1'b0;
`endif
`ifdef REVX_DATA_LB
      dlb_we <= 1'b0; dlb_upd_we <= 1'b0; dlb_upd_valid <= 1'b0; dlb_way <= 1'b0;
      lb_which <= 1'b0;
      for (int w=0; w<2; w++)
        for (int s=0; s<(1<<LB_SET_BITS); s++) begin dlb_valid[w][s] <= 1'b0; end
      for (int s=0; s<(1<<LB_SET_BITS); s++) dlb_lru[s] <= 1'b0;
`endif
    end else begin
      mem_ack <= 1'b0; ram_req <= 1'b0; rom_req <= 1'b0; vd_req <= 1'b0;
      rb_req <= 1'b0;
      cpu_cmos_wr <= 1'b0;
`ifndef REVX_FETCH_LB_DISABLE
      lb_we <= 1'b0;
`endif
`ifdef REVX_DATA_LB
      dlb_we <= 1'b0; dlb_upd_we <= 1'b0;
`endif
      case (cs)
        // Accept a new access only when NOT asserting mem_ack this cycle.  The
        // req-held-until-ack contract (sim_memory_model / bootsmoke_mem's
        // `mem_req && !mem_ack`; tms34010_mem_if's `core_req && !core_ack`) lets a
        // master hold mem_req high THROUGH the ack cycle -- the mem_if does exactly
        // that (bus_req is combinational in S_RD0 and drops only on the S_ACK
        // transition).  Without the !mem_ack guard, C_ACK->C_IDLE saw mem_req still
        // high in the same cycle mem_ack pulsed and launched a SPURIOUS duplicate
        // read; that extra in-flight access desynced ack/rdata by one transaction,
        // so every fetch returned the PREVIOUS fetch's data (tb_revx_top_boot
        // frontier at 0xFFFDE180: opcode 09F2 read back as the stale E160 low half
        // E870 -> +0x10 mis-advance).  MEASURED via the mem_if bus-read transaction
        // diff vs the passing CPU-lane bootsmoke bench (same core, same ROM image).
        //
        // MUTANT REVX_BACKEND_STALE_ACK_MUTANT restores the buggy accept (no
        // !mem_ack) -> the held-req back-to-back read check in tb_revx_backends MUST
        // KILL it (each read returns the PREVIOUS read's word).
`ifdef REVX_BACKEND_STALE_ACK_MUTANT
        C_IDLE: if (mem_req) begin
`else
        C_IDLE: if (mem_req && !mem_ack) begin
`endif
          q_we <= mem_we; q_addr <= mem_addr; q_be <= mem_be; q_wdata <= mem_wdata;
          q_raw_vram <= (mem_raw_vram === 1'b1);
          q_srt <= (mem_srt === 1'b1);
          q_dma_palette <= dma_palette;
          q_fetch <= (mem_fetch !== 1'b0);
          cs <= C_DISPATCH;
        end
        C_DISPATCH: begin
          unique case (region)
`ifdef REVX_FETCH_LB_DISABLE
            R_RAM:   begin ram_req <= 1'b1; cs <= C_WAIT; end
            R_ROM:   begin rom_req <= 1'b1; cs <= C_WAIT; end
`else
            R_RAM:   begin
                       if (q_we) begin
                         // Capture the instruction-LB invalidate decision here;
                         // apply it at RAM completion, before CPU acknowledgement.
                         lb_set <= lv_set;
`ifndef REVX_FETCH_LB_NOINVAL
                         w_lv_hit0 <= lv_hit0;
                         w_lv_hit1 <= lv_hit1;
`endif
`ifdef REVX_DATA_LB
                         // write-through update: latch the resident data-LB word's
                         // slot; C_ACK writes q_wdata into it (read-after-write hits).
                         // Only enabled bytes may change in the cache, just as in
                         // physical RAM. The byte-enabled M10K update preserves
                         // neighbouring bytes without invalidating the whole line.
                         // This matters for the narrow object-field updates in DIRQ.
`ifndef REVX_DATA_LB_NOUPDATE
`ifdef REVX_DATA_LB_FULLUPD
                         // MUTANT (tb_revx_data_lb): the pre-fix behavior -- update on
                         // EVERY RAM write including partials -> the byte-write checks
                         // MUST FAIL (neighbour corruption).  (Also carries the accept-
                         // cone growth the signoff rejected; gate-only, never built.)
                         q_full_word <= 1'b1;
`else
                         // REGISTERED DECISION (2026-09-11): latch ONLY the decision +
                         // the hit context here (trivial captures; the accept cone keeps
                         // its proven depth).  The update/invalidate ACTIONS run in
                         // C_WAIT from these latched values (register-to-register).
                         q_full_word <= (q_be == 4'b1111);
`endif
                         w_dlv_hit0  <= dlv_hit0;
                         w_dlv_hit1  <= dlv_hit1;
                         lb_off      <= lv_off;
`endif
`endif
                         ram_req <= 1'b1; cs <= C_WAIT;
                       end else begin
                         // read: line-buffer lookup
                         lb_set <= lv_set; lb_off <= lv_off; lb_tag <= lv_tag;
                         lb_is_rom <= 1'b0; lb_line_cwa <= {lv_cwa[19:LB_OFF_BITS], {LB_OFF_BITS{1'b0}}};
`ifdef REVX_DATA_LB
                         if (use_dlb) begin
                           // DATA read -> data LB
                           lb_which <= 1'b1;
                           if (dlv_hit0 || dlv_hit1) begin
                             dlb_way <= dlv_hit1;             // 1->way1, 0->way0
                             cs <= C_LBSERVE;
                           end else begin
                             dlb_way <= dlv_victim; fill_k <= '0; lb_filling <= 1'b1; cs <= C_LBFILL;
                           end
                         end else
`endif
                         begin
                           lb_which <= 1'b0;
                           if (lv_hit0 || lv_hit1) begin
                             lb_way <= lv_hit1;              // 1->way1, 0->way0
                             cs <= C_LBSERVE;
                           end else begin
                             lb_way <= lv_victim; fill_k <= '0; lb_filling <= 1'b1; cs <= C_LBFILL;
                           end
                         end
                       end
                     end
            R_ROM:   begin
                       if (q_we) begin
                         rom_req <= 1'b1; cs <= C_WAIT;    // ROM write ignored by u_rom; ROM cache unchanged
                       end else begin
                         lb_set <= lv_set; lb_off <= lv_off; lb_tag <= lv_tag;
                         lb_is_rom <= 1'b1; lb_line_cwa <= {lv_cwa[19:LB_OFF_BITS], {LB_OFF_BITS{1'b0}}};
`ifdef REVX_DATA_LB
                         if (use_dlb) begin
                           // DATA read (ROM checksum etc.) -> data LB
                           lb_which <= 1'b1;
                           if (dlv_hit0 || dlv_hit1) begin
                             dlb_way <= dlv_hit1;
                             cs <= C_LBSERVE;
                           end else begin
                             dlb_way <= dlv_victim; fill_k <= '0; lb_filling <= 1'b1; cs <= C_LBFILL;
                           end
                         end else
`endif
                         begin
                           lb_which <= 1'b0;
                           if (lv_hit0 || lv_hit1) begin
                             lb_way <= lv_hit1;
                             cs <= C_LBSERVE;
                           end else begin
                             lb_way <= lv_victim; fill_k <= '0; lb_filling <= 1'b1; cs <= C_LBFILL;
                           end
                         end
                       end
                     end
`endif
            R_VRAMD: begin vd_req  <= 1'b1; cs <= C_WAIT; end
            R_VRAMC: begin vd_req  <= 1'b1; cs <= C_WAIT; end
            R_CMOS:  begin
                       if (q_we && q_be[0] && !cmos_quiesce) begin
                         cpu_cmos_wr <= 1'b1; cmos_wa <= cmos_idx; cmos_wd <= q_wdata[7:0];
                       end
                       // Registered port B samples the accepted address this edge.
                       // Writes retain their old acknowledgement latency.
                       cs <= q_we ? C_ACK : C_CMOS;
                     end
            R_GFX:   begin gfx_phase <= 1'b0; cgw_req <= 1'b1; cs <= C_GFX; end
            default: begin rdata_q <= 32'd0; cs <= C_ACK; end
          endcase
        end
        C_WAIT: begin
          if (ram_done) begin
            rdata_q <= ram_rdata;
`ifndef REVX_FETCH_LB_DISABLE
`ifndef REVX_FETCH_LB_NOINVAL
            // No tag lookup or live request address reaches the valid flops.
            // Bulk invalidation below retains priority over all publications.
            if (q_we) begin
              if (w_lv_hit0) lb_valid[0][lb_set] <= 1'b0;
              if (w_lv_hit1) lb_valid[1][lb_set] <= 1'b0;
            end
`endif
`endif
`ifdef REVX_DATA_LB
`ifndef REVX_DATA_LB_NOUPDATE
            // Publish only after the physical RAM write commits. Byte enables
            // preserve the rest of a resident word, so narrow object-field
            // writes no longer discard/refill the whole data cache line.
`ifdef REVX_DATA_LB_INVALIDATE_PARTIAL
            // Performance negative control: restore the former refill penalty.
            if (q_we && q_full_word) begin
`else
            if (q_we) begin
`endif
              dlb_upd_valid <= w_dlv_hit0 || w_dlv_hit1;
              dlb_upd_way   <= w_dlv_hit1;
              dlb_upd_set   <= lb_set;
              dlb_upd_off   <= lb_off;
            end else if (q_we) begin
              if (w_dlv_hit0) dlb_valid[0][lb_set] <= 1'b0;
              if (w_dlv_hit1) dlb_valid[1][lb_set] <= 1'b0;
            end
`endif
`endif
            cs <= C_ACK;
          end
          else if (rom_done) begin rdata_q <= rom_rdata; cs <= C_ACK; end
          else if (vd_done)  begin rdata_q <= vd_rdata;  cs <= C_ACK; end
        end
`ifndef REVX_FETCH_LB_DISABLE
        // ---- line-buffer FILL: read LB_LINE_CW consecutive CPU words into the victim line ----
`ifdef REVX_FETCH_LB_BURST
        // PERF burst path (RevX wide fetch lane, 2026-09-09): ONE 16-word SDRAM
        // read-chunk replaces the scalar 8-iteration word-engine loop (16 single
        // transactions, ~600 clk).  The chunk reads exactly the line's 16 SDRAM
        // words (8 CPU words x 2 LE-interleaved halves); C_LBWRITE drains
        // rb_shift 32 bits per clock into the M10K slots.  The line's 16-word
        // SDRAM span starts 16-aligned and never crosses a 512-column row.
        C_LBFILL: begin
          rb_req <= 1'b1; rb_count <= 5'd16;
          rb_addr <= lb_is_rom
                   ? (ROM_SDBASE + (({1'b0, lb_line_cwa} - {1'b0, LB_ROM_CWA_BASE}) << 1))
                   : (RAM_SDBASE + ({1'b0, lb_line_cwa} << 1));
          cs <= C_LBFWAIT;
        end
        C_LBFWAIT: begin
          rb_req <= 1'b1;      // hold the request through the wait (arb may be busy)
          if (rb_ack) begin
            rb_req <= 1'b0;
            rb_shift <= rb_dout;
            fill_k <= '0;
            cs <= C_LBWRITE;
          end
        end
        C_LBWRITE: begin
`ifdef REVX_DATA_LB
          if (lb_which) dlb_we <= 1'b1; else lb_we <= 1'b1;
`else
          lb_we <= 1'b1;
`endif
          lb_wslot <= fill_k;
`ifdef REVX_FETCH_LB_BURST_ORDER_MUTANT
          // MUTANT (tb_revx_fetch_burst): drain the burst payload in REVERSE order --
          // the line's CPU words land in swapped slots -> every served read past the
          // requested word returns the wrong byte position -> the gate MUST FAIL.
          lb_wdata <= rb_shift[255:224];
          rb_shift <= {rb_shift[223:0], 16'd0};
`else
          lb_wdata <= rb_shift[31:0];
          rb_shift <= {16'd0, rb_shift[255:32]};
`endif
          if (fill_k == (LB_LINE_CW-1)) begin
            // last word: publish the line; C_LBDONE then stalls one cycle so the
            // last write settles before the serve read (no_rw_check M10K).
`ifdef REVX_DATA_LB
            if (lb_which) begin
              dlb_tag_st[dlb_way][lb_set] <= lb_tag;
              dlb_valid [dlb_way][lb_set] <= 1'b1;
              dlb_lru   [lb_set]         <= ~dlb_way;     // filled way is MRU
            end else begin
              lb_tag_st[lb_way][lb_set] <= lb_tag;
              lb_valid [lb_way][lb_set] <= 1'b1;
              lb_lru   [lb_set]         <= ~lb_way;       // filled way is MRU
            end
`else
            lb_tag_st[lb_way][lb_set] <= lb_tag;
            lb_valid [lb_way][lb_set] <= 1'b1;
            lb_lru   [lb_set]         <= ~lb_way;         // filled way is MRU
`endif
            lb_filling <= 1'b0;
            cs <= C_LBDONE;
          end else begin
            fill_k <= fill_k + 1'b1;
          end
        end
`else
        // scalar fallback: one word-engine access per CPU word (legacy shape; the
        // behavioral sdram_model benches and the REVX_FETCH_LB_DISABLE-free baseline)
        C_LBFILL: begin
          if (lb_is_rom) rom_req <= 1'b1; else ram_req <= 1'b1;   // fetch word fill_k
          cs <= C_LBFWAIT;
        end
        C_LBFWAIT: begin
          if ((lb_is_rom && rom_done) || (!lb_is_rom && ram_done)) begin
`ifdef REVX_DATA_LB
            if (lb_which) dlb_we <= 1'b1; else lb_we <= 1'b1;  // write fetched word into the line
`else
            lb_we    <= 1'b1;                                   // write fetched word into the line
`endif
            lb_wslot <= fill_k;                                 // slot = THIS word (fill_k may advance)
            lb_wdata <= lb_is_rom ? rom_rdata : ram_rdata;
            if (fill_k == (LB_LINE_CW-1)) begin
              // last word: publish the line, then STALL one cycle so the last write
              // settles before the serve read (no_rw_check M10K: never read a slot the
              // same cycle it is written).
`ifdef REVX_DATA_LB
              if (lb_which) begin
                dlb_tag_st[dlb_way][lb_set] <= lb_tag;
                dlb_valid [dlb_way][lb_set] <= 1'b1;
                dlb_lru   [lb_set]         <= ~dlb_way;
              end else begin
                lb_tag_st[lb_way][lb_set] <= lb_tag;
                lb_valid [lb_way][lb_set] <= 1'b1;
                lb_lru   [lb_set]         <= ~lb_way;
              end
`else
              lb_tag_st[lb_way][lb_set] <= lb_tag;
              lb_valid [lb_way][lb_set] <= 1'b1;
              lb_lru   [lb_set]         <= ~lb_way;             // filled way is MRU
`endif
              lb_filling <= 1'b0;
              cs <= C_LBDONE;
            end else begin
              fill_k <= fill_k + 1'b1;
              cs <= C_LBFILL;
            end
          end
        end
`endif
        // ---- serve: M10K registered read of {way,set,off} (raddr stable) ----
        C_LBDONE:   cs <= C_LBSERVE;                              // post-fill settle (last write commits here)
        C_LBSERVE: begin
          // Replacement updates use the registered lookup result, never a
          // live address -> tag compare -> dynamic 128-way write-enable cone.
`ifdef REVX_DATA_LB
          if (lb_which) dlb_lru[lb_set] <= ~dlb_way;
          else
`endif
            lb_lru[lb_set] <= ~lb_way;
          cs <= C_LBSERVE2;
        end
`ifdef REVX_DATA_LB
        C_LBSERVE2: begin rdata_q <= lb_which ? dlb_rdata : lb_rdata; cs <= C_ACK; end
`else
        C_LBSERVE2: begin rdata_q <= lb_rdata; cs <= C_ACK; end
`endif
`endif
        C_GFX: begin
          // ONE wide beat fetch (beat0). If the 4-byte word does not cross the beat
          // boundary, assemble + ack now; else capture beat0 and fetch beat1 (C_GFX2).
          if (cgw_ack) begin
            cgw_req  <= 1'b0;
            gfx_b0_q <= cgw_data;
            if (gfx_cross) begin
              gfx_phase <= 1'b1;            // request beat0+1 next
              cs <= C_GFX2;
            end else begin
              // offset <= 4: the 32-bit slice lies wholly inside beat0
              rdata_q <= gfx_assemble({64'd0, cgw_data}, {1'b0, gfx_baddr[2:0]});
              cs <= C_ACK;
            end
          end
        end
        C_GFX2: begin
          // crossing access: fetch beat1, then slice across {beat1,beat0}
          if (!cgw_req && !cgw_ack) begin
            cgw_req <= 1'b1;                 // re-arm for beat1 (req dropped a cycle after ack)
          end else if (cgw_ack) begin
            cgw_req <= 1'b0;
            rdata_q <= gfx_assemble({cgw_data, gfx_b0_q}, {1'b0, gfx_baddr[2:0]});
            cs <= C_ACK;
          end
        end
        C_CMOS: begin rdata_q <= {24'd0, cpu_cmos_rdata}; cs <= C_ACK; end
        C_ACK: begin
`ifdef REVX_DATA_LB
          // write-through update: land the written word into the resident data-LB
          // slot (fires for RAM writes whose line was resident), then clear the
          // latch so later READ acks never replay a stale update.
          dlb_upd_we <= dlb_upd_valid;
          dlb_upd_valid <= 1'b0;
`endif
          mem_ack <= 1'b1; cs <= C_IDLE;
        end
        default: cs <= C_IDLE;
      endcase
`ifdef REVX_BLMOVE_BURST
`ifndef REVX_FETCH_LB_DISABLE
      // BLMOVE bypasses the scalar word engine, so the old "sole RAM writer"
      // invariant no longer holds. Conservatively invalidate both ways of the
      // start and following set. The CPU cannot fetch/read RAM during its move;
      // invalidation continues through commit and the mailbox completion gap.
      // Priority over line publication prevents same-edge stale revalidation.
      if (bulk_invalidate_q) begin
        lb_valid[0][bulk_set_q] <= 1'b0;
        lb_valid[1][bulk_set_q] <= 1'b0;
        lb_valid[0][bulk_next_set_q] <= 1'b0;
        lb_valid[1][bulk_next_set_q] <= 1'b0;
`ifdef REVX_DATA_LB
        dlb_valid[0][bulk_set_q] <= 1'b0;
        dlb_valid[1][bulk_set_q] <= 1'b0;
        dlb_valid[0][bulk_next_set_q] <= 1'b0;
        dlb_valid[1][bulk_next_set_q] <= 1'b0;
`endif
      end
`endif
`endif
    end
  end

  // tie-off unused nvram status
  wire _unused = &{1'b0, nvram_busy, nvram_dirty, cmos_quiesce};
endmodule
`default_nettype wire
