#!/usr/bin/env bash
# All conversion/checks finish before obtaining a shared FIFO ticket.
# enqueue_revx.sh diag|production OR enqueue_revx.sh --prepared /absolute/attempt
set -Eeuo pipefail
export PATH="/c/Python314:/usr/local/bin:/usr/bin:/bin:${PATH:-}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PY=/c/Python314/python.exe
LAUNCHER=/d/deck/fpga/shared_quartus_fifo.sh
# 2026-09-15: re-pinned to the shared launcher that runs job guardian v9 (user-approved). The previous pin
# 657764B7... predated the 2026-09-14 simulator-rule edit, so this check refused every ticket since then.
LAUNCHER_SHA=23D991015E85CCFB760CA96F9203D07361FAFF5F64DF3ABE141BA189F43DF8DF
# MSYS2 runtime 3.5+ (git-bash 2.44+) no longer reliably converts /x/... args for native
# tools; the verify step below must pass Windows paths explicitly.
W() { cygpath -w "$1"; }
RESUME=0
if [ "${1:-}" = --resume ]; then
  RESUME=1; shift
fi
if [ "${1:-}" = --prepared ]; then
  [ "$#" -eq 2 ] || { echo 'usage: enqueue_revx.sh --prepared <attempt>' >&2; exit 2; }
  RUN="$(cd "$2" && pwd)"
else
  VARIANT="${1:-diag}"
  case "$VARIANT" in diag|production) ;; *) echo 'usage: enqueue_revx.sh {diag|production}' >&2; exit 2;; esac
  RUN_WIN="$("$PY" "$ROOT/quartus/revx_build.py" prepare "$ROOT" "$VARIANT")"
  RUN="$(cygpath -u "$RUN_WIN")"
fi
if [ "$RESUME" = 1 ]; then
  "$PY" "$(W "$ROOT/quartus/revx_build.py")" resume-asm "$(W "$ROOT")" "$(W "$RUN")" || {
    echo 'FAIL: resume-asm preparation' >&2; exit 2; }
fi
"$PY" "$(W "$RUN/quartus/revx_build.py")" verify "$(W "$RUN")"
[ "$(sha256sum "$LAUNCHER" | awk '{print toupper($1)}')" = "$LAUNCHER_SHA" ] || {
  echo 'FAIL: shared FIFO launcher differs from reviewed protocol' >&2; exit 2;
}
PAYLOAD="$RUN/quartus/build_revx.sh"
chmod +x "$PAYLOAD"
PAY_SHA="$(sha256sum "$PAYLOAD" | awk '{print toupper($1)}')"
READY_SHA="$(sha256sum "$RUN/ready.json" | awk '{print toupper($1)}')"
JOB="revx:$(basename "$RUN")"
echo "Prepared attempt: $RUN"
echo 'The next controlled worker in this ticket is the pinned Quartus executable.'
export REVX_SHARED_QUARTUS_FIFO=1
set +e
if [ "$RESUME" = 1 ]; then
  "$LAUNCHER" --tag "$JOB" --cwd "$RUN" --log "$RUN/queue" \
    --command-sha256 "$PAY_SHA" \
    --ready-receipt "$RUN/ready.json" --ready-sha256 "$READY_SHA" \
    --expect-first-worker quartus_asm \
    --expect-first-worker-path 'C:\intelFPGA_lite\17.0\quartus\bin64\quartus_asm.exe' \
    --expect-first-worker-sha256 F49DBD0C9659AEA524E013B65F69C612B87D715256E904B10C8D7BEFF32FF6CF \
    -- "$PAYLOAD" --physical
else
  "$LAUNCHER" --tag "$JOB" --cwd "$RUN" --log "$RUN/queue" \
    --command-sha256 "$PAY_SHA" \
    --ready-receipt "$RUN/ready.json" --ready-sha256 "$READY_SHA" \
    --expect-first-worker quartus_map \
    --expect-first-worker-path 'C:\intelFPGA_lite\17.0\quartus\bin64\quartus_map.exe' \
    --expect-first-worker-sha256 3DFB729AF88E2EF6217EC6EA0DBAD305485814B84B46610A1CFD41EFF5DBCD45 \
    -- "$PAYLOAD" --physical
fi
RC=$?
set -e
# Launcher has proved its job empty and released FIFO before collection.
"$PY" "$(W "$RUN/quartus/revx_build.py")" collect "$(W "$RUN")" "$RC"
exit "$RC"
