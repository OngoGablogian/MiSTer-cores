X Unit - Revolution X mouse + sprite cache
RBF SHA-256: 8bd67839b1070c556eaaa331253daddc4c5c34d1753d70439ccbcceb2337d15c

This archive contains the selected integration source and build support files.
Use Quartus 17.0 Lite for the DE10-Nano / Cyclone V target. See the project
QSF/QIP files and build scripts for the source list and conversion steps.
Third-party files retain their individual copyright and license notices.
No game ROMs, personal settings, fitted databases or game traces are included.
ROMs are loaded by MiSTer at runtime; ROM-driven simulations need local game data.

Source identity: production_20260918T223459Z_fe77a81d
The compiled binary's validation status is recorded in the feed catalog.
