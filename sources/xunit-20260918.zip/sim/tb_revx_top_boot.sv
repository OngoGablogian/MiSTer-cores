// tb_revx_top_boot.sv -- BOARD lane step 3 (d): REAL TMS34020 boot in revx_top.
//
// revx_top is built -DREVX_USE_REAL_CPU: the real rtl/tms34010 core (IS_34020) +
// tms34010_mem_if drive the RevX 32-bit bus into the real backends (RAM+ROM on the
// MT48 via revx_sdram_arb, VRAM on SDRAM, gfx on DDR3, CMOS via the nvram bridge).
//
// ROM load: the L2.0 program image (built by gen_revx_prog_rom.py) is preloaded into
// the SDRAM for the bulk (sim speed), while the TOP ~20 KiB that actually holds the
// reset vector (bit-addr 0xFFFFFFE0) AND the boot code the first PCs execute
// (0xFFFDExxx) is DOWNLOADED THROUGH THE hps ioctl PATH WITH THE CORE RESET HELD
// HIGH (P0022) -- so the executed code is genuinely ioctl-delivered.  (The P0022
// download-under-reset mutant is separately gated by tb_revx_top_smoke.)
//
// After reset release the core runs and its per-instruction PC (pc_o @ instruction
// start) is captured and diffed IN ORDER against mame-gospel/trace/revx_l20_main_pc.refpc
// with the duplicate-row rule (skip a refpc/DUT consecutive re-log; skip the leading
// reset DINT at 0xFFFDE000 that precedes the refpc's first row 0xFFFDE010).  Prints
// matched/8000 or the first divergence (row, expected, got) for artifact-vs-RTL
// classification.

`timescale 1ns/1ps
`default_nettype none
module tb_revx_top_boot;
  localparam int    REFN    = 8000;
  // Capture the whole boot PC stream (was 400 -- only enough to reach the fetch-
  // plumbing frontier).  8000 ref rows + a margin for the DUT's own consecutive
  // re-logs (I/O poll spins) collapsed by the dedup rule; ~8000 raw suffice, 9000
  // gives head-room.  cap[]/capi[] size off this.
  localparam int    CAPN    = 9000;
  localparam [20:0] ROM_SDBASE = 21'h100000;            // after 0x80000 RAM words *2 (2 MiB RAM, midxunit.cpp:511)
  localparam int    ROMW    = 32'h100000;               // ROM SDRAM 16-bit words (2 MiB)
  // ioctl-delivered top slice (byte offsets within the 2 MiB image)
  localparam [24:0] DL_LO   = 25'h1FB000;               // ~20 KiB: boot code + reset vector
  localparam [24:0] DL_HI   = 25'h200000;

  logic clk=0, reset=1, pll_locked=0;
  always #5 clk=~clk;
  // Drive cpu_ce at the wrapper's real /4 rate so the top-boot exercises the
  // CE-gated u_mif launch + core boundaries at the shipped enable cadence.
  logic [1:0] cpu_ce_div=2'd0;
  always @(posedge clk) cpu_ce_div<=cpu_ce_div+2'd1;
  wire cpu_ce=(cpu_ce_div==2'd0);
  logic mrst=1; initial begin repeat(3) @(posedge clk); mrst<=1'b0; end

  logic        ioctl_download=0, ioctl_wr=0; logic [7:0] ioctl_index=0;
  logic [24:0] ioctl_addr=0; logic [7:0] ioctl_dout=0; logic dl_ready;
  logic        dma_irq=0;
  logic        cmd_req=0, cmd_we=0; logic [31:0] cmd_addr=0, cmd_wdata=0; logic [3:0] cmd_be=4'hf;
  logic [31:0] cmd_rdata; logic cmd_done;
  logic        scan_start=0; logic [15:0] scan_rowaddr=0, scan_coladdr=0;
  logic [14:0] scan_pixel; logic scan_done;
  logic [31:0] reset_pc; logic int0_seen;
  logic [31:0] cpu_pc; logic cpu_retire; logic [15:0] cpu_instr;

  logic [20:0] sd_addr; logic [15:0] sd_din; logic [1:0] sd_be; logic sd_rd, sd_wr; logic [15:0] sd_dout; logic sd_ack;
  logic [17:0] vd_addr; logic [15:0] vd_din; logic [1:0] vd_be; logic vd_rd, vd_wr; logic [15:0] vd_dout; logic vd_ack;
  logic [17:0] vc_addr; logic [15:0] vc_din; logic [1:0] vc_be; logic vc_rd, vc_wr; logic [15:0] vc_dout; logic vc_ack;
  logic [28:0] g_addr; logic [7:0] g_burst; logic g_rd, g_we; logic [63:0] g_din; logic [7:0] g_be; logic g_busy; logic [63:0] g_dout; logic g_dready;
  // read-burst lane (REVX_FETCH_LB_BURST production path): the backends' line fill asks
  // for 16 consecutive SDRAM words and WAITS on rb_ack; without a responder here the
  // burst-converted netlist deadlocks on its very first fetch (0 retires).  This bench
  // answers from the same sdram_model image the dl flow writes (u_sd.mem), one cycle
  // after the request, so a burst-enabled revx_top boots exactly like the scalar one.
  logic [20:0] rb_addr; logic [4:0] rb_count; logic rb_req, rb_ack; logic [255:0] rb_dout;
  always @(posedge clk) begin
    rb_ack <= 0;
    if (rb_req && !rb_ack) begin
      rb_ack <= 1'b1;
      for (int j = 0; j < 16; j = j + 1) rb_dout[16*j +: 16] <= u_sd.mem[rb_addr + j[3:0]];
    end
  end

`ifdef REVX_BLMOVE_BURST
  logic wb2_req,wb2_ack=0;
  logic [20:0] wb2_addr;
  logic [4:0] wb2_count;
  logic [255:0] wb2_data;
  always @(posedge clk) begin
    wb2_ack<=0;
    if(wb2_req && !wb2_ack) begin
      wb2_ack<=1;
      for(integer j=0;j<16;j++) if(j<wb2_count)
        u_sd.mem[wb2_addr+j] <= wb2_data[16*j+:16];
    end
  end
`endif
`ifdef REVX_VRAM_LB
  logic vlb_req,vlb_ack=0;
  logic [17:0] vlb_addr;
  logic [4:0] vlb_count;
  logic [255:0] vlb_data;
  always @(posedge clk) begin
    vlb_ack<=0;
    if(vlb_req && !vlb_ack) begin
      vlb_ack<=1;
      for(integer j=0;j<16;j++) if(j<vlb_count)
        vlb_data[16*j+:16] <= u_vdm.mem[vlb_addr+j];
    end
  end
`endif

  revx_top #(.SD_AW(21), .VSD_AW(18), .ROM_SDBASE(ROM_SDBASE), .RESET_PC(32'hFFFDE010)) dut (
    .clk(clk), .reset(reset), .pll_locked(pll_locked), .cpu_ce(cpu_ce),
    .ioctl_download(ioctl_download), .ioctl_wr(ioctl_wr), .ioctl_index(ioctl_index),
    .ioctl_addr(ioctl_addr), .ioctl_dout(ioctl_dout), .dl_ready(dl_ready),
    .dma_irq(dma_irq),
    .cmd_req(cmd_req), .cmd_we(cmd_we), .cmd_addr(cmd_addr), .cmd_be(cmd_be),
    .cmd_wdata(cmd_wdata), .cmd_rdata(cmd_rdata), .cmd_done(cmd_done),
    .scan_start(scan_start), .scan_rowaddr(scan_rowaddr), .scan_coladdr(scan_coladdr),
    .scan_pixel(scan_pixel), .scan_done(scan_done),
    .reset_pc(reset_pc), .int0_seen(int0_seen), .cpu_pc(cpu_pc), .cpu_retire(cpu_retire), .cpu_instr(cpu_instr),
    .sd_addr(sd_addr), .sd_din(sd_din), .sd_be(sd_be), .sd_rd(sd_rd), .sd_wr(sd_wr), .sd_dout(sd_dout), .sd_ack(sd_ack),
    .vd_addr(vd_addr), .vd_din(vd_din), .vd_be(vd_be), .vd_rd(vd_rd), .vd_wr(vd_wr), .vd_dout(vd_dout), .vd_ack(vd_ack),
    .vc_addr(vc_addr), .vc_din(vc_din), .vc_be(vc_be), .vc_rd(vc_rd), .vc_wr(vc_wr), .vc_dout(vc_dout), .vc_ack(vc_ack),
    .gfx_ddram_addr(g_addr), .gfx_ddram_burstcnt(g_burst), .gfx_ddram_rd(g_rd), .gfx_ddram_we(g_we),
    .gfx_ddram_din(g_din), .gfx_ddram_be(g_be), .gfx_ddram_busy(g_busy), .gfx_ddram_dout(g_dout), .gfx_ddram_dout_ready(g_dready),
    .rb_addr(rb_addr), .rb_count(rb_count), .rb_req(rb_req), .rb_dout(rb_dout), .rb_ack(rb_ack)
`ifdef REVX_BLMOVE_BURST
    , .wb2_req(wb2_req),.wb2_addr(wb2_addr),.wb2_count(wb2_count),.wb2_data(wb2_data),.wb2_ack(wb2_ack)
`endif
`ifdef REVX_VRAM_LB
    , .vlb_rb_req(vlb_req),.vlb_rb_addr(vlb_addr),.vlb_rb_count(vlb_count),.vlb_rb_dout(vlb_data),.vlb_rb_ack(vlb_ack)
`endif
);

  sdram_model #(.AW(21), .LATENCY(2)) u_sd  (.clk(clk), .rst(mrst), .addr(sd_addr), .din(sd_din), .be(sd_be), .rd(sd_rd), .wr(sd_wr), .dout(sd_dout), .ack(sd_ack));
  sdram_model #(.AW(18), .LATENCY(2)) u_vdm (.clk(clk), .rst(mrst), .addr(vd_addr), .din(vd_din), .be(vd_be), .rd(vd_rd), .wr(vd_wr), .dout(vd_dout), .ack(vd_ack));
  sdram_model #(.AW(18), .LATENCY(2)) u_vcm (.clk(clk), .rst(mrst), .addr(vc_addr), .din(vc_din), .be(vc_be), .rd(vc_rd), .wr(vc_wr), .dout(vc_dout), .ack(vc_ack));
  ddr3_avalon_model #(.BASE(29'h6800000), .SW(14), .INIT_MEM(1)) u_ddr (.clk(clk), .rst(mrst),
    .addr(g_addr), .burstcnt(g_burst), .rd(g_rd), .we(g_we), .din(g_din), .be(g_be), .busy(g_busy), .dout(g_dout), .dout_ready(g_dready),
    .cfg_busy(8'd1), .cfg_rlat(8'd2), .cfg_maxburst(8'd0), .cfg_gapevery(8'd0), .cfg_ignore_be(1'b0), .cfg_write_lat(8'd0), .err_count());

  // ---- ROM image + golden refpc ----
  logic [15:0] romhex [0:ROMW-1];
  logic [31:0] refpc    [0:REFN-1];
  logic [31:0] cap    [0:CAPN-1];
  logic [15:0] capi   [0:CAPN-1];
  int capn;
  // deduped streams (consecutive-dup collapse, SAME rule as the CPU-lane
  // tb_020_boot_smoke bench so "8000/8000" means the same in both lanes)
  logic [31:0] ref_dd  [0:REFN-1];
  int unsigned ref_dd_raw [0:REFN-1];
  logic [31:0] dut_dd  [0:CAPN-1];
  logic [31:0] rom_vec;      // ROM reset vector (bit-addr 0xFFFFFFE0), positive reset check
  logic [15:0] rom_op0;      // opcode at the vector (must be DINT 0x0360)
  int          cover_raw;    // raw ref rows covered (8000 on a full pass)
  logic        diverged;     // a real PC divergence (not a dup/run-out) was seen

  function automatic [7:0] img_byte(input [24:0] a);
    logic [15:0] w; w = romhex[a[20:1]];               // SDRAM word = byte>>1
    img_byte = a[0] ? w[15:8] : w[7:0];
  endfunction

  task automatic ioctl_byte(input [24:0] a, input [7:0] d);
    int to;
    @(posedge clk); ioctl_addr<=a; ioctl_dout<=d; ioctl_wr<=1'b1;
    @(posedge clk); ioctl_wr<=1'b0;
    to=0; while(dl_ready && to<50)  begin @(posedge clk); to++; end
    to=0; while(!dl_ready && to<200) begin @(posedge clk); to++; end
  endtask

  // ---- capture per-instruction PC at instruction start ----
  always_ff @(posedge clk)
    if (!reset && cpu_retire && capn < CAPN) begin cap[capn] <= cpu_pc; capi[capn] <= cpu_instr; capn <= capn + 1; end

  integer i, m; int errs;
  initial begin
    errs=0; capn=0;
    $readmemh("sim/build/revx_prog_rom.hex", romhex);
    $readmemh("sim/build/revx_main_pc_ref.hex", refpc);
    // preload the BULK ROM into SDRAM (bytes 0 .. DL_LO-1); the top slice is ioctl'd.
    for (m=0; m<(DL_LO>>1); m++) u_sd.mem[ROM_SDBASE + m] = romhex[m];

    // power-on: PLL locks, core reset HELD HIGH across the whole download (P0022)
    pll_locked<=1'b0; reset<=1'b1; repeat(4) @(posedge clk);
    pll_locked<=1'b1; repeat(8) @(posedge clk);

    ioctl_download<=1'b1; ioctl_index<=8'd0;
    for (i=DL_LO; i<DL_HI; i++) ioctl_byte(i[24:0], img_byte(i[24:0]));
    ioctl_download<=1'b0; repeat(4) @(posedge clk);

    // verify a couple of ioctl'd words landed (reset vector + boot start) via SDRAM
    if (u_sd.mem[ROM_SDBASE + 21'((25'h1FFFFC)>>1)]     !== romhex[(25'h1FFFFC)>>1])
      begin $display("FAIL: ioctl reset-vector lo half not landed"); errs++; end

    // release the core reset (NEVER before the download -- P0022) and run
    reset<=1'b0;
    begin int g; g=0; while (capn < CAPN && g < 40_000_000) begin @(posedge clk); g++; end end

`ifdef REVX_BOOT_DUMP
    begin int q; $display("---- DUT cap[0..30] vs ref[0..30] ----");
      for (q=0;q<31;q++) $display("  %2d  cap=%08H instr=%04H  ref=%08H", q, cap[q], capi[q], refpc[q]); end
`endif
    // ---- diff vs refpc: dedup BOTH streams (dup rule) + positive reset check ----
    diff_pc();
    if (capn < 32) begin $display("FAIL: CPU captured only %0d PCs (harness/boot dead)", capn); errs++; end
    // STRICT verdict: PASS only on a full 8000/8000 raw-row cover with the reset
    // vector verified and no real divergence.  A measured frontier is still reported
    // by diff_pc() (a valid deliverable, DESIGN-RULES.md s.2) but FAILS the gate.
    if (errs==0 && !diverged && cover_raw >= REFN)
      $display("TEST_RESULT: PASS (revx_top_boot: 8000/8000 in order, dup-rule applied; reset-vector verified)");
    else if (errs != 0)
      $display("TEST_RESULT: FAIL: %0d harness error(s)", errs);
    else
      $display("TEST_RESULT: FAIL: boot frontier -- covered %0d of %0d raw ref rows", cover_raw, REFN);
    $finish;
  end

  // in-order PC diff -- dedup BOTH streams then compare, IDENTICAL method to the
  // CPU-lane tb_020_boot_smoke (DESIGN-RULES.md s.5: same oracle both lanes).  The positive
  // reset-vector check REPLACES the old silent leading-DINT skip: the DUT's first
  // retired PC MUST equal the ROM reset vector (32-bit word at bit addr 0xFFFFFFE0)
  // and the opcode there MUST be DINT 0x0360, both read from the loaded ROM image.
  // MAME logs from the 2nd instruction (ref row 0 = FFFDE010), so the compare starts
  // at deduped DUT index 1.  Sets cover_raw (raw ref rows covered) and diverged.
  task automatic diff_pc();
    int rn, dn, k, matched, start_off;
    cover_raw = 0; diverged = 1'b0;
    rn = 0;
    for (int t = 0; t < REFN; t++)
      if (t==0 || refpc[t] !== refpc[t-1]) begin ref_dd[rn]=refpc[t]; ref_dd_raw[rn]=t; rn=rn+1; end
    dn = 0;
    for (int t = 0; t < capn; t++)
      if (t==0 || cap[t] !== cap[t-1]) begin dut_dd[dn]=cap[t]; dn=dn+1; end
    rom_vec = {romhex[20'hFFFFF], romhex[20'hFFFFE]};   // bit addr 0xFFFFFFE0/F0
    rom_op0 = romhex[rom_vec[23:4]];                    // opcode word at the reset vector
    if (rom_vec !== 32'hFFFDE000 || rom_op0 !== 16'h0360) begin
      $display("BOOT: FAIL -- ROM image reset vector/opcode unexpected: vec=%08H op=%04H (expect FFFDE000 / 0360)", rom_vec, rom_op0);
      diverged = 1'b1; return;
    end
    if (dn < 2 || dut_dd[0] !== rom_vec) begin
      $display("BOOT: FAIL -- DUT first retired PC %08H != ROM reset vector %08H", (dn>0)?dut_dd[0]:32'hxxxxxxxx, rom_vec);
      diverged = 1'b1; return;
    end
    $display("BOOT: reset-vector check OK -- DUT first PC %08H == ROM vector, opcode %04H (DINT); ref starts next", dut_dd[0], rom_op0);
    start_off = 1;
    matched = 0;
    for (k = 0; k < rn; k++) begin
      if ((start_off + k) >= dn) begin
        $display("BOOT: RAN OUT of DUT PCs at deduped idx %0d (raw ref row %0d, expected %08H); captured %0d dedup %0d",
                 k, ref_dd_raw[k], ref_dd[k], capn, dn);
        break;
      end else if (dut_dd[start_off + k] !== ref_dd[k]) begin
        $display("FRONTIER: first divergence at ref_row=%0d expected=%08H got=%08H (dedup_idx=%0d)",
                 ref_dd_raw[k], ref_dd[k], dut_dd[start_off + k], k);
        $display("DIVERGE_EXP=%08H", ref_dd[k]);
        $display("DIVERGE_GOT=%08H", dut_dd[start_off + k]);
        diverged = 1'b1; break;
      end else matched = matched + 1;
    end
    cover_raw = (matched >= rn) ? REFN : ref_dd_raw[matched];
    $display("CHECKS: matched_dedup=%0d of %0d; raw ref rows covered=%0d/%0d; captured=%0d dedup=%0d",
             matched, rn, cover_raw, REFN, capn, dn);
    if (cover_raw >= REFN) $display("BOOT: 8000/8000 PC MATCH");
    else                   $display("BOOT: FRONTIER at raw ref row %0d (%0d/%0d covered)", cover_raw, cover_raw, REFN);
  endtask

  initial begin #400_000_000; $display("FAIL: hard timeout capn=%0d", capn); $finish; end
endmodule
`default_nettype wire
