// sim/revx_elab_stubs.v -- iverilog EMU-ELAB stubs (NOT for synthesis; not in any .qip).
// These stand in for standard MiSTer chassis modules that iverilog structurally cannot
// elaborate; they are Quartus-native/IP in a real build and are NOT RevX-authored logic.
//  * pll          : Altera PLL megafunction (rtl/pll) -- IP, not source.
//  * arcade_video : chassis video scaler subtree (sys/arcade_video.v -> video_mixer -> Hq2x);
//                   sys/hq2x.sv trips an iverilog l-value limitation.  Passthrough stub with the
//                   emu's exact port set so the emu's video-out wiring is still bind-checked.
module pll(input rst,input refclk,output outclk_0,output outclk_1,output outclk_2,output outclk_3,output locked);
  assign outclk_0=refclk; assign outclk_1=refclk; assign outclk_2=refclk; assign outclk_3=refclk; assign locked=1'b1;
endmodule
module arcade_video #(parameter WIDTH=320, parameter DW=16, parameter GAMMA=0)
( input clk_video, input ce_pix, input [DW-1:0] RGB_in, input HBlank, input VBlank, input HSync, input VSync,
  output CLK_VIDEO, output CE_PIXEL, output [7:0] VGA_R, output [7:0] VGA_G, output [7:0] VGA_B,
  output VGA_HS, output VGA_VS, output VGA_DE, output [1:0] VGA_SL,
  input [2:0] fx, input forced_scandoubler, inout [21:0] gamma_bus );
  assign CLK_VIDEO=clk_video; assign CE_PIXEL=ce_pix;
  assign VGA_R=RGB_in[DW-1 -:8]; assign VGA_G=RGB_in[(DW*2/3)-1 -:8]; assign VGA_B=RGB_in[7:0];
  assign VGA_HS=HSync; assign VGA_VS=VSync; assign VGA_DE=~(HBlank|VBlank); assign VGA_SL=2'b00;
endmodule
