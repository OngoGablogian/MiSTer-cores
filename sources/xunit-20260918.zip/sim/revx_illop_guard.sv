// revx_illop_guard.sv -- discriminating guard for the CONVERTED-NETLIST boot gate
// (sim/run_revx_converted_boot.sh).  Observer-only; instantiated as a second sim root
// alongside tb_revx_top_boot.  It touches no RTL and does not modify the bench.
//
// WHY IT EXISTS (measured 2026-09-07, this tree):
//   The 8000-row cold-boot PC diff (tb_revx_top_boot) CANNOT tell a 34010-mode netlist
//   from a 34020-mode one.  Measured: the d0320523 (TMS_IS_34020 baked 1'b0) and 524cbd24
//   (1'b1) converted netlists BOTH pass 8000/8000 with BYTE-IDENTICAL captured PC streams.
//   Reasons: (a) the whole 8000-row boot window executes from ROM (FFFDE010..FFFFAA70) and
//   never jumps into RAM a block-move would populate; (b) the fold that IS_34020=0 causes --
//   the 34020 BLMOVE decode arm going away so cold-boot instr #14 (0x00F3 BLMOVE @ FFFDE1E0)
//   is not recognised -- does NOT trap: tms34010_core's illegal handling is a sticky
//   observability latch (tms34010_core.sv:337-344 "Phase 3 skeleton ... cleared only by
//   reset"), so the PC advances past it (FFFDE1E0 -> FFFDE1F0 -> ...) and the PC diff passes.
//   That is the exact "sim green, cab black" seam of DESIGN-RULES.md s.6: on silicon the missing
//   block-move later derails the boot ("ends in the system font"), far beyond 8000 rows.
//
// THE DISCRIMINATOR: tms34010_core.illegal_q.  A 34010-mode netlist latches it during boot
//   (at the BLMOVE, instr 0x00F3); a correct 34020-mode netlist never latches it across the
//   whole valid boot ROM.  This is the check that makes the converted-boot gate FAIL when the
//   TMS_IS_34020 fix is reverted (DESIGN-RULES.md s.5 coverage-check).  Path is
//   tb_revx_top_boot.dut.u_cpu.illegal_q -- if a build shipped the placeholder CPU
//   (-DREVX_USE_BFM_CPU, which preflight check (3) forbids) u_cpu has no illegal_q and this
//   guard fails to elaborate, which the runner reports as a gate failure.
`timescale 1ns/1ps
module revx_illop_guard;
  integer cyc = 0;
  reg     latched = 1'b0;
  integer at_cyc;
  reg [31:0] at_pc;
  reg [15:0] at_instr;
  always @(posedge tb_revx_top_boot.clk) if (!tb_revx_top_boot.reset) begin
    cyc = cyc + 1;
    if (!latched && tb_revx_top_boot.dut.u_cpu.illegal_q) begin
      latched  = 1'b1;
      at_cyc   = cyc;
      at_pc    = tb_revx_top_boot.cpu_pc;
      at_instr = tb_revx_top_boot.cpu_instr;
    end
  end
  final begin
    if (latched)
      $display("ILLOP-GUARD: FAIL -- CPU illegal-opcode latch set at cyc=%0d cpu_pc=%08h instr=%04h; 34010-mode BLMOVE fold, no trap taken so the 8000-row PC diff cannot see it (TMS_IS_34020 baked 1'b0)", at_cyc, at_pc, at_instr);
    else
      $display("ILLOP-GUARD: CLEAN -- CPU illegal-opcode latch never set across the boot (34020 decode live)");
  end
endmodule
