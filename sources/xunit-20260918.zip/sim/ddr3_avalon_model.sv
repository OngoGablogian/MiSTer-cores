// ddr3_avalon_model.sv — FAITHFUL behavioral model of the DE10-Nano HPS f2h_sdram1
// Avalon-MM burst slave (the DDRAM_* port). This is the ORACLE for every VRAM-to-DDR3
// phase, so it is authored to the AUTHORITATIVE contract (sysmem.sv / f2sdram_safe_
// terminator.sv / ddr_svc.sv), NOT copied from jtframe_ddr_model.v — that reference model
// HARDWIRES `assign busy = 0;` (line 57, real logic commented out) and so physically cannot
// catch a master that mutates command lines during BUSY or writes to base-0. A charitable
// oracle passes sim then blacks the cab; this one traps the five silicon-only bug classes:
//
//   (1) command mutated while BUSY high          -> $display + err_count++
//   (2) write latched on a BUSY cycle            -> impossible by construction (commit only
//                                                    in M_WACC where busy==0)
//   (3) wrong DOUT_READY beat count              -> emits EXACTLY burstcnt pulses
//   (4) base-0 / out-of-{4'd3}-window address    -> region_check err_count++
//   (5) read data latched on a non-ready cycle   -> dout driven X unless dout_ready
//
// Protocol (verified against NS objddr/objld usage + sysmem.sv):
//   * ADDR is a 64-bit-BEAT index (NS base = byte>>3, +1/beat). NOT byte-addressed.
//   * waitrequest (busy): master must hold ADDR/RD/WE/BURSTCNT/DIN/BE constant while high;
//     a request beat is accepted on the cycle it is asserted AND busy==0.
//   * read: after accept + first-word latency, emit burstcnt dout_ready pulses, one per beat,
//     presenting mem[addr+beat] on dout the same cycle.
// cfg_busy / cfg_rlat are runtime inputs so one TB run covers multiple latency profiles.
`default_nettype none
module ddr3_avalon_model #(
    parameter [28:0] BASE = 29'h6400000,   // VRAM DDR window base (must match the agent), byte 0x32000000
    parameter integer SW  = 18,            // window size = 2^SW beats (256K beats = 2 MB)
    parameter integer INIT_MEM = 1,        // disable when a testbench supplies its own pattern
    parameter integer CFG_W = 8            // widen in focused tests that outlast production guards
)(
    input wire             clk,
    input wire             rst,             // models f2sdram_safe_terminator draining/reset on sdram_por
    // ---- Avalon slave (faces the agent's master) ----
    input wire      [28:0] addr,
    input wire      [ 7:0] burstcnt,
    input wire             rd,
    input wire             we,
    input wire      [63:0] din,
    input wire      [ 7:0] be,
    output reg        busy,
    output reg [63:0] dout,
    output reg        dout_ready,
    // ---- runtime config + violation counter ----
    input wire      [CFG_W-1:0] cfg_busy,         // backpressure cycles per transaction (>=1)
    input wire      [ 7:0] cfg_rlat,             // read first-word latency
    // FAITHFULNESS: the real HPS f2sdram is NOT a gapless full-length-burst slave. cfg_maxburst
    // models a controller that only returns min(burstcnt,maxburst) beats per read (NS used 32-
    // beat bursts on HW; a longer burst may under-deliver). cfg_gapevery inserts a DOUT_READY gap
    // every N beats (refresh / bank management). Both default 0 = old gapless behavior.
    input wire      [ 7:0] cfg_maxburst,         // 0 = unlimited; else cap beats-returned to this
    input wire      [ 7:0] cfg_gapevery,         // 0 = no gaps; else 1 idle DOUT_READY cycle every N beats
    // FAITHFULNESS (write side): the real HPS f2h_sdram1 is NOT guaranteed to honor per-byte
    // write-enables (BE) on a SINGLE-BEAT burst — some Avalon f2sdram bridges only apply BE on
    // full-width/multi-beat transfers and write the WHOLE 64-bit din on a 1-beat masked write.
    // cfg_ignore_be=1 models that silicon-worst-case (writes all 8 bytes, ignoring cBE). Default 0
    // = the BE-honoring behavior a correct DDR would give. This is the write-side twin of
    // cfg_maxburst: a charitable BE-honoring oracle passes sim then paints the cab white/purple
    // (masked lane writes clobber their 3 neighbor entries in the shared beat).
    input wire             cfg_ignore_be,         // 0 = honor BE (correct DDR); 1 = write full din (BE dropped)
    // FAITHFULNESS (posted writes): the real f2h_sdram1 ACCEPTS a write before the data is committed to
    // DRAM, so a READ issued shortly after (a separate transaction to the same beat) can return STALE
    // data. cfg_write_lat=N holds each accepted write "in flight" (not yet in mem) until the NEXT write
    // accepts (flush) or N cycles elapse (backstop) — a read in between sees the pre-write value. This
    // is the exact hazard that failed the cab VRAM self-test: a per-entry read-modify-write re-reads
    // the beat for the next entry and gets the neighbor's stale value. Default 0 = commit-on-accept.
    input wire      [CFG_W-1:0] cfg_write_lat,
    output reg [31:0] err_count
);
    localparam integer WORDS = (1<<SW);
    reg [63:0] mem [0:WORDS-1];

    localparam M_IDLE=0, M_WBP=1, M_WACC=2, M_RBP=3, M_RACC=4, M_RLAT=5, M_RSTREAM=6, M_WSTREAM=7;
    reg [3:0]     ms;
    reg [CFG_W-1:0] bp;
    reg [7:0]     lat, rem, gapcnt;
    reg [SW-1:0]  aidx;
    reg [7:0]     wbeat, wlim;   // write-burst: current beat, commit limit = min(cB,maxburst)
    reg [SW-1:0]  wa;            // write-burst base word index
    reg [28:0]    cA;  reg [7:0] cB;  reg [7:0] cBE;  reg [63:0] cD;   // captured command
    reg           pw_v;  reg [SW-1:0] pw_i;  reg [63:0] pw_d;  reg [7:0] pw_be;  reg [CFG_W-1:0] pw_c;  // posted write in flight
    integer i, k, j;

    task region_check(input [28:0] a);
        begin
            if (a[28:25] !== 4'd3) begin
                err_count = err_count + 1;
                $display("[ddr3_model] ERROR base-0/region: addr=%h nibble[28:25]=%h (must be 4'd3)", a, a[28:25]);
            end
            if (a < BASE || a >= (BASE + WORDS)) begin
                err_count = err_count + 1;
                $display("[ddr3_model] ERROR out-of-window: addr=%h not in [%h,%h)", a, BASE, (BASE+WORDS));
            end
        end
    endtask

    task chk_stable_wr;
        begin
            if (!we)            begin err_count=err_count+1; $display("[ddr3_model] ERROR: WE dropped during write backpressure"); end
            if (addr !== cA)    begin err_count=err_count+1; $display("[ddr3_model] ERROR: ADDR mutated during BUSY (%h->%h)", cA, addr); end
            if (burstcnt !== cB)begin err_count=err_count+1; $display("[ddr3_model] ERROR: BURSTCNT mutated during BUSY (%0d->%0d)", cB, burstcnt); end
            if (be !== cBE)     begin err_count=err_count+1; $display("[ddr3_model] ERROR: BE mutated during BUSY (%h->%h)", cBE, be); end
            if (din !== cD)     begin err_count=err_count+1; $display("[ddr3_model] ERROR: DIN mutated during BUSY (%h->%h)", cD, din); end
        end
    endtask

    task chk_stable_rd;
        begin
            if (!rd)            begin err_count=err_count+1; $display("[ddr3_model] ERROR: RD dropped during read backpressure"); end
            if (addr !== cA)    begin err_count=err_count+1; $display("[ddr3_model] ERROR: ADDR mutated during BUSY (%h->%h)", cA, addr); end
            if (burstcnt !== cB)begin err_count=err_count+1; $display("[ddr3_model] ERROR: BURSTCNT mutated during BUSY (%0d->%0d)", cB, burstcnt); end
        end
    endtask

    initial begin
        ms = M_IDLE; busy = 1'b1; dout = 64'bx; dout_ready = 1'b0; err_count = 0;
        bp = 0; lat = 0; rem = 0; aidx = 0; cA = 0; cB = 0; cBE = 0; cD = 0; pw_v = 0; pw_c = 0;
        if (INIT_MEM) for (k = 0; k < WORDS; k = k + 1) mem[k] = 64'd0;
    end

    always @(posedge clk) begin
        dout       <= 64'bx;    // read data invalid unless presented WITH dout_ready
        dout_ready <= 1'b0;
        if (rst) begin
            ms <= M_IDLE; busy <= 1'b1; bp <= 0; lat <= 0; rem <= 0; pw_v <= 1'b0; wbeat <= 0; wlim <= 0;
        end else begin
        // posted-write backstop: an accepted write commits to mem after cfg_write_lat cycles (or is
        // flushed early by the next write in M_WACC). Until then reads see the PRE-write mem.
        if (pw_v && (pw_c <= 8'd1)) begin
            for (j=0;j<8;j=j+1) if (cfg_ignore_be || pw_be[j]) mem[pw_i][8*j +: 8] <= pw_d[8*j +: 8];
            pw_v <= 1'b0;
        end else if (pw_v) pw_c <= pw_c - 8'd1;
        case (ms)
            M_IDLE: begin
                busy <= 1'b1;                       // hold busy high so a fresh request is never falsely accepted
                if (we) begin
                    cA<=addr; cB<=burstcnt; cBE<=be; cD<=din; region_check(addr);
                    bp <= (cfg_busy==8'd0) ? 8'd1 : cfg_busy; ms <= M_WBP;
                end else if (rd) begin
                    cA<=addr; cB<=burstcnt; region_check(addr);
                    bp <= (cfg_busy==8'd0) ? 8'd1 : cfg_busy; ms <= M_RBP;
                end
            end
            M_WBP: begin
                busy <= 1'b1; chk_stable_wr;
                if (bp <= 8'd1) begin busy <= 1'b0; ms <= M_WACC; end   // release for the accept cycle
                else bp <= bp - 8'd1;
            end
            M_WACC: begin                            // busy==0 this cycle -> master (WE && !busy) accepts here
                chk_stable_wr;
                // cfg_ignore_be=1: bridge drops per-byte BE on a 1-beat write. cfg_write_lat>0: POSTED
                // write -> hold this beat in flight (reads see stale) until flush/backstop.
                if (cfg_write_lat == 8'd0) begin
                    for (i=0;i<8;i=i+1) if (cfg_ignore_be || cBE[i]) mem[cA-BASE][8*i +: 8] <= cD[8*i +: 8];
                end else begin
                    if (pw_v) for (i=0;i<8;i=i+1) if (cfg_ignore_be || pw_be[i]) mem[pw_i][8*i +: 8] <= pw_d[8*i +: 8];
                    pw_v<=1'b1; pw_i<=cA-BASE; pw_d<=cD; pw_be<=cBE; pw_c<=cfg_write_lat;
                end
                if (cB <= 8'd1) begin
                    busy <= 1'b1; ms <= M_IDLE;                 // single beat (unchanged)
                end else begin                                  // WRITE BURST: stream beats 1..cB-1
                    wa    <= cA - BASE;
                    wbeat <= 8'd1;                               // beat 0 committed above
                    // faithful UNDER-DELIVERY: commit only min(cB,maxburst) beats; drop the rest
                    wlim  <= (cfg_maxburst != 8'd0 && cB > cfg_maxburst) ? cfg_maxburst : cB;
                    busy  <= 1'b0;                               // keep accepting (gapless stream)
                    ms    <= M_WSTREAM;
                end
            end
            M_WSTREAM: begin                                     // one master beat / cycle; 'din' = current beat
                busy <= 1'b0;
                if (wbeat < wlim) begin                          // within the deliverable window -> commit
                    if (cfg_write_lat == 8'd0) begin
                        for (i=0;i<8;i=i+1) if (cfg_ignore_be || be[i]) mem[wa+wbeat][8*i +: 8] <= din[8*i +: 8];
                    end else begin                              // 1-deep posted-write chain (burst tail stays posted)
                        if (pw_v) for (i=0;i<8;i=i+1) if (cfg_ignore_be || pw_be[i]) mem[pw_i][8*i +: 8] <= pw_d[8*i +: 8];
                        pw_v<=1'b1; pw_i<=wa+wbeat; pw_d<=din; pw_be<=be; pw_c<=cfg_write_lat;
                    end
                end                                             // else: beat DROPPED (beyond maxburst) = data loss (the gate signal)
                if (wbeat == cB - 8'd1) begin busy <= 1'b1; ms <= M_IDLE; end
                else wbeat <= wbeat + 8'd1;
            end
            M_RBP: begin
                busy <= 1'b1; chk_stable_rd;
                if (bp <= 8'd1) begin busy <= 1'b0; ms <= M_RACC; end
                else bp <= bp - 8'd1;
            end
            M_RACC: begin                            // busy==0 -> master (RD && !busy) accepts, drops RD
                chk_stable_rd;
                // An exact single-beat readback is the ordered publication primitive used by the
                // VRAM scan fence. The bridge may post a write relative to unrelated/burst reads,
                // but a RAW access to that same beat must retire the write before returning data.
                // Completion therefore remains meaningful when old and new data are numerically equal.
                if (cB <= 8'd1 && pw_v && (pw_i == (cA - BASE))) begin
                    for (i=0;i<8;i=i+1)
                        if (cfg_ignore_be || pw_be[i]) mem[pw_i][8*i +: 8] <= pw_d[8*i +: 8];
                    pw_v <= 1'b0;
                end
                // beats returned = min(burstcnt, cfg_maxburst) -- a real bridge with a max burst
                // UNDER-DELIVERS a longer request (the exact silicon behavior my gapless model missed).
                aidx <= cA - BASE;
                rem  <= (cfg_maxburst != 8'd0 && cB > cfg_maxburst) ? cfg_maxburst : cB;
                lat  <= cfg_rlat; gapcnt <= 8'd0;
                busy <= 1'b1; ms <= M_RLAT;
            end
            M_RLAT: begin
                busy <= 1'b1;
                if (lat == 8'd0) ms <= M_RSTREAM;
                else lat <= lat - 8'd1;
            end
            M_RSTREAM: begin                         // emit min(burstcnt,maxburst) beats, gap every cfg_gapevery
                busy <= 1'b1;
                if (cfg_gapevery != 8'd0 && gapcnt >= cfg_gapevery) begin
                    gapcnt <= 8'd0;                  // GAP: idle DOUT_READY cycle (no beat, no advance)
                end else begin
                    dout       <= mem[aidx];
                    dout_ready <= 1'b1;
                    aidx       <= aidx + 1'b1;
                    gapcnt     <= gapcnt + 8'd1;
                    if (rem <= 8'd1) ms <= M_IDLE;
                    rem <= rem - 8'd1;
                end
            end
            default: ms <= M_IDLE;
        endcase
        end
    end
endmodule
`default_nettype wire
