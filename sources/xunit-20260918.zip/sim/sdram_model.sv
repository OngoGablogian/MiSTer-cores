// sdram_model.sv — Phase 6 W1f: behavioral 16-bit word SDRAM for sim gating.
// Models the single-word channel the Y-unit talks to (srg320 sdram1.sv `ch2`-style):
//   * a request is accepted on the RISING edge of (rd|wr) while idle (srg320 edge-detect
//     `ch2rd && !old_rd2` — robust against the requester holding the line past ack);
//   * the requester holds rd/wr + addr (+din/be) until `ack`, then drops them;
//   * `ack` pulses 1 cycle when the access completes; read `dout` is valid on ack.
// LATENCY (>=1) = cycles from acceptance to ack — a TB proves engines are latency-tolerant
// by verifying byte-identical at LATENCY=1 AND a large value. Word-addressed; `be` is the
// per-byte write mask.
`timescale 1ns/1ps
`default_nettype none
module sdram_model #(
  parameter int AW      = 21,        // word-address width (2^21 = 2M words = 4MB)
  parameter int LATENCY = 4,         // acceptance -> ack, in clk cycles (>=1)
  parameter     HEXFILE = "",        // optional $readmemh preload (word data)
  // DIAG v4a option (MUT_MODEL_IGNORE_WMASK): when 1 this model IGNORES the byte-enable write
  // mask and commits BOTH bytes on every write (a chip that does not honour DQM on writes -- the
  // RevX cabinet-3 fault).  Set ONLY on the main-RAM/ROM SDRAM (which revx_word_sdram feeds) to
  // prove read-modify-write removes the DQM dependence there: with RMW ON the engine only ever
  // issues be=11 writes so ignoring the mask is harmless (gate PASSES); with RMW OFF the native
  // partial writes corrupt the neighbouring byte (gate FAILS).  Default 0 (mask honoured).
  parameter bit IGNORE_WMASK = 1'b0
)(
  input  logic            clk,
  input  logic            rst,
  input  logic [AW-1:0]   addr,      // word address
  input  logic [15:0]     din,       // write data
  input  logic [1:0]      be,        // byte enables: [0]=low byte, [1]=high byte
  input  logic            rd,        // read request  (held until ack)
  input  logic            wr,        // write request (held until ack)
  output logic [15:0]     dout,      // read data (valid on ack)
  output logic            ack        // 1-cycle completion strobe
);
  logic [15:0] mem [0:(1<<AW)-1];
  initial begin
    for (int i=0;i<(1<<AW);i++) mem[i]=16'h0000;
    if (HEXFILE != "") $readmemh(HEXFILE, mem);
  end

  logic        reqd, busy;
  integer      cnt;
  logic [AW-1:0] a_l; logic [15:0] d_l; logic [1:0] be_l; logic wr_l;

  // plain always (not always_ff): `mem` is also written by the `initial` preload above,
  // which always_ff forbids (Questa vopt-7061). Same reason as yunit_mem's arrays.
  always @(posedge clk) begin
    if (rst) begin
      busy <= 1'b0; ack <= 1'b0; reqd <= 1'b0; cnt <= 0;
    end else begin
      ack  <= 1'b0;
      reqd <= (rd | wr);
      if (!busy) begin
        if ((rd | wr) & ~reqd) begin       // accept on rising edge of a request
          a_l  <= addr; d_l <= din; be_l <= be; wr_l <= wr;
          busy <= 1'b1;
          cnt  <= (LATENCY <= 1) ? 0 : (LATENCY - 1);
        end
      end else begin
        if (cnt == 0) begin                // access completes
          if (wr_l) begin
            // IGNORE_WMASK=1 commits BOTH bytes regardless of be (the cabinet-3 write-DQM fault).
            if (be_l[0] | IGNORE_WMASK) mem[a_l][7:0]  <= d_l[7:0];
            if (be_l[1] | IGNORE_WMASK) mem[a_l][15:8] <= d_l[15:8];
            dout <= { (be_l[1] | IGNORE_WMASK) ? d_l[15:8] : mem[a_l][15:8],
                      (be_l[0] | IGNORE_WMASK) ? d_l[7:0]  : mem[a_l][7:0] };
          end else begin
            dout <= mem[a_l];
          end
          ack  <= 1'b1;
          busy <= 1'b0;
        end else begin
          cnt <= cnt - 1;
        end
      end
    end
  end
endmodule
`default_nettype wire
