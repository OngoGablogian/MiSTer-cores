// Exidy 440 output mixer: eight sample x volume products (four channels x
// left/right) after every 50.7 kHz tick, on a four-stage pipeline
// (select -> multiply -> truncate toward zero -> accumulate).  Transcribed
// from MAME 0.289 exidy440_a.cpp:180-215 (`*dest += *srcdata++ * volume / 256`,
// C integer division truncating toward zero) and :663-712 (per-side volumes
// 2*ch+0 / 2*ch+1, clamp to 16 bits).  The r4 STA measured the single-cycle
// version of this chain at -5.9 ns; the pipeline has 2,048 clocks per tick.
module chiller_mixer (
    input  logic               clk,
    input  logic               reset,
    input  logic               tick,
    input  logic signed [15:0] s0, s1, s2, s3,
    input  logic [7:0]         vol0, vol1, vol2, vol3, vol4, vol5, vol6, vol7,
    output logic signed [15:0] audio_l,
    output logic signed [15:0] audio_r
);
    logic [3:0] step;                           // 0..7 issue, 8..11 drain, 12 latch
    logic signed [31:0] acc_l, acc_r;
    logic signed [15:0] sel_sample, s1_sample;
    logic [7:0]         sel_vol, s1_vol;
    logic               s1_v, s1_side, s2_v, s2_side, s3_v, s3_side;
    logic signed [24:0] s2_prod;
    logic signed [16:0] s3_q;

    always_comb begin
        case (step[2:1])
            2'd0: sel_sample = s0;
            2'd1: sel_sample = s1;
            2'd2: sel_sample = s2;
            default: sel_sample = s3;
        endcase
        case (step[2:0])
            3'd0: sel_vol = vol0;  3'd1: sel_vol = vol1;  3'd2: sel_vol = vol2;  3'd3: sel_vol = vol3;
            3'd4: sel_vol = vol4;  3'd5: sel_vol = vol5;  3'd6: sel_vol = vol6;  default: sel_vol = vol7;
        endcase
    end
    wire signed [24:0] s2_abs  = s2_prod[24] ? -s2_prod : s2_prod;
    wire signed [16:0] s2_qabs = s2_abs[24:8];

    function automatic signed [15:0] clamp16(input signed [31:0] v);
        if (v > 32'sd32767)       clamp16 = 16'sd32767;
        else if (v < -32'sd32768) clamp16 = 16'sh8000;
        else                      clamp16 = v[15:0];
    endfunction

    always_ff @(posedge clk) begin
        if (reset) begin
            step <= 4'd13;
            acc_l <= '0; acc_r <= '0;
            audio_l <= '0; audio_r <= '0;
            s1_v <= 1'b0; s2_v <= 1'b0; s3_v <= 1'b0;
        end else begin
            s1_v      <= (step < 4'd8);              // stage 1: select
            s1_sample <= sel_sample;
            s1_vol    <= sel_vol;
            s1_side   <= step[0];
            s2_v      <= s1_v;                       // stage 2: multiply
            s2_side   <= s1_side;
            s2_prod   <= s1_sample * $signed({1'b0, s1_vol});
            s3_v      <= s2_v;                       // stage 3: /256 toward zero
            s3_side   <= s2_side;
            s3_q      <= s2_prod[24] ? -s2_qabs : s2_qabs;
            if (s3_v) begin                          // stage 4: accumulate
                if (s3_side) acc_r <= acc_r + s3_q;
                else         acc_l <= acc_l + s3_q;
            end
            if (tick) begin
                step  <= 4'd0;
                acc_l <= '0;
                acc_r <= '0;
            end else if (step < 4'd12) begin
                step <= step + 4'd1;
            end else if (step == 4'd12) begin
                audio_l <= clamp16(acc_l);
                audio_r <= clamp16(acc_r);
                step <= 4'd13;
            end
        end
    end
endmodule
