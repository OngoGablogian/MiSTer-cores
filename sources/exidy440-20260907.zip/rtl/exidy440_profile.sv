// Exidy 440 game profile: everything that differs between the family's sets,
// decoded from the MRA's index-1 profile byte.  Sources: MAME 0.289
// exidy440.cpp INPUT_PORTS (:522-960), the "Differences between machines"
// notes (:104-186), init_* (:2064-2130), topsecex_video (exidy440_v.cpp:479-484).
//
//   0 crossbow   IN0 active LOW (bit0 unknown reads 1), IN2 start active low, IN3 bit2 = 1
//   1 cheyenne   IN0 active high, IN2 start active LOW, IN3 bit2 = 1
//   2 combat / catch22   active high, IN3 bit2 = 1
//   3 cracksht   active high, IN3 bit2 = 0
//   4 claypign   + 2EC0-2EC3 reads 0x76
//   5 chiller
//   6 topsecex   joystick/dial game: IN0 bit1 = 0, IN2 bit0 = button 2, 2EC5/2EC6/2EC7
//                ports, 2EC1 Y-scroll, 236 visible lines, no collision / beam FIRQ
//   7 hitnmiss   trigger on IN0 bits 1 AND 0
//   8 whodunit   IN0 bit0 mirrors the VBLANK FIRQ flag (bit 7)
//   9 showdown   IN2 = six buttons, bank-0 reads answered by the PLD sequence (tables 0)
//  10 yukon      as showdown with its own PLD tables
module exidy440_profile (
    input  logic [3:0] game,
    output logic       in0_active_low,     // crossbow
    output logic       in0_bit0_one,       // crossbow: unknown bit reads 1
    output logic       in0_bit0_vblank,    // whodunit
    output logic       in0_bit0_trigger,   // hitnmiss
    output logic       in0_bit1_zero,      // topsecex: no trigger on IN0
    output logic       in2_start_low,      // crossbow, cheyenne
    output logic       in2_showdown,       // six buttons on IN2
    output logic       in2_topsecex,       // button 2 on IN2 bit 0
    output logic       in3_bit2_one,       // crossbow, cheyenne, combat
    output logic       claypign_prot,
    output logic       topsecex,
    output logic [1:0] pld_tables          // 0 none, 1 showdown, 2 yukon
);
    always_comb begin
        in0_active_low   = (game == 4'd0);
        in0_bit0_one     = (game == 4'd0);
        in0_bit0_vblank  = (game == 4'd8);
        in0_bit0_trigger = (game == 4'd7);
        in0_bit1_zero    = (game == 4'd6);
        in2_start_low    = (game == 4'd0) || (game == 4'd1);
        in2_showdown     = (game == 4'd9) || (game == 4'd10);
        in2_topsecex     = (game == 4'd6);
        in3_bit2_one     = (game <= 4'd2);
        claypign_prot    = (game == 4'd4);
        topsecex         = (game == 4'd6);
        pld_tables       = (game == 4'd9) ? 2'd1 : (game == 4'd10) ? 2'd2 : 2'd0;
    end
endmodule
