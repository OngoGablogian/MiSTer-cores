//============================================================================
//  Arcade: Exidy 440 family (Crossbow, Cheyenne, Combat/Catch-22, Crackshot,
//  Clay Pigeon, Chiller, Top Secret, Hit 'n Miss, Who Dunit, Showdown) for
//  MiSTer.  One RBF; the MRA's index-1 profile byte selects the game.
//
//  The emu wrapper is an appliance layer: the board lives in rtl/chiller_board.sv
//  and has no MiSTer dependency beyond the DDR3 port for the sample ROM.
//============================================================================
module emu
(
    input         CLK_50M,
    input         RESET,
    inout  [48:0] HPS_BUS,

    output        CLK_VIDEO,
    output        CE_PIXEL,
    output [12:0] VIDEO_ARX,
    output [12:0] VIDEO_ARY,
    output  [7:0] VGA_R,
    output  [7:0] VGA_G,
    output  [7:0] VGA_B,
    output        VGA_HS,
    output        VGA_VS,
    output        VGA_DE,
    output        VGA_F1,
    output  [1:0] VGA_SL,
    output        VGA_SCALER,
    output        VGA_DISABLE,

    input  [11:0] HDMI_WIDTH,
    input  [11:0] HDMI_HEIGHT,
    output        HDMI_FREEZE,
    output        HDMI_BLACKOUT,
    output        HDMI_BOB_DEINT,

`ifdef MISTER_FB
    output        FB_EN,
    output  [4:0] FB_FORMAT,
    output [11:0] FB_WIDTH,
    output [11:0] FB_HEIGHT,
    output [31:0] FB_BASE,
    output [13:0] FB_STRIDE,
    input         FB_VBL,
    input         FB_LL,
    output        FB_FORCE_BLANK,
`ifdef MISTER_FB_PALETTE
    output        FB_PAL_CLK,
    output  [7:0] FB_PAL_ADDR,
    output [23:0] FB_PAL_DOUT,
    input  [23:0] FB_PAL_DIN,
    output        FB_PAL_WR,
`endif
`endif

    output        LED_USER,
    output  [1:0] LED_POWER,
    output  [1:0] LED_DISK,
    output  [1:0] BUTTONS,

    input         CLK_AUDIO,
    output [15:0] AUDIO_L,
    output [15:0] AUDIO_R,
    output        AUDIO_S,
    output  [1:0] AUDIO_MIX,

    inout   [3:0] ADC_BUS,
    output        SD_SCK,
    output        SD_MOSI,
    input         SD_MISO,
    output        SD_CS,
    input         SD_CD,

    output        DDRAM_CLK,
    input         DDRAM_BUSY,
    output  [7:0] DDRAM_BURSTCNT,
    output [28:0] DDRAM_ADDR,
    input  [63:0] DDRAM_DOUT,
    input         DDRAM_DOUT_READY,
    output        DDRAM_RD,
    output [63:0] DDRAM_DIN,
    output  [7:0] DDRAM_BE,
    output        DDRAM_WE,

    output        SDRAM_CLK,
    output        SDRAM_CKE,
    output [12:0] SDRAM_A,
    output  [1:0] SDRAM_BA,
    inout  [15:0] SDRAM_DQ,
    output        SDRAM_DQML,
    output        SDRAM_DQMH,
    output        SDRAM_nCS,
    output        SDRAM_nCAS,
    output        SDRAM_nRAS,
    output        SDRAM_nWE,

`ifdef MISTER_DUAL_SDRAM
    input         SDRAM2_EN,
    output        SDRAM2_CLK,
    output [12:0] SDRAM2_A,
    output  [1:0] SDRAM2_BA,
    inout  [15:0] SDRAM2_DQ,
    output        SDRAM2_nCS,
    output        SDRAM2_nCAS,
    output        SDRAM2_nRAS,
    output        SDRAM2_nWE,
`endif

    input         UART_CTS,
    output        UART_RTS,
    input         UART_RXD,
    output        UART_TXD,
    output        UART_DTR,
    input         UART_DSR,
    input   [6:0] USER_IN,
    output  [6:0] USER_OUT,
    input         OSD_STATUS
);

    assign {SD_SCK, SD_MOSI, SD_CS} = 'Z;
    assign {UART_RTS, UART_TXD, UART_DTR} = 3'b000;
    assign USER_OUT = '1;
    assign ADC_BUS = 'Z;
    assign {SDRAM_DQ, SDRAM_A, SDRAM_BA, SDRAM_CLK, SDRAM_CKE,
            SDRAM_DQML, SDRAM_DQMH, SDRAM_nWE, SDRAM_nCAS,
            SDRAM_nRAS, SDRAM_nCS} = 'Z;

    assign VGA_F1        = 1'b0;
    assign VGA_SCALER    = 1'b0;
    assign VGA_DISABLE   = 1'b0;
    assign LED_POWER     = 2'b00;
    assign LED_DISK      = 2'b00;
    assign BUTTONS       = 2'b00;
    assign AUDIO_MIX     = 2'b00;
    assign AUDIO_S       = 1'b1;
    assign HDMI_FREEZE   = 1'b0;
    assign HDMI_BLACKOUT = 1'b0;
    assign HDMI_BOB_DEINT = 1'b0;

    assign VIDEO_ARX = 13'd4;
    assign VIDEO_ARY = 13'd3;

`include "build_id.v"
    localparam CONF_STR = {
        "Exidy 440;;",
        "-,-= Lightgun =-;",
        "O[9:8],Gun Input,Lightgun/Analog,Mouse,Joystick;",
        "O[14:13],Gun Slot,Auto,Player 1,Player 2;",
        "O[10],Crosshair,Off,On;",
        "O[12:11],Sinden Border,Off,Thin,Medium,Thick;",
        "-,-= Top Secret dial =-;",
        "O[16:15],Dial Source,Spinner,Joystick,Analog X;",
        "O[17],Dial Direction,Normal,Reversed;",
        "-,-= Analogue video output =-;",
        "O[101],CRT Adjust,Off,On;",
        "H1O[100:96],CRT H-Size,",
            "0,+1,+2,+3,+4,+5,+6,+7,+8,+9,+10,+11,+12,+13,+14,+15,",
            "-16,-15,-14,-13,-12,-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1;",
        "H1O[85:79],CRT H-Position,",
            "0,+1,+2,+3,+4,+5,+6,+7,+8,+9,+10,+11,+12,+13,+14,+15,",
            "+16,+17,+18,+19,+20,+21,+22,+23,+24,+25,+26,+27,+28,+29,+30,+31,",
            "+32,+33,+34,+35,+36,+37,+38,",
            "-24,-23,-22,-21,-20,-19,-18,-17,-16,-15,-14,-13,-12,-11,-10,-9,",
            "-8,-7,-6,-5,-4,-3,-2,-1;",
        "H1O[78:74],CRT V-Shift,",
            "0,+1,+2,+3,+4,+5,+6,+7,+8,+9,+10,+11,+12,+13,+14,+15,",
            "-16,-15,-14,-13,-12,-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1;",
        "-;",
        "O[5:3],Scandoubler FX,None,HQ2x,CRT 25%,CRT 50%,CRT 75%;",
        "-;",
        "DIP;",
        "-;",
        "T[43],Save Settings (EEROM);",
        "R0,Reset;",
        "V,v", `BUILD_DATE
    };

    wire clk_sys, clk_half, pll_locked;
    pll pll (
        .refclk(CLK_50M), .rst(1'b0),
        .outclk_0(clk_sys), .outclk_1(clk_half), .locked(pll_locked)
    );

    // Power-on reset for the download path (2-FF synced ~locked, P0022):
    // the ROM stream arrives while the core is held in reset.
    reg [1:0] por_sync = 2'b11;
    always @(posedge clk_sys) por_sync <= {por_sync[0], ~pll_locked};
    wire por = por_sync[1];

    wire [127:0] status;
    wire [1:0]   buttons;
    wire         forced_scandoubler, direct_video;
    wire [21:0]  gamma_bus;
    wire         ioctl_download, ioctl_upload, ioctl_wr;
    wire [24:0]  ioctl_addr;
    wire [7:0]   ioctl_dout, ioctl_din, ioctl_index;
    wire [31:0]  joystick_0, joystick_1;
    wire [15:0]  joystick_l_analog_0, joystick_l_analog_1;
    wire [24:0]  ps2_mouse;
    wire [8:0]   spinner_0;
    wire         dl_busy;
    reg          ioctl_upload_req = 1'b0;

    hps_io #(.CONF_STR(CONF_STR)) u_hps_io (
        .clk_sys(clk_sys), .HPS_BUS(HPS_BUS),
        .buttons(buttons), .status(status), .status_menumask({14'd0, ~status[101], 1'b0}),
        .forced_scandoubler(forced_scandoubler), .gamma_bus(gamma_bus),
        .direct_video(direct_video), .video_rotated(1'b0),
        .ioctl_download(ioctl_download), .ioctl_upload(ioctl_upload),
        .ioctl_upload_req(ioctl_upload_req), .ioctl_upload_index(8'd2),
        .ioctl_wr(ioctl_wr), .ioctl_addr(ioctl_addr),
        .ioctl_dout(ioctl_dout), .ioctl_din(ioctl_din), .ioctl_index(ioctl_index),
        .ioctl_wait(dl_busy),
        .joystick_0(joystick_0), .joystick_1(joystick_1),
        .joystick_l_analog_0(joystick_l_analog_0),
        .joystick_l_analog_1(joystick_l_analog_1),
        .spinner_0(spinner_0),
        .ps2_mouse(ps2_mouse)
    );

    // Game profile byte from the MRA (index 1), DIP bytes (index 254):
    // byte 0 = IN0 dips, byte 1 = IN1 dips.
    reg [3:0] game = 4'd5;
    reg [7:0] dsw [0:1];
    initial begin dsw[0] = 8'h00; dsw[1] = 8'hff; end
    always @(posedge clk_sys) begin
        if (ioctl_wr && ioctl_index == 8'd1 && ioctl_addr == 0) game <= ioctl_dout[3:0];
        if (ioctl_wr && ioctl_index == 8'd254 && ioctl_addr < 2) dsw[ioctl_addr[0]] <= ioctl_dout;
    end
    wire is_topsecex = (game == 4'd6);
    wire is_showdown = (game == 4'd9) || (game == 4'd10);

    // ---- Controls.  MRA button order (sim/tools/gen_mra.py) -> joystick bits 4.. :
    //   gun games : Trigger(4) Start(5) Coin(6)
    //   showdown  : Trigger(4) Action(5) Bet-All(6) Gold(7) Blue(8) Red(9) White(10) Coin(11)
    //   topsecex  : Fire(4) Button2(5) Fireball(6) Laser(7) Missile(8) Oil(9) Turbo(10) Shield(11) Start(12) Coin(13)
    wire [31:0] joy = joystick_0 | joystick_1;
    wire mouse_fire = (status[9:8] == 2'd1) && ps2_mouse[0];
    wire trigger = joy[4] | mouse_fire;
    wire start   = is_topsecex ? joy[12] : joy[5];
    wire coin    = is_topsecex ? joy[13] : is_showdown ? joy[11] : joy[6];
    wire [7:0] aux_btn = is_topsecex ? {joy[11], joy[10], joy[9], joy[8], joy[7], joy[6], joy[5], 1'b0} :
                         is_showdown ? {3'b000, joy[10], joy[9], joy[8], joy[7], joy[6]} : 8'd0;

    wire core_reset = RESET | status[0] | buttons[1] | ~pll_locked |
                      (ioctl_download && ioctl_index == 8'd0);

    wire ce_pix, hb, vb, hs, vs;
    wire [7:0] core_r, core_g, core_b;
    wire [8:0] raster_h, raster_v;
    wire signed [15:0] audio_l, audio_r;
    wire [7:0] gun_x, gun_y, nvram_dout;
    wire overlay_white, coin_counter, render_overrun;
    wire [3:0] dma_active;

    // Frame tick for the joystick aim/dial rates
    reg vb_d = 0;
    always @(posedge clk_sys) vb_d <= vb;
    wire frame_tick = vb & ~vb_d;

    // ---- Top Secret dial (MAME AN0: IPT_DIAL, 8-bit, PORT_REVERSE):
    // spinner deltas, joystick left/right at 2 counts per frame, or the
    // analog stick X as a rate.  Direction is a preference, not a fact.
    reg  [7:0] dial_acc = 8'd0;
    reg        spin_toggle_d = 1'b0;
    wire signed [7:0] stick_x = joystick_l_analog_0[7:0];
    always @(posedge clk_sys) begin
        spin_toggle_d <= spinner_0[8];
        if (status[16:15] == 2'd0) begin
            if (spin_toggle_d != spinner_0[8]) dial_acc <= dial_acc + {{1{spinner_0[7]}}, spinner_0[7:1]};
        end else if (frame_tick) begin
            if (status[16:15] == 2'd1) begin
                if (joy[0]) dial_acc <= dial_acc + 8'd2;      // right
                if (joy[1]) dial_acc <= dial_acc - 8'd2;      // left
            end else begin
                dial_acc <= dial_acc + {{3{stick_x[7]}}, stick_x[7:3]};
            end
        end
    end
    wire [7:0] dial = status[17] ? dial_acc : -dial_acc;      // MAME PORT_REVERSE by default

    // Gun slot: MiSTer delivers a lightgun as the left analog stick of the
    // player slot it landed in.  Auto follows whichever slot last moved.
    reg [15:0] an0_d = 16'd0, an1_d = 16'd0;
    reg        auto_slot = 1'b0;
    always @(posedge clk_sys) begin
        an0_d <= joystick_l_analog_0;
        an1_d <= joystick_l_analog_1;
        if (joystick_l_analog_1 != an1_d) auto_slot <= 1'b1;
        if (joystick_l_analog_0 != an0_d) auto_slot <= 1'b0;
    end
    wire [15:0] gun_analog = (status[14:13] == 2'd1) ? joystick_l_analog_0 :
                             (status[14:13] == 2'd2) ? joystick_l_analog_1 :
                             (auto_slot ? joystick_l_analog_1 : joystick_l_analog_0);

    chiller_gun gun (
        .clk(clk_sys), .ce_pix(ce_pix), .reset(core_reset),
        .source(status[9:8]),
        .analog(gun_analog),
        .ps2_mouse(ps2_mouse),
        .joy_dirs({joy[3], joy[2], joy[1], joy[0]}),
        .frame_tick(frame_tick),
        .gun_x(gun_x), .gun_y(gun_y),
        .raster_h(raster_h), .raster_v(raster_v),
        .crosshair_on(status[10] && !is_topsecex), .border(is_topsecex ? 2'd0 : status[12:11]),
        .overlay_white(overlay_white)
    );

    chiller_board board (
        .clk(clk_sys), .reset(core_reset), .por(por),
        .game(game),
        .dl_wr(ioctl_wr && ioctl_index == 8'd0),
        .dl_addr(ioctl_addr[19:0]), .dl_data(ioctl_dout), .dl_busy(dl_busy),
        .trigger(trigger), .start(start), .coin_n({1'b1, ~coin}),
        .aux_btn(aux_btn), .dial(dial),
        .dip_in0(dsw[0][5:2]), .dip_in1(dsw[1]),
        .gun_x(gun_x), .gun_y(gun_y), .coin_counter(coin_counter),
        .nvram_host_enable((ioctl_download || ioctl_upload) && ioctl_index == 8'd2),
        .nvram_host_write(ioctl_wr && ioctl_index == 8'd2),
        .nvram_host_address(ioctl_addr[12:0]),
        .nvram_host_data_in(ioctl_dout), .nvram_host_data_out(nvram_dout),
        .DDRAM_CLK(DDRAM_CLK), .DDRAM_BUSY(DDRAM_BUSY), .DDRAM_BURSTCNT(DDRAM_BURSTCNT),
        .DDRAM_ADDR(DDRAM_ADDR), .DDRAM_DOUT(DDRAM_DOUT), .DDRAM_DOUT_READY(DDRAM_DOUT_READY),
        .DDRAM_RD(DDRAM_RD), .DDRAM_DIN(DDRAM_DIN), .DDRAM_BE(DDRAM_BE), .DDRAM_WE(DDRAM_WE),
        .ce_pix(ce_pix), .red(core_r), .green(core_g), .blue(core_b),
        .hblank(hb), .vblank(vb), .hsync(hs), .vsync(vs),
        .raster_h(raster_h), .raster_v(raster_v),
        .audio_l(audio_l), .audio_r(audio_r),
        .debug_main_addr(), .debug_main_op(), .debug_main_rd(), .debug_main_wr(),
        .debug_main_dout(), .debug_main_din(),
        .debug_snd_addr(), .debug_snd_op(), .debug_snd_rd(), .debug_snd_wr(),
        .debug_render_overrun(render_overrun), .debug_dma_active(dma_active)
    );

    assign ioctl_din = nvram_dout;

    // Explicit EEROM save (the game rewrites it during play, so an automatic
    // dirty-upload would loop; same policy as the Gladiator core).
    reg save_d = 1'b0;
    always @(posedge clk_sys) begin
        save_d <= status[43];
        ioctl_upload_req <= status[43] && !save_d;
    end

    // Crosshair / Sinden border overlay on the active picture only
    wire [7:0] out_r = overlay_white ? 8'hff : core_r;
    wire [7:0] out_g = overlay_white ? 8'hff : core_g;
    wire [7:0] out_b = overlay_white ? 8'hff : core_b;

    // ---- CRT Adjust: core-side line-buffer geometry (rmonic79), the same
    // block and OSD encoding the Gladiator and Y-unit cores carry.  It never
    // retimes a frame: the 416 x 260 / 60.000 Hz raster stays native and only
    // the picture content (H-Size), the HSync position (H-Position, sync-shift
    // mode) and the VSync line (V-Shift) move.  Off = pure passthrough.
    logic              crt_on = 1'b0;
    logic signed [4:0] crt_hsize = 5'sd0;
    logic        [6:0] crt_hpos_code = 7'd0;
    logic signed [5:0] crt_vshift = 6'sd0;
    always_ff @(posedge clk_sys) if (ce_pix) begin
        crt_on        <= status[101];
        crt_hsize     <= $signed(status[100:96]);
        crt_hpos_code <= status[85:79];
        crt_vshift    <= $signed(status[78:74]);
    end
    // Safe sync-shift range from the real 416-pixel line (docs/SYNC-PROMS.md):
    // active 0..319, front porch 320..343, HSync 344..375, back porch 376..415.
    wire signed [8:0] crt_hoffset =
        (crt_hpos_code <= 7'd38) ? $signed({2'b00, crt_hpos_code})
      : (crt_hpos_code <= 7'd62) ? $signed({2'b00, crt_hpos_code}) - 9'sd63
      : 9'sd0;

    wire crt_hs_ref, crt_ce;
    chiller_crt_read_ce crt_read_rate (
        .clk(clk_sys), .native_ce(ce_pix), .active(crt_on),
        .hsize(crt_hsize), .hs_ref(crt_hs_ref), .read_ce(crt_ce)
    );

    wire [7:0] crt_r, crt_g, crt_b;
    wire crt_hsync, crt_vsync, crt_hblank, crt_vblank;
    crt_adjust #(.VTOTAL(260), .HTOTAL(416), .HPOS_MODE(0)) crt_adjust (
        .clk(clk_sys), .pxl_cen(ce_pix), .pxl2_cen(crt_ce), .active(crt_on),
        .hsize(crt_hsize), .hoffset(crt_hoffset), .voffset(crt_vshift),
        .r_in(out_r), .g_in(out_g), .b_in(out_b),
        .hs_in(hs), .vs_in(vs), .hb_in(hb), .vb_in(vb),
        .r_out(crt_r), .g_out(crt_g), .b_out(crt_b),
        .hs_out(crt_hsync), .vs_out(crt_vsync), .hb_out(crt_hblank), .vb_out(crt_vblank),
        .hs_ref_out(crt_hs_ref)
    );

    arcade_video #(.WIDTH(320), .DW(24)) u_arcade_video (
        .clk_video(clk_sys), .ce_pix(crt_on ? crt_ce : ce_pix),
        .RGB_in(crt_on ? {crt_r, crt_g, crt_b} : {out_r, out_g, out_b}),
        .HBlank(crt_on ? crt_hblank : hb), .VBlank(crt_on ? crt_vblank : vb),
        .HSync(crt_on ? crt_hsync : hs), .VSync(crt_on ? crt_vsync : vs),
        .CLK_VIDEO(CLK_VIDEO), .CE_PIXEL(CE_PIXEL),
        .VGA_R(VGA_R), .VGA_G(VGA_G), .VGA_B(VGA_B),
        .VGA_HS(VGA_HS), .VGA_VS(VGA_VS), .VGA_DE(VGA_DE),
        .VGA_SL(VGA_SL), .fx(status[5:3]),
        .forced_scandoubler(forced_scandoubler), .gamma_bus(gamma_bus)
    );

    assign AUDIO_L  = audio_l;
    assign AUDIO_R  = audio_r;
    assign LED_USER = ioctl_download | coin_counter;

endmodule
