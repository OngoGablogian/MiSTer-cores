// The Legend of Kage video board.
//
// MAME documents three 32x32 8x8 tilemaps, 24 hardware sprites, a 1024-entry
// xRGB444 palette, independent layer scrolling, and the priority rule used
// below.  The implementation time-multiplexes the four graphics ROM planes
// across the eight 48 MHz clocks available for each 6 MHz pixel.
module lkage_video (
    input  wire         clk,
    input  wire         reset,
    input  wire [2:0]   phase,

    input  wire [7:0]   vreg0,
    input  wire [7:0]   vreg1,
    input  wire [7:0]   vreg2,
    input  wire         force_flip,
    input  wire         refresh_60,
    input  wire [7:0]   scroll0,
    input  wire [7:0]   scroll1,
    input  wire [7:0]   scroll2,
    input  wire [7:0]   scroll3,
    input  wire [7:0]   scroll4,
    input  wire [7:0]   scroll5,

    output reg  [9:0]   tx_vram_addr,
    output reg  [9:0]   fg_vram_addr,
    output reg  [9:0]   bg_vram_addr,
    input  wire [7:0]   tx_vram_data,
    input  wire [7:0]   fg_vram_data,
    input  wire [7:0]   bg_vram_data,

    output reg  [4:0]   sprite_addr,
    input  wire [7:0]   sprite_x,
    input  wire [7:0]   sprite_y,
    input  wire [7:0]   sprite_attr,
    input  wire [7:0]   sprite_code,

    output wire [13:0]  gfx_addr,
    input  wire [7:0]   gfx_p0,
    input  wire [7:0]   gfx_p1,
    input  wire [7:0]   gfx_p2,
    input  wire [7:0]   gfx_p3,

    output reg  [9:0]   palette_addr,
    input  wire [11:0]  palette_data,

    output reg  [7:0]   red,
    output reg  [7:0]   green,
    output reg  [7:0]   blue,
    output reg          hsync,
    output reg          vsync,
    output reg          hblank,
    output reg          vblank,
    output wire         ce_pixel,
    output reg          vblank_start
);

    // The video PCB has a 12 MHz crystal.  Its 6 MHz pixel clock, 384 clocks
    // per line and the 272-line Taito raster give 15.625 kHz / 57.4449 Hz.
    // The optional CRT compatibility raster keeps that exact pixel clock but
    // uses 385x260 totals: 15.5844 kHz / 59.9401 Hz.  Active video and sync
    // widths are identical in both modes.
    localparam RASTER_NATIVE_CODE = 1'b0;
    localparam RASTER_COMPAT_CODE = 1'b1;
    localparam [8:0] H_TOTAL_NATIVE = 9'd384;
    localparam [8:0] V_TOTAL_NATIVE = 9'd272;
    localparam [8:0] H_TOTAL_COMPAT = 9'd385;
    localparam [8:0] V_TOTAL_COMPAT = 9'd260;
    localparam [8:0] H_VISIBLE_FIRST = 9'd16;
    localparam [8:0] H_VISIBLE_LAST = 9'd255;
    localparam [8:0] V_VISIBLE_FIRST = 9'd16;
    localparam [8:0] V_VISIBLE_LAST = 9'd239;
    localparam [8:0] HSYNC_FIRST = 9'd304;
    localparam [8:0] HSYNC_END = 9'd336;
    localparam [8:0] VSYNC_FIRST = 9'd248;
    localparam [8:0] VSYNC_END = 9'd252;

    reg refresh_60_active;
    wire native_mode_selected = (refresh_60_active == RASTER_NATIVE_CODE);
    wire compat_mode_selected = (refresh_60_active == RASTER_COMPAT_CODE);
    wire [8:0] h_total = native_mode_selected ? H_TOTAL_NATIVE : compat_mode_selected ? H_TOTAL_COMPAT : H_TOTAL_NATIVE;
    wire [8:0] v_total = native_mode_selected ? V_TOTAL_NATIVE : compat_mode_selected ? V_TOTAL_COMPAT : V_TOTAL_NATIVE;

    wire cen_pix = (phase == 3'd0);
    // The board register remains authoritative for software/cabinet mode.
    // MiSTer's OSD override is applied at the renderer so it is immediate
    // and common to HDMI, Direct Video and Analog I/O outputs.
    wire flip_x  = ~vreg2[0] | force_flip;
    wire flip_y  = ~vreg2[1] | force_flip;

    reg [8:0] hcnt;
    reg [8:0] vcnt;
    reg [8:0] pipe_h;
    reg [8:0] pipe_v;
    reg       fetch_active;

    reg [2:0] bg_bit;
    reg [2:0] fg_bit;
    reg [2:0] tx_bit;
    reg [7:0] bg_b0, bg_b1, bg_b2, bg_b3;
    reg [7:0] fg_b0, fg_b1, fg_b2, fg_b3;
    reg [13:0] tile_gfx_addr;

    localparam [3:0]
        SP_IDLE     = 4'd0,
        SP_CLEAR    = 4'd1,
        SP_ADDR     = 4'd2,
        SP_WAIT     = 4'd3,
        SP_EVAL     = 4'd4,
        SP_GL_WAIT  = 4'd5,
        SP_GL_CAP   = 4'd6,
        SP_GR_WAIT  = 4'd7,
        SP_GR_CAP   = 4'd8,
        SP_DRAW     = 4'd9,
        SP_DONE     = 4'd10;

    reg [3:0] sprite_state;
    reg [7:0] clear_x;
    reg [4:0] sprite_index;
    reg [8:0] render_y;
    reg [13:0] sprite_gfx_addr;
    reg [8:0] work_code;
    reg [3:0] work_row;
    reg [7:0] work_sx;
    reg       work_flipx;
    reg [2:0] work_color;
    reg       work_priority;
    reg [4:0] draw_x;
    reg [7:0] sl0, sl1, sl2, sl3;
    reg [7:0] sr0, sr1, sr2, sr3;

    function automatic [3:0] plane_pixel;
        input [7:0] p0;
        input [7:0] p1;
        input [7:0] p2;
        input [7:0] p3;
        input [2:0] bn;
        begin
            // MAME plane order is listed most-significant output first:
            // 1/4, 0/4, 3/4, 2/4.  Thus ROM quarters 1,0,3,2 map to
            // Verilog pen bits 3,2,1,0 respectively.
            plane_pixel = {p1[bn], p0[bn], p3[bn], p2[bn]};
        end
    endfunction

    wire [3:0] bg_pen = plane_pixel(bg_b0, bg_b1, bg_b2, bg_b3, bg_bit);
    wire [3:0] fg_pen = plane_pixel(fg_b0, fg_b1, fg_b2, fg_b3, fg_bit);
    wire [3:0] tx_pen = plane_pixel(gfx_p0, gfx_p1, gfx_p2, gfx_p3, tx_bit);

    // Sprite scanline buffer: valid, low-priority attribute, palette index.
    reg [8:0] sprite_line [0:255];
    wire [8:0] sprite_pixel = sprite_line[pipe_h[7:0]];

    wire bg_on = vreg2[6];
    wire fg_on = vreg2[5] && (fg_pen != 4'd0);
    wire tx_on = vreg2[4] && (tx_pen != 4'd0);

    // MAME 0.289 assigns BG/FG/TX priority bits 1/(2 or 4)/4 and uses
    // sprite masks 0xf0 (attribute 7 clear) or 0xfc (attribute 7 set).
    // Therefore BG never masks a sprite, TX always masks it, and FG masks it
    // when FG uses priority 4 or when the sprite carries the low-priority bit.
    wire sprite_blocked_by_tiles = tx_on ||
                                   (fg_on && (!vreg1[1] || sprite_pixel[7]));
    wire sp_on = vreg2[7] && sprite_pixel[8] && !sprite_blocked_by_tiles;

    reg [9:0] selected_palette;
    always @(*) begin
        selected_palette = {2'b11, vreg1[7:4], 4'h0};
        if (bg_on) selected_palette = {2'b11, vreg1[7:4], bg_pen};
        if (fg_on) selected_palette = {2'b10, vreg1[7:4], fg_pen};
        if (tx_on) selected_palette = {2'b01, vreg1[7:4], tx_pen};
        if (sp_on) selected_palette = {3'b000, sprite_pixel[6:0]};
    end

    reg [1:0] ce_pipe;
    assign ce_pixel = ce_pipe[1];

    // Source-coordinate temporaries are combinational so the three VRAM
    // addresses are launched together at the start of each pixel slot.
    reg [7:0] bg_sx, bg_sy, fg_sx, fg_sy, tx_sx, tx_sy;
    always @(*) begin
        if (!flip_x) begin
            bg_sx = hcnt[7:0] + scroll4 + 8'd5;
            fg_sx = hcnt[7:0] + scroll2 + 8'd3;
            tx_sx = hcnt[7:0] + scroll0 + 8'd1;
        end else begin
            bg_sx = 8'd255 - hcnt[7:0] + scroll4 - 8'd27;
            fg_sx = 8'd255 - hcnt[7:0] + scroll2 - 8'd25;
            tx_sx = 8'd255 - hcnt[7:0] + scroll0 - 8'd23;
        end

        if (!flip_y) begin
            bg_sy = vcnt[7:0] + scroll5;
            fg_sy = vcnt[7:0] + scroll3;
            tx_sy = vcnt[7:0] + scroll1;
        end else begin
            bg_sy = 8'd255 - vcnt[7:0] + scroll5;
            fg_sy = 8'd255 - vcnt[7:0] + scroll3;
            tx_sy = 8'd255 - vcnt[7:0] + scroll1;
        end
    end

    // Tile fetch pipeline and raw raster timing.
    always @(posedge clk) begin
        if (reset) begin
            hcnt            <= 9'd0;
            vcnt            <= 9'd0;
            pipe_h          <= 9'd0;
            pipe_v          <= 9'd0;
            fetch_active    <= 1'b0;
            tile_gfx_addr   <= 14'd0;
            tx_vram_addr    <= 10'd0;
            fg_vram_addr    <= 10'd0;
            bg_vram_addr    <= 10'd0;
            bg_bit          <= 3'd0;
            fg_bit          <= 3'd0;
            tx_bit          <= 3'd0;
            palette_addr    <= 10'd0;
            red             <= 8'd0;
            green           <= 8'd0;
            blue            <= 8'd0;
            hsync           <= 1'b0;
            vsync           <= 1'b0;
            hblank          <= 1'b1;
            vblank          <= 1'b1;
            ce_pipe         <= 2'b00;
            vblank_start    <= 1'b0;
            refresh_60_active <= RASTER_NATIVE_CODE;
        end else begin
            ce_pipe      <= {ce_pipe[0], cen_pix};
            vblank_start <= 1'b0;

            // Palette RAM is combinational on its video side.  Latch RGB one
            // master clock after the palette index, before CE_PIXEL reaches
            // the MiSTer video wrapper.
            if (ce_pipe[0]) begin
                red   <= {palette_data[11:8], palette_data[11:8]};
                green <= {palette_data[7:4],  palette_data[7:4]};
                blue  <= {palette_data[3:0],  palette_data[3:0]};
            end

            if (cen_pix) begin
                // V-sync is the clean ownership boundary for new totals.
                // Applying the request at its first line makes the complete
                // following sync-to-sync interval use exactly one mode.
                if (hcnt == 9'd0 && vcnt == VSYNC_FIRST)
                    refresh_60_active <= refresh_60;

                // Finish the pixel launched eight clocks earlier.
                palette_addr <= selected_palette;
                hsync  <= (pipe_h >= HSYNC_FIRST && pipe_h < HSYNC_END);
                vsync  <= (pipe_v >= VSYNC_FIRST && pipe_v < VSYNC_END);
                hblank <= (pipe_h < H_VISIBLE_FIRST || pipe_h > H_VISIBLE_LAST);
                vblank <= (pipe_v < V_VISIBLE_FIRST || pipe_v > V_VISIBLE_LAST);

                // Launch all three tilemap lookups for the next pixel.
                pipe_h       <= hcnt;
                pipe_v       <= vcnt;
                fetch_active <= (hcnt < 9'd256 && vcnt < 9'd256);
                bg_vram_addr <= {bg_sy[7:3], bg_sx[7:3]};
                fg_vram_addr <= {fg_sy[7:3], fg_sx[7:3]};
                tx_vram_addr <= {tx_sy[7:3], tx_sx[7:3]};
                // MAME's gfx_layout bit offsets count bit zero from the
                // byte's MSB.  Its {7,6,...,0} X layout therefore selects
                // Verilog bits {0,1,...,7} from left to right.
                bg_bit       <= bg_sx[2:0];
                fg_bit       <= fg_sx[2:0];
                tx_bit       <= tx_sx[2:0];

                if (hcnt == 9'd0 && vcnt == V_VISIBLE_LAST + 1'b1)
                    vblank_start <= 1'b1;

                if (hcnt == h_total-1'b1) begin
                    hcnt <= 9'd0;
                    if (vcnt == v_total-1'b1) begin
                        vcnt <= 9'd0;
                    end else begin
                        vcnt <= vcnt + 9'd1;
                    end
                end else begin
                    hcnt <= hcnt + 9'd1;
                end
            end

            // The sprite engine owns the graphics port in horizontal blank.
            if (sprite_state == SP_IDLE && fetch_active) begin
                case (phase)
                    3'd2: tile_gfx_addr <= {
                        ((vreg1[3] ? 11'h500 : 11'h100) + {3'd0, bg_vram_data}),
                        bg_sy[2:0]
                    };
                    3'd4: begin
                        bg_b0 <= gfx_p0; bg_b1 <= gfx_p1;
                        bg_b2 <= gfx_p2; bg_b3 <= gfx_p3;
                        tile_gfx_addr <= {
                            ((vreg0[2] ? 11'h100 : 11'h000) + {3'd0, fg_vram_data}),
                            fg_sy[2:0]
                        };
                    end
                    3'd6: begin
                        fg_b0 <= gfx_p0; fg_b1 <= gfx_p1;
                        fg_b2 <= gfx_p2; fg_b3 <= gfx_p3;
                        tile_gfx_addr <= {
                            ((vreg0[1] ? 11'h400 : 11'h000) + {3'd0, tx_vram_data}),
                            tx_sy[2:0]
                        };
                    end
                    default: ;
                endcase
            end
        end
    end

    // ---------------------------------------------------------------------
    // Sprite scanline builder.  Clearing and rendering the worst-case 24
    // visible sprites consumes fewer than the 1024 master clocks available
    // in the 128-pixel horizontal blanking interval.
    // ---------------------------------------------------------------------
    assign gfx_addr = (sprite_state == SP_IDLE) ? tile_gfx_addr : sprite_gfx_addr;

    wire sprite_h32 = sprite_attr[3];
    wire sprite_fy  = sprite_attr[1] ^ flip_y;
    wire sprite_fx  = sprite_attr[0] ^ flip_x;
    wire signed [9:0] sprite_sy = flip_y ?
        ($signed({1'b0, sprite_y}) - 10'sd1) :
        (10'sd255 - (sprite_h32 ? 10'sd32 : 10'sd16) - $signed({1'b0, sprite_y}));
    wire signed [9:0] sprite_rel = $signed({1'b0, render_y}) - sprite_sy;
    wire sprite_hits = ($signed({1'b0, render_y}) >= sprite_sy) &&
                       (sprite_rel < (sprite_h32 ? 10'sd32 : 10'sd16));
    wire [8:0] sprite_base_code = {sprite_attr[2], sprite_code};
    wire sprite_code_xor = sprite_h32 && (sprite_fy ? sprite_rel[4] : ~sprite_rel[4]);
    wire [8:0] sprite_line_code = sprite_base_code ^ {8'd0, sprite_code_xor};
    wire [3:0] sprite_rom_row = sprite_fy ? (4'd15 - sprite_rel[3:0]) : sprite_rel[3:0];
    wire [13:0] sprite_left_addr = {sprite_line_code, 5'd0} +
                                    (sprite_rom_row[3] ? 14'd16 : 14'd0) +
                                    {11'd0, sprite_rom_row[2:0]};

    wire [3:0] draw_gfx_x = work_flipx ? (4'd15 - draw_x[3:0]) : draw_x[3:0];
    // Same MAME bit-numbering conversion as the 8x8 tile path above.  The
    // 16x16 layout selects a half-byte address first, then bit 0..7 here.
    wire [2:0] draw_bit = draw_gfx_x[2:0];
    wire [3:0] sprite_pen_l = plane_pixel(sl0, sl1, sl2, sl3, draw_bit);
    wire [3:0] sprite_pen_r = plane_pixel(sr0, sr1, sr2, sr3, draw_bit);
    wire [3:0] sprite_pen = draw_gfx_x[3] ? sprite_pen_r : sprite_pen_l;
    wire [7:0] draw_screen_x = work_sx + draw_x[3:0];

    always @(posedge clk) begin
        if (reset) begin
            sprite_state    <= SP_IDLE;
            clear_x         <= 8'd0;
            sprite_index    <= 5'd0;
            sprite_addr     <= 5'd0;
            sprite_gfx_addr <= 14'd0;
            render_y        <= 9'd0;
            draw_x          <= 5'd0;
        end else begin
            // Start preparing the following scanline when the 256-pixel
            // logical board raster enters horizontal blank.
            if (cen_pix && hcnt == H_VISIBLE_LAST + 1'b1) begin
                sprite_state <= SP_CLEAR;
                clear_x      <= 8'd0;
                sprite_index <= 5'd0;
                render_y     <= (vcnt == v_total-1'b1) ? 9'd0 : (vcnt + 9'd1);
            end else if (cen_pix && hcnt == 9'd0) begin
                sprite_state <= SP_IDLE;
            end else begin
                case (sprite_state)
                    SP_CLEAR: begin
                        sprite_line[clear_x] <= 9'd0;
                        if (clear_x == 8'hff) begin
                            sprite_state <= SP_ADDR;
                            sprite_index <= 5'd0;
                        end else begin
                            clear_x <= clear_x + 8'd1;
                        end
                    end

                    SP_ADDR: begin
                        sprite_addr  <= sprite_index;
                        sprite_state <= SP_WAIT;
                    end

                    SP_WAIT: sprite_state <= SP_EVAL;

                    SP_EVAL: begin
                        if (sprite_index < 5'd24 && sprite_hits && render_y < 9'd256) begin
                            work_code       <= sprite_line_code;
                            work_row        <= sprite_rom_row;
                            work_sx         <= flip_x ? (8'd242 - sprite_x) : (sprite_x - 8'd14);
                            work_flipx      <= sprite_fx;
                            work_color      <= sprite_attr[6:4];
                            work_priority   <= sprite_attr[7];
                            sprite_gfx_addr <= sprite_left_addr;
                            sprite_state    <= SP_GL_WAIT;
                        end else if (sprite_index == 5'd23) begin
                            sprite_state <= SP_DONE;
                        end else begin
                            sprite_index <= sprite_index + 5'd1;
                            sprite_state <= SP_ADDR;
                        end
                    end

                    SP_GL_WAIT: sprite_state <= SP_GL_CAP;

                    SP_GL_CAP: begin
                        sl0 <= gfx_p0; sl1 <= gfx_p1; sl2 <= gfx_p2; sl3 <= gfx_p3;
                        sprite_gfx_addr <= {work_code, 5'd0} +
                                           (work_row[3] ? 14'd16 : 14'd0) +
                                           14'd8 + {11'd0, work_row[2:0]};
                        sprite_state <= SP_GR_WAIT;
                    end

                    SP_GR_WAIT: sprite_state <= SP_GR_CAP;

                    SP_GR_CAP: begin
                        sr0 <= gfx_p0; sr1 <= gfx_p1; sr2 <= gfx_p2; sr3 <= gfx_p3;
                        draw_x       <= 5'd0;
                        sprite_state <= SP_DRAW;
                    end

                    SP_DRAW: begin
                        if (sprite_pen != 4'd0)
                            sprite_line[draw_screen_x] <= {
                                1'b1, work_priority, work_color, sprite_pen
                            };

                        if (draw_x == 5'd15) begin
                            if (sprite_index == 5'd23) begin
                                sprite_state <= SP_DONE;
                            end else begin
                                sprite_index <= sprite_index + 5'd1;
                                sprite_state <= SP_ADDR;
                            end
                        end else begin
                            draw_x <= draw_x + 5'd1;
                        end
                    end

                    default: ;
                endcase
            end
        end
    end

endmodule
