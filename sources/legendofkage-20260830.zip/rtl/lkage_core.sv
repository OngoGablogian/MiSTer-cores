// Top-level recreation of the dedicated Taito Legend of Kage board.
module lkage_core (
    input  wire         clk,
    input  wire         reset,

    input  wire         rom_we,
    input  wire [18:0]  rom_addr,
    input  wire [7:0]   rom_data,

    input  wire [7:0]   dsw1,
    input  wire [7:0]   dsw2,
    input  wire [7:0]   dsw3,
    input  wire [7:0]   system_in,
    input  wire [7:0]   p1_in,
    input  wire [7:0]   p2_in,
    input  wire         flip_screen,
    input  wire         refresh_60,

    output wire [7:0]   red,
    output wire [7:0]   green,
    output wire [7:0]   blue,
    output wire         hsync,
    output wire         vsync,
    output wire         hblank,
    output wire         vblank,
    output wire         ce_pixel,
    output wire [15:0]  audio
);

    // Exact enables derived from the 48 MHz project clock. Keep the board
    // divisors named and source-used so timing-domain qualification cannot
    // silently drift CPU/audio clocks while changing the raster totals.
    localparam integer CEN6_DIVISOR = 8;
    localparam integer CEN4_DIVISOR = 12;
    reg [2:0] phase6;
    reg [3:0] div4;
    wire cen6 = (phase6 == 3'd0);
    wire cen4 = (div4 == 4'd0);
    always @(posedge clk) begin
        if (reset) begin
            phase6 <= 3'd0;
            div4   <= 4'd0;
        end else begin
            if (phase6 == CEN6_DIVISOR - 1'b1) phase6 <= 3'd0;
            else                            phase6 <= phase6 + 3'd1;
            if (div4 == CEN4_DIVISOR - 1'b1) div4 <= 4'd0;
            else                          div4 <= div4 + 4'd1;
        end
    end

    // ------------------------------------------------------------------
    // Runtime ROM image layout (also documented in the supplied MRA):
    //   00000-0ffff main Z80
    //   10000-17fff sound Z80
    //   18000-1bfff main Z80 I/O-space data ROM
    //   1c000-2bfff four 16 KiB graphics planes
    //   2c000-2c7ff optional 68705 image (reserved for protected sets)
    // ------------------------------------------------------------------
    wire main_rom_we = rom_we && (rom_addr < 19'h10000);
    wire snd_rom_we  = rom_we && (rom_addr >= 19'h10000) && (rom_addr < 19'h18000);
    wire data_rom_we = rom_we && (rom_addr >= 19'h18000) && (rom_addr < 19'h1c000);
    wire gfx_rom_we  = rom_we && (rom_addr >= 19'h1c000) && (rom_addr < 19'h2c000);
    wire [15:0] snd_wr_off  = rom_addr[15:0];
    wire [13:0] data_wr_off = rom_addr[13:0];
    wire [15:0] gfx_wr_off  = rom_addr[15:0] - 16'hc000;

    wire [15:0] main_addr;
    wire [7:0] main_dout;
    reg  [7:0] main_din;
    wire main_m1_n, main_mreq_n, main_iorq_n, main_rd_n, main_wr_n;
    wire main_rfsh_n, main_halt_n, main_busak_n;

    wire [7:0] main_rom_q;
    lkage_dpram #(.AW(16)) u_main_rom (
        .clk_a(clk), .addr_a(rom_addr[15:0]), .data_a(rom_data),
        .we_a(main_rom_we), .q_a(),
        .clk_b(clk), .addr_b(main_addr), .data_b(8'd0),
        .we_b(1'b0), .q_b(main_rom_q)
    );

    wire [7:0] data_rom_q;
    lkage_dpram #(.AW(14)) u_data_rom (
        .clk_a(clk), .addr_a(data_wr_off[13:0]), .data_a(rom_data),
        .we_a(data_rom_we), .q_a(),
        .clk_b(clk), .addr_b(main_addr[13:0]), .data_b(8'd0),
        .we_b(1'b0), .q_b(data_rom_q)
    );

    reg prev_main_wr_n;
    wire main_write = prev_main_wr_n && !main_wr_n && !main_mreq_n;

    wire work_cs = !main_mreq_n && (main_addr >= 16'he000) && (main_addr <= 16'he7ff);
    wire [7:0] work_q;
    lkage_dpram #(.AW(11)) u_work_ram (
        .clk_a(clk), .addr_a(main_addr[10:0]), .data_a(main_dout),
        .we_a(main_write && work_cs), .q_a(work_q),
        .clk_b(clk), .addr_b(11'd0), .data_b(8'd0),
        .we_b(1'b0), .q_b()
    );

    // Palette RAM is byte-addressed by the Z80 and combinationally read by
    // the pixel mixer.  xRGB444 stores blue/green in the low byte and red in
    // the low nibble of the high byte.
    (* ramstyle = "MLAB" *) reg [7:0] palette_lo [0:1023];
    (* ramstyle = "MLAB" *) reg [7:0] palette_hi [0:1023];
    wire palette_cs = !main_mreq_n && (main_addr >= 16'he800) && (main_addr <= 16'hefff);
    wire [9:0] cpu_palette_addr = main_addr[10:1];
    wire [7:0] cpu_palette_q = main_addr[0] ? palette_hi[cpu_palette_addr] :
                                              palette_lo[cpu_palette_addr];

    reg [7:0] vreg [0:3];
    reg [7:0] scroll [0:5];

    // Three 1 KiB tilemap planes, dual-ported between the main CPU and video.
    wire tx_cs = !main_mreq_n && (main_addr >= 16'hf400) && (main_addr <= 16'hf7ff);
    wire fg_cs = !main_mreq_n && (main_addr >= 16'hf800) && (main_addr <= 16'hfbff);
    wire bg_cs = !main_mreq_n && (main_addr >= 16'hfc00);
    wire [9:0] tx_video_addr, fg_video_addr, bg_video_addr;
    wire [7:0] tx_cpu_q, fg_cpu_q, bg_cpu_q;
    wire [7:0] tx_video_q, fg_video_q, bg_video_q;

    lkage_dpram #(.AW(10)) u_tx_vram (
        .clk_a(clk), .addr_a(main_addr[9:0]), .data_a(main_dout),
        .we_a(main_write && tx_cs), .q_a(tx_cpu_q),
        .clk_b(clk), .addr_b(tx_video_addr), .data_b(8'd0),
        .we_b(1'b0), .q_b(tx_video_q)
    );
    lkage_dpram #(.AW(10)) u_fg_vram (
        .clk_a(clk), .addr_a(main_addr[9:0]), .data_a(main_dout),
        .we_a(main_write && fg_cs), .q_a(fg_cpu_q),
        .clk_b(clk), .addr_b(fg_video_addr), .data_b(8'd0),
        .we_b(1'b0), .q_b(fg_video_q)
    );
    lkage_dpram #(.AW(10)) u_bg_vram (
        .clk_a(clk), .addr_a(main_addr[9:0]), .data_a(main_dout),
        .we_a(main_write && bg_cs), .q_a(bg_cpu_q),
        .clk_b(clk), .addr_b(bg_video_addr), .data_b(8'd0),
        .we_b(1'b0), .q_b(bg_video_q)
    );

    // 0xf100-0xf15f is 24 four-byte sprite records.  Splitting the bytes into
    // four small memories lets the scanline builder read a whole record at once.
    wire sprite_cs = !main_mreq_n && (main_addr >= 16'hf100) && (main_addr <= 16'hf15f);
    wire [4:0] sprite_video_addr;
    wire [7:0] sprite_video_x, sprite_video_y, sprite_video_attr, sprite_video_code;
    genvar sb;
    generate
        for (sb = 0; sb < 4; sb = sb + 1) begin : g_sprite_ram
            wire [7:0] unused_cpu_q;
            wire [7:0] video_q;
            lkage_dpram #(.AW(5)) u_ram (
                .clk_a(clk), .addr_a(main_addr[6:2]), .data_a(main_dout),
                .we_a(main_write && sprite_cs && (main_addr[1:0] == sb[1:0])),
                .q_a(unused_cpu_q),
                .clk_b(clk), .addr_b(sprite_video_addr), .data_b(8'd0),
                .we_b(1'b0), .q_b(video_q)
            );
            if (sb == 0) assign sprite_video_x    = video_q;
            if (sb == 1) assign sprite_video_y    = video_q;
            if (sb == 2) assign sprite_video_attr = video_q;
            if (sb == 3) assign sprite_video_code = video_q;
        end
    endgenerate

    // Four independent graphics planes permit a four-bit pixel fetch in one
    // memory cycle.  Their bit significance is rearranged in lkage_video.
    wire [13:0] gfx_video_addr;
    wire [7:0] gfx_q0, gfx_q1, gfx_q2, gfx_q3;
    generate
        for (sb = 0; sb < 4; sb = sb + 1) begin : g_gfx_rom
            wire [7:0] plane_q;
            lkage_dpram #(.AW(14)) u_rom (
                .clk_a(clk), .addr_a(gfx_wr_off[13:0]), .data_a(rom_data),
                .we_a(gfx_rom_we && (gfx_wr_off[15:14] == sb[1:0])), .q_a(),
                .clk_b(clk), .addr_b(gfx_video_addr), .data_b(8'd0),
                .we_b(1'b0), .q_b(plane_q)
            );
            if (sb == 0) assign gfx_q0 = plane_q;
            if (sb == 1) assign gfx_q1 = plane_q;
            if (sb == 2) assign gfx_q2 = plane_q;
            if (sb == 3) assign gfx_q3 = plane_q;
        end
    endgenerate

    reg [7:0] mcu_value;
    function automatic [7:0] fake_mcu_reply;
        input [7:0] value;
        begin
            case (value)
                8'h01: fake_mcu_reply = 8'h00;
                8'h90: fake_mcu_reply = 8'hd3;
                8'ha6: fake_mcu_reply = 8'hcd;
                8'h34: fake_mcu_reply = 8'hb3;
                8'h48: fake_mcu_reply = 8'hff;
                default: fake_mcu_reply = value;
            endcase
        end
    endfunction

    reg [7:0] sound_latch;
    reg sound_pending;
    wire sound_ack;

    wire [9:0] palette_video_addr;
    wire [11:0] palette_video_data;
    lkage_palette_decode u_palette_decode (
        .even_byte(palette_lo[palette_video_addr]),
        .odd_byte(palette_hi[palette_video_addr]),
        .rgb444(palette_video_data)
    );
    wire video_vblank_start;

    lkage_video u_video (
        .clk(clk), .reset(reset), .phase(phase6),
        .vreg0(vreg[0]), .vreg1(vreg[1]), .vreg2(vreg[2]),
        .force_flip(flip_screen),
        .refresh_60(refresh_60),
        .scroll0(scroll[0]), .scroll1(scroll[1]),
        .scroll2(scroll[2]), .scroll3(scroll[3]),
        .scroll4(scroll[4]), .scroll5(scroll[5]),
        .tx_vram_addr(tx_video_addr), .fg_vram_addr(fg_video_addr),
        .bg_vram_addr(bg_video_addr),
        .tx_vram_data(tx_video_q), .fg_vram_data(fg_video_q),
        .bg_vram_data(bg_video_q),
        .sprite_addr(sprite_video_addr), .sprite_x(sprite_video_x),
        .sprite_y(sprite_video_y), .sprite_attr(sprite_video_attr),
        .sprite_code(sprite_video_code),
        .gfx_addr(gfx_video_addr), .gfx_p0(gfx_q0), .gfx_p1(gfx_q1),
        .gfx_p2(gfx_q2), .gfx_p3(gfx_q3),
        .palette_addr(palette_video_addr), .palette_data(palette_video_data),
        .red(red), .green(green), .blue(blue),
        .hsync(hsync), .vsync(vsync), .hblank(hblank), .vblank(vblank),
        .ce_pixel(ce_pixel), .vblank_start(video_vblank_start)
    );

    lkage_sound u_sound (
        .clk(clk), .reset(reset), .cen4(cen4),
        .rom_we(snd_rom_we), .rom_wr_addr(snd_wr_off[14:0]),
        .rom_wr_data(rom_data),
        .sound_latch(sound_latch), .latch_pending(sound_pending),
        .latch_ack(sound_ack), .audio(audio)
    );

    reg irq_pending;
    wire main_int_ack = !main_m1_n && !main_iorq_n;

    T80s u_main_cpu (
        .RESET_n(~reset), .CLK(clk), .CEN(cen6), .WAIT_n(1'b1),
        .INT_n(~irq_pending), .NMI_n(1'b1), .BUSRQ_n(1'b1), .OUT0(1'b0),
        .DI(main_din), .DOUT(main_dout), .A(main_addr),
        .M1_n(main_m1_n), .MREQ_n(main_mreq_n), .IORQ_n(main_iorq_n),
        .RD_n(main_rd_n), .WR_n(main_wr_n), .RFSH_n(main_rfsh_n),
        .HALT_n(main_halt_n), .BUSAK_n(main_busak_n)
    );

    always @(*) begin
        main_din = 8'hff;

        if (!main_iorq_n && !main_rd_n) begin
            if (main_addr >= 16'h4000 && main_addr <= 16'h7fff)
                main_din = data_rom_q;
        end else if (!main_mreq_n && !main_rd_n) begin
            if (main_addr < 16'he000)
                main_din = main_rom_q;
            else if (work_cs)
                main_din = work_q;
            else if (palette_cs)
                main_din = cpu_palette_q;
            else if (main_addr >= 16'hf000 && main_addr <= 16'hf003)
                main_din = vreg[main_addr[1:0]];
            else if (main_addr == 16'hf061)
                main_din = 8'hff;
            else if (main_addr == 16'hf062)
                main_din = fake_mcu_reply(mcu_value);
            else if (main_addr == 16'hf080)
                main_din = dsw1;
            else if (main_addr == 16'hf081)
                main_din = dsw2;
            else if (main_addr == 16'hf082)
                main_din = dsw3;
            else if (main_addr == 16'hf083)
                main_din = system_in;
            else if (main_addr == 16'hf084)
                main_din = p1_in;
            else if (main_addr == 16'hf086)
                main_din = p2_in;
            else if (main_addr == 16'hf087)
                main_din = 8'h03;
            else if (main_addr >= 16'hf0c0 && main_addr <= 16'hf0c5)
                main_din = scroll[main_addr[2:0]];
            else if (tx_cs)
                main_din = tx_cpu_q;
            else if (fg_cs)
                main_din = fg_cpu_q;
            else if (bg_cs)
                main_din = bg_cpu_q;
        end
    end

    integer ri;
    always @(posedge clk) begin
        prev_main_wr_n <= main_wr_n;

        if (reset) begin
            prev_main_wr_n <= 1'b1;
            irq_pending    <= 1'b0;
            mcu_value      <= 8'd0;
            sound_latch    <= 8'd0;
            sound_pending  <= 1'b0;
            for (ri = 0; ri < 4; ri = ri + 1) vreg[ri] <= 8'd0;
            for (ri = 0; ri < 6; ri = ri + 1) scroll[ri] <= 8'd0;
        end else begin
            if (video_vblank_start) irq_pending <= 1'b1;
            if (main_int_ack)       irq_pending <= 1'b0;

            if (sound_ack) sound_pending <= 1'b0;

            if (main_write) begin
                if (palette_cs) begin
                    if (main_addr[0]) palette_hi[cpu_palette_addr] <= main_dout;
                    else              palette_lo[cpu_palette_addr] <= main_dout;
                end

                if (main_addr >= 16'hf000 && main_addr <= 16'hf003)
                    vreg[main_addr[1:0]] <= main_dout;

                if (main_addr == 16'hf060) begin
                    sound_latch   <= main_dout;
                    sound_pending <= 1'b1;
                end

                if (main_addr == 16'hf062)
                    mcu_value <= main_dout;

                if (main_addr >= 16'hf0c0 && main_addr <= 16'hf0c5)
                    scroll[main_addr[2:0]] <= main_dout;
            end
        end
    end

endmodule
