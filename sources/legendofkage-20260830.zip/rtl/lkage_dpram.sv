// Generic true dual-port byte RAM used for ROM download storage and board RAM.
// Both ports are synchronous.  The no_rw_check style matches MiSTer's usual
// inferred Cyclone V block-RAM primitive.
module lkage_dpram #(
    parameter integer AW = 10,
    parameter integer DW = 8
) (
    input  wire              clk_a,
    input  wire [AW-1:0]     addr_a,
    input  wire [DW-1:0]     data_a,
    input  wire              we_a,
    output reg  [DW-1:0]     q_a,

    input  wire              clk_b,
    input  wire [AW-1:0]     addr_b,
    input  wire [DW-1:0]     data_b,
    input  wire              we_b,
    output reg  [DW-1:0]     q_b
);

    (* ramstyle = "no_rw_check" *) reg [DW-1:0] mem [0:(1<<AW)-1];

    always @(posedge clk_a) begin
        q_a <= mem[addr_a];
        if (we_a) mem[addr_a] <= data_a;
    end

    always @(posedge clk_b) begin
        q_b <= mem[addr_b];
        if (we_b) mem[addr_b] <= data_b;
    end

endmodule
