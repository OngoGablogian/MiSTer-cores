// Generated from the OSD generation projection; do not edit.
// Generation SHA256: 53faeacc9b9f701e3a807af2adbcd47c1ae8edcad6ccbe5818fc07fa00bf0166
localparam CONF_STR = {
    "Legend of Kage;;",
    "-,-= Analogue video output =-;",
    "O[27:24],CRT H-sync Adjust,0,1,2,3,4,5,6,7,-8,-7,-6,-5,-4,-3,-2,-1;",
    "O[31:28],CRT V-sync Adjust,0,1,2,3,4,5,6,7,-8,-7,-6,-5,-4,-3,-2,-1;",
    "O[8],Raster Timing,Native 57.44 Hz,MAME-targeted 59.94 Hz;",
    "-;",
    "O[5:3],Scandoubler FX,None,HQ2x,CRT 25%,CRT 50%,CRT 75%;",
    "O[6],Flip Screen,Off,On;",
    "O[7],Service,Off,On;",
    "-;",
    "DIP;",
    "R[0],Reset;",
    "J1,Sword,Shuriken,Start 1P,Start 2P,Coin,Pause;",
    "jn,A,B,Start,Select,R,L;",
    "v,1;",
    "V,v", `BUILD_DATE
};
