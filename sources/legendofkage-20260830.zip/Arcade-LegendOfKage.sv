//============================================================================
//  Arcade: The Legend of Kage (Taito, 1985)
//  First MiSTer implementation of the dedicated Legend of Kage hardware.
//============================================================================
module emu
(
    input         CLK_50M,
    input         RESET,
    inout  [48:0] HPS_BUS,

    output        CLK_VIDEO,
    output        CE_PIXEL,
    output [12:0] VIDEO_ARX,
    output [12:0] VIDEO_ARY,
    output  [7:0] VGA_R,
    output  [7:0] VGA_G,
    output  [7:0] VGA_B,
    output        VGA_HS,
    output        VGA_VS,
    output        VGA_DE,
    output        VGA_F1,
    output  [1:0] VGA_SL,
    output        VGA_SCALER,
    output        VGA_DISABLE,

    input  [11:0] HDMI_WIDTH,
    input  [11:0] HDMI_HEIGHT,
    output        HDMI_FREEZE,
    output        HDMI_BLACKOUT,
    output        HDMI_BOB_DEINT,

`ifdef MISTER_FB
    output        FB_EN,
    output  [4:0] FB_FORMAT,
    output [11:0] FB_WIDTH,
    output [11:0] FB_HEIGHT,
    output [31:0] FB_BASE,
    output [13:0] FB_STRIDE,
    input         FB_VBL,
    input         FB_LL,
    output        FB_FORCE_BLANK,
`ifdef MISTER_FB_PALETTE
    output        FB_PAL_CLK,
    output  [7:0] FB_PAL_ADDR,
    output [23:0] FB_PAL_DOUT,
    input  [23:0] FB_PAL_DIN,
    output        FB_PAL_WR,
`endif
`endif

    output        LED_USER,
    output  [1:0] LED_POWER,
    output  [1:0] LED_DISK,
    output  [1:0] BUTTONS,

    input         CLK_AUDIO,
    output [15:0] AUDIO_L,
    output [15:0] AUDIO_R,
    output        AUDIO_S,
    output  [1:0] AUDIO_MIX,

    inout   [3:0] ADC_BUS,
    output        SD_SCK,
    output        SD_MOSI,
    input         SD_MISO,
    output        SD_CS,
    input         SD_CD,

    output        DDRAM_CLK,
    input         DDRAM_BUSY,
    output  [7:0] DDRAM_BURSTCNT,
    output [28:0] DDRAM_ADDR,
    input  [63:0] DDRAM_DOUT,
    input         DDRAM_DOUT_READY,
    output        DDRAM_RD,
    output [63:0] DDRAM_DIN,
    output  [7:0] DDRAM_BE,
    output        DDRAM_WE,

    output        SDRAM_CLK,
    output        SDRAM_CKE,
    output [12:0] SDRAM_A,
    output  [1:0] SDRAM_BA,
    inout  [15:0] SDRAM_DQ,
    output        SDRAM_DQML,
    output        SDRAM_DQMH,
    output        SDRAM_nCS,
    output        SDRAM_nCAS,
    output        SDRAM_nRAS,
    output        SDRAM_nWE,

`ifdef MISTER_DUAL_SDRAM
    input         SDRAM2_EN,
    output        SDRAM2_CLK,
    output [12:0] SDRAM2_A,
    output  [1:0] SDRAM2_BA,
    inout  [15:0] SDRAM2_DQ,
    output        SDRAM2_nCS,
    output        SDRAM2_nCAS,
    output        SDRAM2_nRAS,
    output        SDRAM2_nWE,
`endif

    input         UART_CTS,
    output        UART_RTS,
    input         UART_RXD,
    output        UART_TXD,
    output        UART_DTR,
    input         UART_DSR,
    input   [6:0] USER_IN,
    output  [6:0] USER_OUT,
    input         OSD_STATUS
);

    assign {SD_SCK, SD_MOSI, SD_CS} = 'Z;
    assign {UART_RTS, UART_TXD, UART_DTR} = 3'b000;
    assign USER_OUT = '1;
    assign ADC_BUS = 'Z;
    assign {SDRAM_DQ, SDRAM_A, SDRAM_BA, SDRAM_CLK, SDRAM_CKE,
            SDRAM_DQML, SDRAM_DQMH, SDRAM_nWE, SDRAM_nCAS,
            SDRAM_nRAS, SDRAM_nCS} = 'Z;

    assign DDRAM_CLK      = 1'b0;
    assign DDRAM_BURSTCNT = 8'd0;
    assign DDRAM_ADDR     = 29'd0;
    assign DDRAM_RD       = 1'b0;
    assign DDRAM_DIN      = 64'd0;
    assign DDRAM_BE       = 8'd0;
    assign DDRAM_WE       = 1'b0;

    assign VGA_F1       = 1'b0;
    assign VGA_SCALER   = 1'b0;
    assign VGA_DISABLE  = 1'b0;
    assign LED_USER     = ioctl_download;
    assign LED_POWER    = 2'b00;
    assign LED_DISK     = 2'b00;
    assign BUTTONS      = 2'b00;
    assign AUDIO_MIX    = 2'b00;
    assign HDMI_FREEZE  = 1'b0;
    assign HDMI_BLACKOUT = 1'b0;
    assign HDMI_BOB_DEINT = 1'b0;

    assign VIDEO_ARX = 13'd4;
    assign VIDEO_ARY = 13'd3;

`include "build_id.v"
`include "osd/generated/conf_str.svh"

    wire clk_48m, clk_unused, pll_locked;
    // Keep the conventional MiSTer instance name: sys_top.sdc uses it to
    // separate this core clock from the HPS, HDMI and audio-output clocks.
    pll pll (
        .refclk(CLK_50M), .rst(1'b0),
        .outclk_0(clk_48m), .outclk_1(clk_unused), .locked(pll_locked)
    );
    wire clk_sys = clk_48m;

    wire [31:0] status;
`include "osd/generated/sources.svh"
`include "osd/generated/bindings.svh"
    wire [1:0] buttons;
    wire forced_scandoubler;
    wire [21:0] gamma_bus;
    wire ioctl_download, ioctl_wr;
    wire [24:0] ioctl_addr;
    wire [7:0] ioctl_dout, ioctl_index;
    wire [15:0] joystick_0, joystick_1;

    hps_io #(.CONF_STR(CONF_STR)) u_hps_io (
        .clk_sys(clk_sys), .HPS_BUS(HPS_BUS),
        .buttons(buttons), .status(status), .status_menumask(osd_status_menumask),
        .forced_scandoubler(forced_scandoubler), .gamma_bus(gamma_bus),
        .direct_video(), .video_rotated(1'b0),
        .ioctl_download(ioctl_download), .ioctl_wr(ioctl_wr),
        .ioctl_addr(ioctl_addr), .ioctl_dout(ioctl_dout),
        .ioctl_index(ioctl_index),
        .joystick_0(joystick_0), .joystick_1(joystick_1)
    );

    reg [7:0] dsw [0:2];
    initial begin
        dsw[0] = 8'h7f;
        dsw[1] = 8'h00;
        dsw[2] = 8'hff;
    end
    always @(posedge clk_sys) begin
        if (ioctl_wr && ioctl_index == 8'd254 && ioctl_addr < 3)
            dsw[ioctl_addr[1:0]] <= ioctl_dout;
    end

    wire start1 = joystick_0[6] | joystick_1[7];
    wire start2 = joystick_0[7] | joystick_1[6];
    wire coin1  = joystick_0[8];
    wire coin2  = joystick_1[8];
    wire [7:0] p1_port = {
        2'b11, ~joystick_0[3], ~joystick_0[2],
        ~joystick_0[0], ~joystick_0[1],
        ~joystick_0[5], ~joystick_0[4]
    };
    wire [7:0] p2_port = {
        2'b11, ~joystick_1[3], ~joystick_1[2],
        ~joystick_1[0], ~joystick_1[1],
        ~joystick_1[5], ~joystick_1[4]
    };
    wire [7:0] system_port = {
        2'b00, coin2, coin1, 1'b1, osd_service, ~start2, ~start1
    };
    // Keep the software DIP in its normal orientation.  The OSD flip is a
    // direct video override below, so toggling it does not depend on when the
    // game polls DSW1 or require a core reset.
    wire [7:0] dsw1_port = {dsw[0][7], 1'b1, dsw[0][5:0]};

    wire core_reset;
    assign core_reset = RESET | osd_reset | buttons[1] | ioctl_download | ~pll_locked;
    wire [7:0] core_r, core_g, core_b;
    wire core_hs, core_vs, core_hblank, core_vblank, core_ce;
    wire core_hs_adjusted, core_vs_adjusted;
    wire [15:0] core_audio;

    lkage_core u_core (
        .clk(clk_sys), .reset(core_reset),
        .rom_we(ioctl_wr && ioctl_index == 8'd0),
        .rom_addr(ioctl_addr[18:0]), .rom_data(ioctl_dout),
        .dsw1(dsw1_port), .dsw2(dsw[1]), .dsw3(dsw[2]),
        .system_in(system_port), .p1_in(p1_port), .p2_in(p2_port),
        .flip_screen(osd_flip_screen),
        .refresh_60(osd_raster_timing),
        .red(core_r), .green(core_g), .blue(core_b),
        .hsync(core_hs), .vsync(core_vs),
        .hblank(core_hblank), .vblank(core_vblank),
        .ce_pixel(core_ce), .audio(core_audio)
    );

    // Reuse JTFRAME's field-aware CRT centering block.  It preserves the
    // native line/frame clocks and pulse widths, moving only sync position
    // relative to the active raster.  Four-bit values are signed two's
    // complement, matching the established MiSTer arcade-core OSD encoding.
    jtframe_resync u_crt_resync (
        .clk(clk_sys), .reset(core_reset), .pxl_cen(core_ce),
        .hs_in(core_hs), .vs_in(core_vs),
        .LHBL(~core_hblank), .LVBL(~core_vblank),
        .hoffset(osd_crt_hsync_adjust), .voffset(osd_crt_vsync_adjust),
        .hs_out(core_hs_adjusted), .vs_out(core_vs_adjusted)
    );

    arcade_video #(.WIDTH(256), .DW(24)) u_arcade_video (
        .clk_video(clk_sys), .ce_pix(core_ce),
        .RGB_in({core_r, core_g, core_b}),
        .HBlank(core_hblank), .VBlank(core_vblank),
        .HSync(core_hs_adjusted), .VSync(core_vs_adjusted),
        .CLK_VIDEO(CLK_VIDEO), .CE_PIXEL(CE_PIXEL),
        .VGA_R(VGA_R), .VGA_G(VGA_G), .VGA_B(VGA_B),
        .VGA_HS(VGA_HS), .VGA_VS(VGA_VS), .VGA_DE(VGA_DE),
        .VGA_SL(VGA_SL), .fx(osd_scaler_effects),
        .forced_scandoubler(forced_scandoubler), .gamma_bus(gamma_bus)
    );

    assign AUDIO_L = core_audio;
    assign AUDIO_R = core_audio;
    assign AUDIO_S = 1'b1;

endmodule
