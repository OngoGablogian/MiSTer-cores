#!/usr/bin/env python3
"""Build and run the isolated T-unit ADPCM board with real MAME ROMs.

The generated logical image and simulator logs are written only below
sim/out/, which is ignored by git.  No ROM bytes are copied into source files.
"""

from __future__ import annotations

import argparse
import binascii
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SV2V = Path(r"C:\tools\sv2v\sv2v-Windows\sv2v.exe")
CONST_SELECT_MARKER = "constant selects in always_* processes"
JT6295_DIR = ROOT / "rtl" / "vendor" / "jt6295" / "src"


@dataclass(frozen=True)
class Profile:
    profile_id: int
    archive: str
    cpu_name: str
    cpu_size: int
    cpu_crc: int
    oki12_name: str
    oki12_size: int
    oki12_crc: int
    oki13_name: str
    oki13_size: int
    oki13_crc: int


PROFILES = {
    "mk": Profile(
        0,
        "mk.zip",
        "sl1_mortal_kombat_u3_sound_rom.u3",
        0x40000,
        0xC615844C,
        "sl1_mortal_kombat_u12_sound_rom.u12",
        0x40000,
        0x258BD7F9,
        "sl1_mortal_kombat_u13_sound_rom.u13",
        0x40000,
        0x7B7EC3B6,
    ),
    "nbajam": Profile(
        2,
        "nbajam.zip",
        "l2_nba_jam_u3_sound_rom.u3",
        0x20000,
        0x3A3EA480,
        "l1_nba_jam_u12_sound_rom.u12",
        0x80000,
        0xB94847F1,
        "l1_nba_jam_u13_sound_rom.u13",
        0x80000,
        0xB6FE24BD,
    ),
    "nbajamte": Profile(
        3,
        "nbajamte.zip",
        "l1_nba_jam_tournament_u3_sound_rom.u3",
        0x20000,
        0xD4551195,
        "l1_nba_jam_tournament_u12_sound_rom.u12",
        0x80000,
        0x4FAC97BC,
        "l1_nba_jam_tournament_u13_sound_rom.u13",
        0x80000,
        0x6F27B202,
    ),
    "jdreddp": Profile(
        4,
        "jdreddp.zip",
        "t1_judge_dredd_sound_rom_u3.u3",
        0x20000,
        0x6154D108,
        "t1_judge_dredd_sound_rom_u12.u12",
        0x80000,
        0xEF32F202,
        "t1_judge_dredd_sound_rom_u13.u13",
        0x80000,
        0x3DC70473,
    ),
}


def read_member(archive: zipfile.ZipFile, name: str, size: int, crc: int) -> bytes:
    try:
        payload = archive.read(name)
    except KeyError as exc:
        raise RuntimeError(f"missing archive member {name}") from exc
    actual_crc = binascii.crc32(payload) & 0xFFFFFFFF
    if len(payload) != size or actual_crc != crc:
        raise RuntimeError(
            f"{name}: got size=0x{len(payload):x} crc={actual_crc:08x}; "
            f"expected size=0x{size:x} crc={crc:08x}"
        )
    return payload


def build_image(profile: Profile, rom_dir: Path) -> bytearray:
    archive_path = rom_dir / profile.archive
    with zipfile.ZipFile(archive_path) as archive:
        cpu = read_member(
            archive, profile.cpu_name, profile.cpu_size, profile.cpu_crc
        )
        oki12 = read_member(
            archive, profile.oki12_name, profile.oki12_size, profile.oki12_crc
        )
        oki13 = read_member(
            archive, profile.oki13_name, profile.oki13_size, profile.oki13_crc
        )

    # This is the exact tunit_sound_stream_map logical DDR contract:
    # CPU U3 at 000000-03ffff, then the one-megabyte OKI image at
    # 040000-13ffff.  MK's 256 KiB sample chips are mirrored once; NBA Jam's
    # 128 KiB U3 is mirrored once.
    cpu_image = cpu if len(cpu) == 0x40000 else cpu + cpu
    oki12_image = oki12 if len(oki12) == 0x80000 else oki12 + oki12
    oki13_image = oki13 if len(oki13) == 0x80000 else oki13 + oki13
    image = bytearray(cpu_image + oki12_image + oki13_image)
    if len(image) != 0x140000:
        raise RuntimeError(f"internal image length error: 0x{len(image):x}")
    return image


def write_readmemh(path: Path, image: bytearray) -> None:
    # Eight bytes per line keeps both Icarus and Questa loading reasonably
    # quickly while retaining a simple, portable $readmemh input.
    with path.open("w", encoding="ascii", newline="\n") as out:
        for offset in range(0, len(image), 8):
            out.write(" ".join(f"{value:02x}" for value in image[offset : offset + 8]))
            out.write("\n")


def source_files() -> list[Path]:
    return (
        [ROOT / "rtl" / "vendor" / "mc6809" / "mc6809is.v"]
        + sorted((ROOT / "rtl" / "vendor" / "jt51" / "hdl").glob("*.v"))
        + sorted((ROOT / "rtl" / "vendor" / "jt6295" / "src").glob("*.v"))
        + [
            ROOT / "rtl" / "experimental" / "adpcm" / "tunit_adpcm_board.sv",
            ROOT / "rtl" / "diag" / "tunit_audio_telemetry.sv",
            ROOT / "sim" / "tb_tunit_adpcm_realrom.sv",
        ]
    )


def run(
    command: list[str], *, cwd: Path = ROOT
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, cwd=cwd, text=True, capture_output=True)


def combined(result: subprocess.CompletedProcess[str]) -> str:
    return (result.stdout or "") + (result.stderr or "")


def sv2v_tool() -> str | None:
    if DEFAULT_SV2V.is_file():
        return str(DEFAULT_SV2V)
    return shutil.which("sv2v")


def questa_tool(name: str) -> str | None:
    # Prefer the installed current Questa FSE over Quartus 17's older bundled
    # ModelSim ASE when both suites are on PATH.
    current_bin = Path(r"C:\altera\25.1std\questa_fse\win64")
    current = current_bin / f"{name}.exe"
    if current.exists():
        return str(current)
    return shutil.which(name)


def run_iverilog(out_dir: Path, rom_hex: Path, profile: Profile) -> tuple[bool, str]:
    iverilog = shutil.which("iverilog")
    vvp = shutil.which("vvp")
    if not iverilog or not vvp:
        return False, "SKIP: Icarus tools not found\n"
    executable = out_dir / "adpcm_realrom.vvp"
    sources = source_files()
    command = [
        iverilog,
        "-g2012",
        "-DADPCM_SHORT_ROM",
        "-s",
        "tb_tunit_adpcm_realrom",
        "-o",
        str(executable),
        *(str(path) for path in sources),
    ]
    compile_result = run(command)
    if compile_result.returncode:
        return False, combined(compile_result)
    build_log = combined(compile_result)
    if CONST_SELECT_MARKER in build_log:
        sv2v = sv2v_tool()
        if not sv2v:
            return False, build_log + "\nERROR: sv2v is required for faithful Icarus elaboration\n"
        converted = out_dir / "adpcm_realrom.sv2v.v"
        sv_sources = [path for path in sources if path.suffix == ".sv"]
        v_sources = [path for path in sources if path.suffix != ".sv"]
        convert_result = run(
            [
                sv2v,
                "-D",
                "ADPCM_SHORT_ROM",
                f"--write={converted}",
                *(str(path) for path in sv_sources),
            ]
        )
        if convert_result.returncode:
            return False, build_log + "\n--- sv2v ---\n" + combined(convert_result)
        compile_result = run(
            [
                iverilog,
                "-g2012",
                "-s",
                "tb_tunit_adpcm_realrom",
                "-o",
                str(executable),
                *(str(path) for path in v_sources),
                str(converted),
            ]
        )
        build_log += (
            "\nNATIVE ICARUS REJECTED: constant-select sensitivity warning; "
            "faithful sv2v fallback used.\n--- sv2v compile ---\n"
            + combined(convert_result)
            + combined(compile_result)
        )
        if compile_result.returncode:
            return False, build_log
    sim_result = run(
        [
            vvp,
            str(executable),
            f"+ROM_HEX={rom_hex}",
            f"+PROFILE={profile.profile_id}",
            "+SHORT=1",
        ],
        cwd=JT6295_DIR,
    )
    log = build_log + combined(sim_result)
    passed = (
        sim_result.returncode == 0
        and "PASS tb_tunit_adpcm_realrom" in log
        and "FATAL:" not in log
        and "ERROR:" not in log
    )
    return passed, log


def run_questa(out_dir: Path, rom_hex: Path, profile: Profile) -> tuple[bool, str]:
    vlib = questa_tool("vlib")
    vlog = questa_tool("vlog")
    vsim = questa_tool("vsim")
    if not vlib or not vlog or not vsim:
        return False, "SKIP: Questa tools not found\n"
    work = "work"
    create_result = run([vlib, work], cwd=out_dir)
    compile_result = run(
        [
            vlog,
            "-quiet",
            "-sv",
            "-svinputport=var",
            "-work",
            work,
            *(str(path) for path in source_files()),
        ],
        cwd=out_dir,
    )
    if create_result.returncode or compile_result.returncode:
        return False, combined(create_result) + combined(compile_result)
    sim_result = run(
        [
            vsim,
            "-c",
            "-lib",
            work,
            f"+ROM_HEX={rom_hex}",
            f"+PROFILE={profile.profile_id}",
            "-do",
            "run -all; quit -f",
            "tb_tunit_adpcm_realrom",
        ],
        cwd=out_dir,
    )
    log = combined(create_result) + combined(compile_result) + combined(sim_result)
    passed = (
        sim_result.returncode == 0
        and "PASS tb_tunit_adpcm_realrom" in log
        and "** Fatal:" not in log
        and "Error:" not in log
    )
    return passed, log


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("game", choices=tuple(PROFILES))
    parser.add_argument(
        "--rom-dir",
        type=Path,
        default=Path(r"D:\deck\fpga\tunit\mk2\roms"),
    )
    parser.add_argument(
        "--label",
        default="adpcm-realrom-" + datetime.now().strftime("%Y%m%d-%H%M%S"),
    )
    parser.add_argument(
        "--simulator",
        choices=("both", "iverilog", "questa"),
        default="both",
    )
    args = parser.parse_args()

    profile = PROFILES[args.game]
    out_dir = ROOT / "sim" / "out" / args.label
    if out_dir.exists():
        print(f"ERROR: output already exists: {out_dir}", file=sys.stderr)
        return 2
    out_dir.mkdir(parents=True)

    try:
        image = build_image(profile, args.rom_dir)
    except (OSError, RuntimeError, zipfile.BadZipFile) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    rom_hex = out_dir / f"{args.game}-adpcm-logical.hex"
    write_readmemh(rom_hex, image)
    cpu_bin = out_dir / f"{args.game}-adpcm-cpu-only.bin"
    cpu_bin.write_bytes(image[:0x40000])

    reset_vector = (image[0x3FFFE] << 8) | image[0x3FFFF]
    print(
        f"{args.game}: verified 3 ROM members; logical image=0x{len(image):x}; "
        f"6809 reset vector={reset_vector:04x}"
    )

    results: list[tuple[str, bool, str]] = []
    if args.simulator in ("both", "iverilog"):
        passed, log = run_iverilog(out_dir, cpu_bin, profile)
        (out_dir / "iverilog.log").write_text(
            log, encoding="utf-8", errors="replace"
        )
        results.append(("Icarus", passed, log))
    if args.simulator in ("both", "questa"):
        passed, log = run_questa(out_dir, rom_hex, profile)
        (out_dir / "questa.log").write_text(
            log, encoding="utf-8", errors="replace"
        )
        results.append(("Questa", passed, log))

    all_passed = True
    for name, passed, log in results:
        print(log)
        print(f"{'PASS' if passed else 'FAIL'}: {name} {args.game} real-ROM boot")
        all_passed &= passed
    return 0 if all_passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
