# Four-corner physical proof for the NBA scanline snoop-suppression cone.
#
# The dynamic target_snoop_beats[load_col[8:2]] select is new logic on the
# write-enable decision for all four inferred line stores. Global clock
# summaries prove closure but do not prove this source-to-physical-RAM cone
# survived and was analyzed, so report it explicitly and fail if any source,
# endpoint, or path disappears. Post-fit discovery found the surviving
# scan_write combout, one lineN_we combout per logical row, and two physical RAM
# porta-we endpoints per packed 64-bit row. Bind every fitted chain rather than
# an RTL-like name.

set rev [lindex $quartus(args) 0]
if {$rev eq ""} { set rev "Arcade-TUnit" }

set receipt_path "output_files/tunit_scanline_snoop_timing_receipt.txt"
set receipt [open $receipt_path w]
puts $receipt "TUNIT SCANLINE SNOOP TIMING RECEIPT"
puts $receipt "revision=$rev"
puts $receipt "cone=target_snoop_beats->line0..line3_ram_write_enable_endpoint"

project_open $rev -revision $rev

set corners [list \
    slow 100 slow_100c \
    slow -40 slow_n40c \
    fast 100 fast_100c \
    fast -40 fast_n40c]
set failures 0
set total_paths 0
set progressive_hit_paths 0

foreach {model temperature label} $corners {
    create_timing_netlist -model $model
    read_sdc
    update_timing_netlist
    set_operating_conditions -model $model -temperature $temperature -voltage 1100
    update_timing_netlist

    # Advanced Physical Optimization may duplicate individual bitmap bits for
    # routability.  Count the 128 architectural indices, not physical copies;
    # keep every copy in snoop_regs so all endpoint timing queries see the
    # actual fitted source collection.  Fail on a missing logical bit or on a
    # physical register whose name cannot be bound to a legal bitmap index.
    set snoop_regs [get_registers -nowarn {*tunit_scanline:lines*target_snoop_beats*}]
    set snoop_count [get_collection_size $snoop_regs]
    set logical_bits [dict create]
    set unexpected_snoop_regs [list]
    foreach_in_collection snoop_reg $snoop_regs {
        set snoop_name [get_node_info -name $snoop_reg]
        if {![regexp {target_snoop_beats\[([0-9]+)\]} $snoop_name -> bit] ||
            $bit < 0 || $bit > 127} {
            lappend unexpected_snoop_regs $snoop_name
        } else {
            dict incr logical_bits $bit
        }
    }
    set logical_count [dict size $logical_bits]
    set missing_bits [list]
    for {set bit 0} {$bit < 128} {incr bit} {
        if {![dict exists $logical_bits $bit]} { lappend missing_bits $bit }
    }
    set duplicate_copies [expr {$snoop_count - $logical_count}]
    puts $receipt "corner=$label bitmap_physical_registers=$snoop_count bitmap_logical_bits=$logical_count duplicate_copies=$duplicate_copies"
    if {$snoop_count < 128 || $logical_count != 128 ||
        [llength $missing_bits] != 0 || [llength $unexpected_snoop_regs] != 0} {
        post_message -type error "SCANLINE CONE: $label incomplete/malformed target_snoop_beats collection physical=$snoop_count logical=$logical_count missing=$missing_bits unexpected=$unexpected_snoop_regs"
        incr failures
    }

    if {$snoop_count >= 128 && $logical_count == 128 &&
        [llength $missing_bits] == 0 && [llength $unexpected_snoop_regs] == 0} {
        set corner_we_names [list]
        set corner_ram_names [list]
        foreach row {0 1 2 3} {
            # Quartus's fitted combinational pins are exposed by get_nodes but
            # are not valid timing collections. The RAM's porta_we_reg is a
            # true timing keeper. A 128x60/64 packed row spans exactly two
            # Cyclone V M10Ks, so prove both independently and inspect every
            # path's arrival-point chain for the scan_write combout, row-select
            # combout, and RAM portawe pin.
            set ram_we_keepers [get_keepers -nowarn \
                "*tunit_scanline:lines*line${row}_rtl_0*porta_we_reg"]
            set endpoint_count [get_collection_size $ram_we_keepers]
            puts $receipt "corner=$label row=$row ram_we_endpoints=$endpoint_count"
            if {$endpoint_count != 2} {
                post_message -type error "SCANLINE CONE: $label line$row expected two unique physical RAM porta-we keepers, got $endpoint_count"
                incr failures
            } else {
                set endpoint_index 0
                foreach_in_collection endpoint $ram_we_keepers {
                    set endpoint_name [get_node_info -name $endpoint]
                    set endpoint_type [get_node_info -type $endpoint]
                    lappend corner_ram_names $endpoint_name
                    puts $receipt "corner=$label row=$row slice=$endpoint_index endpoint={$endpoint_name} endpoint_type={$endpoint_type}"
                    set paths [get_timing_paths -setup -npaths 20 -nworst 1 \
                        -from $snoop_regs -to $endpoint]
                    set path_count [get_collection_size $paths]
                    set worst_slack ""
                    set reported_tns 0.0
                    if {$path_count < 1} {
                        post_message -type error "SCANLINE CONE: $label line$row slice$endpoint_index has no timed target_snoop_beats-to-M10K-WE path"
                        incr failures
                    }
                    set report_path "output_files/tunit_scanline_snoop_${label}_line${row}_slice${endpoint_index}.txt"
                    report_timing -setup -npaths 20 -nworst 1 -detail full_path \
                        -from $snoop_regs -to $endpoint -file $report_path
                    set first 1
                    foreach_in_collection path $paths {
                        incr total_paths
                        set slack [get_path_info -slack $path]
                        set source [get_node_info -name [get_path_info -from $path]]
                        set target [get_node_info -name [get_path_info -to $path]]
                        set delay ""
                        set levels ""
                        catch {set delay [get_path_info -data_delay $path]}
                        catch {set levels [get_path_info -num_logic_levels $path]}
                        if {$worst_slack eq "" || $slack < $worst_slack} {
                            set worst_slack $slack
                        }
                        if {$slack < 0.0} {
                            set reported_tns [expr {$reported_tns + $slack}]
                        }
                        if {$first} {
                            set scan_write_count 0
                            set row_we_count 0
                            set ram_pin_count 0
                            set endpoint_point_count 0
                            set scan_write_name ""
                            set we_name ""
                            set ram_pin_name ""
                            foreach_in_collection point [get_path_info -arrival_points $path] {
                                set point_node [get_point_info $point -node]
                                if {$point_node eq ""} { continue }
                                set point_name [get_node_info -name $point_node]
                                set lower_name [string tolower $point_name]
                                if {[string match "*|lines|scan_write|combout" $lower_name]} {
                                    incr scan_write_count
                                    set scan_write_name $point_name
                                }
                                if {[string match "*|lines|line${row}_we~*|combout" $lower_name]} {
                                    incr row_we_count
                                    set we_name $point_name
                                }
                                if {[string match "*line${row}_rtl_0*|portawe*" $lower_name]} {
                                    incr ram_pin_count
                                    set ram_pin_name $point_name
                                }
                                if {$point_name eq $endpoint_name} {
                                    incr endpoint_point_count
                                }
                            }
                            puts $receipt "path corner=$label row=$row slice=$endpoint_index slack=$slack data_delay=$delay levels=$levels from={$source} scan_write={$scan_write_name} row_we={$we_name} ram_pin={$ram_pin_name} to={$target} scan_write_points=$scan_write_count row_we_points=$row_we_count ram_pin_points=$ram_pin_count endpoint_points=$endpoint_point_count"
                            if {$scan_write_count != 1 || $row_we_count != 1 || $ram_pin_count != 1 || $endpoint_point_count != 1 || $target ne $endpoint_name} {
                                post_message -type error "SCANLINE CONE: $label line$row slice$endpoint_index path does not traverse exactly one scan_write -> row WE -> RAM portawe -> porta_we_reg chain"
                                incr failures
                            } else {
                                lappend corner_we_names $we_name
                            }
                            set first 0
                        }
                        if {$slack < 0.0} {
                            post_message -type error "SCANLINE CONE: $label line$row slice$endpoint_index negative setup slack $slack"
                            incr failures
                        }
                    }
                    puts $receipt "corner=$label row=$row slice=$endpoint_index paths=$path_count worst_slack=$worst_slack reported_tns=$reported_tns"
                    incr endpoint_index
                }
            }
        }
        # The same 128-bit ownership bitmap now makes completed beats of a
        # cold software-DPYADR retarget progressively readable. Prove the
        # dynamic beat select reaches every registered row-hit decision; a
        # clean WE cone alone would not cover this new active-video path.
        set corner_hit_rows [list]
        foreach row {0 1 2 3} {
            set hit_regs [get_registers -nowarn \
                "*tunit_scanline:lines*hit${row}_q*"]
            set hit_count [get_collection_size $hit_regs]
            puts $receipt "corner=$label row=$row progressive_hit_endpoints=$hit_count"
            # Advanced Physical Optimization may duplicate a registered hit
            # decision.  Every physical copy must remain timed, but they all
            # represent one architectural row-hit endpoint.
            if {$hit_count < 1} {
                post_message -type error "SCANLINE CONE: $label line$row has no progressive hit register"
                incr failures
            } else {
                lappend corner_hit_rows $row
                set hit_index 0
                foreach_in_collection endpoint $hit_regs {
                    set endpoint_name [get_node_info -name $endpoint]
                    set paths [get_timing_paths -setup -npaths 20 -nworst 1 \
                        -from $snoop_regs -to $endpoint]
                    set path_count [get_collection_size $paths]
                    set worst_slack ""
                    set reported_tns 0.0
                    if {$path_count < 1} {
                        post_message -type error "SCANLINE CONE: $label line$row has no timed target_snoop_beats-to-progressive-hit path"
                        incr failures
                    }
                    set report_path "output_files/tunit_scanline_progressive_${label}_line${row}.txt"
                    report_timing -setup -npaths 20 -nworst 1 -detail full_path \
                        -from $snoop_regs -to $endpoint -file $report_path
                    foreach_in_collection path $paths {
                        incr total_paths
                        incr progressive_hit_paths
                        set slack [get_path_info -slack $path]
                        set source [get_node_info -name [get_path_info -from $path]]
                        set target [get_node_info -name [get_path_info -to $path]]
                        if {$worst_slack eq "" || $slack < $worst_slack} {
                            set worst_slack $slack
                        }
                        if {$slack < 0.0} {
                            set reported_tns [expr {$reported_tns + $slack}]
                            post_message -type error "SCANLINE CONE: $label line$row progressive-hit negative setup slack $slack"
                            incr failures
                        }
                        puts $receipt "progressive_path corner=$label row=$row copy=$hit_index slack=$slack from={$source} to={$target}"
                    }
                    puts $receipt "corner=$label row=$row copy=$hit_index endpoint={$endpoint_name} progressive_paths=$path_count progressive_worst_slack=$worst_slack progressive_reported_tns=$reported_tns"
                    incr hit_index
                }
            }
        }
        if {[llength [lsort -unique $corner_we_names]] != 4} {
            post_message -type error "SCANLINE CONE: $label physical WE endpoint collection is duplicate or incomplete: $corner_we_names"
            incr failures
        }
        if {[llength [lsort -unique $corner_ram_names]] != 8} {
            post_message -type error "SCANLINE CONE: $label RAM endpoint collection is duplicate or incomplete: $corner_ram_names"
            incr failures
        }
        if {[llength [lsort -unique $corner_hit_rows]] != 4} {
            post_message -type error "SCANLINE CONE: $label progressive hit logical-row collection is incomplete: $corner_hit_rows"
            incr failures
        }
    }

    delete_timing_netlist
}

puts $receipt "total_paths=$total_paths"
puts $receipt "progressive_hit_paths=$progressive_hit_paths"
if {$failures == 0 && $total_paths >= 36 && $progressive_hit_paths >= 4} {
    puts $receipt "status=PASS"
} else {
    puts $receipt "status=FAIL failures=$failures"
}
close $receipt
project_close

if {$failures != 0 || $total_paths < 36 || $progressive_hit_paths < 4} {
    error "SCANLINE CONE physical proof failed: failures=$failures total_paths=$total_paths progressive_hit_paths=$progressive_hit_paths"
}
puts "SCANLINE CONE GATE: PASS corners=4 rows=4 paths=$total_paths progressive_hit_paths=$progressive_hit_paths receipt=$receipt_path"
