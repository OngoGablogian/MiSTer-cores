#!/usr/bin/env python3
"""Check all TMS34010 PPOP operations against TI silicon semantics."""

from __future__ import annotations

import argparse
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
NETLIST = ROOT / "build_syn" / "tunit_core.v"
TB = ROOT / "sim" / "monitors" / "tb_tunit_ppop_truth.v"
MAME_REF = ROOT / "docs" / "mame-ref" / "34010gfx.hxx"
MAME_COMMIT = "f34f02505e32c1993c6a782b6814232cbfc74e36"


def run_image(netlist: Path, image: Path, timeout: int) -> tuple[int, str]:
    cc = subprocess.run(
        ["iverilog", "-g2012", "-s", "tb_tunit_ppop_truth", "-o", str(image),
         str(netlist), str(TB)], cwd=ROOT, text=True, capture_output=True,
    )
    if cc.returncode:
        return cc.returncode, cc.stdout + cc.stderr
    sim = subprocess.run(["vvp", str(image)], cwd=ROOT, text=True,
                         capture_output=True, timeout=timeout)
    return sim.returncode, sim.stdout + sim.stderr


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--label", default="tunit-ppop-0289")
    parser.add_argument("--timeout", type=int, default=300)
    args = parser.parse_args()

    if not shutil.which("iverilog") or not shutil.which("vvp"):
        print("PPOP GATE: FAIL (iverilog/vvp unavailable)", file=sys.stderr)
        return 2
    if not NETLIST.is_file() or not TB.is_file() or not MAME_REF.is_file():
        print("PPOP GATE: FAIL (required netlist/TB/MAME reference missing)", file=sys.stderr)
        return 2

    gospel = MAME_REF.read_text(encoding="utf-8", errors="strict")
    required = (
        "pixel_op13(uint32_t dstpix, uint32_t mask, uint32_t srcpix) { return (~srcpix & dstpix) & mask; }",
        "pixel_op19(uint32_t dstpix, uint32_t mask, uint32_t srcpix) { int32_t tmp = srcpix - (dstpix & mask); return (tmp < 0) ? 0 : tmp; }",
    )
    if any(line not in gospel for line in required):
        print("PPOP GATE: FAIL (local MAME 0.289 divergence witness changed unexpectedly)",
              file=sys.stderr)
        return 2

    out = ROOT / "sim" / "out" / args.label
    out.mkdir(parents=True, exist_ok=False)
    net = NETLIST.read_text(encoding="utf-8", errors="replace")

    rc, log = run_image(NETLIST, out / "stock.vvp", args.timeout)
    (out / "stock.log").write_text(log, encoding="utf-8")
    print(log, end="")
    if rc or "TEST_RESULT: PASS tb_tunit_ppop_truth" not in log:
        print("PPOP GATE: FAIL (production does not match TI silicon semantics)", file=sys.stderr)
        return 1

    # Prove the oracle rejects the two exact MAME 0.289 divergences instead of
    # silently importing them into the silicon implementation.
    mut13, n13 = re.subn(
        r"(ppop_apply = )boolean_result;",
        r"\g<1>(ppop[3:0] == 4'hd) ? (~src & dest) : boolean_result;", net, count=1,
    )
    if n13 != 1:
        print("PPOP GATE: FAIL (op13 rollback target absent/vacuous)", file=sys.stderr)
        return 1
    p13 = out / "mut_op13.v"
    p13.write_text(mut13, encoding="utf-8")
    rc13, log13 = run_image(p13, out / "mut_op13.vvp", args.timeout)
    (out / "mut_op13.log").write_text(log13, encoding="utf-8")
    if rc13 != 0 or "TEST_RESULT: FAIL tb_tunit_ppop_truth" not in log13:
        print("PPOP GATE: FAIL (MAME op13 divergence survived)", file=sys.stderr)
        return 1
    print("PPOP MUTATION MAME-op13 duplicate-NOTAND: KILLED")

    mut19, n19 = re.subn(
        r"(4'h3: ppop_apply = \()dp >= sp \? dp - sp( : \{32 \{1'sb0\}\}\);)",
        r"\g<1>sp >= dp ? sp - dp\g<2>", net, count=1,
    )
    if n19 != 1:
        print("PPOP GATE: FAIL (op19 rollback target absent/vacuous)", file=sys.stderr)
        return 1
    p19 = out / "mut_op19.v"
    p19.write_text(mut19, encoding="utf-8")
    rc19, log19 = run_image(p19, out / "mut_op19.vvp", args.timeout)
    (out / "mut_op19.log").write_text(log19, encoding="utf-8")
    if rc19 != 0 or "TEST_RESULT: FAIL tb_tunit_ppop_truth" not in log19:
        print("PPOP GATE: FAIL (MAME op19 reversed-subtract divergence survived)", file=sys.stderr)
        return 1
    print("PPOP MUTATION MAME-op19 S-minus-D: KILLED")
    print(f"PPOP GATE: PASS authority=TI-1988+Midway-assembly mame_divergence_commit={MAME_COMMIT} artifacts={out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
