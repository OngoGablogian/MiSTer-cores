#!/usr/bin/env python3
"""Fail closed before a T-unit Quartus build starts."""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parents[1]
NETLIST = ROOT / "build_syn" / "tunit_core.v"
MANIFEST = ROOT / "build_syn" / "tunit_core.manifest.json"
EXPECTED_DEFINE = {
    "universal": None,
    "adpcm": "-DTUNIT_NO_DCS",
    "dcs": "-DTUNIT_NO_ADPCM",
}
DIAG_ARTIFACT_IDS = frozenset(
    ("NBA-FLASH-DIAG", "NBA-FLASH-SRT-ORDER-DIAG")
)


def digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--variant", required=True, choices=tuple(EXPECTED_DEFINE))
    parser.add_argument(
        "--allow-dirty",
        action="store_true",
        help="permit a provenance-recorded dirty tree for an engineering build",
    )
    args = parser.parse_args()
    errors: list[str] = []
    warnings: list[str] = []
    diag_build_raw = os.environ.get("TUNIT_DIAG_BUILD", "0")
    if diag_build_raw not in {"0", "1"}:
        errors.append("TUNIT_DIAG_BUILD must be exactly 0 or 1")
    diag_requested = diag_build_raw == "1"
    ascal_policy = os.environ.get("TUNIT_ASCAL_POLICY", "")
    artifact_id = os.environ.get("TUNIT_ARTIFACT_ID", "")
    if ascal_policy not in {"main", "nearest", "bilinear"}:
        errors.append("build wrapper did not pin main|nearest|bilinear ascal policy")
    if diag_requested:
        if artifact_id not in DIAG_ARTIFACT_IDS:
            errors.append(
                "TUNIT_DIAG_BUILD=1 requires a reserved NBA flashing diagnostic ID"
            )
        if args.variant != "adpcm" or ascal_policy != "main":
            errors.append(
                "NBA flashing diagnostics require the ADPCM variant and main ascal policy"
            )
        if os.environ.get("TUNIT_ENGINEERING_BUILD", "0") != "1":
            errors.append("NBA flashing diagnostics must remain engineering builds")
    elif artifact_id in DIAG_ARTIFACT_IDS:
        errors.append(
            "reserved NBA flashing diagnostic IDs require TUNIT_DIAG_BUILD=1"
        )

    if not NETLIST.is_file() or not MANIFEST.is_file():
        errors.append("missing generated netlist/provenance; run "
                      f"tools/build_quartus_rtl.py --variant {args.variant}")
    else:
        try:
            metadata = json.loads(MANIFEST.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            errors.append(f"unreadable provenance manifest: {exc}")
            metadata = {}

        if metadata.get("variant") != args.variant:
            errors.append(
                f"netlist variant is {metadata.get('variant')!r}, "
                f"requested {args.variant!r}"
            )
        if metadata.get("family_define") != EXPECTED_DEFINE[args.variant]:
            errors.append("provenance family define does not match requested image")
        expected_extra_defines = []
        if EXPECTED_DEFINE[args.variant]:
            expected_extra_defines.append(EXPECTED_DEFINE[args.variant])
        if diag_requested:
            expected_extra_defines.append("-DTUNIT_DIAG")
        if metadata.get("extra_defines") != expected_extra_defines:
            errors.append("provenance contains unexpected Verilog defines")
        diag_flattened = "-DTUNIT_DIAG" in (metadata.get("extra_defines") or [])
        if diag_flattened != diag_requested:
            errors.append(
                "TUNIT_DIAG mismatch between flattened core and "
                "TUNIT_DIAG_BUILD environment"
            )
        if metadata.get("netlist_sha256") != digest(NETLIST):
            errors.append("netlist hash differs from its provenance manifest")
        provenance_inputs = metadata.get("inputs_sha256", {})
        if not isinstance(provenance_inputs, dict):
            errors.append("provenance input hash map is missing or malformed")
            provenance_inputs = {}
        for relative, wanted in provenance_inputs.items():
            path = ROOT / relative
            if not path.is_file():
                errors.append(f"provenance input disappeared: {relative}")
            elif digest(path) != wanted:
                errors.append(f"provenance input changed after flattening: {relative}")
        for relative in (
            "rtl/experimental/adpcm/tunit_adpcm_board.sv",
            "rtl/tunit.sdc",
            "sim/tb_tunit_adpcm_board.sv",
            "sim/tb_tunit_adpcm_reload_fixedbank.sv",
            "sim/tb_tunit_adpcm_tune_pace.sv",
            "tools/build_quartus_rtl.py",
            "tools/build_tunit.sh",
            "tools/preflight_tunit_build.py",
            "tools/run_tunit_orphan_gate.py",
            "tools/run_tunit_adpcm_reload_gate.py",
            "tools/run_tunit_adpcm_tune_gate.py",
        ):
            if relative not in provenance_inputs:
                errors.append(
                    "fixed-bank source/gate missing from provenance: " + relative
                )
        for relative in (
            "tools/run_tunit_srt_dma_order_gate.py",
            "sim/tb_tunit_srt_dma_repaint.sv",
            "sim/models/ddr3_avalon_model.sv",
        ):
            if relative not in provenance_inputs:
                errors.append(
                    "SRT/DMA order source/gate missing from provenance: " + relative
                )
        for relative in (
            "tools/run_tunit_vram_read32_planes_gate.py",
            "sim/tb_tunit_vram_read32_planes.sv",
            "docs/NBA-SCREEN-SCALE-READ32-MAME0289-GOSPEL-2026-08-26.md",
        ):
            if relative not in provenance_inputs:
                errors.append(
                    "NBA/TE screen-copy read32 proof missing from provenance: "
                    + relative
                )
        for relative in (
            "tools/run_tunit_env_transport_gate.py",
            "sim/tb_tunit_display_blank.sv",
        ):
            if relative not in provenance_inputs:
                errors.append(
                    "ENV transport source/gate missing from provenance: " + relative
                )
        for relative in (
            "tools/run_tunit_scanline_coherence_gate.py",
            "tools/run_tunit_scanline_integrated_tc_gate.py",
            "tools/run_tunit_scanline_lookahead_gate.py",
            "tools/run_tunit_scale140_rgb_gate.py",
            "tools/run_tunit_video_pageflip_gate.py",
            "sim/tb_tunit_scanline_coherence.sv",
            "sim/tb_tunit_scanline_integrated_tc.sv",
            "sim/tb_tunit_scanline_lookahead.sv",
            "sim/tb_tunit_scale140_rgb.sv",
            "sim/tb_tunit_video_ddr_pageflip.sv",
            "docs/NBA-PENDING-PREWARM-MAME0289-GOSPEL-2026-08-26.md",
            "tools/audit_tunit_scanline_physical.py",
            "tools/audit_tunit_postfit_cdc.py",
            "tools/report_tunit_scanline_snoop_timing.tcl",
        ):
            if relative not in provenance_inputs:
                errors.append(
                    "NBA scan-cache source/gate missing from provenance: " + relative
                )
        for relative in (
            "tools/run_tunit_page_fence_blank_end_gate.py",
            "sim/tb_tunit_page_fence_blank_end.sv",
            "sim/tb_tunit_page_owner_srt.sv",
            "sim/tb_tunit_display_publish.sv",
            "docs/NBA-PAGE-OWNER-SOURCE-CONTRACT-2026-08-23.md",
        ):
            if relative not in provenance_inputs:
                errors.append(
                    "page/SRT ownership source/gate missing from provenance: "
                    + relative
                )
        if diag_requested:
            for relative in (
                "rtl/tunit/tunit_page_fence.sv",
                "sim/tb_tunit_page_diag.sv",
                "sim/tb_tunit_page_fence.sv",
                "tools/run_tunit_page_fence_gate.py",
            ):
                if relative not in provenance_inputs:
                    errors.append(
                        "page-diagnostic source/gate missing from provenance: "
                        + relative
                    )
        if metadata.get("git_dirty"):
            if args.allow_dirty:
                warnings.append("engineering build: source tree was dirty when "
                                "the netlist was generated")
            else:
                errors.append("source tree was dirty when the netlist was "
                              "generated; commit it or pass --allow-dirty for "
                              "an explicitly engineering-only build")

    framework = subprocess.run(
        [sys.executable, str(ROOT / "tools" / "verify_framework_snapshot.py")],
        cwd=ROOT, text=True, capture_output=True, check=False,
    )
    if framework.returncode:
        errors.append("MiSTer framework/PLL provenance verification failed")

    ascal_gate = subprocess.run(
        [
            sys.executable,
            str(ROOT / "tools" / "check_tunit_ascal_policy.py"),
            "--policy", ascal_policy or "main",
            "--artifact-id", artifact_id,
        ],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    if ascal_gate.returncode:
        errors.append("T-unit ascal compile-time policy contract failed")

    pll = (ROOT / "rtl" / "pll" / "pll_0002.v").read_text(encoding="utf-8")
    for needle in (
        '.output_clock_frequency0("80.000000 MHz")',
        '.output_clock_frequency1("80.000000 MHz")',
        '.phase_shift1("-3515 ps")',
        '.output_clock_frequency2("12.000000 MHz")',
        '.output_clock_frequency3("24.000000 MHz")',
    ):
        if needle not in pll:
            errors.append(f"PLL contract missing {needle}")

    top_source = (ROOT / "rtl" / "tunit" / "tunit_top.sv").read_text(
        encoding="utf-8"
    )
    for needle in ("pix_div==4'd9", "cpu_sum>=10'd320", "27'd80000000"):
        if needle not in top_source:
            errors.append(f"80 MHz cadence contract missing {needle}")
    for needle in (
        # Retained for the MUT_TUNIT_SOUND_LAST discrimination arm.  Production
        # intentionally puts the low-bandwidth sound client ahead of graphics;
        # the active branch is checked below instead of inferred from this wire.
        ".dcs_safe(gfx_dcs_safe)",
        ".c_priority(gfx_dcs_safe)",
        ".c_addr(sddr_addr)",
        "audio_tel_d_cdc[7] | adpcm_cdc_overflow",
        ".active_page(active_page_w)",
        ".cpu_snoop_pending,.cpu_snoop_overflow",
        ".display_row,.next_row,.next2_row,.display_col",
        "tunit_page_diag page_diag",
        ".board_reset_sys(adpcm_board_reset || !roms_loaded_q || loader_rst_sound)",
        ".epoch_reset_sys(adpcm_cache_epoch_reset)",
        "!roms_loaded_q || loader_rst_sound || snd_dl_busy",
        ".snd_dl_we(snd_wr && !sound_dcs)",
    ):
        if needle not in top_source:
            errors.append(f"shared graphics/sound arbitration wiring missing {needle}")

    scanline_source = (ROOT / "rtl" / "tunit" / "tunit_scanline.sv").read_text(
        encoding="utf-8"
    )
    for needle in (
        'logic [63:0] line0 [0:NBEAT-1];',
        'logic [63:0] line1 [0:NBEAT-1];',
        'logic [63:0] line2 [0:NBEAT-1];',
        'logic [63:0] line3 [0:NBEAT-1];',
        'logic [NBEAT-1:0] target_snoop_beats;',
        'wire logic pixel_ready = hit0 || hit1 || hit2 || hit3;',
        'target_snoop_beats[vram_raddr[8:2]]',
        'assign vram_rvalid = hit0_q || hit1_q || hit2_q || hit3_q;',
    ):
        if needle not in scanline_source:
            errors.append(f"progressive scan-cache contract missing {needle}")

    video_top_source = (
        ROOT / "rtl" / "tunit" / "tunit_video_top.sv"
    ).read_text(encoding="utf-8")
    for needle in (
        "palette_data_valid <= vram_rvalid;",
        "? palette_data : 16'h0000;",
        "`ifdef MUT_TUNIT_SCANMISS_PALETTE0",
    ):
        if needle not in video_top_source:
            errors.append(f"literal-black scan-miss contract missing {needle}")

    vram_source = (ROOT / "rtl" / "sdram" / "stv_vram_ddr_top.sv").read_text(
        encoding="utf-8"
    )
    for needle in (
        "tst_waccept && (tst_waccept_be == 8'hff)",
        "(l_gnt == 3'd2) || (l_gnt == 3'd4)",
        'cpu_snoop_pending',
        'cpu_snoop_overflow',
    ):
        if needle not in vram_source:
            errors.append(f"A/C/D publication contract missing {needle}")

    vram_field_source = (
        ROOT / "rtl" / "sdram" / "vram_sdram.sv"
    ).read_text(encoding="utf-8")
    for needle in (
        "wire [31:0] vlong = vb_l ?",
        "wire logic read32_aligned = !we_l && (szl == 6'd32) && (bo == 4'd0);",
        "wire logic read32_aligned_eff = read32_aligned;",
        "`ifdef MUT_TUNIT_VRAM_READ32_TRUNCATE",
        "read32_aligned_eff ? vlong",
    ):
        if needle not in vram_field_source:
            errors.append(f"aligned VRAM read32 contract missing {needle}")

    adpcm_board_source = (
        ROOT / "rtl" / "experimental" / "adpcm" / "tunit_adpcm_board.sv"
    ).read_text(encoding="utf-8")
    for needle in (
        '(* ramstyle = "M10K" *) logic [7:0] fixed_rom [0:16383];',
        "always_ff @(posedge snd_dl_clk)",
        "always_ff @(posedge clk)",
        "snd_dl_addr[23:14] == 10'h00f",
        "fixed_q  <= fixed_rom[cpu_addr[13:0]];",
        "fixed_aq <= cpu_addr[13:0];",
        "fixed_q_valid",
    ):
        if needle not in adpcm_board_source:
            errors.append(f"ADPCM single-clock fixed-bank contract missing {needle}")
    fixed_section_match = re.search(
        r"logic\s+fixed_q_valid;(?P<body>.*?)`ifdef\s+MUT_TUNIT_NO_FIXED_BANK",
        adpcm_board_source,
        re.DOTALL,
    )
    if fixed_section_match is None:
        errors.append("ADPCM fixed-bank implementation section is missing")
    else:
        fixed_section = fixed_section_match.group("body")
        single_clock_shape = re.compile(
            r"always_ff\s*@\(posedge\s+snd_dl_clk\)\s*begin\s*"
            r"if\s*\(snd_dl_we\s*&&\s*\(snd_dl_addr\[23:14\]\s*==\s*10'h00f\)\)\s*"
            r"fixed_rom\[snd_dl_addr\[13:0\]\]\s*<=\s*snd_dl_data;\s*"
            r"fixed_q\s*<=\s*fixed_rom\[cpu_addr\[13:0\]\];\s*"
            r"fixed_aq\s*<=\s*cpu_addr\[13:0\];\s*end",
            re.DOTALL,
        )
        if single_clock_shape.search(fixed_section) is None:
            errors.append(
                "ADPCM fixed-bank RAM read/write/tag are not one canonical snd_dl_clk block"
            )
        valid_shape = re.compile(
            r"always_ff\s*@\(posedge\s+clk\)\s*begin\s*"
            r"if\s*\(reset\)\s*fixed_q_valid\s*<=\s*1'b0;\s*"
            r"else\s*fixed_q_valid\s*<=\s*1'b1;\s*end",
            re.DOTALL,
        )
        if valid_shape.search(fixed_section) is None:
            errors.append(
                "ADPCM fixed-bank valid is not reset-gated wholly in the sound domain"
            )
        if re.search(r"if\s*\(reset\).*?(fixed_q|fixed_aq)\s*<=", fixed_section, re.DOTALL):
            errors.append("ADPCM M10K read data/address are reset and may become uninferable")
    fixed_ready_shape = re.compile(
        r"`ifdef\s+MUT_TUNIT_NO_FIXED_BANK\s*"
        r"(?:.|\n)*?wire\s+fixed_ready\s*=\s*1'b0;\s*`else\s*"
        r"wire\s+fixed_ready\s*=\s*cpu_rom_fixed\s*&&\s*"
        r"fixed_q_valid\s*&&\s*\(fixed_aq\s*==\s*cpu_addr\[13:0\]\);\s*`endif",
        re.DOTALL,
    )
    if fixed_ready_shape.search(adpcm_board_source) is None:
        errors.append("ADPCM fixed-bank consumption lost its valid/address-tag guard")
    if 'ramstyle = "M10K, no_rw_check"' in adpcm_board_source:
        errors.append("ADPCM fixed bank carries forbidden no_rw_check")

    build_wrapper_source = (ROOT / "tools" / "build_tunit.sh").read_text(
        encoding="utf-8"
    )
    for needle in (
        "ADPCM FIXED-BANK MAP GATE PASS",
        r"Warning \(276027\):.*fixed_rom",
        "fixed_rom_rtl_0.*;[[:space:]]*M10K",
    ):
        if needle not in build_wrapper_source:
            errors.append(f"ADPCM post-map inference gate is missing {needle}")

    for relative in (
        "tools/run_tunit_adpcm_tune_gate.py",
        "tools/run_tunit_adpcm_realrom.py",
        "tools/run_tunit_adpcm_reload_gate.py",
        "sim/tb_tunit_adpcm_tune_pace.sv",
        "sim/tb_tunit_adpcm_reload_fixedbank.sv",
        "sim/tb_tunit_adpcm_cache_epoch.sv",
        "sim/trace_tunit_adpcm_command_ym.lua",
        "docs/goldens/nbajamte_ym92_mame0280.json",
    ):
        if not (ROOT / relative).is_file():
            errors.append(f"ADPCM qualification input is missing: {relative}")

    video_source = (ROOT / "rtl" / "tunit" / "tunit_video.sv").read_text(
        encoding="utf-8"
    )
    for needle in (
        "s0_active = geom_active;",
        "s0_de = geom_active;",
        "(!disp_enable_eff && !env_srt_visible_hold_eff);",
        "`ifdef MUT_TUNIT_ENV_COLLAPSE_TRANSPORT",
        "`ifdef MUT_TUNIT_ENV_SRT_REBLANK",
    ):
        if needle not in video_source:
            errors.append("ENV transport-hold implementation missing: " + needle)

    diag_overlay = (ROOT / "rtl" / "diag" / "tunit_diag_overlay.sv").read_text(
        encoding="utf-8"
    )
    wrapper_source = (ROOT / "Arcade-TUnit.sv").read_text(encoding="utf-8")
    if "video_page ? dbg_page_state" not in diag_overlay:
        errors.append("video diagnostic page lacks active-vs-wanted publication state")
    if "localparam logic [1:0] page_id = 2'd2;" not in diag_overlay:
        errors.append("cabinet diagnostic is not hard-pinned to the magenta video page")
    for stale_page_alternator in ("page_cnt", "old_vb_pg"):
        if stale_page_alternator in diag_overlay:
            errors.append(
                "cabinet diagnostic still contains cycling page state: "
                f"{stale_page_alternator}"
            )
    if ".video_underrun_count,.dbg_blitq,.dbg_page_state" not in wrapper_source:
        errors.append("video diagnostic underrun/queue/page witnesses are not all wired")

    ddr_arb = (ROOT / "rtl" / "tunit" / "tunit_ddr3_arb.sv").read_text(
        encoding="utf-8"
    )
    priority_arms = re.search(
        r"`ifdef\s+MUT_TUNIT_SOUND_LAST(?P<mutation>.*?)"
        r"`else(?P<production>.*?)`endif",
        ddr_arb,
        re.S,
    )
    if priority_arms is None:
        errors.append("sound/graphics priority mutation boundary is missing")
    else:
        mutation_arm = priority_arms.group("mutation")
        production_arm = priority_arms.group("production")
        if "else if(c_req&&c_priority)" not in mutation_arm:
            errors.append("sound-last mutation no longer exercises c_priority")
        sound_pos = production_arm.find("else if(c_req)")
        gfx_pos = production_arm.find("else if(b_req)")
        if sound_pos < 0 or gfx_pos < 0 or sound_pos > gfx_pos:
            errors.append(
                "production DDR3 arbitration does not grant sound before graphics"
            )
        if "c_priority" in production_arm:
            errors.append(
                "production DDR3 arbitration unexpectedly depends on the mutation-only "
                "c_priority predicate"
            )

    gfx_ddr = (ROOT / "rtl" / "common" / "midway_gfx_ddr_top.sv").read_text(
        encoding="utf-8"
    )
    if (
        "!PREFETCH_ENABLE || !USE_STREAM_HINT ||" not in gfx_ddr
        or "!src_active || src_stalled_w ||" not in gfx_ddr
    ):
        errors.append("DCS-safe predicate lacks the paused-source starvation escape")

    tunit_sdc = (ROOT / "rtl" / "tunit.sdc").read_text(encoding="utf-8")
    for needle in (
        "set adpcm_cdc_regs [get_registers -nowarn",
        "T-unit ADPCM CDC absent in this sound-family variant",
        "elseif {[get_collection_size $core_clks] == 0 || "
        "[get_collection_size $snd_clks] == 0}",
        "set cdc_request_addr [get_registers -nowarn",
        "set cdc_response_line [get_registers -nowarn",
        "set cdc_audio_hold [get_registers -nowarn",
        "set cdc_active_command [get_registers -nowarn",
        "TUNIT_BUILD_VARIANT",
        "T-unit ADPCM CDC hierarchy is EMPTY",
        "T-unit CDC payload bundle missing",
        "quasi-static exception is the fixed-ROM q/address tag",
        "set_clock_groups -asynchronous -group $core_clks -group $snd_clks",
    ):
        if needle not in tunit_sdc:
            errors.append(f"sound-family-aware ADPCM CDC constraint missing {needle}")

    sdram = (ROOT / "rtl" / "sdram" / "sdram_stock.sv").read_text(
        encoding="utf-8"
    )
    if "cycles_per_refresh  = 14'd600" not in sdram:
        errors.append("SDRAM refresh is not the audited 600-clock interval")
    if "if(refresh_count > (cycles_per_refresh<<1))" in sdram:
        errors.append("idle SDRAM refresh still permits the obsolete double interval")

    qsf = (ROOT / "Arcade-TUnit.qsf").read_text(encoding="utf-8")
    for needle in (
        "set_global_assignment -name DEVICE 5CSEBA6U23I7",
        "set_global_assignment -name PHYSICAL_SYNTHESIS_REGISTER_RETIMING OFF",
        # Effort 6.0 remains the qualified high-effort recipe. The cb6cf9e
        # structural repair closed the game clock with ample margin at seed 11,
        # but that placement missed one shared-framework HDMI route by 0.111 ns.
        # Seed 10 is the better measured placement basin for the closed netlist.
        "set_global_assignment -name PLACEMENT_EFFORT_MULTIPLIER 6.0",
        "set_global_assignment -name SEED 10",
        'set_global_assignment -name VERILOG_MACRO "SYNTHESIS=1"',
    ):
        if needle not in qsf:
            errors.append(f"Quartus project contract missing {needle}")
    diag_qsf = ROOT / "tools" / "tunit_diag_qsf.tcl"
    build_guard = ROOT / "tools" / "tunit_build_guard.tcl"
    diag_qsf_guard = (
        'if {[info exists ::env(TUNIT_DIAG_BUILD)] && '
        '$::env(TUNIT_DIAG_BUILD) eq "1"} {\n'
        '    set_global_assignment -name VERILOG_MACRO "TUNIT_DIAG=1"\n'
        '}'
    )
    if "source tools/tunit_diag_qsf.tcl" not in qsf:
        errors.append("Quartus project does not source its TUNIT_DIAG guard")
    if "source tools/tunit_build_guard.tcl" not in qsf:
        errors.append("Quartus project does not source its wrapper-only build guard")
    build_guard_text = (
        build_guard.read_text(encoding="utf-8") if build_guard.is_file() else ""
    )
    for needle in (
        "TUNIT_BUILD_WRAPPER_ACTIVE",
        "TUNIT_BUILD_VARIANT",
        "TUNIT_FIFO_TICKET_HELD",
        "FPGA_QUARTUS_LOCK_HELD",
        "FPGA_SESSION",
        "direct Quartus may compile a stale ignored netlist",
    ):
        if needle not in build_guard_text:
            errors.append(f"Quartus wrapper-only build guard missing {needle}")
    diag_qsf_text = (
        diag_qsf.read_text(encoding="utf-8") if diag_qsf.is_file() else ""
    )
    if diag_qsf_guard not in diag_qsf_text.replace("\r\n", "\n"):
        errors.append("Quartus TUNIT_DIAG macro is not environment-guarded")
    if qsf.count('VERILOG_MACRO "TUNIT_DIAG=1"') != 0:
        errors.append("Quartus QSF contains an unguarded TUNIT_DIAG macro")
    if diag_qsf_text.count('VERILOG_MACRO "TUNIT_DIAG=1"') != 1:
        errors.append("Quartus project must contain exactly one guarded TUNIT_DIAG macro")

    if NETLIST.is_file():
        netlist = NETLIST.read_text(encoding="utf-8", errors="replace")
        match = re.search(r"\bmodule tunit_top\b.*?\bendmodule\b", netlist, re.S)
        if match is None:
            errors.append("generated netlist has no tunit_top module")
        else:
            top = match.group(0)
            has_dcs = "tunit_dcs2k dcs" in top
            has_adpcm = "tunit_adpcm_board adpcm_board" in top
            has_sound_cdc = "tunit_sound_cdc sound_cdc" in top
            if args.variant == "universal":
                if not has_dcs or not has_adpcm or not has_sound_cdc:
                    errors.append(
                        "universal image hierarchy does not contain both sound "
                        "paths and the ADPCM CDC"
                    )
                if "assign profile_build_ok = 1'b1;" not in top:
                    errors.append(
                        "universal image lacks its all-profile reset release"
                    )
            elif args.variant == "adpcm":
                if has_dcs or not has_adpcm or not has_sound_cdc:
                    errors.append("ADPCM image hierarchy does not contain only "
                                  "the ADPCM sound path and its CDC")
                if "assign profile_build_ok = profile_q != 3'd1;" not in top:
                    errors.append("ADPCM image lacks its incompatible-profile reset gate")
            else:
                if not has_dcs or has_adpcm or has_sound_cdc:
                    errors.append("DCS image hierarchy does not contain only the DCS path")
                if "assign profile_build_ok = profile_q == 3'd1;" not in top:
                    errors.append("DCS image lacks its incompatible-profile reset gate")
        if "no_rw_check" in netlist.lower():
            errors.append("generated game-side netlist contains no_rw_check")
        if "tunit_protection_all protection" not in netlist:
            errors.append("all-profile protection is absent from production netlist")
        if "tunit_inputs inputs" not in netlist:
            errors.append("all-profile cabinet input mapper is absent from production netlist")

    for mra in sorted((ROOT / "mra").glob("*.mra")):
        try:
            root = ET.parse(mra).getroot()
            order = [int(node.attrib["index"]) for node in root.findall("rom")]
        except (ET.ParseError, KeyError, ValueError) as exc:
            errors.append(f"{mra.name}: malformed MRA ROM list: {exc}")
            continue
        if order[:4] != [3, 0, 1, 2]:
            errors.append(f"{mra.name}: descriptor is not first (order={order})")

    if errors:
        for error in errors:
            print(f"PREFLIGHT: FAIL -- {error}")
        return 1
    for warning in warnings:
        print(f"PREFLIGHT: WARNING -- {warning}")
    print(framework.stdout.strip())
    print(ascal_gate.stdout.strip())
    print(
        f"PREFLIGHT: PASS variant={args.variant} "
        f"netlist_sha256={digest(NETLIST)[:16]}... "
        "pll=80MHz sdram_phase=-3515ps refresh<=625clks"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
