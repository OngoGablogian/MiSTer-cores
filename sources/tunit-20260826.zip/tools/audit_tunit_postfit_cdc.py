#!/usr/bin/env python3
"""Prove the completed ADPCM fit constrained every physical CDC payload copy."""

from __future__ import annotations

from hashlib import sha256
from pathlib import Path
import re
import sys


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "output_files"
FIT_REPORT = OUT / "Arcade-TUnit.fit.rpt"
FIT_LOG = OUT / "build_fit.log"
RECEIPT = OUT / "tunit_postfit_cdc_receipt.txt"
CDC_RE = re.compile(
    r"T-unit CDC payload skew: request=(\d+) \(base=(\d+) duplicate=(\d+)\) "
    r"response=(\d+) audio=(\d+) command=(\d+) telemetry=(\d+) "
    r"register\(s\) constrained"
)
DUP_RE = re.compile(
    r"tunit_adpcm_rom_cdc:adpcm_cdc\|request_addr\[(\d+)\].*?;\s*Duplicated\s*;"
    r".*?request_addr\[\1\]~DUPLICATE",
    re.IGNORECASE,
)


def digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def refuse(message: str) -> int:
    print(f"TUNIT POST-FIT CDC: BLOCKED -- {message}", file=sys.stderr)
    return 1


def main() -> int:
    for path in (FIT_REPORT, FIT_LOG):
        if not path.is_file() or path.stat().st_size < 2048:
            return refuse(f"missing or truncated {path.name}")
    report = FIT_REPORT.read_text(encoding="utf-8", errors="replace")
    log = FIT_LOG.read_text(encoding="utf-8", errors="replace")
    if not re.search(r"Fitter Status\s*;\s*Successful\s*-", report):
        return refuse("Fitter report is not successful")
    if "Fitter was successful. 0 errors" not in log:
        return refuse("Fitter log lacks its zero-error completion marker")
    rejected = (
        "T-unit CDC payload bundle missing or partial",
        "T-unit CDC payload skew collection is EMPTY",
        "T-unit CDC payload hierarchy survived in the DCS-only variant",
    )
    if any(marker in report or marker in log for marker in rejected):
        return refuse("Fitter evidence contains a rejected CDC diagnostic")
    matches = CDC_RE.findall(report)
    if not matches:
        matches = CDC_RE.findall(log)
    if not matches:
        return refuse("no classified CDC payload constraint message")
    final = tuple(int(value) for value in matches[-1])
    request, base, duplicates, response, audio, command, telemetry = final
    if not (18 <= base <= 21):
        return refuse(f"logical request_addr count is {base}, expected 18..21")
    if request != base + duplicates:
        return refuse(
            f"physical request count {request} != base {base} + duplicates {duplicates}"
        )
    if (response, audio, command, telemetry) != (64, 16, 8, 0):
        return refuse(
            "non-request CDC tuple is "
            f"{(response, audio, command, telemetry)}, expected (64, 16, 8, 0)"
        )
    duplicate_bits = sorted(int(bit) for bit in DUP_RE.findall(report))
    if len(duplicate_bits) != duplicates or any(
        bit < 0 or bit > 20 for bit in duplicate_bits
    ):
        return refuse(
            f"physical request_addr duplicate bits are {duplicate_bits}, "
            f"but the classified duplicate count is {duplicates}"
        )
    body = "\n".join(
        (
            "TUNIT POST-FIT CDC RECEIPT",
            f"fit_report_sha256={digest(FIT_REPORT)}",
            f"fit_log_sha256={digest(FIT_LOG)}",
            f"request={request}",
            f"base={base}",
            f"duplicates={duplicates}",
            "duplicate_bits=" + ",".join(str(bit) for bit in duplicate_bits),
            "response=64",
            "audio=16",
            "command=8",
            "telemetry=0",
            "status=PASS",
            "",
        )
    )
    RECEIPT.write_text(body, encoding="utf-8")
    print(
        f"TUNIT POST-FIT CDC: PASS request={request} base={base} "
        f"duplicates={duplicates} bits={duplicate_bits} "
        "response=64 audio=16 command=8"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
