#!/usr/bin/env python3
"""Verify the pinned MiSTer chassis snapshot and project source closure."""

from __future__ import annotations

from hashlib import sha1
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "docs" / "MISTER-FRAMEWORK-MANIFEST.md"
ROW = re.compile(r"^([0-9a-f]{40})  (.+)$")
QIP_ROW = re.compile(r"^set_global_assignment -name \S+_FILE\s+(.+)$")
SOURCE_ROW = re.compile(r"^source\s+(.+)$")
LOCAL_DIVERGENCES = {
    # The donor generated 80 MHz. T-unit now deliberately uses that frequency
    # with a locally regenerated -3515 ps SDRAM phase; keep both immutable blob
    # IDs so provenance cannot silently drift in either direction.
    "rtl/pll/pll_0002.v": (
        "3b2cd234e9ac1a2d12dc33582972de794d8638c9",
        "a81c0db58405ee4c618280f069af428e25b15e3b",
    ),
    # Quartus 17 reports the donor's nonexistent arc* source filter as ignored,
    # and the release gate treats every ignored constraint as fatal. Removing
    # that one unmatched wildcard changes no timed path; retain the donor blob
    # in the manifest and pin the local hygiene-only divergence here.
    "sys/sys_top.sdc": (
        "d76e3bd46ac4dd6d85072af9b5bae85892737240",
        "e0546d8d4818e76645e8be8b510327c1fa140285",
    ),
    # Cabinet-only NBA scaler discriminator.  The donor leaves ascal's filter
    # selection under MiSTer Main; T-unit adds two engineering compile-time
    # policies for the coefficient-free built-in nearest/bilinear modes and
    # makes the five-bit VHDL port width explicit.  The default branch is the
    # donor behavior.
    "sys/sys_top.v": (
        "a646213508db92a25ab07db0645fb7387cc34a62",
        "fc4a3eb03559f758cf9edcdf91ede300264d01ed",
    ),
    # Preserve the scaler's exact max(R,G,B) adaptive-luminance function while
    # expressing it as parallel pairwise comparisons. The donor's sequential
    # R/G-then-B form synthesized into two serial comparator/mux chains and was
    # the only remaining pll_hdmi setup failure in the DCS seed-7 fit.
    "sys/ascal.vhd": (
        "a735e6b40db8b1e7b5ef2c7836a11d521a96eb7c",
        "ef9725ad366437b7392024964244c520d80c9597",
    ),
}


def blob_id(path: Path) -> str:
    data = path.read_bytes()
    return sha1(f"blob {len(data)}\0".encode("ascii") + data).hexdigest()


def main() -> int:
    expected: dict[str, str] = {}
    for line in MANIFEST.read_text(encoding="utf-8").splitlines():
        match = ROW.match(line)
        if match:
            expected[match.group(2)] = match.group(1)

    errors: list[str] = []
    for relative, wanted in expected.items():
        path = ROOT / relative
        if not path.is_file():
            errors.append(f"missing pinned file: {relative}")
        else:
            actual = blob_id(path)
            if relative in LOCAL_DIVERGENCES:
                donor, local = LOCAL_DIVERGENCES[relative]
                if wanted != donor:
                    errors.append(
                        f"manifest donor mismatch: {relative} expected={donor} actual={wanted}"
                    )
                if actual != local:
                    errors.append(
                        f"local divergence mismatch: {relative} expected={local} actual={actual}"
                    )
            elif actual != wanted:
                errors.append(
                    f"blob mismatch: {relative} expected={wanted} actual={actual}"
                )

    qip_refs: list[str] = []
    for line in (ROOT / "files.qip").read_text(encoding="utf-8").splitlines():
        match = QIP_ROW.match(line.strip())
        if match:
            qip_refs.append(match.group(1).strip())
    for relative in qip_refs:
        if not (ROOT / relative).is_file():
            errors.append(f"missing files.qip source: {relative}")

    qsf_sources: list[str] = []
    for line in (ROOT / "Arcade-TUnit.qsf").read_text(encoding="utf-8").splitlines():
        match = SOURCE_ROW.match(line.strip())
        if match:
            qsf_sources.append(match.group(1).strip())
    for relative in qsf_sources:
        if not (ROOT / relative).is_file():
            errors.append(f"missing QSF source script: {relative}")

    if len(expected) != 61:
        errors.append(f"framework manifest contains {len(expected)} files, expected 61")
    if len(qip_refs) != len(set(qip_refs)):
        errors.append("files.qip contains duplicate file assignments")

    if errors:
        for error in errors:
            print(f"FAIL: {error}")
        return 1

    print(
        f"PASS: framework snapshot exact={len(expected) - len(LOCAL_DIVERGENCES)} "
        f"documented_divergences={len(LOCAL_DIVERGENCES)} "
        f"qip_sources={len(qip_refs)} qsf_scripts={len(qsf_sources)}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
