#!/usr/bin/env python3
"""Refuse to assemble an RBF unless STA and fitted RAM semantics are safe.

WHY THIS EXISTS. The Wolf-unit session produced a release-candidate RBF that
FAILED TIMING and their build script emitted it anyway:

    Critical Warning (332148): Timing requirements not met
    Worst-case setup slack -0.031, TNS -0.231, on the CORE clock

Their words, and they are exactly right: a FRESH, correctly-hashed,
provenance-clean RBF that failed STA is the most dangerous artifact any of us can
hand a cabinet, BECAUSE EVERY FRESHNESS CHECK PASSES IT. Timestamp, hash, build
id, "was it rebuilt after the last edit" -- all green. The only thing wrong with
it is the one thing none of those checks look at.

This tree has already done it: output_files/Arcade-TUnit.rbf.MISTIMED-DO-NOT-FLASH
was a flashable artifact sitting in the build output while the handoff claimed no
RBF had been assembled from the mistimed result.

So assembly is gated on the TIMING REPORT, not on freshness. Run this BEFORE
quartus_asm, and treat a non-zero exit as "there is no candidate".

    python tools/assemble_gate.py                 # check only
    python tools/assemble_gate.py --assemble      # check, then run quartus_asm

DESIGN NOTES, each paid for by a specific failure today:
  * A ZERO-BYTE or truncated report is INCONCLUSIVE, never clean. `grep -c` on an
    empty file exits 0 and reports 0, indistinguishable from success -- the
    Y-unit session reported "map errors: 0" twice off an empty log.
  * The report must be NEWER than the netlist it claims to describe, or it
    describes something else. A stale report is how a 31-agent design study got
    aimed at a non-binding timing cone.
  * EVERY corner and EVERY check type, not just worst-case setup. Hold, recovery,
    removal and minimum-pulse-width failures are equally unflashable, and an
    HDMI-domain setup failure at one corner went unnoticed here for a day because
    only the core clock was being read.
  * No allowlist, no tolerance, no "close enough". If a corner needs to be
    excluded, that is a human decision recorded in the SDC, not a threshold here.
  * A game-side inferred RAM whose primitive uses DON'T CARE mixed-port
    read-during-write is accepted only when Quartus explicitly says it inserted
    pass-through logic to preserve the original RTL behavior and the map report
    contains the corresponding bypass nodes. The fitted circuit, not just the
    primitive row or a source attribute, is the authority.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
STA_SUMMARY = ROOT / "output_files" / "Arcade-TUnit.sta.summary"
NETLIST = ROOT / "build_syn" / "tunit_core.v"
BUILD_MANIFEST = ROOT / "build_syn" / "tunit_core.manifest.json"
MAP_LOG = ROOT / "output_files" / "build_map.log"
FIT_LOG = ROOT / "output_files" / "build_fit.log"
STA_LOG = ROOT / "output_files" / "build_sta.log"
SCANLINE_STA_LOG = ROOT / "output_files" / "build_scanline_sta.log"
MAP_REPORT = ROOT / "output_files" / "Arcade-TUnit.map.rpt"
FIT_REPORT = ROOT / "output_files" / "Arcade-TUnit.fit.rpt"
MIN_REPORT_BYTES = 2048          # a real STA summary is tens of KB

SLACK_RE = re.compile(r"^Slack\s*:\s*(-?\d+\.\d+)", re.M)
TYPE_RE = re.compile(r"^Type\s*:\s*(.+?)\s*$", re.M)


def fail(msg: str) -> int:
    print(f"ASSEMBLE GATE: BLOCKED -- {msg}", file=sys.stderr)
    return 1


def fitted_ram_semantics(
    fit_text: str, map_text: str, map_report_text: str
) -> tuple[int, set[str], list[str]]:
    """Return defined inferred-row count, protected RAM names, and findings.

    The fitter table also contains explicit ``altshift_taps`` primitives whose
    implementation happens to end in an ``ALTSYNCRAM`` atom.  Those are shift
    registers, not RAM inferred from synchronous RTL, and Quartus therefore
    does not emit Warning 276020 or ``*_bypass`` nodes for them.  Limit this
    check to rows whose hierarchy contains the exact inferred-RAM instance
    type ``altsyncram:``; that is the same population described by 276020.
    """
    inferred_ram_rows = [
        line for line in fit_text.splitlines()
        if (
            "tunit_top:core" in line
            and "|altsyncram:" in line
            and "ALTSYNCRAM" in line
        )
    ]
    if not inferred_ram_rows:
        return 0, set(), ["no T-unit ALTSYNCRAM rows"]
    undefined_ram_rows = [
        line for line in inferred_ram_rows
        if re.search(r";\s*Don(?:'|\u2019)t care\s*;", line, re.IGNORECASE)
    ]
    undefined_names = set()
    for line in undefined_ram_rows:
        match = re.search(r"\|altsyncram:([^|;]+)", line)
        undefined_names.add(match.group(1) if match else "<unknown>")
    unprotected = []
    protected = set()
    for name in sorted(undefined_names):
        semantic_warning = re.search(
            r'Warning \(276020\): Inferred RAM node "[^"\r\n]*\|' +
            re.escape(name) +
            r'" from synchronous design logic\.\s+Pass-through logic has '
            r'been added to match the read-during-write behavior of the '
            r'original design\.',
            map_text,
        )
        bypass_nodes = f"|{name}_bypass[" in map_report_text
        if semantic_warning and bypass_nodes:
            protected.add(name)
            continue
        missing = []
        if not semantic_warning:
            missing.append("mapper semantic warning")
        if not bypass_nodes:
            missing.append("map-report bypass nodes")
        unprotected.append(f"{name} ({', '.join(missing)})")
    return (
        len(inferred_ram_rows) - len(undefined_ram_rows),
        protected,
        unprotected,
    )


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--assemble", action="store_true",
                    help="run quartus_asm if and only if the gate passes")
    # Testing the gate must not require swapping the real artifact out from
    # under it. Wolf validated their equivalent THREE ways -- real failing log,
    # clean log, and truncated log -- and the third arm matters as much as the
    # first, because an empty report must never read as clean. That validation
    # is only cheap if the gate can be pointed at a fixture.
    ap.add_argument("--summary", type=Path, default=None,
                    help="STA summary to judge (testing only; defaults to the "
                         "real one). Never combine with --assemble.")
    args = ap.parse_args()
    if args.summary and args.assemble:
        return fail("--summary is for validating the gate; refusing to assemble "
                    "a real image from a substituted report")
    global STA_SUMMARY
    if args.summary:
        STA_SUMMARY = args.summary

    if not STA_SUMMARY.is_file():
        return fail(f"no STA summary at {STA_SUMMARY} -- STA has not run, so "
                    "there is no evidence of closure")

    size = STA_SUMMARY.stat().st_size
    if size < MIN_REPORT_BYTES:
        return fail(f"STA summary is {size} bytes (< {MIN_REPORT_BYTES}) -- "
                    "INCONCLUSIVE, not clean. A truncated or empty report greps "
                    "clean and proves nothing")

    freshness_inputs = [
        NETLIST,
        BUILD_MANIFEST,
        ROOT / "Arcade-TUnit.qsf",
        ROOT / "rtl" / "tunit.sdc",
        ROOT / "rtl" / "pll" / "pll_0002.v",
        ROOT / "tools" / "build_tunit.sh",
        ROOT / "tools" / "assemble_gate.py",
        ROOT / "tools" / "audit_tunit_scanline_physical.py",
        ROOT / "tools" / "audit_tunit_postfit_cdc.py",
        ROOT / "tools" / "report_tunit_scanline_snoop_timing.tcl",
    ]
    if BUILD_MANIFEST.is_file():
        try:
            metadata = json.loads(BUILD_MANIFEST.read_text(encoding="utf-8"))
            freshness_inputs.extend(
                ROOT / relative
                for relative in metadata.get("inputs_sha256", {})
            )
        except (json.JSONDecodeError, OSError) as exc:
            return fail(f"build provenance is unparseable: {exc}")
    missing_inputs = [path for path in freshness_inputs if not path.is_file()]
    if missing_inputs:
        return fail("build input missing at gate time: " +
                    ", ".join(str(path.relative_to(ROOT)) for path in missing_inputs))
    newest = max(freshness_inputs, key=lambda path: path.stat().st_mtime)
    if STA_SUMMARY.stat().st_mtime < newest.stat().st_mtime:
        return fail(f"STA summary is OLDER than {newest.relative_to(ROOT)} -- "
                    "it describes different build inputs. Re-run map/fit/sta")

    if not args.summary:
        stage_logs = (MAP_LOG, FIT_LOG, STA_LOG, SCANLINE_STA_LOG)
        missing_logs = [
            path.name for path in stage_logs
            if not path.is_file() or path.stat().st_size < 512
        ]
        if missing_logs:
            return fail("real build log is missing or truncated -- INCONCLUSIVE: " +
                        ", ".join(missing_logs))
        rejected_markers = (
            "Critical Warning (332148): Timing requirements not met",
            "Ignored filter",
            "Warning (10306): Invalid value",
            "Error (",
        )
        # Quartus renders failures in TWO forms and the numbered one is not
        # guaranteed.  Confirmed in this tree -- .runsnap/fifo-close2-overlay-
        # 20260809-0504-7828/stdout.log carries
        #   "Error: Quartus Prime TimeQuest Timing Analyzer was unsuccessful."
        # with no message number at all.  That is a STAGE FAILURE SUMMARY, and
        # "Error (" does not match it; the Y-unit session counted 30 bare
        # "Error:" lines against 6 numbered ones across their build logs.  This
        # gate exists precisely to stop an RBF being packaged from a failed
        # stage, so missing the summary line defeats its whole purpose.
        #
        # Line-ANCHORED: a bare "Error:" substring would fire on ordinary prose
        # (a path, a quoted message, a comment) and a gate that cries wolf gets
        # switched off.  Quartus always starts these at column zero.
        rejected_line_patterns = (
            r"^Error:",
            r"^Fatal Error",
        )
        present = []
        for path in stage_logs:
            stage_text = path.read_text(encoding="utf-8", errors="replace")
            for marker in rejected_markers:
                if marker in stage_text:
                    present.append(f"{path.name}: {marker}")
            for pattern in rejected_line_patterns:
                hit = re.search(pattern, stage_text, re.MULTILINE)
                if hit:
                    line = stage_text[hit.start():].splitlines()[0].strip()
                    present.append(f"{path.name}: {line[:120]}")
        if present:
            return fail("build logs contain rejected diagnostic(s): " +
                        ", ".join(present))

        physical_reports = (MAP_REPORT, FIT_REPORT)
        missing_reports = [
            path.name for path in physical_reports
            if not path.is_file() or path.stat().st_size < MIN_REPORT_BYTES
        ]
        if missing_reports:
            return fail("map/fit report is missing or truncated -- fitted RAM "
                        "semantics are INCONCLUSIVE: " + ", ".join(missing_reports))
        fit_text = FIT_REPORT.read_text(encoding="utf-8", errors="replace")
        map_text = MAP_LOG.read_text(encoding="utf-8", errors="replace")
        map_report_text = MAP_REPORT.read_text(encoding="utf-8", errors="replace")
        defined_count, protected_names, unprotected = fitted_ram_semantics(
            fit_text, map_text, map_report_text
        )
        if unprotected:
            return fail("game-side RAM has unprotected DON'T CARE mixed-port "
                        "read-during-write: " + ", ".join(unprotected))
        print(f"  fitted RAM semantics: {defined_count} defined primitive "
              f"row(s), {len(protected_names)} mapper-protected RAM(s)")

    text = STA_SUMMARY.read_text(encoding="utf-8", errors="replace")
    types = TYPE_RE.findall(text)
    slacks = [float(s) for s in SLACK_RE.findall(text)]
    if not slacks:
        return fail("STA summary contains no Slack lines -- unparseable, "
                    "INCONCLUSIVE")

    # Pair each slack with the Type line that precedes it, so a failure names its
    # corner and check rather than just a number.
    pairs = []
    for m in SLACK_RE.finditer(text):
        head = text[:m.start()]
        tm = None
        for tm in TYPE_RE.finditer(head):
            pass
        pairs.append((tm.group(1) if tm else "<unknown>", float(m.group(1))))

    negative = [(t, s) for t, s in pairs if s < 0.0]

    print(f"ASSEMBLE GATE: {len(pairs)} timing checks parsed from "
          f"{STA_SUMMARY.name} ({size} bytes)")
    if negative:
        print(f"  {len(negative)} FAILING check(s):")
        for t, s in sorted(negative, key=lambda x: x[1])[:12]:
            print(f"    {s:+.3f}  {t}")
        return fail(f"{len(negative)} timing check(s) negative -- no release "
                    "candidate exists. Do NOT assemble, do NOT flash")

    worst = min(s for _, s in pairs)
    print(f"  all checks non-negative; worst slack {worst:+.3f}")

    if not args.assemble:
        print("ASSEMBLE GATE: PASS (check only; pass --assemble to emit)")
        return 0

    asm = Path(r"C:\intelFPGA_lite\17.0\quartus\bin64\quartus_asm.exe")
    if not asm.is_file():
        return fail(f"quartus_asm not found at {asm}")
    print("ASSEMBLE GATE: PASS -- running quartus_asm")
    r = subprocess.run([str(asm), "Arcade-TUnit"], cwd=ROOT, text=True,
                       capture_output=True)
    (ROOT / "output_files" / "rc_asm.log").write_text(
        (r.stdout or "") + (r.stderr or ""), encoding="utf-8", errors="replace")
    if r.returncode:
        return fail(f"quartus_asm exited {r.returncode}")
    print("ASSEMBLE GATE: RBF emitted. It still must not reach a cabinet until "
          "its contents are reported to the owner.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
