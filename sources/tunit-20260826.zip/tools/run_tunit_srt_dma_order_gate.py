#!/usr/bin/env python3
"""Prove T-unit SRT page erase is ordered after physical DMA retirement."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys


RUNNER = Path(__file__).resolve()
ROOT = RUNNER.parents[1]
MANIFEST = ROOT / "tools" / "quartus_sv2v_files.txt"
MEMSYS = ROOT / "rtl" / "tunit" / "tunit_memsys.sv"
MODEL = ROOT / "sim" / "models" / "ddr3_avalon_model.sv"
BENCH = ROOT / "sim" / "tb_tunit_srt_dma_repaint.sv"
PASS_MARKER = (
    "PASS tb_tunit_srt_dma_repaint ordered false-idle erase leaves no stale pixels"
)
MUTANT_MARKER = "SRT_ORDER_STALE_REPAINT"
SUMMARY = re.compile(
    r"SRT_DMA_REPAINT cadence_clear=(\d+) poll_reads=(\d+) "
    r"overlap=(\d+) latch_wait=(\d+) "
    r"transfer_wait=(\d+) early_store=(\d+) early_sink=(\d+) early_ack=(\d+) "
    r"post_drain=(\d+) nonzero=(\d+) first_bad=(-?\d+)"
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run(command: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command, cwd=ROOT, text=True, capture_output=True, check=False
    )


def transcript(result: subprocess.CompletedProcess[str]) -> str:
    return (result.stdout or "") + (result.stderr or "")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--label",
        default=(
            "tunit-srt-dma-order-"
            + datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
            + f"-{os.getpid()}"
        ),
    )
    args = parser.parse_args()

    tools = {name: shutil.which(name) for name in ("vlib", "vlog", "vsim")}
    missing_tools = [name for name, path in tools.items() if path is None]
    if missing_tools:
        print(
            "ERROR: missing simulator tools: " + ", ".join(missing_tools),
            file=sys.stderr,
        )
        return 2

    required = (RUNNER, MANIFEST, MEMSYS, MODEL, BENCH)
    missing_files = [str(path) for path in required if not path.is_file()]
    if missing_files:
        print(
            "ERROR: missing SRT-order input: " + ", ".join(missing_files),
            file=sys.stderr,
        )
        return 2

    sources = []
    for raw in MANIFEST.read_text(encoding="utf-8").splitlines():
        relative = raw.strip()
        if not relative or relative.startswith("#"):
            continue
        source = ROOT / relative
        if not source.is_file():
            print(f"ERROR: missing production source: {relative}", file=sys.stderr)
            return 2
        sources.append(source)

    out = ROOT / "sim" / "out" / args.label
    if out.exists():
        print(f"ERROR: output already exists: {out}", file=sys.stderr)
        return 2
    out.mkdir(parents=True)

    cases = (
        ("stock", ["+define+TUNIT_DIAG"]),
        (
            "revert",
            ["+define+TUNIT_DIAG", "+define+MUT_TUNIT_SRT_DMA_ORDER_REVERT"],
        ),
    )
    results: dict[str, object] = {}
    for name, defines in cases:
        case = out / name
        core = case / "core"
        test = case / "test"
        case.mkdir()

        create_core = run([tools["vlib"], str(core)])
        create_test = run([tools["vlib"], str(test)])
        core_command = [
            tools["vlog"],
            "-quiet",
            "-sv",
            "-svinputport=var",
            *defines,
            "-work",
            str(core),
            *map(str, sources),
        ]
        core_compile = run(core_command)
        core_log = (
            transcript(create_core)
            + transcript(create_test)
            + transcript(core_compile)
        )
        (case / "core_compile.log").write_text(
            core_log, encoding="utf-8", errors="replace"
        )
        if create_core.returncode or create_test.returncode or core_compile.returncode:
            print(
                f"ERROR: {name} production RTL did not compile; see {case}",
                file=sys.stderr,
            )
            return 1

        test_command = [
            tools["vlog"],
            "-quiet",
            "-sv",
            "-svinputport=var",
            "-work",
            str(test),
            "-L",
            str(core),
            str(MODEL),
            str(BENCH),
        ]
        test_compile = run(test_command)
        (case / "test_compile.log").write_text(
            transcript(test_compile), encoding="utf-8", errors="replace"
        )
        if test_compile.returncode:
            print(
                f"ERROR: {name} bench did not compile; see {case}",
                file=sys.stderr,
            )
            return 1


        sim_command = [
            tools["vsim"],
            "-c",
            "-L",
            str(core),
            "-lib",
            str(test),
            "-do",
            "run -all; quit -f",
            "tb_tunit_srt_dma_repaint",
        ]
        simulated = run(sim_command)
        output = transcript(simulated)
        (case / "sim.log").write_text(output, encoding="utf-8", errors="replace")
        match = SUMMARY.search(output)
        metrics = None
        if match:
            metrics = {
                key: int(value)
                for key, value in zip(
                    (
                        "cadence_clear",
                        "poll_reads",
                        "overlap",
                        "latch_wait",
                        "transfer_wait",
                        "early_store",
                        "early_sink",
                        "early_ack",
                        "post_drain",
                        "nonzero",
                        "first_bad",
                    ),
                    match.groups(),
                )
            }
        results[name] = {
            "defines": defines,
            "core_compile_returncode": core_compile.returncode,
            "test_compile_returncode": test_compile.returncode,
            "simulation_returncode": simulated.returncode,
            "metrics": metrics,
            "pass_marker": PASS_MARKER in output,
            "mutant_marker": MUTANT_MARKER in output,
            "fatal_seen": "Fatal:" in output or "** Fatal:" in output,
        }

    stock = results["stock"]
    revert = results["revert"]
    assert isinstance(stock, dict) and isinstance(revert, dict)
    stock_metrics = stock["metrics"]
    revert_metrics = revert["metrics"]
    passed = (
        isinstance(stock_metrics, dict)
        and stock["pass_marker"]
        and not stock["fatal_seen"]
        and stock_metrics["cadence_clear"] == 1
        and 0 < stock_metrics["poll_reads"] <= 3250
        and stock_metrics["overlap"] == 1
        and stock_metrics["transfer_wait"] >= 64
        and stock_metrics["early_store"] == 0
        and stock_metrics["early_sink"] == 0
        and stock_metrics["early_ack"] == 0
        and stock_metrics["post_drain"] == 1
        and stock_metrics["nonzero"] == 0
        and isinstance(revert_metrics, dict)
        and revert["mutant_marker"]
        and revert["fatal_seen"]
        and not revert["pass_marker"]
        and revert_metrics["cadence_clear"] == 1
        and 0 < revert_metrics["poll_reads"] <= 3250
        and revert_metrics["overlap"] == 1
        and (
            revert_metrics["early_store"] == 1
            or revert_metrics["early_sink"] == 1
            or revert_metrics["early_ack"] == 1
        )
        and revert_metrics["post_drain"] == 0
        and revert_metrics["nonzero"] == 800
    )

    receipt = {
        "schema": 1,
        "gate": "tunit-srt-dma-physical-order",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "sources": {
            str(path.relative_to(ROOT)).replace("\\", "/"): sha256(path)
            for path in required
        },
        "results": results,
        "passed": passed,
    }
    (out / "receipt.json").write_text(
        json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    if not passed:
        print(f"ERROR: SRT-DMA order gate failed; see {out}", file=sys.stderr)
        return 1
    print(
        "TUNIT SRT-DMA ORDER GATE: PASS "
        "(false-idle repaint revert killed at 800 stale entries)"
    )
    print(f"  receipt: {out.relative_to(ROOT) / 'receipt.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
