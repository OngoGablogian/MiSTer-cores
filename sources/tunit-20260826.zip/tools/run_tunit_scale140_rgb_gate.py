#!/usr/bin/env python3
"""Kill the alternating-black-column mutation through the complete RGB path."""

from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
SOURCES = (
    "rtl/common/tunit_pkg.sv",
    "rtl/sdram/vram_sdram.sv",
    "rtl/sdram/vram_sdram_top.sv",
    "rtl/sdram/stv_vram_ddr_agent.sv",
    "rtl/sdram/stv_vram_ddr_top.sv",
    "rtl/tunit/tunit_page_fence.sv",
    "rtl/tunit/tunit_scanline.sv",
    "rtl/tunit/tunit_video.sv",
    "rtl/tunit/tunit_video_top.sv",
    "sim/models/ddr3_avalon_model.sv",
    "sim/tb_tunit_scale140_rgb.sv",
)
PASS_MARKER = "PASS tb_tunit_scale140_rgb pixels=16 interior_black=0"
MUTATION_MARKER = "SCALE140_RGB_INTERIOR pixel=1 got=000000 expected=00ff00"
CASES = (
    ("production", (), True, PASS_MARKER),
    ("mutation-drop-upper", ("MUT_TUNIT_FAST16_DROP_UPPER",), False,
     MUTATION_MARKER),
)


def run(command: list[str], log: Path) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(
        command, cwd=ROOT, text=True, capture_output=True, check=False
    )
    log.write_text(
        (result.stdout or "") + (result.stderr or ""),
        encoding="utf-8",
        errors="replace",
    )
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--label",
        default="tunit-scale140-rgb-" + datetime.now().strftime("%Y%m%d-%H%M%S"),
    )
    args = parser.parse_args()
    out = ROOT / "sim" / "out" / args.label
    if out.exists():
        print(f"ERROR: output already exists: {out}", file=sys.stderr)
        return 2
    out.mkdir(parents=True)

    for name, defines, should_pass, marker in CASES:
        image = out / f"{name}.vvp"
        compile_result = run(
            [
                "iverilog", "-g2012", "-s", "tb_tunit_scale140_rgb",
                *[f"-D{define}" for define in defines],
                "-o", str(image), *SOURCES,
            ],
            out / f"{name}-compile.log",
        )
        if compile_result.returncode:
            print(f"ERROR: {name} compile failed; see {out}")
            return compile_result.returncode
        simulation = run(["vvp", str(image)], out / f"{name}-sim.log")
        text = (simulation.stdout or "") + (simulation.stderr or "")
        if should_pass:
            if simulation.returncode or marker not in text:
                print(f"ERROR: production RGB gate failed; see {out}")
                return simulation.returncode or 1
        elif simulation.returncode == 0 or marker not in text or PASS_MARKER in text:
            print(f"ERROR: {name} did not discriminate; see {out}")
            return 1
        print(f"PASS: {name} {'passes' if should_pass else 'fails'} at {marker}")

    print(f"PASS: Scale140 paired pixels survive DDR-to-RGB; mutation killed ({out})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
