#!/usr/bin/env python3
"""Compile the production T-unit RTL once and run every focused component bench.

This is a simulator-only gate. It reads the same source manifest used to create
the Quartus-17 synthesis blob, while compiling the original SystemVerilog (never
the generated Verilog). The outer ``Arcade-TUnit.sv`` framework wrapper has its
own interface/elaboration gate. The DMA and video model benches are also excluded
here because their independent matrix runners exercise them separately.

Every excluded bench is classified below as owned by a focused runner, driven
measurement, or retired experiment. The eight cross-game benches that are
outside the MK2 synthesis manifest are owned by
``tools/run_tunit_orphan_gate.py`` (iverilog, no licence). New unclassified
benches run by default, and the candidate qualifier pins the exact selected/run
count so adding or removing a case cannot silently preserve a green receipt.
"""

from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path
import re
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
QIP_SOURCE = re.compile(r"SYSTEMVERILOG_FILE\s+(.+?)\s*$")
EXCLUDED_BENCHES = frozenset(
    (
        "tb_mister_interface",  # owned by tools/run_wrapper_gate.py
        "tb_tunit_crt_resync",  # retired; replaced by tb_tunit_crt_adjust
        "tb_tunit_dma",  # owned by tools/run_tunit_dma_matrix.py
        "tb_tunit_dma_realgfx",  # owned by tools/run_mk2_dma_gate.py:124-129
        "tb_tunit_dma_vram_realgfx",  # owned by tools/run_mk2_dma_vram_gate.py
        "tb_tunit_flip_deadline",  # owned by the retained video deadline runner
        "tb_tunit_loader_gfx_first_blit",  # owned by its +GFX runner
        "tb_tunit_mk2_shared_blit",  # owned by tools/run_mk2_shared_blit_gate.py
        "tb_tunit_video",  # owned by tools/run_tunit_video_matrix.py
        "tb_tunit_adpcm_realrom",  # owned by tools/run_tunit_adpcm_realrom.py
        # Driven benches: these REQUIRE plusargs the generic runner does not
        # supply, so running them here leaves the suite permanently red -- which
        # is the same disease as a gate that cannot fail. Each has its own owner.
        "tb_tunit_adpcm_starve",  # needs +ROM_BIN/+LAT/+MIN_RATE_PCT (P0044 gate)
        "tb_tunit_adpcm_tune_pace",  # owned by tools/run_tunit_adpcm_tune_gate.py
        "tb_tunit_adpcm_reload_fixedbank",  # owned by tools/run_tunit_adpcm_reload_gate.py
        "tb_tunit_adpcm_cache_epoch",  # owned by tools/run_tunit_adpcm_reload_gate.py
        "tb_tunit_scanline_coherence",  # owned by focused mutation runner
        "tb_tunit_scanline_integrated_tc",  # production L2/DDR A/C/D runner
        "tb_tunit_scanline_lookahead",  # bounded-stall mutation runner
        "tb_tunit_scale140_rgb",  # paired-pixel end-to-end mutation runner
        "tb_tunit_vram_read32_planes",  # owned by aligned-read32 mutation runner
        # Residual S11 publication discriminator; deliberately outside the S12
        # production gate plan until the independent next2 contract is changed.
        "tb_tunit_pending_next2_publish",
        "tb_tunit_page_fence_occupancy",  # measurement bench, needs its own driver
        "tb_tunit_profile_layout",  # owned by tools/run_tunit_profile_matrix.py
        "tb_tunit_ddr3_arb",  # owned by tools/run_tunit_ddr3_arb_gate.py
        # Measurements/probes are deliberately not functional component gates.
        # The contention case is a parameterized synthetic load measurement;
        # authentic NBA/TE register-stream replays own queue loss, scanout, and
        # frame-deadline acceptance. Scanout relief still prints a measurement
        # rather than a PASS verdict. The cadence
        # probe now owns an independent phase oracle plus an injected-fault
        # phase, so it is intentionally included in the functional suite.
        "tb_tunit_blit_contended",
        "tb_tunit_ddr3_scanout_relief",
        # Parameterized measurement copy of tb_tunit_dma_vram_realgfx. Its
        # filename deliberately is not its module name; the paced/shared
        # measurement runners own its parameters and output parsing.
        "tb_sound_measure",
        # This sweep still needs an Avalon-hold-correct traffic driver before
        # its latency numbers are evidence; the current log reports mem_err.
        "tb_tunit_sound_contention",
        # Reverted SDRAM sound experiment: not instantiated by shipping RTL and
        # specifically disallowed as independent evidence for the MK2 recovery.
        "tb_tunit_sound_sdram_agent",
        # These cross-game blocks have focused mutation ownership in the
        # Icarus orphan gate, even where the block is now also production RTL.
        "tb_tunit_adpcm_board",
        "tb_tunit_adpcm_host",
        "tb_tunit_adpcm_rom_cdc",
        "tb_tunit_inputs",
        "tb_tunit_inputs_mk2_equiv",
        # Retired compatibility blocks are absent from the production source
        # manifest.  The generic mapper's MK2 equivalence is owned above by
        # the mutation-capable orphan gate; all-profile protection is owned by
        # tb_tunit_protection_all in that same gate.
        "tb_tunit_mk2_inputs",
        "tb_tunit_protection",
        "tb_tunit_vram_control",
        # The production page-publication seam has focused finite-blank and
        # assembly-order runners, so do not duplicate those long cases here.
        "tb_tunit_page_diag",  # owned by tools/run_tunit_page_fence_gate.py
        "tb_tunit_srt_dma_repaint",  # owned by run_tunit_srt_dma_order_gate.py
        "tb_tunit_page_fence",
        "tb_tunit_page_fence_blank_end",
        "tb_tunit_page_owner_srt",  # owned by page-fence blank-end mutation gate
        "tb_tunit_raster_resync",
        "tb_tunit_protection_all",
        "tb_tunit_sound_cdc",
        "tb_tunit_sound_ddr_multi",
    )
)
FATAL_MARKERS = ("** Fatal:", "Fatal:", "FATAL:", "TEST_RESULT: FAIL")


def run(command: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, cwd=ROOT, text=True, capture_output=True)


def log_text(result: subprocess.CompletedProcess[str]) -> str:
    return (result.stdout or "") + (result.stderr or "")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--label",
        default="components-" + datetime.now().strftime("%Y%m%d-%H%M%S"),
    )
    parser.add_argument("--pattern", default="tb_*.sv")
    parser.add_argument("--stop-on-fail", action="store_true")
    args = parser.parse_args()

    simulator = {name: shutil.which(name) for name in ("vlib", "vlog", "vsim")}
    missing = [name for name, path in simulator.items() if path is None]
    if missing:
        print("ERROR: missing simulator tools: " + ", ".join(missing), file=sys.stderr)
        return 2

    sources: list[Path] = []
    manifest = ROOT / "tools" / "quartus_sv2v_files.txt"
    if manifest.is_file():
        relative_sources = (
            line.strip()
            for line in manifest.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        )
    else:
        relative_sources = (
            match.group(1)
            for line in (ROOT / "files.qip").read_text(encoding="utf-8").splitlines()
            if (match := QIP_SOURCE.search(line))
            and match.group(1) != "Arcade-TUnit.sv"
        )

    for relative in relative_sources:
        source = ROOT / relative
        if not source.is_file():
            print(f"ERROR: missing production source: {relative}", file=sys.stderr)
            return 2
        sources.append(source)
    sources.extend(
        (
            ROOT / "sim" / "models" / "tunit_store_model.sv",
            ROOT / "sim" / "models" / "ddr3_avalon_model.sv",
        )
    )
    sources.extend(
        ROOT / relative.strip()
        for relative in (ROOT / "tools" / "vendor_sound_files.txt").read_text(
            encoding="utf-8"
        ).splitlines()
        if relative.strip()
    )

    benches = sorted(
        path
        for path in (ROOT / "sim").glob(args.pattern)
        if path.stem not in EXCLUDED_BENCHES
    )
    if not benches:
        print(f"ERROR: no component benches match {args.pattern}", file=sys.stderr)
        return 2

    out = ROOT / "sim" / "out" / args.label
    if out.exists():
        print(f"ERROR: output already exists: {out}", file=sys.stderr)
        return 2
    out.mkdir(parents=True)
    corelib = out / "corelib"

    result = run([simulator["vlib"], str(corelib)])
    if result.returncode:
        (out / "core_compile.log").write_text(log_text(result), encoding="utf-8")
        print("ERROR: failed to create core library", file=sys.stderr)
        return 1
    result = run(
        [
            simulator["vlog"],
            "-quiet",
            "-sv",
            "-svinputport=var",
            "-work",
            str(corelib),
            *map(str, sources),
        ]
    )
    (out / "core_compile.log").write_text(
        log_text(result), encoding="utf-8", errors="replace"
    )
    if result.returncode:
        print("ERROR: production RTL compilation failed; see core_compile.log", file=sys.stderr)
        return 1

    passed: list[str] = []
    failed: list[str] = []
    for index, bench in enumerate(benches, 1):
        library = out / f"tb{index:02d}"
        create = run([simulator["vlib"], str(library)])
        compile_result = run(
            [
                simulator["vlog"],
                "-quiet",
                "-sv",
                "-svinputport=var",
                "-work",
                str(library),
                "-L",
                str(corelib),
                str(bench),
            ]
        )
        compile_log = log_text(create) + log_text(compile_result)
        if create.returncode or compile_result.returncode:
            log = compile_log
            ok = False
        else:
            sim_result = run(
                [
                    simulator["vsim"],
                    "-c",
                    "-L",
                    str(corelib),
                    "-lib",
                    str(library),
                    "-do",
                    "run -all; quit -f",
                    bench.stem,
                ]
            )
            log = compile_log + log_text(sim_result)
            ok = (
                sim_result.returncode == 0
                and "PASS" in log
                and not any(marker in log for marker in FATAL_MARKERS)
            )
        (out / f"{bench.stem}.log").write_text(
            log, encoding="utf-8", errors="replace"
        )
        (passed if ok else failed).append(bench.stem)
        print(
            f"[{index:02d}/{len(benches):02d}] {'PASS' if ok else 'FAIL'} {bench.stem}",
            flush=True,
        )
        if not ok and args.stop_on_fail:
            break

    cadence_mutation = "not-run"
    if not failed:
        mutation_library = out / "cadence_phase6_mutant"
        create = run([simulator["vlib"], str(mutation_library)])
        compile_result = run(
            [
                simulator["vlog"], "-quiet", "-sv", "-svinputport=var",
                "+define+MUT_TUNIT_CADENCE_PHASE6",
                "-work", str(mutation_library),
                str(ROOT / "rtl" / "tunit" / "tunit_cpu_cycle_scheduler.sv"),
                str(ROOT / "sim" / "tb_tunit_cadence_overrun_probe.sv"),
            ]
        )
        mutation_log = log_text(create) + log_text(compile_result)
        if not create.returncode and not compile_result.returncode:
            sim_result = run(
                [
                    simulator["vsim"], "-c", "-lib", str(mutation_library),
                    "-do", "run -all; quit -f",
                    "tb_tunit_cadence_overrun_probe",
                ]
            )
            mutation_log += log_text(sim_result)
            exact_failure = "cadence interval range=" in mutation_log
            no_pass = "PASS tb_tunit_cadence_overrun_probe" not in mutation_log
            controlled_fatal = any(
                marker in mutation_log for marker in ("** Fatal:", "Fatal:", "FATAL:")
            )
            if exact_failure and no_pass and controlled_fatal:
                cadence_mutation = "killed"
        (out / "tb_tunit_cadence_phase6_mutant.log").write_text(
            mutation_log, encoding="utf-8", errors="replace"
        )
        if cadence_mutation != "killed":
            failed.append("tb_tunit_cadence_phase6_mutant")

    summary = (
        f"selected={len(benches)} run={len(passed) + len(failed)} "
        f"passed={len(passed)} failed={len(failed)}\n"
        f"failed_tests={','.join(failed)}\n"
        f"cadence_phase6_mutation={cadence_mutation}\n"
    )
    (out / "summary.txt").write_text(summary, encoding="ascii")
    print(summary.strip())
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
