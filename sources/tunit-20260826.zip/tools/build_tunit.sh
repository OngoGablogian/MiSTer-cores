#!/usr/bin/env bash
# T-unit build flow. THE GATE SITS BETWEEN STA AND ASM BY CONSTRUCTION.
#
# WHY THIS FILE EXISTS (Wolf-unit session, 2026-07-27, and confirmed in this tree
# with this tree's own data):
#
#   quartus_sta EXITS 0 WHEN TIMING FAILS.
#
# Proof from output_files/rc_sta.log, today's run: the log contains TWO
# "Critical Warning (332148): Timing requirements not met" lines and a
# worst-case setup slack of -1.607, and it still ends
# "TimeQuest Timing Analyzer was successful. 0 errors" -- and the runner
# recorded sta rc=0. Any `sta && asm` chain therefore ASSEMBLES A MISTIMED RBF,
# and every freshness check passes it. This tree already produced exactly that
# artifact once: output_files/Arcade-TUnit.rbf.MISTIMED-DO-NOT-FLASH.
#
# Before this script, T-unit's protection was that I REMEMBERED to run
# assemble_gate.py by hand after the fit. That is not protection, it is a habit.
# Wolf's framing is the right one: PROTECTION BY ORDERING, NOT BY REMEMBERING.
# Here asm is unreachable except through the gate -- there is no code path from
# a failed STA to quartus_asm.
#
# The companion trap Wolf found on their second look, which this script also
# avoids: `quartus_X | tee log | grep | tail` returns TAIL's status, so every
# stage can die while the build sails on. Every stage here redirects with
# `> log 2>&1` and reads `$?` on the very next line. No stage runs inside a
# pipeline. If you add a pipeline, read ${PIPESTATUS[0]}, not $?.
#
# And the line worth keeping, from Wolf:
#   PROVENANCE ANSWERS "IS THIS IMAGE WHAT WE BUILT". IT CANNOT ANSWER
#   "SHOULD WE HAVE BUILT IT".
# A fresh, correctly-hashed, provenance-clean RBF that failed STA is the most
# dangerous artifact in this project, precisely because freshness says yes.
#
# Usage:
#   tools/build_tunit.sh --variant universal      # one RBF for all profiles
#   tools/build_tunit.sh --variant adpcm          # flatten -> preflight -> Quartus
#   tools/build_tunit.sh --variant dcs --no-asm   # stop after the timing gate
#   tools/build_tunit.sh --variant adpcm --engineering --preflight-only
#   FPGA_SESSION=tunit:rc tools/build_tunit.sh
#
# On the shared host, invoke only through the FIFO owner:
#   TUNIT_VARIANT=universal tools/run_queued_tunit_build.sh

set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT" || exit 2
Q="${QUARTUS_BIN:-/c/intelFPGA_lite/17.0/quartus/bin64}"
if ! command -v cygpath >/dev/null 2>&1; then
  printf 'ERROR: cygpath is required to bind the Quartus toolchain identity\n' >&2
  exit 2
fi
export TUNIT_QUARTUS_BIN_WIN="$(cygpath -aw "$Q")"
PROJ=Arcade-TUnit
OUT=output_files
DO_ASM=1
PREFLIGHT_ONLY=0
ENGINEERING=0
PHYSICAL_ONLY="${TUNIT_PHYSICAL_ONLY:-0}"
case "$PHYSICAL_ONLY" in
  0|1) ;;
  *) printf 'ERROR: TUNIT_PHYSICAL_ONLY must be exactly 0 or 1\n' >&2; exit 2 ;;
esac
VARIANT=
while [ "$#" -gt 0 ]; do
  case "$1" in
    --variant)
      [ "$#" -ge 2 ] || { printf 'ERROR: --variant needs universal, adpcm, or dcs\n' >&2; exit 2; }
      VARIANT="$2"
      shift 2
      ;;
    --no-asm)
      DO_ASM=0
      shift
      ;;
    --preflight-only)
      PREFLIGHT_ONLY=1
      shift
      ;;
    --engineering)
      ENGINEERING=1
      shift
      ;;
    *)
      printf 'ERROR: unknown argument %s\n' "$1" >&2
      exit 2
      ;;
  esac
done
case "$VARIANT" in
  universal|adpcm|dcs) ;;
  *) printf 'ERROR: --variant universal|adpcm|dcs is required\n' >&2; exit 2 ;;
esac

ASCAL_POLICY="${TUNIT_ASCAL_POLICY:-main}"
ARTIFACT_ID="${TUNIT_ARTIFACT_ID:-}"
AB_REFERENCE="${TUNIT_AB_REFERENCE_MANIFEST:-}"
DIAG_BUILD="${TUNIT_DIAG_BUILD:-0}"
case "$DIAG_BUILD" in
  0|1) ;;
  *) printf 'ERROR: TUNIT_DIAG_BUILD must be exactly 0 or 1\n' >&2; exit 2 ;;
esac
COMMITTED_BUILD_DATE="$(git -C "$ROOT" show HEAD:build_id.v 2>/dev/null |
  sed -n 's/^`define BUILD_DATE "\([0-9][0-9][0-9][0-9][0-9][0-9]\)"$/\1/p')"
[ -n "$COMMITTED_BUILD_DATE" ] || {
  printf 'ERROR: committed build_id.v does not contain one YYMMDD BUILD_DATE\n' >&2
  exit 2
}
if [ -n "${TUNIT_BUILD_DATE:-}" ]; then
  BUILD_DATE="$TUNIT_BUILD_DATE"
elif [ "$ENGINEERING" -eq 0 ]; then
  BUILD_DATE="$COMMITTED_BUILD_DATE"
else
  BUILD_DATE="$(date +%y%m%d)"
fi
ASCAL_A_REFERENCE="output_files/Arcade-TUnit-ADPCM-ENGINEERING-NBA-ASCAL-A-NEAREST.manifest.json"
case "$ASCAL_POLICY" in
  main)
    case "$ARTIFACT_ID" in
      NBA-ASCAL-A-NEAREST|NBA-ASCAL-B-BILINEAR)
        printf 'ERROR: reserved NBA-ASCAL artifact ID requires its matching fixed policy\n' >&2
        exit 2
        ;;
    esac
    ;;
  nearest)
    [ "$ARTIFACT_ID" = "NBA-ASCAL-A-NEAREST" ] || {
      printf 'ERROR: nearest policy requires TUNIT_ARTIFACT_ID=NBA-ASCAL-A-NEAREST\n' >&2
      exit 2
    }
    [ -z "$AB_REFERENCE" ] || {
      printf 'ERROR: nearest policy must not carry a TUNIT_AB_REFERENCE_MANIFEST\n' >&2
      exit 2
    }
    ;;
  bilinear)
    [ "$ARTIFACT_ID" = "NBA-ASCAL-B-BILINEAR" ] || {
      printf 'ERROR: bilinear policy requires TUNIT_ARTIFACT_ID=NBA-ASCAL-B-BILINEAR\n' >&2
      exit 2
    }
    [ "$AB_REFERENCE" = "$ASCAL_A_REFERENCE" ] || {
      printf 'ERROR: bilinear policy requires TUNIT_AB_REFERENCE_MANIFEST=%s\n' "$ASCAL_A_REFERENCE" >&2
      exit 2
    }
    ;;
  *) printf 'ERROR: TUNIT_ASCAL_POLICY must be main, nearest, or bilinear\n' >&2; exit 2 ;;
esac
case "$ARTIFACT_ID" in
  ''|*[!A-Z0-9._-]*)
    if [ -n "$ARTIFACT_ID" ]; then
      printf 'ERROR: TUNIT_ARTIFACT_ID must use only A-Z, 0-9, dot, underscore, or dash\n' >&2
      exit 2
    fi
    ;;
esac
if [ -n "$ARTIFACT_ID" ]; then
  case "${ARTIFACT_ID:0:1}" in
    [A-Z0-9]) ;;
    *) printf 'ERROR: TUNIT_ARTIFACT_ID must begin with A-Z or 0-9\n' >&2; exit 2 ;;
  esac
fi
if [ "${#ARTIFACT_ID}" -gt 64 ]; then
  printf 'ERROR: TUNIT_ARTIFACT_ID is longer than 64 characters\n' >&2
  exit 2
fi
case "$BUILD_DATE" in
  [0-9][0-9][0-9][0-9][0-9][0-9]) ;;
  *) printf 'ERROR: TUNIT_BUILD_DATE must be exactly six decimal YYMMDD digits\n' >&2; exit 2 ;;
esac
if [ "$ENGINEERING" -eq 0 ] &&
   [ "$BUILD_DATE" != "$COMMITTED_BUILD_DATE" ]; then
  printf 'ERROR: production TUNIT_BUILD_DATE must match committed build_id.v (%s)\n' "$COMMITTED_BUILD_DATE" >&2
  exit 2
fi
export TUNIT_BUILD_DATE="$BUILD_DATE"
if [ "$ASCAL_POLICY" != "main" ] && [ "$ENGINEERING" -ne 1 ]; then
  printf 'ERROR: fixed ascal policies are engineering-only until cabinet acceptance\n' >&2
  exit 2
fi
if [ "$ASCAL_POLICY" != "main" ] && [ "$VARIANT" != "adpcm" ]; then
  printf 'ERROR: NBA ascal A/B policies require --variant adpcm\n' >&2
  exit 2
fi
if [ "$ASCAL_POLICY" != "main" ] && [ "${TUNIT_DIAG_BUILD:-0}" != "0" ]; then
  printf 'ERROR: fixed ascal A/B policies forbid TUNIT_DIAG_BUILD; the scaler discriminator must be pixel-clean\n' >&2
  exit 2
fi
if [ "$DIAG_BUILD" = "1" ]; then
  case "$ARTIFACT_ID" in
    NBA-FLASH-DIAG|NBA-FLASH-SRT-ORDER-DIAG) ;;
    *)
      printf 'ERROR: TUNIT_DIAG_BUILD=1 requires a reserved NBA flashing diagnostic ID\n' >&2
      exit 2
      ;;
  esac
  [ "$VARIANT" = "adpcm" ] || {
    printf 'ERROR: NBA flashing diagnostics require --variant adpcm\n' >&2
    exit 2
  }
  [ "$ASCAL_POLICY" = "main" ] || {
    printf 'ERROR: NBA flashing diagnostics require TUNIT_ASCAL_POLICY=main\n' >&2
    exit 2
  }
  [ "$ENGINEERING" -eq 1 ] || {
    printf 'ERROR: NBA flashing diagnostics require --engineering\n' >&2
    exit 2
  }
else
  case "$ARTIFACT_ID" in
    NBA-FLASH-DIAG|NBA-FLASH-SRT-ORDER-DIAG)
      printf 'ERROR: reserved NBA flashing diagnostic IDs require TUNIT_DIAG_BUILD=1\n' >&2
      exit 2
      ;;
  esac
fi
if [ -n "$ARTIFACT_ID" ] && [ "$ENGINEERING" -ne 1 ]; then
  printf 'ERROR: labelled diagnostic artifacts require --engineering\n' >&2
  exit 2
fi
if [ "$ENGINEERING" -eq 1 ] && [ "$PREFLIGHT_ONLY" -eq 0 ] && [ -z "$ARTIFACT_ID" ]; then
  printf 'ERROR: an engineering physical build requires an immutable TUNIT_ARTIFACT_ID\n' >&2
  exit 2
fi
if [ "$ASCAL_POLICY" != "bilinear" ] && [ -n "$AB_REFERENCE" ]; then
  printf 'ERROR: only the bilinear B policy accepts TUNIT_AB_REFERENCE_MANIFEST\n' >&2
  exit 2
fi
if [ -n "$AB_REFERENCE" ] && [ ! -f "$ROOT/$AB_REFERENCE" ]; then
  printf 'ERROR: A/B reference manifest is missing: %s\n' "$AB_REFERENCE" >&2
  exit 2
fi

# Direct Quartus project invocation is forbidden.  The QSF sources a Tcl guard
# that errors unless this wrapper-owned sentinel is present; this export is the
# only supported way to make the generated-netlist, preflight, STA and assembly
# ordering reachable.
export TUNIT_BUILD_WRAPPER_ACTIVE=1
export TUNIT_ENGINEERING_BUILD="$ENGINEERING"
export TUNIT_BUILD_VARIANT="$VARIANT"
export TUNIT_ASCAL_POLICY="$ASCAL_POLICY"
export TUNIT_ARTIFACT_ID="$ARTIFACT_ID"
export TUNIT_AB_REFERENCE_MANIFEST="$AB_REFERENCE"
export TUNIT_DIAG_BUILD="$DIAG_BUILD"

# Labelled engineering evidence is immutable. Refuse an occupied destination before
# spending a shared-host Quartus slot; the finalizer repeats this check after
# assembly so a race or interrupted earlier run still fails closed.
if [ -n "$ARTIFACT_ID" ]; then
  case "$VARIANT" in
    universal) VARIANT_LABEL=UNIVERSAL ;;
    adpcm) VARIANT_LABEL=ADPCM ;;
    dcs) VARIANT_LABEL=DCS ;;
  esac
  ARTIFACT_LABEL="${VARIANT_LABEL}-ENGINEERING-${ARTIFACT_ID}"
  for PLANNED_PATH in \
    "$OUT/Arcade-TUnit-${ARTIFACT_LABEL}.sof" \
    "$OUT/Arcade-TUnit-${ARTIFACT_LABEL}.rbf" \
    "$OUT/Arcade-TUnit-${ARTIFACT_LABEL}.manifest.json" \
    "$OUT/Arcade-TUnit-${ARTIFACT_LABEL}-DO-NOT-FLASH.txt" \
    "$OUT/reports-${ARTIFACT_LABEL}"
  do
    if [ -e "$PLANNED_PATH" ]; then
      printf 'ERROR: immutable candidate path already exists: %s\n' "$PLANNED_PATH" >&2
      exit 2
    fi
  done
fi

mkdir -p "$OUT"
log() { printf '[build] %s\n' "$*" >&2; }

# build_id.v is a wrapper-generated physical input, but it is also tracked by
# the upstream MiSTer project. Engineering A/B may pin a different date without
# permanently dirtying the user's tree. Keep the pinned bytes live through
# final provenance/artifact creation, then restore the exact entry state.
BUILD_ID_SNAPSHOT="$OUT/.build_id.v.$$.snapshot"
[ ! -e "$BUILD_ID_SNAPSHOT" ] || {
  log "ERROR: build-id snapshot path already exists: $BUILD_ID_SNAPSHOT"
  exit 2
}
cp -p "$ROOT/build_id.v" "$BUILD_ID_SNAPSHOT" || exit $?
restore_build_id() {
  if [ -f "$BUILD_ID_SNAPSHOT" ]; then
    if ! cmp -s "$BUILD_ID_SNAPSHOT" "$ROOT/build_id.v"; then
      cp -p "$BUILD_ID_SNAPSHOT" "$ROOT/build_id.v"
      log "build_id.v restored to entry state"
    fi
    rm -f "$BUILD_ID_SNAPSHOT"
  fi
}

# Quartus can rewrite the tracked QSF during map as well as fit. Snapshot it
# before flatten/preflight so every failure path restores the exact entry bytes;
# arming this after map would preserve a map-time mutation as the "baseline".
QSF_SNAPSHOT="$(mktemp "$OUT/.${PROJ}.qsf.$$.XXXXXX.snapshot")" || exit $?
if ! cp -p "$ROOT/$PROJ.qsf" "$QSF_SNAPSHOT"; then
  rm -f "$QSF_SNAPSHOT"
  exit 2
fi
restore_qsf() {
  if [ -f "$QSF_SNAPSHOT" ] && ! cmp -s "$QSF_SNAPSHOT" "$ROOT/$PROJ.qsf"; then
    cp -p "$QSF_SNAPSHOT" "$ROOT/$PROJ.qsf"
    log "QSF restored (Quartus rewrote it during this run)"
  fi
}
# One EXIT handler owns both tracked wrapper-generated files. A later trap would
# replace this one, so add any future cleanup by chaining it here.
trap 'restore_qsf; rm -f "$QSF_SNAPSHOT"; restore_build_id' EXIT

log "policy: ascal=$ASCAL_POLICY artifact_id=${ARTIFACT_ID:-canonical}"
if [ "$PHYSICAL_ONLY" = "1" ]; then
  [ "$ENGINEERING" -eq 1 ] || {
    log "ERROR: prepared physical-only execution is engineering-only"
    exit 2
  }
  [ "$PREFLIGHT_ONLY" -eq 0 ] || {
    log "ERROR: physical-only execution cannot also be preflight-only"
    exit 2
  }
  [ -n "${TUNIT_CANDIDATE_PROVENANCE_SHA256:-}" ] || {
    log "ERROR: physical-only execution requires prepared provenance identity"
    exit 2
  }
else
log "=== DETERMINISTIC BUILD ID date=$BUILD_DATE $(date -Is) ==="
python tools/pin_tunit_build_id.py --date "$BUILD_DATE" || exit $?
log "=== ASCAL STATIC POLICY GATE variant=$VARIANT $(date -Is) ==="
python tools/check_tunit_ascal_policy.py \
  --policy "$ASCAL_POLICY" --artifact-id "$ARTIFACT_ID" || exit $?
log "=== FLATTEN variant=$VARIANT $(date -Is) ==="
# TUNIT_DIAG_BUILD=1 builds the cabinet instrument image: the flattened core
# must carry the counters (run 5 shipped them tied to zero because this
# regeneration silently dropped the --diag the outer invocation used).
DIAG_FLAG=""
if [ "$DIAG_BUILD" = "1" ]; then DIAG_FLAG="--diag"; fi
python tools/build_quartus_rtl.py --variant "$VARIANT" $DIAG_FLAG || exit $?
provenance_digest_line="$(sha256sum build_syn/tunit_core.manifest.json)" || exit $?
export TUNIT_CANDIDATE_PROVENANCE_SHA256="${provenance_digest_line%% *}"
log "=== CANDIDATE SOURCE MUTATION GATE variant=$VARIANT $(date -Is) ==="
candidate_provenance_args=(--variant "$VARIANT")
if [ -n "$AB_REFERENCE" ]; then
  candidate_provenance_args+=(--reference "$AB_REFERENCE")
fi
python tools/verify_tunit_candidate_provenance.py \
  "${candidate_provenance_args[@]}" || exit $?
if [ "$ENGINEERING" -eq 0 ]; then
  if [ "$VARIANT" != "universal" ]; then
    log "ERROR: release qualification is currently defined for the universal five-title image only; use --engineering for split-family measurements"
    exit 2
  fi
  if [ -z "${TUNIT_QUALIFICATION_RECEIPT:-}" ]; then
    log "ERROR: production build requires TUNIT_QUALIFICATION_RECEIPT from tools/run_tunit_prequartus_qualification.py"
    exit 2
  fi
  log "=== QUALIFICATION RECEIPT variant=$VARIANT $(date -Is) ==="
  python tools/verify_tunit_qualification_receipt.py \
    --receipt "$TUNIT_QUALIFICATION_RECEIPT" --variant "$VARIANT" || exit $?
else
  log "ENGINEERING build: release qualification receipt is not accepted or implied"
fi
log "=== WRAPPER ELABORATION variant=$VARIANT $(date -Is) ==="
if [ -n "${TUNIT_WRAPPER_EVIDENCE:-}" ] || [ -n "${TUNIT_WRAPPER_NETLIST_SHA:-}" ]; then
  if [ -z "${TUNIT_WRAPPER_EVIDENCE:-}" ] || [ -z "${TUNIT_WRAPPER_NETLIST_SHA:-}" ]; then
    log "ERROR: reusable wrapper evidence requires both TUNIT_WRAPPER_EVIDENCE and TUNIT_WRAPPER_NETLIST_SHA"
    exit 2
  fi
  python tools/verify_wrapper_evidence.py \
    --evidence "$TUNIT_WRAPPER_EVIDENCE" \
    --netlist-sha256 "$TUNIT_WRAPPER_NETLIST_SHA" \
    --variant "$VARIANT" || exit $?
else
  python tools/run_wrapper_gate.py || exit $?
fi
if [ "$DIAG_BUILD" = "1" ]; then
  log "=== PAGE-PUBLICATION DIAGNOSTIC GATE variant=$VARIANT $(date -Is) ==="
  python tools/run_tunit_page_fence_gate.py || exit $?
fi
log "=== ENV TRANSPORT GATE variant=$VARIANT $(date -Is) ==="
python tools/run_tunit_env_transport_gate.py || exit $?
log "=== PROGRESSIVE SCAN-CACHE COHERENCE GATE variant=$VARIANT $(date -Is) ==="
python tools/run_tunit_scanline_coherence_gate.py || exit $?
log "=== PROGRESSIVE SCAN-CACHE INTEGRATED A/C/D GATE variant=$VARIANT $(date -Is) ==="
python tools/run_tunit_scanline_integrated_tc_gate.py || exit $?
log "=== PROGRESSIVE SCAN-CACHE LOOKAHEAD GATE variant=$VARIANT $(date -Is) ==="
python tools/run_tunit_scanline_lookahead_gate.py || exit $?
log "=== SCALE140 RGB GATE variant=$VARIANT $(date -Is) ==="
python tools/run_tunit_scale140_rgb_gate.py || exit $?
log "=== VIDEO PAGE-FLIP GATE variant=$VARIANT $(date -Is) ==="
python tools/run_tunit_video_pageflip_gate.py || exit $?
log "=== TMS34010 SRT/FILL GATE variant=$VARIANT $(date -Is) ==="
python tools/run_tunit_srt_gate.py || exit $?
log "=== SRT/DMA PHYSICAL-ORDER GATE variant=$VARIANT $(date -Is) ==="
python tools/run_tunit_srt_dma_order_gate.py || exit $?
log "=== VRAM OLD-DATA RMW GATE variant=$VARIANT $(date -Is) ==="
python tools/run_tunit_vram_rdw_gate.py || exit $?
log "=== NVRAM POWER-ON CLEAR GATE variant=$VARIANT $(date -Is) ==="
python tools/run_tunit_nvram_gate.py || exit $?
log "=== PREFLIGHT variant=$VARIANT $(date -Is) ==="
if [ "$ENGINEERING" -eq 1 ]; then
  python tools/preflight_tunit_build.py --variant "$VARIANT" --allow-dirty || exit $?
else
  python tools/preflight_tunit_build.py --variant "$VARIANT" || exit $?
fi
if [ "$PREFLIGHT_ONLY" -eq 1 ]; then
  log "preflight passed; stopping before Quartus by request"
  exit 0
fi
fi
if [ "${FPGA_QUARTUS_LOCK_HELD:-0}" != "1" ]; then
  log "ERROR: refusing to start Quartus outside tools/quartus_lock.sh"
  exit 75
fi
if [ "${TUNIT_FIFO_TICKET_HELD:-0}" != "1" ]; then
  log "ERROR: refusing to start Quartus without a live shared-FIFO ticket"
  exit 76
fi
# The environment sentinel proves only that the queue wrapper once granted a
# turn. Preflight can take minutes, so revalidate the caller's actual live
# ticket immediately before the first Quartus process rather than trusting a
# stale variable across that interval.
FIFO_NOTIFY=/tmp/fpga_quartus.queue/_notify.sh
FIFO_HELD=""
if [ -x "$FIFO_NOTIFY" ] && [ -n "${FPGA_SESSION:-}" ]; then
  FIFO_HELD="$("$FIFO_NOTIFY" holds "$FPGA_SESSION" 2>/dev/null)" || FIFO_HELD=""
fi
if [ -z "${TUNIT_FIFO_TICKET:-}" ] ||
   [ "$FIFO_HELD" != "$TUNIT_FIFO_TICKET" ]; then
  log "ERROR: shared-FIFO ticket is not live immediately before Quartus map"
  exit 76
fi
log "FIFO LIVE-TICKET GATE PASS: $TUNIT_FIFO_TICKET"

# Quartus databases are variant-specific even though their default paths are
# not. Reusing them across sound-family images risks a false incremental build.
# These are the only two project-local database directories removed here.
if [ "$PHYSICAL_ONLY" != "1" ]; then
  rm -rf "$ROOT/db" "$ROOT/incremental_db"
fi

# Run one Quartus stage. Redirect, never pipe; read $? on the next line.
run_stage() {
  local name="$1" exe="$2"
  shift 2
  log "=== $name $(date -Is)${*:+ [$*]} ==="
  "$Q/$exe" "$PROJ" "$@" > "$OUT/build_${name}.log" 2>&1
  local rc=$?
  local size
  size=$(wc -c < "$OUT/build_${name}.log" 2>/dev/null || echo 0)
  log "$name rc=$rc log=${size}B"
  # A zero-byte log from a stage that claims success is INCONCLUSIVE, not clean
  # -- the Y-unit session reported "errors: 0" twice off an empty log.
  if [ "$rc" -eq 0 ] && [ "$size" -lt 512 ]; then
    log "ERROR: $name returned 0 but its log is only ${size}B -- INCONCLUSIVE, refusing to continue"
    return 90
  fi
  return $rc
}

# TimeQuest Tcl scripts take their script before the project name. Keep the
# same non-empty-log contract while the FIFO owner still holds the machine.
run_sta_tcl_stage() {
  local name="$1" script="$2"
  log "=== $name $(date -Is) [$script] ==="
  "$Q/quartus_sta.exe" -t "$script" "$PROJ" > "$OUT/build_${name}.log" 2>&1
  local rc=$?
  local size
  size=$(wc -c < "$OUT/build_${name}.log" 2>/dev/null || echo 0)
  log "$name rc=$rc log=${size}B"
  if [ "$rc" -eq 0 ] && [ "$size" -lt 512 ]; then
    log "ERROR: $name returned 0 but its log is only ${size}B -- INCONCLUSIVE"
    return 90
  fi
  return $rc
}

run_stage map quartus_map.exe || exit $?

# Do not spend a fit on a core whose own nets were silently replaced or whose
# attempted lint suppressors became dead hardware.  Vendor PLL/ROM primitives
# emit their own 10030 notices; this gate is deliberately limited to the
# flattened T-unit core and explicit unused_* objects owned by this project.
map_audit="$OUT/build_map.log"
if grep -E 'Warning \(10030\):.*(tunit_core\.v|Arcade-TUnit\.sv)|Warning \(10036\):.*object "unused_' "$map_audit" > "$OUT/build_map_owned_hazards.log"; then
  log "ERROR: project-owned undriven/unused synthesis hazards remain; refusing to fit"
  sed -n '1,80p' "$OUT/build_map_owned_hazards.log" >&2
  exit 91
fi
log "MAP AUDIT PASS: no project-owned undriven nets or explicit unused_* objects"

# The ADPCM fixed bank reads and writes only on the 80 MHz loader/system clock;
# its address-tag settledness guard crosses the result to the 12 MHz board.  A
# source attribute is not proof that Quartus kept the required M10K RAM, and a
# regression to two RAM clocks would reintroduce undefined RDW Warning 276027.
# Fail immediately after map if the bank is uninferred, dual-clock, or not the
# exact 16Kx8 simple-dual-port M10K shape.  This runs for universal and ADPCM;
# the DCS-only image removes the whole ADPCM board.
if [ "$VARIANT" != "dcs" ]; then
  fixed_ram_hazards="$OUT/build_map_adpcm_fixed_ram_hazards.log"
  if grep -E 'Warning \(276027\):.*fixed_rom|Info \(276[0-9]+\): RAM logic ".*fixed_rom.*" is uninferred' \
      "$map_audit" > "$fixed_ram_hazards"; then
    log "ERROR: ADPCM fixed bank has undefined or uninferred map semantics; refusing to fit"
    sed -n '1,40p' "$fixed_ram_hazards" >&2
    exit 92
  fi
  if ! grep -E 'Info \(276029\): Inferred altsyncram megafunction.*fixed_rom_rtl_0' \
      "$map_audit" >/dev/null; then
    log "ERROR: map did not report the ADPCM fixed bank as inferred altsyncram"
    exit 92
  fi
  # Quartus 17 labels a forced embedded-RAM row "M10K block" in the RAM
  # Summary.  Accept the older "M10K" spelling too, but not AUTO or logic.
  fixed_ram_row_re='fixed_rom_rtl_0.*;[[:space:]]*M10K([[:space:]]+block)?[[:space:]]*;[[:space:]]*Simple Dual Port[[:space:]]*;[[:space:]]*16384[[:space:]]*;[[:space:]]*8[[:space:]]*;[[:space:]]*16384[[:space:]]*;[[:space:]]*8[[:space:]]*;[[:space:]]*131072[[:space:]]*;'
  fixed_ram_report="$OUT/$PROJ.map.rpt"
  if [ ! -r "$fixed_ram_report" ]; then
    log "ERROR: ADPCM fixed-bank map report is missing or unreadable: $fixed_ram_report"
    exit 92
  fi
  fixed_ram_row_count="$(grep -Ec "$fixed_ram_row_re" "$fixed_ram_report")"
  fixed_ram_grep_rc=$?
  if [ "$fixed_ram_grep_rc" -gt 1 ]; then
    log "ERROR: could not inspect the ADPCM fixed-bank map row (grep rc=$fixed_ram_grep_rc)"
    exit 92
  fi
  case "$fixed_ram_row_count" in
    ''|*[!0-9]*)
      log "ERROR: invalid ADPCM fixed-bank map-row count: $fixed_ram_row_count"
      exit 92
      ;;
  esac
  if [ "$fixed_ram_row_count" -ne 1 ]; then
    log "ERROR: expected exactly one 16Kx8 simple-dual-port M10K fixed-bank row; got $fixed_ram_row_count"
    exit 92
  fi
  log "ADPCM FIXED-BANK MAP GATE PASS: exactly one single-clock 16Kx8 M10K row; no undefined dual-clock warning"
fi

# Require all four logical progressive scan rows to infer as OLD_DATA M10Ks.
python tools/audit_tunit_scanline_physical.py --stage map || exit $?

# Preserve the exact mapped boundary before the fitter mutates db/ and
# incremental_db/. A placement-only retry can then restore this archive and run
# fit -> STA -> gate -> assembly without repeating simulation, flattening, or
# map. The snapshot is commit-scoped and immutable: an occupied destination is
# evidence from an earlier run, never something this build may overwrite.
SOURCE_COMMIT="$(git -C "$ROOT" rev-parse HEAD)" || exit $?
MAPDB_SNAPSHOT="$OUT/mapdb-snapshot-${VARIANT}-${SOURCE_COMMIT:0:12}${ARTIFACT_ID:+-$ARTIFACT_ID}"
MAPDB_ARCHIVE="$MAPDB_SNAPSHOT/${PROJ}-mapped-db.tar"
MAPDB_FILE_LIST="$MAPDB_SNAPSHOT/mapped-db-files.lst0"
MAPDB_FILE_HASHES="$MAPDB_SNAPSHOT/mapped-db-files.sha256"
MAPDB_RECEIPT="$MAPDB_SNAPSHOT/mapdb-snapshot.receipt"
[ ! -e "$MAPDB_SNAPSHOT" ] || {
  log "ERROR: immutable mapped-DB snapshot already exists: $MAPDB_SNAPSHOT"
  exit 93
}
[ -d "$ROOT/db" ] && [ -d "$ROOT/incremental_db" ] || {
  log "ERROR: map completed without both database directories"
  exit 93
}
mkdir -p "$MAPDB_SNAPSHOT" || exit $?
find db incremental_db -type f -print0 | LC_ALL=C sort -z > "$MAPDB_FILE_LIST" || exit $?
map_db_files="$(tr -cd '\0' < "$MAPDB_FILE_LIST" | wc -c | tr -d ' ')"
case "$map_db_files" in
  ''|*[!0-9]*) log "ERROR: invalid mapped-DB file count: $map_db_files"; exit 93 ;;
esac
[ "$map_db_files" -gt 10 ] || {
  log "ERROR: mapped-DB file set is incomplete: $map_db_files files"
  exit 93
}
xargs -0 sha256sum < "$MAPDB_FILE_LIST" > "$MAPDB_FILE_HASHES" || exit $?
tar --null -T "$MAPDB_FILE_LIST" -cf "$MAPDB_ARCHIVE" || exit $?
[ -s "$MAPDB_ARCHIVE" ] || {
  log "ERROR: mapped-DB snapshot archive is absent or empty"
  exit 93
}
cp -p "$QSF_SNAPSHOT" "$MAPDB_SNAPSHOT/${PROJ}.qsf.entry" || exit $?
cp -p "$ROOT/$PROJ.qpf" "$MAPDB_SNAPSHOT/$PROJ.qpf" || exit $?
cp -p "$OUT/build_map.log" "$MAPDB_SNAPSHOT/build_map.log" || exit $?
cp -p "$OUT/$PROJ.map.rpt" "$MAPDB_SNAPSHOT/$PROJ.map.rpt" || exit $?
cp -p "$OUT/$PROJ.map.summary" "$MAPDB_SNAPSHOT/$PROJ.map.summary" || exit $?
map_db_bytes="$(wc -c < "$MAPDB_ARCHIVE" | tr -d ' ')"
{
  printf 'schema=tunit-mapdb-snapshot-v1\n'
  printf 'source_commit=%s\n' "$SOURCE_COMMIT"
  printf 'variant=%s\n' "$VARIANT"
  printf 'build_date=%s\n' "$BUILD_DATE"
  printf 'candidate_provenance_sha256=%s\n' "$TUNIT_CANDIDATE_PROVENANCE_SHA256"
  printf 'mapped_db_files=%s\n' "$map_db_files"
  printf 'mapped_db_archive_bytes=%s\n' "$map_db_bytes"
  sha256sum "$MAPDB_ARCHIVE" "$MAPDB_FILE_HASHES" \
    "$MAPDB_SNAPSHOT/${PROJ}.qsf.entry" "$MAPDB_SNAPSHOT/$PROJ.qpf" \
    "$MAPDB_SNAPSHOT/build_map.log" "$MAPDB_SNAPSHOT/$PROJ.map.rpt" \
    "$MAPDB_SNAPSHOT/$PROJ.map.summary" build_syn/tunit_core.v \
    build_syn/tunit_core.manifest.json "$Q/quartus_map.exe" \
    "$Q/quartus_fit.exe" "$Q/quartus_sta.exe" "$Q/quartus_asm.exe"
  if [ -n "${TUNIT_QUALIFICATION_RECEIPT:-}" ]; then
    sha256sum "$TUNIT_QUALIFICATION_RECEIPT"
  fi
} > "$MAPDB_RECEIPT" || exit $?
map_db_sha="$(sha256sum "$MAPDB_ARCHIVE" | awk '{print $1}')"
log "MAP DB SNAPSHOT PASS: files=$map_db_files bytes=$map_db_bytes sha256=$map_db_sha path=$MAPDB_SNAPSHOT"

# TUNIT_SEED overrides the fitter placement seed for THIS run only, on the
# command line -- the QSF is never mutated, so preflight's source hashes and the
# artifact provenance stay valid. The seed is recorded in the manifest, because
# an image whose placement cannot be reproduced from the recorded inputs is not
# provenanced. The QSF SEED (10) was chosen for the UNIVERSAL renderer; a
# different variant is a different cell count and therefore a different
# placement basin, so it may need its own.
# QSF PROTECTION IS UNCONDITIONAL and is armed before flatten/preflight above.
# It used to live inside the TUNIT_SEED branch, so an ORDINARY build had none --
# and Quartus rewrites this file on every run.
# Twice now that has bitten: once materialising the conditional
# VERILOG_MACRO "TUNIT_DIAG=1" into the tracked QSF (so the NEXT "production"
# build would silently have been another diag image), and once rewriting it with
# CRLF line endings, which is semantically identical but leaves the tree DIRTY --
# and preflight refuses a dirty tree, so every subsequent build died before the
# fitter with a message about the source tree rather than about the QSF.

fit_args=()
if [ -n "${TUNIT_SEED:-}" ]; then
  case "$TUNIT_SEED" in
    ''|*[!0-9]*) printf 'ERROR: TUNIT_SEED must be a non-negative integer
' >&2; exit 2 ;;
  esac
  fit_args+=("--seed=$TUNIT_SEED")
  # MEASURED 2026-08-02: quartus_fit --seed=N does NOT leave the project alone.
  # It PERSISTS the override back into the QSF (SEED 10 -> SEED 3), so the file
  # no longer hashes to what preflight recorded and every artifact built from
  # that QSF -- including earlier ones -- fails its provenance check. The
  # packager caught it; the claim that the command line "never mutates the QSF"
  # was simply wrong.
  #
  # Snapshot and restore around the fit. The manifest's fitter_seed_override
  # remains the authoritative record of how the image was actually placed, so
  # the reproduction recipe stays complete: this QSF plus TUNIT_SEED=N. This
  # restores a file Quartus edited behind us; it hides nothing.
  log "FITTER SEED OVERRIDE: $TUNIT_SEED (the unconditional QSF snapshot above covers the rewrite)"
fi
run_stage fit quartus_fit.exe "${fit_args[@]+"${fit_args[@]}"}" || exit $?
# Restore as soon as the fitter is done so STA and the gate see the pinned
# file. The EXIT trap stays armed for the stages that follow.
restore_qsf

# Prove the intended scan rows survived fitting as eight unique M10Ks.
python tools/audit_tunit_scanline_physical.py --stage fit || exit $?

if [ "$VARIANT" != "dcs" ]; then
  python tools/audit_tunit_postfit_cdc.py || exit $?
fi

# STA's exit code is deliberately IGNORED for pass/fail. It is 0 on failure.
# We run it for its reports and then judge the reports.
run_stage sta quartus_sta.exe
sta_rc=$?
if [ "$sta_rc" -eq 90 ]; then exit 90; fi
log "note: sta rc=$sta_rc is NOT evidence of closure -- quartus_sta exits 0 when timing fails"

# Prove progressive-valid reaches each physical store and hit path at every
# required timing corner.
run_sta_tcl_stage scanline_sta tools/report_tunit_scanline_snoop_timing.tcl || exit $?

# ---------------------------------------------------------------------------
# THE GATE. Nothing below this line is reachable unless it passes.
# ---------------------------------------------------------------------------
log "=== TIMING GATE $(date -Is) ==="
python tools/assemble_gate.py
gate_rc=$?
if [ "$gate_rc" -ne 0 ]; then
  log "BLOCKED: timing gate failed (rc=$gate_rc). NO RBF WILL BE PRODUCED."
  log "There is no candidate. Do not flash anything from $OUT."
  exit "$gate_rc"
fi

if [ "$DO_ASM" -eq 0 ]; then
  log "gate PASSED; --no-asm given, stopping without an image"
  exit 0
fi

# A zero return from quartus_asm is not proof that it replaced an existing
# generic image.  Remove both generic outputs first so the finalizer can only
# see files emitted by this exact, timing-gated assembly run.
unset TUNIT_ASSEMBLY_COMPLETE
rm -f "$OUT/$PROJ.rbf" "$OUT/$PROJ.sof" || {
  log "ERROR: could not remove stale generic assembly outputs"
  exit 92
}
run_stage asm quartus_asm.exe || exit $?
export TUNIT_ASSEMBLY_COMPLETE=1
# quartus_asm may rewrite the QSF too.  Restore it before the final source
# mutation gate in finalize_tunit_artifact.py rehashes every tracked input.
restore_qsf
if [ "$PHYSICAL_ONLY" = "1" ]; then
  PHYSICAL_RECEIPT="$OUT/physical-${ARTIFACT_ID}.receipt"
  [ ! -e "$PHYSICAL_RECEIPT" ] || {
    log "ERROR: immutable physical receipt already exists: $PHYSICAL_RECEIPT"
    exit 94
  }
  {
    printf 'schema=tunit-physical-v1\n'
    printf 'variant=%s\n' "$VARIANT"
    printf 'artifact_id=%s\n' "$ARTIFACT_ID"
    printf 'diag_build=%s\n' "$DIAG_BUILD"
    printf 'ascal_policy=%s\n' "$ASCAL_POLICY"
    printf 'build_date=%s\n' "$BUILD_DATE"
    printf 'session=%s\n' "${FPGA_SESSION:-}"
    printf 'ticket=%s\n' "${TUNIT_FIFO_TICKET:-}"
    printf 'candidate_provenance_sha256=%s\n' "$TUNIT_CANDIDATE_PROVENANCE_SHA256"
    printf 'timing_gate=pass\n'
    printf 'assembly=pass\n'
  } > "$PHYSICAL_RECEIPT" || exit $?
  log "PHYSICAL CHAIN PASS: receipt=$PHYSICAL_RECEIPT; finalize after FIFO release"
else
  python tools/finalize_tunit_artifact.py --variant "$VARIANT" || exit $?
fi
unset TUNIT_ASSEMBLY_COMPLETE

# Report identity so the owner can decide, per the rule that an RBF must not
# reach a cabinet until its contents are reported.
for ext in sof rbf; do
  f="$OUT/$PROJ.$ext"
  if [ -f "$f" ]; then
    log "$(basename "$f"): $(wc -c < "$f") bytes  sha256=$(sha256sum "$f" | cut -c1-16)...  mtime=$(date -r "$f" -Is)"
  fi
done
log "fit.rpt mtime=$(date -r "$OUT/$PROJ.fit.rpt" -Is 2>/dev/null || echo none)"
log "Compare the image mtime to fit.rpt BY DATE, not clock time (NARC, 2026-07-27)."
log "DONE $(date -Is)"
