#!/usr/bin/env python3
"""Run TC repeat against the production lower row cache and DDR model."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
SOURCES = (
    "rtl/sdram/vram_sdram.sv",
    "rtl/sdram/vram_sdram_top.sv",
    "rtl/sdram/stv_vram_ddr_agent.sv",
    "rtl/sdram/stv_vram_ddr_top.sv",
    "rtl/tunit/tunit_scanline.sv",
    "sim/models/ddr3_avalon_model.sv",
    "sim/tb_tunit_scanline_integrated_tc.sv",
)
CASES = (
    (
        "production",
        ("TUNIT_SCAN_SOURCE_EXACT",),
        "PASS tb_tunit_scanline_integrated_tc tc=passes0,2,130,259,270",
    ),
    (
        "three-line-mutation",
        ("MUT_TUNIT_SCAN_THREE_LINES",),
        "PASS MUTATION_KILLED integrated-three-line",
    ),
    (
        "cpu-only-publication-mutation",
        ("MUT_TUNIT_SCAN_CPU_ONLY_SNOOP",),
        "PASS MUTATION_KILLED cpu-only-publication",
    ),
    (
        "no-d-publication-mutation",
        ("MUT_TUNIT_SCAN_NO_D_SNOOP",),
        "PASS MUTATION_KILLED no-d-publication",
    ),
    (
        "partial-be-publication-mutation",
        ("PARTIAL_BE_WRITE", "MUT_TUNIT_SCAN_PARTIAL_BE"),
        "PASS MUTATION_KILLED partial-be-publication",
    ),
)


def run(command: list[str], log: Path) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(
        command, cwd=ROOT, text=True, capture_output=True, check=False
    )
    log.write_text(
        (result.stdout or "") + (result.stderr or ""),
        encoding="utf-8",
        errors="replace",
    )
    return result


def main() -> int:
    label = "tunit-scanline-integrated-tc-" + datetime.now().strftime(
        "%Y%m%d-%H%M%S"
    )
    out = ROOT / "sim" / "out" / label
    out.mkdir(parents=True)
    passed = True
    for name, defines, marker in CASES:
        image = out / f"{name}.vvp"
        compile_result = run(
            [
                "iverilog",
                "-g2012",
                "-s",
                "tb_tunit_scanline_integrated_tc",
                *[f"-D{define}" for define in defines],
                "-o",
                str(image),
                *SOURCES,
            ],
            out / f"{name}-compile.log",
        )
        if compile_result.returncode:
            passed = False
            continue
        simulation = run(["vvp", str(image)], out / f"{name}-sim.log")
        text = (simulation.stdout or "") + (simulation.stderr or "")
        if simulation.returncode or marker not in text or "FATAL" in text.upper():
            passed = False

    print(("PASS" if passed else "FAIL") + f": integrated TC gate ({out})")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
