#!/usr/bin/env bash
# Run exactly one T-unit build in the shared advisory FIFO and machine lock.
# The FIFO orders adopters; quartus_lock.sh remains the authoritative mutex.
#
# TUNIT_BUILD_MODE defaults to engineering.  A production candidate requires
# TUNIT_BUILD_MODE=production plus TUNIT_QUALIFICATION_RECEIPT; build_tunit.sh
# performs the receipt verification after regenerating the exact netlist.
# Every queued engineering run must carry a unique immutable label, for example
# NBA-SOUND-PACE, NBA-FLASH-DIAG, NBA-FLASH-SRT-ORDER-DIAG, MK2-DCS-S10,
# or an exact NBA-ASCAL A/B ID.

set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VARIANT="${TUNIT_VARIANT:-universal}"
case "$VARIANT" in
  universal|adpcm|dcs) ;;
  *) printf 'ERROR: TUNIT_VARIANT must be universal, adpcm, or dcs\n' >&2; exit 2 ;;
esac
BUILD_MODE="${TUNIT_BUILD_MODE:-engineering}"
case "$BUILD_MODE" in
  engineering) BUILD_MODE_ARG=--engineering ;;
  production) BUILD_MODE_ARG= ;;
  *) printf 'ERROR: TUNIT_BUILD_MODE must be engineering or production\n' >&2; exit 2 ;;
esac
ASCAL_POLICY="${TUNIT_ASCAL_POLICY:-main}"
ARTIFACT_ID="${TUNIT_ARTIFACT_ID:-}"
AB_REFERENCE="${TUNIT_AB_REFERENCE_MANIFEST:-}"
DIAG_BUILD="${TUNIT_DIAG_BUILD:-0}"
case "$DIAG_BUILD" in
  0|1) ;;
  *) printf 'ERROR: TUNIT_DIAG_BUILD must be exactly 0 or 1\n' >&2; exit 2 ;;
esac
COMMITTED_BUILD_DATE="$(git -C "$ROOT" show HEAD:build_id.v 2>/dev/null |
  sed -n 's/^`define BUILD_DATE "\([0-9][0-9][0-9][0-9][0-9][0-9]\)"$/\1/p')"
[ -n "$COMMITTED_BUILD_DATE" ] || {
  printf 'ERROR: committed build_id.v does not contain one YYMMDD BUILD_DATE\n' >&2
  exit 2
}
if [ -n "${TUNIT_BUILD_DATE:-}" ]; then
  BUILD_DATE="$TUNIT_BUILD_DATE"
elif [ "$BUILD_MODE" = "production" ]; then
  # Production qualification binds an exact flattened netlist. Keep its build
  # ID at the committed release value; changing it is a source/release change.
  BUILD_DATE="$COMMITTED_BUILD_DATE"
else
  BUILD_DATE="$(date +%y%m%d)"
fi
ASCAL_A_REFERENCE="output_files/Arcade-TUnit-ADPCM-ENGINEERING-NBA-ASCAL-A-NEAREST.manifest.json"
case "$ASCAL_POLICY" in
  main)
    case "$ARTIFACT_ID" in
      NBA-ASCAL-A-NEAREST|NBA-ASCAL-B-BILINEAR)
        printf 'ERROR: reserved NBA-ASCAL artifact ID requires its matching fixed policy\n' >&2
        exit 2
        ;;
    esac
    ;;
  nearest)
    [ "$ARTIFACT_ID" = "NBA-ASCAL-A-NEAREST" ] || {
      printf 'ERROR: nearest policy requires TUNIT_ARTIFACT_ID=NBA-ASCAL-A-NEAREST\n' >&2
      exit 2
    }
    [ -z "$AB_REFERENCE" ] || {
      printf 'ERROR: nearest policy must not carry a TUNIT_AB_REFERENCE_MANIFEST\n' >&2
      exit 2
    }
    ;;
  bilinear)
    [ "$ARTIFACT_ID" = "NBA-ASCAL-B-BILINEAR" ] || {
      printf 'ERROR: bilinear policy requires TUNIT_ARTIFACT_ID=NBA-ASCAL-B-BILINEAR\n' >&2
      exit 2
    }
    [ "$AB_REFERENCE" = "$ASCAL_A_REFERENCE" ] || {
      printf 'ERROR: bilinear policy requires TUNIT_AB_REFERENCE_MANIFEST=%s\n' "$ASCAL_A_REFERENCE" >&2
      exit 2
    }
    ;;
  *) printf 'ERROR: TUNIT_ASCAL_POLICY must be main, nearest, or bilinear\n' >&2; exit 2 ;;
esac
case "$ARTIFACT_ID" in
  ''|*[!A-Z0-9._-]*)
    if [ -n "$ARTIFACT_ID" ]; then
      printf 'ERROR: TUNIT_ARTIFACT_ID must use only A-Z, 0-9, dot, underscore, or dash\n' >&2
      exit 2
    fi
    ;;
esac
if [ -n "$ARTIFACT_ID" ]; then
  case "${ARTIFACT_ID:0:1}" in
    [A-Z0-9]) ;;
    *) printf 'ERROR: TUNIT_ARTIFACT_ID must begin with A-Z or 0-9\n' >&2; exit 2 ;;
  esac
fi
if [ "${#ARTIFACT_ID}" -gt 64 ]; then
  printf 'ERROR: TUNIT_ARTIFACT_ID is longer than 64 characters\n' >&2
  exit 2
fi
case "$BUILD_DATE" in
  [0-9][0-9][0-9][0-9][0-9][0-9]) ;;
  *) printf 'ERROR: TUNIT_BUILD_DATE must be exactly six decimal YYMMDD digits\n' >&2; exit 2 ;;
esac
if [ "$BUILD_MODE" = "production" ] &&
   [ "$BUILD_DATE" != "$COMMITTED_BUILD_DATE" ]; then
  printf 'ERROR: production TUNIT_BUILD_DATE must match committed build_id.v (%s)\n' "$COMMITTED_BUILD_DATE" >&2
  exit 2
fi
if [ "$ASCAL_POLICY" != "main" ] && [ "$BUILD_MODE" != "engineering" ]; then
  printf 'ERROR: fixed ascal policies are engineering-only until cabinet acceptance\n' >&2
  exit 2
fi
if [ "$ASCAL_POLICY" != "main" ] && [ "$VARIANT" != "adpcm" ]; then
  printf 'ERROR: NBA ascal A/B policies require TUNIT_VARIANT=adpcm\n' >&2
  exit 2
fi
if [ "$ASCAL_POLICY" != "main" ] && [ "$DIAG_BUILD" != "0" ]; then
  printf 'ERROR: fixed ascal A/B policies forbid TUNIT_DIAG_BUILD; the scaler discriminator must be pixel-clean\n' >&2
  exit 2
fi
if [ "$DIAG_BUILD" = "1" ]; then
  case "$ARTIFACT_ID" in
    NBA-FLASH-DIAG|NBA-FLASH-SRT-ORDER-DIAG) ;;
    *)
      printf 'ERROR: TUNIT_DIAG_BUILD=1 requires a reserved NBA flashing diagnostic ID\n' >&2
      exit 2
      ;;
  esac
  [ "$VARIANT" = "adpcm" ] || {
    printf 'ERROR: NBA flashing diagnostics require TUNIT_VARIANT=adpcm\n' >&2
    exit 2
  }
  [ "$ASCAL_POLICY" = "main" ] || {
    printf 'ERROR: NBA flashing diagnostics require TUNIT_ASCAL_POLICY=main\n' >&2
    exit 2
  }
  [ "$BUILD_MODE" = "engineering" ] || {
    printf 'ERROR: NBA flashing diagnostics require TUNIT_BUILD_MODE=engineering\n' >&2
    exit 2
  }
else
  case "$ARTIFACT_ID" in
    NBA-FLASH-DIAG|NBA-FLASH-SRT-ORDER-DIAG)
      printf 'ERROR: reserved NBA flashing diagnostic IDs require TUNIT_DIAG_BUILD=1\n' >&2
      exit 2
      ;;
  esac
fi
if [ -n "$ARTIFACT_ID" ] && [ "$BUILD_MODE" != "engineering" ]; then
  printf 'ERROR: labelled diagnostic artifacts require TUNIT_BUILD_MODE=engineering\n' >&2
  exit 2
fi
if [ "$BUILD_MODE" = "engineering" ] && [ -z "$ARTIFACT_ID" ]; then
  printf 'ERROR: queued engineering builds require an immutable TUNIT_ARTIFACT_ID\n' >&2
  exit 2
fi
if [ "$ASCAL_POLICY" != "bilinear" ] && [ -n "$AB_REFERENCE" ]; then
  printf 'ERROR: only the bilinear B policy accepts TUNIT_AB_REFERENCE_MANIFEST\n' >&2
  exit 2
fi
if [ -n "$AB_REFERENCE" ] && [ ! -f "$ROOT/$AB_REFERENCE" ]; then
  printf 'ERROR: A/B reference manifest is missing: %s\n' "$AB_REFERENCE" >&2
  exit 2
fi
if [ -n "$ARTIFACT_ID" ]; then
  case "$VARIANT" in
    universal) VARIANT_LABEL=UNIVERSAL ;;
    adpcm) VARIANT_LABEL=ADPCM ;;
    dcs) VARIANT_LABEL=DCS ;;
  esac
  ARTIFACT_LABEL="${VARIANT_LABEL}-ENGINEERING-${ARTIFACT_ID}"
  for PLANNED_PATH in \
    "$ROOT/output_files/Arcade-TUnit-${ARTIFACT_LABEL}.sof" \
    "$ROOT/output_files/Arcade-TUnit-${ARTIFACT_LABEL}.rbf" \
    "$ROOT/output_files/Arcade-TUnit-${ARTIFACT_LABEL}.manifest.json" \
    "$ROOT/output_files/Arcade-TUnit-${ARTIFACT_LABEL}-DO-NOT-FLASH.txt" \
    "$ROOT/output_files/reports-${ARTIFACT_LABEL}"
  do
    if [ -e "$PLANNED_PATH" ]; then
      printf 'ERROR: immutable candidate path already exists: %s\n' "$PLANNED_PATH" >&2
      exit 2
    fi
  done
fi
if [ -z "${FPGA_SESSION:-}" ]; then
  printf 'ERROR: FPGA_SESSION must name this unique shared-host owner\n' >&2
  exit 2
fi
TAG="$FPGA_SESSION"
NOTIFY=/tmp/fpga_quartus.queue/_notify.sh

if [ ! -x "$NOTIFY" ]; then
  printf 'ERROR: shared FIFO helper is unavailable: %s\n' "$NOTIFY" >&2
  exit 78
fi

ticket="$("$NOTIFY" enqueue "$TAG" $$)"
rc=$?
if [ "$rc" -ne 0 ]; then
  printf '[tunit-queue] ERROR: FIFO enrollment failed rc=%s\n' "$rc" >&2
  exit 76
fi
# enqueue is idempotent by tag and will return an existing owner's ticket. A
# tag-only holds check would then let this process adopt that ticket and its
# cleanup would dequeue the real owner. Bind the returned basename to this
# wrapper's exact long-lived MSYS PID before arming any dequeue trap.
case "$ticket" in
  *."$TAG".$$) ;;
  *)
    printf '[tunit-queue] ERROR: FPGA_SESSION is already owned by another caller: %s\n' "$ticket" >&2
    exit 76
    ;;
esac

ticket_is_mine() {
  local held
  held="$("$NOTIFY" holds "$TAG" 2>/dev/null)" || return 1
  [ "$held" = "$ticket" ]
}

cleanup() {
  local rc=$?
  trap - EXIT INT TERM
  # dequeue is tag-scoped in the shared helper. Never delete a replacement
  # ticket if this caller's exact basename vanished or ownership changed.
  if ticket_is_mine; then
    "$NOTIFY" dequeue "$TAG" || true
  else
    printf '[tunit-queue] warning: exact ticket no longer owned; refusing tag-scoped dequeue (%s)\n' "$ticket" >&2
  fi
  exit "$rc"
}
trap cleanup EXIT
trap 'exit 130' INT TERM

printf '[tunit-queue] enrolled as %s\n' "$ticket" >&2
ticket_is_mine || {
  printf '[tunit-queue] ERROR: FIFO ticket did not remain live\n' >&2
  exit 76
}

while true; do
  ticket_is_mine || {
    printf '[tunit-queue] ERROR: FIFO ticket vanished while waiting\n' >&2
    exit 76
  }
  if "$NOTIFY" myturn "$TAG" >/dev/null 2>&1; then
    break
  fi
  sleep 10
done

ticket_is_mine || {
  printf '[tunit-queue] ERROR: FIFO ticket vanished as the turn was granted\n' >&2
  exit 76
}

"$NOTIFY" note "$TAG" "fifo-turn-entering-machine-lock" || true
printf '[tunit-queue] FIFO turn reached; entering authoritative lock\n' >&2

TUNIT_FIFO_TICKET_HELD=1 TUNIT_FIFO_TICKET="$ticket" FPGA_SESSION="$TAG" \
  TUNIT_ASCAL_POLICY="$ASCAL_POLICY" TUNIT_ARTIFACT_ID="$ARTIFACT_ID" \
  TUNIT_AB_REFERENCE_MANIFEST="$AB_REFERENCE" TUNIT_BUILD_DATE="$BUILD_DATE" \
  TUNIT_DIAG_BUILD="$DIAG_BUILD" \
  "$ROOT/tools/quartus_lock.sh" \
  "$ROOT/tools/build_tunit.sh" --variant "$VARIANT" $BUILD_MODE_ARG
rc=$?

"$NOTIFY" note "$TAG" "single-authorized-run-exited-rc-$rc" || true
exit "$rc"
