#!/usr/bin/env python3
"""Mutation-prove the third T-unit scanline lookahead buffer."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    iverilog = shutil.which("iverilog")
    vvp = shutil.which("vvp")
    if not iverilog or not vvp:
        print("ERROR: iverilog and vvp are required", file=sys.stderr)
        return 2

    label = "tunit-scanline-lookahead-" + datetime.now().strftime("%Y%m%d-%H%M%S")
    out = ROOT / "sim" / "out" / label
    out.mkdir(parents=True)
    sources = [
        ROOT / "rtl/tunit/tunit_scanline.sv",
        ROOT / "sim/tb_tunit_scanline_lookahead.sv",
    ]
    cases = {
        "production": [],
        "two-line-mutation": ["-DMUT_TUNIT_SCAN_TWO_LINES"],
    }
    passed = True
    for name, defines in cases.items():
        executable = out / f"{name}.vvp"
        compile_cmd = [
            iverilog,
            "-g2012",
            "-s",
            "tb_tunit_scanline_lookahead",
            *defines,
            "-o",
            str(executable),
            *(str(source) for source in sources),
        ]
        compile_result = subprocess.run(
            compile_cmd, cwd=ROOT, text=True, capture_output=True
        )
        (out / f"{name}-compile.log").write_text(
            (compile_result.stdout or "") + (compile_result.stderr or ""),
            encoding="utf-8",
        )
        if compile_result.returncode:
            passed = False
            continue
        run_result = subprocess.run(
            [vvp, str(executable)], cwd=ROOT, text=True, capture_output=True
        )
        log = (run_result.stdout or "") + (run_result.stderr or "")
        (out / f"{name}-sim.log").write_text(log, encoding="utf-8")
        marker = (
            "PASS tb_tunit_scanline_lookahead"
            if name == "production"
            else "PASS MUTATION_KILLED tb_tunit_scanline_lookahead"
        )
        if run_result.returncode or marker not in log or "FATAL" in log.upper():
            passed = False

    print(("PASS" if passed else "FAIL") + f": scanline lookahead gate ({out})")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
