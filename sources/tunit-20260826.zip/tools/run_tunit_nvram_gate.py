#!/usr/bin/env python3
"""Prove deterministic T-unit CMOS boot clear and kill its revert mutant."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
RTL = ROOT / "rtl" / "tunit" / "tunit_nvram_bridge.sv"
BENCH = ROOT / "sim" / "tb_tunit_nvram_bridge.sv"
PASS_MARKER = (
    "PASS tb_tunit_nvram_bridge boot-clear restore-priority "
    "autosave manual-clear"
)
MUTANT_MARKER = "power-on clear did not hold board reset"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run(command: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )


def transcript(result: subprocess.CompletedProcess[str]) -> str:
    return (result.stdout or "") + (result.stderr or "")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--label",
        default=(
            "tunit-nvram-"
            + datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
            + f"-{os.getpid()}"
        ),
    )
    args = parser.parse_args()

    iverilog = shutil.which("iverilog")
    vvp = shutil.which("vvp")
    if not iverilog or not vvp:
        print("ERROR: iverilog/vvp not found", file=sys.stderr)
        return 2

    out = ROOT / "sim" / "out" / args.label
    if out.exists():
        print(f"ERROR: output already exists: {out}", file=sys.stderr)
        return 2
    out.mkdir(parents=True)

    cases = (
        ("stock", []),
        ("no_boot_clear_mutant", ["-DMUT_TUNIT_NVRAM_NO_BOOT_CLEAR"]),
    )
    results: dict[str, object] = {}
    for name, defines in cases:
        image = out / f"{name}.vvp"
        compile_command = [
            iverilog,
            "-g2012",
            *defines,
            "-s",
            "tb_tunit_nvram_bridge",
            "-o",
            str(image),
            str(RTL),
            str(BENCH),
        ]
        compiled = run(compile_command)
        (out / f"{name}.compile.log").write_text(
            transcript(compiled), encoding="utf-8"
        )
        if compiled.returncode:
            print(f"ERROR: {name} did not compile; see {out}", file=sys.stderr)
            return 1

        simulated = run([vvp, str(image)])
        output = transcript(simulated)
        (out / f"{name}.run.log").write_text(output, encoding="utf-8")
        results[name] = {
            "defines": defines,
            "compile_command": compile_command,
            "compile_returncode": compiled.returncode,
            "run_returncode": simulated.returncode,
            "pass_marker": PASS_MARKER in output,
            "mutant_marker": MUTANT_MARKER in output,
        }

    stock = results["stock"]
    mutant = results["no_boot_clear_mutant"]
    assert isinstance(stock, dict) and isinstance(mutant, dict)
    passed = (
        stock["run_returncode"] == 0
        and stock["pass_marker"]
        and mutant["run_returncode"] != 0
        and mutant["mutant_marker"]
        and not mutant["pass_marker"]
    )

    receipt = {
        "schema": 1,
        "gate": "tunit-nvram-boot-clear",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "sources": {
            str(RTL.relative_to(ROOT)).replace("\\", "/"): sha256(RTL),
            str(BENCH.relative_to(ROOT)).replace("\\", "/"): sha256(BENCH),
        },
        "results": results,
        "passed": passed,
    }
    (out / "receipt.json").write_text(
        json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    if not passed:
        print(f"ERROR: NVRAM gate failed; see {out}", file=sys.stderr)
        return 1
    print(f"NVRAM BOOT-CLEAR GATE: PASS ({out.relative_to(ROOT)})")
    print("  stock: deterministic clear, restore priority, manual-save semantics")
    print("  mutant: no-boot-clear revert killed at the intended assertion")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
