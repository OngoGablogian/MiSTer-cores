#!/usr/bin/env python3
"""Run the T-unit candidate-baseline gates and emit one bound receipt."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time


ROOT = Path(__file__).resolve().parents[1]
FRAME_GATE_WALL_TIMEOUT = 3_600
DEFAULT_ROM_DIR = Path(r"D:\deck\fpga\tunit\mk2\roms")
FRAME_SIMULATOR_TOOL_NAMES = ("qrun", "vlog", "vopt", "vsim")


@dataclass(frozen=True)
class Gate:
    name: str
    evidence_class: str
    command: tuple[str, ...]
    marker: str


def digest(path: Path) -> str:
    value = sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def git(*args: str) -> str:
    return subprocess.check_output(
        ["git", *args], cwd=ROOT, text=True, stderr=subprocess.DEVNULL
    ).strip()


def python_gate(
    name: str, evidence_class: str, script: str, marker: str, *args: str
) -> Gate:
    return Gate(
        name,
        evidence_class,
        (sys.executable, str(ROOT / "tools" / script), *args),
        marker,
    )


def gate_plan(args: argparse.Namespace) -> list[Gate]:
    label = args.label
    rom_dir = str(args.rom_dir.resolve())
    mame = str(args.mame.resolve())
    return [
        python_gate(
            "flatten_universal", "shipping-hierarchy", "build_quartus_rtl.py",
            "provenance:", "--variant", "universal",
        ),
        python_gate(
            "frozen_mame_goldens", "independent-mame", "verify_tunit_goldens.py",
            "PASS: T-unit MAME 0.289 goldens",
        ),
        python_gate(
            "framework_snapshot", "pinned-framework", "verify_framework_snapshot.py",
            "PASS: framework snapshot",
        ),
        python_gate(
            "mra_mame_crosscheck", "independent-mame", "validate_tunit_candidate_mras.py",
            "PASS: local MAME", "--mame", mame, "--rom-dir", rom_dir,
        ),
        python_gate(
            "component_suite", "directed-and-model", "run_component_suite.py",
            "selected=46 run=46 passed=46 failed=0\nfailed_tests=\n"
            "cadence_phase6_mutation=killed",
            "--label", f"{label}-components", "--stop-on-fail",
        ),
        python_gate(
            "ddr3_priority", "mutation", "run_tunit_ddr3_arb_gate.py",
            "DDR3 ARBITRATION GATE: PASS", "--label", f"{label}-ddr3-arb",
        ),
        python_gate(
            "tms34010_union", "directed-cpu-suite", "run_tms_shared.py",
            "selected=130 run=130 passed=130 failed=0 inconclusive=0",
            "--label", f"{label}-tms34010", "--stop-on-fail",
        ),
        python_gate(
            "audio_telemetry_window", "mutation", "run_tunit_audio_telemetry_gate.py",
            "AUDIO TELEMETRY GATE: PASS", "--label", f"{label}-audio-telemetry",
        ),
        python_gate(
            "orphan_mutations", "mutation", "run_tunit_orphan_gate.py",
            "ORPHAN GATE: PASS", "--label", f"{label}-orphans",
        ),
        python_gate(
            "profile_layout", "directed", "run_tunit_profile_matrix.py",
            "PASS: T-unit profile/layout matrix", "--label", f"{label}-profiles",
        ),
        python_gate(
            "five_profile_boot", "independent-mame", "run_tunit_profile_boot_gate.py",
            "PROFILE BOOT GATE: PASS", "--cadence", "both",
        ),
        python_gate(
            "loader_equivalence", "independent-reference", "run_tunit_loader_equiv_gate.py",
            "LOADER-EQUIV GATE: PASS",
        ),
        python_gate(
            "loader_mutations", "mutation", "run_tunit_loader_equiv_gate.py",
            "LOADER-EQUIV MUTATION SUITE: PASS", "--mutate", "ALL",
        ),
        python_gate(
            "srt_fill", "independent-vectors", "run_tunit_srt_gate.py",
            "SRT GATE: PASS", "--label", f"{label}-srt",
        ),
        python_gate(
            "srt_dma_order", "mutation", "run_tunit_srt_dma_order_gate.py",
            "TUNIT SRT-DMA ORDER GATE: PASS",
            "--label", f"{label}-srt-dma-order",
        ),
        python_gate(
            "instruction_spacing", "independent-vectors", "run_tunit_spacing_gate.py",
            "SPACING GATE: PASS", "--sweep-cycles", "200000",
        ),
        python_gate(
            "dma_matrix", "independent-mame", "run_tunit_dma_matrix.py",
            "T-unit DMA2 matrix: 161/161 cases",
        ),
        python_gate(
            "video_matrix", "independent-mame", "run_tunit_video_matrix.py",
            "T-unit video matrix:",
        ),
        python_gate(
            "gfx_cycle_accounting", "independent-mame", "run_tunit_gfx_cycle_gate.py",
            "PASS: signed MAME 0.289 graphics cycles", "--label", f"{label}-gfx-cycles",
        ),
        python_gate(
            "ppop_truth", "independent-ti-and-mame", "run_tunit_ppop_truth_gate.py",
            "PPOP GATE: PASS", "--label", f"{label}-ppop",
        ),
        python_gate(
            "gfx_reuse_cache", "donor-differential", "run_tunit_gfx_reuse_cache_gate.py",
            "PASS: T source reuse matches Wolf", "--label", f"{label}-gfx-reuse",
        ),
        python_gate(
            "vram_rdw", "directed", "run_tunit_vram_rdw_gate.py",
            "PASS: CPU VRAM requests survive", "--label", f"{label}-vram-rdw",
        ),
        python_gate(
            "vram_read32_planes", "production-ddr",
            "run_tunit_vram_read32_planes_gate.py",
            "PASS: aligned CPU read32 returns all four selected bytes",
            "--label", f"{label}-vram-read32",
        ),
        python_gate(
            "vram_read32_truncate_mutation", "mutation",
            "run_tunit_vram_read32_planes_gate.py",
            "PASS: exact aligned-read32 upper-half-zero defect reproduced",
            "--mutation", "truncate-upper", "--expect-repro",
            "--label", f"{label}-vram-read32-mutation",
        ),
        python_gate(
            "vram_scan_coherency", "mutation", "run_tunit_vram_scan_gate.py",
            "PASS: scan coherency contracts exercised", "--label", f"{label}-vram-scan",
        ),
        python_gate(
            "vram_bank1", "mutation", "run_tunit_vram_bank1_gate.py",
            "PASS: bank-1 paired-write contracts exercised", "--label", f"{label}-vram-bank1",
        ),
        python_gate(
            "scanline_coherence", "mutation", "run_tunit_scanline_coherence_gate.py",
            "PASS: scanline coherence gate",
        ),
        python_gate(
            "scanline_integrated_acd", "production-ddr-and-mutation",
            "run_tunit_scanline_integrated_tc_gate.py",
            "PASS: integrated TC gate", "--label", f"{label}-scanline-acd",
        ),
        python_gate(
            "scanline_lookahead", "bounded-stall-mutation",
            "run_tunit_scanline_lookahead_gate.py",
            "PASS: scanline lookahead gate", "--label", f"{label}-scanline-lookahead",
        ),
        python_gate(
            "scale140_rgb", "paired-pixel-mutation", "run_tunit_scale140_rgb_gate.py",
            "PASS: Scale140 paired pixels survive DDR-to-RGB; mutation killed",
            "--label", f"{label}-scale140-rgb",
        ),
        python_gate(
            "video_pageflip", "production-ddr-and-mutation",
            "run_tunit_video_pageflip_gate.py",
            "PASS: hidden pending page prewarms before atomic publication",
            "--label", f"{label}-video-pageflip",
        ),
        python_gate(
            "page_fence", "directed", "run_tunit_page_fence_gate.py",
            "PAGE FENCE GATE: PASS",
        ),
        python_gate(
            "page_fence_blank_end", "directed", "run_tunit_page_fence_blank_end_gate.py",
            "PAGE FENCE BLANK-END GATE: PASS",
        ),
        python_gate(
            "dma_page_kill", "mutation", "run_tunit_dma_page_kill_gate.py",
            "PASS: T-unit DMA2 literal kill publishes page", "--label", f"{label}-dma-page",
        ),
        python_gate(
            "raster_resync", "directed", "run_tunit_raster_resync_gate.py",
            "RASTER RESYNC GATE: PASS",
        ),
        python_gate(
            "crt_adjust", "directed", "run_tunit_crt_adjust_gate.py",
            "PASS: tb_tunit_crt_adjust",
        ),
        python_gate(
            "adpcm_te_tune_nba_command", "mame-ym-and-mutation",
            "run_tunit_adpcm_tune_gate.py",
            "ADPCM TE-TUNE/NBA-COMMAND GATE: PASS", "--rom-dir", rom_dir,
            "--label", f"{label}-adpcm-tune", "--jobs", str(args.jobs),
        ),
        python_gate(
            "adpcm_reload_fixedbank", "loader-map-and-mutation",
            "run_tunit_adpcm_reload_gate.py",
            "ADPCM RELOAD INTEGRATION GATE: PASS",
            "--label", f"{label}-adpcm-reload",
        ),
        python_gate(
            "mk2_dcs_pcm", "owner-rom-and-independent-pcm", "run_mk2_dcs_pcm.py",
            "PASS: MK2 DCS2K PCM gate", "--rom", str(args.dcs_rom),
            "--wav", str(args.dcs_wav), "--track", args.dcs_track, "--looping",
            "--label", f"{label}-dcs-pcm",
        ),
        python_gate(
            "mk2_frame_crc", "independent-mame", "run_mk2_frame_gate.py",
            "PASS: MK2 frame gate", "--program", str(args.mk2_program),
            "--graphics", str(args.mk2_graphics), "--sound", str(args.dcs_rom),
            "--nvram", str(args.mk2_nvram), "--golden", str(args.mk2_frame_golden),
            "--engine", "netlist-qrun",
            "--netlist", str(ROOT / "build_syn" / "tunit_core.v"),
            # Exact frames 0..58 precede MAME's first timing-dependent attract
            # transition and include the boot-screen CRC change. The direct
            # NBA/TE page-owner mutation/profile-scope proof is video_pageflip.
            "--frame-count", "59", "--frame-skip", "0", "--golden-start", "0",
            "--qualification-window",
            "--wall-timeout", str(FRAME_GATE_WALL_TIMEOUT),
            "--label", f"{label}-mk2-frames",
        ),
    ]


REQUIRED_GATE_CONTRACT = (
    ("flatten_universal", "build_quartus_rtl.py", "provenance:"),
    ("frozen_mame_goldens", "verify_tunit_goldens.py", "PASS: T-unit MAME 0.289 goldens"),
    ("framework_snapshot", "verify_framework_snapshot.py", "PASS: framework snapshot"),
    ("mra_mame_crosscheck", "validate_tunit_candidate_mras.py", "PASS: local MAME"),
    ("component_suite", "run_component_suite.py", "selected=46 run=46 passed=46 failed=0\nfailed_tests=\ncadence_phase6_mutation=killed"),
    ("ddr3_priority", "run_tunit_ddr3_arb_gate.py", "DDR3 ARBITRATION GATE: PASS"),
    ("tms34010_union", "run_tms_shared.py", "selected=130 run=130 passed=130 failed=0 inconclusive=0"),
    ("audio_telemetry_window", "run_tunit_audio_telemetry_gate.py", "AUDIO TELEMETRY GATE: PASS"),
    ("orphan_mutations", "run_tunit_orphan_gate.py", "ORPHAN GATE: PASS"),
    ("profile_layout", "run_tunit_profile_matrix.py", "PASS: T-unit profile/layout matrix"),
    ("five_profile_boot", "run_tunit_profile_boot_gate.py", "PROFILE BOOT GATE: PASS"),
    ("loader_equivalence", "run_tunit_loader_equiv_gate.py", "LOADER-EQUIV GATE: PASS"),
    ("loader_mutations", "run_tunit_loader_equiv_gate.py", "LOADER-EQUIV MUTATION SUITE: PASS"),
    ("srt_fill", "run_tunit_srt_gate.py", "SRT GATE: PASS"),
    ("srt_dma_order", "run_tunit_srt_dma_order_gate.py", "TUNIT SRT-DMA ORDER GATE: PASS"),
    ("instruction_spacing", "run_tunit_spacing_gate.py", "SPACING GATE: PASS"),
    ("dma_matrix", "run_tunit_dma_matrix.py", "T-unit DMA2 matrix: 161/161 cases"),
    ("video_matrix", "run_tunit_video_matrix.py", "T-unit video matrix:"),
    ("gfx_cycle_accounting", "run_tunit_gfx_cycle_gate.py", "PASS: signed MAME 0.289 graphics cycles"),
    ("ppop_truth", "run_tunit_ppop_truth_gate.py", "PPOP GATE: PASS"),
    ("gfx_reuse_cache", "run_tunit_gfx_reuse_cache_gate.py", "PASS: T source reuse matches Wolf"),
    ("vram_rdw", "run_tunit_vram_rdw_gate.py", "PASS: CPU VRAM requests survive"),
    ("vram_read32_planes", "run_tunit_vram_read32_planes_gate.py", "PASS: aligned CPU read32 returns all four selected bytes"),
    ("vram_read32_truncate_mutation", "run_tunit_vram_read32_planes_gate.py", "PASS: exact aligned-read32 upper-half-zero defect reproduced"),
    ("vram_scan_coherency", "run_tunit_vram_scan_gate.py", "PASS: scan coherency contracts exercised"),
    ("vram_bank1", "run_tunit_vram_bank1_gate.py", "PASS: bank-1 paired-write contracts exercised"),
    ("scanline_coherence", "run_tunit_scanline_coherence_gate.py", "PASS: scanline coherence gate"),
    ("scanline_integrated_acd", "run_tunit_scanline_integrated_tc_gate.py", "PASS: integrated TC gate"),
    ("scanline_lookahead", "run_tunit_scanline_lookahead_gate.py", "PASS: scanline lookahead gate"),
    ("scale140_rgb", "run_tunit_scale140_rgb_gate.py", "PASS: Scale140 paired pixels survive DDR-to-RGB; mutation killed"),
    ("video_pageflip", "run_tunit_video_pageflip_gate.py", "PASS: hidden pending page prewarms before atomic publication"),
    ("page_fence", "run_tunit_page_fence_gate.py", "PAGE FENCE GATE: PASS"),
    ("page_fence_blank_end", "run_tunit_page_fence_blank_end_gate.py", "PAGE FENCE BLANK-END GATE: PASS"),
    ("dma_page_kill", "run_tunit_dma_page_kill_gate.py", "PASS: T-unit DMA2 literal kill publishes page"),
    ("raster_resync", "run_tunit_raster_resync_gate.py", "RASTER RESYNC GATE: PASS"),
    ("crt_adjust", "run_tunit_crt_adjust_gate.py", "PASS: tb_tunit_crt_adjust"),
    ("adpcm_te_tune_nba_command", "run_tunit_adpcm_tune_gate.py", "ADPCM TE-TUNE/NBA-COMMAND GATE: PASS"),
    ("adpcm_reload_fixedbank", "run_tunit_adpcm_reload_gate.py", "ADPCM RELOAD INTEGRATION GATE: PASS"),
    ("mk2_dcs_pcm", "run_mk2_dcs_pcm.py", "PASS: MK2 DCS2K PCM gate"),
    ("mk2_frame_crc", "run_mk2_frame_gate.py", "PASS: MK2 frame gate"),
)
REQUIRED_GATE_NAMES = tuple(row[0] for row in REQUIRED_GATE_CONTRACT)
REQUIRED_EXPLICIT_INPUT_NAMES = (
    "dcs_rom", "dcs_wav", "mame", "mk2_frame_golden", "mk2_graphics",
    "mk2_nvram", "mk2_program", "profile_program_jdreddp", "profile_program_mk",
    "profile_program_mk2", "profile_program_nbajam", "profile_program_nbajamte",
    "rom_archive_jdreddp", "rom_archive_mk", "rom_archive_mk2",
    "rom_archive_nbajam", "rom_archive_nbajamte",
)


def resolve_input(path: Path) -> Path:
    return path if path.is_absolute() else ROOT / path


def frame_simulator_tools() -> dict[str, Path]:
    qrun = shutil.which("qrun")
    if qrun is None:
        raise ValueError("qrun is not installed or not on PATH")
    qrun_path = Path(qrun).resolve()
    suffix = qrun_path.suffix or ".exe"
    tools = {"qrun": qrun_path}
    for name in FRAME_SIMULATOR_TOOL_NAMES[1:]:
        child = qrun_path.with_name(name + suffix)
        if not child.is_file():
            raise ValueError(f"qrun toolchain is missing sibling binary: {child}")
        tools[name] = child
    return tools


def write_receipt(path: Path, receipt: dict) -> None:
    temporary = path.with_suffix(".json.tmp")
    temporary.write_text(
        json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    temporary.replace(path)


def timeout_text(value: str | bytes | None) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--label",
        default="tunit-qualification-" + datetime.now().strftime("%Y%m%d-%H%M%S"),
    )
    parser.add_argument("--mame", type=Path, required=True)
    parser.add_argument("--rom-dir", type=Path, default=DEFAULT_ROM_DIR)
    parser.add_argument("--jobs", type=int, default=4)
    parser.add_argument("--timeout", type=int, default=14_400)
    parser.add_argument("--allow-dirty", action="store_true")
    parser.add_argument("--plan", action="store_true")
    parser.add_argument("--dcs-rom", type=Path, default=Path("sim/generated/mk2_dcs_dense.bin"))
    parser.add_argument("--dcs-wav", type=Path, default=Path("sim/generated/mk2_track__01ca.wav"))
    parser.add_argument("--dcs-track", choices=("01ca",), default="01ca")
    parser.add_argument("--mk2-program", type=Path, default=Path("sim/generated/mk2_main.bin"))
    parser.add_argument("--mk2-graphics", type=Path, default=Path("sim/generated/mk2_video.bin"))
    parser.add_argument("--mk2-nvram", type=Path, default=Path("nvram/mk2/nvram"))
    parser.add_argument(
        "--mk2-frame-golden", type=Path,
        default=Path("sim/goldens/mk2_frame_crc_visible_initialized_0_310.ref"),
    )
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", args.label):
        parser.error("--label must contain only letters, digits, dot, underscore, hyphen")
    if args.jobs < 1 or args.timeout < 1:
        parser.error("--jobs and --timeout must be positive")
    if args.timeout <= FRAME_GATE_WALL_TIMEOUT + 60:
        parser.error(
            f"--timeout must exceed the MK2 frame child timeout "
            f"({FRAME_GATE_WALL_TIMEOUT}s) by more than 60 seconds"
        )
    for name in (
        "mame", "dcs_rom", "dcs_wav", "mk2_program", "mk2_graphics",
        "mk2_nvram", "mk2_frame_golden",
    ):
        setattr(args, name, resolve_input(getattr(args, name)))
    args.rom_dir = args.rom_dir.resolve()
    plan = gate_plan(args)
    plan_contract = tuple(
        (gate.name, Path(gate.command[1]).name, gate.marker) for gate in plan
    )
    if plan_contract != REQUIRED_GATE_CONTRACT:
        print("QUALIFICATION: FAIL -- internal gate plan/contract mismatch", file=sys.stderr)
        return 2
    if args.plan:
        print("PLAN ONLY -- NO QUALIFICATION RECEIPT WILL BE WRITTEN")
        for index, gate in enumerate(plan, 1):
            print(f"{index:02d} {gate.name} [{gate.evidence_class}]")
            print("   " + subprocess.list2cmdline(gate.command))
        return 0

    missing = [
        str(path) for path in (
            args.mame, args.dcs_rom, args.dcs_wav, args.mk2_program,
            args.mk2_graphics, args.mk2_nvram, args.mk2_frame_golden,
        ) if not path.is_file()
    ]
    if not args.rom_dir.is_dir():
        missing.append(str(args.rom_dir))
    if missing:
        print("QUALIFICATION: FAIL -- missing input(s): " + ", ".join(missing), file=sys.stderr)
        return 2

    dirty_text = git("status", "--porcelain")
    if dirty_text and not args.allow_dirty:
        print("QUALIFICATION: FAIL -- worktree is dirty; commit first", file=sys.stderr)
        return 2
    explicit_paths = {
        "mame": args.mame,
        "dcs_rom": args.dcs_rom,
        "dcs_wav": args.dcs_wav,
        "mk2_program": args.mk2_program,
        "mk2_graphics": args.mk2_graphics,
        "mk2_nvram": args.mk2_nvram,
        "mk2_frame_golden": args.mk2_frame_golden,
    }
    for title in ("mk", "mk2", "nbajam", "nbajamte", "jdreddp"):
        explicit_paths[f"profile_program_{title}"] = (
            ROOT / "sim" / "generated" / f"{title}_main.bin"
        )
    for archive in ("mk.zip", "mk2.zip", "nbajam.zip", "nbajamte.zip", "jdreddp.zip"):
        explicit_paths[f"rom_archive_{archive[:-4]}"] = args.rom_dir / archive
    if tuple(sorted(explicit_paths)) != REQUIRED_EXPLICIT_INPUT_NAMES:
        print("QUALIFICATION: FAIL -- explicit-input contract mismatch", file=sys.stderr)
        return 2
    missing_archives = [str(path) for path in explicit_paths.values() if not path.is_file()]
    if missing_archives:
        print(
            "QUALIFICATION: FAIL -- explicit evidence input missing: "
            + ", ".join(missing_archives), file=sys.stderr,
        )
        return 2
    try:
        simulator_tools = frame_simulator_tools()
    except ValueError as exc:
        print(f"QUALIFICATION: FAIL -- {exc}", file=sys.stderr)
        return 2
    out = ROOT / "sim" / "out" / args.label
    if out.exists():
        print(f"QUALIFICATION: FAIL -- output already exists: {out}", file=sys.stderr)
        return 2
    out.mkdir(parents=True)
    receipt_path = out / "receipt.json"
    receipt: dict = {
        "schema": 1,
        "status": "RUNNING",
        "production_build_eligible": not bool(dirty_text),
        "acceptance": "pre-Quartus candidate baseline; cabinet acceptance not implied",
        "variant": "universal",
        "source_commit": git("rev-parse", "HEAD"),
        "source_dirty": bool(dirty_text),
        "label": args.label,
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "runner_sha256": digest(Path(__file__)),
        "golden_manifest_sha256": digest(ROOT / "docs" / "goldens" / "SHA256SUMS.txt"),
        "frame_simulator_tools": {
            name: {"path": str(path), "sha256": digest(path)}
            for name, path in sorted(simulator_tools.items())
        },
        "explicit_inputs_sha256": {
            name: {"path": str(path), "sha256": digest(path)}
            for name, path in sorted(explicit_paths.items())
        },
        "gates": [],
    }
    write_receipt(receipt_path, receipt)
    for index, gate in enumerate(plan, 1):
        log_path = out / f"{index:02d}-{gate.name}.log"
        started = time.monotonic()
        try:
            result = subprocess.run(
                gate.command, cwd=ROOT, text=True, capture_output=True,
                timeout=args.timeout, errors="replace", check=False,
            )
            output = (result.stdout or "") + (result.stderr or "")
            returncode = result.returncode
        except subprocess.TimeoutExpired as exc:
            output = timeout_text(exc.stdout) + timeout_text(exc.stderr)
            output += f"\nQUALIFICATION TIMEOUT after {args.timeout}s\n"
            returncode = 124
        log_path.write_text(output, encoding="utf-8", errors="replace")
        marker_found = gate.marker in output
        script = Path(gate.command[1])
        entry = {
            "name": gate.name,
            "evidence_class": gate.evidence_class,
            "command": list(gate.command),
            "returncode": returncode,
            "required_marker": gate.marker,
            "marker_found": marker_found,
            "duration_seconds": round(time.monotonic() - started, 3),
            "script_path": str(script.relative_to(ROOT)),
            "script_sha256": digest(script),
            "log_path": str(log_path.relative_to(ROOT)),
            "log_sha256": digest(log_path),
        }
        binding_errors: list[str] = []
        if gate.name == "flatten_universal" and returncode == 0 and marker_found:
            manifest_path = ROOT / "build_syn" / "tunit_core.manifest.json"
            netlist_path = ROOT / "build_syn" / "tunit_core.v"
            try:
                metadata = json.loads(manifest_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                metadata = {}
                binding_errors.append(f"flatten manifest unreadable: {exc}")
            if metadata.get("variant") != "universal":
                binding_errors.append("flatten manifest is not universal")
            if metadata.get("extra_defines") != []:
                binding_errors.append("production flatten contains extra Verilog defines")
            if metadata.get("git_commit") != receipt["source_commit"]:
                binding_errors.append("flatten commit differs from qualification commit")
            if bool(metadata.get("git_dirty")) != receipt["source_dirty"]:
                binding_errors.append("flatten dirty state differs from qualification state")
            netlist_hash = metadata.get("netlist_sha256")
            source_hashes = metadata.get("inputs_sha256")
            if not isinstance(netlist_hash, str) or not re.fullmatch(
                r"[0-9a-f]{64}", netlist_hash
            ):
                binding_errors.append("flatten manifest has no valid netlist hash")
            elif not netlist_path.is_file() or digest(netlist_path) != netlist_hash:
                binding_errors.append("flattened netlist does not match its manifest")
            if not isinstance(source_hashes, dict) or not source_hashes:
                binding_errors.append("flatten manifest has no source-input hashes")
            if not binding_errors:
                receipt["netlist_sha256"] = netlist_hash
                receipt["source_inputs_sha256"] = source_hashes
                receipt["flatten_git_commit"] = metadata.get("git_commit")
                receipt["flatten_git_dirty"] = metadata.get("git_dirty")
        if binding_errors:
            entry["binding_errors"] = binding_errors
        receipt["gates"].append(entry)
        passed = returncode == 0 and marker_found and not binding_errors
        print(
            f"[{index:02d}/{len(plan):02d}] {'PASS' if passed else 'FAIL'} "
            f"{gate.name} rc={returncode} marker={int(marker_found)} "
            f"log={log_path.relative_to(ROOT)}",
            flush=True,
        )
        if not passed:
            receipt["status"] = "FAIL"
            receipt["failed_gate"] = gate.name
            receipt["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
            write_receipt(receipt_path, receipt)
            print(f"QUALIFICATION: FAIL -- {gate.name}; receipt={receipt_path}")
            return 1
        write_receipt(receipt_path, receipt)

    final_errors: list[str] = []
    if git("rev-parse", "HEAD") != receipt["source_commit"]:
        final_errors.append("HEAD changed while qualification was running")
    final_dirty = git("status", "--porcelain")
    if bool(final_dirty) != receipt["source_dirty"]:
        final_errors.append("worktree dirty state changed while qualification was running")
    if receipt["production_build_eligible"] and final_dirty:
        final_errors.append(
            "production-build-eligible qualification ended with a dirty worktree"
        )
    netlist_path = ROOT / "build_syn" / "tunit_core.v"
    if (
        not netlist_path.is_file()
        or digest(netlist_path) != receipt.get("netlist_sha256")
    ):
        final_errors.append("qualified flattened netlist changed during later gates")
    for name, record in receipt["explicit_inputs_sha256"].items():
        path = Path(record["path"])
        if not path.is_file() or digest(path) != record["sha256"]:
            final_errors.append(f"explicit evidence input changed during run: {name}")
    if final_errors:
        receipt["status"] = "FAIL"
        receipt["failed_gate"] = "final_binding_check"
        receipt["binding_errors"] = final_errors
        receipt["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
        write_receipt(receipt_path, receipt)
        for error in final_errors:
            print(f"QUALIFICATION: FAIL -- {error}", file=sys.stderr)
        print(f"QUALIFICATION: FAIL -- final binding; receipt={receipt_path}")
        return 1

    receipt["status"] = "PASS"
    receipt["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
    write_receipt(receipt_path, receipt)
    print(
        f"PASS: T-unit pre-Quartus candidate qualification gates={len(plan)} "
        f"commit={receipt['source_commit']} receipt={receipt_path}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
