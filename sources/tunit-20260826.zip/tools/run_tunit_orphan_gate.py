#!/usr/bin/env python3
"""Run every T-unit bench that ``run_component_suite.py`` excludes and that no
other runner owns, under free Icarus Verilog.

Background
----------
``tools/run_component_suite.py`` excludes fourteen benches. Four of them
(``tb_mister_interface``, ``tb_tunit_dma``, ``tb_tunit_dma_realgfx``,
``tb_tunit_video``) really do have dedicated runners, and two more
(``tb_tunit_adpcm_realrom``, ``tb_tunit_profile_layout``) are owned by
``run_tunit_adpcm_realrom.py`` / ``run_tunit_profile_matrix.py``. The remaining
eight had no runner anywhere in the repository: excluded from the suite and
never executed by anything else. This gate owns those eight.

Everything here runs on iverilog + vvp, so it needs no ModelSim/Questa licence
and can run in parallel with anything else.

Two iverilog limitations are handled explicitly:

``sorry: constant selects in always_* processes``
    iverilog cannot infer the sensitivity of a constant part-select inside an
    ``always_*`` block. Its own message says "all bits will be included", i.e.
    the elaborated result is not the source semantics. A bench whose compile
    log contains that message is NEVER reported as PASS from the native path;
    it is retried through sv2v, and if the message survives sv2v the bench is
    reported UNRUNNABLE.

sv2v 0.0.13 lowers ``inout`` task arguments to ``output``
    That silently drops the copy-in half of the argument, so every bit the task
    does not write comes back X. ``rtl/tunit/tunit_inputs.sv`` uses four such
    tasks. This gate repairs exactly the task-argument declarations whose names
    were declared ``inout`` in the SystemVerilog source, and refuses to run if a
    repair it expected could not be made. The repair count is printed for audit.

Mutation testing
----------------
``--mutate`` (on by default) re-runs each PASSing bench against a recorded
single-token mutation of its DUT source. The mutant must compile, run, and make
the bench FAIL. A compile failure is not a semantic kill. A mutation that
survives is reported as MUTATION-SURVIVED and fails the gate: a bench that
cannot detect a deliberate misreading of its DUT is not verification.

Usage
-----
    python tools/run_tunit_orphan_gate.py
    python tools/run_tunit_orphan_gate.py --no-mutate --label quick

The release ``ORPHAN GATE: PASS`` marker is printed only when at least one
selected bench ran and every selected bench is PASS-with-killed-mutation.
``--no-mutate`` may return zero as a smoke test but never prints that release
marker. UNRUNNABLE is deliberately a failure: a bench that could not compile or
simulate verified nothing.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from datetime import datetime
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SV2V = Path(r"C:\tools\sv2v\sv2v-Windows\sv2v.exe")

CONST_SELECT_MARKER = "constant selects in always_* processes"
FATAL_MARKERS = ("** Fatal:", "Fatal [", "FATAL:", "TEST_RESULT: FAIL", "FAIL ")


@dataclass(frozen=True)
class Bench:
    """One orphaned bench, its DUT source list, and its recorded mutation."""

    name: str
    #: RTL/model sources, compile order significant (packages first).
    sources: tuple[str, ...]
    #: Extra -y library directories (vendor cores resolved by module name).
    libdirs: tuple[str, ...] = ()
    #: (source, exact-substring, replacement) applied for --mutate.
    mutation: tuple[str, str, str] | None = None
    #: What the mutation deliberately misreads, for the log.
    mutation_note: str = ""
    #: Exact bench witness required before the mutation is credited as killed.
    mutation_fail_marker: str = ""


BENCHES: tuple[Bench, ...] = (
    Bench(
        name="tb_tunit_sound_cdc",
        sources=("rtl/tunit/tunit_sound_cdc.sv",),
        mutation=(
            "rtl/tunit/tunit_sound_cdc.sv",
            "if (queued_valid) overflow_sticky <= 1'b1;",
            "if (queued_valid) overflow_sticky <= 1'b0;",
        ),
        mutation_note="drop the sticky overflow flag on a third pending command",
        mutation_fail_marker="overflow/latest policy overflow=",
    ),
    Bench(
        name="tb_tunit_adpcm_host",
        sources=("rtl/tunit/tunit_adpcm_host.sv",),
        mutation=(
            "rtl/tunit/tunit_adpcm_host.sv",
            "data_wr && data_offset && (byte_en == 2'b11);",
            "data_wr && data_offset && (byte_en != 2'b00);",
        ),
        mutation_note="accept partial-word sound writes MAME ignores",
        mutation_fail_marker="invalid writes were accepted",
    ),
    Bench(
        name="tb_tunit_adpcm_rom_cdc",
        sources=("rtl/tunit/tunit_adpcm_rom_cdc.sv",),
        mutation=(
            "rtl/tunit/tunit_adpcm_rom_cdc.sv",
            "        line_data[fill_idx]  <= response_line;",
            "        line_data[fill_idx]  <= response_line + 64'd1;",
        ),
        # The bridge now caches 8-byte lines instead of one byte, so the old
        # "snd_data <= response_data" anchor no longer exists.  Corrupting the
        # line as it is filled is the same defect at the same seam: every byte
        # the board reads from that line comes back wrong.
        mutation_note="corrupt the line returned across the ROM handshake",
        mutation_fail_marker="read addr=",
    ),
    Bench(
        name="tb_tunit_sound_ddr_multi",
        # The DDR3 agent and the Avalon memory model are the missing source
        # dirs: rtl/sdram/ and sim/models/.
        sources=(
            "rtl/sdram/stv_vram_ddr_agent.sv",
            "rtl/tunit/tunit_sound_ddr_multi.sv",
            "sim/models/ddr3_avalon_model.sv",
        ),
        mutation=(
            "rtl/tunit/tunit_sound_ddr_multi.sv",
            "wire logic [20:0] dl_beat_adpcm = dl_addr[23:3];",
            "wire logic [20:0] dl_beat_adpcm = dl_addr[23:3] + 21'd1;",
        ),
        mutation_note="shift the ADPCM download beat address by one 64-bit beat",
        mutation_fail_marker="ADPCM byte addr=",
    ),
    Bench(
        name="tb_tunit_inputs",
        sources=("rtl/common/tunit_pkg.sv", "rtl/tunit/tunit_inputs.sv"),
        mutation=(
            "rtl/tunit/tunit_inputs.sv",
            "in1[2] = ~joy0_sync[7];",
            "in1[2] = ~joy0_sync[10];",
        ),
        mutation_note="restore the obsolete six-button Start position for NBA Jam",
        mutation_fail_marker="NBA four-player map profile=2",
    ),
    Bench(
        name="tb_tunit_inputs_mk2_equiv",
        sources=(
            "rtl/common/tunit_pkg.sv",
            "rtl/tunit/tunit_mk2_inputs.sv",
            "rtl/tunit/tunit_inputs.sv",
        ),
        mutation=(
            "rtl/tunit/tunit_mk2_inputs.sv",
            "in0[5]  = ~joy0_sync[6];",
            "in0[5]  = ~joy0_sync[5];",
        ),
        mutation_note="desynchronise the MK2 mapper from the generic mapper",
        mutation_fail_marker="MK2 mapper mismatch",
    ),
    Bench(
        name="tb_tunit_protection_all",
        sources=(
            "rtl/common/tunit_pkg.sv",
            "rtl/experimental/protection/tunit_protection_all.sv",
        ),
        mutation=(
            "rtl/experimental/protection/tunit_protection_all.sv",
            "nba_table_index = nba_offset[16:10];",
            "nba_table_index = nba_offset[15:9];",
        ),
        mutation_note="misread the NBA Jam protection table address stride",
        mutation_fail_marker="FAIL read addr=01b2503f",
    ),
    Bench(
        name="tb_tunit_adpcm_board",
        # The missing source dirs: the three vendor cores the board instantiates
        # (mc6809is / jt51 / jt6295) plus their sub-modules, resolved by -y.
        # tunit_audio_telemetry is a direct instance in the board since the
        # 2026-08-09 diag work, so it belongs in the explicit source list -- the
        # board went UNRUNNABLE here the moment it was added and not listed.
        sources=(
            "rtl/diag/tunit_audio_telemetry.sv",
            "rtl/experimental/adpcm/tunit_adpcm_board.sv",
        ),
        libdirs=(
            "rtl/vendor/mc6809",
            "rtl/vendor/jt51/hdl",
            "rtl/vendor/jt51/hdl/filter",
            "rtl/vendor/jt6295/src",
        ),
        mutation=(
            "rtl/experimental/adpcm/tunit_adpcm_board.sv",
            "hidden_hit = (cpu_addr >= 16'hfb9c) && (cpu_addr <= 16'hfbc6);",
            "hidden_hit = (cpu_addr >= 16'hfb9c) && (cpu_addr <= 16'hfbc5);",
        ),
        mutation_note="shorten the MK 43-byte hidden-RAM overlay by one byte",
        mutation_fail_marker="FAIL: MK1 hidden last-byte read/write",
    ),
)


@dataclass
class Outcome:
    name: str
    status: str  # PASS | FAIL | UNRUNNABLE | MUTATION-SURVIVED
    detail: str
    mode: str = "native"
    repairs: int = 0
    result_line: str = ""
    mutation_status: str = "not-run"
    log_paths: list[Path] = field(default_factory=list)


def run_split(command: list[str], timeout: int) -> tuple[int, str, str]:
    try:
        proc = subprocess.run(
            command, cwd=ROOT, text=True, capture_output=True,
            timeout=timeout, errors="replace",
        )
    except subprocess.TimeoutExpired:
        return 124, "", f"TIMEOUT after {timeout}s: {' '.join(command)}\n"
    return proc.returncode, (proc.stdout or ""), (proc.stderr or "")


def run(command: list[str], timeout: int) -> tuple[int, str]:
    code, out, err = run_split(command, timeout)
    return code, out + err


# --------------------------------------------------------------------------
# sv2v fallback + the inout-task-argument repair
# --------------------------------------------------------------------------

_TASK_ARG_INOUT = re.compile(
    r"^\s*inout\s+(?:var\s+)?(?:logic|reg|wire|bit|integer|int)?\s*"
    r"(?:\[[^\]]*\]\s*)?([A-Za-z_][A-Za-z_0-9]*)\s*[,)]",
    re.MULTILINE,
)


def inout_task_args(sv_sources: list[Path]) -> set[str]:
    """Names declared ``inout`` inside a task/function header in the SV source.

    Only headers are scanned: an ``inout`` module port lives on a different
    line shape (it is followed by more ports and never by ``);`` of a task),
    but to stay conservative the scan is restricted to the text between a
    ``task``/``function`` keyword and its closing ``);``.
    """
    names: set[str] = set()
    header = re.compile(
        r"\b(?:task|function)\b[^;]*?;", re.DOTALL,
    )
    for source in sv_sources:
        text = source.read_text(encoding="utf-8", errors="replace")
        for match in header.finditer(text):
            for arg in _TASK_ARG_INOUT.finditer(match.group(0)):
                names.add(arg.group(1))
    return names


_SV2V_TASK_OUTPUT = re.compile(
    r"^(\s*)output(\s+(?:reg|wire)?\s*(?:\[[^\]]*\]\s*)?)"
    r"([A-Za-z_][A-Za-z_0-9]*)\s*;\s*$"
)


def repair_inout_task_args(verilog: str, names: set[str]) -> tuple[str, int]:
    """Undo sv2v 0.0.13's ``inout`` task argument -> ``output`` lowering.

    Only declarations textually inside a ``task ... endtask`` block whose
    identifier was declared ``inout`` in the SystemVerilog source are touched.
    """
    if not names:
        return verilog, 0
    out: list[str] = []
    depth = 0
    repairs = 0
    for line in verilog.splitlines(keepends=True):
        stripped = line.strip()
        if re.match(r"^task\b", stripped):
            depth += 1
        elif stripped.startswith("endtask"):
            depth = max(0, depth - 1)
        elif depth:
            match = _SV2V_TASK_OUTPUT.match(line.rstrip("\r\n"))
            if match and match.group(3) in names:
                newline = line[len(line.rstrip("\r\n")):]
                line = f"{match.group(1)}inout{match.group(2)}{match.group(3)};{newline}"
                repairs += 1
        out.append(line)
    return "".join(out), repairs


def sv2v_path() -> Path | None:
    candidate = Path(os.environ.get("SV2V", DEFAULT_SV2V))
    if candidate.is_file():
        return candidate
    found = shutil.which("sv2v")
    return Path(found) if found else None


# --------------------------------------------------------------------------
# build + run
# --------------------------------------------------------------------------

def compile_native(
    bench: Bench, sources: list[Path], work: Path, timeout: int
) -> tuple[Path | None, str]:
    vvp_out = work / f"{bench.name}.vvp"
    command = ["iverilog", "-g2012", "-s", bench.name, "-o", str(vvp_out)]
    for libdir in bench.libdirs:
        command += ["-y", str(ROOT / libdir)]
    command += [str(path) for path in sources]
    code, log = run(command, timeout)
    if code != 0:
        return None, log
    return vvp_out, log


def compile_via_sv2v(
    bench: Bench, sources: list[Path], work: Path, timeout: int
) -> tuple[Path | None, str, int]:
    sv2v = sv2v_path()
    if sv2v is None:
        return None, "sv2v not found (set SV2V to the executable)\n", 0

    sv_sources = [path for path in sources if path.suffix == ".sv"]
    v_sources = [path for path in sources if path.suffix != ".sv"]
    code, stdout, stderr = run_split(
        [str(sv2v), *(str(path) for path in sv_sources)], timeout
    )
    if code != 0:
        return None, "sv2v failed:\n" + stdout + stderr, 0
    converted = work / f"{bench.name}.sv2v.v"
    names = inout_task_args(sv_sources)
    repaired, repairs = repair_inout_task_args(stdout, names)
    converted.write_text(repaired, encoding="utf-8")
    if names and repairs == 0:
        return (
            None,
            "sv2v repair expected inout task args "
            + ", ".join(sorted(names))
            + " but made none\n",
            0,
        )

    vvp_out = work / f"{bench.name}.vvp"
    command = ["iverilog", "-g2012", "-s", bench.name, "-o", str(vvp_out)]
    for libdir in bench.libdirs:
        command += ["-y", str(ROOT / libdir)]
    command += [str(converted), *(str(path) for path in v_sources)]
    code, ilog = run(command, timeout)
    if code != 0:
        return None, ilog, repairs
    return vvp_out, ilog, repairs


def build(
    bench: Bench, sources: list[Path], work: Path, timeout: int
) -> tuple[Path | None, str, str, int]:
    """Return (vvp, mode, log, repairs). mode is native / sv2v / unrunnable."""
    work.mkdir(parents=True, exist_ok=True)
    vvp, log = compile_native(bench, sources, work, timeout)
    if vvp is not None and CONST_SELECT_MARKER not in log:
        return vvp, "native", log, 0
    native_log = log
    vvp, log, repairs = compile_via_sv2v(bench, sources, work, timeout)
    if vvp is None:
        return None, "unrunnable", native_log + "\n--- sv2v ---\n" + log, repairs
    if CONST_SELECT_MARKER in log:
        return None, "unrunnable", native_log + "\n--- sv2v ---\n" + log, repairs
    return vvp, "sv2v", native_log + "\n--- sv2v ---\n" + log, repairs


def simulate(bench: Bench, vvp: Path, timeout: int) -> tuple[bool, str, str, int]:
    code, log = run(["vvp", str(vvp)], timeout)
    pass_line = ""
    for line in log.splitlines():
        if line.startswith(f"PASS {bench.name}") or "TEST_RESULT: PASS" in line:
            pass_line = line.strip()
            break
    ok = (
        code == 0
        and pass_line != ""
        and not any(marker in log for marker in FATAL_MARKERS)
    )
    return ok, pass_line, log, code


def controlled_mutant_failure(mode: str, code: int, log: str) -> bool:
    """Recognize a semantic bench failure without crediting crashes/timeouts.

    Native Icarus returns 1 for ``$fatal``. sv2v 0.0.13 lowers the same call to
    ``$finish(1)``; the installed vvp logs both the structured ``Fatal [...]``
    record and ``$finish(1) called`` but exits 0. Accept only that exact
    translation signature for the sv2v path. The caller still requires the
    bench-specific failure witness and forbids a PASS marker.
    """
    if code == 1:
        return True
    return (
        mode == "sv2v"
        and code == 0
        and "Fatal [" in log
        and "$finish(1) called" in log
    )


def staged_sources(bench: Bench, work: Path, mutate: bool) -> list[Path]:
    """Absolute source paths, with the recorded mutation applied under work/."""
    sources = [ROOT / rel for rel in bench.sources] + [
        ROOT / "sim" / f"{bench.name}.sv"
    ]
    if not mutate or bench.mutation is None:
        return sources
    rel, old, new = bench.mutation
    target = ROOT / rel
    text = target.read_text(encoding="utf-8")
    if text.count(old) != 1:
        raise SystemExit(
            f"ERROR: mutation anchor for {bench.name} matches "
            f"{text.count(old)} times in {rel} (must be exactly 1)"
        )
    staged = work / Path(rel).name
    staged.parent.mkdir(parents=True, exist_ok=True)
    staged.write_text(text.replace(old, new), encoding="utf-8")
    return [staged if path == target else path for path in sources]


def run_bench(bench: Bench, out: Path, timeout: int, mutate: bool) -> Outcome:
    work = out / bench.name
    work.mkdir(parents=True, exist_ok=True)

    sources = staged_sources(bench, work, mutate=False)
    missing = [str(path) for path in sources if not path.is_file()]
    if missing:
        return Outcome(bench.name, "UNRUNNABLE", "missing source: " + ", ".join(missing))

    vvp, mode, build_log, repairs = build(bench, sources, work, timeout)
    (work / "build.log").write_text(build_log, encoding="utf-8", errors="replace")
    if vvp is None:
        reason = (
            "iverilog reports 'sorry: constant selects' and sv2v could not "
            "produce a faithful translation"
            if CONST_SELECT_MARKER in build_log
            else "compile failed; see build.log"
        )
        return Outcome(bench.name, "UNRUNNABLE", reason, mode, repairs)

    ok, pass_line, sim_log, _ = simulate(bench, vvp, timeout)
    (work / "sim.log").write_text(sim_log, encoding="utf-8", errors="replace")
    if not ok:
        return Outcome(
            bench.name, "FAIL", "bench did not report PASS; see sim.log",
            mode, repairs,
        )

    outcome = Outcome(
        bench.name, "PASS", "", mode, repairs, result_line=pass_line
    )
    if not mutate:
        outcome.mutation_status = "skipped"
        return outcome
    if bench.mutation is None:
        outcome.status = "UNRUNNABLE"
        outcome.detail = "no recorded mutation; an unmutated PASS is not verification"
        return outcome

    mwork = work / "mutant"
    mwork.mkdir(parents=True, exist_ok=True)
    msources = staged_sources(bench, mwork, mutate=True)
    mvvp, mmode, mbuild, _ = build(bench, msources, mwork, timeout)
    (mwork / "build.log").write_text(mbuild, encoding="utf-8", errors="replace")
    if mvvp is None:
        outcome.status = "UNRUNNABLE"
        outcome.detail = (
            "mutant did not compile; compile rejection is not a semantic kill"
        )
        outcome.mutation_status = "invalid-compile"
        return outcome
    mok, mpass_line, mlog, mcode = simulate(bench, mvvp, timeout)
    (mwork / "sim.log").write_text(mlog, encoding="utf-8", errors="replace")
    if mok:
        outcome.status = "MUTATION-SURVIVED"
        outcome.detail = f"mutation ({bench.mutation_note}) did not fail the bench"
        outcome.mutation_status = "SURVIVED"
        return outcome
    if (
        not controlled_mutant_failure(mmode, mcode, mlog)
        or not bench.mutation_fail_marker
        or bench.mutation_fail_marker not in mlog
        or mpass_line != ""
    ):
        outcome.status = "UNRUNNABLE"
        outcome.detail = (
            "mutant did not reach its exact functional FAIL witness; "
            "a controlled native fatal or exact sv2v $finish(1) signature is "
            "required, so timeout/crash/unrelated assertion is not a kill"
        )
        outcome.mutation_status = "invalid-runtime"
        return outcome
    outcome.mutation_status = "killed"
    return outcome


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument(
        "--label", default="orphan-" + datetime.now().strftime("%Y%m%d-%H%M%S")
    )
    parser.add_argument("--timeout", type=int, default=900)
    parser.add_argument("--only", action="append", default=[])
    parser.add_argument(
        "--no-mutate", dest="mutate", action="store_false",
        help="skip mutation testing (records mutation_status=skipped)",
    )
    args = parser.parse_args()

    for tool in ("iverilog", "vvp"):
        if shutil.which(tool) is None:
            print(f"ERROR: {tool} not on PATH", file=sys.stderr)
            return 2

    selected = [b for b in BENCHES if not args.only or b.name in args.only]
    if not selected:
        print("ERROR: no benches selected", file=sys.stderr)
        return 2

    out = ROOT / "sim" / "out" / args.label
    out.mkdir(parents=True, exist_ok=True)

    print(f"ORPHAN GATE: {len(selected)} runner-less benches, iverilog only")
    print(f"  label={args.label} mutate={args.mutate}")
    outcomes: list[Outcome] = []
    for index, bench in enumerate(selected, 1):
        outcome = run_bench(bench, out, args.timeout, args.mutate)
        outcomes.append(outcome)
        extra = f" mode={outcome.mode}"
        if outcome.repairs:
            extra += f" sv2v-inout-repairs={outcome.repairs}"
        extra += f" mutation={outcome.mutation_status}"
        line = f"[{index}/{len(selected)}] {outcome.status} {outcome.name}{extra}"
        if outcome.detail:
            line += f" :: {outcome.detail}"
        print(line, flush=True)
        if outcome.result_line:
            print(f"        {outcome.result_line}", flush=True)

    ok = [o for o in outcomes if o.status == "PASS"]
    unrunnable = [o for o in outcomes if o.status == "UNRUNNABLE"]
    bad = [o for o in outcomes if o.status in ("FAIL", "MUTATION-SURVIVED")]

    summary = (
        f"selected={len(selected)} pass={len(ok)} "
        f"unrunnable={len(unrunnable)} failed={len(bad)}"
    )
    (out / "summary.txt").write_text(
        summary
        + "\n"
        + "\n".join(
            f"{o.status}\t{o.name}\tmode={o.mode}\tmutation={o.mutation_status}\t{o.detail}"
            for o in outcomes
        )
        + "\n",
        encoding="utf-8",
    )
    print(summary)
    if bad:
        print("ORPHAN GATE: FAIL (" + ", ".join(o.name for o in bad) + ")")
        return 1
    # Fail closed.  This guard was accidentally deleted while removing the two
    # retired sound-on-SDRAM benches in ae80942, reopening the exact false-green
    # it had been added to prevent: 0 PASS, 1 UNRUNNABLE, exit 0.  Tool failure
    # is absence of evidence, never a passing verification result.
    if unrunnable:
        print(
            "ORPHAN GATE: FAIL -- UNRUNNABLE bench(es), which verify NOTHING: "
            + ", ".join(f"{o.name} ({o.detail})" for o in unrunnable)
        )
        return 1
    if not ok:
        print(
            "ORPHAN GATE: FAIL -- no bench ran; a selection that exercises "
            "nothing is not a pass"
        )
        return 1
    if not args.mutate:
        print(
            "ORPHAN GATE: SMOKE ONLY -- stock benches passed but mutations "
            "were not run; this is not a qualification verdict"
        )
        return 0
    print(
        "ORPHAN GATE: PASS ("
        f"{len(ok)} benches PASS with mutation killed, "
        f"{len(unrunnable)} UNRUNNABLE)"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
