#!/usr/bin/env python3
"""Prove fenced T-unit page publication through the complete RGB path."""

from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
SOURCES = (
    "rtl/common/tunit_pkg.sv",
    "rtl/sdram/vram_sdram.sv",
    "rtl/sdram/vram_sdram_top.sv",
    "rtl/sdram/stv_vram_ddr_agent.sv",
    "rtl/sdram/stv_vram_ddr_top.sv",
    "rtl/tunit/tunit_page_fence.sv",
    "rtl/tunit/tunit_scanline.sv",
    "rtl/tunit/tunit_video.sv",
    "rtl/tunit/tunit_video_top.sv",
    "sim/models/ddr3_avalon_model.sv",
    "sim/tb_tunit_video_ddr_pageflip.sv",
)
PASS_MARKER = (
    "PASS tb_tunit_video_ddr_pageflip pending-prewarm RGB red-steady-retain-green "
    "pixels=1740 underruns_delta=0 startup=0 underrun_black=1 "
    "valid_palette0=blue"
)
LATE_MARKER = "late DPYADR escaped without page publication"
IN_WINDOW_MARKER = "in-window pending page escaped before publication"
S10_MARKER = "pending page published before first rows were cache-ready"
PALETTE0_MARKER = "scan-cache underrun leaked palette zero"
CASES = (
    ("production", (), True, PASS_MARKER),
    (
        "mutation-scanmiss-palette0",
        ("MUT_TUNIT_SCANMISS_PALETTE0",),
        False,
        PALETTE0_MARKER,
    ),
    (
        "mutation-s10-no-pending-prewarm",
        ("MUT_TUNIT_NO_PENDING_PREWARM",),
        False,
        LATE_MARKER,
    ),
    (
        "mutation-no-pending-cache-warm",
        ("MUT_TUNIT_NO_PENDING_CACHE_WARM",),
        False,
        S10_MARKER,
    ),
    (
        "mutation-immediate-publication",
        ("MUT_TUNIT_IMMEDIATE_PUBLICATION",),
        False,
        IN_WINDOW_MARKER,
    ),
)


def run(command: list[str], log: Path) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(
        command, cwd=ROOT, text=True, capture_output=True, check=False
    )
    log.write_text(
        (result.stdout or "") + (result.stderr or ""),
        encoding="utf-8",
        errors="replace",
    )
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--label",
        default="tunit-video-pageflip-" + datetime.now().strftime("%Y%m%d-%H%M%S"),
    )
    args = parser.parse_args()
    out = ROOT / "sim" / "out" / args.label
    if out.exists():
        print(f"ERROR: output already exists: {out}", file=sys.stderr)
        return 2
    out.mkdir(parents=True)

    for name, defines, should_pass, marker in CASES:
        image = out / f"{name}.vvp"
        compile_result = run(
            [
                "iverilog",
                "-g2012",
                "-s",
                "tb_tunit_video_ddr_pageflip",
                *[f"-D{define}" for define in defines],
                "-o",
                str(image),
                *SOURCES,
            ],
            out / f"{name}-compile.log",
        )
        if compile_result.returncode:
            print(f"ERROR: {name} compile failed; see {out}")
            return compile_result.returncode
        simulation = run(["vvp", str(image)], out / f"{name}-sim.log")
        text = (simulation.stdout or "") + (simulation.stderr or "")
        if should_pass:
            if simulation.returncode or marker not in text:
                print(f"ERROR: production page-flip gate failed; see {out}")
                return simulation.returncode or 1
        elif simulation.returncode == 0 or marker not in text or PASS_MARKER in text:
            print(f"ERROR: {name} did not discriminate; see {out}")
            return 1
        print(f"PASS: {name} {'passes' if should_pass else 'fails'} at {marker}")

    print(
        "PASS: hidden pending page prewarms before atomic publication "
        f"({out})"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
