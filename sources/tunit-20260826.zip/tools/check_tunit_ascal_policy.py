#!/usr/bin/env python3
"""Fail closed on the T-unit core-scoped ascal A/B policy contract."""

from __future__ import annotations

import argparse
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[1]
ARTIFACT_IDS = {
    "nearest": "NBA-ASCAL-A-NEAREST",
    "bilinear": "NBA-ASCAL-B-BILINEAR",
}
SAFE_ARTIFACT_ID = re.compile(r"^[A-Z0-9][A-Z0-9._-]{0,63}$")


def require(text: str, needle: str, label: str, errors: list[str]) -> None:
    if needle not in text:
        errors.append(f"{label} missing {needle!r}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--policy", required=True, choices=("main", "nearest", "bilinear")
    )
    parser.add_argument("--artifact-id", default="")
    args = parser.parse_args()

    expected_id = ARTIFACT_IDS.get(args.policy)
    if expected_id and args.artifact_id != expected_id:
        parser.error(
            f"policy {args.policy} requires --artifact-id {expected_id}"
        )
    if not expected_id and args.artifact_id in ARTIFACT_IDS.values():
        parser.error("reserved NBA-ASCAL A/B artifact id requires its fixed policy")
    if args.artifact_id and not SAFE_ARTIFACT_ID.fullmatch(args.artifact_id):
        parser.error("--artifact-id is not a safe immutable candidate label")

    sys_top = (ROOT / "sys" / "sys_top.v").read_text(encoding="utf-8")
    ascal = (ROOT / "sys" / "ascal.vhd").read_text(encoding="utf-8")
    guard = (ROOT / "tools" / "tunit_build_guard.tcl").read_text(
        encoding="utf-8"
    )
    builder = (ROOT / "tools" / "build_tunit.sh").read_text(encoding="utf-8")
    provenance_builder = (ROOT / "tools" / "build_quartus_rtl.py").read_text(
        encoding="utf-8"
    )
    queue = (ROOT / "tools" / "run_queued_tunit_build.sh").read_text(
        encoding="utf-8"
    )
    candidate_provenance = (
        ROOT / "tools" / "verify_tunit_candidate_provenance.py"
    ).read_text(encoding="utf-8")
    finalizer = (ROOT / "tools" / "finalize_tunit_artifact.py").read_text(
        encoding="utf-8"
    )
    qsf = (ROOT / "Arcade-TUnit.qsf").read_text(encoding="utf-8")
    framework_tcl = (ROOT / "sys" / "sys.tcl").read_text(encoding="utf-8")

    errors: list[str] = []
    for needle in (
        "wire [2:0] tunit_ascal_filter_mode =",
        "`ifdef TUNIT_ASCAL_FIXED_NEAREST",
        "3'b000;",
        "`elsif TUNIT_ASCAL_FIXED_BILINEAR",
        "3'b001;",
        "{LFB_EN ? LFB_FLT : |scaler_flt, 2'b00};",
        "wire [4:0] tunit_ascal_mode = {1'b0, ~lowlat, tunit_ascal_filter_mode};",
        ".mode     (tunit_ascal_mode)",
    ):
        require(sys_top, needle, "sys/sys_top.v", errors)
    if ".mode     ({~lowlat" in sys_top:
        errors.append("sys/sys_top.v still drives the implicit-width stock mode")

    # sys/sys.tcl installs MiSTer's wall-clock build-id pre-flow.  The project
    # QSF must remove that inherited assignment after every source directive
    # and then install exactly one wrapper-pinned replacement.  Two Quartus
    # pre-flows would make A/B provenance date-dependent despite equal sources.
    require(
        framework_tcl,
        'set_global_assignment -name PRE_FLOW_SCRIPT_FILE "quartus_sh:sys/build_id.tcl"',
        "sys/sys.tcl",
        errors,
    )
    qsf_preflow_assignments = re.findall(
        r'^\s*set_global_assignment\s+-name\s+PRE_FLOW_SCRIPT_FILE\s+"([^"]+)"\s*$',
        qsf,
        flags=re.MULTILINE,
    )
    if qsf_preflow_assignments:
        errors.append(
            "Arcade-TUnit.qsf must delegate pre-flow replacement to the final sourced guard"
        )
    remove_preflow = "remove_all_global_assignments -name PRE_FLOW_SCRIPT_FILE"
    deterministic_preflow = (
        'set_global_assignment -name PRE_FLOW_SCRIPT_FILE '
        '"quartus_sh:tools/tunit_build_id.tcl"'
    )
    if guard.count(remove_preflow) != 1 or guard.count(deterministic_preflow) != 1:
        errors.append(
            "tools/tunit_build_guard.tcl must replace inherited pre-flows exactly once"
        )
    qsf_sources = re.findall(r"^source\s+(\S+)\s*$", qsf, flags=re.MULTILINE)
    if not qsf_sources or qsf_sources[-1] != "tools/tunit_build_guard.tcl":
        errors.append(
            "Arcade-TUnit.qsf must source tunit_build_guard.tcl after every framework source"
        )

    # VHDL implementation anchors: 000 is coefficient-free nearest and 001 is
    # the built-in bilinear selector.  Main-loaded coefficient RAMs are used by
    # the polyphase path selected by the OTHERS arms, not by bilinear output.
    for needle in (
        "mode      : IN unsigned(4 DOWNTO 0);",
        'WHEN "000"  => -- Nearest',
        'WHEN "001" | "010" => -- Bilinear | Sharp Bilinear',
        "o_ldw<=o_h_bil_pix;",
        "o_r<=o_v_bil_pix.r;",
        "o_h_poly_mem(to_integer(poly_a2))<=poly_tdw;",
        "o_v_poly_mem(to_integer(poly_a2))<=poly_tdw;",
    ):
        require(ascal, needle, "sys/ascal.vhd", errors)

    for needle in (
        "TUNIT_ASCAL_POLICY",
        'VERILOG_MACRO "TUNIT_ASCAL_FIXED_NEAREST=1"',
        'VERILOG_MACRO "TUNIT_ASCAL_FIXED_BILINEAR=1"',
        "NBA-ASCAL-A-NEAREST",
        "NBA-ASCAL-B-BILINEAR",
        "fixed T-unit ascal policies are engineering-only",
    ):
        require(guard, needle, "tools/tunit_build_guard.tcl", errors)
    for needle in (
        'ASCAL_POLICY="${TUNIT_ASCAL_POLICY:-main}"',
        "NBA-ASCAL-A-NEAREST",
        "NBA-ASCAL-B-BILINEAR",
        "NBA-FLASH-SRT-ORDER-DIAG",
        "check_tunit_ascal_policy.py",
        "immutable candidate path already exists",
        "engineering physical build requires an immutable TUNIT_ARTIFACT_ID",
        "verify_tunit_candidate_provenance.py",
        "reserved NBA-ASCAL artifact ID requires its matching fixed policy",
        "fixed ascal A/B policies forbid TUNIT_DIAG_BUILD",
        'COMMITTED_BUILD_DATE="$(git -C "$ROOT" show HEAD:build_id.v',
        "production TUNIT_BUILD_DATE must match committed build_id.v",
        "restore_build_id",
    ):
        require(builder, needle, "tools/build_tunit.sh", errors)
    for needle in (
        'ROOT / "sys" / "sys_top.v"',
        'ROOT / "sys" / "ascal.vhd"',
        'ROOT / "tools" / "check_tunit_ascal_policy.py"',
        'ROOT / "tools" / "verify_tunit_candidate_provenance.py"',
        '"quartus_toolchain": quartus_toolchain()',
        '"quartus_sh.exe"',
    ):
        require(
            provenance_builder,
            needle,
            "tools/build_quartus_rtl.py",
            errors,
        )
    for needle in (
        'ASCAL_POLICY="${TUNIT_ASCAL_POLICY:-main}"',
        "NBA-ASCAL-A-NEAREST",
        "NBA-ASCAL-B-BILINEAR",
        "NBA-FLASH-SRT-ORDER-DIAG",
        'TUNIT_ASCAL_POLICY="$ASCAL_POLICY" TUNIT_ARTIFACT_ID="$ARTIFACT_ID"',
        "queued engineering builds require an immutable TUNIT_ARTIFACT_ID",
        'TUNIT_AB_REFERENCE_MANIFEST="$AB_REFERENCE"',
        "immutable candidate path already exists",
        "reserved NBA-ASCAL artifact ID requires its matching fixed policy",
        "FPGA_SESSION is already owned by another caller",
        '*."$TAG".$$)',
        'TUNIT_FIFO_TICKET="$ticket"',
        'COMMITTED_BUILD_DATE="$(git -C "$ROOT" show HEAD:build_id.v',
        "production TUNIT_BUILD_DATE must match committed build_id.v",
    ):
        require(queue, needle, "tools/run_queued_tunit_build.sh", errors)
    for needle in (
        '"nearest": "NBA-ASCAL-A-NEAREST"',
        '"bilinear": "NBA-ASCAL-B-BILINEAR"',
        "NBA-FLASH-SRT-ORDER-DIAG",
        '"ascal_policy": ascal_policy',
        '"artifact_id": artifact_id or None',
        '"ab_reference_manifest": ab_reference_record',
        '"source_finalization_verification": source_finalization_verification',
        '"framework_finalization_verification": framework_finalization_verification',
        'ROOT / "tools" / "verify_framework_snapshot.py"',
        '"quartus_toolchain": provenance.get("quartus_toolchain")',
        '"source_provenance_manifest_sha256": os.environ.get(',
        "engineering artifacts require an immutable TUNIT_ARTIFACT_ID",
        "reserved NBA-ASCAL A/B artifact id requires its fixed policy",
        "NBA ascal A/B policies forbid the diagnostic overlay",
        "refusing to overwrite an immutable finalized artifact/evidence path",
        'target.open("xb")',
    ):
        require(finalizer, needle, "tools/finalize_tunit_artifact.py", errors)
    for needle in (
        "ASCAL_A_REFERENCE",
        "current source",
        "current netlist",
        "current B provenance differs from A",
        "A artifact",
        "A report",
        "current B fitter seed differs from A",
        "Quartus executable identity changed after flatten",
        '"quartus_sh.exe"',
    ):
        require(
            candidate_provenance,
            needle,
            "tools/verify_tunit_candidate_provenance.py",
            errors,
        )

    if errors:
        for error in errors:
            print(f"ASCAL POLICY: FAIL -- {error}")
        return 1

    mode = {"main": "Main-owned nearest/polyphase", "nearest": "000 built-in", "bilinear": "001 built-in"}[args.policy]
    print(
        "ASCAL POLICY: PASS "
        f"policy={args.policy} mode={mode} "
        f"artifact_id={args.artifact_id or 'canonical'}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
