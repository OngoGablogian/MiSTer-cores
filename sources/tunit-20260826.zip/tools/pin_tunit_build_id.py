#!/usr/bin/env python3
"""Pin build_id.v to the wrapper-owned YYMMDD value before provenance."""

from __future__ import annotations

import argparse
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "build_id.v"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", required=True)
    args = parser.parse_args()
    if not re.fullmatch(r"[0-9]{6}", args.date):
        parser.error("--date must be exactly six decimal YYMMDD digits")
    # Match the tracked file byte-for-byte.  Omitting the final newline made a
    # production build dirty its own qualified source tree before provenance
    # verification, even when the requested date was already committed.
    expected = f'`define BUILD_DATE "{args.date}"\n'
    if not TARGET.is_file() or TARGET.read_text(encoding="utf-8") != expected:
        TARGET.write_text(expected, encoding="utf-8")
    if TARGET.read_text(encoding="utf-8") != expected:
        raise SystemExit("build_id.v did not retain the pinned build date")
    print(f"BUILD ID: PASS date={args.date} path={TARGET.name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
