#!/usr/bin/env python3
"""Run the TE MAME-matched YM stream, NBA AA delivery, and two kill controls.

This is a focused Icarus gate; it never invokes Quartus.  ROM archive members
are CRC/size verified by run_tunit_adpcm_realrom before any simulation starts.
"""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

from run_tunit_adpcm_realrom import PROFILES, build_image


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_ROM_DIR = Path(r"D:\deck\fpga\tunit\mk2\roms")
DEFAULT_SV2V = Path(r"C:\tools\sv2v\sv2v-Windows\sv2v.exe")
BOARD = ROOT / "rtl" / "experimental" / "adpcm" / "tunit_adpcm_board.sv"
CDC = ROOT / "rtl" / "tunit" / "tunit_adpcm_rom_cdc.sv"
HOST = ROOT / "rtl" / "tunit" / "tunit_adpcm_host.sv"
SOUND_CDC = ROOT / "rtl" / "tunit" / "tunit_sound_cdc.sv"
BENCH = ROOT / "sim" / "tb_tunit_adpcm_tune_pace.sv"
YM_GOLDEN = ROOT / "docs" / "goldens" / "nbajamte_ym92_mame0280.json"
COMMAND_GOLDENS = {
    "nbajam": ROOT / "docs" / "goldens" / "nbajam_cmds.txt",
    "nbajamte": ROOT / "docs" / "goldens" / "nbajamte_cmds.txt",
}
JT6295_DIR = ROOT / "rtl" / "vendor" / "jt6295" / "src"


@dataclass(frozen=True)
class Game:
    name: str
    profile: int
    command: int
    boot_cycles: int
    tune_cycles: int
    claim: str


# Exact host bytes from the pinned MAME 0.289 command timelines.  TE's first 92
# occurs 0.157065 s after reset release, hence its cycle-derived boot delay.
# NBA's first AA occurs 22.855 s into attract after another reset/command pair;
# reproducing that complete wall-time state in interpreted RTL is deliberately
# not claimed.  Its leg is an isolated post-init AA command probe.
GAMES = (
    Game("nbajam", 2, 0xAA, 1_250_000, 500_000,
         "isolated post-init AA command delivery"),
    Game("nbajamte", 3, 0x92, 1_884_780, 527_469,
         "MAME-matched post-FF92 YM tune stream"),
)
COMMAND_GOLDEN_ROWS = {
    "nbajam": "W t=22.855506 f=1250 data=FFAA ",
    "nbajamte": "W t=0.157116 f=8 data=FF92 ",
}
MUTANTS = {
    "eager-stall-revert": (
        ("MUT_TUNIT_EAGER_STALL",),
        "FAIL: eager-stall banked-read phase",
    ),
    "no-fixed-bank-revert": (
        ("MUT_TUNIT_NO_FIXED_BANK",),
        "FAIL: fixed-window external demand",
    ),
}


def run(command: list[str], timeout: int, cwd: Path = ROOT) -> tuple[int, str]:
    try:
        result = subprocess.run(
            command,
            cwd=cwd,
            text=True,
            capture_output=True,
            timeout=timeout,
            errors="replace",
        )
    except subprocess.TimeoutExpired as exc:
        return 124, (exc.stdout or "") + (exc.stderr or "") + f"\nTIMEOUT {timeout}s\n"
    return result.returncode, (result.stdout or "") + (result.stderr or "")


def vendor_sources() -> list[Path]:
    return (
        [ROOT / "rtl" / "vendor" / "mc6809" / "mc6809is.v"]
        + sorted((ROOT / "rtl" / "vendor" / "jt51" / "hdl").glob("*.v"))
        + sorted((ROOT / "rtl" / "vendor" / "jt6295" / "src").glob("*.v"))
    )


def build_vvp(
    work: Path,
    iverilog: str,
    sv2v: str,
    timeout: int,
    defines: tuple[str, ...],
) -> tuple[Path | None, str]:
    work.mkdir(parents=True, exist_ok=True)
    converted = work / "tb_tunit_adpcm_tune_pace.sv2v.v"
    sv2v_command = [sv2v]
    for define in defines:
        sv2v_command += ["-D", define]
    sv2v_command += [
        f"--write={converted}", str(HOST), str(SOUND_CDC), str(BOARD),
        str(CDC), str(BENCH),
    ]
    code, convert_log = run(sv2v_command, timeout)
    if code:
        (work / "build.log").write_text(convert_log, encoding="utf-8", errors="replace")
        return None, convert_log

    executable = work / "tb_tunit_adpcm_tune_pace.vvp"
    compile_command = [
        iverilog,
        "-g2012",
        "-s",
        "tb_tunit_adpcm_tune_pace",
        "-o",
        str(executable),
        *(str(path) for path in vendor_sources()),
        str(converted),
    ]
    code, compile_log = run(compile_command, timeout)
    log = convert_log + compile_log
    (work / "build.log").write_text(log, encoding="utf-8", errors="replace")
    return (executable if code == 0 else None), log


def evidence(log: str) -> list[str]:
    prefixes = ("EVIDENCE_", "PASS ", "FAIL:", "Fatal")
    return [line for line in log.splitlines() if line.startswith(prefixes)]


YM_ROW = re.compile(
    r"EVIDENCE_YM timer_total=(?P<total10>\d+)/(?P<total11>\d+)/(?P<total14>\d+) "
    r"timer_probe=(?P<timer10>\d+)/(?P<timer11>\d+)/(?P<timer14>\d+) "
    r"ym_data=(?P<ym_data>\d+) key_on=(?P<key_on>\d+) "
    r"key_off=(?P<key_off>\d+) pitch=(?P<pitch>\d+) "
    r"firq_edges=(?P<firq_edges>\d+) firq_vec=(?P<firq_vec>\d+)"
)
PATH_ROW = re.compile(r"EVIDENCE_PATH command_reads=(?P<command_reads>\d+)")


def te_oracle_match(log: str, golden: dict[str, object]) -> tuple[bool, str]:
    """Compare the TE leg to an independently captured equal-duration MAME run."""
    ym_match = YM_ROW.search(log)
    path_match = PATH_ROW.search(log)
    if ym_match is None or path_match is None:
        return False, "missing parseable YM/path evidence"
    got = {key: int(value) for key, value in ym_match.groupdict().items()}
    got["command_reads"] = int(path_match.group("command_reads"))
    tolerance = int(golden["count_tolerance"])
    ranged = {
        "ym_data": "ym_data_writes",
        "timer14": "timer14_writes",
        "firq_vec": "firq_vectors",
    }
    failures: list[str] = []
    for observed, expected_key in ranged.items():
        expected = int(golden[expected_key])
        if abs(got[observed] - expected) > tolerance:
            failures.append(
                f"{observed}={got[observed]} expected={expected}+/-{tolerance}"
            )
    exact = {
        "command_reads": "command_reads",
        "key_on": "key_on_writes",
        "key_off": "key_off_writes",
        "pitch": "pitch_writes",
        "timer10": "timer10_writes",
        "timer11": "timer11_writes",
    }
    for observed, expected_key in exact.items():
        expected = int(golden[expected_key])
        if got[observed] != expected:
            failures.append(f"{observed}={got[observed]} expected={expected}")
    return not failures, "; ".join(failures) if failures else "equal-duration MAME YM counts matched"


def run_leg(
    game: Game,
    kind: str,
    executable: Path,
    vvp: str,
    rom: Path,
    work: Path,
    timeout: int,
    sys_lat: int,
    boot: int,
    tune: int,
    min_rate: int,
    ym_golden: dict[str, object],
) -> dict[str, object]:
    command = [
        vvp,
        str(executable),
        f"+ROM_BIN={rom}",
        f"+PROFILE={game.profile}",
        f"+SYS_LAT={sys_lat}",
        f"+BOOT={game.boot_cycles if boot < 0 else boot}",
        f"+COMMAND={game.command:02x}",
        f"+TUNE={game.tune_cycles if tune < 0 else tune}",
        f"+MIN_RATE_PCT={min_rate}",
    ]
    code, log = run(command, timeout, cwd=JT6295_DIR)
    stem = f"{game.name}-{kind}"
    (work / f"{stem}.command.txt").write_text(
        subprocess.list2cmdline(command) + "\n", encoding="utf-8"
    )
    (work / f"{stem}.log").write_text(log, encoding="utf-8", errors="replace")

    pass_marker = f"PASS tb_tunit_adpcm_tune_pace profile={game.profile}"
    if kind == "stock":
        passed = code == 0 and pass_marker in log and "FAIL:" not in log
        if passed and game.name == "nbajamte":
            matched, oracle_detail = te_oracle_match(log, ym_golden)
            passed = matched
            detail = oracle_detail
        elif passed:
            detail = game.claim + " passed (not a tune-state claim)"
        else:
            detail = "stock command/YM leg failed"
    else:
        required = MUTANTS[kind][1]
        # Icarus/vvp on Windows prints the fatal and executes $finish(1), but
        # some builds still return process status 0.  Require the exact
        # behavioural failure marker plus the simulator's Fatal receipt; a
        # compile failure is already rejected above and cannot count as a kill.
        passed = required in log and "Fatal" in log and pass_marker not in log
        detail = (
            f"killed by required marker: {required}"
            if passed
            else f"mutation did not fail for required marker: {required}"
        )
    return {
        "game": game.name,
        "profile": game.profile,
        "kind": kind,
        "passed": passed,
        "returncode": code,
        "detail": detail,
        "evidence": evidence(log),
    }


def run_phase_leg(
    kind: str,
    executable: Path,
    vvp: str,
    work: Path,
    timeout: int,
) -> dict[str, object]:
    command = [vvp, str(executable), "+PHASE_ONLY=1"]
    code, log = run(command, timeout, cwd=JT6295_DIR)
    stem = f"banked-phase-{kind}"
    (work / f"{stem}.command.txt").write_text(
        subprocess.list2cmdline(command) + "\n", encoding="utf-8"
    )
    (work / f"{stem}.log").write_text(log, encoding="utf-8", errors="replace")
    pass_marker = "PASS tb_tunit_adpcm_tune_pace banked_phase"
    if kind == "stock":
        passed = code == 0 and pass_marker in log and "FAIL:" not in log
        detail = "banked-read miss preserved the six-clock E phase"
    else:
        required = MUTANTS[kind][1]
        passed = required in log and "Fatal" in log and pass_marker not in log
        detail = (
            f"killed by required marker: {required}" if passed else
            f"mutation did not fail for required marker: {required}"
        )
    return {
        "game": "banked-phase",
        "profile": -1,
        "kind": kind,
        "passed": passed,
        "detail": detail,
        "evidence": evidence(log),
        "log": str((work / f"{stem}.log").relative_to(ROOT)).replace("\\", "/"),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--rom-dir", type=Path, default=DEFAULT_ROM_DIR)
    parser.add_argument(
        "--label",
        default="adpcm-auth-tune-" + datetime.now().strftime("%Y%m%d-%H%M%S"),
    )
    parser.add_argument("--timeout", type=int, default=900)
    parser.add_argument("--jobs", type=int, default=2)
    parser.add_argument("--sys-lat", type=int, default=48)
    parser.add_argument(
        "--boot",
        type=int,
        default=-1,
        help="override per-title boot delay (negative uses the pinned defaults)",
    )
    parser.add_argument(
        "--tune", type=int, default=-1,
        help="override per-title window (negative uses equal-duration defaults)",
    )
    parser.add_argument("--min-rate", type=int, default=95)
    parser.add_argument("--no-mutate", action="store_true")
    parser.add_argument(
        "--only-kind",
        choices=("stock", *MUTANTS),
        help="calibration/debug: run one compiled leg; the release gate omits this",
    )
    args = parser.parse_args()

    try:
        ym_golden = json.loads(YM_GOLDEN.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: cannot load TE YM golden: {exc}", file=sys.stderr)
        return 2
    if (ym_golden.get("target_host_word") != "0xFF92" or
            int(ym_golden.get("sound_clocks_at_12mhz", -1)) != 527_469):
        print("ERROR: TE YM golden identity/window is malformed", file=sys.stderr)
        return 2
    for game in GAMES:
        try:
            command_rows = COMMAND_GOLDENS[game.name].read_text(
                encoding="utf-8"
            ).splitlines()
        except OSError as exc:
            print(f"ERROR: cannot load {game.name} command golden: {exc}", file=sys.stderr)
            return 2
        required_rows = (
            "W t=0.000002 f=0 data=FE00 RESET_ASSERT",
            "W t=0.000051 f=0 data=FF00 ",
            COMMAND_GOLDEN_ROWS[game.name],
        )
        if any(row not in command_rows for row in required_rows):
            print(
                f"ERROR: {game.name} command golden lacks the pinned "
                "FE00/FF00/target sequence",
                file=sys.stderr,
            )
            return 2

    iverilog = shutil.which("iverilog")
    vvp = shutil.which("vvp")
    sv2v = str(DEFAULT_SV2V) if DEFAULT_SV2V.is_file() else shutil.which("sv2v")
    missing = [name for name, path in (("iverilog", iverilog), ("vvp", vvp), ("sv2v", sv2v)) if not path]
    if missing:
        print("ERROR: missing tool(s): " + ", ".join(missing), file=sys.stderr)
        return 2
    assert iverilog and vvp and sv2v

    out = ROOT / "sim" / "out" / args.label
    if out.exists():
        print(f"ERROR: output already exists: {out}", file=sys.stderr)
        return 2
    rom_out = out / "roms"
    rom_out.mkdir(parents=True)

    roms: dict[str, Path] = {}
    try:
        for game in GAMES:
            image = build_image(PROFILES[game.name], args.rom_dir)
            path = rom_out / f"{game.name}-adpcm-logical.bin"
            path.write_bytes(image)
            roms[game.name] = path
            reset = (image[0x3FFFE] << 8) | image[0x3FFFF]
            print(f"ROM {game.name}: CRC verified bytes=0x{len(image):x} reset={reset:04x}")
    except (OSError, RuntimeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    builds: dict[str, tuple[Path, Path]] = {}
    build_specs: list[tuple[str, tuple[str, ...]]] = [("stock", ())]
    if not args.no_mutate:
        build_specs += [(name, spec[0]) for name, spec in MUTANTS.items()]
    if args.only_kind:
        build_specs = [
            (args.only_kind, () if args.only_kind == "stock" else MUTANTS[args.only_kind][0])
        ]
    for kind, defines in build_specs:
        work = out / kind
        executable, log = build_vvp(work, iverilog, sv2v, args.timeout, defines)
        if executable is None:
            print(f"FAIL BUILD {kind}: mutation compile failures are not kills")
            print(log)
            return 1
        builds[kind] = (work, executable)

    futures = {}
    results: list[dict[str, object]] = []
    with ThreadPoolExecutor(max_workers=max(1, args.jobs)) as pool:
        for kind, (work, executable) in builds.items():
            # Eager-stall semantics are discriminated by the short, directed
            # banked-read phase leg below.  Once fixed reads became wait-free,
            # running the eager mutant through the long tunes was vacuous.
            if kind != "eager-stall-revert":
                for game in GAMES:
                    future = pool.submit(
                        run_leg,
                        game,
                        kind,
                        executable,
                        vvp,
                        roms[game.name],
                        work,
                        args.timeout,
                        args.sys_lat,
                        args.boot,
                        args.tune,
                        args.min_rate,
                        ym_golden,
                    )
                    futures[future] = (game, kind)
            if kind in ("stock", "eager-stall-revert"):
                future = pool.submit(
                    run_phase_leg, kind, executable, vvp, work, args.timeout
                )
                futures[future] = (None, kind)
        for future in as_completed(futures):
            result = future.result()
            results.append(result)
            status = "PASS" if result["passed"] else "FAIL"
            print(f"{status} {result['kind']} {result['game']}: {result['detail']}")
            for line in result["evidence"]:
                print("  " + line)

    results.sort(key=lambda item: (str(item["kind"]), int(item["profile"])))
    summary = {
        "label": args.label,
        "commands": {game.name: f"0x{game.command:02X}" for game in GAMES},
        "scope": (
            "TE replays FE00/FF00 then the MAME-timed FF92 and checks an "
            "equal-duration MAME YM stream; NBA replays FE00/FF00 but is only "
            "an isolated AA delivery probe because its 22.855 s attract state "
            "is not replayed; a separate two-clock banked-read phase leg kills "
            "the eager whole-divider stall without relying on fixed-bank waits"
        ),
        "te_ym_golden": str(YM_GOLDEN.relative_to(ROOT)).replace("\\", "/"),
        "te_ym_golden_sha256": sha256(YM_GOLDEN.read_bytes()).hexdigest(),
        "command_goldens_sha256": {
            game.name: sha256(COMMAND_GOLDENS[game.name].read_bytes()).hexdigest()
            for game in GAMES
        },
        "sys_latency_cycles": args.sys_lat,
        "minimum_6809_rate_percent": args.min_rate,
        "results": results,
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")

    if all(bool(result["passed"]) for result in results):
        if args.only_kind:
            suffix = f"calibration leg {args.only_kind}"
        else:
            suffix = ("TE tune + NBA AA delivery" if args.no_mutate else
                      "TE tune + NBA AA delivery; eager-stall and no-fixed-bank mutants killed")
        print(f"ADPCM TE-TUNE/NBA-COMMAND GATE: PASS ({suffix})")
        return 0
    print("ADPCM TE-TUNE/NBA-COMMAND GATE: FAIL")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
