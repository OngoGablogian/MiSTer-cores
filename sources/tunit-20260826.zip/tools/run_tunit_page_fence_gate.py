#!/usr/bin/env python3
"""Run the T-unit framebuffer page-publication boundary gate."""

from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    iverilog = shutil.which("iverilog")
    vvp = shutil.which("vvp")
    if not iverilog or not vvp:
        print("ERROR: iverilog/vvp not found", file=sys.stderr)
        return 2
    out = ROOT / "sim/out/tunit_page_fence.vvp"
    sources = [
        ROOT / "rtl/tunit/tunit_page_fence.sv",
        ROOT / "sim/tb_tunit_page_fence.sv",
    ]
    result = subprocess.run(
        [iverilog, "-g2012", "-s", "tb_tunit_page_fence", "-o", str(out),
         *(str(path) for path in sources)],
        cwd=ROOT, text=True, capture_output=True, check=False,
    )
    if result.returncode:
        print((result.stdout or "") + (result.stderr or ""), end="")
        return 1
    result = subprocess.run(
        [vvp, str(out)], cwd=ROOT, text=True, capture_output=True,
        timeout=30, check=False,
    )
    log = (result.stdout or "") + (result.stderr or "")
    print(log, end="")
    if result.returncode or "RESULT: PASS tunit_page_fence" not in log:
        return 1

    # The diagnostic is deliberately outside the ownership FSM, but it is part
    # of the cabinet proof contract: transient mismatch during blank is legal;
    # mismatch surviving blank end must count once and remain screen-readable.
    diag_source = ROOT / "sim/tb_tunit_page_diag.sv"
    diag_pass = "PASS tb_tunit_page_diag live-flags late-override miss-count"
    diag_kill = "PAGE_DIAG_MISS_COUNT got=0 expected=1"
    for name, defines in (("stock", ()),
                          ("no-miss-mutant", ("MUT_TUNIT_PAGE_DIAG_NO_MISS",))):
        image = ROOT / f"sim/out/tunit_page_diag_{name}.vvp"
        compile_result = subprocess.run(
            [iverilog, "-g2012", *(f"-D{item}" for item in defines),
             "-s", "tb_tunit_page_diag", "-o", str(image),
             str(sources[0]), str(diag_source)],
            cwd=ROOT, text=True, capture_output=True, check=False,
        )
        if compile_result.returncode:
            print((compile_result.stdout or "") +
                  (compile_result.stderr or ""), end="")
            return 1
        sim_result = subprocess.run(
            [vvp, "-n", str(image)], cwd=ROOT, text=True,
            capture_output=True, timeout=30, check=False,
        )
        diag_log = (sim_result.stdout or "") + (sim_result.stderr or "")
        print(diag_log, end="")
        if name == "stock":
            if sim_result.returncode or diag_pass not in diag_log:
                return 1
        elif not (sim_result.returncode == 1 and diag_kill in diag_log and
                  diag_pass not in diag_log):
            return 1

    print("PAGE FENCE GATE: PASS page-diag-mutation=killed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
