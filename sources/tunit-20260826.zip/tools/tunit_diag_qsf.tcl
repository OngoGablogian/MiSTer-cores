# Keep the cabinet overlay out of production unless the build explicitly asks
# for the diagnostic image. This file is sourced by Arcade-TUnit.qsf because a
# QSF cannot contain general Tcl control flow directly.
if {[info exists ::env(TUNIT_DIAG_BUILD)] && $::env(TUNIT_DIAG_BUILD) eq "1"} {
    set_global_assignment -name VERILOG_MACRO "TUNIT_DIAG=1"
}
