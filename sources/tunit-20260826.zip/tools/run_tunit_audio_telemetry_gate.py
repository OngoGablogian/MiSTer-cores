#!/usr/bin/env python3
"""Prove audio reset/start telemetry is windowed and kill the sticky mutant."""

from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "rtl" / "diag" / "tunit_audio_telemetry.sv"
BENCH = ROOT / "sim" / "tb_tunit_audio_telemetry.sv"
PASS_MARKER = (
    "PASS tb_tunit_audio_telemetry rates/deltas are windowed and overflow is sticky"
)
CLEAR_ANCHOR = "        reset_c <= '0; okistart_c <= '0;"
CLEAR_MUTANT = "        reset_c <= reset_c; okistart_c <= okistart_c;"


def build_and_run(source: Path, image: Path) -> tuple[int, int | None, str]:
    compile_result = subprocess.run(
        [
            "iverilog", "-g2012", "-s", "tb_tunit_audio_telemetry",
            "-o", str(image), str(source), str(BENCH),
        ],
        cwd=ROOT, text=True, capture_output=True, check=False,
    )
    compile_log = (compile_result.stdout or "") + (compile_result.stderr or "")
    if compile_result.returncode:
        return compile_result.returncode, None, compile_log
    sim_result = subprocess.run(
        ["vvp", str(image)], cwd=ROOT, text=True, capture_output=True,
        timeout=60, check=False,
    )
    return (
        compile_result.returncode,
        sim_result.returncode,
        compile_log + (sim_result.stdout or "") + (sim_result.stderr or ""),
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--label",
        default="tunit-audio-telemetry-" + datetime.now().strftime("%Y%m%d-%H%M%S"),
    )
    args = parser.parse_args()
    if not shutil.which("iverilog") or not shutil.which("vvp"):
        print("AUDIO TELEMETRY GATE: FAIL -- iverilog/vvp unavailable", file=sys.stderr)
        return 2
    out = ROOT / "sim" / "out" / args.label
    if out.exists():
        print(f"AUDIO TELEMETRY GATE: FAIL -- output exists: {out}", file=sys.stderr)
        return 2
    out.mkdir(parents=True)

    stock_compile_rc, stock_sim_rc, stock_log = build_and_run(
        SOURCE, out / "stock.vvp"
    )
    (out / "stock.log").write_text(stock_log, encoding="utf-8", errors="replace")
    if (
        stock_compile_rc
        or stock_sim_rc
        or PASS_MARKER not in stock_log
        or "FAIL " in stock_log
    ):
        print(stock_log, end="")
        print("AUDIO TELEMETRY GATE: FAIL -- stock window semantics", file=sys.stderr)
        return 1

    source_text = SOURCE.read_text(encoding="utf-8")
    if source_text.count(CLEAR_ANCHOR) != 1:
        print("AUDIO TELEMETRY GATE: FAIL -- mutation anchor is not unique", file=sys.stderr)
        return 1
    mutant = out / "tunit_audio_telemetry_sticky_mutant.sv"
    mutant.write_text(source_text.replace(CLEAR_ANCHOR, CLEAR_MUTANT), encoding="utf-8")
    mutant_compile_rc, mutant_sim_rc, mutant_log = build_and_run(
        mutant, out / "mutant.vvp"
    )
    (out / "mutant.log").write_text(mutant_log, encoding="utf-8", errors="replace")
    # A mutant that does not compile proves nothing about the bench.  Require
    # the same executable design to run and fail both newly independent window
    # assertions for the intended semantic reason.
    killed = mutant_compile_rc == 0 and mutant_sim_rc == 0 and (
        "FAIL reset_delta" in mutant_log
        and "FAIL oki_starts" in mutant_log
        and PASS_MARKER not in mutant_log
    )
    if not killed:
        print(mutant_log, end="")
        print("AUDIO TELEMETRY GATE: FAIL -- sticky since-POR mutant survived", file=sys.stderr)
        return 1
    print(
        "AUDIO TELEMETRY GATE: PASS stock window deltas exact; "
        "since-POR reset/start mutant killed"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
