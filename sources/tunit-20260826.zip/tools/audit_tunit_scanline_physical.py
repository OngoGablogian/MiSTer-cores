#!/usr/bin/env python3
"""Fail closed unless the NBA scan window is four defined packed rows.

Quartus can accept the RTL RAM shape during Analysis & Synthesis and still
discard or merge a store during fitting.  This gate reads the vendor reports
at both boundaries.  It deliberately names only the T-unit scanline hierarchy;
framework/ascal line stores are outside this experiment.
"""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
import re
import sys


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "output_files"
ROW_NAME = re.compile(
    r"tunit_video_top:scanout\|tunit_scanline:lines\|"
    r"altsyncram:line([0-3])_rtl_0\|.*\|ALTSYNCRAM"
)


def refuse(message: str) -> int:
    print(f"SCANLINE PHYSICAL GATE: BLOCKED -- {message}", file=sys.stderr)
    return 1


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_table_rows(text: str) -> dict[int, list[str]]:
    rows: dict[int, list[str]] = {}
    for line in text.splitlines():
        match = ROW_NAME.search(line)
        if not match:
            continue
        index = int(match.group(1))
        if index in rows:
            raise ValueError(f"duplicate physical row for line{index}_rtl_0")
        rows[index] = [field.strip() for field in line.split(";")]
    return rows


def as_int(value: str, label: str) -> int:
    try:
        return int(value.replace(",", ""))
    except ValueError as exc:
        raise ValueError(f"{label} is not an integer: {value!r}") from exc


def check_common(
    index: int,
    fields: list[str],
    *,
    offset: int,
    bits_offset: int = 4,
) -> tuple[int, int]:
    if len(fields) <= offset + bits_offset:
        raise ValueError(f"line{index} RAM Summary row is truncated")
    ram_type = fields[2]
    mode = fields[3]
    if ram_type not in {"M10K", "M10K block"}:
        raise ValueError(f"line{index} is {ram_type!r}, not an M10K")
    if mode != "Simple Dual Port":
        raise ValueError(f"line{index} mode is {mode!r}, not Simple Dual Port")
    depth_a = as_int(fields[offset], f"line{index} port-A depth")
    width_a = as_int(fields[offset + 1], f"line{index} port-A width")
    depth_b = as_int(fields[offset + 2], f"line{index} port-B depth")
    width_b = as_int(fields[offset + 3], f"line{index} port-B width")
    bits = as_int(fields[offset + bits_offset], f"line{index} bits")
    if depth_a != 128 or depth_b != 128:
        raise ValueError(
            f"line{index} depth changed: A={depth_a}, B={depth_b}, expected 128"
        )
    # Four adjacent 16-bit pixels are stored as one writer beat.  The renderer
    # does not consume pixel bit 15, so Quartus may trim one bit from each lane:
    # 4x15=60 instead of 4x16=64.  Cyclone V M10K dual-port width tops out at
    # 40 bits, so either legal logical width must occupy exactly two M10Ks.
    if width_a not in {60, 64} or width_b != width_a:
        raise ValueError(
            f"line{index} width changed: A={width_a}, B={width_b}, expected 60 or 64"
        )
    if bits != 128 * width_a:
        raise ValueError(
            f"line{index} bit count {bits} does not match 128x{width_a}"
        )
    return width_a, bits


def inference_blocks(text: str) -> dict[int, str]:
    starts: list[tuple[int, int]] = []
    marker = re.compile(
        r'Info \(276029\): Inferred altsyncram megafunction.*'
        r'tunit_scanline:lines\|line([0-3])_rtl_0"'
    )
    lines = text.splitlines()
    for number, line in enumerate(lines):
        match = marker.search(line)
        if match:
            starts.append((number, int(match.group(1))))
    blocks: dict[int, str] = {}
    for number, index in starts:
        if index in blocks:
            raise ValueError(f"duplicate inference block for line{index}_rtl_0")
        tail = number + 1
        while tail < len(lines) and "Info (276029):" not in lines[tail]:
            tail += 1
        blocks[index] = "\n".join(lines[number:tail])
    return blocks


def require_parameter(block: str, name: str, expected: str, index: int) -> None:
    pattern = re.compile(
        rf"Parameter {re.escape(name)} set to {re.escape(expected)}(?:\s|$)"
    )
    if not pattern.search(block):
        raise ValueError(
            f"line{index} inference lacks {name}={expected}"
        )


def audit_map(report: Path, text: str) -> list[str]:
    rows = parse_table_rows(text)
    if set(rows) != {0, 1, 2, 3}:
        raise ValueError(f"map has scan rows {sorted(rows)}, expected [0, 1, 2, 3]")
    widths = []
    findings = []
    for index in range(4):
        width, bits = check_common(index, rows[index], offset=4)
        widths.append(width)
        findings.append(f"map line{index}: packed M10K SDP 128x{width} bits={bits}")
    if len(set(widths)) != 1:
        raise ValueError(f"map row widths differ: {widths}")

    blocks = inference_blocks(text)
    if set(blocks) != {0, 1, 2, 3}:
        raise ValueError(
            f"map inference blocks are {sorted(blocks)}, expected [0, 1, 2, 3]"
        )
    for index, block in sorted(blocks.items()):
        require_parameter(block, "OPERATION_MODE", "DUAL_PORT", index)
        require_parameter(block, "NUMWORDS_A", "128", index)
        require_parameter(block, "NUMWORDS_B", "128", index)
        require_parameter(block, "RAM_BLOCK_TYPE", "M10K", index)
        require_parameter(
            block, "READ_DURING_WRITE_MODE_MIXED_PORTS", "OLD_DATA", index
        )
        findings.append(f"map line{index}: mixed-port RDW=OLD_DATA")
    return findings


def audit_fit(report: Path, text: str) -> list[str]:
    rows = parse_table_rows(text)
    if set(rows) != {0, 1, 2, 3}:
        raise ValueError(f"fit has scan rows {sorted(rows)}, expected [0, 1, 2, 3]")
    widths = []
    findings = []
    for index in range(4):
        fields = rows[index]
        if len(fields) < 27:
            raise ValueError(f"line{index} Fitter RAM row is truncated")
        if fields[4] != "Single Clock":
            raise ValueError(
                f"line{index} clock mode is {fields[4]!r}, expected Single Clock"
            )
        # Unlike the Mapper table, the Fitter inserts four Boolean columns
        # (port-A/port-B input and output registration) between the logical
        # width fields and the logical bit count.  Keep the indices explicit so
        # a value such as "yes" can never be mistaken for the bit count.
        width, bits = check_common(index, fields, offset=5, bits_offset=8)
        widths.append(width)
        impl_depth_a = as_int(fields[14], f"line{index} implementation A depth")
        impl_width_a = as_int(fields[15], f"line{index} implementation A width")
        impl_depth_b = as_int(fields[16], f"line{index} implementation B depth")
        impl_width_b = as_int(fields[17], f"line{index} implementation B width")
        impl_bits = as_int(fields[18], f"line{index} implementation bits")
        m10ks = as_int(fields[19], f"line{index} M10K count")
        mlabs = as_int(fields[20], f"line{index} MLAB count")
        mixed_rdw = fields[23]
        location = fields[22]
        if (impl_depth_a, impl_width_a, impl_depth_b, impl_width_b, impl_bits) != (
            128, width, 128, width, bits
        ):
            raise ValueError(
                f"line{index} implementation shape changed: "
                f"{impl_depth_a}x{impl_width_a}/{impl_depth_b}x{impl_width_b}, "
                f"bits={impl_bits}"
            )
        if m10ks != 2 or mlabs != 0:
            raise ValueError(
                f"line{index} uses M10Ks={m10ks}, MLABs={mlabs}; expected 2/0"
            )
        if mixed_rdw.casefold() != "old data":
            raise ValueError(
                f"line{index} mixed-port RDW is {mixed_rdw!r}, expected Old data"
            )
        locations = [item.strip() for item in location.split(",") if item.strip()]
        if len(locations) != 2 or any(
            not item.startswith("M10K_") for item in locations
        ):
            raise ValueError(
                f"line{index} does not have exactly two physical M10K locations: {location!r}"
            )
        findings.append(
            f"fit line{index}: {','.join(locations)} packed SDP 128x{width} "
            f"mixed-port-RDW=Old-data"
        )
    if len(set(widths)) != 1:
        raise ValueError(f"fit row widths differ: {widths}")
    return findings


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=("map", "fit"), required=True)
    args = parser.parse_args()
    report = OUT / f"Arcade-TUnit.{args.stage}.rpt"
    if not report.is_file() or report.stat().st_size < 2048:
        return refuse(f"missing or truncated report: {report}")
    text = report.read_text(encoding="utf-8", errors="replace")
    try:
        findings = audit_map(report, text) if args.stage == "map" else audit_fit(report, text)
    except ValueError as exc:
        return refuse(str(exc))

    receipt = OUT / f"tunit_scanline_{args.stage}_physical_receipt.txt"
    body = [
        "TUNIT SCANLINE PHYSICAL RECEIPT",
        f"stage={args.stage}",
        f"report={report.name}",
        f"report_sha256={digest(report)}",
        "rows=4",
        "m10ks=8",
        *findings,
        "status=PASS",
        "",
    ]
    receipt.write_text("\n".join(body), encoding="utf-8")
    print(
        f"SCANLINE PHYSICAL GATE: PASS stage={args.stage} rows=4 m10ks=8 "
        f"receipt={receipt.name}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
