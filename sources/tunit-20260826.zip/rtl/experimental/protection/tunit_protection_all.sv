// SPDX-License-Identifier: BSD-3-Clause
// All-profile Midway T-unit protection engine.
//
// Address inputs are TMS34010 bit addresses. Handler offsets in MAME are
// therefore (addr - window_base) >> 4 for a 16-bit handler. In particular,
// NBA table selection uses ((addr - window_base) >> 10) & 0x7f and Judge
// Dredd's switch values are 16-bit-word offsets from 0x01b00000.
//
// This module is included by the production synthesis manifest. The literal
// tables and behavior are derived from docs/mame-ref/midtunit_m.cpp
// (MAME copyright-holders Alex Pasadyn, Zsolt Vasvari, Ernesto Corvi and
// Aaron Giles; thanks to Kurt Mahan).

`timescale 1ns/1ps
`default_nettype none

module tunit_protection_all (
  input  wire logic           clk,
  input  wire logic           rst,
  input  wire logic [2:0]     profile,
  // Explicit non-profile variant selector. MAME models the unknown MK Turbo
  // GAL counter with random values; this implementation returns a deterministic
  // changing counter so consecutive startup reads differ reproducibly.
  input  wire logic           mk_turbo,
  input  wire logic [31:0]    addr,
  input  wire logic           rd,
  input  wire logic           wr,
  input  wire logic [15:0]    wdata,
  input  wire logic [1:0]     byte_en,
  output logic                hit,
  output logic [15:0]         rdata
);
  import tunit_pkg::*;

  localparam int MK_COUNT = 57;
  localparam logic [MK_COUNT*8-1:0] MK_VALUES = {
    8'h13,8'h27,8'h0f,8'h1f,8'h3e,8'h3d,8'h3b,8'h37,
    8'h2e,8'h1c,8'h38,8'h31,8'h22,8'h05,8'h0a,8'h15,
    8'h2b,8'h16,8'h2d,8'h1a,8'h34,8'h28,8'h10,8'h21,
    8'h03,8'h06,8'h0c,8'h19,8'h32,8'h24,8'h09,8'h13,
    8'h27,8'h0f,8'h1f,8'h3e,8'h3d,8'h3b,8'h37,8'h2e,
    8'h1c,8'h38,8'h31,8'h22,8'h05,8'h0a,8'h15,8'h2b,
    8'h16,8'h2d,8'h1a,8'h34,8'h28,8'h10,8'h21,8'h03,
    8'hff
  };

  localparam logic [4095:0] NBA_VALUES = {
    32'h21283b3b,32'h2439383b,32'h31283b3b,32'h302b3938,32'h31283b3b,32'h302b3938,32'h232f2f2f,32'h26383b3b,
    32'h21283b3b,32'h2439383b,32'h312a1224,32'h302b1120,32'h312a1224,32'h302b1120,32'h232d283b,32'h26383b3b,
    32'h2b3b3b3b,32'h2e2e2e2e,32'h39383b1b,32'h383b3b1b,32'h3b3b3b1b,32'h3a3a3a1a,32'h2b3b3b3b,32'h2e2e2e2e,
    32'h2b39383b,32'h2e2e2e2e,32'h393a1a18,32'h383b1b1b,32'h3b3b1b1b,32'h3a3a1a18,32'h2b39383b,32'h2e2e2e2e,
    32'h01202b3b,32'h0431283b,32'h11202b3b,32'h1021283b,32'h11202b3b,32'h1021283b,32'h03273b3b,32'h06302b39,
    32'h09302b39,32'h0c232f2f,32'h19322e06,32'h18312a12,32'h19322e06,32'h18312a12,32'h0b31283b,32'h0e26383b,
    32'h03273b3b,32'h06302b39,32'h11202b3b,32'h1021283b,32'h13273938,32'h12243938,32'h03273b3b,32'h06302b39,
    32'h0b31283b,32'h0e26383b,32'h19322e06,32'h18312a12,32'h1b332f05,32'h1a302b11,32'h0b31283b,32'h0e26383b,
    32'h21283b3b,32'h2439383b,32'h31283b3b,32'h302b3938,32'h31283b3b,32'h302b3938,32'h232f2f2f,32'h26383b3b,
    32'h21283b3b,32'h2439383b,32'h312a1224,32'h302b1120,32'h312a1224,32'h302b1120,32'h232d283b,32'h26383b3b,
    32'h2b3b3b3b,32'h2e2e2e2e,32'h39383b1b,32'h383b3b1b,32'h3b3b3b1b,32'h3a3a3a1a,32'h2b3b3b3b,32'h2e2e2e2e,
    32'h2b39383b,32'h2e2e2e2e,32'h393a1a18,32'h383b1b1b,32'h3b3b1b1b,32'h3a3a1a18,32'h2b39383b,32'h2e2e2e2e,
    32'h01202b3b,32'h0431283b,32'h11202b3b,32'h1021283b,32'h11202b3b,32'h1021283b,32'h03273b3b,32'h06302b39,
    32'h09302b39,32'h0c232f2f,32'h19322e06,32'h18312a12,32'h19322e06,32'h18312a12,32'h0b31283b,32'h0e26383b,
    32'h03273b3b,32'h06302b39,32'h11202b3b,32'h1021283b,32'h13273938,32'h12243938,32'h03273b3b,32'h06302b39,
    32'h0b31283b,32'h0e26383b,32'h19322e06,32'h18312a12,32'h1b332f05,32'h1a302b11,32'h0b31283b,32'h0e26383b
  };

  localparam logic [4095:0] NBA_TE_VALUES = {
    32'h00000000,32'h04081020,32'h08102000,32'h0c183122,32'h10200000,32'h14281020,32'h18312204,32'h1c393326,
    32'h20000001,32'h24081021,32'h28102000,32'h2c183122,32'h30200001,32'h34281021,32'h38312204,32'h3c393326,
    32'h00000102,32'h04081122,32'h08102102,32'h0c183122,32'h10200000,32'h14281020,32'h18312204,32'h1c393326,
    32'h20000103,32'h24081123,32'h28102102,32'h2c183122,32'h30200001,32'h34281021,32'h38312204,32'h3c393326,
    32'h00010204,32'h04091224,32'h08112204,32'h0c193326,32'h10210204,32'h14291224,32'h18312204,32'h1c393326,
    32'h20000001,32'h24081021,32'h28102000,32'h2c183122,32'h30200001,32'h34281021,32'h38312204,32'h3c393326,
    32'h00010306,32'h04091326,32'h08112306,32'h0c193326,32'h10210204,32'h14291224,32'h18312204,32'h1c393326,
    32'h20000103,32'h24081123,32'h28102102,32'h2c183122,32'h30200001,32'h34281021,32'h38312204,32'h3c393326,
    32'h00000000,32'h01201028,32'h02213018,32'h03012030,32'h04223138,32'h05022110,32'h06030120,32'h07231108,
    32'h08042231,32'h09243219,32'h0a251229,32'h0b050201,32'h0c261309,32'h0d060321,32'h0e072311,32'h0f273339,
    32'h10080422,32'h1128140a,32'h1229343a,32'h13092412,32'h142a351a,32'h150a2532,32'h160b0502,32'h172b152a,
    32'h180c2613,32'h192c363b,32'h1a2d160b,32'h1b0d0623,32'h1c2e172b,32'h1d0e0703,32'h1e0f2733,32'h1f2f371b,
    32'h20100804,32'h2130182c,32'h2231381c,32'h23112834,32'h2432393c,32'h25122914,32'h26130924,32'h2733190c,
    32'h28142a35,32'h29343a1d,32'h2a351a2d,32'h2b150a05,32'h2c361b0d,32'h2d160b25,32'h2e172b15,32'h2f373b3d,
    32'h30180c26,32'h31381c0e,32'h32393c3e,32'h33192c16,32'h343a3d1e,32'h351a2d36,32'h361b0d06,32'h373b1d2e,
    32'h381c2e17,32'h393c3e3f,32'h3a3d1e0f,32'h3b1d0e27,32'h3c3e1f2f,32'h3d1e0f07,32'h3e1f2f37,32'h3f3f3f1f
  };

  localparam int JD_10740_COUNT = 46;
  localparam logic [JD_10740_COUNT*8-1:0] JD_10740_VALUES = {
    8'h14,8'h2a,8'h15,8'h0a,8'h25,8'h32,8'h39,8'h1c,
    8'h2e,8'h37,8'h3b,8'h1d,8'h2e,8'h37,8'h1b,8'h0d,
    8'h26,8'h33,8'h39,8'h3c,8'h1e,8'h2f,8'h37,8'h3b,
    8'h3d,8'h3e,8'h3f,8'h1f,8'h2f,8'h17,8'h0b,8'h25,
    8'h32,8'h19,8'h0c,8'h26,8'h33,8'h19,8'h2c,8'h16,
    8'h2b,8'h15,8'h0a,8'h05,8'h22,8'h00
  };
  localparam logic [7:0] JD_13240_VALUES = {8'h28};
  localparam logic [15:0] JD_76540_VALUES = {8'h04,8'h08};
  localparam int JD_77760_COUNT = 91;
  localparam logic [JD_77760_COUNT*8-1:0] JD_77760_VALUES = {
    8'h14,8'h2a,8'h14,8'h2a,8'h35,8'h2a,8'h35,8'h1a,
    8'h35,8'h1a,8'h2d,8'h1a,8'h2d,8'h36,8'h2d,8'h36,
    8'h1b,8'h36,8'h1b,8'h36,8'h2c,8'h36,8'h2c,8'h18,
    8'h2c,8'h18,8'h31,8'h18,8'h31,8'h22,8'h31,8'h22,
    8'h04,8'h22,8'h04,8'h08,8'h04,8'h08,8'h10,8'h08,
    8'h10,8'h20,8'h10,8'h20,8'h00,8'h20,8'h00,8'h00,
    8'h00,8'h00,8'h01,8'h00,8'h01,8'h02,8'h01,8'h02,
    8'h05,8'h02,8'h05,8'h0b,8'h05,8'h0b,8'h16,8'h0b,
    8'h16,8'h2c,8'h16,8'h2c,8'h18,8'h2c,8'h18,8'h31,
    8'h18,8'h31,8'h22,8'h31,8'h22,8'h04,8'h22,8'h04,
    8'h08,8'h04,8'h08,8'h10,8'h08,8'h10,8'h20,8'h10,
    8'h20,8'h00,8'h00
  };
  localparam int JD_80020_COUNT = 16;
  localparam logic [JD_80020_COUNT*8-1:0] JD_80020_VALUES = {
    8'h3a,8'h1d,8'h2e,8'h37,8'h00,8'h00,8'h2c,8'h1c,
    8'h39,8'h33,8'h00,8'h00,8'h00,8'h00,8'h00,8'h00
  };

  function automatic logic [15:0] protection_word(input logic [7:0] value);
    protection_word = {value[6:0], 9'd0};
  endfunction

  function automatic logic [7:0] mk_value(input logic [5:0] index);
    mk_value = MK_VALUES[MK_COUNT*8-1-index*8 -: 8];
  endfunction

  function automatic logic [31:0] nba_value(input logic [6:0] index);
    nba_value = NBA_VALUES[4095-index*32 -: 32];
  endfunction

  function automatic logic [31:0] nba_te_value(input logic [6:0] index);
    nba_te_value = NBA_TE_VALUES[4095-index*32 -: 32];
  endfunction

  function automatic logic [7:0] jd_10740_value(input logic [6:0] index);
    jd_10740_value =
      JD_10740_VALUES[JD_10740_COUNT*8-1-index*8 -: 8];
  endfunction

  function automatic logic [7:0] jd_77760_value(input logic [6:0] index);
    jd_77760_value =
      JD_77760_VALUES[JD_77760_COUNT*8-1-index*8 -: 8];
  endfunction

  function automatic logic [7:0] jd_80020_value(input logic [6:0] index);
    jd_80020_value =
      JD_80020_VALUES[JD_80020_COUNT*8-1-index*8 -: 8];
  endfunction

  function automatic logic [6:0] mk_search(input logic [5:0] value);
    integer i;
    logic found;
    begin
      mk_search = 7'd0;
      found = 1'b0;
      for (i = 0; i < MK_COUNT; i = i + 1) begin
        if (!found && (mk_value(i[5:0]) == {2'b00,value})) begin
          mk_search = {1'b1, i[5:0]};
          found = 1'b1;
        end
      end
    end
  endfunction

  typedef enum logic [2:0] {
    JD_NONE, JD_10740, JD_13240, JD_76540, JD_77760, JD_80020
  } jd_table_t;

  function automatic logic [7:0] jd_value(
    input jd_table_t table_id,
    input logic [6:0] index
  );
    begin
      jd_value = 8'hff;
      case (table_id)
        JD_10740: if (index < JD_10740_COUNT) jd_value = jd_10740_value(index);
        JD_13240: if (index < 1)              jd_value = JD_13240_VALUES;
        JD_76540: if (index < 2)
          jd_value = JD_76540_VALUES[15-index*8 -: 8];
        JD_77760: if (index < JD_77760_COUNT) jd_value = jd_77760_value(index);
        JD_80020: if (index < JD_80020_COUNT) jd_value = jd_80020_value(index);
        default: jd_value = 8'hff;
      endcase
    end
  endfunction

  wire logic mk_window = (profile == PROFILE_MK1) &&
    addr_in_range(addr, 32'h01b0_0000, 32'h01b6_ffff);
  wire logic turbo_window = (profile == PROFILE_MK1) && mk_turbo &&
    addr_in_range(addr, 32'hffff_f400, 32'hffff_f40f);

  wire logic mk2_wr_window = (profile == PROFILE_MK2) &&
    (addr_in_range(addr, 32'h00f2_0c60, 32'h00f2_0c7f) ||
     addr_in_range(addr, 32'h00f4_2820, 32'h00f4_283f));
  wire logic mk2_data_window = (profile == PROFILE_MK2) &&
    (addr_in_range(addr, 32'h01a1_90e0, 32'h01a1_90ff) ||
     addr_in_range(addr, 32'h01a3_d0c0, 32'h01a3_d0ff));
  wire logic mk2_shift_window = (profile == PROFILE_MK2) &&
    addr_in_range(addr, 32'h01a1_91c0, 32'h01a1_91df);
  wire logic mk2_const_window = (profile == PROFILE_MK2) &&
    (addr_in_range(addr, 32'h01d9_d1e0, 32'h01d9_d1ff) ||
     addr_in_range(addr, 32'h01de_f920, 32'h01de_f93f));

  wire logic nba_window = (profile == PROFILE_NBAJAM) &&
    addr_in_range(addr, 32'h01b1_4020, 32'h01b2_503f);
  wire logic nba_te_window0 = (profile == PROFILE_NBAJAM_TE) &&
    addr_in_range(addr, 32'h01b1_5f40, 32'h01b3_7f5f);
  wire logic nba_te_window1 = (profile == PROFILE_NBAJAM_TE) &&
    addr_in_range(addr, 32'h01b9_5f40, 32'h01bb_7f5f);
  wire logic nba_any_window = nba_window || nba_te_window0 || nba_te_window1;

  wire logic jd_window = (profile == PROFILE_JDREDD) &&
    addr_in_range(addr, 32'h01b0_0000, 32'h01bf_ffff);

  logic [31:0] nba_base;
  logic [31:0] nba_offset;
  logic [6:0] nba_table_index;
  logic [31:0] nba_table_value;
  always_comb begin
    if (nba_window) nba_base = 32'h01b1_4020;
    else if (nba_te_window0) nba_base = 32'h01b1_5f40;
    else nba_base = 32'h01b9_5f40;
    nba_offset = addr - nba_base;
    nba_table_index = nba_offset[16:10];
    nba_table_value = (profile == PROFILE_NBAJAM_TE)
                    ? nba_te_value(nba_table_index)
                    : nba_value(nba_table_index);
  end

  wire logic [15:0] jd_word_offset = addr[19:4];

  logic [5:0] mk_index;
  logic [15:0] turbo_counter;
  logic [15:0] mk2_data;
  logic [15:0] nba_queue [0:4];
  logic [2:0] nba_queue_index;
  jd_table_t jd_table;
  logic [6:0] jd_index;
  logic [6:0] jd_max;
  wire logic [6:0] mk_search_result = mk_search(wdata[14:9]);

  always_comb begin
    hit = (rd && (mk_window || turbo_window || mk2_data_window ||
                  mk2_shift_window || mk2_const_window || nba_any_window ||
                  jd_window)) ||
          (wr && (mk_window || mk2_wr_window || nba_any_window || jd_window));
    rdata = 16'hffff;
    if (rd && turbo_window)
      rdata = turbo_counter;
    else if (rd && mk_window)
      rdata = protection_word(mk_value((mk_index < MK_COUNT) ? mk_index : 6'd0));
    else if (rd && mk2_data_window)
      rdata = mk2_data;
    else if (rd && mk2_shift_window)
      rdata = {1'b0, mk2_data[15:1]};
    else if (rd && mk2_const_window)
      rdata = 16'h0002;
    else if (rd && nba_any_window)
      rdata = nba_queue[nba_queue_index];
    else if (rd && jd_window && (jd_table != JD_NONE) &&
             (jd_index < jd_max))
      rdata = protection_word(jd_value(jd_table, jd_index));
  end

  integer q;
  always_ff @(posedge clk) begin
    if (rst) begin
      mk_index <= 6'd0;
      turbo_counter <= 16'h4d35;
      mk2_data <= 16'h0000;
      for (q = 0; q < 5; q = q + 1)
        nba_queue[q] <= 16'h0000;
      nba_queue_index <= 3'd0;
      jd_table <= JD_NONE;
      jd_index <= 7'd0;
      jd_max <= 7'd0;
    end else begin
      if (wr && mk_window && byte_en[1])
        mk_index <= mk_search_result[6] ? mk_search_result[5:0] : 6'd0;
      else if (rd && mk_window)
        mk_index <= (mk_index >= MK_COUNT) ? 6'd1 : mk_index + 1'b1;

      if (rd && turbo_window)
        turbo_counter <= turbo_counter + 16'h0101;

      if (wr && mk2_wr_window) begin
        if (byte_en[0]) mk2_data[7:0] <= wdata[7:0];
        if (byte_en[1]) mk2_data[15:8] <= wdata[15:8];
      end

      if (wr && nba_any_window) begin
        nba_queue[0] <= wdata;
        nba_queue[1] <= protection_word(nba_table_value[31:24]);
        nba_queue[2] <= protection_word(nba_table_value[23:16]);
        nba_queue[3] <= protection_word(nba_table_value[15:8]);
        nba_queue[4] <= protection_word(nba_table_value[7:0]);
        nba_queue_index <= 3'd0;
      end else if (rd && nba_any_window && (nba_queue_index < 3'd4)) begin
        nba_queue_index <= nba_queue_index + 1'b1;
      end

      if (wr && jd_window) begin
        case (jd_word_offset)
          16'h1074: begin jd_table <= JD_10740; jd_index <= 0; jd_max <= 7'd46; end
          16'h1324: begin jd_table <= JD_13240; jd_index <= 0; jd_max <= 7'd1; end
          16'h7654: begin jd_table <= JD_76540; jd_index <= 0; jd_max <= 7'd2; end
          16'h7776: begin jd_table <= JD_77760; jd_index <= 0; jd_max <= 7'd91; end
          16'h8002: begin jd_table <= JD_80020; jd_index <= 0; jd_max <= 7'd16; end
          default: ;
        endcase
      end else if (rd && jd_window && (jd_table != JD_NONE) &&
                   (jd_index < jd_max)) begin
        jd_index <= jd_index + 1'b1;
      end
    end
  end

endmodule

`default_nettype wire
