// tunit_adpcm_board.sv - experimental Williams D-11581 ADPCM sound board
// adaptation for Midway T-unit games.
//
// The register map, ROM banking and delayed external-IRQ clear follow MAME's
// williams_adpcm_sound_device. ROM data is read through the common T-unit
// sound-DDR byte bridge:
//   000000-03ffff  sound CPU U3 (expanded to 256 KiB by the MRA)
//   040000-13ffff  OKI sample image (expanded to 1 MiB by the MRA)
//
// The external ROM port is a cached-address interface. ext_rom_addr remains
// stable until ext_rom_ok, then this module retains the byte for the 6809 or
// JT6295 client. This lets one SDRAM byte port serve both devices safely.
//
// Unlike the Y-unit PIA-level interface, the T-unit host presents a one-cycle
// command_wr pulse for every accepted sound write. Every such pulse latches the
// low command byte and asserts the 6809 IRQ; main-CPU D9 is not passed here.
//
// Adapted from the local Arcade-SmashTV_MiSTer donor. The combined design uses
// GPL-licensed MC6809/JT51/JT6295 dependencies; see rtl/vendor/ADPCM-PROVENANCE.md.
`timescale 1ns/1ps
`default_nettype none
module tunit_adpcm_board (
  input  logic               clk,          // 12 MHz
  input  logic               reset_pon,
  input  logic               reset,
  input  logic [2:0]         profile,
  input  logic               command_wr,
  input  logic [7:0]         command,

  // Logical sound-download stream in the system clock domain.  The fixed
  // 6809 window is copied here while the whole core is already loader-held in
  // reset; soft sound-board resets must not invalidate it.
  input  logic               snd_dl_clk,
  input  logic [23:0]        snd_dl_addr,
  input  logic [7:0]         snd_dl_data,
  input  logic               snd_dl_we,

  output logic [20:0]        ext_rom_addr,
  input  logic [7:0]         ext_rom_data,
  input  logic               ext_rom_ok,

  output logic signed [15:0] audio_l,
  output logic signed [15:0] audio_r,
  output logic               irq_state,

  // Diagnostic telemetry, sound-clock domain.  Nothing on this board is
  // observable on hardware today; these are the fields that carry a measured
  // MAME 0.289 golden, so a cabinet reading is a comparison rather than an
  // interpretation.  See rtl/diag/tunit_audio_telemetry.sv.
  output logic [15:0]        tel_ym_per_s,
  output logic [15:0]        tel_firq_per_s,
  output logic [15:0]        tel_dac_per_s,
  output logic [15:0]        tel_oki_writes,
  output logic [15:0]        tel_e_rate_cpct,
  output logic [15:0]        tel_romwait_pct,
  output logic [15:0]        tel_cmd_reads,
  output logic [15:0]        tel_misc,
  output logic               tel_tick
);
  // The existing CVSD board stretches POR because JT51's internal reset shift
  // chains need considerably more than one host reset cycle. Do the same here.
  logic [8:0] por_count = 9'h1ff;
  always_ff @(posedge clk) begin
    if (reset_pon) por_count <= 9'h1ff;
    else if (por_count != 0) por_count <= por_count - 1'b1;
  end
  wire core_reset = reset | reset_pon | (por_count != 0);

  wire         board_reset = core_reset;

  // FIX 1 -- A/B child-reset split (port of yunit_adpcm_board ea468de, adapted).
  // MAME's williams_adpcm_sound_device::reset_write() -> device_reset() resets
  // the 6809 interrupt lines and the board's two timers ONLY; it never resets
  // the ym2151/oki6295 child devices (MAME 0.289 williamssound.cpp:820-830, and
  // the YM/6809 wiring at :771-772).  A host/board reset therefore leaves the
  // YM's Timer-A period and IRQ-enable intact -- the sequencer keeps ticking.
  // T diverged by COUPLING all three resets onto board_reset (see the jt51/oki
  // .rst and the ym_cen/oki_cen accumulators below), so a mid-track host reset
  // zeroes jt51 value_A; because the game programs the period (0x10/0x11) only
  // ONCE per track (never re-written during steady play), value_A stays 0 for
  // the whole track and the 13,982 Hz FIRQ heartbeat collapses to the ~54.6 Hz
  // value_A=0 floor.  Keep the CPU/board transport on the host-reset domain but
  // let both sound chips AND their clock phases see power-on reset only.
`ifdef MUT_ADPCM_CHILD_RESET_COUPLED
  // MUTANT (mirrors Y's MUT_ADPCM_CHILD_RESET_COUPLED): restore the old coupling
  // that reset jt51/OKI on every host reset.  This branch must FAIL the LEG B
  // full-board FIRQ leg of tb_tunit_fm_cadence (value_A lost across the reset).
  wire         child_reset = board_reset;
`else
  wire         child_reset = reset_pon | (por_count != 0);
`endif

  // 6809E at 8 MHz / 4 = 2 MHz, represented as falling E/Q enables in the
  // 12 MHz host domain (the same proven cadence as williams_cvsd_board).
  logic en_half;
  logic [1:0] div_count;
  logic cpu_e_en, cpu_q_en, cpu_write;
  wire cpu_rom_ready;
  wire cpu_rom_wait;
  wire logic [15:0] cpu_addr;
  logic [7:0] cpu_din;
  wire logic [7:0] cpu_dout;
  wire logic cpu_rnw;
  wire logic ym_irq_n;
  logic cpu_irq;
  // A ROM miss is visible several host clocks before the 6809 consumes the
  // byte.  Run E/Q freely through that latency and hold only the falling-E
  // enable that would consume an unready byte.  Freezing the whole divider on
  // the first miss turns memory latency directly into a lower effective CPU
  // clock, while the YM clock keeps running -- the held-note/late-key-off
  // signature reported by NBA Jam and TE.
`ifdef MUT_TUNIT_EAGER_STALL
  // Kill control for the focused real-ROM pace gate: restore the old eager,
  // whole-divider freeze.  The single-clock fixed bank makes fixed reads
  // wait-free, so the tune gate exercises this mutant on a real banked-window
  // miss whose consumption timing this branch corrupts.
  wire e_hold = cpu_rom_wait;
`else
  wire e_hold = en_half && (div_count == 2'd0) && cpu_rom_wait;
`endif
  always_ff @(posedge clk) begin
    cpu_e_en <= 1'b0;
    cpu_q_en <= 1'b0;
    cpu_write <= 1'b0;
    if (board_reset) begin
      en_half <= 1'b0;
      div_count <= 2'd0;
    end else if (!e_hold) begin
      en_half <= ~en_half;
      if (en_half) begin
        div_count <= (div_count == 2'd2) ? 2'd0 : div_count + 1'b1;
        if (div_count == 2'd0) cpu_e_en <= 1'b1;
        if (div_count == 2'd2) begin
          cpu_q_en <= 1'b1;
          cpu_write <= ~cpu_rnw;
        end
      end
    end
  end

  mc6809is u_cpu (
    .CLK(clk), .fallE_en(cpu_e_en), .fallQ_en(cpu_q_en),
    .OP(cpu_din), .D(cpu_din), .DOut(cpu_dout), .ADDR(cpu_addr),
    .RnW(cpu_rnw), .BS(), .BA(), .nIRQ(~cpu_irq),
    .nFIRQ(ym_irq_n), .nNMI(1'b1), .AVMA(), .BUSY(), .LIC(),
    .nHALT(1'b1), .nRESET(~board_reset), .nDMABREQ(1'b1), .RegData()
  );

  // 8 KiB work RAM.
  logic [7:0] ram [0:8191];
  logic [7:0] ram_q;
  always_ff @(posedge clk) begin
    ram_q <= ram[cpu_addr[12:0]];
    if (cpu_write && cpu_addr < 16'h2000)
      ram[cpu_addr[12:0]] <= cpu_dout;
  end

  // MAME installs a 43-byte hidden RAM overlay in the otherwise fixed-ROM
  // window. Its base differs by T-unit game family. Clear it only at power-on;
  // a command-controlled sound-board reset must not destroy protection state.
  localparam logic [2:0] PROFILE_MK1       = 3'd0;
  localparam logic [2:0] PROFILE_NBAJAM    = 3'd2;
  localparam logic [2:0] PROFILE_NBAJAM_TE = 3'd3;
  localparam logic [2:0] PROFILE_JDREDD    = 3'd4;
  logic [7:0] hidden_ram [0:42];
  logic [5:0] hidden_clear_count;
  logic       hidden_hit;
  logic [5:0] hidden_index;

  always_comb begin
    hidden_hit = 1'b0;
    hidden_index = 6'd0;
    case (profile)
      PROFILE_MK1: begin
        hidden_hit = (cpu_addr >= 16'hfb9c) && (cpu_addr <= 16'hfbc6);
        hidden_index = cpu_addr[5:0] - 6'h1c;
      end
      PROFILE_NBAJAM: begin
        hidden_hit = (cpu_addr >= 16'hfbaa) && (cpu_addr <= 16'hfbd4);
        hidden_index = cpu_addr[5:0] - 6'h2a;
      end
      PROFILE_NBAJAM_TE: begin
        hidden_hit = (cpu_addr >= 16'hfbec) && (cpu_addr <= 16'hfc16);
        hidden_index = cpu_addr[5:0] - 6'h2c;
      end
      PROFILE_JDREDD: begin
        hidden_hit = (cpu_addr >= 16'hfbcf) && (cpu_addr <= 16'hfbf9);
        hidden_index = cpu_addr[5:0] - 6'h0f;
      end
      default: begin
        hidden_hit = 1'b0;
        hidden_index = 6'd0;
      end
    endcase
  end

  always_ff @(posedge clk) begin
    if (reset_pon) begin
      hidden_clear_count <= 6'd0;
    end else if (hidden_clear_count < 6'd43) begin
      hidden_ram[hidden_clear_count] <= 8'h00;
      hidden_clear_count <= hidden_clear_count + 1'b1;
    end else if (cpu_write && hidden_hit) begin
      hidden_ram[hidden_index] <= cpu_dout;
    end
  end

  wire io_bank   = cpu_addr[15:10] == 6'b001000; // 2000-23ff
  wire io_ym     = cpu_addr[15:10] == 6'b001001; // 2400-27ff
  wire io_dac    = cpu_addr[15:10] == 6'b001010; // 2800-2bff
  wire io_oki    = cpu_addr[15:10] == 6'b001011; // 2c00-2fff
  wire io_cmd    = cpu_addr[15:10] == 6'b001100; // 3000-33ff
  wire io_okibnk = cpu_addr[15:10] == 6'b001101; // 3400-37ff
  wire io_talk   = cpu_addr[15:10] == 6'b001111; // 3c00-3fff
  wire cpu_rom   = (cpu_addr >= 16'h4000) && !hidden_hit;
  // P0044: c000-ffff is served from the local mirror, 4000-bfff from DDR3.
  wire cpu_rom_fixed = cpu_rom && (cpu_addr[15:14] == 2'b11);

  logic [2:0] cpu_bank, oki_bank;
  logic [7:0] dac_data, talkback;
  logic [7:0] command_latch;
  logic [7:0] irq_clear_count;

  // FIX 2 -- in-order command-delivery FIFO (port of yunit_adpcm_board cb17d16,
  // adapted to T's plumbing).  MEASURED ROOT CAUSE (Y cb17d16 / T rtl-firq-census
  // M8): the game stops music with 0x00 and frequently fires 0x00 then the next
  // track-select back-to-back in ONE main-CPU burst.  On MAME the 6809 reads
  // BOTH in order only because williams sync_command() calls perfect_quantum
  // (100 us) (williamssound.cpp:844).  On silicon both clock domains free-run and
  // the 6809 IRQ entry (~10 us) >> the CDC's ~200-360 ns command spacing, so a
  // single overwrite latch loses the 0x00 (the later byte clobbers it before the
  // 6809 services it) -> the prior note never keys off ("held note after a stop").
  //
  // Fork discipline (rtl-firq-census 3b): Y edge-detects the raw {sound_trig,
  // sound_select} tuple; T instead consumes pre-serialized command_wr pulses from
  // tunit_sound_cdc, so this port enqueues exactly ONE entry per command_wr (no
  // tuple edge-detect, no D9 latch-only path -- every T command asserts IRQ, see
  // the header note).  T's 120-clock (10 us) external-IRQ hold is preserved.
  // Overflow is gospel-faithful newest-enqueued/oldest-dropped (williamssound.cpp
  // :839 m_latch=data always takes the newest), degenerating toward the single
  // latch only under genuine 6809 overload.
  localparam int CFD = 8;                     // depth 8 (>= observed bursts of 2-3)
  logic [7:0]  cfifo [0:CFD-1];
  logic [3:0]  cf_head, cf_tail;              // extra top bit distinguishes full/empty
  wire         cf_empty = (cf_head == cf_tail);
  wire         cf_full  = (cf_head[2:0] == cf_tail[2:0]) && (cf_head[3] != cf_tail[3]);
  wire [2:0]   cf_hidx  = cf_head[2:0];
  wire [2:0]   cf_tidx  = cf_tail[2:0];
  logic [7:0]  reassert_count;
  typedef enum logic [1:0] { CQ_IDLE, CQ_PRES, CQ_WAIT } cq_state_t;
  cq_state_t   cq_state;
  // The command port read (0x3000-class) that clears the command IRQ.
  wire         cmd_read = cpu_rnw && cpu_e_en && io_cmd;

  // Each T-unit host pulse is a new command, including repeated byte values.
  // Reading 0x3000 clears the CPU line immediately, but keeps the externally
  // visible IRQ high for 10 us, matching williams_adpcm_sound_device.
  // Reset only for a real board reset.  The background mirror fill must neither
  // clear nor defer a host command: pinned MAME's sync_command latches the byte
  // and asserts the 6809 IRQ (MAME 0.289 williamssound.cpp:837-845).
  always_ff @(posedge clk) begin
    if (core_reset) begin
      cpu_bank <= 3'd0;
      oki_bank <= 3'd0;
      dac_data <= 8'h80;
      talkback <= 8'h00;
      // command_latch NOT cleared here: williamssound.cpp:820-830 device_reset()
      // resets the interrupt state but leaves m_latch alone, so a byte latched
      // across a reset is still readable when the 6809 comes out of it.
      cpu_irq <= 1'b0;
      irq_state <= 1'b0;
      irq_clear_count <= 8'd0;
`ifndef MUT_ADPCM_SINGLE_LATCH
      reassert_count <= 8'd0;
      cq_state <= CQ_IDLE;
      // Theory C (d4215e5): midtunit_m.cpp:560-561 calls reset_write() BEFORE
      // write(), so a command issued together with a board reset still lands and
      // the 6809 takes it on release.  Seed a single-entry queue from a
      // reset-coincident command_wr (newest wins if several arrive while held);
      // otherwise empty the queue at power-on / board reset.
      if (command_wr) begin
        cfifo[3'd0] <= command;
        cf_head <= 4'd0;
        cf_tail <= 4'd1;
      end else begin
        cf_head <= 4'd0;
        cf_tail <= 4'd0;
      end
`endif
    end else begin
      if (irq_clear_count != 0) begin
        irq_clear_count <= irq_clear_count - 1'b1;
        if (irq_clear_count == 1) irq_state <= 1'b0;
      end

      if (cpu_write) begin
        if (io_bank)        cpu_bank <= cpu_dout[2:0];
        else if (io_dac)    dac_data <= cpu_dout;
        else if (io_okibnk) oki_bank <= cpu_dout[2:0];
        else if (io_talk)   talkback <= cpu_dout;
      end

      // MAME delays the externally visible clear by 10 us. At 12 MHz that is
      // 120 clocks; the local CPU IRQ itself clears on the command read.
      if (cmd_read) begin
        cpu_irq <= 1'b0;
        irq_clear_count <= 8'd120;
      end

`ifndef MUT_ADPCM_SINGLE_LATCH
      // ---- FIX 2: enqueue one entry per command_wr pulse ------------------
      // Kept OUTSIDE-equivalent (the else branch still runs on a soft reset
      // release cycle) but the reset-coincident case is handled by the seed
      // above, so theory-C delivery is preserved with an in-order queue.
      if (command_wr) begin
        cfifo[cf_tidx] <= command;
        cf_tail <= cf_tail + 4'd1;
        if (cf_full) cf_head <= cf_head + 4'd1;    // OVERFLOW: drop OLDEST
                                                   // (single-latch degenerate,
                                                   //  williamssound.cpp:839)
      end

      // ---- present / re-assert FSM (queue-driven) -------------------------
      // Restores the consume-before-next ordering perfect_quantum guarantees in
      // MAME: present the head, then present the NEXT queued command only after
      // the 6809 reads the command port (cmd_read), with a 120-clk (10 us)
      // spacing that mirrors the external-IRQ hold (williamssound.cpp:716).
      case (cq_state)
        CQ_IDLE: begin
          if (!cf_empty) begin
            command_latch <= cfifo[cf_hidx];
            cpu_irq <= 1'b1;
            irq_state <= 1'b1;
            irq_clear_count <= 8'd0;
            cq_state <= CQ_PRES;
          end
        end
        CQ_PRES: begin
          if (cmd_read) begin
            cf_head <= cf_head + 4'd1;             // pop the served head
            reassert_count <= 8'd120;              // 10 us spacing before next
            cq_state <= CQ_WAIT;
          end
        end
        CQ_WAIT: begin
          if (reassert_count != 0)
            reassert_count <= reassert_count - 1'b1;
          else if (cf_head != cf_tail) begin       // present next queued command
            command_latch <= cfifo[cf_hidx];
            cpu_irq <= 1'b1;
            irq_state <= 1'b1;
            irq_clear_count <= 8'd0;
            cq_state <= CQ_PRES;
          end else
            cq_state <= CQ_IDLE;
        end
      endcase
`endif
    end

`ifdef MUT_ADPCM_SINGLE_LATCH
    // MUT_ADPCM_SINGLE_LATCH -- the pre-FIX-2 single overwrite latch (T's shipped
    // board).  A back-to-back stop(0x00)+track pair loses 0x00 before the 6809
    // reads it, so the prior note never keys off.  This branch MUST FAIL the
    // LEG C command-drop leg of tb_tunit_fm_cadence.  Kept OUTSIDE the reset
    // branch (theory C): a command issued together with a board reset still
    // lands and wins over a coincident command read/clear.
    if (command_wr) begin
      command_latch <= command;
      cpu_irq <= 1'b1;
      irq_state <= 1'b1;
      irq_clear_count <= 8'd0;
    end
`endif
  end

  // YM2151 at NTSC colorburst (3.579545 MHz): exact 105/352 accumulator.
  logic [9:0] ym_acc;
  logic ym_cen, ym_cen_p1, ym_alt;
  always_ff @(posedge clk) begin
    ym_cen <= 1'b0;
    ym_cen_p1 <= 1'b0;
    if (child_reset) begin        // FIX 1: power-on only, host reset excluded
      ym_acc <= 10'd0;
      ym_alt <= 1'b0;
    end else if (ym_acc + 10'd105 >= 10'd352) begin
      ym_acc <= ym_acc + 10'd105 - 10'd352;
      ym_cen <= 1'b1;
      ym_alt <= ~ym_alt;
      ym_cen_p1 <= ym_alt;
    end else begin
      ym_acc <= ym_acc + 10'd105;
    end
  end

  logic [7:0] ym_dout;
  logic signed [15:0] ym_left, ym_right;
  jt51 u_ym (
    .rst(child_reset), .clk(clk), .cen(ym_cen), .cen_p1(ym_cen_p1),  // FIX 1
    .cs_n(~io_ym), .wr_n(~(cpu_write && io_ym)), .a0(cpu_addr[0]),
    .din(cpu_dout), .dout(ym_dout), .ct1(), .ct2(), .irq_n(ym_irq_n),
    .sample(), .left(), .right(), .xleft(ym_left), .xright(ym_right)
  );

  // OKI6295 input clock is 8 MHz / 8 = 1 MHz; pin 7 is high.
  logic [3:0] oki_div;
  logic oki_cen;
  always_ff @(posedge clk) begin
    oki_cen <= 1'b0;
    if (child_reset) oki_div <= 4'd0;   // FIX 1: power-on only, host reset excluded
    else if (oki_div == 4'd11) begin
      oki_div <= 4'd0;
      oki_cen <= 1'b1;
    end else oki_div <= oki_div + 1'b1;
  end

  logic [7:0] oki_dout;
  logic [17:0] oki_addr;
  logic signed [13:0] oki_sound;
  logic [7:0] oki_rom_data;
  logic oki_rom_ok;
  // INTERPOL(0) handed out a raw 7,575 Hz zero-order hold with no
  // reconstruction filter, into a 48 kHz sink -- aliasing images across the
  // whole audible band, which is what "crunchy samples" is.  The real board
  // has an analog reconstruction filter and MAME's resampler does the
  // equivalent.  Enabling the vendor's 4x upsampling FIR requires fixes 2
  // and 3 above or the coefficients never load and the OKI goes silent.
  jt6295 #(.INTERPOL(1)) u_oki (
    .rst(child_reset), .clk(clk), .cen(oki_cen), .ss(1'b1),   // FIX 1
    .wrn(~(cpu_write && io_oki)), .din(cpu_dout), .dout(oki_dout),
    .rom_addr(oki_addr), .rom_data(oki_rom_data), .rom_ok(oki_rom_ok),
    .sound(oki_sound), .sample()
  );

  // MAME CPU ROM layout after removing the unused 0x10000 region prefix.
  logic [20:0] cpu_rom_want;
  logic [14:0] cpu_bank_offset;
  logic [15:0] cpu_bank_offset_full;
  always_comb begin
    cpu_bank_offset_full = cpu_addr - 16'h4000;
    cpu_bank_offset = cpu_bank_offset_full[14:0];
    if (cpu_addr < 16'hc000)
      cpu_rom_want = {3'd0, cpu_bank, cpu_bank_offset};
    else
      cpu_rom_want = 21'h3c000 + {7'd0, cpu_addr[13:0]};
  end

  // MAME's expanded OKI banking. Values are logical offsets within the
  // one-megabyte sample image; 0x40000 is added for the CPU-ROM prefix.
  logic [20:0] oki_logical;
  always_comb begin
    if (!oki_addr[17]) begin
      case (oki_bank)
        3'd0, 3'd1: oki_logical = 21'h40000 + {4'd0, oki_addr[16:0]};
        3'd2:       oki_logical = 21'h20000 + {4'd0, oki_addr[16:0]};
        3'd3:       oki_logical =           {4'd0, oki_addr[16:0]};
        3'd4:       oki_logical = 21'he0000 + {4'd0, oki_addr[16:0]};
        3'd5:       oki_logical = 21'hc0000 + {4'd0, oki_addr[16:0]};
        3'd6:       oki_logical = 21'ha0000 + {4'd0, oki_addr[16:0]};
        default:    oki_logical = 21'h80000 + {4'd0, oki_addr[16:0]};
      endcase
    end else begin
      // Fixed 0x20000-0x3ffff window maps to logical 0x60000-0x7ffff.
      oki_logical = 21'h40000 + {3'd0, oki_addr};
    end
  end
  wire [20:0] oki_rom_want = 21'h40000 + oki_logical;

  // ---------------------------------------------------------------- fixed ROM
  // MAME maps the 6809's c000-ffff window to expanded U3 image bytes
  // 03c000-03ffff.  tunit_sound_stream_map presents that same logical address
  // to snd_addr, so copy exactly that 16 KiB range during download.  The full
  // high-address compare is intentional: ADPCM OKI payloads can have the same
  // low 18 address bits and must never populate this bank.  In a universal
  // build DCS can also present logical 03c000; tunit_top suppresses DCS writes
  // at this ADPCM-only preload tap because the ADPCM board is inactive for MK2.
  //
  // Keep both RAM ports on snd_dl_clk (the 80 MHz system clock).  Quartus 17
  // emits Warning 276027 for every inferred dual-clock RAM because mixed-clock
  // read-during-write behaviour is undefined; resetting the 12 MHz read-data
  // register also makes this array uninferable.  The neighbouring Y-unit core
  // solved the same fixed-bank seam with this canonical single-clock shape.
  //
  // cpu_addr is quasi-static for a whole 6809 E cycle.  The fast domain samples
  // it and captures fixed_q/fixed_aq together; the sound-domain equality test is
  // the settledness guard.  fixed_q_valid remains a 12 MHz reset-domain bit, so
  // no value is consumable while reset is asserted or before the first sound
  // edge after release.
  //
  // A read/write collision cannot be observed in production: tunit_top threads
  // the loader's dedicated rst_sound fence into the board reset before the
  // mapped sound stream can write and holds it through the final backend ack.
  // The 80 MHz read port continues to run during that interval, but
  // fixed_q_valid keeps its result unobservable; after release there are no
  // writes.  Thus a same-address read/write result can never reach the CPU.
  // Do not use no_rw_check here:
  // T-unit's release policy rejects that false promise.  Quartus map must prove
  // this single-clock 1W/1R shape is exactly 16 M10Ks before assembly.
  //
  // The RAM is never cleared by core_reset, so the host's ordinary FE00/FF00
  // sound reset cannot destroy the program; a new game load overwrites all
  // 16 KiB before release.
  (* ramstyle = "M10K" *) logic [7:0] fixed_rom [0:16383];
  logic [7:0]  fixed_q;
  logic [13:0] fixed_aq;
  logic        fixed_q_valid;
  always_ff @(posedge snd_dl_clk) begin
    if (snd_dl_we && (snd_dl_addr[23:14] == 10'h00f))
      fixed_rom[snd_dl_addr[13:0]] <= snd_dl_data;
    fixed_q  <= fixed_rom[cpu_addr[13:0]];
    fixed_aq <= cpu_addr[13:0];
  end
  always_ff @(posedge clk) begin
    if (reset)
      fixed_q_valid <= 1'b0;
    else
      fixed_q_valid <= 1'b1;
  end
`ifdef MUT_TUNIT_NO_FIXED_BANK
  // Kill control for the focused real-ROM tune gate: restore the pre-mirror
  // shape in which every fixed-window fetch goes through the external port.
  wire fixed_ready = 1'b0;
`else
  wire fixed_ready = cpu_rom_fixed && fixed_q_valid &&
                     (fixed_aq == cpu_addr[13:0]);
`endif

  // Two-client read cache over the one external SDRAM byte stream.  Only the
  // banked 4000-bfff CPU window reaches this port; fixed-ROM fetches wait for
  // the tagged local-RAM read above and never consume DDR bandwidth.
  typedef enum logic {FETCH_CPU, FETCH_OKI} fetch_t;
  fetch_t fetch_client;
  logic [20:0] cpu_rom_tag, oki_rom_tag;
  logic [7:0] cpu_rom_data;
  logic cpu_rom_valid, oki_rom_valid;
  assign cpu_rom_ready = cpu_rom_valid && cpu_rom_tag == cpu_rom_want;
`ifdef MUT_TUNIT_NO_FIXED_BANK
  assign cpu_rom_wait = cpu_rnw && cpu_rom && !cpu_rom_ready;
  wire cpu_ext_need = cpu_rom_wait;
`else
  assign cpu_rom_wait = cpu_rnw && cpu_rom &&
                        (cpu_rom_fixed ? !fixed_ready : !cpu_rom_ready);
  wire cpu_ext_need = cpu_rom_wait && !cpu_rom_fixed;
`endif

  // Strict-priority selector for the one external byte port: CPU, then OKI.
  // Priority is evaluated only between byte transactions. Once
  // a request starts, its owner and address must remain stable until snd_ok:
  // tunit_adpcm_rom_cdc latches request_addr while request_pending and exposes
  // a response only when cached_addr still equals snd_addr.  The transaction
  // owner/address lock prevents a newly arriving CPU request from relabelling
  // an in-flight OKI response (or vice versa).
  typedef enum logic {SEL_CPU, SEL_OKI} sel_t;
  sel_t ext_sel;
  sel_t ext_txn_owner = SEL_CPU;
  logic ext_txn_busy = 1'b0;
  logic ext_req_needed;
  logic [20:0] ext_txn_addr = 21'd0;

  // Lock one accepted byte transaction through its acknowledgement.  An OKI
  // byte may delay a newly arriving CPU request by only the remainder of that
  // transaction; when idle, CPU > OKI priority is evaluated again.
  always_ff @(posedge clk) begin
    if (board_reset) begin
      ext_txn_busy  <= 1'b0;
      ext_txn_owner <= SEL_CPU;
      ext_txn_addr  <= 21'd0;
    end else if (ext_txn_busy) begin
      if (ext_rom_ok)
        ext_txn_busy <= 1'b0;
    end else if (ext_req_needed && !ext_rom_ok) begin
      ext_txn_busy  <= 1'b1;
      ext_txn_owner <= ext_sel;
      ext_txn_addr  <= ext_rom_addr;
    end
  end

  always_ff @(posedge clk) begin
    if (board_reset) begin
      fetch_client <= FETCH_CPU;
      cpu_rom_tag <= 21'd0;
      oki_rom_tag <= 21'd0;
      cpu_rom_data <= 8'h00;
      oki_rom_data <= 8'h00;
      cpu_rom_valid <= 1'b0;
      oki_rom_valid <= 1'b0;
    end else begin
      if (cpu_rom_valid && cpu_rom_tag != cpu_rom_want)
        cpu_rom_valid <= 1'b0;
      if (oki_rom_valid && oki_rom_tag != oki_rom_want)
        oki_rom_valid <= 1'b0;

      // P0047: latch into whichever client the strict-priority selector is
      // currently pointing at.  The old round-robin fetch_client is retained
      // only as a debug/observation register; it no longer drives the port.
      if (ext_rom_ok) begin
        if (ext_sel == SEL_CPU) begin
          cpu_rom_tag <= ext_rom_addr;
          cpu_rom_data <= ext_rom_data;
          cpu_rom_valid <= 1'b1;
          fetch_client <= FETCH_OKI;
        end else if (ext_sel == SEL_OKI) begin
          oki_rom_tag <= ext_rom_addr;
          oki_rom_data <= ext_rom_data;
          oki_rom_valid <= 1'b1;
          fetch_client <= FETCH_CPU;
        end
      end
    end
  end

  wire oki_rom_hit = oki_rom_valid && (oki_rom_tag == oki_rom_want);

  always_comb begin
    // CPU first (it is the only client that can stall a real clock edge), then
    // the OKI. An active transaction overrides live priority so
    // the bundled address cannot change before ext_rom_ok.
    ext_req_needed = 1'b1;
    if (ext_txn_busy) begin
      ext_sel      = ext_txn_owner;
      ext_rom_addr = ext_txn_addr;
    end else if (cpu_ext_need) begin
      ext_sel      = SEL_CPU;
      ext_rom_addr = cpu_rom_want;
    end else if (!oki_rom_hit) begin
      ext_sel      = SEL_OKI;
      ext_rom_addr = oki_rom_want;
    end else begin
      // With no requester, park on the board's already-cached OKI address. This
      // keeps snd_addr stable without creating a new CDC transaction.
      ext_sel        = SEL_OKI;
      ext_rom_addr   = oki_rom_want;
      ext_req_needed = 1'b0;
    end
    oki_rom_ok = oki_rom_hit;
  end

  always_comb begin
    if (!cpu_rnw)                         cpu_din = cpu_dout;
    else if (cpu_addr < 16'h2000)         cpu_din = ram_q;
    else if (hidden_hit)                   cpu_din = hidden_ram[hidden_index];
    else if (io_ym)                       cpu_din = ym_dout;
    else if (io_oki)                      cpu_din = oki_dout;
    else if (io_cmd)                      cpu_din = command_latch;
    else if (fixed_ready)                    cpu_din = fixed_q;
    else if (cpu_rom && cpu_rom_ready)     cpu_din = cpu_rom_data;
    else                                  cpu_din = 8'hff;
  end

  wire oki_phrase_start = cpu_write && io_oki && cpu_dout[7];

  // ------------------------------------------------------------- telemetry
  // Every observation point below is an existing board-local signal; this adds
  // no logic to any audio or CPU path.  cmd_overflow is tied low here: the
  // sound-CDC's sticky overflow lives on the host side and is reported there.
`ifdef TUNIT_DIAG
  tunit_audio_telemetry #(.CLK_HZ(12_000_000)) u_tel (
    .clk(clk), .rst(reset_pon),
    .cpu_e_en(cpu_e_en), .cpu_rom_wait(cpu_rom_wait),
    .cpu_write(cpu_write), .cpu_rnw(cpu_rnw), .cpu_addr(cpu_addr),
    .io_ym(io_ym), .io_dac(io_dac), .io_oki(io_oki), .io_cmd(io_cmd),
        // A phrase-start command is a write to the OKI port with din[7] set
    // (jt6295_ctrl.v:98-108); observing it on the CPU bus avoids a hierarchical
    // reference into the vendored core, which is not synthesis-safe.
    .board_reset(board_reset), .oki_start({3'b000, oki_phrase_start}),
    .cmd_overflow(1'b0),
    .ym_per_s(tel_ym_per_s), .firq_per_s(tel_firq_per_s),
    .dac_per_s(tel_dac_per_s), .oki_writes(tel_oki_writes),
    .e_rate_cpct(tel_e_rate_cpct), .romwait_pct(tel_romwait_pct),
    .cmd_reads(tel_cmd_reads), .misc(tel_misc), .tick(tel_tick));
`else
  // PRODUCTION CARRIES NO TELEMETRY.  This instance had no `ifdef` at all, so
  // every shipped image paid for ~190 registers of counters plus a 24-bit
  // window comparator in the 12 MHz domain that nothing downstream reads --
  // tunit_top ties audio_tel_* to the overlay only under TUNIT_DIAG.
  //
  // Normally Quartus would strip a dead cone like that.  It could NOT here:
  // the hold registers in tunit_audio_tel_cdc carry (* preserve *), added so
  // the name-based set_max_skew collection would attach, and preserve blocks
  // exactly the optimisation that would have removed them.  The diagnostic
  // aid and its constraint were together pinning dead logic into every
  // production fit, on a design that is one corner short at -0.074 ns.
  assign tel_ym_per_s = 16'd0; assign tel_firq_per_s = 16'd0;
  assign tel_dac_per_s = 16'd0; assign tel_oki_writes = 16'd0;
  assign tel_e_rate_cpct = 16'd0; assign tel_romwait_pct = 16'd0;
  assign tel_cmd_reads = 16'd0; assign tel_misc = 16'd0;
  assign tel_tick = 1'b0;
`endif

  // MAME board gains: YM L/R 0.10 each, 8-bit DAC 0.10, OKI 0.15.
  // Use a wide signed accumulator and saturate once, then duplicate the mono
  // board output. The constants are close integer approximations of the gains.
  logic signed [17:0] dac_signed, oki_signed;
  logic signed [31:0] ym_left_term, ym_right_term;
  logic signed [31:0] dac_term, oki_term;
  logic signed [31:0] mix;
  always_comb begin
    dac_signed = ($signed({1'b0, dac_data}) - 18'sd128) <<< 8;
    oki_signed = {{4{oki_sound[13]}}, oki_sound};
    // Keep each multiply wide through the scale shift. A 20-bit intermediate
    // wraps a full-scale DAC term before >>8 and inverts its sign.
    ym_left_term  = ($signed(ym_left)  * 32'sd26) >>> 8;
    ym_right_term = ($signed(ym_right) * 32'sd26) >>> 8;
    dac_term      = ($signed(dac_signed) * 32'sd26) >>> 8;
    // P0046: the OKI term was 24 dB too quiet.  YM and DAC are correct because
    // jt51's xleft/xright and the 8-bit DAC are already full-scale 16-bit
    // words, so 26/256 == MAME's 0.10 routes (williamssound.cpp:773,775).
    // jt6295 is NOT full-scale 16-bit: at att=0 gain_lut[0]==32 and
    // sound <= mul_VI[16:5] (jt6295_adpcm.v:161,184), so one voice arrives here
    // as a +-2048 word - the identical units as MAME's oki_adpcm_state::clock()
    // return.  MAME normalises ONE voice at max volume to full scale
    // (signal * volume/2 against 32768, volume max 0x20) and then applies the
    // 0.15 route (williamssound.cpp:781), i.e. +-2048 -> +-4915.  38/256 gave
    // +-304.  614/256 = 2.398 gives +-4912.  Four voices at max reach 19,644,
    // exactly MAME's own 0.6 headroom, so the saturator below is not newly hit.
    oki_term      = ($signed(oki_signed) * 32'sd614) >>> 8;
    mix = ym_left_term + ym_right_term + dac_term + oki_term;
    if (mix > 32'sd32767) begin
      audio_l = 16'sh7fff;
      audio_r = 16'sh7fff;
    end else if (mix < -32'sd32768) begin
      audio_l = -16'sh8000;
      audio_r = -16'sh8000;
    end else begin
      audio_l = mix[15:0];
      audio_r = mix[15:0];
    end
  end
endmodule
`default_nettype wire
