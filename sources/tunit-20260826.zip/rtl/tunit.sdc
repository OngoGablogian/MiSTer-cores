# T-unit board clocks, MT48LC16M16 pin timing, and narrowly scoped
# clock-enable/pipeline exceptions. Full-rate command-capture boundaries remain
# single-cycle timed.
create_generated_clock -name SDRAM_CLK \
  -source [get_pins -compatibility_mode {emu|pll|pll_inst|altera_pll_i|general[1].gpll~PLL_OUTPUT_COUNTER|divclk}] \
  [get_ports {SDRAM_CLK}]

set_input_delay  -clock SDRAM_CLK -max  6.0 [get_ports {SDRAM_DQ[*]}]
set_input_delay  -clock SDRAM_CLK -min  2.5 [get_ports {SDRAM_DQ[*]}]
set_output_delay -clock SDRAM_CLK -max  1.5 [get_ports {SDRAM_A* SDRAM_BA* SDRAM_D* SDRAM_CKE SDRAM_n*}]
set_output_delay -clock SDRAM_CLK -min -0.8 [get_ports {SDRAM_A* SDRAM_BA* SDRAM_D* SDRAM_CKE SDRAM_n*}]

set_multicycle_path -setup -end \
  -rise_from [get_clocks {SDRAM_CLK}] \
  -rise_to [get_clocks {emu|pll|pll_inst|altera_pll_i|general[0].gpll~PLL_OUTPUT_COUNTER|divclk}] 2

# The production exact-cycle scheduler advances the TMS34010 microengine on
# every 80 MHz edge while an instruction is active, then holds it between
# instructions until the MAME cycle budget expires. Consequently every active
# CPU, request, response, and I/O-command path must meet the ordinary one-clock
# requirement. The block below documents the retired fractional-enable timing
# model but is deliberately not evaluated. Keeping the literal false guard here
# makes any accidental reactivation an explicit source change rather than a
# silent match against similarly named optimized registers.
if {0} {
# The TMS34010 implementation advances at an average-exact 31.25 MHz cadence;
# the 125/320 fractional enable has a minimum spacing of two 80 MHz system clocks.
# Restrict the exception to CPU-enable registers. The registered I/O command
# boundary and the physical I/O/video register file live in the same hierarchy
# but clock at full rate (or on ce_pix), so explicitly remove them. Transfers
# to those blocks and to the full-rate memory/DMA system remain single-cycle.
set cpu_regs [get_registers {*tms34010_core:cpu|*}]
set cpu_io_command_regs [get_registers {
  *tms34010_io_write_boundary:u_io_write_boundary|*
}]
set cpu_live_io_regs [get_registers {
  *tms34010_io_regs:u_io_regs|*
}]
set cpu_full_rate_regs [add_to_collection $cpu_io_command_regs $cpu_live_io_regs]
if {[get_collection_size $cpu_full_rate_regs] == 0} {
  post_message -type error "T-unit full-rate CPU I/O exclusion collection is empty"
} else {
  post_message -type info "T-unit CPU multicycle excludes [get_collection_size $cpu_full_rate_regs] full-rate I/O/video registers"
  set cpu_regs [remove_from_collection $cpu_regs $cpu_full_rate_regs]
}
if {[get_collection_size $cpu_regs] == 0} {
  post_message -type error "T-unit CPU timing collection is empty"
} else {
  post_message -type info "T-unit CPU multicycle covers [get_collection_size $cpu_regs] registers"
}
set_multicycle_path -setup 2 -from $cpu_regs -to $cpu_regs
set_multicycle_path -hold  1 -from $cpu_regs -to $cpu_regs

# I/O writes are accepted only on a ce_cpu retirement edge after the held
# external transaction has acknowledged.  The registered command therefore
# has the same two-system-clock minimum launch spacing as the CPU datapath. Its
# output is consumed by the live I/O/video register file on the very next
# system edge, so only CPU-to-command capture receives this directed exception;
# command-to-live-I/O remains a normal single-cycle path.
if {[get_collection_size $cpu_io_command_regs] == 0} {
  post_message -type error "T-unit CPU I/O command timing collection is empty"
} else {
  post_message -type info "T-unit CPU I/O command multicycle covers [get_collection_size $cpu_io_command_regs] capture registers"
}
set_multicycle_path -setup 2 -from $cpu_regs -to $cpu_io_command_regs
set_multicycle_path -hold  1 -from $cpu_regs -to $cpu_io_command_regs

# An opcode is captured as CORE_FETCH retires, then passes through the
# mandatory CORE_DECODE and CORE_EXECUTE enable steps before a normal
# CORE_WRITEBACK can clock the architectural register file. With the CPU
# enable's minimum two-system-clock spacing, this specific path has six
# full system clocks. Earlier opcode consumers retain the general two-clock
# CPU constraint above.
set cpu_opcode_regs [get_registers {*tms34010_core:cpu|instr_word_q[*]}]
set cpu_arch_regs [get_registers {
  *tms34010_regfile:u_regfile|a_regs*
  *tms34010_regfile:u_regfile|b_regs*
  *tms34010_regfile:u_regfile|sp_q*
  *tms34010_core:cpu|instr_word_q*
  *tms34010_core:cpu|dsjs_delay_q*
  *tms34010_core:cpu|popped_st_q*
  *tms34010_core:cpu|popped_pc_q*
  *tms34010_core:cpu|pix_dest_q*
  *tms34010_core:cpu|mv_load_data_q*
  *tms34010_core:cpu|fill_dest_q*
  *tms34010_core:cpu|imm_hi_q*
  *tms34010_core:cpu|imm2_lo_q*
  *tms34010_core:cpu|imm2_hi_q*
  *tms34010_core:cpu|pblt_src_pix_q*
  *tms34010_core:cpu|pblt_dst_pix_q*
  *tms34010_core:cpu|drav_dest_q*
  *tms34010_core:cpu|pixt_inside_q*
  *tms34010_core:cpu|line_dest_q*
  *tms34010_core:cpu|io_is_io_q*
  *tms34010_pc:u_pc|pc_q*
  *tms34010_status_reg:u_status_reg|st_q*
  *tms34010_io_cpu_config:u_io_cpu_config|psize*
  *tms34010_io_cpu_config:u_io_cpu_config|convdp*
  *tms34010_io_cpu_config:u_io_cpu_config|convsp*
  *tms34010_io_cpu_config:u_io_cpu_config|control*
  *tms34010_io_cpu_config:u_io_cpu_config|pmask*
  *tms34010_io_cpu_config:u_io_cpu_config|dpyctl*
  *tms34010_io_cpu_status:u_io_cpu_status|intenb*
  *tms34010_io_cpu_status:u_io_cpu_status|intpend*
  *tms34010_io_cpu_status:u_io_cpu_status|hstctlh*
}]
if {[get_collection_size $cpu_opcode_regs] == 0 || [get_collection_size $cpu_arch_regs] == 0} {
  post_message -type error "T-unit opcode-to-register-file timing collection is empty"
} else {
  post_message -type info "T-unit opcode writeback multicycle covers [get_collection_size $cpu_arch_regs] architectural registers"
}
set_multicycle_path -setup 6 -from $cpu_opcode_regs -to $cpu_arch_regs
set_multicycle_path -hold  5 -from $cpu_opcode_regs -to $cpu_arch_regs

# A low immediate is fetched only after DECODE selects FETCH_IMM_LO. It cannot
# be captured before the second subsequent CPU-enable edge, or four system
# clocks after the opcode register. Higher/second immediates are covered by
# the longer architectural group above.
set cpu_imm_lo_regs [get_registers {*tms34010_core:cpu|imm_lo_q*}]
if {[get_collection_size $cpu_imm_lo_regs] == 0} {
  post_message -type error "T-unit low-immediate timing collection is empty"
}
set_multicycle_path -setup 4 -from $cpu_opcode_regs -to $cpu_imm_lo_regs
set_multicycle_path -hold  3 -from $cpu_opcode_regs -to $cpu_imm_lo_regs

# Decoded MOVE and MMTM/MMFM commands are captured only while CORE_EXECUTE
# retires. Starting from the CORE_FETCH edge that loads instr_word_q,
# CORE_DECODE and CORE_EXECUTE are two mandatory ce_cpu steps, or at least four
# full system clocks. This directed exception covers only those registered
# command boundaries; their outputs and all acknowledgement/response paths
# retain their normal one-cycle timing.
set cpu_move_command_regs [get_registers {
  *tms34010_core:cpu|move_mem_cmd_valid_q*
  *tms34010_core:cpu|move_mem_cmd_we_q*
  *tms34010_core:cpu|move_mem_cmd_addr_q*
  *tms34010_core:cpu|move_mem_cmd_size_q*
  *tms34010_core:cpu|move_mem_cmd_wdata_q*
  *tms34010_core:cpu|mm_mem_cmd_valid_q*
  *tms34010_core:cpu|mm_mem_cmd_we_q*
  *tms34010_core:cpu|mm_mem_cmd_addr_q*
  *tms34010_core:cpu|mm_mem_cmd_wdata_q*
}]
if {[get_collection_size $cpu_move_command_regs] == 0} {
  post_message -type error "T-unit CPU command timing collection is empty"
} else {
  post_message -type info "T-unit opcode-to-CPU-command multicycle covers [get_collection_size $cpu_move_command_regs] registers"
}
set_multicycle_path -setup 4 -from $cpu_opcode_regs -to $cpu_move_command_regs
set_multicycle_path -hold  3 -from $cpu_opcode_regs -to $cpu_move_command_regs

# The SAME registered command boundary, reached from the OTHER direction. The
# generic `-setup 2 -from $cpu_regs -to $cpu_regs` above is the fallback for
# every CPU-to-CPU path, and it is what currently governs the
# mem_op_step -> move-command family -- the worst CPU path in the last fit at
# -1.568 ns. That family is bounded far more strongly than 3, and the bound is
# DERIVED rather than sampled:
#
#   * Both endpoints are mem_ack-qualified. mem_op_step advances only inside the
#     CORE_MEMORY acknowledgement arm, and the command registers capture at
#     tms34010_core.sv:1807 under (move_mem_cmd_valid_q && mem_ack).
#   * mem_ack is cpu_ack_q, which SELF-CLEARS on every ce_cpu edge that consumes
#     it (tunit_memsys.sv:284-289), so mem_ack is unconditionally low for the
#     whole ce_cpu step after any consumption. Two ack-driven events therefore
#     cannot be closer than TWO ce_cpu steps.
#   * ce_cpu's minimum firing gap is 2 system clocks, DERIVED from the accumulator
#     arithmetic rather than sampled (tunit_top.sv:52-74). acc += 125 each clock and
#     fires at >= 320, so immediately after any fire acc = (acc_prev + 125) - 320
#     where acc_prev + 125 lies in [320,444], hence acc lies in [0,124]. From the
#     worst case acc = 124 the next fire needs 124+125k >= 320, i.e. k = 2
#     (124 -> 249 -> 374). From acc = 0 it needs k = 3. So the gap is 2 or 3
#     and NEVER 1, for every reachable accumulator state -- not merely for the
#     fires the spacing gate happened to observe. A measured minimum is a
#     minimum over visited cadences; post-reset, stall or mode-change cadences
#     could in principle be shorter and never appear in a sample.
#   => >= 2 steps x 2 clocks = 4 system clocks, for every instruction form,
#      independent of stimulus.
#
# Corroborating but NOT the basis: tools/run_tunit_spacing_gate.py measures this
# family at 13 (directed MOVE/MOVB/MMTM/MMFM sweep) and 28 (MK2 boot). Both
# exceed the derived floor. The ack structure is the justification; the
# measurement is only the cross-check. A sampled minimum alone would not be
# grounds -- that sample has just ONE distinct launching value, which is exactly
# the thin evidence this file was audited to remove.
#
# SCOPE. The source collection is mem_op_step ALONE, not $cpu_regs. The Wolf-unit
# session caught this before the first fit: move_mem_cmd_* has TWO capture arms --
# tms34010_core.sv:1753 on (state_q == CORE_EXECUTE && move_mem_cmd_class), which is
# NOT ack-qualified, and :1807 on (move_mem_cmd_valid_q && mem_ack), which is. The
# derivation above covers only the second. A `-from $cpu_regs` exception would have
# handed 4 cycles of window to every CPU register feeding the EXECUTE-issue arm on a
# justification that does not apply to it -- and that error is INVISIBLE in STA,
# because STA would simply report PASS. The EXECUTE arm keeps its own exception
# (opcode -> command, above) and its own separate justification. An exception must
# scope to exactly the set its argument covers, never to the set that happens to
# contain it.
#
# 4 is the DERIVED FLOOR, deliberately not the measured 13, and it is the same
# value the opcode-sourced exception above carries, for the same reason: both
# are bounded by the acknowledgement structure rather than by decode depth.
set cpu_memstep_regs [get_registers {*tms34010_core:cpu|mem_op_step*}]
if {[get_collection_size $cpu_memstep_regs] == 0} {
  post_message -type error "T-unit mem_op_step timing collection is empty"
} else {
  post_message -type info "T-unit memstep-to-CPU-command multicycle covers [get_collection_size $cpu_memstep_regs] source registers"
}
set_multicycle_path -setup 4 -from $cpu_memstep_regs -to $cpu_move_command_regs
set_multicycle_path -hold  3 -from $cpu_memstep_regs -to $cpu_move_command_regs

# The registered I/O command cannot capture until the decoded memory
# instruction has reached EXECUTE and its transaction retires.  DECODE and
# EXECUTE alone guarantee two ce_cpu intervals from opcode capture; request
# qualification and acknowledgement add further margin.
set_multicycle_path -setup 4 -from $cpu_opcode_regs -to $cpu_io_command_regs
set_multicycle_path -hold  3 -from $cpu_opcode_regs -to $cpu_io_command_regs

# A multiply result is captured in CORE_EXECUTE, after the mandatory DECODE
# step. Keep this shorter than the normal six-clock writeback exception.
set cpu_execute_capture_regs [get_registers {
  *tms34010_core:cpu|mpy_product_q*
  *tms34010_core:cpu|drav_linear_q*
  *tms34010_divider:u_divider|st_q*
  *tms34010_divider:u_divider|ovf_q*
  *tms34010_divider:u_divider|rem_q*
  *tms34010_divider:u_divider|quot_q*
  *tms34010_divider:u_divider|dvd_lo_q*
  *tms34010_divider:u_divider|divisor_q*
  *tms34010_divider:u_divider|iter_q*
}]
if {[get_collection_size $cpu_execute_capture_regs] == 0} {
  post_message -type error "T-unit execute-capture timing collection is empty"
}
set_multicycle_path -setup 4 -from $cpu_opcode_regs -to $cpu_execute_capture_regs
set_multicycle_path -hold  3 -from $cpu_opcode_regs -to $cpu_execute_capture_regs

# Non-MOVE memory requests likewise cannot become active before the
# CORE_EXECUTE edge, and the full-rate adapters capture them on a later system
# edge. Restrict the six-clock opcode exception to the two adapters' command
# capture registers. Adapter evolution, acknowledgement, response, and all
# non-opcode sources remain normally single-cycle timed.
set cpu_external_command_regs [get_registers {
  *tunit_memsys:memsys|tunit_mem:mapped|addr_q*
  *tunit_memsys:memsys|tunit_mem:mapped|wdata_q*
  *tunit_memsys:memsys|tunit_mem:mapped|size_q*
  *tunit_memsys:memsys|tunit_mem:mapped|we_q*
  *tunit_memsys:memsys|tunit_mem:mapped|target_q*
  *tunit_memsys:memsys|tunit_mem:mapped|state*
  *tunit_memsys:memsys|d_word_base*
  *tunit_memsys:memsys|d_bit_offset*
  *tunit_memsys:memsys|d_size*
  *tunit_memsys:memsys|d_wdata*
  *tunit_memsys:memsys|dstate*
}]
if {[get_collection_size $cpu_external_command_regs] == 0} {
  post_message -type error "T-unit external command timing collection is empty"
} else {
  post_message -type info "T-unit opcode-to-external-command multicycle covers [get_collection_size $cpu_external_command_regs] registers"
}

# tunit_memsys requires every newly asserted or atomically replaced CPU request
# to remain stable for four full system clocks before either adapter may
# capture it. request_age_q is cleared on the launch/retirement edge, advances
# 000->001->011->111 on the following edges, and request_ready is observed by
# the adapter only on the next edge. This is a hardware-enforced four-clock
# CPU-to-command budget, independent of the fractional ce_cpu spacing. Sources
# outside the ce_cpu domain remain normally timed.
set_multicycle_path -setup 4 -from $cpu_regs -to $cpu_external_command_regs
set_multicycle_path -hold  3 -from $cpu_regs -to $cpu_external_command_regs

# Opcode-dependent commands have already spent the mandatory DECODE and
# EXECUTE ce_cpu steps before the request-aging interval begins.
set_multicycle_path -setup 6 -from $cpu_opcode_regs -to $cpu_external_command_regs
set_multicycle_path -hold  5 -from $cpu_opcode_regs -to $cpu_external_command_regs

# Both memory adapters hold their registered response while cpu_ack_q samples
# completion on a ce_cpu edge. The core observes cpu_ack_q only on the following
# ce_cpu edge, at least two system clocks later. Keep the exception directed
# into the CPU domain; adapter-internal paths remain one-cycle.
set cpu_response_regs [get_registers {
  *tunit_memsys:memsys|cpu_ack_q*
  *tunit_memsys:memsys|dma_ack_q*
  *tunit_memsys:memsys|d_rdata*
  *tunit_memsys:memsys|tunit_mem:mapped|state*
  *tunit_memsys:memsys|tunit_mem:mapped|mem_rdata*
}]
if {[get_collection_size $cpu_response_regs] == 0} {
  post_message -type error "T-unit CPU response timing collection is empty"
} else {
  post_message -type info "T-unit response-to-CPU multicycle covers [get_collection_size $cpu_response_regs] source registers"
}
set_multicycle_path -setup 2 -from $cpu_response_regs -to $cpu_regs
set_multicycle_path -hold  1 -from $cpu_response_regs -to $cpu_regs
set_multicycle_path -setup 2 -from $cpu_response_regs -to $cpu_io_command_regs
set_multicycle_path -hold  1 -from $cpu_response_regs -to $cpu_io_command_regs

# cpu_ack_q changes on the ce_cpu edge that retires an adapter transaction.
# Any atomically replaced command clears request_age_q on that edge and cannot
# be captured by either adapter until the four-clock qualification sequence
# completes, so this source has the same hardware-enforced budget as the other
# CPU request fields.
set cpu_ack_regs [get_registers {*tunit_memsys:memsys|cpu_ack_q*}]
if {[get_collection_size $cpu_ack_regs] == 0} {
  post_message -type error "T-unit registered acknowledgement timing collection is empty"
}
set_multicycle_path -setup 4 -from $cpu_ack_regs -to $cpu_external_command_regs
set_multicycle_path -hold  3 -from $cpu_ack_regs -to $cpu_external_command_regs

# mm_mask_q changes only when a registered MMTM/MMFM command retires. Its next
# command is captured in mm_mem_cmd_* on that same ce_cpu edge; CORE_MEMORY
# drives the adapters exclusively from those registered command fields. Any
# direct mask-to-adapter path left by shared-mux synthesis is therefore
# functionally inactive.
set cpu_mm_mask_regs [get_registers {*tms34010_core:cpu|mm_mask_q*}]
if {[get_collection_size $cpu_mm_mask_regs] == 0} {
  post_message -type error "T-unit MMTM/MMFM mask timing collection is empty"
}
set_false_path -from $cpu_mm_mask_regs -to $cpu_external_command_regs

# mem_op_step advances only on an acknowledged multi-step memory transaction.
# If a replacement step subsequently writes a CPU I/O shadow, its capture is
# qualified by the next acknowledgement. cpu_ack_q self-clears when consumed,
# so two such events are separated by at least two ce_cpu steps; the derived
# two-system-clock minimum per step gives a four-clock floor. The source and
# destinations below are the only ack-forwarded CPU shadows in this path.
set cpu_io_shadow_regs [get_registers {
  *tms34010_io_cpu_config:u_io_cpu_config|psize*
  *tms34010_io_cpu_config:u_io_cpu_config|convdp*
  *tms34010_io_cpu_config:u_io_cpu_config|convsp*
  *tms34010_io_cpu_config:u_io_cpu_config|control*
  *tms34010_io_cpu_config:u_io_cpu_config|pmask*
  *tms34010_io_cpu_config:u_io_cpu_config|dpyctl*
  *tms34010_io_cpu_status:u_io_cpu_status|intenb*
  *tms34010_io_cpu_status:u_io_cpu_status|intpend*
  *tms34010_io_cpu_status:u_io_cpu_status|hstctlh*
}]
if {[get_collection_size $cpu_io_shadow_regs] == 0} {
  post_message -type error "T-unit CPU I/O shadow timing collection is empty"
} else {
  post_message -type info "T-unit memstep-to-I/O-shadow multicycle covers [get_collection_size $cpu_io_shadow_regs] registers"
}
set_multicycle_path -setup 4 -from $cpu_memstep_regs -to $cpu_io_shadow_regs
set_multicycle_path -hold  3 -from $cpu_memstep_regs -to $cpu_io_shadow_regs

# Every CPU-programmed I/O shadow capture is qualified by the retiring
# acknowledgement, not just the multi-step form above. tunit_memsys refuses
# to accept a new or atomically replaced request until request_age_q has
# completed its four-clock qualification sequence. Therefore any CPU-domain
# value feeding the shadow's address/data/enable mux has the same conservative
# four-clock floor. Keep the destination scoped to these ack-only shadows;
# ordinary CPU-to-CPU paths retain the general setup-2/hold-1 constraint.
set_multicycle_path -setup 4 -from $cpu_regs -to $cpu_io_shadow_regs
set_multicycle_path -hold  3 -from $cpu_regs -to $cpu_io_shadow_regs

# The full-rate I/O write boundary captures the same retiring transaction one
# stage before the CPU shadows above. For a multi-step replacement,
# mem_op_step was launched by the preceding acknowledgement and cannot be
# consumed here until the next one, giving the same derived four-clock floor.
set_multicycle_path -setup 4 -from $cpu_memstep_regs -to $cpu_io_command_regs
set_multicycle_path -hold  3 -from $cpu_memstep_regs -to $cpu_io_command_regs

# Internal I/O read data is snapshotted at the first full-rate edge after the
# request appears. An opcode cannot assert that request until it has traversed
# the mandatory DECODE and EXECUTE ce_cpu steps, whose derived minimum spacing
# is two system clocks each. Keep this four-clock exception on the snapshot
# registers only; later acknowledgement/response paths remain independently
# constrained.
set cpu_io_read_capture_regs [get_registers {
  *tms34010_core:cpu|io_rdata_req_q*
  *tms34010_core:cpu|io_rdata_req_valid_q*
}]
if {[get_collection_size $cpu_io_read_capture_regs] == 0} {
  post_message -type error "T-unit CPU I/O read-capture timing collection is empty"
} else {
  post_message -type info "T-unit opcode-to-I/O-read-capture multicycle covers [get_collection_size $cpu_io_read_capture_regs] registers"
}
set_multicycle_path -setup 4 -from $cpu_opcode_regs -to $cpu_io_read_capture_regs
set_multicycle_path -hold  3 -from $cpu_opcode_regs -to $cpu_io_read_capture_regs

# request_age_q sees a decoded memory request only after the opcode has crossed
# the mandatory DECODE and EXECUTE CPU-enable steps. Its first capture is on a
# later full-rate edge, so four clocks is a conservative bound (the actual
# minimum is five). This exception is opcode-only: state_q can assert mem_req
# immediately after its own launch and therefore remains single-cycle into the
# request-age register.
set cpu_request_age_regs [get_registers {
  *tunit_memsys:memsys|request_age_q*
}]
if {[get_collection_size $cpu_request_age_regs] == 0} {
  post_message -type error "T-unit request-age timing collection is empty"
} else {
  post_message -type info "T-unit opcode-to-request-age multicycle covers [get_collection_size $cpu_request_age_regs] registers"
}
set_multicycle_path -setup 4 -from $cpu_opcode_regs -to $cpu_request_age_regs
set_multicycle_path -hold  3 -from $cpu_opcode_regs -to $cpu_request_age_regs

# Quartus 17 infers srt_buf as a dual-port altsyncram and does not expose its
# internal write pins as TimeQuest keepers. Do not invent a collection merely
# to preserve the former opcode-to-register exception: every SRT RAM path keeps
# the normal one-system-clock requirement. The RTL/map gates independently
# require the 1024x16 inferred RAM and its board-visible transfer behavior.
}

# ---- exact-scheduler full-rate CPU pipeline boundaries --------------------
# Production advances active CPU microsteps on every 80 MHz edge. The decoder
# now terminates at registered `decoded`, so ordinary CPU-to-CPU paths remain
# single-cycle timed. Only the explicit hardware protocols below receive more
# than one edge.
set exact_cpu_regs [get_registers -nowarn {*tms34010_core:cpu|*}]
set exact_opcode_regs [get_registers -nowarn {*tms34010_core:cpu|instr_word_q*}]
set exact_decoded_regs [get_registers -nowarn {*tms34010_core:cpu|decoded*}]
set exact_cpu_nondecode_regs [remove_from_collection $exact_cpu_regs $exact_decoded_regs]
set exact_external_command_regs [get_registers -nowarn {
  *tunit_memsys:memsys|tunit_mem:mapped|addr_q*
  *tunit_memsys:memsys|tunit_mem:mapped|wdata_q*
  *tunit_memsys:memsys|tunit_mem:mapped|size_q*
  *tunit_memsys:memsys|tunit_mem:mapped|we_q*
  *tunit_memsys:memsys|tunit_mem:mapped|target_q*
  *tunit_memsys:memsys|tunit_mem:mapped|state*
  *tunit_memsys:memsys|d_word_base*
  *tunit_memsys:memsys|d_bit_offset*
  *tunit_memsys:memsys|d_size*
  *tunit_memsys:memsys|d_wdata*
  *tunit_memsys:memsys|dstate*
}]
set exact_io_read_regs [get_registers -nowarn {
  *tms34010_core:cpu|io_rdata_req_q*
  *tms34010_core:cpu|io_rdata_req_valid_q*
}]
set exact_io_ack_regs [get_registers -nowarn {
  *tms34010_io_write_boundary:u_io_write_boundary|*
  *tms34010_core:cpu|io_rdata_q*
  *tms34010_core:cpu|io_is_io_q*
}]
set exact_io_shadow_regs [get_registers -nowarn {
  *tms34010_io_cpu_config:u_io_cpu_config|*
  *tms34010_io_cpu_status:u_io_cpu_status|*
}]
set exact_pc_writeback_regs [get_registers -nowarn {
  *tms34010_pc:u_pc|pc_q*
}]
set exact_move_command_regs [get_registers -nowarn {
  *tms34010_core:cpu|move_mem_cmd_*_q*
}]
set exact_execute_capture_regs [get_registers -nowarn {
  *tms34010_core:cpu|mpy_product_q*
  *tms34010_core:cpu|move_mem_cmd_*_q*
  *tms34010_core:cpu|gfx_timing_saddr_raw_q*
  *tms34010_core:cpu|gfx_timing_daddr_raw_q*
  *tms34010_core:cpu|pixt_ptr_q*
}]
set exact_late_execute_capture_regs [get_registers -nowarn {
  *tms34010_core:cpu|mm_mem_cmd_*_q*
  *tms34010_core:cpu|drav_linear_q*
  *tms34010_core:cpu|pixt_inside_q*
  *tms34010_core:cpu|io_rdata_req_age_q*
  *tms34010_core:cpu|div_dvd_sign_q*
  *tms34010_core:cpu|div_dvs_sign_q*
  *tms34010_divider:u_divider|st_q*
  *tms34010_divider:u_divider|ovf_q*
}]
set exact_arch_writeback_regs [get_registers -nowarn {
  *tms34010_regfile:u_regfile|a_regs*
  *tms34010_regfile:u_regfile|b_regs*
  *tms34010_regfile:u_regfile|sp_q*
  *tms34010_status_reg:u_status_reg|st_q*
}]
set exact_instr_psize_regs [get_registers -nowarn {
  *tms34010_core:cpu|instr_psize_q*
}]
set exact_instr_convdp_regs [get_registers -nowarn {*tms34010_core:cpu|instr_convdp_q*}]
set exact_instr_convsp_regs [get_registers -nowarn {*tms34010_core:cpu|instr_convsp_q*}]
set exact_instr_control_regs [get_registers -nowarn {*tms34010_core:cpu|instr_control_q*}]
set exact_instr_pmask_regs [get_registers -nowarn {*tms34010_core:cpu|instr_pmask_q*}]
set exact_instr_dpyctl_regs [get_registers -nowarn {*tms34010_core:cpu|instr_dpyctl_q*}]
set exact_instr_gfx_config_regs $exact_instr_psize_regs
set exact_instr_gfx_config_regs [add_to_collection $exact_instr_gfx_config_regs $exact_instr_convdp_regs]
set exact_instr_gfx_config_regs [add_to_collection $exact_instr_gfx_config_regs $exact_instr_convsp_regs]
set exact_instr_gfx_config_regs [add_to_collection $exact_instr_gfx_config_regs $exact_instr_control_regs]
set exact_instr_gfx_config_regs [add_to_collection $exact_instr_gfx_config_regs $exact_instr_pmask_regs]
set exact_instr_gfx_config_regs [add_to_collection $exact_instr_gfx_config_regs $exact_instr_dpyctl_regs]
set exact_regfile_writeback_regs [get_registers -nowarn {
  *tms34010_regfile:u_regfile|a_regs*
  *tms34010_regfile:u_regfile|b_regs*
  *tms34010_regfile:u_regfile|sp_q*
}]
set exact_immediate_regs [get_registers -nowarn {
  *tms34010_core:cpu|imm_lo_q*
  *tms34010_core:cpu|imm_hi_q*
  *tms34010_core:cpu|imm2_lo_q*
  *tms34010_core:cpu|imm2_hi_q*
}]
set exact_interrupt_shadow_regs [get_registers -nowarn {
  *tms34010_io_cpu_status:u_io_cpu_status|intenb*
  *tms34010_io_cpu_status:u_io_cpu_status|intpend*
  *tms34010_io_cpu_status:u_io_cpu_status|hstctlh*
}]
set exact_mm_mask_regs [get_registers -nowarn {
  *tms34010_core:cpu|mm_mask_q*
}]
set exact_mm_command_regs [get_registers -nowarn {
  *tms34010_core:cpu|mm_mem_cmd_*_q*
}]
set exact_ppop_capture_regs [get_registers -nowarn {
  *tms34010_core:cpu|fill_processed_q*
  *tms34010_core:cpu|pblt_processed_q*
  *tms34010_core:cpu|drav_processed_q*
  *tms34010_core:cpu|line_processed_q*
  *tms34010_core:cpu|pixt_processed_q*
}]
set exact_fill_ppop_source_regs [get_registers -nowarn {
  *tms34010_core:cpu|fill_dest_q*
  *tms34010_core:cpu|fill_color_q*
}]
set exact_pblt_ppop_source_regs [get_registers -nowarn {
  *tms34010_core:cpu|pblt_src_pix_q*
  *tms34010_core:cpu|pblt_dst_pix_q*
  *tms34010_core:cpu|pblt_color0_q*
  *tms34010_core:cpu|pblt_color1_q*
}]
set exact_drav_ppop_source_regs [get_registers -nowarn {
  *tms34010_core:cpu|drav_dest_q*
  *tms34010_core:cpu|drav_color_q*
}]
set exact_line_ppop_source_regs [get_registers -nowarn {
  *tms34010_core:cpu|line_dest_q*
  *tms34010_core:cpu|line_color_q*
}]
set exact_pixt_ppop_source_regs [get_registers -nowarn {
  *tms34010_core:cpu|pix_dest_q*
}]
set exact_move_wdata_regs [get_registers -nowarn {
  *tms34010_core:cpu|move_mem_cmd_wdata_q*
}]
set exact_fill_ppop_target_regs [get_registers -nowarn {*tms34010_core:cpu|fill_processed_q*}]
set exact_pblt_ppop_target_regs [get_registers -nowarn {*tms34010_core:cpu|pblt_processed_q*}]
set exact_drav_ppop_target_regs [get_registers -nowarn {*tms34010_core:cpu|drav_processed_q*}]
set exact_line_ppop_target_regs [get_registers -nowarn {*tms34010_core:cpu|line_processed_q*}]
set exact_pixt_ppop_target_regs [get_registers -nowarn {*tms34010_core:cpu|pixt_processed_q*}]
set exact_instruction_operand_regs [get_registers -nowarn {
  *tms34010_core:cpu|fill_*_q*
  *tms34010_core:cpu|pblt_*_q*
  *tms34010_core:cpu|drav_*_q*
  *tms34010_core:cpu|line_*_q*
  *tms34010_core:cpu|mv_load_data_q*
  *tms34010_core:cpu|mm_rp_q*
  *tms34010_core:cpu|mm_mask_q*
  *tms34010_core:cpu|gfx_timing_*_snap_q*
  *tms34010_divider:u_divider|dvd_lo_q*
  *tms34010_divider:u_divider|divisor_q*
  *tms34010_divider:u_divider|rem_q*
  *tms34010_divider:u_divider|st_q*
  *tms34010_divider:u_divider|ovf_q*
}]
set exact_divider_operand_regs [get_registers -nowarn {
  *tms34010_divider:u_divider|dvd_lo_q*
  *tms34010_divider:u_divider|divisor_q*
  *tms34010_divider:u_divider|rem_q*
}]
set exact_div_sign_regs [get_registers -nowarn {
  *tms34010_core:cpu|div_dvd_sign_q*
  *tms34010_core:cpu|div_dvs_sign_q*
}]
set exact_retire_aux_regs [get_registers -nowarn {
  *tms34010_core:cpu|dsjs_delay_q*
  *tms34010_core:cpu|prev_wb_nop_q*
  *tms34010_core:cpu|instruction_active_q*
  *tms34010_core:cpu|timing_interrupt_q*
}]
# Quartus re-encodes this binary FSM into one literal-named register per
# reachable state.  Keep every setup-state collection separate so a renamed or
# optimized-away state fails closed instead of silently weakening the exception
# below.  These are the operand/window-capture states only; draw, hit/miss,
# writeback, and retirement states are intentionally absent.
set exact_fill_setup_state_regs [get_registers -nowarn {
  *tms34010_core:cpu|state_q.001001*
}]
set exact_pblt_setup_state_regs [get_registers -nowarn {
  *tms34010_core:cpu|state_q.001100*
}]
set exact_pblt_setup2_state_regs [get_registers -nowarn {
  *tms34010_core:cpu|state_q.010000*
}]
set exact_fill_setup_win_state_regs [get_registers -nowarn {
  *tms34010_core:cpu|state_q.010101*
}]
set exact_pblt_setup_win_state_regs [get_registers -nowarn {
  *tms34010_core:cpu|state_q.010110*
}]
set exact_drav_setup_win_state_regs [get_registers -nowarn {
  *tms34010_core:cpu|state_q.011100*
}]
set exact_line_setup1_state_regs [get_registers -nowarn {
  *tms34010_core:cpu|state_q.011101*
}]
set exact_line_setup2_state_regs [get_registers -nowarn {
  *tms34010_core:cpu|state_q.011110*
}]
set exact_line_setup3_state_regs [get_registers -nowarn {
  *tms34010_core:cpu|state_q.011111*
}]
set exact_line_linear_state_regs [get_registers -nowarn {
  *tms34010_core:cpu|state_q.101110*
}]
set exact_line_setup_win_state_regs [get_registers -nowarn {
  *tms34010_core:cpu|state_q.100100*
}]
set exact_pixt_setup_win_state_regs [get_registers -nowarn {
  *tms34010_core:cpu|state_q.100101*
}]
set exact_drav_draw_state_regs [get_registers -nowarn {
  *tms34010_core:cpu|state_q.011011*
}]
set exact_memory_state_regs [get_registers -nowarn {
  *tms34010_core:cpu|state_q.000110*
}]
set exact_int_push_st_state_regs [get_registers -nowarn {
  *tms34010_core:cpu|state_q.010001*
}]
set exact_fill_setup_inactive_regs [get_registers -nowarn {
  *tms34010_core:cpu|pblt_src_addr_q*
  *tms34010_core:cpu|pblt_dst_addr_q*
  *tms34010_core:cpu|pblt_src_row_q*
  *tms34010_core:cpu|pblt_dst_row_q*
}]
set exact_line_setup1_inactive_regs [get_registers -nowarn {
  *tms34010_core:cpu|fill_addr_q*
  *tms34010_core:cpu|fill_row_base_q*
  *tms34010_core:cpu|pblt_src_addr_q*
  *tms34010_core:cpu|pblt_dst_addr_q*
  *tms34010_core:cpu|pblt_src_row_q*
  *tms34010_core:cpu|pblt_dst_row_q*
  *tms34010_core:cpu|line_linear_q*
  *tms34010_core:cpu|mm_rp_q*
  *tms34010_core:cpu|line_inc2_q*
  *tms34010_divider:u_divider|dvd_lo_q*
  *tms34010_divider:u_divider|rem_q*
}]
set exact_line_setup2_inactive_regs [get_registers -nowarn {
  *tms34010_core:cpu|mm_rp_q*
  *tms34010_core:cpu|line_linear_q*
  *tms34010_core:cpu|pblt_src_row_q*
  *tms34010_divider:u_divider|dvd_lo_q*
  *tms34010_divider:u_divider|rem_q*
}]
set exact_line_setup3_inactive_regs [get_registers -nowarn {
  *tms34010_core:cpu|line_linear_q*
  *tms34010_core:cpu|line_d_q*
  *tms34010_core:cpu|drav_rs_q*
}]
set exact_line_setup_state_regs $exact_line_setup1_state_regs
set exact_line_setup_state_regs [add_to_collection $exact_line_setup_state_regs $exact_line_setup2_state_regs]
set exact_line_setup_state_regs [add_to_collection $exact_line_setup_state_regs $exact_line_setup3_state_regs]
set exact_line_setup_state_regs [add_to_collection $exact_line_setup_state_regs $exact_line_linear_state_regs]
set exact_line_setup_state_regs [add_to_collection $exact_line_setup_state_regs $exact_line_setup_win_state_regs]
set exact_gfx_setup_state_regs $exact_fill_setup_state_regs
set exact_gfx_setup_state_regs [add_to_collection $exact_gfx_setup_state_regs $exact_pblt_setup_state_regs]
set exact_gfx_setup_state_regs [add_to_collection $exact_gfx_setup_state_regs $exact_pblt_setup2_state_regs]
set exact_gfx_setup_state_regs [add_to_collection $exact_gfx_setup_state_regs $exact_fill_setup_win_state_regs]
set exact_gfx_setup_state_regs [add_to_collection $exact_gfx_setup_state_regs $exact_pblt_setup_win_state_regs]
set exact_gfx_setup_state_regs [add_to_collection $exact_gfx_setup_state_regs $exact_drav_setup_win_state_regs]
set exact_gfx_setup_state_regs [add_to_collection $exact_gfx_setup_state_regs $exact_line_setup_state_regs]
set exact_gfx_setup_state_regs [add_to_collection $exact_gfx_setup_state_regs $exact_pixt_setup_win_state_regs]
set exact_gfx_snapshot_regs [get_registers -nowarn {
  *tms34010_core:cpu|gfx_timing_*_snap_q*
}]
set exact_gfx_counter_regs [get_registers -nowarn {
  *tms34010_gfx_cycle_counter:u_gfx_cycle_counter|*
}]
set exact_scheduler_retire_regs [get_registers -nowarn {
  *tunit_cpu_cycle_scheduler:u_cpu_scheduler|target_q*
  *tunit_cpu_cycle_scheduler:u_cpu_scheduler|permit_q*
}]
set exact_dma_o_regs [get_registers -nowarn {
  *midway_dma:dma|o_r*
}]
set exact_dma_cadence_regs [get_registers -nowarn {
  *midway_dma:dma|cadence_phase_r*
  *midway_dma:dma|cadence_x_rem_r*
  *midway_dma:dma|cadence_y_rem_r*
  *midway_dma:dma|cadence_valid_r
}]
if {[get_collection_size $exact_cpu_regs] == 0 ||
    [get_collection_size $exact_cpu_nondecode_regs] == 0 ||
    [get_collection_size $exact_opcode_regs] == 0 ||
    [get_collection_size $exact_decoded_regs] == 0 ||
    [get_collection_size $exact_external_command_regs] == 0 ||
    [get_collection_size $exact_io_read_regs] == 0 ||
    [get_collection_size $exact_io_ack_regs] == 0 ||
    [get_collection_size $exact_io_shadow_regs] == 0 ||
    [get_collection_size $exact_pc_writeback_regs] == 0 ||
    [get_collection_size $exact_move_command_regs] == 0 ||
    [get_collection_size $exact_execute_capture_regs] == 0 ||
    [get_collection_size $exact_late_execute_capture_regs] == 0 ||
    [get_collection_size $exact_arch_writeback_regs] == 0 ||
    [get_collection_size $exact_instr_psize_regs] == 0 ||
    [get_collection_size $exact_instr_convdp_regs] == 0 ||
    [get_collection_size $exact_instr_convsp_regs] == 0 ||
    [get_collection_size $exact_instr_control_regs] == 0 ||
    [get_collection_size $exact_instr_pmask_regs] == 0 ||
    [get_collection_size $exact_instr_dpyctl_regs] == 0 ||
    [get_collection_size $exact_instr_gfx_config_regs] == 0 ||
    [get_collection_size $exact_regfile_writeback_regs] == 0 ||
    [get_collection_size $exact_immediate_regs] == 0 ||
    [get_collection_size $exact_interrupt_shadow_regs] == 0 ||
    [get_collection_size $exact_mm_mask_regs] == 0 ||
    [get_collection_size $exact_mm_command_regs] == 0 ||
    [get_collection_size $exact_ppop_capture_regs] == 0 ||
    [get_collection_size $exact_fill_ppop_source_regs] == 0 ||
    [get_collection_size $exact_pblt_ppop_source_regs] == 0 ||
    [get_collection_size $exact_drav_ppop_source_regs] == 0 ||
    [get_collection_size $exact_line_ppop_source_regs] == 0 ||
    [get_collection_size $exact_pixt_ppop_source_regs] == 0 ||
    [get_collection_size $exact_move_wdata_regs] == 0 ||
    [get_collection_size $exact_fill_ppop_target_regs] == 0 ||
    [get_collection_size $exact_pblt_ppop_target_regs] == 0 ||
    [get_collection_size $exact_drav_ppop_target_regs] == 0 ||
    [get_collection_size $exact_line_ppop_target_regs] == 0 ||
    [get_collection_size $exact_pixt_ppop_target_regs] == 0 ||
    [get_collection_size $exact_instruction_operand_regs] == 0 ||
    [get_collection_size $exact_divider_operand_regs] == 0 ||
    [get_collection_size $exact_div_sign_regs] == 0 ||
    [get_collection_size $exact_retire_aux_regs] == 0 ||
    [get_collection_size $exact_fill_setup_state_regs] == 0 ||
    [get_collection_size $exact_pblt_setup_state_regs] == 0 ||
    [get_collection_size $exact_pblt_setup2_state_regs] == 0 ||
    [get_collection_size $exact_fill_setup_win_state_regs] == 0 ||
    [get_collection_size $exact_pblt_setup_win_state_regs] == 0 ||
    [get_collection_size $exact_drav_setup_win_state_regs] == 0 ||
    [get_collection_size $exact_line_setup1_state_regs] == 0 ||
    [get_collection_size $exact_line_setup2_state_regs] == 0 ||
    [get_collection_size $exact_line_setup3_state_regs] == 0 ||
    [get_collection_size $exact_line_linear_state_regs] == 0 ||
    [get_collection_size $exact_line_setup_win_state_regs] == 0 ||
    [get_collection_size $exact_pixt_setup_win_state_regs] == 0 ||
    [get_collection_size $exact_drav_draw_state_regs] == 0 ||
    [get_collection_size $exact_memory_state_regs] == 0 ||
    [get_collection_size $exact_int_push_st_state_regs] == 0 ||
    [get_collection_size $exact_fill_setup_inactive_regs] == 0 ||
    [get_collection_size $exact_line_setup1_inactive_regs] == 0 ||
    [get_collection_size $exact_line_setup2_inactive_regs] == 0 ||
    [get_collection_size $exact_line_setup3_inactive_regs] == 0 ||
    [get_collection_size $exact_gfx_snapshot_regs] == 0 ||
    [get_collection_size $exact_gfx_counter_regs] == 0 ||
    [get_collection_size $exact_scheduler_retire_regs] == 0 ||
    [get_collection_size $exact_dma_o_regs] == 0 ||
    [get_collection_size $exact_dma_cadence_regs] == 0} {
  post_message -type error "T-unit exact-scheduler pipeline timing collection is empty"
}

# External adapter command capture remains single-cycle timed. Internal I/O
# read data uses its own explicit age bit. Response/I/O-write
# capture occurs still later, after the registered adapter has acknowledged;
# use the same conservative two-clock floor rather than the larger observation.
set_multicycle_path -setup 2 -from $exact_cpu_nondecode_regs -to $exact_io_read_regs
set_multicycle_path -hold  1 -from $exact_cpu_nondecode_regs -to $exact_io_read_regs
set_multicycle_path -setup 2 -from $exact_cpu_nondecode_regs -to $exact_io_ack_regs
set_multicycle_path -hold  1 -from $exact_cpu_nondecode_regs -to $exact_io_ack_regs
set_multicycle_path -setup 2 -from $exact_cpu_nondecode_regs -to $exact_io_shadow_regs
set_multicycle_path -hold  1 -from $exact_cpu_nondecode_regs -to $exact_io_shadow_regs

# decoded launches as DECODE retires.  The following edge performs only
# DECODE_DISPATCH; the next edge enters EXECUTE; and the earliest architected
# command, I/O-shadow, or PC writeback capture is the third edge.  Keep the
# dispatch/state/illegal consumers at their ordinary one-clock requirement and
# grant only these three proven endpoint families the exact three-clock
# lifetime of the held registered decode image.
set_multicycle_path -setup 3 -from $exact_decoded_regs -to $exact_external_command_regs
set_multicycle_path -hold  2 -from $exact_decoded_regs -to $exact_external_command_regs
set_multicycle_path -setup 3 -from $exact_decoded_regs -to $exact_io_shadow_regs
set_multicycle_path -hold  2 -from $exact_decoded_regs -to $exact_io_shadow_regs
set_multicycle_path -setup 3 -from $exact_decoded_regs -to $exact_io_ack_regs
set_multicycle_path -hold  2 -from $exact_decoded_regs -to $exact_io_ack_regs
set_multicycle_path -setup 3 -from $exact_decoded_regs -to $exact_pc_writeback_regs
set_multicycle_path -hold  2 -from $exact_decoded_regs -to $exact_pc_writeback_regs

# EXECUTE captures the registered multiply result and the complete held MOVE
# command on E3, exactly two clocks after decoded launches on E1.  Ordinary
# architectural A/B/SP/ST writeback is one edge later on E4.  These endpoint
# families are explicit because leaving either as a nominal one-clock path
# asks Quartus to time a protocol edge that cannot capture that value.
set_multicycle_path -setup 2 -from $exact_decoded_regs -to $exact_execute_capture_regs
set_multicycle_path -hold  1 -from $exact_decoded_regs -to $exact_execute_capture_regs
# MMTM/MMFM command payload, DRAV's converted address, and PIXT's remembered
# compare result are later EXECUTE-family captures.  `decoded` launches on E1,
# E2 is unconditionally DECODE_DISPATCH, and the earliest of these registers
# can consume it on E3.  Keep this separate from unrelated divider/I/O-age
# registers so the exception is exactly the observed decode cone.
set_multicycle_path -setup 2 -from $exact_decoded_regs -to $exact_late_execute_capture_regs
set_multicycle_path -hold  1 -from $exact_decoded_regs -to $exact_late_execute_capture_regs
# An internal I/O snapshot follows EXECUTE's request and a dedicated age edge;
# decoded therefore has three full edges before this exact capture family.
set_multicycle_path -setup 3 -from $exact_decoded_regs -to $exact_io_read_regs
set_multicycle_path -hold  2 -from $exact_decoded_regs -to $exact_io_read_regs
set_multicycle_path -setup 2 -from $exact_decoded_regs -to $exact_ppop_capture_regs
set_multicycle_path -hold  1 -from $exact_decoded_regs -to $exact_ppop_capture_regs
set_multicycle_path -setup 2 -from $exact_decoded_regs -to $exact_instruction_operand_regs
set_multicycle_path -hold  1 -from $exact_decoded_regs -to $exact_instruction_operand_regs
set_multicycle_path -setup 3 -from $exact_decoded_regs -to $exact_arch_writeback_regs
set_multicycle_path -hold  2 -from $exact_decoded_regs -to $exact_arch_writeback_regs
set_multicycle_path -setup 3 -from $exact_decoded_regs -to $exact_retire_aux_regs
set_multicycle_path -hold  2 -from $exact_decoded_regs -to $exact_retire_aux_regs

# instr_word_q is captured one edge before decoded.  The same three endpoint
# families therefore see a four-clock held-opcode lifetime: DECODE,
# DECODE_DISPATCH, EXECUTE, then the earliest command/writeback capture.
set_multicycle_path -setup 4 -from $exact_opcode_regs -to $exact_external_command_regs
set_multicycle_path -hold  3 -from $exact_opcode_regs -to $exact_external_command_regs
set_multicycle_path -setup 4 -from $exact_opcode_regs -to $exact_io_shadow_regs
set_multicycle_path -hold  3 -from $exact_opcode_regs -to $exact_io_shadow_regs
set_multicycle_path -setup 4 -from $exact_opcode_regs -to $exact_pc_writeback_regs
set_multicycle_path -hold  3 -from $exact_opcode_regs -to $exact_pc_writeback_regs
set_multicycle_path -setup 3 -from $exact_opcode_regs -to $exact_execute_capture_regs
set_multicycle_path -hold  2 -from $exact_opcode_regs -to $exact_execute_capture_regs
set_multicycle_path -setup 3 -from $exact_opcode_regs -to $exact_ppop_capture_regs
set_multicycle_path -hold  2 -from $exact_opcode_regs -to $exact_ppop_capture_regs
set_multicycle_path -setup 4 -from $exact_opcode_regs -to $exact_arch_writeback_regs
set_multicycle_path -hold  3 -from $exact_opcode_regs -to $exact_arch_writeback_regs
set_multicycle_path -setup 4 -from $exact_opcode_regs -to $exact_retire_aux_regs
set_multicycle_path -hold  3 -from $exact_opcode_regs -to $exact_retire_aux_regs

# Architected A/B/SP/ST values cannot be produced and consumed by a new
# instruction on adjacent 80 MHz edges: FETCH, registered DECODE, and mandatory
# DECODE_DISPATCH separate writeback from the next command.  Within one
# instruction the selected operands are held until retirement.  Give only the
# explicit command/capture/writeback families that two-clock minimum; status
# evaluation and ordinary local state remain single-cycle timed.
foreach arch_endpoint [list \
    $exact_external_command_regs $exact_pc_writeback_regs \
    $exact_execute_capture_regs $exact_late_execute_capture_regs \
    $exact_ppop_capture_regs $exact_arch_writeback_regs \
    $exact_retire_aux_regs $exact_scheduler_retire_regs] {
  set_multicycle_path -setup 2 -from $exact_arch_writeback_regs -to $arch_endpoint
  set_multicycle_path -hold  1 -from $exact_arch_writeback_regs -to $arch_endpoint
}

# Immediate words are captured before EXECUTE. A command or writeback that
# uses them follows the registered execute boundary, never the next edge.
foreach immediate_endpoint [list \
    $exact_external_command_regs $exact_pc_writeback_regs \
    $exact_mm_command_regs $exact_arch_writeback_regs \
    $exact_scheduler_retire_regs] {
  set_multicycle_path -setup 2 -from $exact_immediate_regs -to $immediate_endpoint
  set_multicycle_path -hold  1 -from $exact_immediate_regs -to $immediate_endpoint
}

# An on-chip I/O read snapshot is captured only after the request has spent a
# full edge in io_rdata_req_age_q.  The held mapped/DMA transaction then
# completes on a later adapter edge.  A multi-step MOVE can copy that snapshot
# into its replacement write command only on acknowledgement, never on the
# adjacent edge after the snapshot launches.
set_multicycle_path -setup 2 -from $exact_io_read_regs -to $exact_move_command_regs
set_multicycle_path -hold  1 -from $exact_io_read_regs -to $exact_move_command_regs
# The same aged request snapshot reaches architectural writeback only after the
# registered external adapter completes and CORE_MEMORY retires. MMFM's direct
# pop write is still separated from the snapshot launch by the adapter route.
set_multicycle_path -setup 2 -from $exact_io_read_regs -to $exact_arch_writeback_regs
set_multicycle_path -hold  1 -from $exact_io_read_regs -to $exact_arch_writeback_regs

# Signed-divide operand signs are captured at EXECUTE and held for the complete
# iterative divide. Architectural quotient/remainder writeback cannot occur on
# the adjacent edge; keep the ordinary divider iteration paths single-cycle.
set_multicycle_path -setup 2 -from $exact_div_sign_regs -to $exact_arch_writeback_regs
set_multicycle_path -hold  1 -from $exact_div_sign_regs -to $exact_arch_writeback_regs

# MAME executes each graphics instruction atomically. PSIZE, CONVDP, CONVSP,
# CONTROL, PMASK, and DPYCTL.SRT are therefore snapshotted beside `decoded` in
# CORE_DECODE. DECODE_DISPATCH is the mandatory following edge, so none of the
# listed command, pixel-result, operand, or writeback registers can consume a
# snapshot in fewer than two clocks. Live I/O readback remains ordinarily
# timed; a graphics write crossing the I/O window cannot mutate its own loop.
foreach gfx_config_endpoint [list \
    $exact_external_command_regs $exact_move_command_regs \
    $exact_ppop_capture_regs $exact_instruction_operand_regs \
    $exact_arch_writeback_regs] {
  set_multicycle_path -setup 2 -from $exact_instr_gfx_config_regs -to $gfx_config_endpoint
  set_multicycle_path -hold  1 -from $exact_instr_gfx_config_regs -to $gfx_config_endpoint
}

# CORE_DRAV and a valid held MOVE command are mutually exclusive decode
# classes.  DRAV can issue its own real read/write command, so cut only the
# impossible state-27 arm of the MOVE payload mux; every DRAV path to the board
# command and every MOVE data path from its genuine sources remains timed.
set_false_path -from $exact_drav_draw_state_regs -to $exact_move_command_regs
set_false_path -from $exact_drav_draw_state_regs -to $exact_arch_writeback_regs

# FILL, PIXBLT, DRAV, LINE, and PIXT share one PPOP implementation, selected by
# disjoint registered instruction classes. Each client's held source operands
# can reach only its own processed-result capture; PIXT alone can reach the
# MOVE write-payload register. Cut only the cross-client source/target pairs.
# Every real client-to-own-result path remains normally single-cycle timed.
foreach target [list \
    $exact_pblt_ppop_target_regs $exact_drav_ppop_target_regs \
    $exact_line_ppop_target_regs $exact_pixt_ppop_target_regs \
    $exact_move_wdata_regs] {
  set_false_path -from $exact_fill_ppop_source_regs -to $target
}
foreach target [list \
    $exact_fill_ppop_target_regs $exact_drav_ppop_target_regs \
    $exact_line_ppop_target_regs $exact_pixt_ppop_target_regs \
    $exact_move_wdata_regs] {
  set_false_path -from $exact_pblt_ppop_source_regs -to $target
}
foreach target [list \
    $exact_fill_ppop_target_regs $exact_pblt_ppop_target_regs \
    $exact_line_ppop_target_regs $exact_pixt_ppop_target_regs \
    $exact_move_wdata_regs] {
  set_false_path -from $exact_drav_ppop_source_regs -to $target
}
foreach target [list \
    $exact_fill_ppop_target_regs $exact_pblt_ppop_target_regs \
    $exact_drav_ppop_target_regs $exact_pixt_ppop_target_regs \
    $exact_move_wdata_regs] {
  set_false_path -from $exact_line_ppop_source_regs -to $target
}
set_false_path -from $exact_pixt_ppop_source_regs -to $exact_ppop_capture_regs

# An MMTM/MMFM mask is updated only on a completed external transaction.  The
# next command payload is continuously preselected during the following
# transaction and cannot be replaced on the adjacent edge.
set_multicycle_path -setup 2 -from $exact_mm_mask_regs -to $exact_mm_command_regs
set_multicycle_path -hold  1 -from $exact_mm_mask_regs -to $exact_mm_command_regs
# MMFM consumes the selected mask bit only when the following external read
# acknowledges. The updated mask has therefore crossed the complete registered
# adapter transaction before it can choose the architectural pop destination.
set_multicycle_path -setup 2 -from $exact_mm_mask_regs -to $exact_arch_writeback_regs
set_multicycle_path -hold  1 -from $exact_mm_mask_regs -to $exact_arch_writeback_regs

# CORE_MEMORY is entered before the held initial MMTM/MMFM command reaches the
# registered adapter. A subsequent command payload is captured only on that
# transaction's acknowledgement, never on the adjacent edge.
set_multicycle_path -setup 2 -from $exact_memory_state_regs -to $exact_mm_command_regs
set_multicycle_path -hold  1 -from $exact_memory_state_regs -to $exact_mm_command_regs

# CORE_MEMORY is entered before the registered adapter accepts the request;
# architectural MMFM/pointer writeback is qualified only by the later ack.
set_multicycle_path -setup 2 -from $exact_memory_state_regs -to $exact_arch_writeback_regs
set_multicycle_path -hold  1 -from $exact_memory_state_regs -to $exact_arch_writeback_regs

# INT_PUSH_ST only emits the first stack command. It cannot capture a MOVE
# payload or architectural writeback; SP/ST retirement occurs in INT_DONE.
set_false_path -from $exact_int_push_st_state_regs -to $exact_move_command_regs
set_false_path -from $exact_int_push_st_state_regs -to $exact_arch_writeback_regs

# CPU-domain interrupt shadows are registered before the interrupt-entry
# sequence. INT_PUSH_ST and INT_PUSH_PC precede the first vector command, so
# the shadow-to-adapter relationship has a conservative two-clock minimum.
set_multicycle_path -setup 2 -from $exact_interrupt_shadow_regs -to $exact_external_command_regs
set_multicycle_path -hold  1 -from $exact_interrupt_shadow_regs -to $exact_external_command_regs

# Graphics setup states 9/12/16/21/22/28/29/30/31/36/37 only read implied
# operands or window corners into their dedicated local registers. In every one
# of these states mem_req, pc_load_en, the on-chip I/O write strobes,
# architectural writeback, and retirement are unconditionally disabled. Shared
# async-read muxes nevertheless create impossible paths from the state-select
# bits to those disabled D inputs. Cut only the exact setup-state literals and
# only those capture-disabled endpoint families. Every real FILL/PIXBLT/DRAV/
# LINE/PIXT operand, window, timing-snapshot, and cycle-counter capture remains
# ordinary single-cycle timing.
set_false_path -from $exact_gfx_setup_state_regs -to $exact_external_command_regs
set_false_path -from $exact_gfx_setup_state_regs -to $exact_pc_writeback_regs
set_false_path -from $exact_gfx_setup_state_regs -to $exact_io_shadow_regs
set_false_path -from $exact_gfx_setup_state_regs -to $exact_execute_capture_regs
set_false_path -from $exact_gfx_setup_state_regs -to $exact_late_execute_capture_regs
set_false_path -from $exact_gfx_setup_state_regs -to $exact_arch_writeback_regs
set_false_path -from $exact_gfx_setup_state_regs -to $exact_retire_aux_regs
set_false_path -from $exact_gfx_setup_state_regs -to $exact_scheduler_retire_regs
set_false_path -from $exact_gfx_setup_state_regs -to $exact_ppop_capture_regs
set_false_path -from $exact_gfx_setup_state_regs -to $exact_divider_operand_regs

# The LINE operand states share synthesized enable muxes with unrelated FILL,
# PIXBLT, divider, and MMTM registers. These exact state/target pairs are never
# enabled together. Genuine LINE_SETUP1 captures (d/DYDX/COUNT) and
# LINE_SETUP2 captures (INC1/INC2/OFFSET) remain single-cycle timed.
set_false_path -from $exact_line_setup1_state_regs -to $exact_line_setup1_inactive_regs
set_false_path -from $exact_line_setup2_state_regs -to $exact_line_setup2_inactive_regs
set_false_path -from $exact_line_setup3_state_regs -to $exact_line_setup3_inactive_regs
set_false_path -from $exact_fill_setup_state_regs -to $exact_fill_setup_inactive_regs

# Graphics setup snapshots the complete MAME tuple at E0. start_pipe_q delays
# the counter's initial capture until E2; later row updates remain ordinary
# one-clock counter-internal paths.
set_multicycle_path -setup 2 -from $exact_gfx_snapshot_regs -to $exact_gfx_counter_regs
set_multicycle_path -hold  1 -from $exact_gfx_snapshot_regs -to $exact_gfx_counter_regs

# o_r can update only while the walker is allowed to step.  The only
# synthesized o_r-to-cadence cone runs through kill_enter_w, which requires a
# pending kill and simultaneously disables every o_r write.  Ordinary cadence
# updates do not consume o_r.  Cut that exact mutually-exclusive source/target
# pair while retaining every real o_r-to-source-address/pixel path.
set_false_path -from $exact_dma_o_regs -to $exact_dma_cadence_regs

# The shortest instruction captures its opcode at E0, registered decode at E1,
# dispatches at E2, executes at E3, and retires at E4. Only the retirement
# scheduler registers consume the combinational MAME cycle budget.
set_multicycle_path -setup 4 -from $exact_opcode_regs -to $exact_scheduler_retire_regs
set_multicycle_path -hold  3 -from $exact_opcode_regs -to $exact_scheduler_retire_regs
set_multicycle_path -setup 3 -from $exact_decoded_regs -to $exact_scheduler_retire_regs
set_multicycle_path -hold  2 -from $exact_decoded_regs -to $exact_scheduler_retire_regs

# A mapped-memory command is captured in M_IDLE, routed in M_ROUTE, and only
# then committed to mem_rdata. The command latches remain stable throughout,
# giving their data mux exactly two full system clocks. State/ack/control paths
# are intentionally not part of this exception.
set mem_command_regs [get_registers {*tunit_mem:mapped|addr_q[*] *tunit_mem:mapped|wdata_q[*] *tunit_mem:mapped|size_q[*] *tunit_mem:mapped|we_q}]
set mem_response_regs [get_registers {*tunit_mem:mapped|mem_rdata[*]}]
if {[get_collection_size $mem_command_regs] == 0 || [get_collection_size $mem_response_regs] == 0} {
  post_message -type error "T-unit mapped-memory response timing collection is empty"
}
set_multicycle_path -setup 2 -from $mem_command_regs -to $mem_response_regs
set_multicycle_path -hold  1 -from $mem_command_regs -to $mem_response_regs

# DMA requests and their held acknowledgement are now generated by the
# full-rate adapter. The acknowledgement-to-CPU path also intentionally keeps
# the default single-cycle requirement.

# DMA pixel timing is structural now: S_PIX registers the complete next source
# pointer, then S_WR (or the second half of clip_gap) copies it. The former
# ix/xstep_c -> multiply -> add -> cache-address multicycle exception is
# intentionally gone; every dynamic pixel-position path keeps the normal
# one-cycle game-clock requirement.

# bpp_c is different: it is a quasi-static command field captured only on the
# S_SETUP edge and held for the complete blit. A bpp-dependent arm of the
# src_state_addr_r mux cannot capture on the following edge: the walker must
# first cross S_ROWCHK. The first such capture is therefore at least two full
# game clocks after bpp_c changes. Skip's S_ROWCHK->S_SKB0 address capture can
# occur on that intervening edge, but it selects {offset_r>>3} directly; no
# bpp_c data path is sensitized in that mux arm.
#
# This is deliberately NOT the former blanket DMA exception. It covers only
# the four bpp_c source bits and the 32 registered source-address destination
# bits. State, o_r, cache predicates, request controls, acknowledgements and
# every other source into src_state_addr_r remain single-cycle timed.
# sim/monitors/tb_tunit_dma_spacing.v exercises every bpp value on the exact
# flattened midway_dma module with fastest-legal handshakes; the spacing gate
# also raises the measured claim by one and requires that mutation to fail.
set dma_bpp_regs [get_registers {*midway_dma:dma|bpp_c*}]
set dma_src_state_addr_regs [get_registers {*midway_dma:dma|src_state_addr_r*}]
if {[get_collection_size $dma_bpp_regs] == 0 ||
    [get_collection_size $dma_src_state_addr_regs] == 0} {
  post_message -type error "T-unit DMA bpp-to-source-address timing collection is empty"
} else {
  post_message -type info "T-unit DMA bpp multicycle covers [get_collection_size $dma_bpp_regs] source and [get_collection_size $dma_src_state_addr_regs] destination register(s)"
}
set_multicycle_path -setup 2 -from $dma_bpp_regs -to $dma_src_state_addr_regs
set_multicycle_path -hold  1 -from $dma_bpp_regs -to $dma_src_state_addr_regs

# A program-ROM request is decoded in M_ROUTE and asserted in M_ROM; the
# program cache therefore captures base_word two clocks after addr_q was
# latched. Keep this exception on that request register only.
set mem_addr_regs [get_registers {*tunit_mem:mapped|addr_q[*]}]
set prog_base_regs [get_registers {*tunit_prog_sdram:program_rom|base_word[*]}]
if {[get_collection_size $mem_addr_regs] == 0 || [get_collection_size $prog_base_regs] == 0} {
  post_message -type error "T-unit program request timing collection is empty"
} else {
  post_message -type info "T-unit program request multicycle covers [get_collection_size $prog_base_regs] registers"
}
set_multicycle_path -setup 2 -from $mem_addr_regs -to $prog_base_regs
set_multicycle_path -hold  1 -from $mem_addr_regs -to $prog_base_regs

# base_word launches on the request edge into P_LOOKUP. The following edge
# clocks both M10K read ports and advances to P_CHECK; only the next edge can
# update line_data or invalidate a missed cache line. Keep this two-cycle
# lookup exception on those two P_CHECK destinations.
set prog_lookup_regs [get_registers {
  *tunit_prog_sdram:program_rom|line_data[*]
  *tunit_prog_sdram:program_rom|cache_valid[*]
  *tunit_prog_sdram:program_rom|cache_tag*
  *tunit_prog_sdram:program_rom|fill_base[*]
  *tunit_prog_sdram:program_rom|fill_offset*
  *tunit_prog_sdram:program_rom|hot_valid*
  *tunit_prog_sdram:program_rom|hot_word*
  *tunit_prog_sdram:program_rom|hot_data*
  *tunit_prog_sdram:program_rom|state*
}]
if {[get_collection_size $prog_lookup_regs] == 0} {
  post_message -type error "T-unit program lookup timing collection is empty"
} else {
  post_message -type info "T-unit program lookup multicycle covers [get_collection_size $prog_lookup_regs] registers"
}
set_multicycle_path -setup 2 -from $prog_base_regs -to $prog_lookup_regs
set_multicycle_path -hold  1 -from $prog_base_regs -to $prog_lookup_regs

# A cache tag can change only on the final P_FILL edge. The FSM then traverses
# P_LOOKUP before P_CHECK can use that tag to invalidate a cache_valid bit, so
# this tag-to-valid control path has two complete system clocks.
set prog_tag_regs [get_registers {*tunit_prog_sdram:program_rom|cache_tag*}]
set prog_valid_regs [get_registers {*tunit_prog_sdram:program_rom|cache_valid*}]
if {[get_collection_size $prog_tag_regs] == 0 || [get_collection_size $prog_valid_regs] == 0} {
  post_message -type error "T-unit program tag-check timing collection is empty"
}
set_multicycle_path -setup 2 -from $prog_tag_regs -to $prog_valid_regs
set_multicycle_path -hold  1 -from $prog_tag_regs -to $prog_valid_regs

# Cache-valid and tag bits can change only on a download invalidation or the
# final P_FILL edge.  A CPU lookup then spends one complete edge in P_LOOKUP
# before P_CHECK may consume those bits to update line_data or invalidate a
# selected line.  These are the only two destinations in that decision cone.
set prog_check_sources [get_registers {
  *tunit_prog_sdram:program_rom|cache_valid*
  *tunit_prog_sdram:program_rom|cache_tag*
}]
set prog_check_results [get_registers {
  *tunit_prog_sdram:program_rom|cache_valid*
  *tunit_prog_sdram:program_rom|line_data[*]
}]
if {[get_collection_size $prog_check_sources] == 0 || [get_collection_size $prog_check_results] == 0} {
  post_message -type error "T-unit program cache-check timing collection is empty"
}
set_multicycle_path -setup 2 -from $prog_check_sources -to $prog_check_results
set_multicycle_path -hold  1 -from $prog_check_sources -to $prog_check_results

# The DCS2K instruction FSM and its ROM-cache FSM advance on the same 1-in-2
# enable. The external-response catcher remains full-rate and is deliberately
# excluded; paths that cross the DCS boundary also retain single-cycle timing.
set dcs_ce_regs [get_registers -nowarn {*adsp2105:cpu|*}]
set dcs_full_rate_regs [get_registers -nowarn {*adsp2105:cpu|dcs_mem:u_mem|ext_rsp_valid *adsp2105:cpu|dcs_mem:u_mem|ext_rsp_q[*] *adsp2105:cpu|dac_ce *adsp2105:cpu|pm_we}]
if {[get_collection_size $dcs_full_rate_regs] != 0} {
  set dcs_ce_regs [remove_from_collection $dcs_ce_regs $dcs_full_rate_regs]
}
if {[get_collection_size $dcs_ce_regs] == 0} {
  post_message -type info "T-unit DCS (absent in this variant, skipped):  clock-enable timing collection is empty"
} else {
  post_message -type info "T-unit DCS multicycle covers [get_collection_size $dcs_ce_regs] registers"
  set_multicycle_path -setup 2 -from $dcs_ce_regs -to $dcs_ce_regs
  set_multicycle_path -hold  1 -from $dcs_ce_regs -to $dcs_ce_regs
}

# MSTAT bit 0 selects the active G0 register bank.  The ADSP core changes
# MSTAT only while retiring S_EXEC, and the implementation explicitly forbids
# an instruction from both changing that bank bit and touching a banked
# register on the same retirement edge.  The earliest dependent G0 write is
# therefore the next instruction's S_EXEC after FETCH and DECODE: three DCS
# enables, or six 80 MHz clocks. Scope the architectural exception to the
# bank-select bit and G0 array; all other DCS paths keep the two-clock rule.
set dcs_bank_select_regs [get_registers -nowarn {*adsp2105:cpu|mstat[0]*}]
set dcs_g0_regs [get_registers -nowarn {*adsp2105:cpu|gr[*]}]
if {[get_collection_size $dcs_bank_select_regs] == 0 || [get_collection_size $dcs_g0_regs] == 0} {
  post_message -type info "T-unit DCS (absent in this variant, skipped):  bank-select timing collection is empty"
} else {
  post_message -type info "T-unit DCS bank-select multicycle covers [get_collection_size $dcs_bank_select_regs] source and [get_collection_size $dcs_g0_regs] destination registers"
  set_multicycle_path -setup 6 -from $dcs_bank_select_regs -to $dcs_g0_regs
  set_multicycle_path -hold  5 -from $dcs_bank_select_regs -to $dcs_g0_regs
}

# LINT1 is mirrored into the dedicated, registered CPU interrupt-status
# shadow.  The generic asynchronous I/O read bus also exposes the live bit,
# but tms34010_io_cpu_read_mux replaces that bus on the only address where the
# live bit exists (INTPEND).  Consequently the synthesized blit_irq-to-
# mv_load_data path requires mutually exclusive select values and is
# functionally impossible.  Keep the exception to that precise source and
# destination; the real blit_irq-to-interrupt-status path remains timed.
set lint1_source_regs [get_registers {*midway_dma:dma|blit_irq*}]
set cpu_mv_load_regs [get_registers {*tms34010_core:cpu|mv_load_data_q[*]}]
if {[get_collection_size $lint1_source_regs] == 0 || [get_collection_size $cpu_mv_load_regs] == 0} {
  post_message -type error "T-unit mutually-exclusive INTPEND read collection is empty"
} else {
  post_message -type info "T-unit mutually-exclusive INTPEND read exception covers [get_collection_size $lint1_source_regs] source and [get_collection_size $cpu_mv_load_regs] destination registers"
}
set_false_path -from $lint1_source_regs -to $cpu_mv_load_regs

# The framework HQ2x blend pipeline clocks only on ce_x4i. T-unit's pixel
# enable is exactly one pulse per 10 system clocks and scandoubler spaces its
# four HQ samples across that interval, so ce_x4i has a minimum spacing of two 80 MHz
# clocks. Keep this exception inside the Blend instance only.
set hq2x_blend_regs [get_registers {*Hq2x:Hq2x|Blend:blender|*}]
if {[get_collection_size $hq2x_blend_regs] == 0} {
  post_message -type error "T-unit HQ2x blend timing collection is empty"
} else {
  post_message -type info "T-unit HQ2x blend multicycle covers [get_collection_size $hq2x_blend_regs] registers"
}
set_multicycle_path -setup 2 -from $hq2x_blend_regs -to $hq2x_blend_regs
set_multicycle_path -hold  1 -from $hq2x_blend_regs -to $hq2x_blend_regs

# ---------------------------------------------------------------------------
# 12 MHz Williams ADPCM sound-board domain (PLL outclk_2) vs the 80 MHz core.
#
# Transactional paths between these domains go through tunit_sound_cdc
# (command, reset/profile, and coherent stereo sample transport) or
# tunit_adpcm_rom_cdc (ROM requests/responses). Both use toggle handshakes with
# preserved two-flop synchronisers and bundled-data hold contracts.  The one
# quasi-static exception is the fixed-ROM q/address tag: its M10K is wholly on
# the 80 MHz clock, cpu_addr is stable for a 6809 E cycle, q/tag are captured
# together, and the 12 MHz side refuses the value until the tags match and its
# reset-domain valid bit has asserted.  These crossings must NOT be timed as
# ordinary synchronous paths.
#
# This is DESIGN-RULES.md section 6 / STV P0019 -- "a CDC the STA never timed" is a
# silicon-only failure class. Declaring the groups is what makes STA analyse the
# design that actually exists rather than one where 12 MHz and 80 MHz launch
# edges are related.
#
# general[0] (core) and general[1] (SDRAM) are BOTH 80 MHz and must stay mutually
# synchronous, so they share a group; only the 12 MHz output is separated.
#
# The ADPCM-family build must fail loudly if either clock disappears. The
# DCS-only build deliberately compiles out both CDC blocks and every 12 MHz
# register, so an empty sound-clock collection is correct only when their
# register hierarchy is also absent.
set adpcm_cdc_regs [get_registers -nowarn {*tunit_sound_cdc:sound_cdc|* *tunit_adpcm_rom_cdc:adpcm_cdc|*}]
set core_clks [get_clocks -nowarn {*|pll_inst|altera_pll_i|general[0].gpll~PLL_OUTPUT_COUNTER|divclk *|pll_inst|altera_pll_i|general[1].gpll~PLL_OUTPUT_COUNTER|divclk}]
set snd_clks  [get_clocks -nowarn {*|pll_inst|altera_pll_i|general[2].gpll~PLL_OUTPUT_COUNTER|divclk}]
set tunit_adpcm_expected [expr {$::env(TUNIT_BUILD_VARIANT) ne "dcs"}]
if {$tunit_adpcm_expected && [get_collection_size $adpcm_cdc_regs] == 0} {
  post_message -type error "T-unit ADPCM CDC hierarchy is EMPTY in a variant that requires it"
} elseif {!$tunit_adpcm_expected && [get_collection_size $adpcm_cdc_regs] != 0} {
  post_message -type error "T-unit ADPCM CDC hierarchy survived in the DCS-only variant"
} elseif {!$tunit_adpcm_expected} {
  post_message -type info "T-unit ADPCM CDC absent in this sound-family variant; 12/80 MHz clock-group constraint skipped"
} elseif {[get_collection_size $core_clks] == 0 || [get_collection_size $snd_clks] == 0} {
  post_message -type error "T-unit ADPCM clock-group constraint matched nothing (core=[get_collection_size $core_clks] snd=[get_collection_size $snd_clks]); the 12/80 MHz CDC would be left timed as synchronous"
} else {
  post_message -type info "T-unit ADPCM CDC: [get_collection_size $adpcm_cdc_regs] register(s), [get_collection_size $core_clks] core clock(s) vs [get_collection_size $snd_clks] sound clock(s) declared asynchronous"
  set_clock_groups -asynchronous -group $core_clks -group $snd_clks
}

# ---------------------------------------------------------------------------
# BUNDLED-DATA SKEW on the 12/80 MHz crossings.
#
# set_clock_groups -asynchronous above tells STA to ignore this crossing, which
# is correct for the toggle handshakes -- but it also stops STA checking the
# SKEW BETWEEN PAYLOAD BITS.  tunit_adpcm_rom_cdc now carries a 64-bit line
# (widened from one byte by the 2026-08-09 line cache) and a 21-bit address; a
# torn capture there is a wrong sample byte or a wrong fill address, silently.
#
# Reported by the Y-unit session, from a shipped RBF: its sound-ROM crossing ran
# unconstrained on silicon because the payload constraints sat inside
# `if {[get_collection_size $x] > 0} { ... }`, the fitter duplicated one register
# and did not preserve two others, the collections came back empty and the block
# was SILENTLY SKIPPED.  The SDC still read as complete.  Two defences: the
# payload registers are marked preserve in RTL, and this block fails LOUD rather
# than skipping.
set cdc_request_addr [get_registers -nowarn {*tunit_adpcm_rom_cdc:adpcm_cdc|request_addr*}]
set cdc_response_line [get_registers -nowarn {*tunit_adpcm_rom_cdc:adpcm_cdc|response_line*}]
set cdc_audio_hold [get_registers -nowarn {*tunit_sound_cdc:*|audio_hold_snd*}]
set cdc_active_command [get_registers -nowarn {*tunit_sound_cdc:*|active_command*}]
set cdc_tel_regs [get_registers -nowarn {*tunit_audio_tel_cdc:audio_tel_cdc|*}]
set cdc_tel_hold [get_registers -nowarn {*tunit_audio_tel_cdc:audio_tel_cdc|h_*}]
set cdc_payload [get_registers -nowarn {
  *tunit_adpcm_rom_cdc:adpcm_cdc|request_addr*
  *tunit_adpcm_rom_cdc:adpcm_cdc|response_line*
  *tunit_audio_tel_cdc:audio_tel_cdc|h_*
  *tunit_sound_cdc:*|audio_hold_snd*
  *tunit_sound_cdc:*|active_command*
}]
set cdc_payload_missing {}
if {$tunit_adpcm_expected} {
  # request_addr is a 21-bit register but only bits [20:3] cross the CDC as
  # bundled data.  [2:0] is the intra-line byte offset: its only path is the
  # unused sys_addr[2:0] (the CDC fetches an aligned 64-bit line, so byte-select
  # is source-side), so those 3 flops are DEAD and the fitter removes a
  # SEED-DEPENDENT 0..3 of them (measured: seed 10 -> 18 survive, seed 3 -> 20).
  # The 18 live line-address bits [20:3] drive the real ROM fetch and can never
  # be optimised away, so a healthy LOGICAL crossing is 18..21 registers.  The
  # fitter may add physical copies named ~DUPLICATE for routability; those are
  # additional CDC launch registers and must remain in cdc_payload (and thus in
  # set_max_skew), but they must not make the logical-cardinality guard fail.
  # Classify every match instead of merely raising the upper bound: this still
  # fails loud for a missing live bit, a vanished preserved source register, or
  # an unexpected register name that the broad payload wildcard picked up.
  set request_addr_n [get_collection_size $cdc_request_addr]
  set request_addr_base_n 0
  set request_addr_duplicate_n 0
  set request_addr_base_bits {}
  set request_addr_unclassified {}
  foreach_in_collection request_addr_reg $cdc_request_addr {
    set request_addr_name [get_node_info -name $request_addr_reg]
    if {![regexp {\|request_addr\[([0-9]+)\](.*)$} \
            $request_addr_name unused request_addr_bit request_addr_suffix]} {
      lappend request_addr_unclassified $request_addr_name
    } elseif {$request_addr_bit < 0 || $request_addr_bit > 20} {
      lappend request_addr_unclassified $request_addr_name
    } elseif {$request_addr_suffix eq ""} {
      incr request_addr_base_n
      if {[lsearch -exact $request_addr_base_bits $request_addr_bit] < 0} {
        lappend request_addr_base_bits $request_addr_bit
      }
    } elseif {[string match {~DUPLICATE*} $request_addr_suffix]} {
      incr request_addr_duplicate_n
    } else {
      lappend request_addr_unclassified $request_addr_name
    }
  }
  set request_addr_missing_live_bits {}
  for {set request_addr_bit 3} {$request_addr_bit <= 20} \
      {incr request_addr_bit} {
    if {[lsearch -exact $request_addr_base_bits $request_addr_bit] < 0} {
      lappend request_addr_missing_live_bits $request_addr_bit
    }
  }
  if {$request_addr_base_n < 18 || $request_addr_base_n > 21} {
    lappend cdc_payload_missing \
        "request_addr_base=$request_addr_base_n!=18..21(physical=$request_addr_n,duplicates=$request_addr_duplicate_n)"
  }
  if {[llength $request_addr_missing_live_bits] != 0} {
    lappend cdc_payload_missing \
        "request_addr_live_bits_missing=[join $request_addr_missing_live_bits {/}]"
  }
  if {[llength $request_addr_unclassified] != 0} {
    lappend cdc_payload_missing \
        "request_addr_unclassified=[join $request_addr_unclassified {;}]"
  }
  foreach {bundle regs expected} [list \
      response_line $cdc_response_line 64 \
      audio_hold_snd $cdc_audio_hold 16 \
      active_command $cdc_active_command 8] {
    set matched [get_collection_size $regs]
    if {$matched != $expected} {
      lappend cdc_payload_missing "$bundle=$matched!=$expected"
    }
  }
}
# The diagnostic telemetry bridge is compiled out of production.  This cabinet
# image pins the overlay to the magenta VIDEO page, so the audio telemetry is
# intentionally unobservable and synthesis must remove its entire 128-bit hold
# bank.  Requiring 128 here would make the fixed-page diagnostic unfittable;
# accepting a partial bank would still hide a torn crossing.  Therefore a DIAG
# fit requires exactly zero telemetry holds while the video-page hard-pin is the
# source contract enforced by preflight_tunit_build.py.
set tunit_diag_expected [expr {
  [info exists ::env(TUNIT_DIAG_BUILD)] && $::env(TUNIT_DIAG_BUILD) eq "1"
}]
if {$tunit_diag_expected && $tunit_adpcm_expected && [get_collection_size $cdc_tel_hold] != 0} {
  lappend cdc_payload_missing "fixed_video_diag_audio_tel_holds=[get_collection_size $cdc_tel_hold]!=0"
} elseif {!$tunit_diag_expected && [get_collection_size $cdc_tel_regs] > 0} {
  lappend cdc_payload_missing "audio_tel_hierarchy_present_in_production"
}
if {!$tunit_adpcm_expected && [get_collection_size $cdc_payload] != 0} {
  post_message -type error "T-unit CDC payload hierarchy survived in the DCS-only variant"
} elseif {!$tunit_adpcm_expected} {
  post_message -type info "T-unit CDC payload skew: ADPCM CDC absent in this variant; skipped"
} elseif {[llength $cdc_payload_missing] != 0} {
  post_message -type error "T-unit CDC payload bundle missing or partial: [join $cdc_payload_missing {, }]"
} elseif {[get_collection_size $cdc_payload] == 0} {
  post_message -type error "T-unit CDC payload skew collection is EMPTY -- the bundled data would cross unconstrained (check the preserve attributes survived the fitter)"
} else {
  post_message -type info "T-unit CDC payload skew: request=$request_addr_n (base=$request_addr_base_n duplicate=$request_addr_duplicate_n) response=[get_collection_size $cdc_response_line] audio=[get_collection_size $cdc_audio_hold] command=[get_collection_size $cdc_active_command] telemetry=[get_collection_size $cdc_tel_hold] register(s) constrained"
  set_max_skew -from $cdc_payload -to [get_registers *] 12.5
}

# ---------------------------------------------------------------------------
# profile_q/variant_q quasi-static per-title selectors.
#
# DERIVATION (already recorded in this tree at commit 7d8dfc4, which said it would be
# MEASURED before being constrained -- this is that measurement):
# `profile` is the game selector. It is written at reset (tunit_loader.sv:305,345) and
# once more at descriptor parse (:493), and is static for the entire run thereafter.
# Its consumers are held in RESET whenever it changes (tunit_top.sv:78-80, where
# profile_valid_q is registered ALONGSIDE profile_q precisely so reset release stays
# behind the settled copy). That is a stronger hardware guarantee than the enable-spacing
# arguments already audited here.
#
# WHY MULTICYCLE AND NOT FALSE PATH: both are defensible, and the WEAKER claim is the one
# worth asserting. 3 cycles at 80 MHz leaves 37.5 ns of budget on a signal that changes
# once per ROM load -- far outside the 1.35 ns seed spread measured on this design -- while
# a false path would assert something about a signal I have not proven can never move
# during operation. Y-unit reached the same conclusion independently on their game_id and
# measured core Fmax 51.64 -> 53.85 MHz from it.
#
# SCOPE: profile_q and the alongside variant_q ONLY. Not profile_valid_q, which
# gates reset release and must stay single-cycle, and not the loader-side values
# before they are registered.
set tunit_profile_regs [get_registers -nowarn {*tunit_top*|profile_q[*] *tunit_top*|variant_q[*]}]
if {[get_collection_size $tunit_profile_regs] == 0} {
  post_message -type info "T-unit profile/variant multicycle: collection empty, skipped"
} else {
  post_message -type info "T-unit profile/variant multicycle covers [get_collection_size $tunit_profile_regs] register(s)"
  set_multicycle_path -setup 3 -from $tunit_profile_regs
  set_multicycle_path -hold  2 -from $tunit_profile_regs
}

# ---------------------------------------------------------------------------
# TUNIT-P0036: fitter-only setup overconstraint on the HDMI pixel clock.
#
# The chronic slow/-40C blocker is the ascal output stage: unregistered M10K
# line/palette reads into the o_vpix/o_hpix registers, where a ~2.5 ns clock
# spine mismatch plus one long routing hop leaves the whole cone parked within
# +/-50 ps of zero at every seed (measured: -0.010, -0.043 across seed 8 at
# efforts 4.0 and 6.0; the report is
# output_files/tunit_hdmi_slow_m40_setup_paths.txt). The fitter simply stops
# optimizing at "barely fails" because the domain is at its effort floor.
#
# Remedy: during quartus_fit ONLY, add setup uncertainty to paths latched by
# the HDMI divclk so the annealer sees this domain as failing by ~0.3 ns and
# keeps working it. quartus_sta does NOT take this branch: sign-off runs the
# true constraints, bit-identical to every previous build, so the assemble
# gate is not weakened -- a build only ships if the REAL check passes.
# ---------------------------------------------------------------------------
if {[info exists ::TimeQuestInfo(nameofexecutable)] &&
    $::TimeQuestInfo(nameofexecutable) eq "quartus_fit"} {
  set tunit_hdmi_clk [get_clocks -nowarn {*pll_hdmi*counter[0]*divclk}]
  if {[get_collection_size $tunit_hdmi_clk] == 0} {
    post_message -type info "T-unit HDMI fitter overconstraint: clock not found, skipped"
  } else {
    # 0.300 closed run 4 (production) outright; with the TUNIT_DIAG overlay
    # present the fitter left 0.084 on the table (run 6), so push harder. The
    # 80 MHz core absorbed the diag logic and still closed (+0.126 slow/100C).
    # Bisected: with the diag overlay in, 0.300 leaves HDMI at -0.084 (run 6)
    # and 0.450 closes HDMI (+0.094) but raids the core to -0.168 (run 7); the
    # two domains trade a near-fixed pot. 0.375 asks for the measured need.
    # ADPCM diag image (70% ALMs) needs a little more than the universal tuning:
    # that fit left HDMI at -0.115 slow/-40C while the 80 MHz core held +0.157
    # and +0.443, so the core can afford to give. Measured response is ~1.2 ns
    # of HDMI per ns of uplift, so +0.10 covers a 0.115 gap.
    # P0049 measured the next universal placement at -0.246 ns on
    # o_vcpt_pre3[0] -> o_vcpt_pre3[10] while the real sign-off constraints
    # remained unchanged.  The measured response above is about 1.2 ns of
    # HDMI slack per 1 ns of fitter uplift, so another 0.225 ns asks for about
    # 0.270 ns.  The simultaneous DMA arithmetic rewrite removes the separate
    # -0.029 ns game-clock cone instead of asking the fitter to raid HDMI for
    # it.  Sign-off still never takes this branch.
    # 2026-08-10: removing no_rw_check from the jt6295 FIR RAM made Quartus add
    # its own pass-through logic (15x Warning 276020), which changed the netlist
    # and cost the placement that had closed -- seed 7 went from HDMI +0.127 /
    # core +0.292 to HDMI -0.287 / core +0.194.  Measured seed spread on the old
    # netlist was large (seed 3 -0.344, seed 4 -0.431, seed 7 +0.127, seed 2
    # -0.061), so seeds move this design far more than the +/-50 ps this comment
    # originally described.
    #
    # Buying the 0.287 back from the core rather than re-running the seed
    # lottery: at the measured ~1.2 ns of HDMI per 1 ns of uplift, 0.240 covers
    # it, and the core is holding +0.194 to fund it.  That is deliberately tight
    # -- if the core goes negative instead, the pot really is exhausted at this
    # netlist and the answer is an RTL fix on the core cone
    # (tms34010|pblt_* -> memsys|d_wdata), not more uplift.
    # 0.940 got slow/100C to exactly 0.000 and left ONLY slow/-40C failing, at
    # -0.095 (HDMI), while the core held +0.530 / +0.580 at the two slow corners.
    # The core is nowhere near its limit, so fund the last 0.095 with margin
    # rather than shaving it: +0.16 of uplift buys ~0.19 of HDMI at the measured
    # 1.2 ratio and still leaves the core around +0.42.
    post_message -type info "T-unit HDMI fitter overconstraint: +1.100 ns setup uncertainty (fit only)"
    set_clock_uncertainty -setup -to $tunit_hdmi_clk -add 1.100
  }
}
