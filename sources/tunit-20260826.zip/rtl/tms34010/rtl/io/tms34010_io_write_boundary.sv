// -----------------------------------------------------------------------------
// tms34010_io_write_boundary.sv
//
// Registered boundary between the CE-gated TMS34010 datapath and the full-rate
// I/O register file.  The core's memory outputs are combinational functions of
// state/decode/regfile data and become stable only after a cpu_ce edge.  The
// external-memory adapter therefore accepts them on a later cpu_ce edge.  I/O
// writes must obey the same rule: capture the exact transaction only when the
// core accepts its acknowledgement, then present one full-rate-clock write
// pulse made entirely from registered command fields.
// -----------------------------------------------------------------------------

`default_nettype none
module tms34010_io_write_boundary
  import tms34010_pkg::*;
(
  input  wire logic                    clk,
  input  wire logic                    rst,
  input  wire logic                    ce_cpu,
  input  wire logic                    req,
  input  wire logic                    we,
  input  wire logic                    is_io,
  input  wire logic                    ack,
  input  wire logic [ADDR_WIDTH-1:0]   addr,
  input  wire logic [15:0]             wdata,
  // Field size of the access (1..32). I/O registers are ordinary field targets;
  // the size must cross the boundary with the address and data so io_regs can
  // read-modify-write only the addressed bits.
  input  wire logic [FIELD_SIZE_WIDTH-1:0] size,

  output logic                         wr_valid,
  output logic [ADDR_WIDTH-1:0]        wr_addr,
  output logic [15:0]                  wr_data,
  output logic [FIELD_SIZE_WIDTH-1:0]  wr_size,
  (* preserve *)
  output logic                         wr_status_guard
);

`ifdef MUT_IO_LIVE_WRITE
  // Mutation: restore the rejected full-rate live path.  A request held while
  // waiting for ack writes on every sysclk and exposes CPU combinational logic
  // directly to io_reg[*].D.
  assign wr_valid = req && we && is_io;
  assign wr_addr  = addr;
  assign wr_data  = wdata;
  assign wr_size  = size;
  assign wr_status_guard = 1'b0;
`else
  // wr_valid is a one-sysclk pulse.  Address/data change only on the retiring
  // cpu_ce edge and are already stable before wr_valid is consumed by io_regs
  // on the following sysclk edge.
  always_ff @(posedge clk) begin
    if (rst) begin
      wr_valid <= 1'b0;
      wr_addr  <= '0;
      wr_data  <= '0;
      wr_size  <= '0;
      wr_status_guard <= 1'b0;
    end else begin
      wr_valid <= 1'b0;
      wr_status_guard <= 1'b0;
      if ((ce_cpu !== 1'b0) && req && we && is_io && ack) begin
        wr_valid <= 1'b1;
        wr_addr  <= addr;
        wr_data  <= wdata;
        wr_size  <= size;
        wr_status_guard <= 1'b1;
      end
    end
  end
`endif

endmodule : tms34010_io_write_boundary
`default_nettype wire
