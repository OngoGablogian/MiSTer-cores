// -----------------------------------------------------------------------------
// tms34010_io_regs.sv
//
// On-chip memory-mapped I/O register file for the TMS34010.
//
// Per the 1988 User's Guide Figure 6-1 (page 6-3), the GSP has 32 internal
// 16-bit registers occupying the bit-address range 0xC0000000-0xC00001FF.
// Each register sits at a 0x10-bit-aligned address (16 bits apart). The CPU
// (and, on real silicon, the host) reaches them through the ordinary
// bit-addressed memory interface; an address decodes to I/O space when its
// two MSBs are 11 and bits[29:9] are 0. The register index is addr[8:4].
//
// "All I/O registers ... are cleared to 0 at reset" (UG §6, Reset). The one
// documented exception concerns the HLT bit's dependence on the HCS pin of
// the host interface, which this FPGA reimplementation does not yet model;
// resetting every register to 0 is therefore correct here.
//
// Scope (Task 0081 — foundation; P00xx — live video counters):
//   - Plain read/write storage for the control/graphics registers that the
//     instruction set reads (PSIZE, PMASK, CONVSP, CONVDP, CONTROL, DPYCTL, ...).
//   - HCOUNT/VCOUNT are now the LIVE horizontal/vertical counters from u_video
//     (read-only on silicon; see the rdata mux). REFCNT/DPYADR remain plain
//     storage; INTPEND bits are software-clear with device set-on-event (DI/WV).
//
// Port shape:
//   - Synchronous active-high reset (assumption A0003), all registers -> 0.
//   - One synchronous write port (req & we & is_io).
//   - One combinational (async) read port. The 32x16 array is tiny (512
//     bits) and async read keeps this composable with the core's existing
//     register-style reads; FPGA maps it to flops + a 32:1 mux.
//   - `is_io` tells the caller whether `addr` decoded as I/O space, so the
//     surrounding memory fabric can route reads/writes here vs. external RAM.
//
// Spec source:
//   third_party/TMS34010_Info/docs/ti-official/1988_TI_TMS34010_Users_Guide.pdf
//   Figure 6-1 (I/O Register Memory Map), §6 "I/O Registers".
// -----------------------------------------------------------------------------

`default_nettype none
module tms34010_io_regs
  import tms34010_pkg::*;
(
  input  wire logic                  clk,
  input  wire logic                  rst,

  input  wire logic                  req,      // access strobe
  input  wire logic                  we,       // 1 = write, 0 = read
  // Registered write-command address.  In the core integration this comes
  // only from tms34010_io_write_boundary, never from the live CPU datapath.
  input  wire logic [ADDR_WIDTH-1:0] addr,
  input  wire logic [15:0]           wdata,
  // Field size of the registered write command (1..32). A sub-word write must
  // read-modify-write only the addressed bits; see io_field_merge.
  input  wire logic [FIELD_SIZE_WIDTH-1:0] wr_size,
  input  wire logic                  status_guard,

  // Live read/decode address.  Keeping it separate preserves async I/O reads
  // and external-write suppression without letting it reach io_reg[*].D.
  input  wire logic [ADDR_WIDTH-1:0] raddr,

  // Pixel-clock ENABLE for the video-timing counters (u_video). Threaded from
  // the emu (Arcade-SmashTV.sv ce_pix = 96 MHz / 12 = 8 MHz) through the core.
  // Left UNCONNECTED by legacy unit TBs -> u_video defaults to full rate (its
  // own `ce === 1'b0` guard), so those TBs are unaffected.
  input  wire logic                  ce_pix,

  output logic [15:0]           rdata,    // selected register (0 if not I/O)
  output logic                  is_io,    // addr decodes to I/O space

  // Dedicated taps for the graphics datapath (combinational views of the
  // stored registers). More can be added (PMASK/CONTROL) as the graphics ops
  // that need them land.
  output logic [15:0]           psize_o,  // PSIZE: pixel size in bits (1..16)
  output logic [15:0]           convdp_o, // CONVDP: XY->linear dest pitch shift
  output logic [15:0]           convsp_o, // CONVSP: XY->linear source pitch shift
  output logic [15:0]           control_o,// CONTROL: PPOP[14:10], PBV/PBH, W, T(bit5)
  output logic [15:0]           pmask_o,  // PMASK: plane mask (1 bit = plane masked)
  output logic [15:0]           intenb_o, // INTENB: maskable-interrupt enables
  output logic [15:0]           intpend_o,// INTPEND: maskable-interrupt pending bits
  output logic [15:0]           dpyctl_o, // CORE-2: DPYCTL bit 11 selects shift-register transfer
  output logic [15:0]           dpystrt_o,// DPYSTRT: frame display-address reload value
  output logic [15:0]           dpytap_o, // DPYTAP: horizontal display tap
  output logic [15:0]           dpyadr_o, // live hardware/software display address
  output logic [15:0]           display_row_o,
  output logic [15:0]           display_col_o,
  output logic [1:0]            display_yoffset_o,
  output logic                  display_enable_o,
  // TUNIT-P0048: live HEBLNK >= HSBLNK. The TI TMS34010 User's Guide
  // pp. 6-27/6-29 defines HEBLNK as the end and HSBLNK as the start of
  // horizontal blanking, so this ordering leaves no active horizontal span.
  // MAME 0.289 tms34010.cpp:1168,1191-1193 consequently paints the configured
  // visarea black: the [heblnk,hsblnk) callback loop in
  // midtunit_v.cpp:848-856 runs zero times. Export the predicate here so its
  // one decode stays beside every other display-parameter decode.
  output logic                  display_blank_o,
  output logic                  vblank_start_o,
  output logic [15:0]           hstctlh_o,// HSTCTLH: host control (NMI/NMIM in bits 8/9)
  // First timing activation: registered one-cycle pulse on the clock AFTER the
  // write that changes HTOTAL from reset/disabled zero to nonzero.  This puts a
  // hard register boundary between CPU decode/write data and the video reset /
  // rephase tree; the HTOTAL value is already stored when consumers reset.
  output logic                  timing_start_o,
  input  wire logic                  nmi_clear,// 1-cycle: clear HSTCTLH.NMI (device took NMI)
  input  wire logic                  wvp_set,  // 1-cycle: set INTPEND.WV (window violation)
  // P0016: external interrupt pin LINT1 (level). Per the 1988 UG §8.3 the
  // INTPEND.X1P bit REFLECTS the pin level (it is not a latch and cannot be
  // cleared by writing INTPEND) -- so it is OR-mirrored into the INTPEND view
  // (both the dedicated intpend_o tap and CPU reads of the register).
  input  wire logic                  lint1_in
);

  // I/O-space decode: two MSBs = 11 and bits[29:9] = 0 (range C0000000-
  // C00001FF). The register index is addr[8:4].
  logic [IO_REG_IDX_W-1:0] rd_idx;
  logic [IO_REG_IDX_W-1:0] wr_idx;
  logic                    wr_is_io;
  assign is_io = (raddr[ADDR_WIDTH-1:ADDR_WIDTH-2] == 2'b11)
              && (raddr[ADDR_WIDTH-3:IO_REG_IDX_W+4] == '0);
  assign rd_idx = raddr[IO_REG_IDX_W+3 : 4];
  assign wr_is_io = (addr[ADDR_WIDTH-1:ADDR_WIDTH-2] == 2'b11)
                 && (addr[ADDR_WIDTH-3:IO_REG_IDX_W+4] == '0);
  assign wr_idx = addr[IO_REG_IDX_W+3 : 4];

  // Register storage.
  logic [15:0] io_reg [0:IO_REG_COUNT-1];

  // Value the addressed register takes after this write command, with only the
  // addressed field replaced. Aligned FS=16 writes reduce to `wdata`.
  logic [15:0] wr_merged;
  assign wr_merged = io_field_merge(io_reg[wr_idx], wdata, addr[3:0], wr_size);

  logic timing_start_req;
  assign timing_start_req = !rst && req && we && wr_is_io &&
                            (wr_idx == IO_IDX_HTOTAL) &&
                            (io_reg[IO_IDX_HTOTAL] == 16'd0) &&
                            (wr_merged != 16'd0);

  // The request is true on the HTOTAL write edge.  Its registered image is
  // consumed on the following edge, after io_reg[HTOTAL] has taken wdata.  A
  // held bus request cannot stretch the pulse: after the write edge HTOTAL is
  // nonzero, so timing_start_req falls before this pulse is consumed.
`ifdef MUT_TIMING_COMB_START
  // Mutation coverage for the rejected TimeQuest defect: restore the live CPU
  // decode directly onto the video reset/rephase tree.
  assign timing_start_o = timing_start_req;
`else
  always_ff @(posedge clk) begin
    if (rst) timing_start_o <= 1'b0;
    else     timing_start_o <= timing_start_req;
  end
`endif

  // ---------------------------------------------------------------------------
  // Display-interrupt source + live video counters (P0012 + P00xx).
  // The vendored `tms34010_video` block generates DPYINT_PULSE (a 1-clock strobe
  // at HSBLNK, the start of horizontal blanking at the end of DPYINT's selected
  // line) from the video-timing registers.
  // Wire it here where all the timing registers already live. It is clocked by
  // the io_regs clk and gated by ce_pix (the dot-clock enable) so DPYINT fires
  // ONCE PER FRAME at the DPYINT scan line -- matching real HW / MAME -- instead
  // of at the core clock (the fork-inherited bug: ~12x too fast, which derailed
  // NBA/UMK3 init before the RAM interrupt-dispatch table is built).
  // hcount/vcount are the LIVE counters and are returned on CPU reads of
  // HCOUNT/VCOUNT (see the rdata mux): NBA display_blank spins on VCOUNT
  // (BB.ASM #nxt: `move *VCOUNT,a0; jrz` waits for VCOUNT to leave 0) and hangs
  // forever if the read returns a dead/stored 0.
  // ---------------------------------------------------------------------------
  wire logic   dpyint_pulse;
  wire logic   dpyint_event;
  wire logic   video_line_advance;
  (* preserve *) logic dpyint_event_q;
  (* preserve *) logic wvp_set_q;
  (* preserve *) logic nmi_clear_q;
  logic [15:0] vid_hcount, vid_vcount;
  logic        vid_hs_unused, vid_vs_unused, vid_hb_unused, vid_vb_unused, vid_bl_unused;

  tms34010_video u_video (
    .clk         (clk),
    .rst         (rst),
    .timing_start(timing_start_o),
    .ce          (ce_pix),   // dot-clock enable: HCOUNT/dot, VCOUNT/line, DPYINT/frame
    .hesync      (io_reg[IO_IDX_HESYNC]),
    .heblnk      (io_reg[IO_IDX_HEBLNK]),
    .hsblnk      (io_reg[IO_IDX_HSBLNK]),
    .htotal      (io_reg[IO_IDX_HTOTAL]),
    .vesync      (io_reg[IO_IDX_VESYNC]),
    .veblnk      (io_reg[IO_IDX_VEBLNK]),
    .vsblnk      (io_reg[IO_IDX_VSBLNK]),
    .vtotal      (io_reg[IO_IDX_VTOTAL]),
    .dpyint      (io_reg[IO_IDX_DPYINT]),
    .hcount      (vid_hcount),
    .vcount      (vid_vcount),
    .hsync       (vid_hs_unused),
    .vsync       (vid_vs_unused),
    .hblank      (vid_hb_unused),
    .vblank      (vid_vb_unused),
    .blank       (vid_bl_unused),
    .dpyint_pulse(dpyint_pulse),
    .line_advance(video_line_advance),
    .vblank_start(vblank_start_o)
  );

  assign dpyint_event = dpyint_pulse &&
                        (io_reg[IO_IDX_VTOTAL] != 16'h0) &&
                        io_reg[IO_IDX_DPYCTL][15];

  // Async read: the selected register, or 0 when the address is not in
  // I/O space (so a non-I/O read contributes nothing to a merged read bus).
  // P0016: CPU reads of INTPEND see the live LINT1 pin mirrored into X1P.
  // The `=== 1'b1` makes an UNCONNECTED pin (legacy TBs: 'z) read as not
  // asserted in sim; synthesis treats it as plain equality.
  logic lint1_lvl;
  assign lint1_lvl = (lint1_in === 1'b1);
  // HCOUNT/VCOUNT are READ-ONLY-ish counters on real silicon (1988 UG Fig 6-1;
  // memory_map.md marks them "read-only on silicon"): a CPU read returns the
  // LIVE horizontal/vertical counter, not the stored io_reg. NBA display_blank
  // spins on VCOUNT (BB.ASM #nxt) and MAME returns a live, sweeping VCOUNT; a
  // dead/stored 0 hangs the spin. Writes still fall through to io_reg[idx] (dead
  // storage for these two indices) -- harmless, and matches MAME, where the
  // stored write does not feed the computed read.
  assign rdata = !is_io ? 16'h0
               : (rd_idx == IO_IDX_VCOUNT)  ? vid_vcount
               : (rd_idx == IO_IDX_HCOUNT)  ? vid_hcount
               : (rd_idx == IO_IDX_INTPEND)
                 ? (io_reg[rd_idx] | (16'(lint1_lvl) << INT_X1_BIT))
                 : io_reg[rd_idx];

  // Dedicated graphics taps.
  assign psize_o   = io_reg[IO_IDX_PSIZE];
  assign convdp_o  = io_reg[IO_IDX_CONVDP];
  assign convsp_o  = io_reg[IO_IDX_CONVSP];
  assign control_o = io_reg[IO_IDX_CONTROL];
  assign pmask_o   = io_reg[IO_IDX_PMASK];
  assign intenb_o  = io_reg[IO_IDX_INTENB];
  assign dpyctl_o  = io_reg[IO_IDX_DPYCTL];
  assign dpystrt_o = io_reg[IO_IDX_DPYSTRT];
  assign dpytap_o  = io_reg[IO_IDX_DPYTAP];
  assign dpyadr_o  = io_reg[IO_IDX_DPYADR];
  assign display_enable_o = io_reg[IO_IDX_DPYCTL][15];
  assign display_blank_o  = (io_reg[IO_IDX_HEBLNK] >= io_reg[IO_IDX_HSBLNK]);

  // MAME 0.289 tms34010.cpp:get_display_params(), which follows the 34010
  // display-address hardware: origin inversion is applied before both the row
  // and column fields are derived.  T-unit scanout later doubles coladdr
  // because each 34010 video clock emits two physical pixels.
  logic [15:0] display_dpyadr;
  assign display_dpyadr = io_reg[IO_IDX_DPYCTL][10]
                         ? io_reg[IO_IDX_DPYADR]
                         : (io_reg[IO_IDX_DPYADR] ^ 16'hfffc);
  assign display_row_o = display_dpyadr >> 4;
  assign display_col_o = ((display_dpyadr & 16'h007c) << 4) |
                         (io_reg[IO_IDX_DPYTAP] & 16'h3fff);
  assign display_yoffset_o = (io_reg[IO_IDX_DPYSTRT] -
                              io_reg[IO_IDX_DPYADR]) & 16'h0003;
  // P0016: X1P mirrors the LINT1 pin level into the pending view.
  assign intpend_o = io_reg[IO_IDX_INTPEND] | (16'(lint1_lvl) << INT_X1_BIT);
  assign hstctlh_o = io_reg[IO_IDX_HSTCTLH];

  // Synchronous write + reset. The reset loop is bounded (32 iterations) and
  // fully unrollable, so synthesis treats it as parallel resets.
  always_ff @(posedge clk) begin
    if (rst) begin
      for (int i = 0; i < IO_REG_COUNT; i++) begin
        io_reg[i] <= 16'h0;
      end
      dpyint_event_q <= 1'b0;
      wvp_set_q      <= 1'b0;
      nmi_clear_q    <= 1'b0;
    end else begin
      // Local one-cycle history exactly spans the registered CPU-write
      // boundary without creating a full-rate I/O/raster path into the CPU
      // collection. E-1 actions expire by E1; E0 actions are q at E1.
      dpyint_event_q <= dpyint_event;
      wvp_set_q      <= (wvp_set === 1'b1);
      nmi_clear_q    <= (nmi_clear === 1'b1);

      if (req && we && wr_is_io) begin
        if (wr_idx == IO_IDX_INTPEND) begin
`ifdef MUT_IO_INTPEND_WHOLE_WRITE
          io_reg[wr_idx] <= wr_merged;
`else
          io_reg[wr_idx] <= intpend_apply_cpu_write(io_reg[wr_idx],wr_merged);
`endif
        end else begin
          io_reg[wr_idx] <= wr_merged;
        end
      end
`ifdef MUT_IO_EVENT_GAP
      else if (nmi_clear) begin
        // The device automatically clears HSTCTLH.NMI when it takes the NMI
        // (1988 UG §8). A normal I/O write takes precedence (the else-if order):
        // simultaneous host write + take is a don't-care corner.
        io_reg[IO_IDX_HSTCTLH][HSTCTL_NMI_BIT] <= 1'b0;
      end else if (wvp_set) begin
        // The graphics engine sets INTPEND.WV on a window violation (1988 UG
        // §7.10). Like nmi_clear, this is a device-internal set, lower priority
        // than a host/program I/O write.
        io_reg[IO_IDX_INTPEND][INT_WV_BIT] <= 1'b1;
      end
`else
      // Consume carried E0 actions only with an actual command emitted by the
      // registered boundary. This distinguishes a new same-bit event from an
      // old pending bit without feeding live I/O state back into CPU timing.
      if (req && we && wr_is_io && (status_guard === 1'b1)) begin
        if (wr_idx == IO_IDX_INTPEND) begin
          if (wvp_set_q)
            io_reg[IO_IDX_INTPEND][INT_WV_BIT] <= 1'b1;
          if (dpyint_event_q)
            io_reg[IO_IDX_INTPEND][INT_DI_BIT] <= 1'b1;
        end
        if ((wr_idx == IO_IDX_HSTCTLH) && nmi_clear_q)
          io_reg[IO_IDX_HSTCTLH][HSTCTL_NMI_BIT] <= 1'b0;
      end

      // Device actions are newer than the CPU transaction, which retired one
      // sysclk earlier, so current-edge actions win at physical commit.
      if (nmi_clear === 1'b1)
        io_reg[IO_IDX_HSTCTLH][HSTCTL_NMI_BIT] <= 1'b0;
      if (wvp_set === 1'b1)
        io_reg[IO_IDX_INTPEND][INT_WV_BIT] <= 1'b1;
`endif
      // Display interrupt (P0012): when DPYCTL.ENV (bit 15) is enabled, set
      // INTPEND.DI at HSBLNK on the DPYINT line. ENV gates only this SET event;
      // disabling it neither clears an already-pending DI nor stops the raster.
      // Independent of the else-if chain above so a coincident I/O write to a
      // DIFFERENT register cannot drop the frame's DI. A same-cycle write to
      // INTPEND itself: this bit-select assign wins for bit DI (set-dominant),
      // matching the device-sets / software-clears model (the handler clears DI
      // by writing INTPEND). dpyint_pulse is a ce-gated one-clock strobe (once
      // per frame), so it never fights RETI.
      // Gate on a programmed raster (VTOTAL != 0) so the reset state (all timing
      // regs 0 -> pulse whenever ce fires) doesn't spam INTPEND.DI before the
      // game sets up video. Harmless while IE=0, but keep it clean.
      if (dpyint_event) begin
        io_reg[IO_IDX_INTPEND][INT_DI_BIT] <= 1'b1;
      end

      // MAME 0.289 tms34010.cpp display-address update path. At VSBLNK the
      // device reloads DPYADR from DPYSTRT. On each visible scanline it first
      // walks the
      // two-bit Y subrow down to zero, then subtracts DPYCTL.DUDATE while
      // restoring DPYSTRT's subrow.  A CPU write to DPYADR on this physical
      // edge is newest and therefore wins over the automatic action.
      if (!(req && we && wr_is_io && (wr_idx == IO_IDX_DPYADR))) begin
        if (vblank_start_o) begin
          io_reg[IO_IDX_DPYADR] <= io_reg[IO_IDX_DPYSTRT];
        end else if (video_line_advance &&
                     (vid_vcount >= io_reg[IO_IDX_VEBLNK]) &&
                     (vid_vcount <  io_reg[IO_IDX_VSBLNK])) begin
          if (io_reg[IO_IDX_DPYADR][1:0] == 2'b00) begin
`ifdef MUT_DPYADR_NO_DUDATE
            // Discriminating mutation: hold at the subrow boundary instead of
            // advancing to the next display row.
            io_reg[IO_IDX_DPYADR] <= io_reg[IO_IDX_DPYADR];
`else
            io_reg[IO_IDX_DPYADR] <=
              ((io_reg[IO_IDX_DPYADR] & 16'hfffc) -
               (io_reg[IO_IDX_DPYCTL] & 16'h03fc)) |
              (io_reg[IO_IDX_DPYSTRT] & 16'h0003);
`endif
          end else begin
            io_reg[IO_IDX_DPYADR] <=
              (io_reg[IO_IDX_DPYADR] & 16'hfffc) |
              ((io_reg[IO_IDX_DPYADR] - 16'd1) & 16'h0003);
          end
        end
      end
    end
  end

endmodule : tms34010_io_regs

`default_nettype wire
