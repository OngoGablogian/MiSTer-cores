// Audio telemetry crossing, 12 MHz sound domain -> 80 MHz system domain.
//
// The telemetry words are rewritten once per one-second window and are stable
// for the whole second in between, so a toggle handshake carries the entire set
// coherently: the source flags a window close, and the destination captures the
// bus only after the toggle has resolved through two stages.  Capturing the raw
// words with per-bit synchronisers instead would allow a torn value spanning two
// windows, which on a rate field reads as a plausible wrong number rather than
// as an obvious fault.
`default_nettype none
module tunit_audio_tel_cdc (
  input  wire logic        clk_snd,
  input  wire logic        clk_sys,
  input  wire logic        rst_pon,

  input  wire logic        tick_snd,
  input  wire logic [15:0] ym_snd, firq_snd, dac_snd, oki_snd,
  input  wire logic [15:0] erate_snd, romwait_snd, cmdrd_snd, misc_snd,

  output logic [31:0]      row_a,   // {ym_per_s, firq_per_s}
  output logic [31:0]      row_b,   // {dac_per_s, oki_writes}
  output logic [31:0]      row_c,   // {e_rate_cpct, romwait_pct}
  output logic [31:0]      row_d    // {cmd_reads, misc}
);
  // Preserved for the same reason as tunit_adpcm_rom_cdc's payloads: the skew
  // constraint is name-based and a merged/duplicated register empties it.
  logic        tog_snd;
  (* preserve *) logic [15:0] h_ym, h_firq, h_dac, h_oki, h_erate, h_romwait, h_cmdrd, h_misc;

  always_ff @(posedge clk_snd) begin
    if (rst_pon) begin
      tog_snd <= 1'b0;
      {h_ym,h_firq,h_dac,h_oki,h_erate,h_romwait,h_cmdrd,h_misc} <= '0;
    end else if (tick_snd) begin
      h_ym <= ym_snd; h_firq <= firq_snd; h_dac <= dac_snd; h_oki <= oki_snd;
      h_erate <= erate_snd; h_romwait <= romwait_snd;
      h_cmdrd <= cmdrd_snd; h_misc <= misc_snd;
      tog_snd <= ~tog_snd;
    end
  end

  (* preserve, async_reg = "true" *) logic [1:0] tog_sync;
  logic tog_seen;

  always_ff @(posedge clk_sys) begin
    if (rst_pon) begin
      tog_sync <= 2'b00; tog_seen <= 1'b0;
      row_a <= '0; row_b <= '0; row_c <= '0; row_d <= '0;
    end else begin
      tog_sync <= {tog_sync[0], tog_snd};
      if (tog_sync[1] != tog_seen) begin
        tog_seen <= tog_sync[1];
        row_a <= {h_ym,    h_firq};
        row_b <= {h_dac,   h_oki};
        row_c <= {h_erate, h_romwait};
        row_d <= {h_cmdrd, h_misc};
      end
    end
  end
endmodule
`default_nettype wire
