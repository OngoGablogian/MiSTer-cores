// Quartus-17 boundary package for the MiSTer wrapper.
//
// The game-side synthesis blob has already resolved tunit_pkg through sv2v.
// Arcade-TUnit.sv only needs the profile width at that boundary. Keep it as a
// packed logic typedef here so SystemVerilog's implicit .profile connection is
// assignment-equivalent to the Verilog-2005 blob port.

`default_nettype none
package tunit_pkg;
  typedef logic [2:0] tunit_profile_t;
endpackage
`default_nettype wire
