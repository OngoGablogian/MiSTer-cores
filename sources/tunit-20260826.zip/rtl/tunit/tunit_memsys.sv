// T-unit main-CPU memory system: exact CPU map plus DMA2 register adapter.
// Bulk storage remains behind explicit ports so the board-level wrapper can
// arbitrate SDRAM/DDR without importing Wolf-unit placement assumptions.

`default_nettype none
module tunit_memsys
  import tunit_pkg::*;
  import tunit_profile_layout_pkg::*;
(
  input  wire logic        clk,
  input  wire logic        rst,
  input  wire logic        ce_cpu,
  input  wire tunit_profile_t profile,
  input  wire tunit_variant_t variant,
  input  wire logic        gfx_rom_large,

  input  wire logic        mem_req,
  input  wire logic        mem_we,
  input  wire logic [31:0] mem_addr,
  input  wire logic [5:0]  mem_size,
  input  wire logic [31:0] mem_wdata,
  input  wire logic        mem_srt,
  output logic [31:0] mem_rdata,
  output logic        mem_ack,

  input  wire logic [15:0] in0,
  input  wire logic [15:0] in1,
  input  wire logic [15:0] in2,
  input  wire logic [15:0] dsw,

  output logic        store_req,
  output logic        store_we,
  output logic        store_srt,
  output tunit_map_target_t store_target,
  output logic [27:0] store_word_addr,
  output logic [3:0]  store_bit_offset,
  output logic [5:0]  store_size,
  output logic [31:0] store_wdata,
  input  wire logic [31:0] store_rdata,
  input  wire logic        store_ack,

  output logic        rom_req,
  output logic        rom_is_gfx,
  output logic [23:0] rom_byte_addr,
  input  wire logic [47:0] rom_line,
  input  wire logic        rom_ack,

  output logic        dcs_status_rd,
  output logic        dcs_data_rd,
  output logic        dcs_data_wr,
  output logic        dcs_data_offset,
  output logic [15:0] dcs_wdata,
  output logic [1:0]  dcs_byte_en,
  input  wire logic [15:0] dcs_status_rdata,
  input  wire logic [15:0] dcs_data_rdata,

  // Blit-queue health. The queue does NOT back-pressure: a trigger arriving
  // full is DROPPED silently (midway_dma.sv:770-772). This was discarded here
  // for the whole life of the core, which is why the NBA Jam sprite regression
  // needed a cabinet round trip to find instead of one panel reading.
  output logic        dbg_q_overflow,
  output logic [15:0] dbg_q_drops,
  output logic        dma_src_req,
  output logic [31:0] dma_src_addr,
  output logic        dma_src_active,
  output logic        dma_src_stream,
  input  wire logic [7:0]  dma_src_data,
  input  wire logic        dma_src_ack,
  output logic        dma_fb_we,
  output logic [FB_ADDR_W-1:0] dma_fb_addr,
  output logic [15:0] dma_fb_wdata,
  input  wire logic        dma_fb_ack,
  input  wire logic        dma_wr_busy,
  output logic        dma_busy,
  // TUNIT_DIAG: {count of DMA register writes, last DMA_COMMAND value}.
  // Answers whether the CPU ever asks for a blit at all.
  output logic [31:0] dbg_dma_activity,
  // Sticky diagnostic-only witness: the title attempted its SRT page erase
  // before the renderer and downstream VRAM write path had both retired.
  output logic        dbg_srt_dma_overlap,
  output logic        lint1,
  output logic [15:0] dma_palette,

  output logic        video_bank,
  output logic [23:0] gfx_bank_offset,
  output logic [15:0] control_word,
  output logic        cmos_write_enable,
  output logic        watchdog_kick,
  output logic [7:0]  last_target
);

  // The ce_cpu-gated core asserts and then holds every command until ack.
  // Capture it on the first following 80 MHz edge. Qualifying acceptance with
  // ce_cpu would miss the just-asserted request at that edge and postpone it
  // by a complete CPU-enable interval.
  wire logic cpu_step = ce_cpu !== 1'b0;
  logic [2:0] request_age_q;
`ifndef MUT_TUNIT_CPU_LEGACY_SCHED
  // The exact scheduler runs the microengine at 80 MHz. A command launched on
  // one edge is held through acknowledgement, so the adapter captures it on
  // the following edge. Registered decode and per-class command boundaries
  // keep this production path shallow without adding gameplay-visible latency.
  wire logic request_ready = mem_req;
`elsif TUNIT_MEMSYS_FAST_REQ
  // Diagnostic mutation: accept the held CPU command on the first full-rate
  // edge after it is presented.  The core changes the payload only on a
  // ce_cpu edge and holds it through acknowledgement, so that intervening
  // edge is already a complete setup interval.
  wire logic request_ready = mem_req;
`else
  wire logic request_ready = mem_req && request_age_q[2];
`endif

  // T-unit DMA2 occupies exactly one 256-bit-address page at 01A80000.
  // Select that fixed page directly instead of placing the complete board map
  // decoder in front of both command adapters.  The mapped router performs
  // its full target decode from a registered address in its existing route
  // phase; DMA2 retains the same first-edge capture as every other request.
  wire logic dma_select = mem_req &&
                          (mem_addr[31:8] == TMAP_DMA_LO[31:8]);

  // Preserve the ordering between software-visible DMA completion and the
  // TMS34010 shift-register page erase which follows it. TIMED_IRQ_PUMP can
  // clear DMACTRL[15] while this serialized renderer still owes pixels. If an
  // SRT write reaches the VRAM D lane in that false-idle window, it can erase
  // the old page before the renderer resumes and repaints stale UI over it.
  // The CPU holds the complete SRT request until acknowledgement, so delaying
  // mapped acceptance until renderer/write retirement needs no payload capture
  // and preserves the program order MAME gets from synchronous draws. Reads
  // remain unchanged because NBA/TE perform their SRT latch before DMA starts.
`ifdef SYNTHESIS
  wire logic mem_srt_i = mem_srt;
`else
  // Older focused benches may leave the post-P0027 sideband unconnected.
  wire logic mem_srt_i = (mem_srt === 1'b1);
`endif
`ifdef MUT_TUNIT_SRT_DMA_ORDER_REVERT
  wire logic srt_dma_wait_w = 1'b0;
`else
  wire logic srt_dma_wait_w = request_ready && !dma_select && mem_srt_i &&
                              mem_we && (dma_busy || dma_wr_busy);
`endif

  logic [31:0] mapped_rdata;
  logic mapped_ack;
  (* preserve *) logic cpu_ack_q;
`ifndef MUT_TUNIT_CPU_LEGACY_SCHED
  wire logic mapped_retire_step = cpu_step && mapped_ack;
`elsif TUNIT_MEMSYS_DIRECT_ACK
  // Diagnostic mutation: both adapters hold their registered completion, so
  // let the next ce_cpu edge consume it directly instead of first copying it
  // into a second response register and waiting one more ce_cpu interval.
  wire logic mapped_retire_step = cpu_step && mapped_ack;
`else
  wire logic mapped_retire_step = cpu_step && cpu_ack_q && mapped_ack;
`endif

  tunit_mem mapped (
    .clk, .rst, .ce_cpu(mapped_retire_step), .profile, .variant,
    .mem_req(request_ready && !dma_select && !srt_dma_wait_w),
    .mem_we, .mem_addr, .mem_size,
    .mem_wdata, .mem_rdata(mapped_rdata), .mem_ack(mapped_ack),
    .in0, .in1, .in2, .dsw,
    .store_req, .store_we, .store_target, .store_word_addr,
    .store_bit_offset, .store_size, .store_wdata, .store_rdata, .store_ack,
    .rom_req, .rom_is_gfx, .rom_byte_addr, .rom_line, .rom_ack,
    .dcs_status_rd, .dcs_data_rd, .dcs_data_wr, .dcs_data_offset,
    .dcs_wdata, .dcs_byte_en, .dcs_status_rdata, .dcs_data_rdata,
    .video_bank, .gfx_bank_offset, .control_word,
    .cmos_write_enable, .watchdog_kick, .last_target
  );

  // The core holds mem_srt with the request until acknowledgement. Preserve
  // that qualifier through the mapped-memory/store-router latency.
  assign store_srt = mem_srt && (store_target == MAP_VRAM);

  logic dma_reg_we;
  logic [3:0] dma_reg_addr;
  logic [15:0] dma_reg_wdata;
  logic [15:0] dma_reg_rdata;
  logic [15:0] dma_reg_merge_rdata;

  // Use the cabinet-proven Wolf command engine for both board families. T and
  // Wolf share this DMA2 register set; the profile-specific differences live
  // outside the renderer. The timed IRQ pump preserves the ASIC-visible
  // completion cadence while physical busy remains held through write drain.
  midway_dma #(
    .TIMED_IRQ_PUMP(1'b1),
    // DMA2.DOC and the shipped NBA/TE display loops agree on the literal
    // control contract: first DGO=0 halts, DGO=1 resumes, and the second
    // consecutive zero kills.  Do not reinterpret the frame-boundary kill as
    // a request to drain this RTL's private modeled-cadence queue.
    .DRAIN_QUEUED_ON_STOP(1'b0),
    // P0041: 256 was sized on MK2, whose worst captured frame issues 332
    // commands but draws large sprites the renderer retires quickly. NBA Jam
    // TE issues 436 in its worst captured frame (frame 204 of
    // te_blit_stream.txt) and they are small, so arrivals outrun retirement
    // and the queue reached 256 and DROPPED commands -- silently, because
    // NOW CONNECTED (2026-08-10). Dropped blits are missing
    // graphics with no other symptom. 512 covers the worst measured frame of
    // any title with margin.
    .NORMAL_Q_DEPTH(512)
  ) dma (
    .clk, .rst, .gfx_rom_large,
    .reg_we(dma_reg_we), .reg_addr(dma_reg_addr),
    .reg_wdata(dma_reg_wdata), .reg_rdata(dma_reg_rdata),
    .reg_merge_rdata(dma_reg_merge_rdata),
    .src_req(dma_src_req), .src_addr(dma_src_addr),
    .src_active(dma_src_active), .src_stream(dma_src_stream),
    .src_data(dma_src_data), .src_ack(dma_src_ack),
    .fb_we(dma_fb_we), .fb_addr(dma_fb_addr), .fb_wdata(dma_fb_wdata),
    .fb_ack(dma_fb_ack), .wr_busy(dma_wr_busy),
    .busy(dma_busy), .blit_irq(lint1), .dma_palette,
    .dbg_q_overflow(dbg_q_overflow), .dbg_q_highwater(), .dbg_q_drops(dbg_q_drops)
  );

`ifdef TUNIT_DIAG
  // The cabinet reads dma_busy == 0 on every title, so the blitter never
  // starts. Distinguish the three causes: the CPU never writes the DMA block
  // (count 0), it writes but never sets the go bit (count > 0, last_cmd
  // bit15 = 0), or it does trigger and the engine ignores it (bit15 = 1 with
  // busy still 0). DMA_COMMAND is register index 1.
  logic [15:0] dma_we_count_r, dma_last_cmd_r;
  logic srt_dma_overlap_r;
  always_ff @(posedge clk) begin
    if (rst) begin
      dma_we_count_r <= 16'd0;
      dma_last_cmd_r <= 16'd0;
      srt_dma_overlap_r <= 1'b0;
    end else begin
      if (dma_reg_we && dma_we_count_r != 16'hffff)
        dma_we_count_r <= dma_we_count_r + 16'd1;
      if (dma_reg_we && dma_reg_addr == 4'd1)
        dma_last_cmd_r <= dma_reg_wdata;
      // mem_srt_i is asserted only for the CPU's shift-register transaction,
      // so re-decoding !dma_select here is redundant.  Keeping that address
      // comparison on this diagnostic flop pulled the CPU ALU/address cone
      // into srt_dma_overlap_r and cost 4.239 ns of setup.  The production
      // ordering barrier above retains its full request qualification.
      if (request_ready && mem_srt_i && mem_we &&
          (dma_busy || dma_wr_busy))
        srt_dma_overlap_r <= 1'b1;
    end
  end
  assign dbg_dma_activity = {dma_we_count_r, dma_last_cmd_r};
  assign dbg_srt_dma_overlap = srt_dma_overlap_r;
`else
  assign dbg_dma_activity = 32'd0;
  assign dbg_srt_dma_overlap = 1'b0;
`endif

  typedef enum logic [3:0] {
    D_IDLE, D_R0, D_R1, D_R2, D_R3,
    D_W0_PRE, D_W0, D_W1_PRE, D_W1, D_W2_PRE, D_W2
  } dstate_t;
  dstate_t dstate;
  // Completion is a distinct held response phase rather than a decode of the
  // adapter FSM.  Besides shortening the CPU write-enable path, this lets the
  // multiword engine return to idle while the ce_cpu-gated core waits for its
  // next sampling edge.  Preserve the flop so synthesis cannot fold it back
  // into a state decode.
  (* preserve *) logic dma_ack_q;
  logic [4:0] d_word_base;
  logic [3:0] d_bit_offset;
  logic [5:0] d_size;
  logic [31:0] d_wdata;
  logic [31:0] d_rdata;
  logic [31:0] d_read_lo;
  logic [15:0] d_read_hi;

  logic [1:0] d_phase;
  logic [4:0] d_word_index;
  logic d_word_valid;
  logic [47:0] d_field_mask;
  logic [47:0] d_shifted_wdata;
  logic [15:0] d_word_mask;
  logic [15:0] d_word_bits;
  logic [15:0] d_read_word;
  logic [15:0] d_write_data_q;
  logic        d_write_valid_q;

  always_comb begin
    case (dstate)
      D_R1, D_W1_PRE, D_W1: d_phase = 2'd1;
      D_R2, D_W2_PRE, D_W2: d_phase = 2'd2;
      default:    d_phase = 2'd0;
    endcase
    d_word_index = d_word_base + {3'd0, d_phase};
    d_word_valid = d_word_index < 5'd16;
    dma_reg_addr = d_word_index[3:0];

    d_field_mask = 48'd0;
    if (d_size != 0)
      d_field_mask = ((48'd1 << d_size) - 48'd1) << d_bit_offset;
    d_shifted_wdata = {16'd0, d_wdata} << d_bit_offset;
    case (d_phase)
      2'd1: begin
        d_word_mask = d_field_mask[31:16];
        d_word_bits = d_shifted_wdata[31:16];
      end
      2'd2: begin
        d_word_mask = d_field_mask[47:32];
        d_word_bits = d_shifted_wdata[47:32];
      end
      default: begin
        d_word_mask = d_field_mask[15:0];
        d_word_bits = d_shifted_wdata[15:0];
      end
    endcase
    dma_reg_wdata = d_write_data_q;
    dma_reg_we = ((dstate == D_W0) || (dstate == D_W1) ||
                  (dstate == D_W2)) && d_write_valid_q;
    d_read_word = d_word_valid ? dma_reg_rdata : 16'hffff;
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      dstate <= D_IDLE;
      d_word_base <= 0;
      d_bit_offset <= 0;
      d_size <= 0;
      d_wdata <= 0;
      d_rdata <= 0;
      d_read_lo <= 0;
      d_read_hi <= 0;
      d_write_data_q <= 0;
      d_write_valid_q <= 0;
      dma_ack_q <= 1'b0;
    end else begin
      if (dma_ack_q) begin
        if (cpu_step && mem_ack) dma_ack_q <= 1'b0;
      end else if ((dstate == D_R3) || (dstate == D_W2)) begin
        dma_ack_q <= 1'b1;
      end
      case (dstate)
        // Match the mapped-memory port: the ce_cpu-gated core holds its
        // command until ack, so capture on the first full-rate system clock
        // after assertion and then run the multiword adapter at full rate.
        D_IDLE: if (request_ready && dma_select && !dma_ack_q) begin
          d_word_base <= {1'b0, mem_addr[7:4]};
          d_bit_offset <= mem_addr[3:0];
          d_size <= mem_size;
          d_wdata <= mem_wdata;
          dstate <= mem_we ? D_W0_PRE : D_R0;
        end
        D_R0: begin
          d_read_lo[15:0] <= d_read_word;
          dstate <= D_R1;
        end
        D_R1: begin
          d_read_lo[31:16] <= d_read_word;
          dstate <= D_R2;
        end
        D_R2: begin
          // Register the third adapter word before the variable field
          // extraction.  This removes the live state/address decode from the
          // full-width shift path at 80 MHz.
          d_read_hi <= d_read_word;
          dstate <= D_R3;
        end
        D_R3: begin
          d_rdata <= 32'(({d_read_hi, d_read_lo} >> d_bit_offset) &
                         ((48'd1 << d_size) - 48'd1));
          dstate <= D_IDLE;
        end
        // Precompute and register each partial-field merge before presenting
        // it to the DMA register file. The following commit state therefore
        // has only a short registered-data write path at 80 MHz.
        D_W0_PRE, D_W1_PRE, D_W2_PRE: begin
          d_write_data_q <= (dma_reg_merge_rdata & ~d_word_mask) |
                            (d_word_bits & d_word_mask);
          d_write_valid_q <= d_word_valid && (d_word_mask != 0);
          case (dstate)
            D_W0_PRE: dstate <= D_W0;
            D_W1_PRE: dstate <= D_W1;
            default:  dstate <= D_W2;
          endcase
        end
        D_W0: dstate <= D_W1_PRE;
        D_W1: dstate <= D_W2_PRE;
        D_W2: begin
          d_rdata <= 0;
          dstate <= D_IDLE;
        end
        default: dstate <= D_IDLE;
      endcase
    end
  end

  // The memory adapters finish at the full 80 MHz rate, while the CPU consumes
  // their data only on ce_cpu. Sample a held adapter completion into cpu_ack_q
  // on a ce_cpu edge. The CPU observes the old value on that edge and consumes
  // the registered acknowledgement on the following ce_cpu edge, at least
  // three full system clocks later. This makes acknowledgement-to-CPU timing a
  // real clock-enable path instead of a live adapter-state decode.
  //
  // Requests use one additional full-rate qualification stage. A command
  // launched on a ce_cpu edge is therefore stable for four complete system
  // clocks before either full-rate adapter captures it.
  always_ff @(posedge clk) begin
    if (rst) begin
      request_age_q <= 3'b000;
      cpu_ack_q     <= 1'b0;
    end else begin
      // Require a newly presented (or atomically replaced) CPU command to
      // remain stable for four full-rate clocks before either adapter may
      // capture it. A retiring ce_cpu edge resets the age even when mem_req
      // stays high for the next step of a multi-transfer instruction.
      if (!mem_req || (cpu_step && mem_ack))
        request_age_q <= 3'b000;
      else if (!request_age_q[2])
        request_age_q <= {request_age_q[1:0], 1'b1};

      if (cpu_step) begin
        if (cpu_ack_q)
          cpu_ack_q <= 1'b0;
        else
          cpu_ack_q <= dma_ack_q | mapped_ack;
      end
    end
  end

  // dma_ack_q owns the response mux until the registered CPU acknowledgement
  // retires the held transfer. The single-outstanding CPU protocol makes
  // mapped_ack and dma_ack_q mutually exclusive.
`ifndef MUT_TUNIT_CPU_LEGACY_SCHED
  assign mem_ack = dma_ack_q | mapped_ack;
`elsif TUNIT_MEMSYS_DIRECT_ACK
  assign mem_ack = dma_ack_q | mapped_ack;
`else
  assign mem_ack = cpu_ack_q;
`endif
  assign mem_rdata = dma_ack_q ? d_rdata : mapped_rdata;

endmodule
`default_nettype wire
