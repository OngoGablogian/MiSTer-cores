// Assemble the CPU's 48-bit graphics-ROM read window from the proven
// byte-granular Wolf/T-unit DDR cache interface.

`default_nettype none
module tunit_gfx_line(
  input  wire logic clk,
  input  wire logic rst,
  input  wire logic line_req,
  input  wire logic [23:0] line_byte_addr,
  output logic [47:0] line_data,
  output logic line_ack,
  output logic byte_req,
  output logic [25:0] byte_addr,
  input  wire logic [7:0] byte_data,
  input  wire logic byte_ack
);
  typedef enum logic[2:0]{G_IDLE,G_READ,G_GAP,G_SERVE} state_t;
  state_t state;
  logic[23:0]base_q;
  logic[2:0]index;
  assign byte_req=state==G_READ;
  assign byte_addr={2'd0,base_q}+index;
  assign line_ack=state==G_SERVE;
  always_ff @(posedge clk)begin
    if(rst)begin state<=G_IDLE;base_q<=0;index<=0;line_data<=0;end
    else case(state)
      G_IDLE:if(line_req)begin base_q<=line_byte_addr;index<=0;state<=G_READ;end
      G_READ:if(byte_ack)begin
        line_data[8*index+:8]<=byte_data;
        if(index==3'd5)state<=G_SERVE;
        else begin index<=index+1'b1;state<=G_GAP;end
      end
      G_GAP:state<=G_READ;
      G_SERVE:if(!line_req)state<=G_IDLE;
      default:state<=G_IDLE;
    endcase
  end
endmodule
`default_nettype wire
