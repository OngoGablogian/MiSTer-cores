// Midway T-unit framebuffer scanout.
//
// The T-unit TMS34010 video clock is 4 MHz with two physical pixels per video
// clock. This block serializes those pairs at the effective 8 MHz pixel rate;
// pair_x changes only once per two ce_pix pulses and tms_ce marks that boundary.
// This is intentionally not Wolf's one-pixel-per-TMS-clock model.

`default_nettype none

module tunit_video
  import tunit_pkg::*;
#(
  parameter int H_ACT  = 400,
  parameter int H_FP   = 6,
  parameter int H_SYNC = 43,
  parameter int H_BP   = 57,
  parameter int V_ACT  = 254,
  parameter int V_FP   = 15,
  parameter int V_SYNC = 3,
  parameter int V_BP   = 17,
  // TUNIT-P0034 -- follow the cabinet-proven Wolf core. wolf_top.sv:551 builds
  // wolf_video with USE_TMS_RASTER_SYNC(1), which re-anchors the output raster
  // to the TMS VSBLNK edge EVERY frame (wolf_video.sv:133-141). T-unit only
  // re-anchored on `timing_start`, a CRTC register WRITE, and free-ran between
  // them -- so the page fence armed on the TMS raster while committing against
  // this one, with nothing to pull the two back into step. Default on.
  parameter bit USE_TMS_RASTER_SYNC = 1,
  // Blank lines reserved at the END of vblank, during which the page flip may
  // no longer commit so current+next can prime before the third opportunistic
  // lookahead row.
  // Default 4 preserves the T-unit cabinet baseline. Wolf now uses 1, but its
  // program and publication path are not a source oracle for T-unit. Keep this
  // parameterized for tb_tunit_flip_deadline; do not change the default without
  // the deadline/cache-miss sweep and cabinet confirmation.
  parameter int FLIP_PREFETCH_LINES = 4
)(
  input  wire logic   clk,
  input  wire logic   rst,
  input  wire logic   ce_pix,       // effective 8 MHz physical-pixel enable
  input  wire logic   timing_start, // registered TMS HTOTAL activation/rephase
  input  wire logic   vblank_start, // TMS34010 VSBLNK edge; per-frame re-anchor
  input  wire logic   disp_enable,  // live DPYCTL.ENV
  // NBA/TE clear the hidden page with DPYCTL.SRT while ENV is low.  The FPGA
  // backend serializes that transfer; this profile-scoped hold keeps the last
  // published page visible during the extended SRT interval.
  input  wire logic   env_srt_visible_hold,
  // TUNIT-P0048 -- live HEBLNK >= HSBLNK. In pinned MAME 0.289,
  // tms340x0_ind16 calls the driver for [heblnk,hsblnk), then black-pens the
  // portions outside that span. midtunit_video_device::scanline_update paints
  // the same half-open interval (src/mame/williams/midtunit_v.cpp:848-856). Thus
  // HEBLNK == HSBLNK paints no game pixels and blacks the complete visible
  // line. The invalid zero-width visible area is not installed by MAME's
  // screen-reconfigure guard. NBA Jam and NBA TE deliberately perform this
  // write pair (historicalsource-nbajam/UTIL.ASM:1832-1861 and
  // historicalsource-nbajamte/UTIL.ASM:1774-1804).
  // X-safe by the same idiom as disp_enable below: unconnected => never blank,
  // so every pre-existing bench keeps its current behaviour.
  input  wire logic   display_blank,

  // Live TMS get_display_params values. col0 is already
  // params->coladdr << 1 and reduced modulo the 512-column row.
  input  wire logic [FB_ADDR_W-1:0] disp_row0,
  input  wire logic [8:0]      disp_col0,

  output logic [FB_ADDR_W-1:0] vram_raddr,
  input  wire logic [15:0]     vram_rdata,
  output logic [14:0]          pal_raddr,
  input  wire logic [15:0]     pal_rdata,

  output logic [7:0]  vid_r, vid_g, vid_b,
  output logic        hsync, vsync,
  output logic        hblank, vblank,
  output logic        de,
  output logic        vblank_irq,
  output logic        tms_ce,
  output logic        pixel_pair_phase,
  output logic        pixel_fetch_active,
  output logic        page_commit_window
);

  localparam int H_TOTAL = H_ACT + H_FP + H_SYNC + H_BP;
  localparam int V_TOTAL = V_ACT + V_FP + V_SYNC + V_BP;
  // The external-row BRAM plus registered palette/output path has eight
  // physical-pixel stages between address presentation and RGB. Look ahead in
  // the 512-column source row so active coordinate zero remains MAME's
  // HEBLNK-relative source pixel zero.
  // Source-index alignment against MAME midtunit_v.cpp:846-855, which requires
  // visible pixel n to show source word ((coladdr<<1) + n) & 0x1ff.
  //
  // MEASURED, not tuned (sim/tb_tunit_scanout_column_align.sv): the sync path
  // s0->s1->s2->de is THREE ce_pix registers, while the data path is only ONE
  // (the vid_r/g/b output register) -- the line-buffer read (tunit_scanline.sv:85)
  // and the palette read (tunit_local_store.sv) are both registered on the
  // FULL-RATE clock and so are sub-pixel at any ce divider. The source index
  // must therefore LAG the visible pixel index by 2, not lead it.
  //
  // This was +8, which rotated every scanline LEFT by 10 source words and
  // wrapped them onto the right edge through MAME's & 0x1ff. It reached the
  // cabinet because nothing constrained ABSOLUTE column alignment: the constant
  // appeared in one source file and zero benches, and tb_tunit_video_timing.sv
  // pins disp_col0 = 0, which cannot see a constant rotation. Confirmed on the
  // cabinet on every title INCLUDING the MK1 diagnostic menu, which is drawn
  // outside the game engine and so localised the fault to scanout geometry.
  //
  // Expressed modulo the 512-word row so the arithmetic stays unsigned.
  localparam int SOURCE_X_ADVANCE = 510;   // == -2 (mod 512)
  localparam int H_PAIRS = H_TOTAL / 2;
  localparam int H_RAW_VIS_START = H_SYNC + H_BP;
  localparam int V_RAW_VIS_START = V_SYNC + V_BP;
  localparam int H_RESET_PAIR = (H_TOTAL - H_RAW_VIS_START) / 2;
  // Reset occurs partway through the output raster's final raw line while the
  // TMS counter starts at HCOUNT=0. Account for that partial first line so
  // output active line zero coincides with TMS VCOUNT=VEBLNK.
  localparam int V_RESET_LINE = V_TOTAL - V_RAW_VIS_START - 1;

  // T-unit's 506-dot line is exactly 253 TMS video clocks.
  initial begin
    if ((H_TOTAL & 1) != 0) $error("tunit_video H_TOTAL must be even");
    // Both TMS anchors land on raw sync position zero, which in these
    // active-first coordinates is H_ACT+H_FP -- the same horizontal point
    // wolf_video.sv:135 uses. Pin that equality rather than restating 203.
    if (H_RESET_PAIR * 2 != H_ACT + H_FP)
      $error("tunit_video H_RESET_PAIR must equal (H_ACT+H_FP)/2");
  end

  logic [8:0] pair_x;
  logic [11:0] vc;
  logic phase;
  wire [11:0] physical_x = {2'b00, pair_x, 1'b0} + phase;
  assign pixel_pair_phase = phase;
  assign tms_ce = ce_pix && phase;
  wire logic timing_start_eff = (timing_start === 1'b1);
  wire logic disp_enable_eff = (disp_enable === 1'b0) ? 1'b0 : 1'b1;
  wire logic env_srt_visible_hold_eff =
      (env_srt_visible_hold === 1'b1) ? 1'b1 : 1'b0;
  wire logic display_blank_eff = (display_blank === 1'b1) ? 1'b1 : 1'b0;
  wire logic raster_sync_i = USE_TMS_RASTER_SYNC && (vblank_start === 1'b1);

  always_ff @(posedge clk) begin
    if (rst || timing_start_eff) begin
      // The output coordinate system is active-first, while the 34010 CRTC
      // resets at raw sync position zero. Start at the equivalent negative
      // visible offset so active (0,0) coincides with (HEBLNK,VEBLNK) in the
      // live TMS counters after the initial blank interval.
      pair_x <= 9'(H_RESET_PAIR);
      vc <= 12'(V_RESET_LINE);
      phase <= 1'b0;
      vblank_irq <= 1'b0;
    end else if (raster_sync_i) begin
      // Per-frame re-anchor, mirroring wolf_video.sv:133-141. VCOUNT has just
      // entered VSBLNK, so the vertical coordinate sits one line below active
      // end and advances to V_ACT when this line completes. Deliberately NOT
      // gated on ce_pix: tms_ce is a strict subset of ce_pix, so the core's
      // one-clock VSBLNK pulse need not coincide with a pixel enable, and
      // sampling it under ce_pix would silently drop frames.
      pair_x <= 9'(H_RESET_PAIR);
      vc <= 12'(V_ACT - 1);
      phase <= 1'b0;
      vblank_irq <= 1'b0;
    end else if (ce_pix) begin
      vblank_irq <= 1'b0;
      if (!phase) begin
        phase <= 1'b1;
      end else begin
        phase <= 1'b0;
        if (pair_x == H_PAIRS-1) begin
          pair_x <= 9'd0;
          if (vc == V_TOTAL-1) vc <= 12'd0;
          else begin
            vc <= vc + 12'd1;
            if (vc == V_ACT-1) vblank_irq <= 1'b1;
          end
        end else pair_x <= pair_x + 9'd1;
      end
    end
  end

  logic s0_de, s0_active, s0_content_blank, s0_hs, s0_vs, s0_hb, s0_vb;
  wire logic geom_active = (physical_x < H_ACT) && (vc < V_ACT);
  always_comb begin
    // s0_active is the raster's own idea of "inside the active window" and is
    // deliberately INDEPENDENT of the blank: it keeps driving the scanline
    // prefetch and the VRAM/palette address generator so a game-driven blank
    // episode cannot cold-start the line cache on unblank. Only the emitted
    // pixel content is blanked, which is what MAME does (it black-pens the
    // bitmap; m_local_videoram and raster transport are untouched).
`ifdef MUT_TUNIT_ENV_COLLAPSE_TRANSPORT
    s0_active = disp_enable_eff && geom_active;
    s0_de = s0_active;
    s0_content_blank = display_blank_eff;
`else
    s0_active = geom_active;
    s0_de = geom_active;
`ifdef MUT_TUNIT_ENV_SRT_REBLANK
    s0_content_blank = display_blank_eff || !disp_enable_eff;
`else
    s0_content_blank = display_blank_eff ||
                       (!disp_enable_eff && !env_srt_visible_hold_eff);
`endif
`endif
    s0_hb = (physical_x >= H_ACT);
    s0_vb = (vc >= V_ACT);
    s0_hs = (physical_x >= H_ACT + H_FP) &&
            (physical_x < H_ACT + H_FP + H_SYNC);
    s0_vs = (vc >= V_ACT + V_FP) &&
            (vc < V_ACT + V_FP + V_SYNC);
  end
  assign pixel_fetch_active = s0_active;
  // Keep the final FLIP_PREFETCH_LINES blank lines exclusively for both
  // scanline buffers to prefetch after a page commit.
  assign page_commit_window = s0_vb && (vc < V_TOTAL-FLIP_PREFETCH_LINES);

  // MAME 0.289 midtunit_video_device::scanline_update:
  // src[(params->coladdr<<1 + visible_pixel) & 0x1ff], with the row
  // base masked before adding the wrapped column.
  assign vram_raddr = FB_ADDR_W'((((disp_row0 << FB_ROWSHIFT) & 32'h3fe00) +
                                  ((disp_col0 + physical_x + SOURCE_X_ADVANCE) & 12'h1ff)));
  assign pal_raddr = vram_rdata[14:0];

  logic s1_de,s1_content_blank,s1_hs,s1_vs,s1_hb,s1_vb;
  logic s2_de,s2_content_blank,s2_hs,s2_vs,s2_hb,s2_vb;
  logic [23:0] rgb;
  assign rgb = rgb555_to_888(pal_rdata);

  always_ff @(posedge clk) begin
    if (rst) begin
      s1_de<=0;s1_hs<=0;s1_vs<=0;s1_hb<=0;s1_vb<=0;
      s2_de<=0;s2_hs<=0;s2_vs<=0;s2_hb<=0;s2_vb<=0;
      s1_content_blank<=0;s2_content_blank<=0;
      de<=0;hsync<=0;vsync<=0;hblank<=0;vblank<=0;
      vid_r<=0;vid_g<=0;vid_b<=0;
    end else if (ce_pix) begin
      s1_de<=s0_de;s1_hs<=s0_hs;s1_vs<=s0_vs;s1_hb<=s0_hb;s1_vb<=s0_vb;
      s2_de<=s1_de;s2_hs<=s1_hs;s2_vs<=s1_vs;s2_hb<=s1_hb;s2_vb<=s1_vb;
      s1_content_blank<=s0_content_blank;s2_content_blank<=s1_content_blank;
      de<=s2_de;hsync<=s2_hs;vsync<=s2_vs;hblank<=s2_hb;vblank<=s2_vb;
      vid_r <= (s2_de && !s2_content_blank) ? rgb[23:16] : 8'h00;
      vid_g <= (s2_de && !s2_content_blank) ? rgb[15:8]  : 8'h00;
      vid_b <= (s2_de && !s2_content_blank) ? rgb[7:0]   : 8'h00;
    end
  end

endmodule

`default_nettype wire
