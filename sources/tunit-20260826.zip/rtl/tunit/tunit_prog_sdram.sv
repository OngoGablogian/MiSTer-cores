// Program-ROM SDRAM front end: byte-lane loader writes and 48-bit CPU fetch
// windows over one held-request 16-bit word channel.

`default_nettype none
module tunit_prog_sdram #(
  parameter int CACHE_LINES=64,
  parameter int CACHE_WORDS=8
)(
  input  wire logic        clk,
  input  wire logic        rst,

  input  wire logic        line_req,
  input  wire logic [23:0] line_byte_addr,
  output logic [47:0]      line_data,
  output logic             line_ack,

  input  wire logic        dl_wr,
  input  wire logic [18:0] dl_word_addr,
  input  wire logic [15:0] dl_wdata,
  input  wire logic [1:0]  dl_be,
  output logic             dl_ready,
  output logic             busy,
  output logic             dl_busy,

  output logic [19:0]      sd_addr,
  output logic [15:0]      sd_din,
  output logic [1:0]       sd_be,
  output logic             sd_rd,
  output logic             sd_wr,
  input  wire logic [15:0] sd_dout,
  input  wire logic        sd_ack
);
  localparam int CACHE_OFFSET_BITS=$clog2(CACHE_WORDS);
  localparam int CACHE_INDEX_BITS=$clog2(CACHE_LINES);
  localparam int CACHE_TAG_BITS=20-CACHE_OFFSET_BITS-CACHE_INDEX_BITS;

  typedef enum logic [3:0] {
    P_IDLE,P_DL,P_DL_DROP,P_LOOKUP,P_CHECK,P_FILL,P_SERVE,P_SERVE_DROP
  } state_t;
  state_t state;
  logic [19:0] base_word,fill_base;
  logic [CACHE_OFFSET_BITS-1:0]fill_offset;
  logic [18:0] dl_addr_q;
  logic [15:0] dl_data_q;
  logic [1:0] dl_be_q;
  // Two exact 48-bit windows retain the most recently executed instruction
  // windows. A hit is served on the first system clock after line_req; a miss
  // follows the registered M10K lookup below. This preserves the CPU cadence
  // for tight two-instruction loops without putting the full cache in ALMs.
  logic hot_valid0,hot_valid1;
  logic [19:0]hot_word0,hot_word1;
  logic [47:0]hot_data0,hot_data1;
  wire logic [19:0]request_word=line_byte_addr[20:1];
  wire logic hot_hit0=hot_valid0&&(request_word==hot_word0);
  wire logic hot_hit1=hot_valid1&&(request_word==hot_word1);
  logic[CACHE_LINES-1:0]cache_valid;
  logic[CACHE_TAG_BITS-1:0]cache_tag[0:CACHE_LINES-1];

  logic[19:0]cache_word0,cache_word1,cache_word2;
  logic hit0,hit1,hit2;
  assign cache_word0=base_word;
  assign cache_word1=base_word+20'd1;
  assign cache_word2=base_word+20'd2;
  assign hit0=cache_valid[cache_word0[CACHE_OFFSET_BITS +: CACHE_INDEX_BITS]]&&
    cache_tag[cache_word0[CACHE_OFFSET_BITS +: CACHE_INDEX_BITS]]==
      cache_word0[CACHE_OFFSET_BITS+CACHE_INDEX_BITS +: CACHE_TAG_BITS];
  assign hit1=cache_valid[cache_word1[CACHE_OFFSET_BITS +: CACHE_INDEX_BITS]]&&
    cache_tag[cache_word1[CACHE_OFFSET_BITS +: CACHE_INDEX_BITS]]==
      cache_word1[CACHE_OFFSET_BITS+CACHE_INDEX_BITS +: CACHE_TAG_BITS];
  assign hit2=cache_valid[cache_word2[CACHE_OFFSET_BITS +: CACHE_INDEX_BITS]]&&
    cache_tag[cache_word2[CACHE_OFFSET_BITS +: CACHE_INDEX_BITS]]==
      cache_word2[CACHE_OFFSET_BITS+CACHE_INDEX_BITS +: CACHE_TAG_BITS];
  logic[19:0]miss_word;
  always_comb begin
    if(!hit0)miss_word=base_word;
    else if(!hit1)miss_word=base_word+20'd1;
    else miss_word=base_word+20'd2;
  end

  // Bank the cache by word-within-line. Each bank is a true dual-port
  // CACHE_LINES x 16 M10K: port A is the lookup/fill port and port B reads the
  // possible second line for a 48-bit fetch that crosses a cache boundary.
  // The previous flat 512x16 array needed three combinational reads and became
  // 8,192 registers plus a large mux in Quartus.
  logic [CACHE_WORDS*16-1:0] cache_line_a_q, cache_line_b_q;
  wire logic [CACHE_INDEX_BITS-1:0] cache_port_a_index =
    (state == P_FILL)
      ? fill_base[CACHE_OFFSET_BITS +: CACHE_INDEX_BITS]
      : base_word[CACHE_OFFSET_BITS +: CACHE_INDEX_BITS];
  wire logic [CACHE_INDEX_BITS-1:0] cache_port_b_index =
    cache_word2[CACHE_OFFSET_BITS +: CACHE_INDEX_BITS];
  wire logic cache_fill_we = (state == P_FILL) && sd_ack;

  genvar cache_bank_i;
  generate
    for(cache_bank_i=0;cache_bank_i<CACHE_WORDS;cache_bank_i=cache_bank_i+1) begin: cache_bank
      // no_rw_check REMOVED -- this is the WORST instance of the false promise in the
      // tree, and it is on the PROGRAM ROM cache that feeds CPU instruction fetches.
      // The write below uses `cache_port_a_index`, the SAME index expression as read
      // port A, so read and write are at the identical address on EVERY fill cycle --
      // not "can collide", but "always collides when writing". Port B collides too
      // whenever both ports request the same line. Under no_rw_check the fitter may
      // take DONT_CARE, whose mixed-port collision output Quartus documents as
      // UNDEFINED, while Verilog models deterministic OLD data -- so simulation can
      // never show it and the cabinet would fetch undefined instruction bytes during
      // cache fills. Every gate in this tree validates against the Verilog semantics.
      (* ramstyle = "M10K" *)
      logic [15:0] data [0:CACHE_LINES-1];
      always_ff @(posedge clk) begin
        cache_line_a_q[cache_bank_i*16 +: 16] <= data[cache_port_a_index];
        cache_line_b_q[cache_bank_i*16 +: 16] <= data[cache_port_b_index];
        if(cache_fill_we && (fill_offset == cache_bank_i))
          data[cache_port_a_index] <= sd_dout;
      end
    end
  endgenerate

  wire logic [CACHE_WORDS*32-1:0] cache_two_lines =
    {cache_line_b_q,cache_line_a_q};
  wire logic [CACHE_OFFSET_BITS:0] cache_pick0 =
    {1'b0,base_word[CACHE_OFFSET_BITS-1:0]};
  wire logic [CACHE_OFFSET_BITS:0] cache_pick1 = cache_pick0 + 1'b1;
  wire logic [CACHE_OFFSET_BITS:0] cache_pick2 = cache_pick0 + 2'd2;
  wire logic [15:0] cache_data0 =
    cache_two_lines[cache_pick0*16 +: 16];
  wire logic [15:0] cache_data1 =
    cache_two_lines[cache_pick1*16 +: 16];
  wire logic [15:0] cache_data2 =
    cache_two_lines[cache_pick2*16 +: 16];

  assign line_ack = state == P_SERVE;
  assign busy = state != P_IDLE;
  // Only download work belongs in the board reset equation.  Runtime CPU
  // line fetches are normal operation and must never reassert rst_cpu.
  assign dl_busy = dl_wr || state == P_DL || state == P_DL_DROP;
  always_comb begin
    sd_addr=20'd0;sd_din=16'd0;sd_be=2'b00;sd_rd=1'b0;sd_wr=1'b0;
    case(state)
      P_DL: begin sd_addr={1'b0,dl_addr_q};sd_din=dl_data_q;sd_be=dl_be_q;sd_wr=1'b1;end
      P_FILL: begin sd_addr=fill_base+20'(fill_offset);sd_rd=1'b1;end
      default: ;
    endcase
  end

  integer cache_index;
  always_ff @(posedge clk) begin
    if(rst) begin
      state<=P_IDLE;line_data<=48'd0;dl_ready<=1'b0;
      base_word<=20'd0;fill_base<=20'd0;fill_offset<='0;
      dl_addr_q<=19'd0;dl_data_q<=16'd0;dl_be_q<=2'b00;cache_valid<='0;
      hot_valid0<=1'b0;hot_valid1<=1'b0;
      hot_word0<=20'd0;hot_word1<=20'd0;hot_data0<=48'd0;hot_data1<=48'd0;
      for(cache_index=0;cache_index<CACHE_LINES;cache_index=cache_index+1)cache_tag[cache_index]<='0;
    end else begin
      dl_ready<=1'b0;
      case(state)
        P_IDLE: begin
          if(dl_wr) begin
            dl_addr_q<=dl_word_addr;dl_data_q<=dl_wdata;dl_be_q<=dl_be;state<=P_DL;
          end else if(line_req) begin
            if(hot_hit0)begin line_data<=hot_data0;state<=P_SERVE;end
            else if(hot_hit1)begin line_data<=hot_data1;state<=P_SERVE;end
            else begin base_word<=request_word;state<=P_LOOKUP;end
          end
        end
        P_DL: if(sd_ack) begin
          cache_valid[dl_addr_q[CACHE_OFFSET_BITS +: CACHE_INDEX_BITS]]<=1'b0;
          hot_valid0<=1'b0;hot_valid1<=1'b0;
          dl_ready<=1'b1;state<=P_DL_DROP;
        end
        P_DL_DROP: if(!dl_wr) state<=P_IDLE;
        // One full clock for all banked M10K read ports to register both lines.
        P_LOOKUP: state<=P_CHECK;
        P_CHECK: begin
`ifdef TUNIT_CACHE_TRACE
          $display("PCHECK t=%0t base=%05x valid=%b tag=%x want=%x hit=%b%b%b",
            $time,base_word,cache_valid[base_word[CACHE_OFFSET_BITS +: CACHE_INDEX_BITS]],
            cache_tag[base_word[CACHE_OFFSET_BITS +: CACHE_INDEX_BITS]],
            base_word[CACHE_OFFSET_BITS+CACHE_INDEX_BITS +: CACHE_TAG_BITS],hit0,hit1,hit2);
`endif
          if(hit0&&hit1&&hit2)begin
            line_data<={cache_data2,cache_data1,cache_data0};
            hot_valid1<=hot_valid0;hot_word1<=hot_word0;hot_data1<=hot_data0;
            hot_valid0<=1'b1;hot_word0<=base_word;
            hot_data0<={cache_data2,cache_data1,cache_data0};
            state<=P_SERVE;
          end else begin
            fill_base<={miss_word[19:CACHE_OFFSET_BITS],{CACHE_OFFSET_BITS{1'b0}}};
            fill_offset<='0;
            cache_valid[miss_word[CACHE_OFFSET_BITS +: CACHE_INDEX_BITS]]<=1'b0;
            state<=P_FILL;
          end
        end
        P_FILL: if(sd_ack)begin
          if(fill_offset==CACHE_WORDS-1)begin
`ifdef TUNIT_CACHE_TRACE
            $display("PFILL DONE t=%0t base=%05x index=%0d tag=%x",$time,fill_base,
              fill_base[CACHE_OFFSET_BITS +: CACHE_INDEX_BITS],
              fill_base[CACHE_OFFSET_BITS+CACHE_INDEX_BITS +: CACHE_TAG_BITS]);
`endif
            cache_tag[fill_base[CACHE_OFFSET_BITS +: CACHE_INDEX_BITS]]<=
              fill_base[CACHE_OFFSET_BITS+CACHE_INDEX_BITS +: CACHE_TAG_BITS];
            cache_valid[fill_base[CACHE_OFFSET_BITS +: CACHE_INDEX_BITS]]<=1'b1;
            state<=P_LOOKUP;
          end else fill_offset<=fill_offset+1'b1;
        end
        P_SERVE: if(!line_req) state<=P_SERVE_DROP;
        P_SERVE_DROP: state<=P_IDLE;
        default: state<=P_IDLE;
      endcase
    end
  end

`ifndef SYNTHESIS
  initial begin
    if(CACHE_LINES<2||(CACHE_LINES&(CACHE_LINES-1))!=0)$fatal(1,"CACHE_LINES must be a power of two");
    if(CACHE_WORDS<4||(CACHE_WORDS&(CACHE_WORDS-1))!=0)$fatal(1,"CACHE_WORDS must be a power of two >=4");
  end
`endif
endmodule
`default_nettype wire
