// T-unit main-CPU host side of the Williams ADPCM sound board.
// This follows midtunit_adpcm_state::sound_state_r/sound_r/sound_w:
// offset-zero and partial writes are ignored, an accepted full-word
// offset-one write always posts its low command byte, D8 controls board reset,
// and status emulates the game's 128-read settling window.

`default_nettype none
module tunit_adpcm_host (
  input  wire logic        clk,
  input  wire logic        rst,
  input  wire logic        status_rd,
  input  wire logic        data_rd,
  input  wire logic        data_wr,
  input  wire logic        data_offset,
  input  wire logic [15:0] wdata,
  input  wire logic [1:0]  byte_en,
  output logic [15:0]      status_rdata,
  output logic [15:0]      data_rdata,
  output logic             command_wr,
  output logic [7:0]       command,
  output logic             board_reset,
  output logic [7:0]       busy_reads
);
  wire logic accepted_write =
    data_wr && data_offset && (byte_en == 2'b11);

  assign status_rdata = (busy_reads != 0) ? 16'h0000 : 16'hffff;
  assign data_rdata = 16'hffff;

  always_ff @(posedge clk) begin
    if (rst) begin
      command_wr <= 1'b0;
      command <= 8'h00;
      board_reset <= 1'b0;
      busy_reads <= 8'd0;
    end else begin
      command_wr <= 1'b0;

      if (accepted_write) begin
        command <= wdata[7:0];
        board_reset <= ~wdata[8];
        busy_reads <= 8'd128;
        command_wr <= 1'b1;
      end else if (status_rd && (busy_reads != 0)) begin
        busy_reads <= busy_reads - 1'b1;
      end
    end
  end

  // data_rd is intentionally side-effect-free. It is retained as an explicit
  // port because the common T-unit sound router distinguishes status/data
  // accesses even though MAME returns all ones for ADPCM data reads.
endmodule
`default_nettype wire
