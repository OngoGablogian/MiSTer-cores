// Lossless T-unit sound crossing between the 80 MHz main domain and the
// 12 MHz Williams ADPCM board. A toggle handshake preserves repeated command
// bytes. One queued command absorbs a second write while the first crosses;
// further writes retain the newest latch value and raise overflow_sticky.
// Profile/reset move toward the sound board only while it is held reset, and
// the stereo result returns through a coherent held-bus/toggle transfer.

`default_nettype none
module tunit_sound_cdc (
  input  wire logic       clk_sys,
  input  wire logic       clk_snd,
  input  wire logic       rst_pon,
  input  wire logic       command_wr_sys,
  input  wire logic [7:0] command_sys,
  input  wire logic       board_reset_sys,
  input  wire logic [2:0] profile_sys,
  input  wire logic signed [15:0] audio_l_snd,
  input  wire logic signed [15:0] audio_r_snd,
  output logic            command_wr_snd,
  output logic [7:0]      command_snd,
  output logic            board_reset_snd,
  output logic [2:0]      profile_snd,
  output logic signed [15:0] audio_sys,
  output logic            overflow_sticky
);
  logic req_toggle;
  (* preserve *) logic [7:0] active_command;
  logic queued_valid;
  (* preserve *) logic [7:0] queued_command;
  (* preserve, async_reg = "true" *) logic [1:0] ack_sync;

  logic req_seen;
  (* preserve, async_reg = "true" *) logic [1:0] req_sync;
  (* preserve, async_reg = "true" *) logic [1:0] reset_sync;
  logic ack_toggle;
  logic [2:0] snd_rst_pipe = 3'b111;
  // BUNDLED-DATA PAYLOAD, and the tightest crossing in the design: the toggle
  // below flips on EVERY clk_snd edge, so the destination captures at the
  // maximum possible rate and these 16 bits have only ~2-3 clk_sys of settling
  // -- the smallest margin of any payload here.  set_clock_groups -asynchronous
  // makes STA check NONE of it.  Preserved so the name-based set_max_skew in
  // rtl/tunit.sdc can actually attach; a merged or duplicated register empties
  // that collection and the crossing ships unconstrained (the Y-unit RBF did).
  (* preserve *) logic signed [15:0] audio_hold_snd;
  logic audio_toggle_snd;
  (* preserve, async_reg = "true" *) logic [1:0] audio_toggle_sync;
  logic audio_toggle_seen;

  wire logic source_idle = req_toggle == ack_sync[1];
  wire logic snd_rst = snd_rst_pipe[2];
  // Soft reset asserts immediately in the destination domain and releases
  // only after the two-stage synchronizer has observed a stable low level.
  assign board_reset_snd = board_reset_sys || reset_sync[1];

  // The power-on reset can deassert before the PLL's first 12 MHz edge.
  // Asynchronously assert and then retain reset for three destination clocks.
  always_ff @(posedge clk_snd or posedge rst_pon) begin
    if (rst_pon) snd_rst_pipe <= 3'b111;
    else snd_rst_pipe <= {snd_rst_pipe[1:0], 1'b0};
  end

  always_ff @(posedge clk_sys) begin
    if (rst_pon) begin
      req_toggle <= 1'b0;
      active_command <= 8'h00;
      queued_valid <= 1'b0;
      queued_command <= 8'h00;
      ack_sync <= 2'b00;
      audio_toggle_sync <= 2'b00;
      audio_toggle_seen <= 1'b0;
      audio_sys <= 16'sd0;
      overflow_sticky <= 1'b0;
    end else begin
      ack_sync <= {ack_sync[0], ack_toggle};
      audio_toggle_sync <= {audio_toggle_sync[0], audio_toggle_snd};
      if (audio_toggle_sync[1] != audio_toggle_seen) begin
        audio_toggle_seen <= audio_toggle_sync[1];
        audio_sys <= audio_hold_snd;
      end

      // MAME 0.289 gospel, williamssound.cpp:820-846 + midtunit_m.cpp:560-561.
      // sound_w calls reset_write() and THEN write().  device_reset() cancels a
      // PENDING sync_command and clears the IRQ lines, but never touches
      // m_latch; sync_command() then fires and sets the latch and IRQ with no
      // reset check at all.  So a command issued together with a board reset IS
      // delivered -- the 6809 takes it when reset releases.
      //
      // This previously discarded it outright, which is why NBA Jam (cabinet:
      // resets=20) reached its YM init part-configured and left Timer A at
      // value_A=0 -- a 53 Hz FIRQ against a 13,236 Hz gospel.  MK (resets=3)
      // rarely hit the window and worked.  Drop the QUEUED command to match
      // adjust(never), but let the new one through.
      if (board_reset_sys && !command_wr_sys) begin
        queued_valid <= 1'b0;
        overflow_sticky <= 1'b0;
      end else if (board_reset_sys && command_wr_sys) begin
        // Cancel anything pending, then deliver this command like sync_command.
        queued_valid <= 1'b0;
        overflow_sticky <= 1'b0;
        if (source_idle) begin
          active_command <= command_sys;
          req_toggle <= ~req_toggle;
        end else begin
          queued_command <= command_sys;
          queued_valid <= 1'b1;
        end
      end else if (source_idle && queued_valid) begin
        active_command <= queued_command;
        req_toggle <= ~req_toggle;
        if (command_wr_sys) begin
          queued_command <= command_sys;
          queued_valid <= 1'b1;
        end else begin
          queued_valid <= 1'b0;
        end
      end else if (source_idle && command_wr_sys) begin
        active_command <= command_sys;
        req_toggle <= ~req_toggle;
      end else if (command_wr_sys) begin
        if (queued_valid) overflow_sticky <= 1'b1;
        queued_command <= command_sys;
        queued_valid <= 1'b1;
      end
    end
  end

  always_ff @(posedge clk_snd) begin
    if (snd_rst) begin
      req_sync <= 2'b00;
      req_seen <= 1'b0;
      ack_toggle <= 1'b0;
      reset_sync <= 2'b11;
      command_wr_snd <= 1'b0;
      command_snd <= 8'h00;
      profile_snd <= 3'd0;
      audio_hold_snd <= 16'sd0;
      audio_toggle_snd <= 1'b0;
    end else begin
      req_sync <= {req_sync[0], req_toggle};
      reset_sync <= {reset_sync[0], board_reset_sys};
      command_wr_snd <= 1'b0;
      audio_hold_snd <= 16'sd0 +
                        (($signed({audio_l_snd[15], audio_l_snd}) +
                          $signed({audio_r_snd[15], audio_r_snd})) >>> 1);
      audio_toggle_snd <= ~audio_toggle_snd;

      // Profile is quasi-static and is sampled only while the destination board
      // is held reset.
      if (reset_sync[1])
        profile_snd <= profile_sys;

      // Delivery is NOT gated on reset.  This branch used to align req_seen to
      // req_sync while reset was asserted, swallowing the request -- so even
      // after the source side was fixed to send a reset-coincident command, the
      // destination threw it away.  MAME's sync_command (williamssound.cpp:
      // 837-845) has no reset check: it sets m_latch and raises the 6809 IRQ
      // regardless, and device_reset() (:820-830) never clears m_latch.
      // Cancelling a command that was merely PENDING is the source side's job
      // (it clears queued_valid), matching adjust(never).
      if (req_sync[1] != req_seen) begin
        req_seen <= req_sync[1];
        command_snd <= active_command;
        command_wr_snd <= 1'b1;
        ack_toggle <= req_sync[1];
      end
    end
  end
endmodule
`default_nettype wire
