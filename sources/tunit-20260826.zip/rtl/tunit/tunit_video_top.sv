// T-unit pixel pipeline plus a dynamic previous/current/next/next2 DDR3 window.

`default_nettype none
module tunit_video_top
  import tunit_pkg::*;
#(
  parameter int H_ACT=400, H_FP=6, H_SYNC=43, H_BP=57,
  parameter int V_ACT=254, V_FP=15, V_SYNC=3, V_BP=17,
  parameter int NCOL=512,
  parameter int FLIP_SETTLE_PIXELS=128,
  parameter int FLIP_PREFETCH_LINES=4,
  parameter bit BYPASS_PUBLICATION=0
)
(
  input  wire logic clk,input wire logic rst,input wire logic ce_pix,
  input  wire logic timing_start,input wire logic display_enable,
  input  wire logic env_srt_visible_hold,
  input  wire logic pending_page_prewarm_enable,
  input  wire logic display_blank, // TUNIT-P0048: live HEBLNK >= HSBLNK
  input  wire logic vblank_start,
  input  wire logic [8:0] display_row,input wire logic [8:0] next_row,
  input  wire logic [8:0] next2_row,
  input  wire logic [8:0] display_col,input wire logic wr_busy,
  input  wire logic dma_busy,
  input  wire logic cpu_snoop_valid,input wire logic[18:0]cpu_snoop_addr,
  input  wire logic[63:0]cpu_snoop_data,
  input  wire logic cpu_snoop_pending,input wire logic cpu_snoop_overflow,
  output logic [14:0] palette_addr,input wire logic[15:0]palette_data,
  output logic scan_req,output logic[18:0]scan_addr,
  input  wire logic[15:0]scan_data,input wire logic scan_ack,
  output logic[7:0]vid_r,vid_g,vid_b,
  output logic hsync,vsync,hblank,vblank,de,vblank_irq,tms_ce,
  output logic scan_ready,video_underrun,output logic[31:0]video_underrun_count,
  output logic page_commit,
  // Observability only: the page the publication fence currently exposes.
  output logic active_page,
  // Release for the source-ordered post-flip SRT clear/write.
  output logic srt_write_allow
);
  logic[18:0]vram_raddr;logic[15:0]vram_rdata;logic vram_rvalid;
  logic pixel_phase,pixel_fetch_active,page_commit_window;
  logic[8:0]committed_display_row,committed_next_row,committed_next2_row;
  logic[8:0]cache_display_row,cache_next_row,cache_next2_row;
  logic[8:0]fenced_display_row,fenced_next_row;
  logic pending_prewarm,pending_page;
  wire logic pending_cache_ready = scan_ready && !cpu_snoop_pending &&
                                   !cpu_snoop_valid &&
                                   !cpu_snoop_overflow;
`ifdef MUT_TUNIT_NO_PENDING_PREWARM
  wire logic pending_page_prewarm_enable_eff = 1'b0;
`else
  wire logic pending_page_prewarm_enable_eff =
      (pending_page_prewarm_enable === 1'b1);
`endif
`ifdef MUT_TUNIT_NO_PENDING_CACHE_WARM
  wire logic pending_cache_warm_eff = 1'b0;
`else
  wire logic pending_cache_warm_eff = pending_page_prewarm_enable_eff;
`endif

  // Publication seam: the page selected by DPYADR is a proposal until the final
  // visible-page DMA/write tail has drained. The same committed page is then
  // presented to the pixel address generator and the line-cache tags. Wolf has
  // the same structure, but its HUD-flash candidates were not cabinet fixes.
  tunit_page_fence #(.SETTLE_PIXELS(FLIP_SETTLE_PIXELS)) page_fence(
    .clk,.rst,.ce_pix,.vblank_start,.commit_window(page_commit_window),
    .render_busy(dma_busy||wr_busy),
    .pending_prewarm_enable(pending_page_prewarm_enable_eff),
    .pending_prewarm_ready(pending_cache_ready),.display_row,.next_row,
    .committed_display_row(fenced_display_row),
    .committed_next_row(fenced_next_row),.page_commit,.active_page,
    .pending_prewarm,.pending_page,
    .srt_write_allow);
  assign committed_display_row = BYPASS_PUBLICATION ? display_row
                                                     : fenced_display_row;
  assign committed_next_row = BYPASS_PUBLICATION ? next_row
                                                  : fenced_next_row;
  // The fence translates only the page bit. Apply that same page ownership
  // decision to the second real DPYADR lookahead supplied by tunit_top; never
  // invent a row by assuming subrow reuse or a fixed direction here.
  assign committed_next2_row = BYPASS_PUBLICATION ? next2_row :
                               next2_row ^
                               {display_row[8]^fenced_display_row[8],8'b0};
  // Pixels remain on the committed page throughout the drain interval. During
  // blank only, let the cache follow the raw DPYADR proposal instead so its
  // first current/next rows are complete before the atomic ownership change.
  // Address-tagged A/C/D publications naturally update the prewarmed page and
  // cannot expose it through the committed pixel address.
  assign cache_display_row = pending_prewarm ? display_row
                                             : committed_display_row;
  assign cache_next_row = pending_prewarm ? next_row : committed_next_row;
  assign cache_next2_row = pending_prewarm ? next2_row
                                           : committed_next2_row;
  // The TMS video block produces vblank_start from the live programmable
  // raster compares. Register the external copy beside that block before it
  // fans across the device into every scanline-cache control enable. The
  // one-system-clock delay is far shorter than a pixel enable interval and
  // still reprimes during the same vertical-blank entry.
  logic frame_reprime_q;
  always_ff @(posedge clk) begin
    if (rst) frame_reprime_q <= 1'b0;
    else     frame_reprime_q <= vblank_start ||
                              (page_commit && !pending_cache_warm_eff);
  end
  tunit_scanline #(.NCOL(NCOL)) lines(
    .clk,.rst,.ce_pix,.frame_reprime(frame_reprime_q),
    .display_row(cache_display_row),.next_row(cache_next_row),
    .next2_row(cache_next2_row),
    .active_pixel(pixel_fetch_active),.cpu_snoop_valid,.cpu_snoop_addr,.cpu_snoop_data,
    .cpu_snoop_pending,.cpu_snoop_overflow,
    .vram_raddr,.vram_rdata,.vram_rvalid,
    .scan_req,.scan_addr,.scan_data,.scan_ack,.ready(scan_ready),
    .underrun(video_underrun),.underrun_count(video_underrun_count));
  // HDMI has no transparent-pixel representation. On a genuine cache miss,
  // emit literal black while preserving DE and every raster/address cadence.
  // Looking up vram_rdata==0 would instead expose the game's palette entry 0,
  // which is the cabinet-observed flickering dark blue. Prewarm remains the
  // primary fix; this is only the fail-closed colour for an actual underrun.
  // palette_data is a registered full-clock RAM read, so delay validity by the
  // same clock. This matters at the miss->hit boundary: using the live cache
  // hit could bless the preceding palette-zero response as valid.
  logic palette_data_valid;
  always_ff @(posedge clk) begin
    if (rst) palette_data_valid <= 1'b0;
    else     palette_data_valid <= vram_rvalid;
  end
`ifdef MUT_TUNIT_SCANMISS_PALETTE0
  wire logic [15:0] palette_data_eff = palette_data;
`else
  wire logic [15:0] palette_data_eff = palette_data_valid
                                              ? palette_data : 16'h0000;
`endif

  tunit_video #(
    .H_ACT(H_ACT),.H_FP(H_FP),.H_SYNC(H_SYNC),.H_BP(H_BP),
    .V_ACT(V_ACT),.V_FP(V_FP),.V_SYNC(V_SYNC),.V_BP(V_BP),
    .FLIP_PREFETCH_LINES(FLIP_PREFETCH_LINES)) video(
    .clk,.rst,.ce_pix,.timing_start,.vblank_start,.disp_enable(display_enable),
    .env_srt_visible_hold,
    .display_blank,
    // The caller advances DPYADR once before presenting display_row so this
    // row is both the cache's current priority and the pixel source. next_row
    // is reserved for ahead-of-time scanline prefetch.
    .disp_row0({10'd0,committed_display_row}),.disp_col0(display_col),
    .vram_raddr,.vram_rdata,.pal_raddr(palette_addr),.pal_rdata(palette_data_eff),
    .vid_r,.vid_g,.vid_b,.hsync,.vsync,.hblank,.vblank,.de,.vblank_irq,.tms_ce,
    .pixel_pair_phase(pixel_phase),.pixel_fetch_active,.page_commit_window);
endmodule
`default_nettype wire
