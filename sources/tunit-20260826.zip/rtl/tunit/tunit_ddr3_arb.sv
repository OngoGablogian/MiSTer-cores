// Resettable three-way grant-held Avalon arbiter for T-unit HPS DDR3.
// Recovered production order is VRAM scanout/writeback, sound, then graphics
// (A-C-B).  The conditional sound-last order exists only as a mutation arm.

`default_nettype none
module tunit_ddr3_arb(
  input  wire logic clk,
  input  wire logic rst,

  input  wire logic [28:0] a_addr,input wire logic[7:0]a_burstcnt,
  input  wire logic a_rd,a_we,input wire logic[63:0]a_din,input wire logic[7:0]a_be,
  output logic a_busy,output logic[63:0]a_dout,output logic a_dout_ready,

  input  wire logic [28:0] b_addr,input wire logic[7:0]b_burstcnt,
  input  wire logic b_rd,b_we,input wire logic[63:0]b_din,input wire logic[7:0]b_be,
  output logic b_busy,output logic[63:0]b_dout,output logic b_dout_ready,

  input  wire logic [28:0] c_addr,input wire logic[7:0]c_burstcnt,
  input  wire logic c_rd,c_we,input wire logic[63:0]c_din,input wire logic[7:0]c_be,
  output logic c_busy,output logic[63:0]c_dout,output logic c_dout_ready,
  // Graphics asserts this after it has buffered source runway.  The recovered
  // production order below currently grants sound ahead of graphics, so this
  // predicate is exercised only by the explicit SOUND_LAST mutation arm.  A
  // remains unconditional priority because scanout has a hard line deadline.
  input  wire logic c_priority,

  output logic [28:0] ddram_addr,output logic[7:0]ddram_burstcnt,
  output logic ddram_rd,ddram_we,output logic[63:0]ddram_din,output logic[7:0]ddram_be,
  input  wire logic ddram_busy,input wire logic[63:0]ddram_dout,input wire logic ddram_dout_ready
);
  typedef enum logic[1:0]{G_NONE,G_A,G_B,G_C} grant_t;
  grant_t grant;
  logic grant_write;
  logic[7:0] beats_left;
  wire logic a_req=a_rd||a_we,b_req=b_rd||b_we,c_req=c_rd||c_we;

  always_ff @(posedge clk) begin
    if(rst)begin grant<=G_NONE;grant_write<=0;beats_left<=0;end
    else case(grant)
      G_NONE: begin
        if(a_req)begin grant<=G_A;grant_write<=a_we;if(a_rd)beats_left<=(a_burstcnt==0)?1:a_burstcnt;end
        // RECOVERED ORDER, NOT A ROOT-CAUSE CLAIM.  C is the latency client and
        // B is the throughput client, so the current production arm grants C
        // first.  The shipping topology has not yet been re-measured with real
        // port-C traffic, and this order did not establish the missing-music
        // cause.  The former conditional sound grant is retained as a mutation
        // arm so the intended production order cannot be inferred from a dead
        // substring again.
`ifdef MUT_TUNIT_SOUND_LAST
        else if(c_req&&c_priority)begin grant<=G_C;grant_write<=c_we;if(c_rd)beats_left<=(c_burstcnt==0)?1:c_burstcnt;end
        else if(b_req)begin grant<=G_B;grant_write<=b_we;if(b_rd)beats_left<=(b_burstcnt==0)?1:b_burstcnt;end
        else if(c_req)begin grant<=G_C;grant_write<=c_we;if(c_rd)beats_left<=(c_burstcnt==0)?1:c_burstcnt;end
`else
        else if(c_req)begin grant<=G_C;grant_write<=c_we;if(c_rd)beats_left<=(c_burstcnt==0)?1:c_burstcnt;end
        else if(b_req)begin grant<=G_B;grant_write<=b_we;if(b_rd)beats_left<=(b_burstcnt==0)?1:b_burstcnt;end
`endif
      end
      G_A: if(grant_write)begin if(!a_we)grant<=G_NONE;end
           else if(ddram_dout_ready)begin if(beats_left<=1)grant<=G_NONE;else beats_left<=beats_left-1'b1;end
      G_B: if(grant_write)begin if(!b_we)grant<=G_NONE;end
           else if(ddram_dout_ready)begin if(beats_left<=1)grant<=G_NONE;else beats_left<=beats_left-1'b1;end
      G_C: if(grant_write)begin if(!c_we)grant<=G_NONE;end
           else if(ddram_dout_ready)begin if(beats_left<=1)grant<=G_NONE;else beats_left<=beats_left-1'b1;end
      default: grant<=G_NONE;
    endcase
  end

  always_comb begin
    ddram_addr=29'd0;ddram_burstcnt=8'd0;ddram_rd=0;ddram_we=0;ddram_din=64'd0;ddram_be=8'd0;
    case(grant)
      G_A:begin ddram_addr=a_addr;ddram_burstcnt=a_burstcnt;ddram_rd=a_rd;ddram_we=a_we;ddram_din=a_din;ddram_be=a_be;end
      G_B:begin ddram_addr=b_addr;ddram_burstcnt=b_burstcnt;ddram_rd=b_rd;ddram_we=b_we;ddram_din=b_din;ddram_be=b_be;end
      G_C:begin ddram_addr=c_addr;ddram_burstcnt=c_burstcnt;ddram_rd=c_rd;ddram_we=c_we;ddram_din=c_din;ddram_be=c_be;end
      default:;
    endcase
    a_busy=(grant==G_A)?ddram_busy:a_req;
    b_busy=(grant==G_B)?ddram_busy:b_req;
    c_busy=(grant==G_C)?ddram_busy:c_req;
    a_dout=ddram_dout;b_dout=ddram_dout;c_dout=ddram_dout;
    a_dout_ready=(grant==G_A)&&ddram_dout_ready;
    b_dout_ready=(grant==G_B)&&ddram_dout_ready;
    c_dout_ready=(grant==G_C)&&ddram_dout_ready;
  end
endmodule
`default_nettype wire
