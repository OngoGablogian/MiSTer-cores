// MK2 DCS2K sound-ROM storage in HPS DDR3.
//
// Loader bytes are packed into full 64-bit writes. The loader's synthetic
// ROM_RELOAD half (logical slot bit 19) is acknowledged without a duplicate
// write; runtime reads clear the corresponding beat-address bit, preserving
// the six 1 MiB logical DCS slots while storing each 512 KiB chip once.

`default_nettype none
module tunit_sound_ddr #(
  parameter logic [28:0] SOUND_DDR_BASE=29'h6c00000,
  parameter int FLUSH_IDLE=64
)(
  input  wire logic clk,
  input  wire logic sdram_por,

  input  wire logic dl_wr,
  input  wire logic [23:0] dl_addr,
  input  wire logic [7:0] dl_data,
  output logic dl_ack,
  output logic dl_busy,

  input  wire logic rom_req,
  input  wire logic [19:0] rom_addr,
  output logic rom_ready,
  output logic [63:0] rom_data,

  output logic [28:0] ddram_addr,
  output logic [7:0] ddram_burstcnt,
  output logic ddram_rd,ddram_we,
  output logic [63:0] ddram_din,
  output logic [7:0] ddram_be,
  input  wire logic ddram_busy,
  input  wire logic [63:0] ddram_dout,
  input  wire logic ddram_dout_ready
);
  logic [19:0] wc_beat;
  logic [63:0] wc_data;
  logic [7:0] wc_mask;
  logic wc_valid,force_flush,dl_seen;
  logic [7:0] idle_count;
  wire logic [19:0] dl_beat={dl_addr[22:20],1'b0,dl_addr[18:3]};
  wire logic [2:0] dl_lane=dl_addr[2:0];
  wire logic dl_mirror=dl_addr[19];
  wire logic flush_needed=wc_valid&&((wc_mask==8'hff)||force_flush||
                           (idle_count>=FLUSH_IDLE));

  typedef enum logic[2:0]{O_IDLE,O_RMW_WAIT,O_WRITE_START,O_WRITE_WAIT,O_READ_WAIT,O_SERVE} owner_t;
  owner_t owner;
  wire logic take_flush=(owner==O_IDLE)&&flush_needed;
  logic [19:0] flush_beat;
  logic [63:0] flush_data,rmw_data;
  logic [7:0] flush_mask;
  logic agent_wr_req,agent_rd_req,agent_busy,agent_rd_valid,agent_seen_busy;
  logic [19:0] agent_addr;
  logic [63:0] agent_wdata,agent_rdata;

  stv_vram_ddr_agent #(.VRAM_DDR_BASE(SOUND_DDR_BASE)) agent(
    .clk,.sdram_por,
    .tst_wr_req(agent_wr_req),.tst_rd_req(agent_rd_req),
    .tst_addr({6'd0,agent_addr}),.tst_wdata(agent_wdata),.tst_be(8'hff),
    .tst_burstcnt(8'd1),.tst_rdata(agent_rdata),.tst_rd_valid(agent_rd_valid),
    .tst_busy(agent_busy),
    .tst_wr_done(),.tst_wr_base(),.tst_wr_count(),.tst_wr_last_data(),
    .tst_wnext(),
    .ddram_addr,.ddram_burstcnt,.ddram_rd,.ddram_we,.ddram_din,.ddram_be,
    .ddram_busy,.ddram_dout,.ddram_dout_ready
  );

  function automatic logic [63:0] merge_lanes(
    input logic[63:0] oldv,input logic[63:0] newv,input logic[7:0] mask
  );
    integer i;
    begin
      merge_lanes=oldv;
      for(i=0;i<8;i=i+1)if(mask[i])merge_lanes[8*i+:8]=newv[8*i+:8];
    end
  endfunction

  wire logic owner_is_download = (owner==O_RMW_WAIT) ||
                                 (owner==O_WRITE_START) ||
                                 (owner==O_WRITE_WAIT);
  // Runtime DCS reads share the agent but are not loader work and must never
  // enter the main-CPU reset equation.
  assign dl_busy=dl_wr||wc_valid||force_flush||owner_is_download;

  always_ff @(posedge clk) begin
    if(sdram_por)begin
      wc_beat<=0;wc_data<=0;wc_mask<=0;wc_valid<=0;force_flush<=0;dl_seen<=0;idle_count<=0;
      owner<=O_IDLE;flush_beat<=0;flush_data<=0;flush_mask<=0;rmw_data<=0;
      agent_wr_req<=0;agent_rd_req<=0;agent_seen_busy<=0;agent_addr<=0;agent_wdata<=0;
      dl_ack<=0;rom_ready<=0;rom_data<=0;
    end else begin
      dl_ack<=0;rom_ready<=0;agent_wr_req<=0;agent_rd_req<=0;
      if(!dl_wr)dl_seen<=0;
      if(wc_valid&&!dl_wr&&idle_count<8'hff)idle_count<=idle_count+1'b1;
      else if(dl_wr)idle_count<=0;

      case(owner)
        O_IDLE: begin
          agent_seen_busy<=0;
          if(flush_needed)begin
            flush_beat<=wc_beat;flush_data<=wc_data;flush_mask<=wc_mask;
            wc_valid<=0;wc_mask<=0;force_flush<=0;idle_count<=0;
            agent_addr<=wc_beat;
            if(wc_mask==8'hff)begin agent_wdata<=wc_data;owner<=O_WRITE_START;end
            else begin agent_rd_req<=1;owner<=O_RMW_WAIT;end
          end else if(rom_req)begin
            agent_addr<={rom_addr[19:17],1'b0,rom_addr[15:0]};
            agent_rd_req<=1;owner<=O_READ_WAIT;
          end
        end
        O_RMW_WAIT: if(agent_rd_valid)begin
          rmw_data<=agent_rdata;
          agent_wdata<=merge_lanes(agent_rdata,flush_data,flush_mask);
          owner<=O_WRITE_START;
        end
        O_WRITE_START: begin agent_wr_req<=1;agent_seen_busy<=0;owner<=O_WRITE_WAIT;end
        O_WRITE_WAIT: begin
          if(agent_busy)agent_seen_busy<=1;
          if(agent_seen_busy&&!agent_busy)owner<=O_IDLE;
        end
        O_READ_WAIT: if(agent_rd_valid)begin rom_data<=agent_rdata;rom_ready<=1;owner<=O_SERVE;end
        O_SERVE: if(!rom_req)owner<=O_IDLE;
        default: owner<=O_IDLE;
      endcase

      // Accept each held loader request once. A different physical beat first
      // forces the current combine buffer to durable DDR storage.
      if(dl_wr&&!dl_seen)begin
        if(dl_mirror)begin dl_ack<=1;dl_seen<=1;end
        else if(!wc_valid)begin
          wc_valid<=1;wc_beat<=dl_beat;wc_data<=64'd0;wc_mask<=8'd0;
          wc_data[8*dl_lane+:8]<=dl_data;wc_mask[dl_lane]<=1;
          dl_ack<=1;dl_seen<=1;
        end else if(wc_beat==dl_beat)begin
          wc_data[8*dl_lane+:8]<=dl_data;wc_mask[dl_lane]<=1;
          dl_ack<=1;dl_seen<=1;
        end else if(!take_flush) force_flush<=1;
      end
    end
  end
endmodule
`default_nettype wire
