// Profile-selected T-unit cabinet input synchronizer and active-low MAME port
// mapper. MiSTer joystick bits are R,L,D,U at 0..3, followed by the action
// buttons declared by each MRA, then Start and Coin.  Start/Coin therefore sit
// at 10/11 for the six-button fighters, 7/8 for three-button NBA Jam, and 8/9
// for four-button Judge Dredd.

`default_nettype none
module tunit_inputs
  import tunit_pkg::*;
(
  input  wire logic        clk,
  input  wire logic        rst_pon,
  input  wire tunit_profile_t profile,
  input  wire logic [15:0] joystick_0_raw,
  input  wire logic [15:0] joystick_1_raw,
  input  wire logic [15:0] joystick_2_raw,
  input  wire logic [15:0] joystick_3_raw,
  input  wire logic        service_raw,
  input  wire logic        service_credit_raw,
  input  wire logic        tilt_raw,
  input  wire logic        volume_up_raw,
  input  wire logic        volume_down_raw,
  input  wire logic        ejb_trigger_raw,
  input  wire logic        vblank_raw,
  input  wire logic [15:0] dsw,
  output logic [15:0]      in0,
  output logic [15:0]      in1,
  output logic [15:0]      in2,
  output logic [15:0]      dsw_o
);
  logic [15:0] joy0_meta, joy0_sync;
  logic [15:0] joy1_meta, joy1_sync;
  logic [15:0] joy2_meta, joy2_sync;
  logic [15:0] joy3_meta, joy3_sync;
  logic [4:0] ctl_meta, ctl_sync;
  logic ejb_trigger_meta, ejb_trigger_sync, ejb_trigger_d;
  logic vblank_d;
  logic ejb_active, ejb_press, ejb_mk2;
  logic [2:0] ejb_group;
  logic [3:0] ejb_remaining;

  function automatic logic [3:0] ejb_group_count(
    input logic mk2,
    input logic [2:0] group
  );
    begin
      if (mk2) begin
        case (group)
          3'd0: ejb_group_count = 4'd5;
          3'd1: ejb_group_count = 4'd10;
          3'd2: ejb_group_count = 4'd2;
          3'd3: ejb_group_count = 4'd8;
          default: ejb_group_count = 4'd2;
        endcase
      end else begin
        case (group)
          3'd0: ejb_group_count = 4'd5;
          3'd1: ejb_group_count = 4'd10;
          3'd2: ejb_group_count = 4'd2;
          3'd3: ejb_group_count = 4'd1;
          3'd4: ejb_group_count = 4'd2;
          3'd5: ejb_group_count = 4'd3;
          default: ejb_group_count = 4'd4;
        endcase
      end
    end
  endfunction

  always_ff @(posedge clk) begin
    if (rst_pon) begin
      joy0_meta <= 16'd0;
      joy0_sync <= 16'd0;
      joy1_meta <= 16'd0;
      joy1_sync <= 16'd0;
      joy2_meta <= 16'd0;
      joy2_sync <= 16'd0;
      joy3_meta <= 16'd0;
      joy3_sync <= 16'd0;
      ctl_meta <= 5'd0;
      ctl_sync <= 5'd0;
      ejb_trigger_meta <= 1'b0;
      ejb_trigger_sync <= 1'b0;
    end else begin
      joy0_meta <= joystick_0_raw;
      joy0_sync <= joy0_meta;
      joy1_meta <= joystick_1_raw;
      joy1_sync <= joy1_meta;
      joy2_meta <= joystick_2_raw;
      joy2_sync <= joy2_meta;
      joy3_meta <= joystick_3_raw;
      joy3_sync <= joy3_meta;
      ctl_meta <= {volume_down_raw, volume_up_raw, tilt_raw,
                   service_credit_raw, service_raw};
      ctl_sync <= ctl_meta;
      ejb_trigger_meta <= ejb_trigger_raw;
      ejb_trigger_sync <= ejb_trigger_meta;
    end
  end

  // The original EJB entry is a deliberately awkward alternating Block
  // sequence.  The OSD trigger emits that exact sequence at one press and one
  // release per native video frame, so every press is visible to the game's
  // input poll and all 27 taps complete in about one second.  The profile is
  // latched at launch; non-MK profiles ignore the trigger.
  always_ff @(posedge clk) begin
    if (rst_pon) begin
      ejb_trigger_d <= 1'b0;
      vblank_d <= 1'b0;
      ejb_active <= 1'b0;
      ejb_press <= 1'b0;
      ejb_mk2 <= 1'b0;
      ejb_group <= 3'd0;
      ejb_remaining <= 4'd0;
    end else begin
      ejb_trigger_d <= ejb_trigger_sync;
      vblank_d <= vblank_raw;

      if (ejb_trigger_sync && !ejb_trigger_d &&
          ((profile == PROFILE_MK1) || (profile == PROFILE_MK2))) begin
        ejb_active <= 1'b1;
        ejb_press <= 1'b0;
        ejb_mk2 <= (profile == PROFILE_MK2);
        ejb_group <= 3'd0;
        ejb_remaining <= 4'd5;
      end else if (ejb_active &&
                   ((ejb_mk2 && (profile != PROFILE_MK2)) ||
                    (!ejb_mk2 && (profile != PROFILE_MK1)))) begin
        ejb_active <= 1'b0;
        ejb_press <= 1'b0;
      end else if (ejb_active && vblank_raw && !vblank_d) begin
        if (!ejb_press) begin
          ejb_press <= 1'b1;
        end else begin
          ejb_press <= 1'b0;
          if (ejb_remaining != 4'd1) begin
            ejb_remaining <= ejb_remaining - 1'b1;
          end else if (ejb_group == (ejb_mk2 ? 3'd4 : 3'd6)) begin
            ejb_active <= 1'b0;
          end else begin
            ejb_group <= ejb_group + 1'b1;
            ejb_remaining <= ejb_group_count(ejb_mk2, ejb_group + 1'b1);
          end
        end
      end
    end
  end

  // Return complete active-low arcade-port bytes rather than mutating an
  // inout task argument.  Quartus treated the old nested task temporary as an
  // undriven net (Warning 10030: map_directions.port) and substituted zeroes.
  // Pure functions leave one explicit driver for every mapped input bit.
  function automatic logic [7:0] map_fighter(input logic [15:0] joy);
    begin
      map_fighter = 8'hff;
      map_fighter[0] = ~joy[3]; // up
      map_fighter[1] = ~joy[2]; // down
      map_fighter[2] = ~joy[1]; // left
      map_fighter[3] = ~joy[0]; // right
      map_fighter[4] = ~joy[4]; // high punch
      map_fighter[5] = ~joy[6]; // block
      map_fighter[6] = ~joy[7]; // high kick
    end
  endfunction

  function automatic logic [7:0] map_nba(input logic [15:0] joy);
    begin
      map_nba = 8'hff;
      map_nba[0] = ~joy[3]; // up
      map_nba[1] = ~joy[2]; // down
      map_nba[2] = ~joy[1]; // left
      map_nba[3] = ~joy[0]; // right
      map_nba[4] = ~joy[5]; // shoot / block
      map_nba[5] = ~joy[6]; // pass / steal
      map_nba[6] = ~joy[4]; // turbo
    end
  endfunction

  function automatic logic [7:0] map_jdredd(input logic [15:0] joy);
    begin
      map_jdredd[0] = ~joy[3]; // up
      map_jdredd[1] = ~joy[2]; // down
      map_jdredd[2] = ~joy[1]; // left
      map_jdredd[3] = ~joy[0]; // right
      map_jdredd[4] = ~joy[5]; // jump
      map_jdredd[5] = ~joy[6]; // punch
      map_jdredd[6] = ~joy[4]; // kick
      map_jdredd[7] = ~joy[7]; // crouch
    end
  endfunction

  always_comb begin
    in0 = 16'hffff;
    in1 = 16'hffff;
    in2 = 16'hffff;
    dsw_o = dsw;

    // Service wiring is common. Coin and Start are profile-selected below
    // because MiSTer places them immediately after the MRA's action buttons.
    in1[3] = ~ctl_sync[2];
    in1[4] = ~ctl_sync[0];
    in1[6] = ~ctl_sync[1];

    case (profile)
      PROFILE_MK1: begin
        in1[0] = ~joy0_sync[11];
        in1[1] = ~joy1_sync[11];
        in1[2] = ~joy0_sync[10];
        in1[5] = ~joy1_sync[10];
        in0[7:0] = map_fighter(joy0_sync);
        in0[15:8] = map_fighter(joy1_sync);
        in1[7]  = 1'b1;
        in1[8]  = 1'b1;
        in1[9]  = ~joy1_sync[5]; // P2 low punch
        in1[10] = ~joy1_sync[8]; // P2 low kick
        in1[11] = ~joy1_sync[9]; // P2 second block
        in1[12] = ~joy0_sync[5]; // P1 low punch
        in1[13] = ~joy0_sync[8]; // P1 low kick
        in1[15] = ~joy0_sync[9]; // P1 second block
      end

      PROFILE_MK2: begin
        in1[0] = ~joy0_sync[11];
        in1[1] = ~joy1_sync[11];
        in1[2] = ~joy0_sync[10];
        in1[5] = ~joy1_sync[10];
        in0[7:0] = map_fighter(joy0_sync);
        in0[15:8] = map_fighter(joy1_sync);
        in1[11] = ~ctl_sync[4];
        in1[12] = ~ctl_sync[3];
        in2[0] = ~joy0_sync[5]; // P1 low punch
        in2[1] = ~joy0_sync[8]; // P1 low kick
        in2[2] = ~joy0_sync[9]; // P1 second block
        in2[4] = ~joy1_sync[5]; // P2 low punch
        in2[5] = ~joy1_sync[8]; // P2 low kick
        in2[6] = ~joy1_sync[9]; // P2 second block
      end

      PROFILE_NBAJAM, PROFILE_NBAJAM_TE: begin
        in1[0] = ~joy0_sync[8];
        in1[1] = ~joy1_sync[8];
        in1[2] = ~joy0_sync[7];
        in1[5] = ~joy1_sync[7];
        in0[7:0] = map_nba(joy0_sync);
        in0[15:8] = map_nba(joy1_sync);
        in2[7:0] = map_nba(joy2_sync);
        in2[15:8] = map_nba(joy3_sync);
        in1[7]  = ~joy2_sync[8];
        in1[8]  = ~joy3_sync[8];
        in1[9]  = ~joy2_sync[7];
        in1[10] = ~joy3_sync[7];
        in1[11] = ~ctl_sync[4];
        in1[12] = ~ctl_sync[3];
      end

      PROFILE_JDREDD: begin
        in1[0] = ~joy0_sync[9];
        in1[1] = ~joy1_sync[9];
        in1[2] = ~joy0_sync[8];
        in1[5] = ~joy1_sync[8];
        in0[7:0] = map_jdredd(joy0_sync);
        in0[15:8] = map_jdredd(joy1_sync);
        in2[7:0] = map_jdredd(joy2_sync);
        in1[7]  = ~joy2_sync[9];
        in1[8]  = ~joy3_sync[9];
        in1[9]  = ~joy2_sync[8];
        in1[11] = ~ctl_sync[4];
        in1[12] = ~ctl_sync[3];
      end

      default: ;
    endcase

    // Both T-unit fighter profiles wire primary Block to IN0 bit 5 for P1 and
    // bit 13 for P2.  Active-low injection composes with real controls and is
    // completely absent when the trigger is idle.
    if (ejb_active && ejb_press) begin
      if (ejb_group[0])
        in0[13] = 1'b0;
      else
        in0[5] = 1'b0;
    end
  end
endmodule
`default_nettype wire
