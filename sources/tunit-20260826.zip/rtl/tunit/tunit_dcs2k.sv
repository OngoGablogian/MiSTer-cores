// MK2 DCS Audio 2K board wrapper. This is deliberately separate from Wolf's
// DCS8K glue: early-DCS host offsets, reset bit, status shift, six-ROM layout,
// and 2 KiB SRAM mapping belong to the T-unit profile.

`default_nettype none
module tunit_dcs2k #(
  parameter EXT_ROM = 1,
  parameter PF_LINES = 512
)(
  input  wire logic   clk,
  input  wire logic   rst,
  input  wire logic   dac_ce_31250,

  input  wire logic   cpu_status_rd,
  input  wire logic   cpu_data_rd,
  input  wire logic   cpu_data_wr,
  input  wire logic   cpu_data_offset,
  input  wire logic [15:0] cpu_wdata,
  input  wire logic [1:0] cpu_byte_en,
  output logic [15:0] cpu_status_rdata,
  output logic [15:0] cpu_data_rdata,

  output logic        rom_req,
  output logic [19:0] rom_addr,
  input  wire logic   rom_ready,
  input  wire logic [63:0] rom_rdata,

  output logic signed [15:0] audio,
  output logic        audio_ce,
  output logic        audio_underrun,
  output logic        audio_overrun,
  output logic [13:0] adsp_pc,
  output logic        adsp_valid,
  output logic        adsp_unimplemented
);
  logic dcs_run;
  logic host_cmd_w;
  logic [15:0] host_cmd_data;
  logic [15:0] host_status, host_response;
  logic host_resp_rd;
  logic [15:0] dac_sample;
  logic dac_strobe;
  logic core_ce;
  logic core_phase;
  logic host_cmd_pending;
  logic host_resp_pending;
  logic dac_pending;

  assign cpu_status_rdata = cpu_status_rd ? (host_status >> 4) : 16'hffff;
  assign cpu_data_rdata = cpu_data_rd ? {8'h00,host_response[7:0]} : 16'hffff;
  assign core_ce = core_phase;
  assign host_resp_rd = core_ce && host_resp_pending;
  assign host_cmd_w = core_ce && host_cmd_pending;
  // A bit-8 board reset is also the physical-output mute boundary.  Do not
  // expose the held sample for the one system clock between the host write and
  // the ADSP's full reset branch; that is enough for a coincident DAC slot to
  // preserve stale PCM outside the sound board.
  assign audio = dcs_run ? $signed(dac_sample) : 16'sd0;
  assign audio_ce = dcs_run && dac_strobe;

  always_ff @(posedge clk) begin
    if (rst) begin
      dcs_run <= 1'b0;
      host_cmd_data <= 16'h0000;
      core_phase <= 1'b0;
      host_cmd_pending <= 1'b0;
      host_resp_pending <= 1'b0;
      dac_pending <= 1'b0;
    end else begin
      core_phase <= ~core_phase;
      // Scrub wrapper-side mailbox/DAC slots for the whole held-reset interval.
      // The Wolf post-death tone survived partly because a pending outer slot
      // outlived the reset even after the inner PCM queue was emptied.
      if (!dcs_run) begin
        host_cmd_pending <= 1'b0;
        host_resp_pending <= 1'b0;
        dac_pending <= 1'b0;
      end else begin
        if (core_ce && host_cmd_pending)
          host_cmd_pending <= 1'b0;
        if (core_ce && host_resp_pending)
          host_resp_pending <= 1'b0;
        if (core_ce && dac_pending)
          dac_pending <= 1'b0;
        if (cpu_data_rd)
          host_resp_pending <= 1'b1;
        if (dac_ce_31250)
          dac_pending <= 1'b1;
      end
      // mk2_state::dcs_w ignores offset 0 and requires both byte lanes. Offset
      // 1 writes reset state from bit 8 and the 8-bit command from bits 7:0.
      if (cpu_data_wr && cpu_data_offset && (cpu_byte_en == 2'b11)) begin
        dcs_run <= cpu_wdata[8];
        host_cmd_data <= {8'h00,cpu_wdata[7:0]};
        host_cmd_pending <= 1'b1;
      end
    end
  end

  adsp2105 #(
    .DCS_2K(1), .EXT_ROM(EXT_ROM), .PF_LINES(PF_LINES), .PRELOAD_PM(0),
    .CORE_CE_EN(1)
  ) cpu (
    // The DCS reset bit is a held board reset, not a request to reload the
    // boot page forever.  Keep the ADSP and its ROM cache in reset until RUN
    // is asserted; the reset-release edge naturally starts the bank-0 boot.
    .clk(clk), .rst(rst || !dcs_run), .core_ce(core_ce), .host_rst(1'b0),
    .host_cmd_w(host_cmd_w), .host_cmd_data(host_cmd_data),
    .host_status_r(host_status), .host_response_r(host_response),
    .host_resp_rd(host_resp_rd),
    .rom_ddr_req(rom_req), .rom_ddr_addr(rom_addr),
    .rom_ddr_rdy(rom_ready), .rom_ddr_q(rom_rdata),
    .dac_ce_in(core_ce && dac_pending),
    .o_ppc(adsp_pc), .o_valid(adsp_valid), .o_unimpl(adsp_unimplemented),
    .dac_sample(dac_sample), .dac_ce(dac_strobe),
    .audio_underrun(audio_underrun), .audio_overrun(audio_overrun)
  );
endmodule
`default_nettype wire
