// T-unit profile metadata and physical-ROM stream transforms shared by the
// loader and the profile-focused verification benches.

`default_nettype none

package tunit_profile_layout_pkg;
  typedef enum logic [1:0] {
    VARIANT_STANDARD  = 2'd0,
    VARIANT_MK_TURBO  = 2'd1,
    VARIANT_NBA_PROTO = 2'd2
  } tunit_variant_t;

  localparam logic [7:0] FEATURE_GFX_LARGE          = 8'h01;
  localparam logic [7:0] FEATURE_MK_TURBO_PROT      = 8'h02;
  localparam logic [7:0] FEATURE_NBA_PROGRAM_RELOAD = 8'h04;
endpackage

module tunit_profile_meta
  import tunit_pkg::*;
  import tunit_profile_layout_pkg::*;
(
  input  wire tunit_profile_t profile,
  input  wire tunit_variant_t variant,

  output logic                meta_valid,
  output logic [7:0]          sound_type,
  output logic [7:0]          gfx_layout,
  output logic [7:0]          program_layout,
  output logic [7:0]          feature_flags,
  output logic                gfx_large,

  output logic [24:0]         program_physical_bytes,
  output logic [24:0]         program_logical_bytes,
  output logic [24:0]         gfx_physical_bytes,
  output logic [24:0]         gfx_populated_bytes,
  output logic [24:0]         gfx_region_bytes,
  output logic [24:0]         sound_physical_bytes,
  output logic [24:0]         sound_cpu_logical_bytes,
  output logic [24:0]         sound_sample_logical_bytes,
  output logic [24:0]         sound_dense_logical_bytes,
  output logic [24:0]         sound_ddr_image_bytes,

  // Byte zero occupies descriptor[7:0]. This preserves the current MK2 byte
  // stream exactly: 54 01 01 01 01 01 01 54.
  output logic [63:0]         descriptor
);

  logic [7:0] descriptor_checksum;

  always_comb begin
    meta_valid = 1'b0;
    sound_type = 8'd0;
    gfx_layout = 8'd0;
    program_layout = 8'd0;
    feature_flags = 8'd0;
    gfx_large = 1'b0;

    program_physical_bytes = 25'd0;
    program_logical_bytes = 25'd0;
    gfx_physical_bytes = 25'd0;
    gfx_populated_bytes = 25'd0;
    gfx_region_bytes = 25'd0;
    sound_physical_bytes = 25'd0;
    sound_cpu_logical_bytes = 25'd0;
    sound_sample_logical_bytes = 25'd0;
    sound_dense_logical_bytes = 25'd0;
    sound_ddr_image_bytes = 25'd0;
    descriptor_checksum = 8'd0;
    descriptor = 64'd0;

    case (profile)
      PROFILE_MK1: if ((variant == VARIANT_STANDARD) ||
                       (variant == VARIANT_MK_TURBO)) begin
        meta_valid = 1'b1;
        sound_type = 8'd0;
        gfx_layout = 8'd2;       // 12 x 512 KiB, four byte lanes
        program_layout = 8'd1;   // UJ12 then UG12, 512 KiB each
        feature_flags = (variant == VARIANT_MK_TURBO) ?
                        FEATURE_MK_TURBO_PROT : 8'd0;
        program_physical_bytes = 25'h10_0000;
        program_logical_bytes = 25'h10_0000;
        gfx_physical_bytes = 25'h60_0000;
        gfx_populated_bytes = 25'h60_0000;
        gfx_region_bytes = 25'hc0_0000;
        sound_physical_bytes = 25'h0c_0000;
        sound_cpu_logical_bytes = 25'h04_0000;
        sound_sample_logical_bytes = 25'h10_0000;
        sound_ddr_image_bytes = 25'h14_0000;
      end

      PROFILE_MK2: if (variant == VARIANT_STANDARD) begin
        meta_valid = 1'b1;
        sound_type = 8'd1;
        gfx_layout = 8'd1;       // 12 x 1 MiB, four byte lanes
        program_layout = 8'd1;
        feature_flags = FEATURE_GFX_LARGE;
        gfx_large = 1'b1;
        program_physical_bytes = 25'h10_0000;
        program_logical_bytes = 25'h10_0000;
        gfx_physical_bytes = 25'hc0_0000;
        gfx_populated_bytes = 25'hc0_0000;
        gfx_region_bytes = 25'hc0_0000;
        sound_physical_bytes = 25'h30_0000;
        sound_dense_logical_bytes = 25'h60_0000;
        sound_ddr_image_bytes = 25'h60_0000;
      end

      PROFILE_NBAJAM: if ((variant == VARIANT_STANDARD) ||
                          (variant == VARIANT_NBA_PROTO)) begin
        meta_valid = 1'b1;
        sound_type = 8'd0;
        gfx_layout = 8'd3;       // 16 x 512 KiB, four byte lanes
        // Prototype P1/P2 uses two 256 KiB chips and reloads each lane.
        program_layout = (variant == VARIANT_NBA_PROTO) ? 8'd2 : 8'd1;
        feature_flags = (variant == VARIANT_NBA_PROTO) ?
                        FEATURE_NBA_PROGRAM_RELOAD : 8'd0;
        program_physical_bytes = (variant == VARIANT_NBA_PROTO) ?
                                 25'h08_0000 : 25'h10_0000;
        program_logical_bytes = 25'h10_0000;
        gfx_physical_bytes = 25'h80_0000;
        gfx_populated_bytes = 25'h80_0000;
        gfx_region_bytes = 25'hc0_0000;
        sound_physical_bytes = 25'h12_0000;
        sound_cpu_logical_bytes = 25'h04_0000;
        sound_sample_logical_bytes = 25'h10_0000;
        sound_ddr_image_bytes = 25'h14_0000;
      end

      PROFILE_NBAJAM_TE: if (variant == VARIANT_STANDARD) begin
        meta_valid = 1'b1;
        sound_type = 8'd0;
        gfx_layout = 8'd3;
        program_layout = 8'd1;
        program_physical_bytes = 25'h10_0000;
        program_logical_bytes = 25'h10_0000;
        gfx_physical_bytes = 25'h80_0000;
        gfx_populated_bytes = 25'h80_0000;
        gfx_region_bytes = 25'hc0_0000;
        sound_physical_bytes = 25'h12_0000;
        sound_cpu_logical_bytes = 25'h04_0000;
        sound_sample_logical_bytes = 25'h10_0000;
        sound_ddr_image_bytes = 25'h14_0000;
      end

      PROFILE_JDREDD: if (variant == VARIANT_STANDARD) begin
        meta_valid = 1'b1;
        sound_type = 8'd0;
        gfx_layout = 8'd3;
        program_layout = 8'd1;
        program_physical_bytes = 25'h10_0000;
        program_logical_bytes = 25'h10_0000;
        gfx_physical_bytes = 25'h80_0000;
        gfx_populated_bytes = 25'h80_0000;
        gfx_region_bytes = 25'hc0_0000;
        sound_physical_bytes = 25'h12_0000;
        sound_cpu_logical_bytes = 25'h04_0000;
        sound_sample_logical_bytes = 25'h10_0000;
        sound_ddr_image_bytes = 25'h14_0000;
      end

      default: ;
    endcase

    if (meta_valid) begin
      descriptor_checksum = 8'h54 ^ 8'h01 ^ {5'd0, profile} ^
                            sound_type ^ gfx_layout ^ program_layout ^
                            feature_flags;
      descriptor = {
        descriptor_checksum,
        feature_flags,
        program_layout,
        gfx_layout,
        sound_type,
        {5'd0, profile},
        8'h01,
        8'h54
      };
    end
  end
endmodule


module tunit_program_stream_map
  import tunit_pkg::*;
  import tunit_profile_layout_pkg::*;
(
  input  wire tunit_profile_t profile,
  input  wire tunit_variant_t variant,
  input  wire logic [24:0]    physical_addr,
  input  wire logic           copy_index,
  output logic                write_valid,
  output logic [1:0]          copy_count,
  output logic [18:0]         word_addr,
  output logic                high_byte
);
  logic profile_variant_valid;

  always_comb begin
    profile_variant_valid =
      ((profile == PROFILE_MK1) &&
       ((variant == VARIANT_STANDARD) || (variant == VARIANT_MK_TURBO))) ||
      ((profile == PROFILE_MK2) && (variant == VARIANT_STANDARD)) ||
      ((profile == PROFILE_NBAJAM) &&
       ((variant == VARIANT_STANDARD) || (variant == VARIANT_NBA_PROTO))) ||
      (((profile == PROFILE_NBAJAM_TE) || (profile == PROFILE_JDREDD)) &&
       (variant == VARIANT_STANDARD));
    write_valid = 1'b0;
    copy_count = 2'd0;
    word_addr = 19'd0;
    high_byte = 1'b0;

    if ((variant == VARIANT_NBA_PROTO) &&
        (profile == PROFILE_NBAJAM)) begin
      copy_count = 2'd2;
      high_byte = physical_addr[18];
      word_addr = {copy_index, physical_addr[17:0]};
      write_valid = physical_addr < 25'h08_0000;
    end else if (profile_variant_valid) begin
      copy_count = 2'd1;
      high_byte = physical_addr[19];
      word_addr = physical_addr[18:0];
      write_valid = (physical_addr < 25'h10_0000) && !copy_index;
    end
  end
endmodule


module tunit_gfx_stream_map
  import tunit_pkg::*;
  import tunit_profile_layout_pkg::*;
(
  input  wire tunit_profile_t profile,
  input  wire tunit_variant_t variant,
  input  wire logic [24:0]    physical_addr,
  output logic                write_valid,
  output logic [23:0]         logical_addr
);
  logic [24:0] physical_limit;
  logic [3:0] chip;

  always_comb begin
    physical_limit = 25'd0;
    logical_addr = 24'd0;
    chip = 4'd0;

    case (profile)
      PROFILE_MK1:
        if ((variant == VARIANT_STANDARD) ||
            (variant == VARIANT_MK_TURBO))
          physical_limit = 25'h60_0000;
      PROFILE_MK2:
        if (variant == VARIANT_STANDARD)
          physical_limit = 25'hc0_0000;
      PROFILE_NBAJAM,
      PROFILE_NBAJAM_TE,
      PROFILE_JDREDD:
        if ((variant == VARIANT_STANDARD) ||
            ((profile == PROFILE_NBAJAM) &&
             (variant == VARIANT_NBA_PROTO)))
          physical_limit = 25'h80_0000;
      default: physical_limit = 25'd0;
    endcase

    write_valid = (physical_limit != 0) &&
                  (physical_addr < physical_limit);
    if (write_valid) begin
      if (profile == PROFILE_MK2) begin
        chip = physical_addr[23:20];
        // This is bit-for-bit the current loader's MK2 transform.
        logical_addr = ({20'd0, chip[3:2]} << 22) |
                       ({4'd0, physical_addr[19:0]} << 2) |
                       {22'd0, chip[1:0]};
      end else begin
        chip = physical_addr[22:19];
        logical_addr = ({20'd0, chip[3:2]} << 21) |
                       ({5'd0, physical_addr[18:0]} << 2) |
                       {22'd0, chip[1:0]};
      end
    end
  end
endmodule


module tunit_sound_stream_map
  import tunit_pkg::*;
  import tunit_profile_layout_pkg::*;
(
  input  wire tunit_profile_t profile,
  input  wire tunit_variant_t variant,
  input  wire logic [24:0]    physical_addr,
  input  wire logic           copy_index,
  output logic                write_valid,
  output logic [1:0]          copy_count,
  // 0 = Williams sound CPU, 1 = OKI sample ROM, 2 = dense DCS2K ROM.
  output logic [1:0]          target,
  // logical_addr is target-relative. For ADPCM, ddr_addr places the CPU image
  // at 0x000000-0x03ffff and the OKI image at 0x040000-0x13ffff.
  output logic [23:0]         logical_addr,
  output logic [23:0]         ddr_addr
);
  localparam logic [1:0] TARGET_ADPCM_CPU = 2'd0;
  localparam logic [1:0] TARGET_ADPCM_OKI = 2'd1;
  localparam logic [1:0] TARGET_DCS       = 2'd2;

  logic [2:0] dcs_chip;
  logic [24:0] sound_offset;

  always_comb begin
    write_valid = 1'b0;
    copy_count = 2'd0;
    target = TARGET_ADPCM_CPU;
    logical_addr = 24'd0;
    ddr_addr = 24'd0;
    dcs_chip = 3'd0;
    sound_offset = 25'd0;

    case (profile)
      PROFILE_MK1: if ((variant == VARIANT_STANDARD) ||
                       (variant == VARIANT_MK_TURBO)) begin
        if (physical_addr < 25'h04_0000) begin
          copy_count = 2'd1;
          target = TARGET_ADPCM_CPU;
          logical_addr = physical_addr[23:0];
          write_valid = !copy_index;
        end else if (physical_addr < 25'h08_0000) begin
          copy_count = 2'd2;
          target = TARGET_ADPCM_OKI;
          sound_offset = physical_addr - 25'h04_0000;
          logical_addr = sound_offset[23:0] +
                         (copy_index ? 24'h04_0000 : 24'd0);
          write_valid = 1'b1;
        end else if (physical_addr < 25'h0c_0000) begin
          copy_count = 2'd2;
          target = TARGET_ADPCM_OKI;
          sound_offset = physical_addr - 25'h08_0000;
          logical_addr = 24'h08_0000 + sound_offset[23:0] +
                         (copy_index ? 24'h04_0000 : 24'd0);
          write_valid = 1'b1;
        end
      end

      PROFILE_MK2: if (variant == VARIANT_STANDARD) begin
        if (physical_addr < 25'h30_0000) begin
          copy_count = 2'd2;
          target = TARGET_DCS;
          dcs_chip = physical_addr[21:19];
          // Six concatenated 512 KiB files become six dense 1 MiB slots.
          logical_addr = ({21'd0, dcs_chip} << 20) |
                         (copy_index ? 24'h08_0000 : 24'd0) |
                         {5'd0, physical_addr[18:0]};
          write_valid = 1'b1;
        end
      end

      PROFILE_NBAJAM,
      PROFILE_NBAJAM_TE,
      PROFILE_JDREDD:
      if ((variant == VARIANT_STANDARD) ||
          ((profile == PROFILE_NBAJAM) &&
           (variant == VARIANT_NBA_PROTO))) begin
        if (physical_addr < 25'h02_0000) begin
          copy_count = 2'd2;
          target = TARGET_ADPCM_CPU;
          logical_addr = physical_addr[23:0] +
                         (copy_index ? 24'h02_0000 : 24'd0);
          write_valid = 1'b1;
        end else if (physical_addr < 25'h0a_0000) begin
          copy_count = 2'd1;
          target = TARGET_ADPCM_OKI;
          sound_offset = physical_addr - 25'h02_0000;
          logical_addr = sound_offset[23:0];
          write_valid = !copy_index;
        end else if (physical_addr < 25'h12_0000) begin
          copy_count = 2'd1;
          target = TARGET_ADPCM_OKI;
          sound_offset = physical_addr - 25'h0a_0000;
          logical_addr = 24'h08_0000 + sound_offset[23:0];
          write_valid = !copy_index;
        end
      end

      default: ;
    endcase

    if (write_valid) begin
      if (target == TARGET_ADPCM_OKI)
        ddr_addr = 24'h04_0000 + logical_addr;
      else
        ddr_addr = logical_addr;
    end
  end
endmodule

`default_nettype wire
