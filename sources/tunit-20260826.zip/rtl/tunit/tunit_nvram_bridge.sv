// MiSTer index-4 persistence control for the 16 KiB T-unit CMOS image.

`default_nettype none
module tunit_nvram_bridge #(
  parameter integer NVRAM_BYTES = 16384
)(
  input  wire logic        clk,
  input  wire logic        rst_pon,
  input  wire logic        ioctl_download,
  input  wire logic        ioctl_upload,
  input  wire logic        ioctl_wr,
  input  wire logic [7:0]  ioctl_index,
  input  wire logic [24:0] ioctl_addr,
  input  wire logic [7:0]  ioctl_dout,
  output logic [7:0]       ioctl_din,
  output logic             ioctl_upload_req,

  input  wire logic        autosave,
  input  wire logic        manual_save,
  input  wire logic        clear_nvram,
  input  wire logic        osd_status,
  input  wire logic        cpu_write_pulse,

  output logic             nvram_ext_wr,
  output logic [13:0]      nvram_ext_addr,
  output logic [7:0]       nvram_ext_wdata,
  input  wire logic [7:0]  nvram_ext_rdata,
  output logic             nvram_loading,
  output logic             nvram_dirty
);
  logic clearing;
  logic boot_clearing;
  logic [13:0] clear_addr;
  logic old_clear, old_manual, old_osd;
  logic save_pending;

  wire nvram_download = ioctl_download && (ioctl_index == 8'd4);
  wire nvram_upload = ioctl_upload && (ioctl_index == 8'd4);
  wire nvram_addr_valid = ioctl_addr < NVRAM_BYTES;
  wire nvram_restore_write = nvram_download && ioctl_wr && nvram_addr_valid;

  assign nvram_loading = nvram_download || clearing;
  // An index-4 restore is authoritative from its first cycle. Suppress the
  // power-on sweep for the whole download window so its first byte cannot be
  // overwritten by a simultaneous clear write.
  assign nvram_ext_wr = nvram_restore_write || (clearing && !nvram_download);
  assign nvram_ext_addr = nvram_restore_write ? ioctl_addr[13:0] : clear_addr;
  assign nvram_ext_wdata = nvram_restore_write ? ioctl_dout : 8'h00;
  assign ioctl_din = (ioctl_index == 8'd4 && nvram_addr_valid)
                   ? nvram_ext_rdata : 8'h00;
  assign ioctl_upload_req = save_pending;

  always_ff @(posedge clk) begin
    if (rst_pon) begin
`ifdef MUT_TUNIT_NVRAM_NO_BOOT_CLEAR
      clearing <= 1'b0;
      boot_clearing <= 1'b0;
`else
      // The fitted CMOS M10Ks have no initialization file and the project
      // permits power-up don't-care state. Hold the board in nvram_loading
      // while deterministically clearing every byte before the first boot.
      clearing <= 1'b1;
      boot_clearing <= 1'b1;
`endif
      clear_addr <= 14'd0;
      old_clear <= 1'b0;
      old_manual <= 1'b0;
      old_osd <= 1'b0;
      save_pending <= 1'b0;
      nvram_dirty <= 1'b0;
    end else begin
      old_clear <= clear_nvram;
      old_manual <= manual_save;
      old_osd <= osd_status;

      if (cpu_write_pulse) nvram_dirty <= 1'b1;

      // A restored 16 KiB image supersedes the boot sweep. Download has
      // priority over both starting and advancing a clear operation.
      if (nvram_download) begin
        clearing <= 1'b0;
        boot_clearing <= 1'b0;
      end else if (clear_nvram && !old_clear && !clearing) begin
        clearing <= 1'b1;
        boot_clearing <= 1'b0;
        clear_addr <= 14'd0;
      end else if (clearing) begin
        if (clear_addr == NVRAM_BYTES-1) begin
          clearing <= 1'b0;
          boot_clearing <= 1'b0;
          // A manual clear is a user change and must be persisted. The
          // automatic boot clear is only deterministic initialization; do not
          // ask hps_io to save a blank image over a possible SD-card restore.
          if (!boot_clearing) begin
            nvram_dirty <= 1'b1;
            save_pending <= 1'b1;
          end
        end else clear_addr <= clear_addr + 1'b1;
      end

      if ((manual_save && !old_manual) ||
          (autosave && nvram_dirty && osd_status && !old_osd))
        save_pending <= 1'b1;

      // hps_io has accepted the request and begun the index-4 upload.
      if (nvram_upload) begin
        save_pending <= 1'b0;
        nvram_dirty <= 1'b0;
      end

      // A restored save is authoritative and starts clean.
      if (nvram_restore_write)
        nvram_dirty <= 1'b0;
    end
  end
endmodule
`default_nettype wire
