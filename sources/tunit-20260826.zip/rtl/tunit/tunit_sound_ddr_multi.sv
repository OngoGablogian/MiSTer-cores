// Shared T-unit sound-ROM storage in HPS DDR3. The download layout and
// runtime client are selected by the loaded profile: compressed/mirrored
// DCS2K beats for MK2, or a flat 0x140000-byte Williams ADPCM image.

`default_nettype none
module tunit_sound_ddr_multi #(
  parameter logic [28:0] SOUND_DDR_BASE = 29'h6c00000,
  parameter int FLUSH_IDLE = 64,
  // Verification can disable tuple-based rearming to prove the loader emits
  // an actual low-valid transaction boundary. Production keeps the defensive
  // held-valid compatibility path enabled.
  parameter logic ALLOW_HELD_VALID_REARM = 1'b1
)(
  input  wire logic clk,
  input  wire logic sdram_por,
  input  wire logic sound_dcs,

  input  wire logic dl_wr,
  input  wire logic [23:0] dl_addr,
  input  wire logic [7:0] dl_data,
  output logic dl_ack,
  output logic dl_busy,

  input  wire logic dcs_req,
  input  wire logic [19:0] dcs_addr,
  output logic dcs_ready,
  output logic [63:0] dcs_data,

  input  wire logic adpcm_req,
  input  wire logic [20:0] adpcm_addr,
  output logic adpcm_ready,
  output logic [7:0] adpcm_data,
  // The agent already reads a full 64-bit DDR3 word for every ADPCM byte
  // (:178 agent_addr = adpcm_addr[20:3]); seven eighths of it used to be
  // discarded at the lane select below.  Hand the whole beat to
  // tunit_adpcm_rom_cdc's line cache -- same DDR3 traffic, up to 8x fewer
  // round trips, and the 6809's clock stops being frozen for each of them.
  output logic [63:0] adpcm_line,

  output logic [28:0] ddram_addr,
  output logic [7:0] ddram_burstcnt,
  output logic ddram_rd,
  output logic ddram_we,
  output logic [63:0] ddram_din,
  output logic [7:0] ddram_be,
  input  wire logic ddram_busy,
  input  wire logic [63:0] ddram_dout,
  input  wire logic ddram_dout_ready
);
  logic [20:0] wc_beat;
  logic [63:0] wc_data;
  logic [7:0] wc_mask;
  logic wc_valid, force_flush, dl_seen;
  logic [23:0] dl_seen_addr;
  logic [7:0] dl_seen_data;
  logic [7:0] idle_count;
  wire logic [20:0] dl_beat_dcs =
    {1'b0, dl_addr[22:20], 1'b0, dl_addr[18:3]};
  wire logic [20:0] dl_beat_adpcm = dl_addr[23:3];
  wire logic [20:0] dl_beat = sound_dcs ? dl_beat_dcs : dl_beat_adpcm;
  wire logic [2:0] dl_lane = dl_addr[2:0];
  wire logic dl_mirror = sound_dcs && dl_addr[19];
  // The loader may keep dl_wr asserted while advancing from copy 0 to copy 1
  // of one physical byte. A low-only re-arm deadlocks that legal back-to-back
  // request: copy 0 is acknowledged, the address changes, but dl_wr never
  // falls. Treat a changed held-valid tuple as the next transaction while
  // still suppressing repeated cycles of the same request.
  wire logic dl_request_new =
    !dl_seen || (ALLOW_HELD_VALID_REARM &&
                 ((dl_addr != dl_seen_addr) || (dl_data != dl_seen_data)));
  wire logic flush_needed = wc_valid && ((wc_mask == 8'hff) ||
                           force_flush || (idle_count >= FLUSH_IDLE));

  typedef enum logic [2:0] {
    O_IDLE, O_RMW_WAIT, O_WRITE_START, O_WRITE_WAIT, O_READ_WAIT, O_SERVE
  } owner_t;
  owner_t owner;
  wire logic take_flush = (owner == O_IDLE) && flush_needed;
  logic [20:0] flush_beat;
  logic [63:0] flush_data, rmw_data;
  logic [7:0] flush_mask;
  logic agent_wr_req, agent_rd_req, agent_busy, agent_rd_valid;
  logic agent_seen_busy;
  logic [20:0] agent_addr;
  logic [63:0] agent_wdata, agent_rdata;
  logic read_is_adpcm;
  logic [2:0] adpcm_lane_q;

  stv_vram_ddr_agent #(.VRAM_DDR_BASE(SOUND_DDR_BASE)) agent(
    .clk, .sdram_por,
    .tst_wr_req(agent_wr_req), .tst_rd_req(agent_rd_req),
    .tst_addr({5'd0,agent_addr}), .tst_wdata(agent_wdata), .tst_be(8'hff),
    .tst_burstcnt(8'd1), .tst_rdata(agent_rdata),
    .tst_rd_valid(agent_rd_valid), .tst_busy(agent_busy),
    .tst_wr_done(), .tst_wr_base(), .tst_wr_count(), .tst_wr_last_data(),
    .tst_wnext(),
    .tst_waccept(), .tst_waccept_addr(),
    .tst_waccept_data(), .tst_waccept_be(),
    .ddram_addr, .ddram_burstcnt, .ddram_rd, .ddram_we, .ddram_din,
    .ddram_be, .ddram_busy, .ddram_dout, .ddram_dout_ready
  );

  function automatic logic [63:0] merge_lanes(
    input logic [63:0] oldv,
    input logic [63:0] newv,
    input logic [7:0] mask
  );
    integer i;
    begin
      merge_lanes = oldv;
      for (i = 0; i < 8; i = i + 1)
        if (mask[i]) merge_lanes[8*i+:8] = newv[8*i+:8];
    end
  endfunction

  wire logic owner_is_download =
    (owner == O_RMW_WAIT) || (owner == O_WRITE_START) ||
    (owner == O_WRITE_WAIT);
  assign dl_busy = dl_wr || wc_valid || force_flush || owner_is_download;

  always_ff @(posedge clk) begin
    if (sdram_por) begin
      wc_beat <= 0;
      wc_data <= 0;
      wc_mask <= 0;
      wc_valid <= 0;
      force_flush <= 0;
      dl_seen <= 0;
      dl_seen_addr <= 0;
      dl_seen_data <= 0;
      idle_count <= 0;
      owner <= O_IDLE;
      flush_beat <= 0;
      flush_data <= 0;
      flush_mask <= 0;
      rmw_data <= 0;
      agent_wr_req <= 0;
      agent_rd_req <= 0;
      agent_seen_busy <= 0;
      agent_addr <= 0;
      agent_wdata <= 0;
      read_is_adpcm <= 0;
      adpcm_lane_q <= 0;
      dl_ack <= 0;
      dcs_ready <= 0;
      dcs_data <= 0;
      adpcm_ready <= 0;
      adpcm_data <= 0;
      adpcm_line <= 64'd0;
    end else begin
      dl_ack <= 0;
      dcs_ready <= 0;
      adpcm_ready <= 0;
      agent_wr_req <= 0;
      agent_rd_req <= 0;
      if (!dl_wr) dl_seen <= 0;
      if (wc_valid && !dl_wr && idle_count < 8'hff)
        idle_count <= idle_count + 1'b1;
      else if (dl_wr)
        idle_count <= 0;

      case (owner)
        O_IDLE: begin
          agent_seen_busy <= 0;
          if (flush_needed) begin
            flush_beat <= wc_beat;
            flush_data <= wc_data;
            flush_mask <= wc_mask;
            wc_valid <= 0;
            wc_mask <= 0;
            force_flush <= 0;
            idle_count <= 0;
            agent_addr <= wc_beat;
            if (wc_mask == 8'hff) begin
              agent_wdata <= wc_data;
              owner <= O_WRITE_START;
            end else begin
              agent_rd_req <= 1;
              owner <= O_RMW_WAIT;
            end
          end else if (dcs_req) begin
            agent_addr <= {1'b0,dcs_addr[19:17],1'b0,dcs_addr[15:0]};
            read_is_adpcm <= 0;
            agent_rd_req <= 1;
            owner <= O_READ_WAIT;
          end else if (adpcm_req) begin
            agent_addr <= {3'd0,adpcm_addr[20:3]};
            adpcm_lane_q <= adpcm_addr[2:0];
            read_is_adpcm <= 1;
            agent_rd_req <= 1;
            owner <= O_READ_WAIT;
          end
        end

        O_RMW_WAIT: if (agent_rd_valid) begin
          rmw_data <= agent_rdata;
          agent_wdata <= merge_lanes(agent_rdata, flush_data, flush_mask);
          owner <= O_WRITE_START;
        end

        O_WRITE_START: begin
          agent_wr_req <= 1;
          agent_seen_busy <= 0;
          owner <= O_WRITE_WAIT;
        end

        O_WRITE_WAIT: begin
          if (agent_busy) agent_seen_busy <= 1;
          if (agent_seen_busy && !agent_busy) owner <= O_IDLE;
        end

        O_READ_WAIT: if (agent_rd_valid) begin
          if (read_is_adpcm) begin
            adpcm_data <= agent_rdata[8*adpcm_lane_q+:8];
            adpcm_line <= agent_rdata;
            adpcm_ready <= 1;
          end else begin
            dcs_data <= agent_rdata;
            dcs_ready <= 1;
          end
          owner <= O_SERVE;
        end

        O_SERVE: begin
          if ((read_is_adpcm && !adpcm_req) ||
              (!read_is_adpcm && !dcs_req))
            owner <= O_IDLE;
        end

        default: owner <= O_IDLE;
      endcase

      if (dl_wr && dl_request_new) begin
        if (dl_mirror) begin
          dl_ack <= 1;
          dl_seen <= 1;
          dl_seen_addr <= dl_addr;
          dl_seen_data <= dl_data;
        end else if (!wc_valid) begin
          wc_valid <= 1;
          wc_beat <= dl_beat;
          wc_data <= 64'd0;
          wc_mask <= 8'd0;
          wc_data[8*dl_lane+:8] <= dl_data;
          wc_mask[dl_lane] <= 1;
          dl_ack <= 1;
          dl_seen <= 1;
          dl_seen_addr <= dl_addr;
          dl_seen_data <= dl_data;
        end else if (wc_beat == dl_beat) begin
          wc_data[8*dl_lane+:8] <= dl_data;
          wc_mask[dl_lane] <= 1;
          dl_ack <= 1;
          dl_seen <= 1;
          dl_seen_addr <= dl_addr;
          dl_seen_data <= dl_data;
        end else if (!take_flush) begin
          force_flush <= 1;
        end
      end
    end
  end
endmodule
`default_nettype wire
