// T-unit TMS34010 instruction-retirement cadence scheduler.
//
// The TMS34010 core is a multi-state implementation: a core enable advances
// one RTL microstep, not one architectural processor cycle.  All MAME 0.289
// T-unit profiles use a 50 MHz TMS34010 master clock, and the processor turns
// eight master clocks into one architectural cycle.  On this 80 MHz fabric,
// one architectural cycle is 12.8 system clocks.  Phase units use 64 per
// architectural cycle and advance by 5 per system clock, representing that
// ratio exactly without rounding each instruction.
//
// The microengine runs at the full fabric rate while an instruction is active.
// After retirement, the next opcode may start only when the exact MAME cycle
// budget has elapsed from the previous accepted opcode.  A registered permit
// drives the high-fanout core enable.  Memory or implementation latency that
// exceeds the budget is never hidden by catch-up; cadence_overrun latches it.
`default_nettype none

module tunit_cpu_cycle_scheduler (
  input  wire logic        clk,
  input  wire logic        rst,
  input  wire logic        instr_start,
  input  wire logic        instr_retire,
  input  wire logic [15:0] instr_cycles,
  output logic             ce_cpu,
  output logic             cadence_stall,
  output logic             cadence_overrun_pulse,
  output logic             cadence_overrun
);
  localparam int unsigned PHASE_PER_ARCH_CYCLE = 64;
`ifdef MUT_TUNIT_CADENCE_PHASE6
  // Causal gate mutant: the independent 64:5 cadence oracle must reject this.
  localparam int unsigned PHASE_PER_SYSCLK = 6;
`else
  localparam int unsigned PHASE_PER_SYSCLK = 5;
`endif
  localparam int unsigned TIME_W = 23;

  (* preserve *) logic permit_q;
  logic active_q;
  logic waiting_q;
  logic [TIME_W-1:0] elapsed_q;
  logic [TIME_W-1:0] target_q;

  logic [15:0] budget_cycles;
  logic [TIME_W-1:0] budget_phase;
  logic [TIME_W-1:0] elapsed_plus_one;
  logic [TIME_W-1:0] start_residue;
  logic [TIME_W:0] target_plus_cycle;
  logic              elapsed_lookahead_carry;
  logic [16:0]       elapsed_cycle_lookahead;
  logic              retire_budget_met;
  logic              wait_budget_met;

  always_comb begin
    budget_cycles = (instr_cycles == 16'd0) ? 16'd1 : instr_cycles;
    budget_phase = {{(TIME_W-22){1'b0}}, budget_cycles, 6'b000000};

    elapsed_plus_one = (elapsed_q > ({TIME_W{1'b1}} - PHASE_PER_SYSCLK))
                     ? {TIME_W{1'b1}}
                     : elapsed_q + TIME_W'(PHASE_PER_SYSCLK);
    // Compare (elapsed_q + 10 phase units) with a cycle-aligned target without
    // placing a 23-bit add followed by a 23-bit compare on permit_q.  Every
    // target is an integer number of 64-unit architectural cycles, so only a
    // carry from phase 54..63 and the upper cycle count can affect the result.
    // This is algebraically identical to elapsed_plus_two >= target.
    elapsed_lookahead_carry = (elapsed_q[5:0] >= 6'd54);
    elapsed_cycle_lookahead = {1'b0, elapsed_q[21:6]}
                            + {{16{1'b0}}, elapsed_lookahead_carry};
    retire_budget_met = elapsed_q[22]
                     || (elapsed_cycle_lookahead >= {1'b0, budget_cycles});
    wait_budget_met = elapsed_q[22]
                   || (elapsed_cycle_lookahead >= {1'b0, target_q[21:6]});
    start_residue = (waiting_q && (elapsed_plus_one >= target_q))
                  ? elapsed_plus_one - target_q : '0;
    target_plus_cycle = {1'b0, target_q}
                      + (TIME_W+1)'(PHASE_PER_ARCH_CYCLE);

    ce_cpu = permit_q;
    cadence_stall = waiting_q && !permit_q;
    // A budget is defined from one accepted opcode to the next.  Export the
    // exact close-of-interval event for mutation-only telemetry; unlike the
    // sticky flag below, this fires once for each instruction that is at
    // least one complete architectural cycle late.
    cadence_overrun_pulse = instr_start && waiting_q
                          && ({1'b0, elapsed_plus_one} >= target_plus_cycle);
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      permit_q        <= 1'b1;
      active_q        <= 1'b0;
      waiting_q       <= 1'b0;
      elapsed_q       <= '0;
      target_q        <= TIME_W'(PHASE_PER_ARCH_CYCLE);
      cadence_overrun <= 1'b0;
    end else begin
      if (active_q || waiting_q)
        elapsed_q <= elapsed_plus_one;

      // Start has priority over the ordinary waiting update.  The start edge
      // itself closes the prior start-to-start interval, then establishes the
      // zero point for the new instruction.
      if (instr_start) begin
        // Preserve only the sub-cycle residue introduced by the 64:5 phase
        // quantisation.  A whole architectural cycle late is a real physical
        // overrun and must not be recovered by speeding up later software.
        if (waiting_q
            && ({1'b0, elapsed_plus_one} >= target_plus_cycle))
          cadence_overrun <= 1'b1;
        active_q  <= 1'b1;
        waiting_q <= 1'b0;
        elapsed_q <= (waiting_q
                   && ({1'b0, elapsed_plus_one} < target_plus_cycle))
                   ? start_residue : '0;
        permit_q  <= 1'b1;
      end else if (instr_retire) begin
        active_q  <= 1'b0;
        waiting_q <= 1'b1;
        target_q  <= budget_phase;
        // permit_q is consumed on the next edge, hence the two-clock
        // lookahead from the pre-edge elapsed register.
        permit_q <= retire_budget_met;
        if ({1'b0, elapsed_plus_one}
            >= ({1'b0, budget_phase} + (TIME_W+1)'(PHASE_PER_ARCH_CYCLE)))
          cadence_overrun <= 1'b1;
      end else if (waiting_q) begin
        permit_q <= wait_budget_met;
      end else begin
        permit_q <= 1'b1;
      end
    end
  end

`ifndef SYNTHESIS
  always_ff @(posedge clk) begin
    if (!rst) begin
      if (instr_start && instr_retire)
        $fatal(1, "tunit_cpu_cycle_scheduler: simultaneous start and retire");
      if ((instr_start || instr_retire) && !ce_cpu)
        $fatal(1, "tunit_cpu_cycle_scheduler: handshake without ce_cpu");
      if (instr_start && active_q)
        $fatal(1, "tunit_cpu_cycle_scheduler: start while instruction active");
      if (instr_retire && !active_q)
        $fatal(1, "tunit_cpu_cycle_scheduler: retire while no instruction active");
      if (active_q && waiting_q)
        $fatal(1, "tunit_cpu_cycle_scheduler: active and waiting both set");
    end
  end
`endif

endmodule

`default_nettype wire
