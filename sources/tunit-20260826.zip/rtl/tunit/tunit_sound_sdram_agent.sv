// Memory agent backed by a 16-bit SDRAM arbiter channel (sound ROM, gfx ROM).
//
// DROP-IN for stv_vram_ddr_agent as tunit_sound_ddr_multi uses it: same
// wr_req/rd_req/addr/wdata/rdata/rd_valid/busy contract, so the sound module's
// own FSM, mirror layout, lane merge and DCS/ADPCM routing are UNCHANGED.  That
// is deliberate -- the partition rebalance should move where the bytes live, not
// rewrite how the sound board reads them, so the existing sound gates stay valid.
//
// WHY (docs/PARTITION-REBALANCE-PLAN.md): sound ROM sat on DDR3 as the LOWEST
// priority of three clients, behind VRAM scanout and the blitter's framebuffer
// writes.  T-unit was the only one of the three sibling cores arranged that way;
// Y-unit's sound is clean on SDRAM with a line cache.  Moving it here frees DDR3
// for VRAM alone and gives sound a port whose other tenants are cold and cached.
//
// ONE 64-BIT WORD = FOUR 16-BIT SDRAM WORDS, issued back to back, little-endian
// lane order to match the DDR3 agent's rdata[63:0] layout: lane 0 -> [15:0].
// Getting that order wrong is silent -- it would play as corrupted samples rather
// than as an obvious fault -- so tb_tunit_sound_sdram_agent checks the byte
// identity of a written-then-read word, and checks the SDRAM contents directly,
// rather than merely that a word arrived. A symmetric write+read pair alone would
// let a swapped assembly cancel out and pass.
`default_nettype none
module tunit_sound_sdram_agent #(
  // 64-bit-word index width. Sound needs 21 bits; the gfx region is larger, so
  // its instance widens this. Kept a parameter rather than fixed at the maximum
  // so each consumer's index width stays visible at its instantiation.
  parameter int AW = 21
)(
  input  wire logic        clk,
  input  wire logic        rst,

  // Agent contract (identical to stv_vram_ddr_agent's tst_* subset in use)
  input  wire logic        wr_req,
  input  wire logic        rd_req,
  input  wire logic [AW-1:0] addr,      // 64-bit word index into the region
  input  wire logic [63:0] wdata,
  output logic [63:0]      rdata,
  output logic             rd_valid,
  output logic             busy,

  // Write-retirement report, matching stv_vram_ddr_agent's tst_wr_* subset.
  // midway_gfx_ddr_top uses these to build a download FENCE: after a write it
  // re-reads the last beat and compares. That fence exists because DDR3 writes
  // are POSTED and may not be visible to a later read. It is not needed on this
  // path -- the arbiter serialises and the controller acks on acceptance -- but
  // it is satisfied rather than deleted, so the consumer's verification logic
  // keeps working unchanged and still proves the bytes landed.
  output logic             wr_done,
  output logic [25:0]      wr_base,
  output logic [7:0]       wr_count,
  output logic [63:0]      wr_last_data,

  // SDRAM arbiter channel (word)
  output logic [23:0]      s_addr,      // 16-bit word index into the sound region
  output logic [15:0]      s_din,
  output logic [1:0]       s_be,
  output logic             s_rd,
  output logic             s_wr,
  input  wire logic [15:0] s_dout,
  input  wire logic        s_ack
);
  typedef enum logic [1:0] {A_IDLE, A_REQ, A_WAIT, A_DONE} astate_t;
  astate_t st;
  logic [1:0]  lane;
  logic        is_write;
  logic [AW-1:0] addr_q;
  logic [63:0] data_q;
  logic [63:0] wdata_q;   // untouched copy; data_q rotates as lanes retire

  assign busy = (st != A_IDLE);

  // lane 0 is the LOW word, matching the DDR3 agent's 64-bit layout.
  wire [23:0] lane_addr = ({22'd0, addr_q} << 2) + {22'd0, lane};

  always_ff @(posedge clk) begin
    if (rst) begin
      st <= A_IDLE; lane <= 2'd0; is_write <= 1'b0;
      addr_q <= '0; data_q <= 64'd0;
      rdata <= 64'd0; rd_valid <= 1'b0;
      wr_done <= 1'b0; wr_base <= 26'd0; wr_count <= 8'd1; wr_last_data <= 64'd0;
      wdata_q <= 64'd0;
      s_addr <= 24'd0; s_din <= 16'd0; s_be <= 2'b00; s_rd <= 1'b0; s_wr <= 1'b0;
    end else begin
      rd_valid <= 1'b0;
      wr_done  <= 1'b0;
      case (st)
        A_IDLE: begin
          s_rd <= 1'b0; s_wr <= 1'b0;
          if (wr_req || rd_req) begin
            is_write <= wr_req;      // a simultaneous pair cannot occur; the
                                     // caller drives one strobe per transaction
            addr_q   <= addr;
            data_q   <= wdata;
            wdata_q  <= wdata;
            lane     <= 2'd0;
            st       <= A_REQ;
          end
        end
        A_REQ: begin
          s_addr <= lane_addr;
          s_be   <= 2'b11;
          s_din  <= data_q[15:0];    // rotated below as lanes retire
          s_rd   <= ~is_write;
          s_wr   <=  is_write;
          st     <= A_WAIT;
        end
        A_WAIT: if (s_ack) begin
          s_rd <= 1'b0; s_wr <= 1'b0;
          // READ: shift the arriving word into the TOP and rotate down, so after
          // four acks data_q holds lane0 in [15:0] -- little-endian, matching the
          // DDR3 agent's rdata layout.
          //
          // The is_write guard is BELT AND BRACES, not a bug fix. I first claimed
          // it fixed a defect; the mutation proved otherwise and the claim was
          // wrong. Folding s_dout in during a write lands it in [63:48], and across
          // exactly four lanes every write payload reaches [15:0] before that
          // rotates down -- so the two forms are equivalent AT FOUR LANES. The
          // guard is kept because that equivalence is an accident of the lane
          // count: change 64/16 to any other ratio and the unguarded form starts
          // writing bus noise. No mutant is offered for it, because a mutant that
          // cannot be killed is a false entry in a gate.
`ifdef MUT_SND_AGENT_LANE_ORDER
          // Mutant: assemble big-endian. Still returns a full word, on time.
          data_q <= is_write ? {16'd0, data_q[63:16]}
                             : {data_q[47:0], s_dout};
`else
          data_q <= is_write ? {16'd0, data_q[63:16]}
                             : {s_dout, data_q[63:16]};
`endif
          if (lane == 2'd3) begin
            st <= A_DONE;
          end else begin
            lane <= lane + 2'd1;
            st   <= A_REQ;
          end
        end
        A_DONE: begin
          if (!is_write) begin
            rdata    <= data_q;
            rd_valid <= 1'b1;
          end else begin
            wr_done      <= 1'b1;
            wr_base      <= 26'(addr_q);
            wr_count     <= 8'd1;
            wr_last_data <= wdata_q;
          end
          st <= A_IDLE;
        end
        default: st <= A_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
