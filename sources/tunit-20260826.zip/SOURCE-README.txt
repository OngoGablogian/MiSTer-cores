T Unit - ADPCM S12 baseline
RBF SHA-256: 868825b1578997257b89cfa16e6d86a138f117219a969995e3a8eee0c7206bd0

This archive contains the selected integration source and build support files.
Use Quartus 17.0 Lite for the DE10-Nano / Cyclone V target. See the project
QSF/QIP files and build scripts for the source list and conversion steps.
Third-party files retain their individual copyright and license notices.
No game ROMs, personal settings, fitted databases or game traces are included.
ROMs are loaded by MiSTer at runtime; ROM-driven simulations need local game data.

Source identity: tunit-s12-sources
For Wolf Unit use WOLF_MASTER=1,CRT_ADJUST=1,USE_DDR3_GFX=1,USE_DDR3_VRAM=1.
The compiled binary's validation status is recorded in the feed catalog.
