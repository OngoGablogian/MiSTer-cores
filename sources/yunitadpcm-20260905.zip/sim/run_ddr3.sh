#!/usr/bin/env bash
# run_ddr3.sh — VRAM->DDR3 iverilog gates (no license needed). Both expect "RESULT: PASS".
#   P0 loopback : agent + FAITHFUL f2sdram oracle, 9 assertions + mutation coverage.
#   P1 xdiff    : DDR3 VRAM subsystem bit-exact vs the proven SDRAM-backed vram_sdram_top.
#   ./run_ddr3.sh
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
T="${TMPDIR:-/tmp}"

echo "== P0 loopback =="
iverilog -g2012 -o "$T/tb_vram_ddr.vvp" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_vram_ddr_loopback.sv"
vvp "$T/tb_vram_ddr.vvp" | grep -iE "RESULT|\[tb\]|main model"

echo "== P1 cross-diff (DDR3 vs SDRAM golden) =="
iverilog -g2012 -o "$T/tb_vram_ddr_xdiff.vvp" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/sim/sdram_model.sv" "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_vram_ddr_xdiff.sv"
vvp "$T/tb_vram_ddr_xdiff.vvp" | grep -iE "RESULT|MISMATCH|FAIL"

echo "== B-fill atomic barrier: first-cache coherence + ownership drain =="
BFILL_SRC=("$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" "$ROOT/sim/tb_vram_ddr_bfill_red.sv")
iverilog -g2012 -o "$T/tb_vram_ddr_bfill.vvp" "${BFILL_SRC[@]}"
BFILL_OUT="$(vvp "$T/tb_vram_ddr_bfill.vvp")"
printf '%s\n' "$BFILL_OUT" | grep -iE "PASS|RESULT|FAIL|INVALID"
printf '%s\n' "$BFILL_OUT" | grep -q "RESULT: PASS -- B-fill D coherence"

echo "== B-fill barrier MUTATION (-DMUT_BFILL_NOLOCK): first-cache gates MUST fail =="
iverilog -g2012 -DMUT_BFILL_NOLOCK -o "$T/tb_vram_ddr_bfill_mut.vvp" "${BFILL_SRC[@]}"
BFILL_MUT_OUT="$(vvp "$T/tb_vram_ddr_bfill_mut.vvp")"
printf '%s\n' "$BFILL_MUT_OUT" | grep -iE "RED|RESULT|TEST-INVALID"
printf '%s\n' "$BFILL_MUT_OUT" | grep -q "RESULT: FAIL -- B-fill D coherence"

# ---- A-write-behind / D-partial same-beat coherency -------------------------
# This bench existed but NO runner executed it, which is how its two mutation
# defines sat orphaned. It also could not have passed: its ack wait polled at
# negedge, while fb_ack is combinational and one cycle wide (stv_vram_ddr_top.sv
# :1005 over the :938 edge-detect), so it reported TEST-INVALID on a write that
# had actually landed. Repaired to latch the ack at the posedge.
AWB_SRC=("$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" "$ROOT/sim/tb_vram_ddr_awb_dpartial_red.sv")
echo "== A-WB/D-partial same-beat coherency =="
iverilog -g2012 -o "$T/tb_awb.vvp" "${AWB_SRC[@]}"
AWB_OUT="$(vvp "$T/tb_awb.vvp")"
printf '%s\n' "$AWB_OUT" | grep -iE "GREEN|RED|RESULT|TEST-INVALID"
printf '%s\n' "$AWB_OUT" | grep -q "RESULT: PASS -- A/D same-beat coherency"

echo "== A-WB/D-partial MUTATION (-DMUT_AWB_DPARTIAL_STALE): merge bypass MUST fail =="
iverilog -g2012 -DMUT_AWB_DPARTIAL_STALE -o "$T/tb_awb_mut.vvp" "${AWB_SRC[@]}"
AWB_MUT_OUT="$(vvp "$T/tb_awb_mut.vvp")"
printf '%s\n' "$AWB_MUT_OUT" | grep -iE "RED|RESULT|TEST-INVALID"
printf '%s\n' "$AWB_MUT_OUT" | grep -q "RESULT: FAIL -- A/D same-beat coherency"

# PERF_NO_WBACK is the write-through CONTROL, not a mutant: the bench header
# (tb_vram_ddr_awb_dpartial_red.sv:6-7) specifies that D takes its ordinary
# DDR-read path and BOTH lanes still pass. Asserting PASS here is the point --
# a "contract" demanding it fail would have the polarity backwards.
echo "== A-WB/D-partial CONTROL (-DPERF_NO_WBACK): write-through must still PASS =="
iverilog -g2012 -DPERF_NO_WBACK -o "$T/tb_awb_ctl.vvp" "${AWB_SRC[@]}"
AWB_CTL_OUT="$(vvp "$T/tb_awb_ctl.vvp")"
printf '%s\n' "$AWB_CTL_OUT" | grep -iE "GREEN|RED|RESULT|TEST-INVALID"
printf '%s\n' "$AWB_CTL_OUT" | grep -q "RESULT: PASS -- A/D same-beat coherency"

echo "== Scanline live-write overlays: completed/inflight + ownership boundaries =="
SCANLINE_SRC=("$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/yunit/yunit_scanline.sv" \
  "$ROOT/sim/tb_yunit_scanline_livewrite_red.sv")
iverilog -g2012 -I "$ROOT/rtl/pkg" -s tb_yunit_scanline_livewrite_red \
  -o "$T/tb_yunit_scanline_livewrite.vvp" "${SCANLINE_SRC[@]}"
SCANLINE_OUT="$(vvp "$T/tb_yunit_scanline_livewrite.vvp")"
printf '%s\n' "$SCANLINE_OUT" | grep -iE "PASS|RESULT|FAIL"
printf '%s\n' "$SCANLINE_OUT" | grep -q "RESULT: PASS completed/in-flight + boundary/reuse races"

echo "== Scanline live-write MUTATION (-DMUT_SCANLINE_NO_SNOOP): coherency gates MUST fail =="
iverilog -g2012 -DMUT_SCANLINE_NO_SNOOP -I "$ROOT/rtl/pkg" -s tb_yunit_scanline_livewrite_red \
  -o "$T/tb_yunit_scanline_livewrite_mut.vvp" "${SCANLINE_SRC[@]}"
SCANLINE_MUT_OUT="$(vvp "$T/tb_yunit_scanline_livewrite_mut.vvp")"
printf '%s\n' "$SCANLINE_MUT_OUT" | grep -iE "RESULT: FAIL|FAIL completed|FAIL in-flight|FAIL same-edge|FAIL frame-start"
printf '%s\n' "$SCANLINE_MUT_OUT" | grep -q "RESULT: FAIL errors="

echo "== Scanline row-boundary MUTATION (-DMUT_SCANLINE_HIT_REGISTERED_ROW): stale-row replay MUST fail =="
iverilog -g2012 -DMUT_SCANLINE_HIT_REGISTERED_ROW -I "$ROOT/rtl/pkg" -s tb_yunit_scanline_livewrite_red \
  -o "$T/tb_yunit_scanline_hitrow_mut.vvp" "${SCANLINE_SRC[@]}"
SCANLINE_HITROW_MUT_OUT="$(vvp "$T/tb_yunit_scanline_hitrow_mut.vvp")"
printf '%s\n' "$SCANLINE_HITROW_MUT_OUT" | grep -iE "RESULT: FAIL|FAIL completed|FAIL exact-load-start|FAIL row-advance|FAIL same-edge"
printf '%s\n' "$SCANLINE_HITROW_MUT_OUT" | grep -q "RESULT: FAIL errors="

echo "== Composed video raw-vblank ownership: frame-wrap snoop must not tear row 0 =="
VBLANK_SRC=("$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/yunit/yunit_video.sv" \
  "$ROOT/rtl/yunit/yunit_scanline.sv" "$ROOT/rtl/yunit/yunit_video_top.sv" \
  "$ROOT/sim/tb_yunit_video_vblank_snoop.sv")
iverilog -g2012 -I "$ROOT/rtl/pkg" -s tb_yunit_video_vblank_snoop \
  -o "$T/tb_yunit_video_vblank_snoop.vvp" "${VBLANK_SRC[@]}"
VBLANK_OUT="$(vvp "$T/tb_yunit_video_vblank_snoop.vvp")"
printf '%s\n' "$VBLANK_OUT" | grep -iE "PASS|RESULT|FAIL"
printf '%s\n' "$VBLANK_OUT" | grep -q "RESULT: PASS composed vblank-fall coherency"

echo "== Composed vblank MUTATION (-DMUT_SCANLINE_DELAYED_VBLANK): row-0 tear MUST fail =="
iverilog -g2012 -DMUT_SCANLINE_DELAYED_VBLANK -I "$ROOT/rtl/pkg" -s tb_yunit_video_vblank_snoop \
  -o "$T/tb_yunit_video_vblank_snoop_mut.vvp" "${VBLANK_SRC[@]}"
VBLANK_MUT_OUT="$(vvp "$T/tb_yunit_video_vblank_snoop_mut.vvp")"
printf '%s\n' "$VBLANK_MUT_OUT" | grep -iE "RESULT: FAIL|delayed-vblank snoop tore"
printf '%s\n' "$VBLANK_MUT_OUT" | grep -q "RESULT: FAIL delayed-vblank snoop tore row0"

echo "== Composed 34010/yunit raster phase: production /12 + sync-reset topology =="
PHASE_SRC=("$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" \
  "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv" "$ROOT/rtl/yunit/yunit_video.sv" \
  "$ROOT/sim/tb_yunit_tms_raster_phase.sv")
iverilog -g2012 -I "$ROOT/rtl/pkg" -I "$ROOT/rtl/tms34010/rtl" -s tb_yunit_tms_raster_phase \
  -o "$T/tb_yunit_tms_raster_phase.vvp" "${PHASE_SRC[@]}"
PHASE_OUT="$(vvp "$T/tb_yunit_tms_raster_phase.vvp")"
printf '%s\n' "$PHASE_OUT" | grep -iE "PASS|RESULT|FAIL"
printf '%s\n' "$PHASE_OUT" | grep -q "RESULT: PASS composed TMS/yunit raster phase"

echo "== Raster phase MUTATION (-DMUT_YVIDEO_ZERO_PHASE): -90px/-20-line anchors MUST fail =="
iverilog -g2012 -DMUT_YVIDEO_ZERO_PHASE -I "$ROOT/rtl/pkg" -I "$ROOT/rtl/tms34010/rtl" \
  -s tb_yunit_tms_raster_phase -o "$T/tb_yunit_tms_raster_phase_zero.vvp" "${PHASE_SRC[@]}"
PHASE_ZERO_OUT="$(vvp "$T/tb_yunit_tms_raster_phase_zero.vvp")"
printf '%s\n' "$PHASE_ZERO_OUT" | grep -iE "FAIL active|FAIL DPYINT|RESULT: FAIL"
printf '%s\n' "$PHASE_ZERO_OUT" | grep -q "RESULT: FAIL composed TMS/yunit raster phase errors=3"

echo "== Raster reset MUTATION (-DMUT_YVIDEO_RAW_RESET): release-edge skew MUST fail =="
iverilog -g2012 -DMUT_YVIDEO_RAW_RESET -I "$ROOT/rtl/pkg" -I "$ROOT/rtl/tms34010/rtl" \
  -s tb_yunit_tms_raster_phase -o "$T/tb_yunit_tms_raster_phase_raw.vvp" "${PHASE_SRC[@]}"
PHASE_RAW_OUT="$(vvp "$T/tb_yunit_tms_raster_phase_raw.vvp")"
printf '%s\n' "$PHASE_RAW_OUT" | grep -iE "FAIL active x=0 phase|RESULT: FAIL"
printf '%s\n' "$PHASE_RAW_OUT" | grep -q "RESULT: FAIL composed TMS/yunit raster phase errors=1"

echo "== CPU-to-I/O registered write boundary: ack-retired one-shot commands =="
IO_BOUNDARY_SRC=("$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" \
  "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv" \
  "$ROOT/rtl/tms34010/rtl/io/tms34010_io_write_boundary.sv" \
  "$ROOT/rtl/tms34010/rtl/io/tms34010_io_regs.sv" \
  "$ROOT/rtl/tms34010/sim/tb/tb_io_write_boundary.sv")
iverilog -g2012 -I "$ROOT/rtl/tms34010/rtl" -s tb_io_write_boundary \
  -o "$T/tb_io_write_boundary.vvp" "${IO_BOUNDARY_SRC[@]}"
IO_BOUNDARY_OUT="$(vvp "$T/tb_io_write_boundary.vvp")"
printf '%s\n' "$IO_BOUNDARY_OUT" | grep -iE "TEST_RESULT"
printf '%s\n' "$IO_BOUNDARY_OUT" | grep -q "TEST_RESULT: PASS (registered I/O boundary: ack-retired one-shot, consecutive no-low writes, device-set persistence, reset-kill)"

echo "== I/O boundary MUTATION (-DMUT_IO_LIVE_WRITE): pre-ack/repeat corruption MUST fail =="
iverilog -g2012 -DMUT_IO_LIVE_WRITE -I "$ROOT/rtl/tms34010/rtl" -s tb_io_write_boundary \
  -o "$T/tb_io_write_boundary_mut.vvp" "${IO_BOUNDARY_SRC[@]}"
IO_BOUNDARY_MUT_OUT="$(vvp "$T/tb_io_write_boundary_mut.vvp")"
printf '%s\n' "$IO_BOUNDARY_MUT_OUT" | grep -iE "without a retiring ack|double-committed|erased coincident device-set|TEST_RESULT: FAIL"
printf '%s\n' "$IO_BOUNDARY_MUT_OUT" | grep -q "TEST_RESULT: FAIL: tb_io_write_boundary found"

echo "== CPU graphics-config shadows: ack-edge forwarding before architectural readback =="
IO_CONFIG_SRC=("$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" \
  "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv" \
  "$ROOT/rtl/tms34010/rtl/io/tms34010_io_write_boundary.sv" \
  "$ROOT/rtl/tms34010/rtl/io/tms34010_io_regs.sv" \
  "$ROOT/rtl/tms34010/rtl/io/tms34010_io_cpu_config.sv" \
  "$ROOT/rtl/tms34010/sim/tb/tb_io_cpu_config.sv")
iverilog -g2012 -I "$ROOT/rtl/tms34010/rtl" -s tb_io_cpu_config \
  -o "$T/tb_io_cpu_config.vvp" "${IO_CONFIG_SRC[@]}"
IO_CONFIG_OUT="$(vvp "$T/tb_io_cpu_config.vvp")"
printf '%s\n' "$IO_CONFIG_OUT" | grep -iE "TEST_RESULT"
printf '%s\n' "$IO_CONFIG_OUT" | grep -Fq \
  "TEST_RESULT: PASS (CPU graphics config: ack-edge forwarding, next-sysclk readback, held-request safety, live interrupts)"

echo "== Config-shadow MUTATION (-DMUT_IO_LIVE_TAPS): io_reg-Q bypass MUST fail =="
iverilog -g2012 -DMUT_IO_LIVE_TAPS -I "$ROOT/rtl/tms34010/rtl" -s tb_io_cpu_config \
  -o "$T/tb_io_cpu_config_mut.vvp" "${IO_CONFIG_SRC[@]}"
IO_CONFIG_MUT_OUT="$(vvp "$T/tb_io_cpu_config_mut.vvp")"
printf '%s\n' "$IO_CONFIG_MUT_OUT" | grep -iE "not write-forwarded at ack|TEST_RESULT: FAIL"
for config_reg in PSIZE CONVDP CONVSP CONTROL PMASK; do
  printf '%s\n' "$IO_CONFIG_MUT_OUT" | grep -Fq \
    "TEST_RESULT: FAIL: $config_reg shadow not write-forwarded at ack: 0000"
done
printf '%s\n' "$IO_CONFIG_MUT_OUT" | grep -Fq \
  "TEST_RESULT: FAIL: tb_io_cpu_config found 5 failure(s)"

echo "== CPU status shadows/read mux: /1+/4 bridges, sticky events, live H/V =="
IO_STATUS_SRC=("$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" \
  "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv" \
  "$ROOT/rtl/tms34010/rtl/io/tms34010_io_write_boundary.sv" \
  "$ROOT/rtl/tms34010/rtl/io/tms34010_io_regs.sv" \
  "$ROOT/rtl/tms34010/rtl/io/tms34010_io_cpu_status.sv" \
  "$ROOT/rtl/tms34010/rtl/io/tms34010_io_cpu_read_mux.sv" \
  "$ROOT/rtl/tms34010/sim/tb/tb_io_cpu_status.sv")
iverilog -g2012 -I "$ROOT/rtl/tms34010/rtl" -s tb_io_cpu_status \
  -o "$T/tb_io_cpu_status.vvp" "${IO_STATUS_SRC[@]}"
IO_STATUS_OUT="$(vvp "$T/tb_io_cpu_status.vvp")"
printf '%s\n' "$IO_STATUS_OUT" | grep -iE "TEST_RESULT"
printf '%s\n' "$IO_STATUS_OUT" | grep -Fq \
  "TEST_RESULT: PASS (status shadows: /1+/4 bridge, sticky events, NMI clear, special reads, live H/V)"

echo "== Status-bridge MUTATION (-DMUT_IO_STATUS_NO_BRIDGE): /1 stale reassert MUST fail =="
iverilog -g2012 -DMUT_IO_STATUS_NO_BRIDGE -I "$ROOT/rtl/tms34010/rtl" \
  -s tb_io_cpu_status -o "$T/tb_io_cpu_status_nobridge.vvp" "${IO_STATUS_SRC[@]}"
IO_STATUS_NOBRIDGE_OUT="$(vvp "$T/tb_io_cpu_status_nobridge.vvp")"
printf '%s\n' "$IO_STATUS_NOBRIDGE_OUT" | grep -iE "bridge failed|bridge hold failed|TEST_RESULT: FAIL"
printf '%s\n' "$IO_STATUS_NOBRIDGE_OUT" | grep -Fq \
  "TEST_RESULT: FAIL: /1 E1 bridge failed to hold forwarded clear across stale live input"
printf '%s\n' "$IO_STATUS_NOBRIDGE_OUT" | grep -Fq \
  "TEST_RESULT: FAIL: set-dominant E1 did not hold clear/live event"
printf '%s\n' "$IO_STATUS_NOBRIDGE_OUT" | grep -Fq \
  "TEST_RESULT: FAIL: INTENB bridge hold failed"
printf '%s\n' "$IO_STATUS_NOBRIDGE_OUT" | grep -Fq \
  "TEST_RESULT: FAIL: tb_io_cpu_status found 3 failure(s)"

echo "== Status/config read MUTATION (-DMUT_IO_LIVE_READBACK): 8 live bypasses MUST fail =="
iverilog -g2012 -DMUT_IO_LIVE_READBACK -I "$ROOT/rtl/tms34010/rtl" \
  -s tb_io_cpu_status -o "$T/tb_io_cpu_status_liveread.vvp" "${IO_STATUS_SRC[@]}"
IO_STATUS_LIVEREAD_OUT="$(vvp "$T/tb_io_cpu_status_liveread.vvp")"
printf '%s\n' "$IO_STATUS_LIVEREAD_OUT" | grep -iE "read not shadowed|TEST_RESULT: FAIL"
for read_reg in PSIZE CONVDP CONVSP CONTROL PMASK INTENB INTPEND HSTCTLH; do
  printf '%s\n' "$IO_STATUS_LIVEREAD_OUT" | grep -Fq \
    "TEST_RESULT: FAIL: $read_reg read not shadowed"
done
printf '%s\n' "$IO_STATUS_LIVEREAD_OUT" | grep -Fq \
  "TEST_RESULT: FAIL: tb_io_cpu_status found 8 failure(s)"

echo "== TI INTPEND semantics: RO X1/X2/HI, DI/WV write-zero-to-clear =="
IO_INTPEND_SRC=("$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" \
  "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv" \
  "$ROOT/rtl/tms34010/rtl/io/tms34010_io_write_boundary.sv" \
  "$ROOT/rtl/tms34010/rtl/io/tms34010_io_regs.sv" \
  "$ROOT/rtl/tms34010/rtl/io/tms34010_io_cpu_status.sv" \
  "$ROOT/rtl/tms34010/sim/tb/tb_io_intpend_semantics.sv")
iverilog -g2012 -I "$ROOT/rtl/tms34010/rtl" -s tb_io_intpend_semantics \
  -o "$T/tb_io_intpend_semantics.vvp" "${IO_INTPEND_SRC[@]}"
IO_INTPEND_OUT="$(vvp "$T/tb_io_intpend_semantics.vvp")"
printf '%s\n' "$IO_INTPEND_OUT" | grep -iE "TEST_RESULT"
printf '%s\n' "$IO_INTPEND_OUT" | grep -Fq \
  "TEST_RESULT: PASS (INTPEND: RO X1/X2/HI, DI/WV W0C, physical+CPU shadow)"

echo "== INTPEND MUTATION (-DMUT_IO_INTPEND_WHOLE_WRITE): vector writes MUST fail =="
iverilog -g2012 -DMUT_IO_INTPEND_WHOLE_WRITE -I "$ROOT/rtl/tms34010/rtl" \
  -s tb_io_intpend_semantics -o "$T/tb_io_intpend_semantics_mut.vvp" \
  "${IO_INTPEND_SRC[@]}"
IO_INTPEND_MUT_OUT="$(vvp "$T/tb_io_intpend_semantics_mut.vvp")"
printf '%s\n' "$IO_INTPEND_MUT_OUT" | grep -iE "software write|read-only|TEST_RESULT: FAIL"
for intpend_failure in \
  "all-ones software write set DI/WV in CPU shadow" \
  "all-ones software write set read-only bits in CPU shadow" \
  "all-ones software write set physical DI/WV" \
  "all-ones software write set physical read-only bits" \
  "DI0/WV1 write altered read-only shadow bits" \
  "DI0/WV1 write altered physical read-only bits" \
  "software write cleared read-only X1 shadow"; do
  printf '%s\n' "$IO_INTPEND_MUT_OUT" | grep -Fq "TEST_RESULT: FAIL: $intpend_failure"
done
printf '%s\n' "$IO_INTPEND_MUT_OUT" | grep -Fq \
  "TEST_RESULT: FAIL: tb_io_intpend_semantics found 7 failure(s)"

echo "== Event-safe delayed I/O commit: old clear, E0/E1 WVP+DI, NMI ordering =="
IO_EVENT_GAP_SRC=("$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" \
  "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv" \
  "$ROOT/rtl/tms34010/rtl/io/tms34010_io_write_boundary.sv" \
  "$ROOT/rtl/tms34010/rtl/io/tms34010_io_regs.sv" \
  "$ROOT/rtl/tms34010/sim/tb/tb_io_event_gap.sv")
iverilog -g2012 -I "$ROOT/rtl/tms34010/rtl" -s tb_io_event_gap \
  -o "$T/tb_io_event_gap.vvp" "${IO_EVENT_GAP_SRC[@]}"
IO_EVENT_GAP_OUT="$(vvp "$T/tb_io_event_gap.vvp")"
printf '%s\n' "$IO_EVENT_GAP_OUT" | grep -iE "TEST_RESULT"
printf '%s\n' "$IO_EVENT_GAP_OUT" | grep -Fq \
  "TEST_RESULT: PASS (event-safe delayed commit: old clear, E0/E1 WVP+DI, same-bit DI, NMI ordering)"

echo "== Event-gap MUTATION (-DMUT_IO_EVENT_GAP): blind delayed commit MUST fail =="
iverilog -g2012 -DMUT_IO_EVENT_GAP -I "$ROOT/rtl/tms34010/rtl" \
  -s tb_io_event_gap -o "$T/tb_io_event_gap_mut.vvp" "${IO_EVENT_GAP_SRC[@]}"
IO_EVENT_GAP_MUT_OUT="$(vvp "$T/tb_io_event_gap_mut.vvp")"
printf '%s\n' "$IO_EVENT_GAP_MUT_OUT" | grep -iE "erased|lost|resurrected|TEST_RESULT: FAIL"
for gap_failure in \
  "E0 WVP erased by delayed clear" \
  "E1 WVP lost on physical commit" \
  "same-bit E0 DI erased by delayed clear" \
  "E0 nmi_clear resurrected at delayed HSTCTLH commit" \
  "E1 nmi_clear lost on HSTCTLH commit"; do
  printf '%s\n' "$IO_EVENT_GAP_MUT_OUT" | grep -Fq "TEST_RESULT: FAIL: $gap_failure"
done
printf '%s\n' "$IO_EVENT_GAP_MUT_OUT" | grep -Fq \
  "TEST_RESULT: FAIL: tb_io_event_gap found 5 failure(s)"

echo "== Live INITIO timing origin: delayed/spaced/held HTOTAL programming =="
TIMING_SRC=("$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" \
  "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv" \
  "$ROOT/rtl/tms34010/rtl/io/tms34010_io_regs.sv" "$ROOT/rtl/yunit/yunit_video.sv" \
  "$ROOT/sim/tb_yunit_timing_start_phase.sv")
iverilog -g2012 -I "$ROOT/rtl/pkg" -I "$ROOT/rtl/tms34010/rtl" \
  -s tb_yunit_timing_start_phase -o "$T/tb_yunit_timing_start_phase.vvp" "${TIMING_SRC[@]}"
TIMING_OUT="$(vvp "$T/tb_yunit_timing_start_phase.vvp")"
printf '%s\n' "$TIMING_OUT" | grep -iE "PASS case|TEST_RESULT"
printf '%s\n' "$TIMING_OUT" | grep -q "TEST_RESULT: PASS live HTOTAL timing origin locks TMS/yunit raster"

echo "== Timing-boundary MUTATION (-DMUT_TIMING_COMB_START): live CPU reset path MUST fail =="
iverilog -g2012 -DMUT_TIMING_COMB_START -I "$ROOT/rtl/pkg" -I "$ROOT/rtl/tms34010/rtl" \
  -s tb_yunit_timing_start_phase -o "$T/tb_yunit_timing_start_phase_comb.vvp" "${TIMING_SRC[@]}"
TIMING_COMB_OUT="$(vvp "$T/tb_yunit_timing_start_phase_comb.vvp")"
printf '%s\n' "$TIMING_COMB_OUT" | grep -iE "preceding HTOTAL request|preceded stored HTOTAL|TEST_RESULT: FAIL"
printf '%s\n' "$TIMING_COMB_OUT" | grep -q "TEST_RESULT: FAIL timing-start phase errors="

echo "== Live INITIO MUTATION (-DMUT_TIMING_NO_HTOTAL_RESYNC): boot-delay offsets MUST fail =="
iverilog -g2012 -DMUT_TIMING_NO_HTOTAL_RESYNC -I "$ROOT/rtl/pkg" -I "$ROOT/rtl/tms34010/rtl" \
  -s tb_yunit_timing_start_phase -o "$T/tb_yunit_timing_start_phase_noht.vvp" "${TIMING_SRC[@]}"
TIMING_NOHT_OUT="$(vvp "$T/tb_yunit_timing_start_phase_noht.vvp")"
printf '%s\n' "$TIMING_NOHT_OUT" | grep -iE "FAIL case|TEST_RESULT: FAIL"
printf '%s\n' "$TIMING_NOHT_OUT" | grep -q "TEST_RESULT: FAIL timing-start phase errors="

echo "== Live INITIO MUTATION (-DMUT_TIMING_NO_DIV_RESYNC): one-pixel phase MUST fail =="
iverilog -g2012 -DMUT_TIMING_NO_DIV_RESYNC -I "$ROOT/rtl/pkg" -I "$ROOT/rtl/tms34010/rtl" \
  -s tb_yunit_timing_start_phase -o "$T/tb_yunit_timing_start_phase_nodiv.vvp" "${TIMING_SRC[@]}"
TIMING_NODIV_OUT="$(vvp "$T/tb_yunit_timing_start_phase_nodiv.vvp")"
printf '%s\n' "$TIMING_NODIV_OUT" | grep -iE "FAIL case|TEST_RESULT: FAIL"
printf '%s\n' "$TIMING_NODIV_OUT" | grep -q "TEST_RESULT: FAIL timing-start phase errors="

echo "== DPYINT edge MUTATION (-DMUT_DPYINT_LATE): leaving-HSBLNK pulse MUST fail =="
iverilog -g2012 -DMUT_DPYINT_LATE -I "$ROOT/rtl/pkg" -I "$ROOT/rtl/tms34010/rtl" \
  -s tb_yunit_timing_start_phase -o "$T/tb_yunit_timing_start_phase_dpylate.vvp" "${TIMING_SRC[@]}"
TIMING_DPYLATE_OUT="$(vvp "$T/tb_yunit_timing_start_phase_dpylate.vvp")"
printf '%s\n' "$TIMING_DPYLATE_OUT" | grep -iE "FAIL case.*DPYINT arrival|TEST_RESULT: FAIL"
printf '%s\n' "$TIMING_DPYLATE_OUT" | grep -q "TEST_RESULT: FAIL timing-start phase errors="

echo "== P1.9d raster integration (REAL video chain: prefetch loader -> B scanout + C erase) =="
iverilog -g2012 -o "$T/tb_vram_ddr_raster.vvp" \
  "$ROOT/rtl/pkg/yunit_pkg.sv" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/rtl/yunit/yunit_video.sv" "$ROOT/rtl/yunit/yunit_scanline.sv" "$ROOT/rtl/yunit/yunit_video_top.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" "$ROOT/sim/tb_vram_ddr_raster.sv"
vvp "$T/tb_vram_ddr_raster.vvp" | grep -iE "RESULT|FAIL|beam-lock|issue counts|sentinel"
# headroom: 2-3x cab-realistic DDR contention must still erase every row every frame
vvp "$T/tb_vram_ddr_raster.vvp" +busy=20 +rlat=12 | grep -iE "RESULT|FAIL"

echo "== RAMCHECK full-stack (yunit_mem R_VRAM decode -> field engine -> DDR3, real self-test geometry) =="
iverilog -g2012 -DUSE_HW_RAM -DUSE_SDRAM_VRAM -DUSE_DDR3_VRAM -DYM_EXT_RD -o "$T/tb_yunit_vramcheck.vvp" \
  "$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/yunit/yunit_protection.sv" "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/rtl/yunit/yunit_mem.sv" "$ROOT/rtl/yunit/yunit_palram.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" "$ROOT/sim/tb_yunit_vramcheck.sv" 2>&1 | grep -v "sorry:" || true
[ -f "$T/tb_yunit_vramcheck.vvp" ] || { echo "RESULT: FAIL -- RAMCHECK full-stack did not COMPILE (stderr was hidden by 2>/dev/null; yunit_protection.sv was missing)"; exit 1; }
VRC_OUT="$(vvp "$T/tb_yunit_vramcheck.vvp")"
printf "%s
" "$VRC_OUT" | grep -iE "RESULT|FAIL"
printf "%s
" "$VRC_OUT" | grep -q "RESULT: PASS" || { echo "RESULT: FAIL -- RAMCHECK full-stack"; exit 1; }

echo "== W-THRU2 fb write-combine (lane D): content + cost + coherency + redraw-fits-in-frame =="
FBC_SRC=("$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/yunit/vram_sdram.sv" \
  "$ROOT/rtl/yunit/vram_sdram_top.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" "$ROOT/sim/tb_vram_ddr_fbcombine.sv")
iverilog -g2012 -o "$T/tb_vram_ddr_fbcombine.vvp" "${FBC_SRC[@]}"
vvp "$T/tb_vram_ddr_fbcombine.vvp" | grep -iE "RESULT|FAIL|COST over|clk/px"
# MUTATION coverage: -DPERF_NO_FBCOMBINE disables the same-beat combine (every pixel a partial RMW).
# The cost + redraw-fits gates MUST then FAIL (proving the gate exercises the combine AND that the
# uncombined cost reproduces the attract watchdog condition). Coherency + content stay green.
echo "== on-add snoop MUTATION (-DMUT_NO_ONADD): A/B coherency gates MUST fail =="
iverilog -g2012 -DMUT_NO_ONADD -o "$T/tb_fbc_onadd_mut.vvp" "${FBC_SRC[@]}"
ONADD_OUT="$(vvp "$T/tb_fbc_onadd_mut.vvp")"
printf '%s
' "$ONADD_OUT" | grep -iE "RESULT|FAIL" | head -4
printf '%s
' "$ONADD_OUT" | grep -q "RESULT: FAIL" || { echo "run_ddr3: MUT_NO_ONADD did NOT fail -- contract is not real"; exit 1; }

echo "== fb write-combine MUTATION (-DPERF_NO_FBCOMBINE): cost/redraw gates MUST fail (coverage) =="
iverilog -g2012 -DPERF_NO_FBCOMBINE -o "$T/tb_vram_ddr_fbcombine_mut.vvp" "${FBC_SRC[@]}"
vvp "$T/tb_vram_ddr_fbcombine_mut.vvp" | grep -iE "RESULT|COST FAIL|REDRAW FAIL"

echo "== B-fill/framebuffer overlap: cross-row progress + same-row coherency =="
OVL_SRC=("$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/yunit/vram_sdram.sv" \
  "$ROOT/rtl/yunit/vram_sdram_top.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" "$ROOT/sim/tb_vram_ddr_overlap.sv")
iverilog -g2012 -o "$T/tb_vram_ddr_overlap.vvp" "${OVL_SRC[@]}"
OVL_OUT="$(vvp "$T/tb_vram_ddr_overlap.vvp")"
printf '%s\n' "$OVL_OUT" | grep -iE "OVERLAP-COST|SAME-ROW|RESULT"
printf '%s\n' "$OVL_OUT" | grep -q "RESULT: PASS -- cross-row writes overlap B fills"

echo "== overlap MUTATION (-DMUT_FB_FILL_PARK): old whole-fill park MUST fail cost gate =="
iverilog -g2012 -DMUT_FB_FILL_PARK -o "$T/tb_vram_ddr_overlap_mut.vvp" "${OVL_SRC[@]}"
OVL_MUT_OUT="$(vvp "$T/tb_vram_ddr_overlap_mut.vvp")"
printf '%s\n' "$OVL_MUT_OUT" | grep -iE "OVERLAP-COST|COST FAIL|RESULT"
printf '%s\n' "$OVL_MUT_OUT" | grep -q "RESULT: FAIL -- 1 error(s)."

echo "== captured intro: real 24-blit DMA stream + concurrent scan fills =="
INTRO_SRC=("$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/yunit/yunit_dma.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/yunit/vram_sdram.sv" \
  "$ROOT/rtl/yunit/vram_sdram_top.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" "$ROOT/sim/tb_intro_ddr_pace.sv")
iverilog -g2012 -o "$T/tb_intro_ddr_pace.vvp" "${INTRO_SRC[@]}"
INTRO_OUT="$(vvp "$T/tb_intro_ddr_pace.vvp" "+BLITS=$ROOT/sim/build/blit_regs.txt")"
printf '%s\n' "$INTRO_OUT" | grep -iE "INTRO-DDR|INTRO-WAIT|RESULT"
printf '%s\n' "$INTRO_OUT" | grep -q "RESULT: PASS -- captured intro frame drained"

echo "== intro MUTATION (-DMUT_FB_ACK_REGISTERED): one-late acknowledge MUST fail cost gate =="
iverilog -g2012 -DMUT_FB_ACK_REGISTERED -o "$T/tb_intro_ddr_ack_mut.vvp" "${INTRO_SRC[@]}"
INTRO_ACK_MUT_OUT="$(vvp "$T/tb_intro_ddr_ack_mut.vvp" "+BLITS=$ROOT/sim/build/blit_regs.txt")"
printf '%s\n' "$INTRO_ACK_MUT_OUT" | grep -iE "INTRO-DDR|INTRO-WAIT|COST FAIL|RESULT"
printf '%s\n' "$INTRO_ACK_MUT_OUT" | grep -q "RESULT: FAIL -- captured intro DDR pace errors=1"

echo "== Williams CVSD mono mix: MAME routing/normalization + old-routing mutation =="
AUDIO_SRC=("$ROOT/rtl/yunit/yunit_audio_mix.sv" "$ROOT/sim/tb_audio_mix.sv")
iverilog -g2012 -o "$T/tb_audio_mix.vvp" "${AUDIO_SRC[@]}"
AUDIO_OUT="$(vvp "$T/tb_audio_mix.vvp")"
printf '%s\n' "$AUDIO_OUT" | grep -iE "PASS AUDIO-MIX|RESULT"
# Match the STABLE PREFIX plus an explicit no-failure check. The old assertion
# demanded "PASS AUDIO-MIX: mono YM sum", which the bench STOPPED PRINTING when the
# mix was retuned to MAME's ratios (tb_audio_mix.sv:45 now prints "+6 dB JT51 music,
# mono routing, unsigned DAC normalization, saturation"). The gate PASSED and this
# single line turned the whole script red -- stale-expected-string bit-rot, the same
# class as the RAMCHECK build line that had been silently dead 260 lines above.
printf '%s\n' "$AUDIO_OUT" | grep -q "^PASS AUDIO-MIX"
if printf '%s\n' "$AUDIO_OUT" | grep -qE "^FAIL AUDIO-MIX|^RESULT: FAIL AUDIO-MIX"; then
  echo "run_ddr3: audio mix reported failures"; exit 1
fi
iverilog -g2012 -DMUT_AUDIO_OLD_ROUTING -o "$T/tb_audio_mix_mut.vvp" "${AUDIO_SRC[@]}"
AUDIO_MUT_OUT="$(vvp "$T/tb_audio_mix_mut.vvp")"
printf '%s\n' "$AUDIO_MUT_OUT" | grep -iE "FAIL AUDIO-MIX|RESULT"
printf '%s\n' "$AUDIO_MUT_OUT" | grep -q "RESULT: FAIL AUDIO-MIX errors=9"
# mixer-gain audit kill controls (2026-08-18): the 3.3x-hot CVSD coefficient
# (HI/SHI crowd wash) and the hot-crowd-era YM x0.20 must both be rejected.
iverilog -g2012 -DMUT_AUDIO_HOT_CVSD -o "$T/tb_audio_mix_mut2.vvp" "${AUDIO_SRC[@]}"
vvp "$T/tb_audio_mix_mut2.vvp" | grep -q "RESULT: FAIL AUDIO-MIX errors=1" \
  || { echo "run_ddr3: MUT_AUDIO_HOT_CVSD mutant SURVIVED"; exit 1; }
iverilog -g2012 -DMUT_AUDIO_YM_020 -o "$T/tb_audio_mix_mut3.vvp" "${AUDIO_SRC[@]}"
vvp "$T/tb_audio_mix_mut3.vvp" | grep -q "RESULT: FAIL AUDIO-MIX errors=5" \
  || { echo "run_ddr3: MUT_AUDIO_YM_020 mutant SURVIVED"; exit 1; }
