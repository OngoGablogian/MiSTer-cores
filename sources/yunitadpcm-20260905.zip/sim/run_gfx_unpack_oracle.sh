#!/usr/bin/env bash
# Graphics DELIVERY gate: real ROM planes -> the real on-chip unpack pass ->
# the game's own per-chip ROM checksum test.
#
# This is the first gate in the tree that checks graphics CONTENT rather than
# just that the display path configures.  See sim/tb_yunit_gfx_unpack_oracle.sv
# for why that gap existed.
#
#   usage: sim/run_gfx_unpack_oracle.sh <smashtv|totcarn> [acklat] [stall]
#
# The ack matrix is the point: leg 1 is the easy always-ready case, later legs
# make the arbiter grant late and intermittently.  A pass on leg 1 alone proves
# very little.
set -euo pipefail

TITLE="${1:?usage: run_gfx_unpack_oracle.sh <smashtv|totcarn> [acklat] [stall]}"
ACKLAT="${2:-0}"
STALL="${3:-0}"

ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
ROMS="${YUNIT_ROMS:-}"
if [ -z "$ROMS" ]; then
  for cand in "$ROOT/../roms" "$ROOT/../smash tv/roms"; do
    [ -d "$cand" ] && { ROMS="$cand"; break; }
  done
fi
[ -d "$ROMS" ] || { echo "GFX_ORACLE_FAIL cannot find the ROM dir; set YUNIT_ROMS" >&2; exit 66; }
WORK="$ROOT/sim/build/gfx-unpack-oracle/$TITLE"
mkdir -p "$WORK"

case "$TITLE" in
  smashtv) PLANE_BYTES=$((0x60000));  BPP4=0; ZIPNAME=smashtv.zip ;;
  totcarn) PLANE_BYTES=$((0x100000)); BPP4=0; ZIPNAME=totcarn.zip ;;
  # Mortal Kombat rev 1.0 (the set the ADPCM MRA boots). 3 planes x 2 MB --
  # the LARGEST Y-unit image, and the first ADPCM-sized run of this gate: the
  # cabinet-proven titles never source a pixel above image offset 4 MB, MK's
  # gameplay blits are 77% above it (blitprof mkla1 2026-08-16, MAME 0.289).
  mkla1)   PLANE_BYTES=$((0x200000)); BPP4=0; ZIPNAME=mk.zip ;;
  # Terminator 2 LA4 (midyunit.cpp:3547-3561): 3 planes x 4 x 512 KB, the
  # same 2 MB plane size as MK. First customer: the cabinet's black
  # boot->attract transition traced to the game's ROM-error/checksum path
  # (pc ffc05110 byte-sum loop, MAME-unreachable with the same CMOS) -- if
  # T2's delivered gfx bytes differ from the golden unpack, POST fails and
  # the game detours exactly there.
  term2)   PLANE_BYTES=$((0x200000)); BPP4=0; ZIPNAME=term2.zip ;;
  # Strike Force LA1 (midyunit.cpp:2867-2879): the family's 4bpp OUTLIER --
  # TWO planes of 6 chips (u111-114+u106-107 at region 0x0, u95-98+u90-91 at
  # region 0x200000 = gfx_chunk stride, midyunit_m.cpp:249). Never covered by
  # this oracle before 2026-08-18 (the family-blindness hole the cab found:
  # half the splash sprites missing, no intro, HUD-only in game).
  strkforc) PLANE_BYTES=$((0xC0000)); BPP4=1; ZIPNAME=strkforc.zip ;;
  *) echo "GFX_ORACLE_FAIL unsupported title: $TITLE" >&2; exit 64 ;;
esac
PLANE_WORDS=$((PLANE_BYTES / 2))

PLANES_HEX="$WORK/planes.hex"
DUMP="$WORK/unpacked.bin"

# ---- stage the raw planes exactly as the download mapper packs them --------
python - "$TITLE" "$ROMS" "$PLANES_HEX" <<'PY'
import sys, zipfile, pathlib
title, roms, out = sys.argv[1], pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[3])
SPEC = {
 "smashtv": ("smashtv.zip", "la1_smash_tv_game_rom_{c}.{c}",
             [["u111","u112","u113"],["u95","u96","u97"],["u106","u107","u108"]]),
 "totcarn": ("totcarn.zip", "la1_total_carnage_game_rom_{c}.{c}",
             [["u111","u112","u113","u114"],["u95","u96","u97","u98"],
              ["u106","u107","u108","u109"]]),
 "mkla1":   ("mk.zip", "mkla1/l1_mortal_kombat_game_rom_u-{n}.{c}",
             [["u111","u112","u113","u114"],["u95","u96","u97","u98"],
              ["u106","u107","u108","u109"]]),
 "term2":   ("term2.zip", "la1_terminator_2_game_rom_{c}.{c}",
             [["u111","u112","u113","u114"],["u95","u96","u97","u98"],
              ["u106","u107","u108","u109"]]),
 "strkforc": ("strkforc.zip", "la1_strike_force_game_rom_{c}.{c}",
             [["u111","u112","u113","u114","u106","u107"],
              ["u95","u96","u97","u98","u90","u91"]]),
}
zipname, pat, planes_spec = SPEC[title]
with zipfile.ZipFile(roms / zipname) as zf:
    planes = [b"".join(zf.read(pat.format(c=c, n=c.lstrip("u"))) for c in row)
              for row in planes_spec]
spans = {len(p) for p in planes}
assert len(spans) == 1, f"plane spans differ: {[hex(len(p)) for p in planes]}"
blob = b"".join(planes)                      # plane0 | plane1 | plane2, contiguous
# 16-bit little-endian words, one per line -- $readmemh order
with out.open("w") as f:
    for i in range(0, len(blob), 2):
        f.write(f"{blob[i+1]<<8 | blob[i]:04x}\n")
print(f"staged {len(blob):#x} plane bytes ({len(planes)} planes x {len(planes[0]):#x})")
PY

# ---- run the real unpack pass ---------------------------------------------
echo "=== unpack pass: $TITLE acklat=$ACKLAT stall=1/$STALL ==="
bash "$ROOT/sim/run.sh" tb_yunit_gfx_unpack_oracle \
  "+PLANES=$PLANES_HEX" "+OUT=$DUMP" "+PW=$PLANE_WORDS" "+BPP4=$BPP4" \
  "+ACKLAT=$ACKLAT" "+STALL=$STALL"

[ -s "$DUMP" ] || { echo "GFX_ORACLE_FAIL no dump produced" >&2; exit 1; }

# ---- check what the RTL actually produced ----------------------------------
if [ "$TITLE" = "mkla1" ] || [ "$TITLE" = "strkforc" ]; then
  # No DIAG.ASM table exists for MK (no historicalsource tree): use the FULL
  # byte-diff oracle instead -- python init_gfxrom transcription vs RTL output.
  echo "=== full-image byte diff vs the independent python unpack ==="
  python "$ROOT/tools/yunit_rom_selftest.py" "$TITLE" \
    --readback "$DUMP" --diff-zip "$ROMS/$ZIPNAME"
else
  echo "=== the game's own ROM self-test, against what the RTL actually produced ==="
  python "$ROOT/tools/yunit_rom_selftest.py" "$TITLE" --readback "$DUMP"
fi
