#!/usr/bin/env python3
# make_stv_maindata_hex.py -- Smash TV program-ROM hex for tb_stv_cpu_replay.
#
# MAME gospel (docs/mame-ref/midyunit.cpp:2343-2345, set `smashtv` rev 8.00 = la8):
#   ROM_REGION16_LE( 0x100000, "maindata", 0 )
#   ROM_LOAD16_BYTE( "la8_smash_tv_game_rom_u105.u105", 0xc0000, 0x20000, ... )  // even -> LOW byte
#   ROM_LOAD16_BYTE( "la8_smash_tv_game_rom_u89.u89",   0xc0001, 0x20000, ... )  // odd  -> HIGH byte
# CPU window (midyunit.cpp:195): map(0xff800000, 0xffffffff).rom().region("maindata", 0)
#   -- 34010 BIT addresses: the 8M-bit window = 1 MB = the whole region, 1:1, NO mirror.
#   word index = (bitaddr - 0xFF800000) >> 4, i.e. 0x80000 words; program words at 0x60000..0x7FFFF
#   (byte offset 0xC0000), so code sits at bit 0xFFE00000+ and the vectors at 0xFFFFFExx/0xFFFFFFxx.
#
# Output: 0x80000 lines, one 4-hex-digit 16-bit word per line (word = u105[i] | u89[i]<<8),
# unpopulated low region = 0000 (MAME region default fill; never fetched).
import sys, zipfile

zpath, out = sys.argv[1], sys.argv[2]
z = zipfile.ZipFile(zpath)
def member(frag):
    # top-level la8 set only (subdirs hold older revisions)
    for n in z.namelist():
        if "/" not in n and frag in n:
            return z.read(n)
    raise SystemExit(f"member with '{frag}' not found at zip top level")

u105 = member("u105")   # even bytes -> low
u89  = member("u89")    # odd  bytes -> high
assert len(u105) == 0x20000 and len(u89) == 0x20000, (len(u105), len(u89))

words = [0] * 0x80000
for i in range(0x20000):
    words[0x60000 + i] = u105[i] | (u89[i] << 8)

with open(out, "w") as f:
    for w in words:
        f.write(f"{w:04X}\n")

# sanity: the reset vector (bit 0xFFFFFFE0 -> words 0x7FFFE/0x7FFFF) must point into ROM
rv = words[0x7FFFE] | (words[0x7FFFF] << 16)
print(f"reset vector = {rv:08X}")
assert (rv >> 24) == 0xFF, f"reset vector {rv:08X} not in the ROM window"
print(f"OK: {out} ({len(words)} words, program at 0x60000..0x7FFFF)")
