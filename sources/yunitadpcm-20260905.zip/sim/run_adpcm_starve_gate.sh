#!/usr/bin/env bash
# GATE: the ADPCM sound client TAXES the main CPU's SDRAM grants, never starves
# them. Bar = the arbiter's own rationale for sound-above-CPU priority
# (yunit_sdram_arb.sv: "sound consumes only short word refills" -> <=25% tax,
# i.e. the CPU must retain >=75% of its no-sound grant ceiling).
#
# HISTORY: tb_adpcm_arb_starve was authored for SHIP-SPEC-yunit-2026-08-02 F0
# and then had NO RUNNER -- it never gated anything, and the defect it was
# written to catch shipped in the first ADPCM RBF (YUnitADPCM_20260816):
# the board's two-client ext-ROM mux free-ran, toggling the address every
# cycle once both clients were valid, so the single-stream word cache missed
# continuously and held snd_rd forever. Measured on the full core: totcarn
# profile boot 4.81M cycles sound-off vs 88.21M sound-on (main CPU at ~5%),
# identical with real and all-zero sound ROM. This runner exists so the gate
# can never sit unrun again.
#
# Runs the mutation control every invocation: -DMUT_ADPCM_FREE_RUN restores
# the free-running fetch behaviour and MUST fail.
set -euo pipefail
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
IV="${IV:-iverilog}"

command -v "$IV" >/dev/null 2>&1 || { echo "GATE_INCONCLUSIVE: no iverilog on PATH"; exit 77; }

# The bench boots the REAL 6809 firmware and plays COINSND through the OKI:
# it needs the canonical TC sound image.
if [ ! -s "$ROOT/sim/build/totcarn_sound.hex" ]; then
  python "$ROOT/sim/make_adpcm_hex.py" \
    "${YUNIT_TC_ZIP:-D:/deck/fpga/smash tv/roms/totcarn.zip}" \
    "$ROOT/sim/build/totcarn_sound.hex" \
    || { echo "GATE_INCONCLUSIVE: cannot stage totcarn sound image"; exit 77; }
fi

SRC=("$ROOT/rtl/pkg/yunit_pkg.sv")
for f in "$ROOT"/rtl/sound/jt51/hdl/*.v; do SRC+=("$f"); done
for f in "$ROOT"/rtl/sound/jt6295/*.v;   do SRC+=("$f"); done
SRC+=("$ROOT/rtl/sound/williams_cvsd/mc6809is.v"
      "$ROOT/rtl/yunit/yunit_sound_cdc.sv"
      "$ROOT/rtl/yunit/yunit_sound_rom_cache.sv"
      "$ROOT/rtl/sdram/yunit_sdram_arb.sv"
      "$ROOT/rtl/yunit/yunit_audio_mix.sv"
      "$ROOT/rtl/yunit/yunit_adpcm_board.sv"
      "$ROOT/sim/tb_adpcm_arb_starve.sv")

D="$ROOT/sim/build"
"$IV" -g2012 -s tb_adpcm_arb_starve -o "$D/starve.vvp"  "${SRC[@]}" 2>&1 | grep -v "sorry:" || true
"$IV" -g2012 -DMUT_ADPCM_FREE_RUN -s tb_adpcm_arb_starve -o "$D/starvem.vvp" "${SRC[@]}" 2>&1 | grep -v "sorry:" || true

(cd "$ROOT/sim" && vvp "$D/starve.vvp")  | tee "$D/starve.log"
(cd "$ROOT/sim" && vvp "$D/starvem.vvp") | tee "$D/starve_mutant.log" >/dev/null

grep -q "ARB-STARVE PASS" "$D/starve.log" \
  || { echo "GATE FAIL: adpcm_starve -- the sound client starves the main CPU"; exit 1; }
grep -q "ARB-STARVE FAIL" "$D/starve_mutant.log" \
  || { echo "GATE_INCONCLUSIVE: the MUT_ADPCM_FREE_RUN mutant SURVIVED"; exit 77; }

echo "ADPCM-STARVE: PASS (mutant killed)"
