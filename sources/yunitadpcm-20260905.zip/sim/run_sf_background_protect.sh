#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SCENE="${SCENE:-sf}"
case "$SCENE" in
  sf)
    CHECKPOINT="${SF_CHECKPOINT:-/d/deck/fpga/smash tv/Arcade-SmashTV_MiSTer/sim/build/mame-p6-checkpoint-strkforc-f7199-safe-r1}"
    GFX="${SF_GFX_HEX:-/d/deck/fpga/smash tv/Arcade-SmashTV_MiSTer/sim/build/dense-p6-assets/strkforc/strkforc.gfx.hex}"
    NV="${SCENE_NV:-591}"
    ;;
  t2)
    CHECKPOINT="${T2_CHECKPOINT:-/d/deck/fpga/smash tv/Arcade-SmashTV_MiSTer/sim/build/mame-p6-checkpoint-term2-gameplay-f8999-r1}"
    GFX="${T2_GFX_HEX:-/d/deck/fpga/smash tv/Arcade-SmashTV_MiSTer/sim/build/dense-p6-assets/term2/term2.gfx.hex}"
    NV="${SCENE_NV:-1181}"
    ;;
  *) echo "unsupported scene: $SCENE" >&2; exit 64 ;;
esac
OUT="${SF_PROTECT_OUT:-$ROOT/sim/build/${SCENE}_background_protect}"
VVP="$OUT/tb_yunit_sf_background_protect.vvp"
LOG="$OUT/run.log"
PUB_DELAY="${PUB_DELAY:-0}"
SRC_CACHE="${SRC_CACHE:-0}"

EXTRA_DEFINES=()
EXTRA_SOURCES=()
if [ "$SCENE" = "t2" ]; then
  EXTRA_DEFINES+=( -DYUNIT_T2_SCENE )
fi
if [ "$SRC_CACHE" = "1" ]; then
  EXTRA_DEFINES+=( -DSF_USE_SRC_CACHE )
  EXTRA_SOURCES+=( "$ROOT/rtl/sdram/yunit_src_cache.sv" )
elif [ "$SRC_CACHE" = "2" ]; then
  EXTRA_DEFINES+=( -DSF_USE_SRC_CACHE -DSF_USE_SRC_PHYSICAL )
  EXTRA_SOURCES+=( "$ROOT/rtl/sdram/yunit_src_cache.sv"
                   "$ROOT/rtl/sdram/sdram_stock.sv"
                   "$ROOT/sim/sf_src_sdram_physical.sv" )
fi

mkdir -p "$OUT"
iverilog -g2012 -DYUNIT_NO_COMMITGATE "${EXTRA_DEFINES[@]}" -s tb_yunit_sf_background_protect \
  -o "$VVP" \
  "$ROOT/rtl/pkg/yunit_pkg.sv" \
  "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" \
  "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv" \
  "$ROOT/rtl/yunit/yunit_display_address_sequencer.sv" \
  "$ROOT/rtl/yunit/family2/yunit_dma_family2.sv" \
  "${EXTRA_SOURCES[@]}" \
  "$ROOT/rtl/yunit/vram_sdram.sv" \
  "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/rtl/yunit/yunit_video.sv" \
  "$ROOT/rtl/yunit/yunit_scanline.sv" \
  "$ROOT/rtl/yunit/yunit_video_top.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_yunit_sf_background_protect.sv"

cd "$ROOT/sim"
vvp "$VVP" \
  "+VEC=$CHECKPOINT/dma.vec" "+NV=$NV" \
  "+PRE_VRAM=$CHECKPOINT/pre_vram.hex" \
  "+POST_VRAM=$CHECKPOINT/dma_expected_vram.hex" \
  "+GFX=$GFX" "+PUB_DELAY=$PUB_DELAY" | tee "$LOG"

grep -Fq "TEST_RESULT: PASS exact background scene" "$LOG"
! grep -Fq "TEST_RESULT: FAIL" "$LOG"
