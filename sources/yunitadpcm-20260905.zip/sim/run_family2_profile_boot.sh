#!/usr/bin/env bash
# Run every audited Y-unit program ROM through the production FULL hierarchy
# until its title-specific live display path is active on physical DDR3.
set -euo pipefail
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ROM_DIR="${1:?usage: $0 ROM_DIRECTORY [game ...]}"
shift
GAMES=("$@")
if [ "${#GAMES[@]}" -eq 0 ]; then
  GAMES=(trog smashtv hiimpact shimpact strkforc saurnfrnt mk term2 totcarn yunittst)
fi

BUILD="$ROOT/sim/build/family2_profile_boot"
HEXDIR="$BUILD/program"
NVRAM_DIR="${PROFILE_BOOT_NVRAM_DIR:-$ROOT/sim/build/mame_nvram_factory}"
mkdir -p "$BUILD" "$HEXDIR"
python "$ROOT/tools/make_yunit_program_hex.py" "$ROM_DIR" "$HEXDIR" "${GAMES[@]}"
if [ -z "${PROFILE_BOOT_NVRAM_DIR:-}" ]; then
  NVRAM_GAMES=()
  for game in "${GAMES[@]}"; do
    case "$game" in
      yunittst) ;;
      mk) NVRAM_GAMES+=(mkla4);;
      saurnfrnt) NVRAM_GAMES+=(strkforc);;
      *) NVRAM_GAMES+=("$game");;
    esac
  done
  [ "${#NVRAM_GAMES[@]}" -eq 0 ] || python \
    "$ROOT/tools/make_yunit_factory_nvram.py" "$ROM_DIR" "$NVRAM_DIR" \
    --mame "${PROFILE_BOOT_MAME:-C:\tools\mame\mame.exe}" \
    --games "${NVRAM_GAMES[@]}"
fi
FAST_SELFTEST_ARGS=()
if [ "${PROFILE_BOOT_EXACT_POST:-0}" != 1 ]; then
  python "$ROOT/tools/accelerate_yunit_profile_hex.py" "$HEXDIR" "${GAMES[@]}"
  FAST_SELFTEST_ARGS+=(+FAST_SELFTEST)
fi

export SV2V_EXTRA="-DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_FULL -DSIM_INIT_MEM -DPROFILE_BOOT_QUIET_SOUND"
bash "$ROOT/quartus/build_sv2v.sh"
python "$ROOT/tools/gen_vhdl_stub.py" \
  "$ROOT/rtl/sound/williams_cvsd/williams_cvsd_board.vhd" williams_cvsd_board \
  > "$BUILD/williams_cvsd_board.v"

VENDOR=("$ROOT/rtl/sound/williams_cvsd/mc6809is.v")
for file in "$ROOT"/rtl/sound/jt51/hdl/*.v; do VENDOR+=("$file"); done
for file in "$ROOT"/rtl/sound/jt6295/*.v; do VENDOR+=("$file"); done

IMAGE="$BUILD/tb_family2_profile_boot.vvp"
iverilog -g2012 -DPROFILE_BOOT_QUIET_SOUND -s tb_family2_profile_boot -o "$IMAGE" \
  "$ROOT/build_syn/smashtv_core.v" \
  "${VENDOR[@]}" \
  "$BUILD/williams_cvsd_board.v" \
  "$ROOT/sim/sdram_chip.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_family2_profile_boot.sv"

profile_for() {
  case "$1" in
    smashtv) echo 0;; trog) echo 1;; hiimpact) echo 2;; shimpact) echo 3;;
    strkforc) echo 4;; mk) echo 5;; term2) echo 6;; totcarn) echo 7;;
    yunittst) echo 8;; saurnfrnt) echo 9;;
    *) echo "unknown game $1" >&2; return 2;;
  esac
}

start_for() {
  case "$1" in strkforc|saurnfrnt|term2) echo e00c;; *) echo fffc;; esac
}

vsblnk_for() {
  case "$1" in mk) echo 0112;; strkforc|saurnfrnt|term2) echo 0113;; *) echo 0114;; esac
}

row_for() {
  case "$1" in strkforc|saurnfrnt|term2) echo 1ff;; *) echo 000;; esac
}

nvram_set_for() {
  case "$1" in
    mk) echo mkla4;;
    saurnfrnt) echo strkforc;;
    *) echo "$1";;
  esac
}

for game in "${GAMES[@]}"; do
  log="$BUILD/$game.log"
  extra_args=()
  if [ "$game" = yunittst ]; then
    extra_args+=(+PROGRAM_ONLY)
  else
    nvset="$(nvram_set_for "$game")"
    nvram_file="$NVRAM_DIR/$nvset/$nvset/nvram"
    [ -f "$nvram_file" ] || {
      echo "ERROR: missing initialized NVRAM for $game: $nvram_file" >&2
      exit 2
    }
    extra_args+=("+NVRAM=$(cygpath -m "$nvram_file")")
  fi
  echo "running: FAMILY2_PROFILE_BOOT $game"
  set +e
  (cd "$ROOT/sim" && vvp "$IMAGE" \
    "+GAME=$(profile_for "$game")" \
    "+NAME=$game" \
    "+ROM=build/family2_profile_boot/program/$game.hex" \
    "+EXPECT_START=$(start_for "$game")" \
    "+EXPECT_VSBLNK=$(vsblnk_for "$game")" \
    "+EXPECT_ROW=$(row_for "$game")" \
    "+MAXC=${PROFILE_BOOT_MAXC:-180000000}" \
    ${PROFILE_BOOT_EXTRA_ARGS:-} \
    "${FAST_SELFTEST_ARGS[@]}" \
    "${extra_args[@]}" \
    ${PROFILE_BOOT_MEMTRACE:+"+MEMTRACE"} \
    ${PROFILE_BOOT_TRACE:+"+PCTRACE"}) >"$log" 2>&1
  status=$?
  set -e
  grep -E "PASS:|FAIL:|RESULT:" "$log" || true
  if [ "$status" -ne 0 ] || grep -qE "^FAIL:|^RESULT: FAIL" "$log" || ! grep -q "PASS: FAMILY2_PROFILE_BOOT" "$log"; then
    echo "FAMILY2 PROFILE BOOT: FAIL ($game; transcript $log)" >&2
    exit 1
  fi
done

echo "FAMILY2 PROFILE BOOT: PASS (${#GAMES[@]} profiles)"
