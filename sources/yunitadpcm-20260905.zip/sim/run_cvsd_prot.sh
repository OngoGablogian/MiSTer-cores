#!/usr/bin/env bash
# run_cvsd_prot.sh -- Y-unit CVSD board protection/hidden-RAM gate.
#
# WHY GHDL AND NOT QUESTA: williams_cvsd_board.vhd is VHDL whose leaf
# instantiations (mc6809is, jt51, smashtv_snd_rom) are Verilog/SystemVerilog, so
# the usual answer is mixed-language Questa -- which is NODELOCKED and shared
# across sessions. sim/cvsd_prot_stubs.vhd supplies pure-VHDL stand-ins for
# exactly those three leaves (the CPU one is a bus transactor; the board's own
# E/Q generator still makes the write strobe), so the REAL, UNMODIFIED board
# elaborates under licence-free GHDL. Nothing in the decode, banking,
# protection window or read mux is stubbed.
#
# MUTATION CONTRACT: rebuild the board with prot_read reverted to the old
# bank-unconditional, valid-bit-only form. Cases 3/4/5 (CVSD_SMALL read in a
# non-zero bank) and 8/10 (CVSD large pre-write reads) MUST then fail. A mutation
# that cannot be observed is a false green line, not coverage.
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export PATH="/usr/bin:/mingw64/bin:$PATH"
GHDL=/d/tools/ghdl/bin/ghdl
[ -x "$GHDL" ] || { echo "ghdl not found at $GHDL"; exit 1; }

cd "$ROOT/sim"
CVSD="$ROOT/rtl/sound/williams_cvsd"
FLAGS="--std=08 -fsynopsys -frelaxed"

build_and_run() {          # $1 = board source, $2 = workdir
  rm -rf "$2"; mkdir -p "$2"
  "$GHDL" -a $FLAGS --workdir="$2" \
     "$CVSD/gen_ram.vhd" "$CVSD/hc55564.vhd" "$CVSD/pia6821.vhd" \
     cvsd_prot_stubs.vhd "$1" tb_cvsd_prot_bank.vhd >/dev/null 2>&1
  "$GHDL" -r $FLAGS --workdir="$2" tb_cvsd_prot_bank 2>&1 \
    | grep -E "ok  |FAIL|PASS|CHECKS|RESULT" || true
}

echo "== CVSD protection gate (production) =="
PROD="$(build_and_run "$CVSD/williams_cvsd_board.vhd" .ghw_prot)"
printf '%s\n' "$PROD"
printf '%s\n' "$PROD" | grep -q "PASS: tb_cvsd_prot_bank" || { echo "run_cvsd_prot: production FAILED"; exit 1; }
printf '%s\n' "$PROD" | grep -q "CHECKS=11 FAILS=0" || { echo "run_cvsd_prot: production reported failures / wrong check count"; exit 1; }

echo
echo "== MUTATION (prot_read reverted to bank-unconditional): gate MUST fail =="
MUT=.ghw_prot_mut
MUTSRC=.ghw_prot_mutsrc
rm -rf "$MUTSRC"; mkdir -p "$MUTSRC"
python - "$CVSD/williams_cvsd_board.vhd" "$MUTSRC/board_mut.vhd" <<'PY'
import sys, re
src, dst = sys.argv[1], sys.argv[2]
s = open(src, newline='').read()
# Line-ending tolerant: match the whole prot_read concurrent assignment.
pat = re.compile(r"prot_read\s*<=\s*'1'\s+when\s+prot_hit.*?else\s*'0';", re.S)
new = "prot_read <= '1' when prot_hit = '1' and prot_valid(prot_index) = '1' else '0';"
s2, n = pat.subn(new, s)
assert n == 1, "mutation anchor not found (%d matches) -- the gate would be vacuous" % n
open(dst, 'w', newline='').write(s2)
PY
MUT_OUT="$(build_and_run "$MUTSRC/board_mut.vhd" "$MUT")"
printf '%s\n' "$MUT_OUT"
if printf '%s\n' "$MUT_OUT" | grep -qE "FAILS=[1-9]"; then
  echo "run_cvsd_prot: PASS -- production green, mutant dies as required"
  exit 0
fi
echo "run_cvsd_prot: FAIL -- the mutant STILL PASSES, so this contract is not real."
exit 1
