#!/usr/bin/env bash
# GATE: does the SHIPPING Family2 configuration actually instantiate the runtime
# DPYSTRT consumer?
#
# WHY THIS GATE EXISTS
#   Measured 2026-08-16 (mame-trace/yunit_render_profile.lua, MAME 0.280):
#     smashtv  DPYSTRT written   2x in 3301 frames, ONE value  (FFFC)  -- static
#     totcarn  DPYSTRT written   4x,                ONE value  (FFFC)  -- static
#     hiimpact DPYSTRT written 2543x, TWO values (FFFC/EFFC), 2157 flips
#     strkforc DPYSTRT written 2950x, TWO values (F00C/E00C), 2947 flips
#   High Impact and Strike Force PAGE-FLIP every frame between two 256-row pages
#   of a 512-row VRAM. yunit_display_address_sequencer is the only module in the
#   tree that follows DPYSTRT at runtime, and it is instantiated inside
#   `ifdef YUNIT_FULL (yunit_top_family2.sv:388). The shipping Family2 flavour
#   does not define YUNIT_FULL -- quartus/build_hw.sh:185 whitelists exactly
#   -DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE (+ optional -DYUNIT_CVSD_BRAM_SOUND)
#   and DIES on any other token -- so the display base falls back to the
#   compile-time constant DISP_ROW0=0 (yunit_video_family2.sv:121). The core
#   cannot follow a page flip, and both titles must flash.
#
#   No simulation caught this because sim/run_family2_profile_boot.sh:41 -- the
#   most production-shaped bench in the tree -- elaborates with -DYUNIT_FULL,
#   i.e. a configuration that DOES have the sequencer and never ships.
#
# WHAT IT ASSERTS (updated after the fix landed)
#   The fix does NOT instantiate yunit_display_address_sequencer in Family2 --
#   that module also models DPYADR advance, contract validation and prefetch
#   scheduling, none of which Family2 needs. Family2 latches DPYSTRT directly
#   and applies it at the vblank edge. So this gate asserts the CAPABILITY,
#   not one particular module:
#     1. the DPYSTRT tracker is compiled into the shipping flavour
#     2. the video path receives the live base
#     3. autoerase follows the same base, not the old constant
#   plus a nonsense needle that MUST return 0, so a grep matching everything
#   cannot masquerade as a pass.
#
# POSITIVE CONTROL (mandatory -- a grep that finds nothing proves nothing)
#   The same search is run with -DYUNIT_FULL added. It MUST find the
#   instantiation there. If the control fails, the gate is broken, not the
#   design, and the result is INCONCLUSIVE rather than a pass or a fail.
set -uo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
TOP="$ROOT/rtl/yunit/family2/yunit_top_family2.sv"
IV="${IV:-iverilog}"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

command -v "$IV" >/dev/null 2>&1 || { echo "GATE_INCONCLUSIVE: no iverilog on PATH"; exit 77; }
[ -f "$TOP" ] || { echo "GATE_INCONCLUSIVE: missing $TOP"; exit 77; }

# -DSYNTHESIS is NOT optional here: quartus/build_sv2v.sh:66 passes it on every
# production conversion, and yunit_mem_family2.sv:33,52 turns it into
# USE_SDRAM_VRAM -> YM_VRAM_HW, which is what selects the stv_vram_ddr_top branch
# holding the LIVE erase_en binding. Preprocessing without it resolves a
# configuration that never ships -- the same "bench tests a core that does not
# exist" failure this gate was written to catch, one level down.
SHIP_DEFS=(-DSYNTHESIS -DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_CVSD_BRAM_SOUND)
"$IV" -E -g2012 "${SHIP_DEFS[@]}" -o "$WORK/ship.v" "$TOP" 2>"$WORK/ship.err"
[ -s "$WORK/ship.v" ] || { echo "GATE_INCONCLUSIVE: preprocess produced nothing"; sed -n '1,5p' "$WORK/ship.err"; exit 77; }

n_of () { grep -cE "$1" "$WORK/ship.v" 2>/dev/null | tr -d ' '; }

# The autoerase toggle is NOT decided in the top. Under -DUSE_DDR3_VRAM the bulk
# erase_start sweep is tied OFF (stv_vram_ddr_top.sv:165) and a beam-locked C
# engine erases instead, enabled by erase_en in yunit_mem_family2.sv. A gate that
# preprocessed only the top matched `.erase_start(... && !autoerase_off)`, passed,
# and shipped a toggle that did NOTHING on the cabinet. So resolve the ifdefs in
# the files that hold the LIVE binding, and assert there.
MEM="$ROOT/rtl/yunit/family2/yunit_mem_family2.sv"
DDR="$ROOT/rtl/sdram/stv_vram_ddr_top.sv"
for f in "$MEM" "$DDR"; do
  [ -f "$f" ] || { echo "GATE_INCONCLUSIVE: missing $f"; exit 77; }
done
"$IV" -E -g2012 "${SHIP_DEFS[@]}" -o "$WORK/mem.v" "$MEM" 2>/dev/null
"$IV" -E -g2012 "${SHIP_DEFS[@]}" -o "$WORK/ddr.v" "$DDR" 2>/dev/null
[ -s "$WORK/mem.v" ] || { echo "GATE_INCONCLUSIVE: mem preprocess produced nothing"; exit 77; }
[ -s "$WORK/ddr.v" ] || { echo "GATE_INCONCLUSIVE: ddr preprocess produced nothing"; exit 77; }
n_mem () { grep -cE "$1" "$WORK/mem.v" 2>/dev/null | tr -d ' '; }
n_ddr () { grep -cE "$1" "$WORK/ddr.v" 2>/dev/null | tr -d ' '; }

# The dpystrt_we assignment wraps across two lines, so match the single-line
# row extraction plus the register-index reference separately.
# The row must be the COMPLEMENT of the raw field: gospel XORs DPYADR with
# 0xfffc before shifting whenever DPYCTL bit 10 is clear (tms34010.cpp:1150-1152),
# and it is clear on this family -- Smash writes DPYCTL=F010 (MAIN.ASM:502-532).
# N_RAWROW guards the regression: the un-complemented form must NOT come back.
N_TRACK=$(n_of 'dpystrt_row_w[[:space:]]*=[[:space:]]*~tms_display_wr_data\[12:4\]')
N_RAWROW=$(n_of 'dpystrt_row_w[[:space:]]*=[[:space:]]*tms_display_wr_data\[12:4\]')
N_IDX=$(n_of 'IO_IDX_DPYSTRT')
# b3cdae0 moved the video path off disp_row_dyn: it latches disp_row_next on the
# same vblank edge its prefetcher uses. This gate checked the OLD binding and so
# read 0 from then on -- stale, not failing. Check the binding that ships.
N_VID=$(n_of '\.disp_row_next\(disp_row_next\)')
N_ERASE=$(n_of '\.erase_row0\(disp_row_dyn\)')
N_OLDERASE=$(n_of "\.erase_row0\(9'\(DISP_ROW0\)\)")
# The runtime autoerase kill must be present AND gated the right way round: with
# the OSD bit at its 0 default the expression must reduce to the shipping
# `vblank_irq`. N_AE_UNGATED catches the toggle silently vanishing; the polarity
# is `&& !autoerase_off`, so an inverted edit fails N_AE_TOGGLE instead.
N_AE_TOGGLE=$(n_of '\.erase_start\(vblank_irq[[:space:]]*&&[[:space:]]*!autoerase_off\)')
N_AE_UNGATED=$(n_of '\.erase_start\(vblank_irq\)')
# THE LOAD-BEARING CHECKS: the toggle must reach the engine that actually erases.
# 2026-08-18: the raw-space guard (the SF/Saurian phantom-erase fix) added a
# third term to the non-FULL binding: `autoerase && !autoerase_off &&
# erase_frame_raw_ok`. The OSD toggle MUST still be present -- the pattern
# requires !autoerase_off explicitly; the added frame guard is accepted (and
# only that exact term, so an arbitrary weakening still fails).
N_LIVE_GATED=$(n_mem '\.erase_en\(autoerase[[:space:]]*&&[[:space:]]*!autoerase_off([[:space:]]*&&[[:space:]]*erase_frame_raw_ok)?\)')
N_LIVE_UNGATED=$(n_mem '\.erase_en\(autoerase\)')
# Confirms the premise of the two checks above: the bulk sweep really is tied off
# on this build, so erase_en is the live enable. If someone revives the bulk path
# this count drops and the assumption behind this gate must be re-read.
N_BULK_TIED=$(n_ddr "\.erase_start\(1'b0\)")
N_BOGUS=$(n_of 'yunit_this_identifier_does_not_exist_anywhere')
N_BOGUS_MEM=$(n_mem 'yunit_this_identifier_does_not_exist_anywhere')

echo "shipping Family2 (${SHIP_DEFS[*]}):"
echo "  DPYSTRT row extraction   : $N_TRACK"
echo "  RAW (uncomplemented) row : $N_RAWROW  (must be 0)"
echo "  IO_IDX_DPYSTRT referenced: $N_IDX"
echo "  live base -> video       : $N_VID"
echo "  live base -> autoerase   : $N_ERASE"
echo "  OLD constant autoerase   : $N_OLDERASE  (must be 0)"
echo "  runtime toggle (bulk)    : $N_AE_TOGGLE"
echo "  UNGATED erase_start      : $N_AE_UNGATED  (must be 0)"
echo "  LIVE erase_en GATED      : $N_LIVE_GATED  (the one that matters)"
echo "  LIVE erase_en UNGATED    : $N_LIVE_UNGATED  (must be 0)"
echo "  bulk sweep tied off      : $N_BULK_TIED  (premise: >=1)"
echo "  nonsense control         : $N_BOGUS / $N_BOGUS_MEM  (both must be 0)"

if [ "$N_BOGUS" -ne 0 ] || [ "$N_BOGUS_MEM" -ne 0 ]; then
  echo "GATE_INCONCLUSIVE: a nonsense needle matched -- the search is broken."
  exit 77
fi
if [ "$N_BULK_TIED" -lt 1 ]; then
  echo "GATE_INCONCLUSIVE: the bulk erase sweep is no longer tied off in stv_vram_ddr_top."
  echo "  This gate assumes erase_en is the LIVE enable. Re-read that assumption before trusting it."
  exit 77
fi

RC=0
[ "$N_TRACK"    -ge 1 ] || { echo "GATE_FAIL: no complemented DPYSTRT row extraction in the shipping flavour"; RC=1; }
[ "$N_RAWROW"   -eq 0 ] || { echo "GATE_FAIL: row taken RAW -- gospel complements it (tms34010.cpp:1150-1152); strkforc is wrong every frame and term2 cannot be right on more than one of its three bases"; RC=1; }
[ "$N_IDX"      -ge 1 ] || { echo "GATE_FAIL: DPYSTRT register index never referenced"; RC=1; }
[ "$N_VID"      -ge 1 ] || { echo "GATE_FAIL: the video path does not receive the live base"; RC=1; }
[ "$N_ERASE"    -ge 1 ] || { echo "GATE_FAIL: autoerase does not follow the live base (midyunit_v.cpp:554 erases rowaddr-1)"; RC=1; }
[ "$N_OLDERASE" -eq 0 ] || { echo "GATE_FAIL: autoerase still pinned to the compile-time constant"; RC=1; }
[ "$N_AE_TOGGLE"  -ge 1 ] || { echo "GATE_FAIL: the runtime autoerase toggle is missing from the shipping flavour -- the cabinet A/B cannot be run"; RC=1; }
[ "$N_AE_UNGATED" -eq 0 ] || { echo "GATE_FAIL: erase_start is bound UNGATED; the OSD toggle would do nothing"; RC=1; }
[ "$N_LIVE_GATED"   -ge 1 ] || { echo "GATE_FAIL: the OSD toggle does NOT reach erase_en -- the LIVE beam-locked engine ignores it. This is the exact defect that shipped in YUnitAutoerase_20260816 and measured as 'no difference' on the cabinet."; RC=1; }
[ "$N_LIVE_UNGATED" -eq 0 ] || { echo "GATE_FAIL: erase_en is bound UNGATED (.erase_en(autoerase)); autoerase cannot be killed at runtime"; RC=1; }

if [ "$RC" -eq 0 ]; then
  echo "GATE_PASS: shipping Family2 has a runtime display base (tracker + video + autoerase)."
fi
exit $RC
