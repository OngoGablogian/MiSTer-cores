#!/usr/bin/env bash
# CVSD (HC55564) decay + reset gate, with its mutation contract.
#
# The DUT and bench are both VHDL, so this small gate runs under license-free
# GHDL. It exercises the exact production entity without occupying or waiting
# for the shared mixed-language simulator.
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export PATH="/usr/bin:/mingw64/bin:$PATH"
GHDL=/d/tools/ghdl/bin/ghdl
[ -x "$GHDL" ] || { echo "ghdl not found at $GHDL"; exit 1; }

cd "$ROOT/sim"
FLAGS="--std=08 -fsynopsys -frelaxed"

# $1 = workdir, remaining args = testbench generic overrides.
build_and_run() {
  local work="$1"; shift
  rm -rf "$work"; mkdir -p "$work"
  "$GHDL" -a $FLAGS --workdir="$work" \
    "$ROOT/rtl/sound/williams_cvsd/hc55564.vhd" \
    "$ROOT/sim/tb_hc55564.vhd" >/dev/null
  "$GHDL" -r $FLAGS --workdir="$work" tb_hc55564 "$@" 2>&1
}

echo "== CVSD decay/reset gate (production) =="
PROD_OUT="$(build_and_run .ghw_hc55564_prod)"
printf '%s\n' "$PROD_OUT" | grep -iE "PASS|FAIL|RESULT" || true
if ! printf '%s\n' "$PROD_OUT" | grep -qE "PASS"; then
  echo "run_cvsd: production FAILED"; exit 1
fi
if printf '%s\n' "$PROD_OUT" | grep -qE "FAIL|RESULT:.*FAIL"; then
  echo "run_cvsd: production reported failures"; exit 1
fi

echo "== CVSD MUTATION (256/256 decay, reset ignored): gate MUST fail =="
MUT_OUT="$(build_and_run .ghw_hc55564_mut -gH_NUM=256 -gB_NUM=256 -gHONOR_RST=false)"
printf '%s\n' "$MUT_OUT" | grep -iE "PASS|FAIL|RESULT" || true
if printf '%s\n' "$MUT_OUT" | grep -qE "FAIL|RESULT: [1-9]"; then
  echo "run_cvsd: PASS -- production green, mutant dies as required"
  exit 0
fi
echo "run_cvsd: FAIL -- the mutant STILL PASSES, so this contract is not real."
exit 1
