#!/usr/bin/env bash
# Compile-and-elaborate the synthesizable design (run 0). Proves every port and
# width binds. Not a functional run.
#
#   ./elab_top.sh sdram             core top, family hierarchy, SDRAM framebuffer   (Questa)
#   ./elab_top.sh ddr3              core top, family hierarchy, DDR3 framebuffer    (Questa)
#   ./elab_top.sh recovery-icarus   COMPLETE emu top, YUNIT_SMASH_RECOVERY          (Icarus)
#   ./elab_top.sh recovery          recovery CORE top + real VHDL CVSD              (Questa)
#
# THE TWO RECOVERY LEGS ARE COMPLEMENTARY, NOT REDUNDANT. RUN BOTH.
# -----------------------------------------------------------------
# The Smash recovery candidate's risk is concentrated at the emu<->core seam: the
# `CORE_TOP` selector macro, the recovery-only parameter overrides, and the two new
# emu-level helpers (smashtv_legacy_download_mapper, smashtv_cabinet_inputs). A
# core-only compile cannot see any of that, so it would pass while Quartus failed --
# and a wasted Quartus map/fit attempt is the most expensive mistake available in
# this project. But Questa structurally cannot elaborate the emu top here, so the
# emu-level proof and the mixed-language proof are split by tool capability:
#
#   recovery-icarus  THE emu-LEVEL PROOF. Licence-free, seconds, runs anywhere.
#                    Elaborates the whole `emu` wrapper against
#                    build_syn/smashtv_core.v -- the EXACT Verilog Quartus is handed
#                    -- with the real sys/ framework chain, then asserts the
#                    ELABORATED hierarchy with tools/check_elab_hierarchy.py: the
#                    fail-closed proof that the recovery top was selected and that
#                    no family block is reachable. Icarus cannot read VHDL, so the
#                    CVSD board is replaced by a stub GENERATED FROM ITS OWN VHDL
#                    ENTITY -- a renamed or resized port therefore still fails to bind.
#
#   recovery         THE MIXED-LANGUAGE PROOF. Questa, needs the shared nodelocked
#                    licence. Elaborates yunit_top_smash_firefix from the RAW
#                    recovery SystemVerilog (not the translated blob) against the
#                    REAL VHDL Williams CVSD board. Two things Icarus cannot do:
#                    bind VHDL, and read the recovery sources as SystemVerilog
#                    before sv2v rewrites them.
#
# WHY QUESTA DOES NOT ELABORATE `emu` (measured, do not re-derive)
# ---------------------------------------------------------------
# Questa rejects unchanged MiSTer framework source outright with vlog-2730
# ("Undefined variable"), which is NOT suppressible:
#   * sys/hps_io.sv references the generate-scoped {kbd_rd, kbd_we, mouse_rd,
#     mouse_we} unconditionally from an always block, so with PS2DIV=0 those names
#     are never declared;
#   * sys/video_mixer.sv assigns from {R_in, G_in, B_in} in the non-GAMMA generate
#     branch, where they likewise have no declaration.
# Quartus and Icarus both create implicit nets and compile it; Questa will not.
# Translating sys/ through sv2v does not help -- sv2v faithfully preserves the
# missing declarations. Fixing it means patching vendor framework files that the
# real build compiles cleanly, so the emu-level proof is Icarus's job instead. The
# framework video/HPS chain is unchanged from the cabinet-good design anyway.
#
# Both recovery legs stub exactly one leaf: `pll_0002`, the wrapper around the
# altera_pll primitive. The REAL rtl/pll.v is compiled, so the emu<->pll seam is
# still proven; only the vendor primitive (which Quartus supplies natively) is
# replaced, and the stub's port list is taken from the vendor file's own header.
set -euo pipefail
# Codex/PowerShell may launch Git Bash without its own POSIX directories in PATH.
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"; SND="$ROOT/rtl/sound"
MODE="${1:-sdram}"
PYTHON="${PYTHON:-python}"

case "$MODE" in
  sdram|ddr3|recovery|recovery-icarus|family2-icarus|full-icarus|adpcm-icarus|cvsdseq-icarus) ;;
  *) echo "usage: $0 [sdram|ddr3|recovery|recovery-icarus|family2-icarus|full-icarus|adpcm-icarus]"; exit 2 ;;
esac

find_questa() {
  for d in /c/altera/*/questa_fse/win64 /c/altera_pro/*/questa_fse/win64; do
    [ -x "$d/vlog.exe" ] && { VLOG="$d/vlog"; VCOM="$d/vcom"; VSIM="$d/vsim"; VLIB="$d/vlib"; return 0; }
  done
  return 1
}

build_family_src() {
  # SystemVerilog: CPU core (pkg first) + yunit + sdram + video + jt51 + 6809/snd_rom.
  # Shared by the family core-top modes and by the recovery Questa leg, which needs
  # the same packages, TMS core, and sound vendor files under the recovery top.
  SRC=( "$CORE/rtl/tms34010_pkg.sv" )
  while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
  SRC+=( "$ROOT/rtl/pkg/yunit_pkg.sv"
         "$ROOT/rtl/yunit/yunit_protection.sv"
         "$ROOT/rtl/yunit/yunit_nvram_bridge.sv"
         "$ROOT/rtl/yunit/yunit_mem.sv" "$ROOT/rtl/yunit/yunit_dma.sv"
         "$ROOT/rtl/yunit/yunit_dma_logical_timer.sv"
         "$ROOT/rtl/yunit/yunit_dma_descriptor_fifo.sv"
         "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv"
         "$ROOT/rtl/yunit/vram_sdram_scanout.sv"
         "$ROOT/rtl/yunit/yunit_memsys.sv"
         "$ROOT/rtl/yunit/yunit_display_address_sequencer.sv"
         "$ROOT/rtl/yunit/yunit_autoerase_scheduler.sv"
         "$ROOT/rtl/yunit/yunit_autoerase_sdram_backend.sv"
         "$ROOT/rtl/yunit/yunit_shiftreg_engine.sv"
         "$ROOT/rtl/yunit/yunit_vram_word_arb.sv"
         "$ROOT/rtl/yunit/yunit_video.sv" "$ROOT/rtl/yunit/yunit_scanline.sv"
         "$ROOT/rtl/yunit/yunit_video_top.sv" "$ROOT/rtl/yunit/yunit_palram.sv"
         "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv"
         "$ROOT/rtl/sdram/yunit_sdram_arb.sv"
         "$ROOT/rtl/sdram/yunit_sdram_burst_arb.sv"
         "$ROOT/rtl/sdram/sdram_stock.sv"
         "$ROOT/rtl/sdram/yunit_sdram_adapter.sv"
         "$ROOT/rtl/sdram/yunit_src_cache.sv"
         "$ROOT/rtl/yunit/yunit_gfx_unpack.sv"
         "$ROOT/rtl/yunit/yunit_download_mapper.sv"
         "$ROOT/rtl/video/crt_adjust.sv"
         "$ROOT/rtl/video/yunit_crt_adjust.sv" )
  while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$SND/jt51/hdl" -maxdepth 1 -name '*.v' | sort)
  while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$SND/jt6295" -maxdepth 1 -name '*.v' | sort)
  SRC+=( "$SND/williams_cvsd/mc6809is.v" "$SND/smashtv_snd_rom.sv"
         "$ROOT/rtl/yunit/yunit_mem_cdc.sv"
         "$ROOT/rtl/yunit/yunit_sound_cdc.sv"
         "$ROOT/rtl/yunit/yunit_sound_rom_cache.sv"
         "$ROOT/rtl/yunit/yunit_service_counters.sv"
         "$ROOT/rtl/diag/yunit_diag_service_overlay.sv"
         "$ROOT/rtl/yunit/yunit_audio_mix.sv"
         "$ROOT/rtl/yunit/yunit_adpcm_board.sv"
         "$ROOT/rtl/yunit/yunit_cpu_cadence.sv"
         "$ROOT/rtl/yunit/yunit_top.sv" )
}

################################################################################
# Recovery: the isolated cabinet-good Smash datapath.
################################################################################
if [ "$MODE" = "recovery" ] || [ "$MODE" = "recovery-icarus" ] || [ "$MODE" = "family2-icarus" ] || [ "$MODE" = "full-icarus" ] || [ "$MODE" = "adpcm-icarus" ] || [ "$MODE" = "cvsdseq-icarus" ]; then
  GEN="$ROOT/sim/build/elab_recovery"
  LOGDIR="$ROOT/sim/build"
  mkdir -p "$GEN" "$LOGDIR"

  # Recovery source list, in dependency order, matching quartus/build_sv2v.sh.
  RECOVERY_SV=( "$ROOT/rtl/yunit/smashtv_cabinet_inputs.sv" \
                "$ROOT/rtl/yunit/smashtv_legacy_download_mapper.sv" \
                "$ROOT/rtl/yunit/yunit_mem_smash_firefix.sv" \
                "$ROOT/rtl/yunit/yunit_dma_smash_firefix.sv" \
                "$ROOT/rtl/yunit/yunit_memsys_smash_firefix.sv" \
                "$ROOT/rtl/yunit/yunit_video_smash_firefix.sv" \
                "$ROOT/rtl/yunit/yunit_scanline_smash_firefix.sv" \
                "$ROOT/rtl/yunit/yunit_video_top_smash_firefix.sv" \
                "$ROOT/rtl/yunit/yunit_top_smash_firefix.sv" )

  VENDOR_V=( "$SND/williams_cvsd/mc6809is.v" )
  while IFS= read -r f; do VENDOR_V+=( "$f" ); done < <(find "$SND/jt51/hdl" -maxdepth 1 -name '*.v' | sort)
  while IFS= read -r f; do VENDOR_V+=( "$f" ); done < <(find "$SND/jt6295" -maxdepth 1 -name '*.v' | sort)

  # Every module the recovery image must contain, and every family block it must not.
  REQUIRE=( yunit_top_smash_firefix yunit_memsys_smash_firefix yunit_mem_smash_firefix \
            yunit_dma_smash_firefix yunit_video_top_smash_firefix \
            yunit_scanline_smash_firefix yunit_video_smash_firefix \
            smashtv_legacy_download_mapper smashtv_cabinet_inputs \
            stv_vram_ddr_top stv_vram_ddr_agent williams_cvsd_board \
            tms34010_core yunit_crt_adjust )
  FORBID=( yunit_top yunit_memsys yunit_mem yunit_dma yunit_video yunit_video_top \
           yunit_scanline yunit_dma_logical_timer yunit_dma_descriptor_fifo \
           yunit_display_address_sequencer yunit_shiftreg_engine \
           yunit_autoerase_scheduler yunit_autoerase_sdram_backend \
           yunit_vram_word_arb yunit_download_mapper yunit_input_mapper \
           yunit_adpcm_board smashtv_diag_top smashtv_diag_rom )

  # family2 (PLAN-family2-rebase.md): the rebased family hierarchy. Its gate
  # forbids BOTH the old scheduler-based family blocks AND the frozen recovery
  # modules -- selecting either from a family2 build is a defect.
  # YUNIT_FULL: the single all-titles core. Same rebased family2 hierarchy,
  # 8 MB graphics region, and BOTH sound boards -- the Y-unit family genuinely
  # shipped two, and one core serving every title must carry both. That became
  # affordable only once CVSD sound moved to SDRAM: the three 64 KiB sample
  # BRAMs measured 192 of 553 device M10Ks, while the ADPCM board's second
  # YM2151 costs ~9 because its samples already stream from SDRAM.
  if [ "$MODE" = "adpcm-icarus" ]; then
    # ADPCM sibling: MK / T2 / Total Carnage. Same family2 datapath and 8 MB map as FULL
    # (YUNIT_ADPCM defines YUNIT_FULL in the emu), but the CVSD board must be PROVABLY ABSENT
    # -- that absence is the whole point of the split, and a name-based FORBID is the only
    # thing that catches a half-plumbed define that quietly kept it.
    MACRO_DEFINE=YUNIT_ADPCM
    TOP_RTL="$ROOT/rtl/yunit/family2/yunit_top_family2.sv"
    FORBID=( $(printf '%s\n' "${FORBID[@]}" | grep -vE '^(yunit_adpcm_board|yunit_video|yunit_video_top|yunit_scanline|yunit_display_address_sequencer)$') )
    REQUIRE=( yunit_top_family2 yunit_memsys_family2 yunit_mem_family2
              yunit_dma_family2 yunit_video_top yunit_scanline yunit_video
              yunit_display_address_sequencer
              family2_download_mapper family2_cabinet_inputs
              stv_vram_ddr_top stv_vram_ddr_agent
              yunit_adpcm_board jt6295 mc6809is
              tms34010_core yunit_crt_adjust )
    FORBID+=( williams_cvsd_board yunit_audio_mix smashtv_snd_rom )
    FORBID+=( yunit_top_smash_firefix yunit_memsys_smash_firefix yunit_mem_smash_firefix
              yunit_dma_smash_firefix yunit_video_top_smash_firefix
              yunit_scanline_smash_firefix yunit_video_smash_firefix
              smashtv_legacy_download_mapper smashtv_cabinet_inputs )
    FORBID+=( yunit_video_top_family2 yunit_scanline_family2 yunit_video_family2
              yunit_shiftreg_engine yunit_shiftreg_command_bridge
              yunit_vram_word_arb )
  elif [ "$MODE" = "full-icarus" ]; then
    MACRO_DEFINE=YUNIT_FULL
    TOP_RTL="$ROOT/rtl/yunit/family2/yunit_top_family2.sv"
    # The shared base list forbids the ADPCM board (it is a defect in every
    # OTHER flavour). This is the one build where it is mandatory.
    FORBID=( $(printf '%s
' "${FORBID[@]}" | grep -vE '^(yunit_adpcm_board|yunit_video|yunit_video_top|yunit_scanline|yunit_display_address_sequencer)$') )
    REQUIRE=( yunit_top_family2 yunit_memsys_family2 yunit_mem_family2
              yunit_dma_family2 yunit_video_top yunit_scanline yunit_video
              yunit_display_address_sequencer
              family2_download_mapper family2_cabinet_inputs
              stv_vram_ddr_top stv_vram_ddr_agent
              yunit_adpcm_board jt6295 mc6809is williams_cvsd_board
              tms34010_core yunit_crt_adjust )
    FORBID+=( yunit_top_smash_firefix yunit_memsys_smash_firefix               yunit_mem_smash_firefix yunit_dma_smash_firefix               yunit_video_top_smash_firefix yunit_scanline_smash_firefix               yunit_video_smash_firefix smashtv_legacy_download_mapper               smashtv_cabinet_inputs )
    FORBID+=( yunit_video_top_family2 yunit_scanline_family2 yunit_video_family2
              yunit_shiftreg_engine yunit_shiftreg_command_bridge
              yunit_vram_word_arb )
  elif [ "$MODE" = "cvsdseq-icarus" ]; then
    # YUNIT_DISPLAY_SEQ: the FULL display sequencer + yunit_video_top scanout
    # (SF/Saurian column fix) WITHOUT the ADPCM sound board (M10K economy for a
    # CVSD core). = full-icarus's video expectations, but the ADPCM board is
    # FORBIDDEN, not required, and the CVSD board is required.
    MACRO_DEFINE=YUNIT_FAMILY2
    TOP_RTL="$ROOT/rtl/yunit/family2/yunit_top_family2.sv"
    FORBID=( $(printf '%s\n' "${FORBID[@]}" | grep -vE '^(yunit_video|yunit_video_top|yunit_scanline|yunit_display_address_sequencer)$') )
    REQUIRE=( yunit_top_family2 yunit_memsys_family2 yunit_mem_family2
              yunit_dma_family2 yunit_video_top yunit_scanline yunit_video
              yunit_display_address_sequencer
              family2_download_mapper family2_cabinet_inputs
              stv_vram_ddr_top stv_vram_ddr_agent
              williams_cvsd_board
              tms34010_core yunit_crt_adjust )
    FORBID+=( yunit_adpcm_board jt6295 )
    FORBID+=( yunit_top_smash_firefix yunit_memsys_smash_firefix yunit_mem_smash_firefix
              yunit_dma_smash_firefix yunit_video_top_smash_firefix
              yunit_scanline_smash_firefix yunit_video_smash_firefix
              smashtv_legacy_download_mapper smashtv_cabinet_inputs )
    FORBID+=( yunit_video_top_family2 yunit_scanline_family2 yunit_video_family2
              yunit_shiftreg_engine yunit_shiftreg_command_bridge
              yunit_vram_word_arb )
  elif [ "$MODE" = "family2-icarus" ]; then
    MACRO_DEFINE=YUNIT_FAMILY2
    TOP_RTL="$ROOT/rtl/yunit/family2/yunit_top_family2.sv"
    REQUIRE=( yunit_top_family2 yunit_memsys_family2 yunit_mem_family2 \
              yunit_dma_family2 yunit_video_top_family2 \
              yunit_scanline_family2 yunit_video_family2 \
              family2_download_mapper family2_cabinet_inputs \
              stv_vram_ddr_top stv_vram_ddr_agent williams_cvsd_board \
              tms34010_core yunit_crt_adjust )
    FORBID+=( yunit_top_smash_firefix yunit_memsys_smash_firefix \
              yunit_mem_smash_firefix yunit_dma_smash_firefix \
              yunit_video_top_smash_firefix yunit_scanline_smash_firefix \
              yunit_video_smash_firefix smashtv_legacy_download_mapper \
              smashtv_cabinet_inputs )
  else
    MACRO_DEFINE=YUNIT_SMASH_RECOVERY
    TOP_RTL="$ROOT/rtl/yunit/yunit_top_smash_firefix.sv"
  fi

  # The exact Strike Force SRT-fill candidate deliberately instantiates the
  # command bridge.  In every shipping/default flavour it remains forbidden,
  # so a stray bridge still fails closed; only the explicit sv2v feature token
  # turns its presence into a required hierarchy witness.
  # In a direct elaboration ELAB_EXTRA_DEFINES is folded into SV2V_EXTRA only
  # after this mode-specific hierarchy list is assembled.  Inspect both inputs
  # here so the exact SRT feature cannot be translated successfully yet remain
  # mislabeled as forbidden by the hierarchy gate.
  if [[ " ${SV2V_EXTRA:-} ${ELAB_EXTRA_DEFINES:-} " == *" -DYUNIT_SRT_FILL_BURST "* ]]; then
    FORBID=( $(printf '%s\n' "${FORBID[@]}" \
      | grep -vE '^yunit_shiftreg_command_bridge$') )
    REQUIRE+=( yunit_shiftreg_command_bridge )
  fi
fi

if [ "$MODE" = "recovery-icarus" ] || [ "$MODE" = "family2-icarus" ] || [ "$MODE" = "full-icarus" ] || [ "$MODE" = "adpcm-icarus" ] || [ "$MODE" = "cvsdseq-icarus" ]; then
  command -v iverilog >/dev/null 2>&1 || { echo "iverilog not found"; exit 1; }
  SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
  BLOB="$ROOT/build_syn/smashtv_core.v"

  # Exact production translation flavour. Regenerated every run: elaborating a
  # stale netlist proves nothing about the build that is about to be requested.
  #
  # ELAB_SKIP_SV2V=1 is for ONE caller: quartus/build_hw.sh, which has already run
  # the translation and recorded the netlist's hash in the run manifest. Letting
  # this leg regenerate it there would overwrite a recorded build artifact. The
  # blob must already exist -- skipping is never allowed to mean "elaborate
  # whatever happens to be lying around".
  if [ "${ELAB_SKIP_SV2V:-0}" = 1 ]; then
    [ -s "$BLOB" ] \
      || { echo "ELAB_SKIP_SV2V=1 but $BLOB is missing or empty" >&2; exit 1; }
    [ "$BLOB" -nt "$TOP_RTL" ] \
      || { echo "ELAB_SKIP_SV2V=1 but $BLOB is older than the selected top RTL" >&2; exit 1; }
    echo "=== reusing caller's translation ($(wc -l < "$BLOB") lines) ==="
  else
    # The flavour macro must reach sv2v, not just the Quartus-native emu:
    # yunit_top_family2.sv selects its sound board with `ifdef YUNIT_FULL,
    # and sv2v never saw it, so the ADPCM build silently elaborated the CVSD
    # board. Only YUNIT_FULL is referenced inside sv2v'd rtl/, so the proven
    # recovery/family2 translations stay byte-identical.
    export SV2V_EXTRA="-DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE"
    if [ "$MODE" = "full-icarus" ]; then
      export SV2V_EXTRA="$SV2V_EXTRA -DYUNIT_FULL"
    fi
    if [ "$MODE" = "adpcm-icarus" ]; then
      # BOTH tokens. The emu's `ifdef YUNIT_ADPCM -> `define YUNIT_FULL does NOT reach the
      # sv2v'd core (separate compilation unit), so without -DYUNIT_FULL the core silently
      # builds the FAMILY2 4 MB video path while the emu believes it is FULL.
      export SV2V_EXTRA="$SV2V_EXTRA -DYUNIT_ADPCM -DYUNIT_FULL"
    fi
    # Same reason, for diagnostic flavours: ELAB_EXTRA_DEFINES has to reach BOTH legs.
    # The emu is compiled from raw SV (so -D on the iverilog line is enough), but the core
    # arrives as a pre-translated blob, so a define that never reaches sv2v produces exactly
    # the silent half-build described above -- an overlay painting zeros from counters that
    # were compiled out.
    if [ -n "${ELAB_EXTRA_DEFINES:-}" ]; then
      export SV2V_EXTRA="$SV2V_EXTRA ${ELAB_EXTRA_DEFINES}"
    fi
    echo "=== exact recovery translation (SV2V_EXTRA=$SV2V_EXTRA) ==="
    bash "$ROOT/quartus/build_sv2v.sh"
  fi

  # --- derived elaboration sources. All are generated, never checked in, so none
  # --- of them can drift away from the source it stands in for.
  # sync_fix lives inside sys/sys_top.v, which also instantiates emu and every
  # piece of Altera board IP, so the module cannot simply be compiled out of it.
  # Extract it verbatim.
  awk '/^module sync_fix/{f=1} f{print} /^endmodule/{if(f) exit}' \
    "$ROOT/sys/sys_top.v" > "$GEN/sync_fix.v"
  grep -q "^module sync_fix" "$GEN/sync_fix.v" \
    || { echo "could not extract sync_fix from sys/sys_top.v" >&2; exit 1; }

  # pll_0002 leaf: keep the vendor port header, drop the altera_pll body.
  {
    echo "// GENERATED from rtl/pll/pll_0002.v by sim/elab_top.sh -- do not edit."
    sed -n '/^module  *pll_0002(/,/^);/p' "$ROOT/rtl/pll/pll_0002.v"
    echo "  assign outclk_0 = refclk;"
    echo "  assign outclk_1 = refclk;"
    echo "  assign outclk_2 = refclk;"
    echo "  assign outclk_3 = refclk;"
    echo "  assign locked   = ~rst;"
    echo "endmodule"
  } > "$GEN/pll_0002.v"
  grep -q "^);" "$GEN/pll_0002.v" \
    || { echo "could not extract the pll_0002 port header" >&2; exit 1; }

  # The MiSTer framework modules `emu` instantiates, plus their children. These go
  # through the SAME sv2v as the core blob because two of them size a port from a
  # localparam declared AFTER the port list, which Icarus rejects. They are still
  # the REAL framework modules -- stubbing the video chain would delete the
  # emu<->video seam this mode exists to check.
  SYS_SV=( "$ROOT/sys/hps_io.sv" "$ROOT/sys/arcade_video.v" \
           "$ROOT/sys/video_mixer.sv" "$ROOT/sys/video_freezer.sv" \
           "$ROOT/sys/scandoubler.v" "$ROOT/sys/hq2x.sv" \
           "$ROOT/sys/gamma_corr.sv" )
  "$SV2V" -DSYNTHESIS -I "$ROOT/sys" "${SYS_SV[@]}" > "$GEN/sys_sv2v.v"
  [ "$(grep -c '^module' "$GEN/sys_sv2v.v")" -ge 17 ] \
    || { echo "sys framework translation produced too few modules" >&2; exit 1; }

  "$PYTHON" "$ROOT/tools/gen_vhdl_stub.py" \
    "$SND/williams_cvsd/williams_cvsd_board.vhd" williams_cvsd_board \
    > "$GEN/williams_cvsd_board.v"

  IMAGE="$GEN/emu_${MODE}.vvp"
  LOG="$LOGDIR/elab_${MODE}.log"
  rm -f "$IMAGE"
  echo "=== iverilog: elaborating emu ($MACRO_DEFINE) ==="
  set +e
  # ELAB_EXTRA_DEFINES lets a diagnostic flavour be elaborated by the same gate, e.g.
  #   ELAB_EXTRA_DEFINES=-DDIAG_SERVICE sim/elab_top.sh full-icarus
  # The service instrument spans the sv2v/Quartus seam, so it MUST be elaborated with the
  # define set or a half-plumbed build reaches the fitter unchecked.
  iverilog -g2012 -o "$IMAGE" -s emu \
    -DSYNTHESIS -DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -D$MACRO_DEFINE ${ELAB_EXTRA_DEFINES:-} \
    -I"$ROOT" -I"$ROOT/sys" -I"$ROOT/sim" \
    "$ROOT/Arcade-SmashTV.sv" "$BLOB" "$ROOT/rtl/pll.v" "$GEN/sys_sv2v.v" \
    "$GEN/sync_fix.v" "$GEN/pll_0002.v" "$GEN/williams_cvsd_board.v" \
    "${VENDOR_V[@]}" >"$LOG" 2>&1
  IV_STATUS=$?
  set -e
  # Icarus reports where a sys/ port is wider than this wrapper's net (the MiSTer
  # framework outgrew the wrapper's status/joystick/ioctl widths); Quartus pads
  # identically. Those lines are shown, not suppressed, but they are not errors.
  grep -viE "warning: Static variable initialization" "$LOG" | head -40 || true
  if [ "$IV_STATUS" -ne 0 ]; then
    echo "elab_top: iverilog elaboration FAILED (exit $IV_STATUS); full log at $LOG" >&2
    exit "$IV_STATUS"
  fi
  [ -s "$IMAGE" ] || { echo "elab_top: no elaboration image produced" >&2; exit 1; }

  REQ_ARGS=(); for m in "${REQUIRE[@]}"; do REQ_ARGS+=( --require "$m" ); done
  FBD_ARGS=(); for m in "${FORBID[@]}"; do FBD_ARGS+=( --forbid "$m" ); done
  "$PYTHON" "$ROOT/tools/check_elab_hierarchy.py" "$IMAGE" \
    --top emu --root-type emu "${REQ_ARGS[@]}" "${FBD_ARGS[@]}" \
    | tee "$LOGDIR/elab_${MODE}_hierarchy.log"
  echo "elab_top: $MODE done (log $LOG)"
  exit 0
fi

if [ "$MODE" = "recovery" ]; then
  find_questa || { echo "Questa not found"; exit 1; }
  unset LM_LICENSE_FILE MGLS_LICENSE_FILE
  # Cross-session Questa interlock; exit 3 = never got the licence, which is an
  # infrastructure result, NOT an RTL result. See sim/questa_lock.sh.
  . "$(cd "$(dirname "$0")" && pwd)/questa_lock.sh"
  questa_lock_acquire "yunit:elab_top:recovery" || exit 3

  cd "$ROOT/sim"
  rm -rf work_recovery; "$VLIB" work_recovery >/dev/null
  LOG="$LOGDIR/elab_recovery_questa.log"
  build_family_src

  # The RAW recovery SystemVerilog, not the translated blob: this leg is the only
  # place the recovery sources are read as SystemVerilog before sv2v rewrites them.
  # The family sources are compiled alongside (they share yunit_pkg and the TMS
  # core) but must not be ELABORATED, which the load-list assertions below enforce.
  "$VLOG" -sv -quiet -svinputport=var -suppress 2892 \
    +define+SYNTHESIS +define+USE_DDR3_VRAM +define+YUNIT_NO_COMMITGATE \
    +define+YUNIT_SMASH_RECOVERY \
    +incdir+"$ROOT" -work work_recovery \
    "${SRC[@]}" "${RECOVERY_SV[@]}"

  # The real mixed-language leg: the Williams CVSD board is VHDL.
  "$VCOM" -2008 -quiet -work work_recovery \
    "$SND/williams_cvsd/gen_ram.vhd" \
    "$SND/williams_cvsd/hc55564.vhd" \
    "$SND/williams_cvsd/pia6821.vhd" \
    "$SND/williams_cvsd/williams_cvsd_board.vhd"

  echo "=== Questa: elaborating yunit_top_smash_firefix (real VHDL CVSD) ==="
  # Ask the simulator for its own instance tree instead of scraping "Loading
  # work.<unit>" lines. Questa 2025.2 runs a vopt pass and never prints those, so an
  # assertion built on them is a guaranteed false negative regardless of what
  # elaborated -- exactly the broken-instrument failure class. `find instances`
  # answers the question directly, and its output is the record kept in the log.
  cat > "$GEN/elab_recovery.do" <<'DO'
run 0
puts "ELAB_TREE_BEGIN"
foreach inst [find instances -recursive /*] { puts "ELAB_INST $inst" }
puts "ELAB_TREE_END"
quit -f
DO
  # Keep the whole transcript: piping vsim into grep discards the evidence a
  # mid-elaboration death leaves behind AND returns grep's exit status instead of
  # vsim's, which is a fake pass.
  # -voptargs=+acc is LOAD-BEARING, not a debug nicety. Without it vopt merges away
  # every module it does not need to keep visible, and `find instances` then reports
  # a tree that is missing yunit_video_top_smash_firefix, yunit_palram,
  # yunit_sdram_arb and stv_vram_ddr_agent -- all of which are really there. An
  # absence check against an optimized tree answers "what survived optimization",
  # not "what was instantiated", so it would produce confident wrong answers in
  # both directions. +acc makes the tree complete and the gate below meaningful.
  set +e
  "$VSIM" -c -work work_recovery -voptargs="+acc" \
    -do "$GEN/elab_recovery.do" yunit_top_smash_firefix >"$LOG" 2>&1
  VSIM_STATUS=$?
  set -e
  grep -viE "^# (Loading|//|\*\* Note)" "$LOG" | grep -iE "error|warning|fatal" | head -40 || true
  if [ "$VSIM_STATUS" -ne 0 ]; then
    echo "elab_top: Questa elaboration FAILED (exit $VSIM_STATUS); full log at $LOG" >&2
    exit "$VSIM_STATUS"
  fi
  grep -Eq "^# Errors: 0," "$LOG" \
    || { echo "elab_top: Questa did not report zero errors" >&2; exit 1; }
  # Suppressed-message accounting. The vendor modelsim.ini suppresses exactly one
  # code, 8780 ("the TCL force command follows Verilog semantics of a single wire"
  # -- verror 8780), which is a machine-wide default unrelated to this design. Any
  # OTHER suppression would have to come from this script's own -suppress flags,
  # which are listed at the vlog call above. Print the count so it stays visible.
  grep -Eo "Suppressed Errors: [0-9]+" "$LOG" | tail -1 \
    | sed 's/^/elab_top: vendor-ini (vsim-8780, TCL force wire model) /' || true
  # `find instances -recursive` prints "<path> (<module type>)", so this leg gets a
  # fully independent second witness to the hierarchy: the Icarus gate reads types
  # out of the elaborated .vvp image, this one reads them out of Questa's own
  # instance tree, and the two tools consumed different source forms to get there.
  # NOTE: `puts` output has no "# " transcript prefix. Anchoring on one would make
  # every assertion below a guaranteed false negative.
  grep -q "^ELAB_TREE_BEGIN" "$LOG" \
    || { echo "elab_top: no instance tree in the transcript" >&2; exit 1; }
  TYPES="$GEN/questa_elab_types.txt"
  sed -nE 's/^ELAB_INST .* \(([A-Za-z0-9_]+)\)$/\1/p' "$LOG" | sort -u > "$TYPES"
  [ -s "$TYPES" ] \
    || { echo "elab_top: could not extract module types from the tree" >&2; exit 1; }
  grep -Eq "^ELAB_INST /yunit_top_smash_firefix/u_board " "$LOG" \
    || { echo "elab_top: VHDL CVSD board instance is absent" >&2; exit 1; }
  # A VHDL-side runtime message attributed to u_board proves the VHDL really
  # elaborated and executed, not merely that a name resolved.
  grep -Eq "Instance: /yunit_top_smash_firefix/u_board" "$LOG" \
    || echo "elab_top: NOTE - no VHDL-side runtime message from u_board this run"

  # The emu-level helpers sit above this top, so they are checked by the Icarus leg.
  MISSING=0
  for m in "${REQUIRE[@]}"; do
    case "$m" in
      smashtv_legacy_download_mapper|smashtv_cabinet_inputs|yunit_crt_adjust) continue ;;
    esac
    grep -qx "$m" "$TYPES" \
      || { echo "elab_top: REQUIRED module absent from elaboration: $m" >&2; MISSING=1; }
  done
  for m in "${FORBID[@]}"; do
    if grep -qx "$m" "$TYPES"; then
      echo "elab_top: FORBIDDEN family module elaborated: $m" >&2; MISSING=1
    fi
  done
  [ "$MISSING" -eq 0 ] || { echo "elab_top: Questa hierarchy gate FAILED" >&2; exit 1; }

  INSTS=$(grep -c "^ELAB_INST " "$LOG")
  [ "$INSTS" -ge 20 ] \
    || { echo "elab_top: instance tree is implausibly small ($INSTS)" >&2; exit 1; }
  echo "elab_top: $INSTS instances, $(wc -l < "$TYPES") distinct module types;"
  echo "          required present, $(printf '%s\n' "${FORBID[@]}" | wc -l) forbidden absent"
  echo "elab_top: recovery (Questa) done -- full transcript at $LOG"
  exit 0
fi

################################################################################
# Family core-top elaboration (unchanged): real TMS34010 core + yunit_* + SDRAM
# controller + video + palette mirror + the mixed-language Williams CVSD board.
################################################################################
DEFS=( +define+SYNTHESIS )
if [ "$MODE" = "ddr3" ]; then
  DEFS+=( +define+USE_DDR3_VRAM )
else
  # Questa preprocesses source files as separate compilation units, so the
  # SYNTHESIS fallback defined inside yunit_mem is not visible in yunit_top.
  DEFS+=( +define+USE_SDRAM_VRAM )
fi

find_questa || { echo "Questa not found"; exit 1; }
unset LM_LICENSE_FILE MGLS_LICENSE_FILE

# Cross-session Questa interlock. This was the LAST unlocked vsim invocation in the
# tree: the family qualification failed here with "Exiting VSIM license process" and
# reported it as "DDR3 top elaboration failed with exit code 1" -- an infrastructure
# collision misreported as an RTL result, which is exactly what the interlock and the
# exit-code convention exist to prevent. Exit 3 = never got the licence.
. "$(cd "$(dirname "$0")" && pwd)/questa_lock.sh"
questa_lock_acquire "yunit:elab_top:${MODE}" || exit 3

cd "$ROOT/sim"
rm -rf work_top; "$VLIB" work_top >/dev/null

build_family_src


"$VLOG" -sv -quiet -svinputport=var -suppress 2892 \
  "${DEFS[@]}" -work work_top "${SRC[@]}"

"$VCOM" -2008 -quiet -work work_top \
  "$SND/williams_cvsd/gen_ram.vhd" \
  "$SND/williams_cvsd/hc55564.vhd" \
  "$SND/williams_cvsd/pia6821.vhd" \
  "$SND/williams_cvsd/williams_cvsd_board.vhd"

echo "elaborating yunit_top ($MODE) ..."
"$VSIM" -c -quiet -work work_top -do "run 0; quit -f" yunit_top 2>&1 \
  | grep -viE "^# (Loading|//|\*\* Note)" | grep -iE "error|warning|fatal|yunit_top" | head -40
echo "elab_top done"
