#!/usr/bin/env bash
# Run a yunit_top system testbench in Questa under SYNTHESIS (real CPU + SDRAM
# controller + behavioral MT48LC16M16 + video + palette + VHDL sound board).
#   ./run_top.sh [tb_yunit_top_boot] [+PLUSARGS...]
set -e
# Codex/PowerShell may launch Git Bash without its own POSIX directories in
# PATH.  Keep the harness self-contained so dirname/find/sort/grep resolve.
export PATH="/usr/bin:/mingw64/bin:$PATH"
TB="${1:-tb_yunit_top_boot}"; shift || true
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"; SND="$ROOT/rtl/sound"

for d in /c/altera/*/questa_fse/win64 /c/altera_pro/*/questa_fse/win64; do
  [ -x "$d/vlog.exe" ] && { VLOG="$d/vlog"; VCOM="$d/vcom"; VSIM="$d/vsim"; VLIB="$d/vlib"; break; }
done
[ -n "$VLOG" ] || { echo "Questa not found"; exit 1; }
unset LM_LICENSE_FILE MGLS_LICENSE_FILE

# Cross-session Questa interlock (nodelocked to ONE vsim; sibling core sessions
# share this machine). Exit 3 = could not get the licence, which is NOT an RTL
# result. See sim/questa_lock.sh.
. "$(cd "$(dirname "$0")" && pwd)/questa_lock.sh"
questa_lock_acquire "yunit:run_top:$TB" || exit 3

cd "$ROOT/sim"
rm -rf work_top; "$VLIB" work_top >/dev/null

SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SRC+=( "$ROOT/rtl/pkg/yunit_pkg.sv"
       "$ROOT/rtl/yunit/yunit_protection.sv"
       "$ROOT/rtl/yunit/yunit_nvram_bridge.sv"
       "$ROOT/rtl/yunit/yunit_mem.sv" "$ROOT/rtl/yunit/yunit_dma.sv"
       "$ROOT/rtl/yunit/yunit_dma_logical_timer.sv"
       "$ROOT/rtl/yunit/yunit_dma_descriptor_fifo.sv"
       "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv"
       "$ROOT/rtl/yunit/vram_sdram_scanout.sv"
       "$ROOT/rtl/yunit/yunit_memsys.sv"
       "$ROOT/rtl/yunit/yunit_display_address_sequencer.sv"
       "$ROOT/rtl/yunit/yunit_autoerase_scheduler.sv"
       "$ROOT/rtl/yunit/yunit_autoerase_sdram_backend.sv"
       "$ROOT/rtl/yunit/yunit_shiftreg_engine.sv"
       "$ROOT/rtl/yunit/yunit_vram_word_arb.sv"
       "$ROOT/rtl/yunit/yunit_video.sv" "$ROOT/rtl/yunit/yunit_scanline.sv"
       "$ROOT/rtl/yunit/yunit_video_top.sv" "$ROOT/rtl/yunit/yunit_palram.sv"
       "$ROOT/rtl/sdram/yunit_sdram_arb.sv"
       "$ROOT/rtl/sdram/yunit_sdram_burst_arb.sv"
       "$ROOT/rtl/sdram/sdram_stock.sv" "$ROOT/rtl/sdram/yunit_sdram_adapter.sv"
       "$ROOT/rtl/yunit/yunit_gfx_unpack.sv"
       "$ROOT/rtl/yunit/yunit_mem_cdc.sv" "$ROOT/rtl/yunit/yunit_sound_cdc.sv"
       "$ROOT/rtl/yunit/yunit_audio_mix.sv" "$ROOT/rtl/yunit/yunit_adpcm_board.sv"
       "$ROOT/rtl/yunit/yunit_cpu_cadence.sv" "$ROOT/rtl/yunit/yunit_top.sv"
       "$ROOT/sim/sdram_chip.sv" "$ROOT/sim/sdram_chip_ca.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$SND/jt51/hdl" -maxdepth 1 -name '*.v' | sort)
while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$SND/jt6295" -maxdepth 1 -name '*.v' | sort)
SRC+=( "$SND/williams_cvsd/mc6809is.v" "$SND/smashtv_snd_rom.sv" "$ROOT/sim/$TB.sv" )

# SIM_INIT_MEM: this bench compiles with SYNTHESIS to exercise the synthesizable
# configuration, which drops yunit_mem's sim-only array zeroing. On silicon those
# arrays are BRAM and come up 0; without this the simulator alone sees X.
"$VLOG" -sv -quiet -svinputport=var +define+SYNTHESIS +define+USE_SDRAM_VRAM \
  +define+SIM_INIT_MEM \
  +define+SIM_NO_ALTERA ${EXTRA_DEFINES:-} -work work_top "${SRC[@]}"
"$VCOM" -2008 -quiet -work work_top \
  "$SND/williams_cvsd/gen_ram.vhd" "$SND/williams_cvsd/hc55564.vhd" \
  "$SND/williams_cvsd/pia6821.vhd" "$SND/williams_cvsd/williams_cvsd_board.vhd"

echo "running $TB ..."
# Keep the full transcript. Piping vsim straight into grep would both discard
# the evidence needed to diagnose a mid-run simulator death and return grep's
# exit status instead of vsim's -- a fake pass.
LOG="${TOP_LOG:-$ROOT/sim/build/$TB.top.log}"
mkdir -p "$(dirname "$LOG")"
set +e
"$VSIM" -c -quiet -work work_top -do "run -all; quit -f" "$TB" "$@" >"$LOG" 2>&1
VSIM_STATUS=$?
set -e
grep -viE "^# (Loading|//|\*\* Note)" "$LOG" | grep -iE "\[|==|error|fatal|preload" || true
echo "run_top: full transcript at $LOG"

# ORDER MATTERS. The simulator dying mid-run must never look like a pass, and it
# must not look like a real RTL failure either -- it is INCONCLUSIVE. A license
# death also makes vsim exit non-zero, so this check MUST come FIRST or the run
# gets misreported as exit 1 (real fail). Questa here is nodelocked to ONE vsim
# and several sibling core sessions share this machine, so contention -- not
# simulator fragility -- is the usual cause. Re-run when the license is free.
if grep -qE "lost connection|Exiting VSIM license process|Kernel lost connection|Fatal:" "$LOG"; then
  echo "run_top: simulator died mid-run ($TB) -- INCONCLUSIVE, not a pass, not a fail"
  echo "run_top: check for a competing vsim (nodelocked license) and re-run"
  exit 2
fi
if [ "$VSIM_STATUS" -ne 0 ]; then
  echo "run_top: vsim exited $VSIM_STATUS ($TB)"
  exit 1
fi
if grep -q "HARD TIMEOUT" "$LOG"; then
  echo "run_top: hard timeout ($TB)"
  exit 1
fi
if [ "$TB" = "tb_yunit_e2e" ]; then
  if grep -qE "E2E FAIL|== DEADLOCK" "$LOG"; then
    echo "run_top: download/unpack E2E failure"
    exit 1
  fi
  if ! grep -q "== E2E PASS" "$LOG"; then
    echo "run_top: no E2E PASS verdict"
    exit 1
  fi
  echo "run_top: $TB E2E PASS"
  exit 0
fi
if [ "$TB" = "tb_yunit_realboot" ]; then
  if grep -qE "== DERAIL|== DLBOOT FAIL|DLROM DEADLOCK" "$LOG"; then
    echo "run_top: reset-overlap ROM download failed"
    exit 1
  fi
  if ! grep -q "== DLBOOT PASS" "$LOG"; then
    echo "run_top: no DLBOOT PASS verdict"
    exit 1
  fi
  echo "run_top: $TB DLBOOT PASS"
  exit 0
fi
# ADDITIVE gate: the POWERTST milestone assertion (INITDATA display timing) is a
# separate, byte-exact proof that real self-test code ran. It never relaxes the
# BOOT SMOKE criteria below -- it can only add a failure.
if grep -q "MILESTONE FAIL" "$LOG"; then
  echo "run_top: MILESTONE FAIL ($TB)"
  exit 1
fi
if grep -q "BOOT SMOKE FAIL" "$LOG"; then
  echo "run_top: BOOT SMOKE FAIL ($TB)"
  exit 1
fi
if ! grep -q "BOOT SMOKE PASS" "$LOG"; then
  echo "run_top: no BOOT SMOKE verdict ($TB)"
  exit 1
fi
echo "run_top: $TB BOOT SMOKE PASS"
