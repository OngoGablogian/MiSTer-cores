#!/usr/bin/env bash
set -u
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$(cd "$(dirname "$0")" && pwd)"
g="$1"; secs="${2:-40}"; st="${3:-warm}"
NV="$D/nvpt_${g}_${st}"; rm -rf "$NV"; mkdir -p "$NV"
[ "$st" = "warm" ] && cp -r "$D/nvwarm/$g" "$NV/$g"
PT_OUT="$D/pt_${g}_${st}.txt" PT_SECS=$secs \
"$MAME" "$g" -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$NV" \
  -autoboot_script "$D/prot_trace.lua" -autoboot_delay 0 \
  -video none -sound none -seconds_to_run $((secs+15)) -nothrottle -skip_gameinfo \
  > "$D/ptlog_${g}_${st}.txt" 2>&1
grep -m1 '^PT: writes' "$D/ptlog_${g}_${st}.txt" || echo "NO PT LINE"
