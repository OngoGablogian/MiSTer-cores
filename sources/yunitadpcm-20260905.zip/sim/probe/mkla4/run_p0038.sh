#!/usr/bin/env bash
# run_p0038.sh GAME SECS  -- baseline vs injected, on a WARM CMOS.
# Reuses sim/probe/p0038-sufficiency/inject_p0038.lua UNMODIFIED.
# The warm CMOS is load-bearing: mkla4 does not reach display init on a blank
# CMOS at all (measured), so an injection run on a cold CMOS would be a
# ZERO-COVERAGE gate -- both arms would render nothing regardless of the defect.
set -u
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$(cd "$(dirname "$0")" && pwd)"
H="$D/../p0038-sufficiency"
g="$1"; secs="${2:-60}"
for mode in base inj; do
  inj=0; [ "$mode" = "inj" ] && inj=1
  rm -rf "$D/nvp_${g}_${mode}"; mkdir -p "$D/nvp_${g}_${mode}"
  cp -r "$D/nvwarm/$g" "$D/nvp_${g}_${mode}/$g"
  mkdir -p "$D/snapp_${g}_${mode}"
  P0038_INJECT=$inj P0038_OUT="$D/p38_${g}_${mode}.txt" P0038_SECS=$secs \
  P0038_SNAP="$D/snapp_${g}_${mode}" P0038_TRACE="${P0038_TRACE:-0}" \
  "$MAME" "$g" -rompath "$RP" -cfg_directory "$D/cfg" \
    -nvram_directory "$D/nvp_${g}_${mode}" \
    -snapshot_directory "$D/snapp_${g}_${mode}" \
    -autoboot_script "$H/inject_p0038.lua" -autoboot_delay 0 \
    -video none -sound none -seconds_to_run $((secs+15)) -nothrottle -skip_gameinfo \
    > "$D/p38log_${g}_${mode}.txt" 2>&1
  echo "-- $g $mode: $(grep -m1 'P0038_SUFF\[' "$D/p38log_${g}_${mode}.txt")"
done
