#!/usr/bin/env bash
# run_misc.sh GAME MODE SECS warm|cold
set -u
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$(cd "$(dirname "$0")" && pwd)"
g="$1"; mode="$2"; secs="${3:-40}"; st="${4:-warm}"
NV="$D/nvmi_${g}_${mode}_${st}"; rm -rf "$NV"; mkdir -p "$NV"
[ "$st" = "warm" ] && cp -r "$D/nvwarm/$g" "$NV/$g"
mkdir -p "$D/snapmi_${g}_${mode}_${st}"
MISC_MODE="$mode" MI_OUT="$D/mi_${g}_${mode}_${st}.txt" MI_SECS=$secs \
MI_SNAP="$D/snapmi_${g}_${mode}_${st}" \
"$MAME" "$g" -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$NV" \
  -snapshot_directory "$D/snapmi_${g}_${mode}_${st}" \
  -autoboot_script "$D/inject_misc.lua" -autoboot_delay 0 \
  -video none -sound none -seconds_to_run $((secs+15)) -nothrottle -skip_gameinfo \
  > "$D/milog_${g}_${mode}_${st}.txt" 2>&1
echo -n "$g/$mode/$st: "; grep -m1 '^MI\[' "$D/milog_${g}_${mode}_${st}.txt" || echo "NO MI LINE"
