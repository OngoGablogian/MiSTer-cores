#!/bin/sh
# cmosaudit_run.sh <title> <frames> <mode:cold|warm>
# Independent (blind) re-measurement of the cold-CMOS render question.
# COLD = fresh -nvram_directory -> MAME allocates an ALL-ZERO CMOS
#        (docs/mame-ref/midyunit.cpp:1257 nvram_device::DEFAULT_ALL_0), the same
#        image the FPGA core presents from zero-initialised BRAM with no .nvm.
# WARM = a second pass over the directory the previous run saved.
HERE="$(cd "$(dirname "$0")" && pwd)"
TITLE="$1"; FRAMES="${2:-1800}"; MODE="${3:-cold}"
NVDIR="$HERE/ca_nv_$TITLE"
SNAP="$HERE/ca_snap_${TITLE}_${MODE}"
[ "$MODE" = "cold" ] && rm -rf "$NVDIR"
mkdir -p "$NVDIR" "$SNAP"
SECS=$(( FRAMES / 50 + 15 ))
MK_OUT="$HERE/ca_${TITLE}_${MODE}.txt" MK_FRAMES="$FRAMES" \
"C:/tools/mame/mame.exe" "$TITLE" \
  -rompath "D:/deck/fpga/smash tv/roms" \
  -video none -sound none -nothrottle -skip_gameinfo \
  -seconds_to_run "$SECS" \
  -nvram_directory "$NVDIR" -snapshot_directory "$SNAP" \
  -autoboot_script "$HERE/cmos_render_census.lua" \
  >"$HERE/ca_mame_${TITLE}_${MODE}.log" 2>&1
echo "=== $TITLE $MODE rc=$? ==="
sed -n '/== SUMMARY ==/,$p' "$HERE/ca_${TITLE}_${MODE}.txt"
echo "nvram saved:"; ls -l "$NVDIR" 2>/dev/null | tail -3
