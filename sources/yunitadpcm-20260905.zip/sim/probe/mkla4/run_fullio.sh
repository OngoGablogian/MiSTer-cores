#!/usr/bin/env bash
# run_fullio.sh GAME SECS  -- WARM CMOS (copied from nvwarm/, same as run_bitoff.sh)
set -u
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$(cd "$(dirname "$0")" && pwd)"
g="$1"; secs="${2:-60}"
rm -rf "$D/nvfi_$g"; mkdir -p "$D/nvfi_$g"; cp -r "$D/nvwarm/$g" "$D/nvfi_$g/$g"
FI_OUT="$D/fi_$g.txt" FI_SECS=$secs \
"$MAME" "$g" -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$D/nvfi_$g" \
  -autoboot_script "$D/fullio_probe.lua" -autoboot_delay 0 \
  -video none -sound none -seconds_to_run $((secs+15)) -nothrottle -skip_gameinfo \
  > "$D/filog_$g.txt" 2>&1
grep -m1 '^FI\[' "$D/filog_$g.txt" || echo "NO FI LINE -- CHECK $D/filog_$g.txt"
