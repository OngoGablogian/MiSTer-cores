#!/usr/bin/env python3
"""Two-sided diff of the CORE's protection algorithm against the MAME gospel.

The model below is transcribed from the RTL ONLY --
  rtl/yunit/yunit_protection.sv:22-113  (reset_word / data_word / always_ff)
-- and is then replayed against a gospel trace captured live from MAME 0.280
(prot_trace.lua), which records every write to 0x01C00060-0x01C0007F and the
value MAME returned on every read of that window.

FAIL at zero coverage: if the trace contains no reads, the diff proves nothing
and the script exits non-zero.

usage: prot_replay.py <trace.txt> <game>
"""
import sys, re

# ---- transcribed from rtl/yunit/yunit_protection.sv ------------------------
RESET = {
    "mk":      [0x0d00, 0x0c00, 0x0900],   # YG_MK        :32
    "totcarn": [0x0f00, 0x0f00, 0x0f00],   # YG_TOTCARN   :34
    "term2":   [0x0f00, 0x0f00, 0x0f00],   # YG_TERM2     :33
}
DATA = {
    "mk": [0x4600, 0xf600, 0xa600, 0x0600, 0x2600, 0x9600, 0xc600, 0xe600,
           0x8600, 0x7600, 0x8600, 0x8600, 0x9600, 0xd600, 0x6600, 0xb600,
           0xd600, 0xe600, 0xf600, 0x7600, 0xb600, 0xa600],       # :66-75
    "mk_default": 0x3600,
    "totcarn": [0x4a00, 0x6a00, 0xda00, 0x6a00, 0x9a00, 0x4a00,
                0x2a00, 0x9a00, 0x1a00, 0x8a00],                  # :80-84
    "totcarn_default": 0xaa00,
    "term2": [0x4000, 0xf000],                                    # :77-78
    "term2_default": 0xa000,
}

def data_word(game, n):
    tbl = DATA[game]
    return tbl[n] if n < len(tbl) else DATA[game + "_default"]

class Prot:
    """rtl/yunit/yunit_protection.sv always_ff block, cycle-accurate per write."""
    def __init__(self, game):
        self.g = game
        self.seq0 = self.seq1 = self.seq2 = 0
        self.index = 0          # 5 bits in RTL
        self.result = 0
    def write(self, wdata):
        rw = RESET[self.g]
        masked = wdata & 0x0f00
        reset_match = (self.seq1 == rw[0]) and (self.seq2 == rw[1]) and (masked == rw[2])
        clock_edge  = bool(self.seq2 & 0x0800) and not (masked & 0x0800)
        # non-blocking: all right-hand sides use the PRE-write state
        nseq0, nseq1, nseq2 = self.seq1, self.seq2, masked
        nindex, nresult = self.index, self.result
        if reset_match:
            nindex = 0
        if clock_edge:
            idx = 0 if reset_match else self.index
            nresult = data_word(self.g, idx)
            nindex = (idx + 1) & 0x1f
        self.seq0, self.seq1, self.seq2 = nseq0, nseq1, nseq2
        self.index, self.result = nindex, nresult

def main():
    path, game = sys.argv[1], sys.argv[2]
    p = Prot(game)
    nr = nw = bad = 0
    firstbad = None
    for line in open(path):
        m = re.match(r"^([WR]) ([0-9A-F]{4}) ", line)
        if not m:
            continue
        kind, val = m.group(1), int(m.group(2), 16)
        if kind == "W":
            nw += 1
            p.write(val)
        else:
            nr += 1
            if p.result != val:
                bad += 1
                if firstbad is None:
                    firstbad = (nr, val, p.result, line.strip())
    print(f"trace={path} game={game}")
    print(f"WRITES_REPLAYED  {nw}")
    print(f"READS_CHECKED    {nr}   <-- 0 = ZERO COVERAGE, gate is void")
    print(f"MISMATCHES       {bad}")
    if firstbad:
        i, exp, got, ln = firstbad
        print(f"FIRST_MISMATCH   read#{i} mame={exp:04X} rtl_model={got:04X}  {ln}")
    if nr == 0:
        print("RESULT FAIL(zero-coverage)")
        sys.exit(2)
    print("RESULT " + ("PASS" if bad == 0 else "FAIL"))
    sys.exit(0 if bad == 0 else 1)

main()
