#!/usr/bin/env bash
# run_census.sh GAME SECS PASSTAG [--fresh]
# Runs render_census.lua on GAME for SECS emulated seconds using nvram dir
# nv_<GAME>.  --fresh wipes that dir first (cold CMOS).  Without --fresh the
# dir carries over from the previous pass (warm CMOS).
set -u
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$(cd "$(dirname "$0")" && pwd)"
g="$1"; secs="$2"; tag="$3"; fresh="${4:-}"
NV="$D/nv_$g"
[ "$fresh" = "--fresh" ] && { rm -rf "$NV"; }
mkdir -p "$NV" "$D/snap_${g}_${tag}" "$D/cfg"
RC_OUT="$D/res_${g}_${tag}.txt" RC_SECS="$secs" RC_SNAP="$D/snap_${g}_${tag}" \
"$MAME" "$g" -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$NV" \
  -snapshot_directory "$D/snap_${g}_${tag}" \
  -autoboot_script "$D/render_census.lua" -autoboot_delay 0 \
  -video none -sound none -seconds_to_run $((secs+15)) -nothrottle -skip_gameinfo \
  > "$D/log_${g}_${tag}.txt" 2>&1
echo "== $g $tag rc=$?"
grep -m1 '^RC\[' "$D/log_${g}_${tag}.txt" || echo "  (no RC line -- CHECK LOG)"
echo "  nvram after: $(ls -l "$NV"/*/* 2>/dev/null | awk '{print $5, $9}' | tr '\n' ' ')"
