#!/usr/bin/env bash
# run_bootdiff.sh GAME SECS warm|cold
set -u
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$(cd "$(dirname "$0")" && pwd)"
g="$1"; secs="${2:-40}"; st="${3:-warm}"
NV="$D/nvbd_${g}_${st}"
rm -rf "$NV"; mkdir -p "$NV"
[ "$st" = "warm" ] && cp -r "$D/nvwarm/$g" "$NV/$g"
BD_OUT="$D/bd_${g}_${st}.txt" BD_SECS=$secs \
"$MAME" "$g" -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$NV" \
  -autoboot_script "$D/bootdiff.lua" -autoboot_delay 0 \
  -video none -sound none -seconds_to_run $((secs+15)) -nothrottle -skip_gameinfo \
  > "$D/bdlog_${g}_${st}.txt" 2>&1
grep -m1 '^BD\[' "$D/bdlog_${g}_${st}.txt" || echo "NO BD LINE ($g/$st) -- CHECK LOG"
