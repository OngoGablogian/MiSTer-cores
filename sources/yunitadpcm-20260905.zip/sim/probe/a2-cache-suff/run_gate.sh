#!/usr/bin/env bash
# A-sports round 2: sufficiency of the yunit_sound_rom_cache stale-entry defect.
# Two arms in ONE run: the REAL frozen address, and the ADVERSARIAL freeze that
# guarantees a served pre-image byte (the mutation kill).
set -e
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
D="$(cd "$(dirname "$0")" && pwd)"; ROOT="$(cd "$D/../../.." && pwd)"; cd "$D"

iverilog -g2012 -DSIM_NO_ALTERA -s tb_snd_stale_suff -o suff.vvp \
  "$ROOT/rtl/sdram/sdram_stock.sv" "$ROOT/sim/sdram_chip.sv" \
  "$ROOT/rtl/sdram/yunit_sdram_adapter.sv" "$ROOT/rtl/sdram/yunit_sdram_arb.sv" \
  "$ROOT/rtl/yunit/yunit_sound_rom_cache.sv" \
  "$D/tb_snd_stale_suff.sv" 2>&1 | grep -v "sorry: constant selects" || true

echo "############ ARM 1: ADVERSARIAL freeze (mutation control -- MUST kill) ############"
vvp suff.vvp +FREEZE=1 +VEC=0 2>&1 | tail -30
echo
echo "############ ARM 2: REAL freeze = ext_rom_addr_r power-on 0, with reset vector ####"
vvp suff.vvp +FREEZE=0 +VEC=1 2>&1 | tail -30
echo
echo "############ ARM 3: REAL freeze, NO reset vector (adversarial ordering) ###########"
vvp suff.vvp +FREEZE=0 +VEC=0 2>&1 | tail -30
echo
echo "#### ARM 4: ADVERSARIAL freeze, dead-cycle 0xFFFF reads STRIPPED (harshest bound) ####"
vvp suff.vvp +FREEZE=1 +VEC=0 +NODUMMY=1 2>&1 | tail -30
echo
echo "#### ARM 5: REAL freeze, dead-cycle reads STRIPPED ################################"
vvp suff.vvp +FREEZE=0 +VEC=0 +NODUMMY=1 2>&1 | tail -30
