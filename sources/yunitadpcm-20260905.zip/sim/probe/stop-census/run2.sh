#!/usr/bin/env bash
# Y-unit STOP census runner (ysc2).
#   pass1 = cold, seeds NVRAM (no NVRAM -> the game parks at the CMOS/factory screen and never
#           reaches display init, so a single-pass trace is missing the code we want). Discarded.
#   pass2 = warm, MEASURED.
# usage: FR=6000 COIN=0 ./run2.sh smashtv trog ...
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
ROMS="/d/deck/fpga/smash tv/roms"
MAME="/c/ProgramData/chocolatey/bin/mame.exe"      # 0.280
OUT="$HERE/out2"; mkdir -p "$OUT/cfg"
FR=${FR:-6000}
COIN=${COIN:-0}
SUF=${SUF:-attract}

for title in "$@"; do
  nv="$OUT/nv_$title"; mkdir -p "$nv"
  for pass in 1 2; do
    o="$OUT/${title}_${SUF}_p${pass}"
    YSC_OUT="$o.txt" YSC_STOP_FRAME=$FR YSC_COIN_AT=$COIN YSC_TAG="${title}/${SUF}/p${pass}" \
      "$MAME" "$title" -rompath "$ROMS" -nvram_directory "$nv" -cfg_directory "$OUT/cfg" \
        -video none -sound none -skip_gameinfo -nothrottle \
        -autoboot_script "$HERE/ysc2.lua" > "$o.log" 2>&1
    echo "[$title $SUF p$pass] mame_exit=$?"
    grep -h '^SUMMARY' "$o.txt" 2>/dev/null || echo "   NO SUMMARY -- capture VOID"
  done
done
