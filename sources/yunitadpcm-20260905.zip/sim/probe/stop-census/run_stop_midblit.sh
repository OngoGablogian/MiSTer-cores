#!/usr/bin/env bash
# Mid-blit STOP characterisation gate.  iverilog only (the Questa licence is
# nodelocked to ONE vsim across sessions).  The repo path contains a space --
# every path stays quoted.
#
# SHIPPING define set for the blitter:
#   -DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_CVSD_BRAM_SOUND
# YUNIT_KILL_TRUNCATE and YUNIT_NO_DMASTOP are NOT defined (confirmed absent
# from quartus/build_hw.sh and every .qsf).  The TB fails closed if the define
# set is wrong.
#
# Two builds are run:
#   ship  -- the shipping DUT; its numbers are the deliverable characterisation.
#   mut   -- the same DUT with -DYUNIT_KILL_TRUNCATE (abandoned truncate
#            semantics).  The runner REQUIRES the two logs to differ; identical
#            logs would mean the bench never exercises the STOP path at all.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../../.." && pwd)"
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"

SRC=( "$ROOT/rtl/pkg/yunit_pkg.sv"
      "$ROOT/rtl/yunit/family2/yunit_dma_family2.sv"
      "$HERE/ackgen_stop.sv"
      "$HERE/tb_stop_midblit.sv" )

build_run () {  # $1 = tag, $2.. = extra defines
  local tag="$1"; shift
  local out="$HERE/stop_midblit_$tag.vvp"
  local log="$HERE/stop_midblit_$tag.log"
  iverilog -g2012 \
    -DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_CVSD_BRAM_SOUND "$@" \
    -s tb_stop_midblit -o "$out" "${SRC[@]}"
  vvp "$out" > "$log" 2>&1 || { echo "RUNNER: vvp($tag) failed"; cat "$log"; exit 1; }
  echo "$log"
}

SHIP_LOG="$(build_run ship)"
MUT_LOG="$(build_run mut -DYUNIT_KILL_TRUNCATE)"

echo "===================== SHIPPING BUILD ====================="
cat "$SHIP_LOG"
echo "=========================================================="

if grep -qE "^FAIL" "$SHIP_LOG"; then echo "RUNNER: shipping build FAILED"; exit 1; fi
if ! grep -qE "^PASS" "$SHIP_LOG"; then echo "RUNNER: no PASS line in shipping log"; exit 1; fi

# Coverage must be non-zero and explicit.
COV="$(grep -oE 'mid-draw STOPs landed = [0-9]+' "$SHIP_LOG" | grep -oE '[0-9]+$')"
if [ -z "$COV" ] || [ "$COV" -eq 0 ]; then
  echo "RUNNER: ZERO COVERAGE -- no STOP landed mid-draw; gate is worthless"; exit 1
fi

# Discrimination: the mutant must not produce the same characterisation.
if diff -q <(grep '^CASE' "$SHIP_LOG") <(grep '^CASE' "$MUT_LOG") >/dev/null; then
  echo "RUNNER: NON-DISCRIMINATING -- KILL_TRUNCATE mutant produced identical"
  echo "        case lines, so the bench does not exercise the STOP path."
  exit 1
fi
echo "DISCRIMINATION: KILL_TRUNCATE mutant differs from shipping. Diff:"
diff <(grep '^CASE' "$SHIP_LOG") <(grep '^CASE' "$MUT_LOG") || true

echo "RUNNER: OK  (coverage=$COV)  ship=$SHIP_LOG  mut=$MUT_LOG"
