#!/usr/bin/env python3
"""How does the Y-unit display pump synchronise with the blitter?

Input: capture_cmd_and_poll.lua output (every DMA_COMMAND write AND read).
Settles: does the pump wait on the completion IRQ (LINT1) or SPIN on COMMAND
bit15 (dma_r, docs/mame-ref/midyunit_v.cpp:384-386)?

Reports, per trigger:
  * how many busy-poll reads it took to clear
  * BUSY-WAIT ns  = last-read-with-bit15-set -> first-read-with-bit15-clear
  * SETUP ns      = first-clear-read -> the next trigger write   (pure CPU work)
  * and the count of triggers issued while the previous blit was still busy
    (i.e. a successor that could ever be "pending at S_DONE" in the RTL).
FAILS at zero coverage.
"""
import sys, os

path = sys.argv[1]
rows = []
for line in open(path):
    p = line.split()
    if p[0] not in ("R", "W"):
        continue
    rows.append((p[0], int(p[1]), p[2], int(p[3], 16), float(p[4])))

if len(rows) < 100:
    print(f"ZERO/THIN COVERAGE: {len(rows)} events -- FAIL")
    sys.exit(2)

trig = [i for i, r in enumerate(rows) if r[0] == "W" and (r[3] & 0x8000)]
notrig = [i for i, r in enumerate(rows) if r[0] == "W" and not (r[3] & 0x8000)]
reads = sum(1 for r in rows if r[0] == "R")
print(f"file={os.path.basename(path)}  events={len(rows)}  "
      f"triggers={len(trig)}  non-trigger COMMAND writes={len(notrig)}  "
      f"COMMAND reads={reads}")
print(f"busy-poll reads per trigger = {reads/len(trig):.1f}")

polls, busywait, setup, overlap = [], [], [], 0
for k, i in enumerate(trig[:-1]):
    j = trig[k + 1]
    seg = rows[i + 1:j]
    r = [s for s in seg if s[0] == "R"]
    polls.append(len(r))
    busy_set = [s for s in r if s[3] & 0x8000]
    clear = [s for s in r if not (s[3] & 0x8000)]
    if not clear:
        # the successor trigger was issued without ever seeing busy clear
        overlap += 1
        continue
    first_clear = clear[0]
    if busy_set:
        busywait.append((first_clear[4] - rows[i][4]) * 1e9)
    setup.append((rows[j][4] - first_clear[4]) * 1e9)


def q(v, p):
    v = sorted(v)
    return v[min(len(v) - 1, max(0, int(round(p / 100.0 * (len(v) - 1)))))]


print(f"triggers issued WITHOUT ever reading busy==0 : {overlap} "
      f"({100.0*overlap/len(trig):.3f}%)  <- the ONLY way a successor can be "
      f"pending at the RTL's S_DONE")
if polls:
    print(f"poll reads between triggers: p10={q(polls,10)} p50={q(polls,50)} "
          f"p90={q(polls,90)} max={max(polls)}")
if busywait:
    print(f"BUSY-WAIT ns (cmd -> first busy==0 read): p10={q(busywait,10):.0f} "
          f"p50={q(busywait,50):.0f} p90={q(busywait,90):.0f}")
if setup:
    print(f"SETUP ns (busy==0 seen -> next trigger):  min={min(setup):.0f} "
          f"p10={q(setup,10):.0f} p50={q(setup,50):.0f} p90={q(setup,90):.0f}")
