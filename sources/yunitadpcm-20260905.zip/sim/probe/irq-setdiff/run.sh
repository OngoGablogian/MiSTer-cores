#!/usr/bin/env bash
# Build + run the done-IRQ set-difference census under Icarus (no Questa: the
# licence is nodelocked to ONE vsim across sessions).  The repo path contains a
# space -- every path is quoted.
#
# SHIPPING DEFINE SET for the blitter (anything else is dead code):
#   -DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_CVSD_BRAM_SOUND
# YUNIT_KILL_TRUNCATE is deliberately NOT defined; the TB fails closed if either
# YUNIT_NO_COMMITGATE is missing or YUNIT_KILL_TRUNCATE is present.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../../.." && pwd)"
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"

bash "$HERE/mkclones.sh"

OUT="$HERE/setdiff.vvp"
LOG="$HERE/setdiff.log"

iverilog -g2012 \
  -DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_CVSD_BRAM_SOUND \
  -s tb_yunit_dma_irq_setdiff -o "$OUT" \
  "$ROOT/rtl/pkg/yunit_pkg.sv" \
  "$ROOT/rtl/yunit/family2/yunit_dma_family2.sv" \
  "$HERE/yunit_dma_family2_p1.sv" \
  "$HERE/yunit_dma_family2_p2.sv" \
  "$HERE/yunit_dma_family2_p3.sv" \
  "$HERE/ackgen.sv" \
  "$HERE/tb_yunit_dma_irq_setdiff.sv"

vvp "$OUT" > "$LOG" 2>&1
VVP=$?
tail -5 "$LOG"
if [ $VVP -ne 0 ]; then echo "RUNNER: vvp exited $VVP"; exit 1; fi
if grep -qE "^FAIL|RESULT:.*FAIL" "$LOG"; then echo "RUNNER: testbench FAILED"; exit 1; fi
if ! grep -qE "^PASS" "$LOG"; then echo "RUNNER: no PASS line"; exit 1; fi
echo "RUNNER: OK  ($LOG)"
