#!/usr/bin/env python3
"""Per-frame blitter operating point, per title (MAME 0.280 captures).

Because the display pump is CLOSED-LOOP on blit completion in every title
(measured: hiimpact/shimpact spin on COMMAND bit15, smashtv/trog take exactly one
LINT1 per blit), the blitter's speed does not change WHICH interrupts fire -- it
changes HOW MUCH the pump gets through in a frame. So the operating point that
matters is the per-frame budget:

    frame_time  >=  blits*SETUP_ns  +  pixels*(clk_per_px * 1000/96) ns

SETUP_ns is the measured software cost per blit (capture_cmd_and_poll /
capture_lint1: the constant delay from "completion observed" to the next trigger).
Anything over 100% means the pump does not drain its display list that frame, and
NDSP1.ASM:646-648 cans the tail objects -- "sprites flashing in and out".
"""
import sys, os, collections
sys.path.insert(0, os.path.dirname(__file__))
from opoint import load, pct

NS_PER_CLK = 1000.0 / 96.0

# measured software cost per blit (ns), from the handshake captures in this dir
SETUP = {"hiimpact": 5600.0,   # busy-poll exit -> next trigger, constant
         "shimpact": 5600.0,   # same pump (assumed identical; hiimpact measured)
         "smashtv": 7200.0,    # LINT1 vector fetch -> next trigger, p50
         "trog": 7200.0}       # LINT1 pump; smashtv figure used pending its own p50

BASE = os.path.join(os.path.dirname(__file__), "..", "blitq-depth", "out")
HERE = os.path.dirname(__file__)
TITLES = [("hiimpact", os.path.join(BASE, "hiimpact_attract.txt")),
          ("shimpact", os.path.join(BASE, "shimpact_attract.txt")),
          ("smashtv", os.path.join(BASE, "smashtv_attract2.txt")),
          ("trog", os.path.join(HERE, "trog_blits.txt"))]

SWEEP = [3.03, 3.25, 4.00, 5.00, 6.00, 8.00]

print("Per-frame blitter budget.  FRAME period derived from the capture's own "
      "timestamps.\n")
for title, path in TITLES:
    if not os.path.exists(path):
        print(f"{title}: MISSING {path}")
        continue
    rows = load(path)
    if not rows:
        print(f"{title}: ZERO COVERAGE -- FAIL")
        sys.exit(2)
    nfr = rows[-1]["frame"] - rows[0]["frame"]
    frame_ns = (rows[-1]["t"] - rows[0]["t"]) * 1e9 / nfr if nfr else 0
    per_f_blits = collections.Counter()
    per_f_px = collections.Counter()
    for r in rows:
        per_f_blits[r["frame"]] += 1
        per_f_px[r["frame"]] += r["px"]
    frames = sorted(per_f_blits)
    b = [per_f_blits[f] for f in frames]
    x = [per_f_px[f] for f in frames]
    setup = SETUP[title]
    print(f"===== {title} =====  {len(rows)} blits over {nfr} frames, "
          f"frame period {frame_ns/1e6:.3f} ms ({1e9/frame_ns:.2f} Hz)")
    print(f"  blits/frame   p50={pct(b,50)}  p90={pct(b,90)}  p99={pct(b,99)}  "
          f"max={max(b)}")
    print(f"  pixels/frame  p50={pct(x,50)}  p90={pct(x,90)}  p99={pct(x,99)}  "
          f"max={max(x)}")
    print(f"  software cost {setup:.0f} ns/blit -> "
          f"p90 frame = {pct(b,90)*setup/frame_ns*100:.1f}% of the frame "
          f"BEFORE a single pixel is drawn")
    print("   clk/px   ns/px    p50 frame   p90 frame   p99 frame   max frame"
          "   frames over 100%")
    for cpp in SWEEP:
        nsp = cpp * NS_PER_CLK
        occ = [(per_f_blits[f] * setup + per_f_px[f] * nsp) / frame_ns * 100.0
               for f in frames]
        over = sum(1 for o in occ if o > 100.0)
        print(f"   {cpp:5.2f}  {nsp:6.2f}    {pct(occ,50):8.1f}%   "
              f"{pct(occ,90):8.1f}%   {pct(occ,99):8.1f}%   {max(occ):8.1f}%"
              f"   {over:6d}/{len(frames)} ({100.0*over/len(frames):.1f}%)")
    print()
