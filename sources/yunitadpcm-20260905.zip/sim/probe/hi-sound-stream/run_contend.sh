#!/usr/bin/env bash
# A/B: streaming CVSD sound client ON vs OFF, same core, same measured trace.
set -e
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
D="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$D/../../.." && pwd)"
cd "$D"

iverilog -g2012 -DSIM_NO_ALTERA -s tb_hi_snd_contend -o contend.vvp \
  "$ROOT/rtl/sdram/sdram_stock.sv" \
  "$ROOT/sim/sdram_chip.sv" \
  "$ROOT/rtl/sdram/yunit_sdram_adapter.sv" \
  "$ROOT/rtl/sdram/yunit_sdram_arb.sv" \
  "$ROOT/rtl/sdram/yunit_src_cache.sv" \
  "$ROOT/rtl/yunit/yunit_sound_rom_cache.sv" \
  "$D/tb_hi_snd_contend.sv"

for arm in 1 0; do
  vvp contend.vvp +SND=$arm "$@"
done
