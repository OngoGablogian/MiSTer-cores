#!/bin/bash
# Broker discriminator #2: do the BRAM-sound titles that WORK on the cabinet
# (trog, strkforc) busy-poll the DMA COMMAND register at the sports' rate?
# Reuses the EXISTING sim/probe/yq-demand/capture_dma_poll.lua unmodified.
set -u
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$(cd "$(dirname "$0")" && pwd)"
LUA="$D/../yq-demand/capture_dma_poll.lua"

for g in "$@"; do
  mkdir -p "$D/nvram/$g"
  "$MAME" $g -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$D/nvram/$g" \
    -video none -sound none -seconds_to_run 45 -nothrottle -skip_gameinfo \
    > "$D/out/${g}_poll_p1.log" 2>&1
  YB_OUT="$D/out/poll_${g}.txt" YB_STOP=6000 YB_COIN_AT=400 \
  "$MAME" $g -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$D/nvram/$g" \
    -autoboot_script "$LUA" -autoboot_delay 0 \
    -video none -sound none -seconds_to_run 600 -nothrottle -skip_gameinfo \
    > "$D/out/${g}_poll_p2.log" 2>&1
  echo "== $g : $(cat "$D/out/poll_${g}.txt" 2>/dev/null)"
done
