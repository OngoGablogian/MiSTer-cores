#!/usr/bin/env bash
set -e
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
D="$(cd "$(dirname "$0")" && pwd)"; ROOT="$(cd "$D/../../.." && pwd)"; cd "$D"
iverilog -g2012 -DSIM_NO_ALTERA -s tb_hi_snd_contend -o contend.vvp \
  "$ROOT/rtl/sdram/sdram_stock.sv" "$ROOT/sim/sdram_chip.sv" \
  "$ROOT/rtl/sdram/yunit_sdram_adapter.sv" "$ROOT/rtl/sdram/yunit_sdram_arb.sv" \
  "$ROOT/rtl/sdram/yunit_src_cache.sv" "$ROOT/rtl/yunit/yunit_sound_rom_cache.sv" \
  "$D/tb_hi_snd_contend.sv" 2>&1 | grep -v "sorry: constant selects" || true
echo "### MUTATION (chip image corrupted above word 0x8000; the byte check MUST die)"
vvp contend.vvp +SND=1 +CGFX=0 +MUT=1 2>&1 | grep -E "MUTAN|RESULT|FAIL"
for cg in 0 32 128; do
  for arm in 1 0; do
    echo "### CGFX period=$cg  SND=$arm"
    vvp contend.vvp +SND=$arm +CGFX=$cg 2>&1 | grep -E "^== ARM|^   |^RESULT|^FAIL"
  done
done
