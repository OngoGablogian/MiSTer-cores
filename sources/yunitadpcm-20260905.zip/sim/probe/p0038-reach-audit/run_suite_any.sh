#!/usr/bin/env bash
# Licence-free full-core oracle runner for Y-unit (sv2v + Icarus), ported
# verbatim in mechanism from T-unit's sim/iv/run_suite.sh. Only the tree root
# and the TB location differ. No check is weakened.
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
CORE="${CORE_OVERRIDE:?}"
SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
export PATH="/c/iverilog/bin:$PATH"
OUT="${WORK_OVERRIDE:-$HERE/work}"; SAN="$OUT/src"; mkdir -p "$OUT" "$SAN"
DEFS="${DEFS:-}"
sanitize() {
  local src="$1" dst="$SAN/$(basename "$1")"
  perl -pe 's/[^\x00-\x7F]/?/g; s/\b[A-Za-z_][A-Za-z_0-9]*\.name\(\)/"?"/g' "$src" > "$dst"
  echo "$dst"
}
RAW_SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do RAW_SRC+=("$f"); done \
  < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
RAW_SRC+=( "$CORE/sim/models/sim_memory_model.sv" )
CORE_SRC=(); for f in "${RAW_SRC[@]}"; do CORE_SRC+=( "$(sanitize "$f")" ); done
pass=0; fail=0
for tb in "$@"; do
  src="$HERE/${tb}.sv"; [ -f "$src" ] || src="$CORE/sim/tb/${tb}.sv"
  [ -f "$src" ] || { echo "MISSING $tb"; fail=$((fail+1)); continue; }
  src="$(sanitize "$src")"
  if ! $SV2V $DEFS -w "$OUT/$tb.v" "${CORE_SRC[@]}" "$src" 2>"$OUT/$tb.sv2v.err"; then
    echo "SV2V-FAIL $tb"; head -3 "$OUT/$tb.sv2v.err"; fail=$((fail+1)); continue; fi
  if [ ! -s "$OUT/$tb.v" ] || [ -s "$OUT/$tb.sv2v.err" ]; then
    echo "SV2V-FAIL $tb"; head -3 "$OUT/$tb.sv2v.err"; fail=$((fail+1)); continue; fi
  if ! iverilog -g2012 -s "$tb" -o "$OUT/$tb.vvp" "$OUT/$tb.v" > "$OUT/$tb.iv.log" 2>&1; then
    echo "COMPILE-FAIL $tb"; head -5 "$OUT/$tb.iv.log"; fail=$((fail+1)); continue; fi
  ( cd "$OUT" && vvp "$OUT/$tb.vvp" ) > "$OUT/$tb.log" 2>&1
  if grep -q "TEST_RESULT: PASS" "$OUT/$tb.log"; then echo "PASS $tb"; pass=$((pass+1))
  else echo "FAIL $tb"; grep -m6 -iE "TEST_RESULT|FAIL:" "$OUT/$tb.log" | sed 's/^/      /'; fail=$((fail+1)); fi
done
echo "SUITE: $pass/$((pass+fail)) PASS"
[ $fail -eq 0 ]
