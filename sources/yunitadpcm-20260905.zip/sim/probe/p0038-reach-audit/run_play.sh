#!/bin/bash
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$PWD"
for g in "$@"; do
  P0038_PLAY=1 P0038_OUT="$D/sites_${g}_play.txt" P0038_SECS=120 "$MAME" $g \
    -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$D/nvram" \
    -autoboot_script "$D/p0038_io_field_probe.lua" -autoboot_delay 0 \
    -video none -sound none -seconds_to_run 130 -nothrottle -skip_gameinfo \
    > "$D/log_${g}_play.txt" 2>&1
  echo "== $g play: $(tail -2 "$D/sites_${g}_play.txt" | tr '\n' ' ')"
done
