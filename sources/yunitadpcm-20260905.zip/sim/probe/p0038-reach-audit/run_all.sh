#!/bin/bash
# Two runs per title: pass 1 creates NVRAM (game parks at the CMOS screen),
# pass 2 is the MEASURED run.
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$PWD"
for g in "$@"; do
  for pass in 1 2; do
    P0038_OUT="$D/sites_${g}_p${pass}.txt" P0038_SECS=60 "$MAME" $g \
      -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$D/nvram" \
      -autoboot_script "$D/p0038_io_field_probe.lua" -autoboot_delay 0 \
      -video none -sound none -seconds_to_run 70 -nothrottle -skip_gameinfo \
      > "$D/log_${g}_p${pass}.txt" 2>&1
  done
  echo "== $g pass2: $(tail -2 "$D/sites_${g}_p2.txt" 2>/dev/null | tr '\n' ' ')"
done
