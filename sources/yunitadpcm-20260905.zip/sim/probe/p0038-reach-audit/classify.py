import sys,glob,os
# opcode decode (MAME 0.280 34010dsm.cpp:219 subop=(op&0x01e0); :129 F=(op&0x200))
def decode(op):
    sub=op&0x01e0; F=(op>>9)&1
    if sub==0x0180: return ("MOVE Rs,@abs,%d"%F, F, None)
    if sub==0x01a0: return ("MOVE @abs,Rd,%d"%F, F, None)
    if sub==0x01c0: return ("MOVE @abs,@abs,%d"%F, F, None)
    if sub==0x01e0:
        if F: return ("MOVE @abs,Rd (32)", None, 32)
        return ("MOVB Rs,@abs", None, 8)      # MOVB: fixed 8, ST-independent
    if sub==0x0100 and False: pass
    return ("op=%04X sub=%03X F=%d"%(op,sub,F), F, None)
for path in sorted(sys.argv[1:]):
    rows=[]
    for ln in open(path):
        if ln.startswith('#'): continue
        p=ln.split()
        rw,pc,idx,ln4,fs0,fs1,op,cnt,addr=p[0],p[1],p[2],int(p[3],16),int(p[4]),int(p[5]),int(p[6],16),int(p[7]),p[8]
        name,F,fixed=decode(op)
        size = fixed if fixed is not None else (fs1 if F==1 else fs0)
        rows.append((rw,pc,idx,ln4,size,name,cnt,addr,fs0,fs1))
    bad=[r for r in rows if r[4]!=16]
    print("==== %s : %d sites, %d SUB-WORD/NON-16 sites"%(os.path.basename(path),len(rows),len(bad)))
    for r in sorted(bad,key=lambda r:-r[6])[:14]:
        print("   %s pc=%s ioidx=%02X off=%X SIZE=%d  %-20s n=%d addr=%s (fs0=%d fs1=%d)"%
              (r[0],r[1],int(r[2],16),r[3],r[4],r[5],r[6],r[7],r[8],r[9]))
