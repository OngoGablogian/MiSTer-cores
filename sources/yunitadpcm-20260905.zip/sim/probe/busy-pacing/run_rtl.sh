#!/usr/bin/env bash
# iverilog-only. Shipping defines: USE_DDR3_VRAM, YUNIT_NO_COMMITGATE, YUNIT_CVSD_BRAM_SOUND.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$D/../../.." && pwd)"
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
mkdir -p "$D/out"
iverilog -g2012 -gsupported-assertions -s tb_busy_pacing \
  -DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_CVSD_BRAM_SOUND -DSIM_NO_ALTERA \
  -o "$D/out/busy_pacing.vvp" \
  "$ROOT/rtl/pkg/yunit_pkg.sv" \
  "$ROOT/rtl/yunit/family2/yunit_dma_family2.sv" \
  "$D/mut/yunit_dma_family2_mut.sv" \
  "$ROOT/rtl/sdram/yunit_src_cache.sv" \
  "$ROOT/rtl/sdram/sdram_stock.sv" \
  "$ROOT/sim/sdram_chip.sv" \
  "$D/tb_busy_pacing.sv"
cd "$D"
vvp "$D/out/busy_pacing.vvp" "$@"
