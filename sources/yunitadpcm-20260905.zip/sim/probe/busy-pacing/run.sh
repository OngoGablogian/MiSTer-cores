#!/usr/bin/env bash
# Y-unit BUSY-PACING census. Icarus only (Questa is nodelocked to one vsim).
# The repo path contains a space -- every path stays quoted.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../../.." && pwd)"
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"

# SHIPPING defines (anything outside these is dead code in the DUT).
DEFS=( -DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_CVSD_BRAM_SOUND )

OUT="$HERE/tb_yunit_busy_pacing.vvp"
LOG="$HERE/tb_yunit_busy_pacing.log"

iverilog -g2012 "${DEFS[@]}" -s tb_yunit_busy_pacing -o "$OUT" \
  "$ROOT/rtl/pkg/yunit_pkg.sv" \
  "$ROOT/rtl/yunit/family2/yunit_dma_family2.sv" \
  "$HERE/yunit_dma_family2_pace1.sv" \
  "$HERE/yunit_dma_family2_pace2.sv" \
  "$HERE/yunit_dma_family2_pace3.sv" \
  "$HERE/dma_pace_probe_lib.sv" \
  "$HERE/tb_yunit_busy_pacing.sv"

set +e
vvp "$OUT" > "$LOG" 2>&1
ST=$?
set -e
cat "$LOG"
if [ "$ST" -ne 0 ]; then echo "RUNNER: vvp exited $ST"; exit 1; fi
if grep -qE "^FAIL|RESULT:.*FAIL" "$LOG"; then echo "RUNNER: testbench reported FAIL"; exit 1; fi
if ! grep -qE "^PASS" "$LOG"; then echo "RUNNER: no PASS line"; exit 1; fi
echo "RUNNER: tb_yunit_busy_pacing OK"
