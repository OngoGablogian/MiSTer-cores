#!/usr/bin/env bash
# GATE: scanout honours the CRTC's RUNTIME visible width (HEBLNK/HSBLNK).
# iverilog only -- no Questa, no licence.
#
# Behavioural, at the real pixel output. See tb_crtc_width.sv for the method,
# the measured per-title widths, and why the palette must return a NON-ZERO
# colour for the bench to distinguish "blanked" from "drawn".
#
# Runs the mutation control on every invocation: -DMUT_IGNORE_WIDTH restores the
# pre-fix hardwired width and MUST fail. A gate that cannot kill the old code
# proves nothing, and this tree has already shipped one that could not.
set -euo pipefail
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
D="$ROOT/sim/probe/crtc-width"
IV="${IV:-iverilog}"

command -v "$IV" >/dev/null 2>&1 || { echo "GATE_INCONCLUSIVE: no iverilog on PATH"; exit 77; }

SRC=("$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/yunit/family2/yunit_video_family2.sv" "$D/tb_crtc_width.sv")
for f in "${SRC[@]}"; do
  [ -f "$f" ] || { echo "GATE_INCONCLUSIVE: missing $f"; exit 77; }
done

"$IV" -g2012 -s tb_crtc_width -o "$D/tb.vvp"  "${SRC[@]}"
"$IV" -g2012 -DMUT_IGNORE_WIDTH -s tb_crtc_width -o "$D/tbm.vvp" "${SRC[@]}"
"$IV" -g2012 -DMUT_IGNORE_ENV   -s tb_crtc_width -o "$D/tbe.vvp" "${SRC[@]}"

vvp "$D/tb.vvp"  | tee "$D/crtc_width.log"
vvp "$D/tbm.vvp" | tee "$D/crtc_width_mutant.log" >/dev/null

grep -q "^PASS: CRTC_WIDTH" "$D/crtc_width.log" \
  || { echo "GATE FAIL: crtc_width -- the fix does not hold"; exit 1; }
grep -q "^FAIL: CRTC_WIDTH" "$D/crtc_width_mutant.log" \
  || { echo "GATE_INCONCLUSIVE: the MUT_IGNORE_WIDTH mutant SURVIVED -- this gate cannot distinguish the fix from the bug"; exit 77; }

vvp "$D/tbe.vvp" | tee "$D/crtc_env_mutant.log" >/dev/null
grep -q "^FAIL: CRTC_WIDTH" "$D/crtc_env_mutant.log"   || { echo "GATE_INCONCLUSIVE: the MUT_IGNORE_ENV mutant SURVIVED -- the ENV leg proves nothing"; exit 77; }

echo "CRTC-WIDTH: PASS (width + ENV mutants both killed)"
