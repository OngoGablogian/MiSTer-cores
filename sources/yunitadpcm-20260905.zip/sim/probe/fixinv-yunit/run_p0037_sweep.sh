#!/usr/bin/env bash
# P0037 opcode sweep + in-run mutation contract.
#   PKG=... DEC=... ./run_p0037_sweep.sh
set -uo pipefail
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
HERE="$(cd "$(dirname "$0")" && pwd)"
: "${PKG:?set PKG=<tms34010_pkg.sv>}"
: "${DEC:?set DEC=<tms34010_decode.sv>}"
TB="$HERE/tb_p0037_sweep.sv"
OUT="$HERE/build"; mkdir -p "$OUT"
SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"

run_one () {
  "$SV2V" "$PKG" "$2" "$TB" > "$OUT/$1.v" 2> "$OUT/$1.sv2v.err" || {
    echo "[$1] sv2v FAILED"; tail -20 "$OUT/$1.sv2v.err"; return 99; }
  iverilog -g2012 -o "$OUT/$1.vvp" "$OUT/$1.v" 2> "$OUT/$1.iv.err" || {
    echo "[$1] iverilog FAILED"; tail -20 "$OUT/$1.iv.err"; return 99; }
  vvp "$OUT/$1.vvp" > "$OUT/$1.log" 2>&1
  grep -E "^(SWEEP|PASS|RESULT|FAIL)" "$OUT/$1.log"
  grep -q "^PASS: tb_p0037_sweep" "$OUT/$1.log"
}

echo "=== LIVE: $DEC"
run_one live "$DEC"; LIVE=$?

MUT="$OUT/tms34010_decode_MUTANT.sv"
sed 's/if (top6 == MOVE_OFF_NI_TOP6) begin/if (1'"'"'b0 \&\& top6 == MOVE_OFF_NI_TOP6) begin/' "$DEC" > "$MUT"
if cmp -s "$MUT" "$DEC"; then
  echo "MUTATION SETUP FAILED: guard 'if (top6 == MOVE_OFF_NI_TOP6) begin' not found -> INCONCLUSIVE"; exit 98
fi
echo "=== MUTANT (P0037 arm disabled == pre-fix decoder)"
run_one mutant "$MUT"; MUTPASS=$?

echo "----"
[ "$LIVE" -eq 0 ] || { echo "GATE: LIVE FAILED"; exit 1; }
[ "$MUTPASS" -eq 99 ] && { echo "GATE: mutant build error"; exit 1; }
[ "$MUTPASS" -eq 0 ] && { echo "GATE: MUTANT SURVIVED -> gate does not exercise the fix. INVALID."; exit 1; }
echo "GATE: PASS (live) + KILL CONFIRMED (mutant failed) in this same run"
