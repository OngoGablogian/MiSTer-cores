#!/bin/bash
# DMA-REGISTER-REGION reachability capture. Same harness/method as the sibling
# p0038-reach-audit run_all.sh, with the tap window moved from the on-chip I/O
# file (0xC0000000-0xC00001FF) to the BLIT REGISTER region (0x01A00000-0x01AFFFFF,
# which covers both 0x01A0xxxx and the 0x01A8xxxx mirror the games actually use).
# Reuses the sibling's NVRAM so the games are past the CMOS screen.
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$(cd "$(dirname "$0")" && pwd)"
S="$D/../p0038-reach-audit"
mkdir -p "$D/dmareach"
for g in "$@"; do
  P0038_OUT="$D/dmareach/dma_${g}.txt" P0038_SECS=60 P0038_PLAY=1 "$MAME" $g \
    -rompath "$RP" -cfg_directory "$S/cfg" -nvram_directory "$S/nvram" \
    -autoboot_script "$D/dma_field_probe.lua" -autoboot_delay 0 \
    -video none -sound none -seconds_to_run 70 -nothrottle -skip_gameinfo \
    > "$D/dmareach/log_${g}.txt" 2>&1
  echo "== $g : $(tail -2 "$D/dmareach/dma_${g}.txt" 2>/dev/null | tr '\n' ' ')"
done
