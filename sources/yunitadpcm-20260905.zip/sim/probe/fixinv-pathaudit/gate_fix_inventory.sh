#!/bin/sh
# FIX-PRESENCE INVENTORY GATE for the LIVE Y-unit tree.
# Each item runs LIVE (must pass) and MUTANT (must be killed) in THIS run, and
# every verdict is ASSERTED (exit status), not merely printed.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
R="$(cd "$D/../../.." && pwd)"
SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
PKG="$R/rtl/tms34010/rtl/tms34010_pkg.sv"
T="/tmp/fixinv.$$"; mkdir -p "$T"
fail=0

# ---- P0030: SUB/SUBB/CMP carry = pure unsigned operand compare --------------
echo "== SHARED-P0030 =="
L=$(PKG="$PKG" ALU="$R/rtl/tms34010/rtl/core/tms34010_alu.sv" sh "$D/run_sub_cflag.sh" 2>&1) || true
M=$(PKG="$PKG" ALU="$D/mutant_alu_p0030.sv"                   sh "$D/run_sub_cflag.sh" 2>&1) || true
echo "$L" | grep -E "^PASS|^FAIL" | head -2
echo "$M" | grep -E "^FAIL" | head -2
echo "$L" | grep -q "^PASS: tb_tms34010_sub_cflag" || { echo "ASSERT-FAIL P0030: live ALU not green"; fail=1; }
echo "$M" | grep -q "^PASS: tb_tms34010_sub_cflag" && { echo "ASSERT-FAIL P0030: mutant SURVIVED"; fail=1; }
echo "$M" | grep -q "SUBB a==b borrow-in (the P0025 case)" || { echo "ASSERT-FAIL P0030: named case did not fire"; fail=1; }

# ---- P0016: INTPEND read-only + write-zero-to-clear -------------------------
echo "== SHARED-P0016 =="
cd "$R"
L=$(./sim/run.sh tb_tms34010_intpend_rmw 2>&1) || true
set +e; M=$(MUTATE=MUT_IO_INTPEND_WHOLE_WRITE ./sim/run.sh tb_tms34010_intpend_rmw 2>&1); MS=$?; set -e
echo "$L" | grep -E "^PASS" | head -1
echo "$M" | grep -E "^FAIL" | head -2
echo "$L" | grep -q "RUNNER: tb_tms34010_intpend_rmw OK" || { echo "ASSERT-FAIL P0016: live not green"; fail=1; }
[ "$MS" -eq 0 ] && { echo "ASSERT-FAIL P0016: mutant SURVIVED"; fail=1; }
echo "$M" | grep -qE "^FAIL" || { echo "ASSERT-FAIL P0016: mutant emitted no FAIL"; fail=1; }

# ---- P0037: MOVE *Rs(off),*Rd+ -- 65,536-encoding decode sweep --------------
echo "== P0037 =="
"$SV2V" "$PKG" "$R/rtl/tms34010/rtl/core/tms34010_decode.sv" "$D/tb_p0037_opcode_sweep.sv" > "$T/l.v"
iverilog -g2012 -s tb_p0037_opcode_sweep -o "$T/l.vvp" "$T/l.v"; L=$(vvp "$T/l.vvp" 2>&1)
"$SV2V" "$PKG" "$D/mutant_decode_p0037.sv"                    "$D/tb_p0037_opcode_sweep.sv" > "$T/m.v"
iverilog -g2012 -s tb_p0037_opcode_sweep -o "$T/m.vvp" "$T/m.v"; M=$(vvp "$T/m.vvp" 2>&1)
echo "$L" | grep -E "^SWEEP|^PASS|^FAIL"
echo "$M" | grep -E "^SWEEP|^FAIL" | head -3
echo "$L" | grep -q "^PASS: tb_p0037_opcode_sweep" || { echo "ASSERT-FAIL P0037: live sweep not green"; fail=1; }
echo "$M" | grep -q "^PASS: tb_p0037_opcode_sweep" && { echo "ASSERT-FAIL P0037: mutant SURVIVED"; fail=1; }
echo "$M" | grep -q "1024/1024 of 0xD000-0xD3FF still decode ILLEGAL" || { echo "ASSERT-FAIL P0037: mutant did not reproduce the recorded signature"; fail=1; }

rm -rf "$T"
[ "$fail" -eq 0 ] || { echo "GATE_RESULT: FAIL"; exit 1; }
echo "GATE_RESULT: PASS -- P0030 + P0016 + P0037 all PRESENT on the live Y-unit tree, each proved by a mutant killed in this same run"
