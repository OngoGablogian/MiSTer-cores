#!/usr/bin/env bash
# Strike Force gfx-socket gate. Runs the SAME TB against:
#   FIXED  = the live tree  -> must PASS
#   MUTANT = the live tree with the 4bpp gfxrom_r alias reverted on the
#            external-fetch path (exd_alias forced 0) -> must FAIL, and must
#            fail ONLY at unpacked byte >= 0x200000 (the U106/U107/U90/U91
#            window), which is what makes this gate DISCRIMINATING rather than
#            merely green.
# The kill is ASSERTED in this same run; the script exits non-zero if either
# side misbehaves. No check is weakened anywhere.
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../../.." && pwd)"
export PATH="/c/iverilog/bin:$PATH"
OUT="$HERE/work"; mkdir -p "$OUT"

SRC_PKG="$ROOT/rtl/pkg/yunit_pkg.sv"
SRC_MEM="$ROOT/rtl/yunit/family2/yunit_mem_family2.sv"
TB="$HERE/tb_sf_gfx_alias.sv"

build_and_run() {   # $1 = tag, $2 = mem source
  local tag="$1" mem="$2"
  iverilog -g2012 -DUSE_EXT_GFX -s tb_sf_gfx_alias \
    -o "$OUT/$tag.vvp" "$SRC_PKG" "$ROOT/rtl/yunit/yunit_protection.sv" "$mem" "$TB" > "$OUT/$tag.iv.log" 2>&1 || {
      echo "COMPILE-FAIL $tag"; tail -20 "$OUT/$tag.iv.log"; return 2; }
  ( cd "$OUT" && vvp "$OUT/$tag.vvp" ) > "$OUT/$tag.log" 2>&1
  grep -E "COVERAGE|FAILS|TEST_RESULT|^FAIL:" "$OUT/$tag.log" | head -14
}

# ---- MUTANT: revert the fix (force exd_alias low) -------------------------
mkdir -p "$OUT/mut"
sed 's|^  wire exd_alias = !exd_isrom \&\& bpp4;|  wire exd_alias = 1'"'"'b0; // MUTANT: alias reverted|' \
    "$SRC_MEM" > "$OUT/mut/yunit_mem_family2.sv"
if ! grep -q "MUTANT: alias reverted" "$OUT/mut/yunit_mem_family2.sv"; then
  echo "GATE ERROR: mutation did not apply -- the kill would be vacuous"; exit 3
fi

echo "=== FIXED (live tree) ==="
build_and_run fixed "$SRC_MEM"
echo "=== MUTANT (alias reverted) ==="
build_and_run mutant "$OUT/mut/yunit_mem_family2.sv"

FIX_OK=$(grep -c "TEST_RESULT: PASS" "$OUT/fixed.log")
MUT_FAIL=$(grep -c "TEST_RESULT: FAIL$" "$OUT/mutant.log")
MUT_HI=$(sed -n 's/.*at_or_above_0x200000=\([0-9]*\).*/\1/p' "$OUT/mutant.log" | head -1)
MUT_LO=$(sed -n 's/.*below_0x200000=\([0-9]*\).*/\1/p'        "$OUT/mutant.log" | head -1)
FIX_N=$(sed -n 's/.*total_reads=\([0-9]*\).*/\1/p'            "$OUT/fixed.log"  | head -1)

echo
echo "GATE SUMMARY: fixed_pass=$FIX_OK  mutant_fail=$MUT_FAIL  fixed_reads=${FIX_N:-0}"
echo "              mutant failures below 0x200000 = ${MUT_LO:-?}, at/above = ${MUT_HI:-?}"

rc=0
[ "$FIX_OK"   = "1" ] || { echo "ASSERT FAIL: live tree did not PASS";            rc=1; }
[ "$MUT_FAIL" = "1" ] || { echo "ASSERT FAIL: mutant was NOT killed";             rc=1; }
[ "${FIX_N:-0}" -gt 0 ] 2>/dev/null || { echo "ASSERT FAIL: zero coverage";       rc=1; }
[ "${MUT_HI:-0}" -gt 0 ] 2>/dev/null || { echo "ASSERT FAIL: mutant did not fail in the U106/U107/U90/U91 window"; rc=1; }
[ $rc -eq 0 ] && echo "GATE: PASS (fix present, mutation killed in the same run)" \
              || echo "GATE: FAIL"
exit $rc
