#!/usr/bin/env bash
# usage: run.sh <game> <mode> <tag> [secs] [snapsec]
set -uo pipefail
D="$(cd "$(dirname "$0")" && pwd)"
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
g="$1"; mode="$2"; tag="$3"; secs="${4:-30}"; snap="${5:-0}"
mkdir -p "$D/cfg" "$D/nvram" "$D/snap"
SFOUT="$D/census_${g}_${tag}.txt" SFMODE="$mode" SFSECS="$secs" SFSNAP="$snap" \
SFCUT="${SFCUT:-2097152}" \
"$MAME" "$g" -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$D/nvram_${tag}" \
  -snapshot_directory "$D/snap/${g}_${tag}" \
  -autoboot_script "$D/sf_gfx_tap.lua" -autoboot_delay 0 \
  -video none -sound none -seconds_to_run $((secs+8)) -nothrottle -skip_gameinfo \
  > "$D/log_${g}_${tag}.txt" 2>&1
echo "--- $g/$tag exit=$? ---"
tail -3 "$D/census_${g}_${tag}.txt" 2>/dev/null
