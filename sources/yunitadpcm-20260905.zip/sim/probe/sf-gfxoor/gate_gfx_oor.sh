#!/usr/bin/env bash
# Does exd_gfx_oor bound ALL covered words, or only word 0?
#
# Three arms, THREE title configurations, ONE invocation:
#   LIVE   the shipping tree                      -> expected FAIL on straddles,
#                                                    and PASS on word0-OOR
#   FIXED  per-covered-word bound (scripted)      -> must PASS everywhere
#   MUTW0  FIXED with the word-0 bound removed    -> POSITIVE CONTROL, must FAIL
#                                                    at word0-OOR
# The MUTW0 arm is what makes a FIXED pass non-vacuous: it proves the TB can see
# an unbounded word 0 too, in the same run that reports the FIXED pass.
#
# Configs (ALLOC = GFX_PIXELS = SDRAM_ROMB, GB = per-title yunit_gfx_bytes):
#   sf   ALLOC 0x400000  GB 0x300000  4bpp   strkforc / saurnfrnt / trog-shaped
#                                            -> overrun lands in STALE gfx SDRAM
#   shi  ALLOC 0x400000  GB 0x400000  6bpp   shimpact (family2 map)
#                                            -> overrun lands in PROGRAM ROM
#   mk   ALLOC 0x800000  GB 0x800000  6bpp   mk / term2 (ADPCM map)
#                                            -> overrun lands in PROGRAM ROM
#   smash ALLOC 0x400000 GB 0x180000  6bpp   Smash T.V. in the family2 map
#                                            (yunit_pkg.sv plane_words 0x030000 x8)
#   trog  ALLOC 0x400000 GB 0x300000  4bpp   Trog in the family2 map
#                                            (yunit_pkg.sv plane_words 0x060000 x8)
#   totcarn ALLOC 0x800000 GB 0x400000 6bpp  Total Carnage (ADPCM map)
#                                            -> overrun lands in STALE gfx SDRAM
# smash/trog are the CABINET-CONFIRMED titles: they are measured, not assumed.
# (trog's geometry is identical to sf by construction; it is listed by name so the
# regression claim is auditable per title rather than inferred.)
# No check is weakened anywhere; zero coverage and an unexercised straddle class
# are both explicit FAILs inside the TB.
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../../.." && pwd)"
export PATH="/c/iverilog/bin:$PATH"
OUT="$HERE/work"; mkdir -p "$OUT"
SRC_MEM="$ROOT/rtl/yunit/family2/yunit_mem_family2.sv"

# mkvariants is BIDIRECTIONAL: whichever side the shipping tree is on, it emits all
# three arms (and round-trip-verifies the derivation it had to compute). The FIXED arm
# is the shipping file itself once SRC-4 is applied.
python "$HERE/mkvariants.py" "$SRC_MEM" "$OUT/mem_live.sv" "$OUT/mem_fixed.sv" "$OUT/mem_mutw0.sv" || exit 3

declare -A MEM=( [live]="$OUT/mem_live.sv" [fixed]="$OUT/mem_fixed.sv" [mutw0]="$OUT/mem_mutw0.sv" )

run() {  # $1=arm  $2=cfgname  $3..=defines
  local arm="$1" cfg="$2"; shift 2
  local tag="${arm}_${cfg}"
  iverilog -g2012 -DUSE_EXT_GFX "$@" -s tb_gfx_oor -o "$OUT/$tag.vvp" \
    "$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/yunit/yunit_protection.sv" \
    "${MEM[$arm]}" "$HERE/tb_gfx_oor.sv" > "$OUT/$tag.iv.log" 2>&1
  if [ ! -f "$OUT/$tag.vvp" ]; then echo "COMPILE-FAIL $tag"; tail -5 "$OUT/$tag.iv.log"; return 2; fi
  ( cd "$OUT" && vvp "$OUT/$tag.vvp" ) > "$OUT/$tag.log" 2>&1
  grep -E "^(CONFIG|COVERAGE|FAILS|LEAKED|TEST_RESULT)" "$OUT/$tag.log"
}

fld() { sed -n "s/.*$2=\([0-9]*\).*/\1/p" "$OUT/$1.log" | sed -n "$3p"; }
# FAILS line fields: 1=total 2=in_range 3=word0_oor 4=straddle_to_stale 5=straddle_to_progrom
res()  { grep -c "TEST_RESULT: $2" "$OUT/$1.log"; }
covline() { sed -n 's/^COVERAGE: //p' "$OUT/$1.log"; }
failline(){ sed -n 's/^FAILS: //p'    "$OUT/$1.log"; }
num() { sed -n "s/^$2: .*$3=\([0-9]*\).*/\1/p" "$OUT/$1.log" | head -1; }

rc=0
PC_KILLS=0
for cfg in sf shi mk smash trog totcarn; do
  case $cfg in
    sf)      D=(-DGFXPIX=32\'h400000 -DGFXBYTES=24\'h300000 -DBPP4=1\'b1);;
    shi)     D=(-DGFXPIX=32\'h400000 -DGFXBYTES=24\'h400000 -DBPP4=1\'b0);;
    mk)      D=(-DGFXPIX=32\'h800000 -DGFXBYTES=24\'h800000 -DBPP4=1\'b0);;
    smash)   D=(-DGFXPIX=32\'h400000 -DGFXBYTES=24\'h180000 -DBPP4=1\'b0);;
    trog)    D=(-DGFXPIX=32\'h400000 -DGFXBYTES=24\'h300000 -DBPP4=1\'b1);;
    totcarn) D=(-DGFXPIX=32\'h800000 -DGFXBYTES=24\'h400000 -DBPP4=1\'b0);;
  esac
  for arm in live fixed mutw0; do
    echo "=== $arm / $cfg ==="
    run "$arm" "$cfg" "${D[@]}"
  done

  L=${cfg}; LIVE=live_$L; FIX=fixed_$L; MUT=mutw0_$L
  s_cov=$(( $(num $LIVE COVERAGE straddle_to_stale) + $(num $LIVE COVERAGE straddle_to_progrom) ))
  s_fail=$(( $(num $LIVE FAILS straddle_to_stale) + $(num $LIVE FAILS straddle_to_progrom) ))
  echo "--- $cfg: straddle cases exercised=$s_cov  LIVE straddle failures=$s_fail"

  [ "$s_cov" -gt 0 ] 2>/dev/null || { echo "ASSERT FAIL[$cfg]: no straddle case exercised"; rc=1; }
  [ "$(num $LIVE FAILS in_range)" = "0" ]  || { echo "ASSERT FAIL[$cfg]: LIVE fails IN RANGE -- instrument suspect"; rc=1; }
  [ "$(num $LIVE FAILS word0_oor)" = "0" ] || { echo "ASSERT FAIL[$cfg]: LIVE fails on word0 -- :655 does not even bound word 0"; rc=1; }
  [ "$s_fail" -gt 0 ] 2>/dev/null || { echo "ASSERT FAIL[$cfg]: LIVE did NOT leak on a straddle -- defect claim REFUTED"; rc=1; }
  [ "$(res $FIX PASS)" = "1" ]   || { echo "ASSERT FAIL[$cfg]: FIXED does not close it"; rc=1; }

  # TIMING REGRESSION (added with SRC-4): the fix is combinational logic on the
  # win_s_q load only. At identical stimulus the LIVE and FIXED arms must burn the
  # IDENTICAL number of request->ack clocks -- if the edit perturbed the M_EXD/M_GFX
  # FSM by even one cycle this equality breaks. A missing CYCLES line is a FAIL, not
  # a skip.
  c_live=$(num $LIVE CYCLES total); c_fix=$(num $FIX CYCLES total)
  [ -n "$c_live" ] && [ -n "$c_fix" ] || { echo "ASSERT FAIL[$cfg]: no CYCLES instrumentation"; rc=1; }
  [ "$c_live" = "$c_fix" ] || { echo "ASSERT FAIL[$cfg]: fetch latency CHANGED live=$c_live fixed=$c_fix"; rc=1; }
  echo "--- $cfg: request->ack clocks  live=$c_live  fixed=$c_fix  (must be equal)"

  # POSITIVE CONTROL. exd_gfx_oor (:655) is only REACHABLE when the populated
  # image ends INSIDE the 0x800000-byte window. For mk/term2 gfx_bytes == the
  # window size, so the bound can never fire and the control is INERT BY
  # CONSTRUCTION -- asserted as inert, not skipped. The kill is still
  # demonstrated in this same run by the sf and shi configs.
  reach=$(sed -n 's/^W0_BOUND_REACHABLE=//p' "$OUT/$LIVE.log" | head -1)
  m_w0=$(num $MUT FAILS word0_oor)
  if [ "${reach:-0}" = "1" ]; then
    [ "$(res $MUT FAIL)" -ge 1 ] 2>/dev/null || { echo "ASSERT FAIL[$cfg]: positive control not killed"; rc=1; }
    [ "${m_w0:-0}" -gt 0 ] 2>/dev/null || { echo "ASSERT FAIL[$cfg]: positive control did not fail at word0 -- FIXED pass would be vacuous"; rc=1; }
    echo "--- $cfg: word-0 bound REACHABLE; positive control killed with $m_w0 word0 failures"
    PC_KILLS=$((PC_KILLS+1))
  else
    [ "$(num $LIVE COVERAGE word0_oor)" = "0" ] || { echo "ASSERT FAIL[$cfg]: claimed unreachable but word0-OOR cases exist"; rc=1; }
    [ "${m_w0:-0}" = "0" ] || { echo "ASSERT FAIL[$cfg]: control claimed inert but failed at word0"; rc=1; }
    echo "--- $cfg: word-0 bound UNREACHABLE by construction (gfx_bytes == window top);"
    echo "          positive control asserted INERT (0 word0 failures), kill shown by sf/shi"
  fi
  echo
done

# the kill must be demonstrated somewhere in THIS run, not argued
[ "${PC_KILLS:-0}" -ge 1 ] || { echo "ASSERT FAIL: positive control never killed in any config"; rc=1; }

if [ $rc -eq 0 ]; then
  echo "GATE: PASS -- shipping tree leaks on straddles (defect), scripted fix closes it,"
  echo "              and the positive control proves the TB is not blind."
else
  echo "GATE: FAIL"
fi
exit $rc
