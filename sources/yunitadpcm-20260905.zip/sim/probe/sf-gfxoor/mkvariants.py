#!/usr/bin/env python3
"""Derive the LIVE, FIXED and POSITIVE-CONTROL variants of yunit_mem_family2.sv.

Nothing in the shipping tree is modified. Every substitution is verified; if any
anchor is missing the script aborts so a kill/pass can never be vacuous.

  LIVE   : word-0-only bound (the DEFECT).
  FIXED  : exd_gfx_oor's bound extended from word 0 to ALL 1..3 covered words.
  MUTW0  : FIXED with the word-0 bound removed -- positive control proving the TB
           detects an unbounded word 0 as well (so a FIXED pass is not vacuous).

BIDIRECTIONAL (SRC-4 applied 2026-08-04). The generator originally assumed the
shipping tree still carried the defect and derived FIXED forward from it. Now
that SRC-4 is applied in-tree, it detects which side the source is on and derives
the OTHER one, so the three arms are unchanged and the FIXED arm is literally the
shipping file:

  source has OLD_WIN  -> pre-fix  tree: LIVE = source,  FIXED/MUTW0 derived forward
  source has NEW_WIN  -> applied  tree: FIXED = source, LIVE derived BACKWARD and
                                        ROUND-TRIP VERIFIED (re-applying the fix to
                                        the derived LIVE must reproduce the source
                                        byte-for-byte, else abort)

No assertion, case or arm is removed or loosened by this: all three variants are
still built and every check in gate_gfx_oor.sh runs against them unchanged.
"""
import sys, os

src_path, out_live, out_fixed, out_mutw0 = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
src = open(src_path, encoding='utf-8', errors='surrogateescape').read()

ANCHOR_OOR = "  wire exd_gfx_oor = !exd_isrom && (exd_base >= gfx_bytes);\n"
ANCHOR_ALIAS = "  wire exd_alias = !exd_isrom && bpp4;\n"

ADD_AFTER_ALIAS = """\
  // ---- PER-COVERED-WORD out-of-range bound (round-2 finding) ---------------
  // exd_gfx_oor above names ONLY exd_base, i.e. window word 0, but M_GFX fetches
  // exd_need = 1..3 words at exd_base, +2, +4 (:644 extnw, :1318 latch). A field
  // straddling the top of the populated image therefore merged RAW SDRAM into
  // words 1/2 where MAME's zero-initialised m_gfx_rom reads 0.
  // TIMING (2026-08-04): the first cut of these two bounds wrote them as
  //   (exd_base + 24'd2) >= gfx_bytes   and   (exd_base + 24'd4) >= gfx_bytes
  // which put TWO 24-bit adders into the same window-load cone the word-0 bound
  // above was already moved OFF once (see :650-654: the in-cone version cost
  // 0.39 ns). Measured cost of the adder form on the Family2 image: Slow -40C
  // setup +0.188 -> -0.051 (-0.239 ns), while Slow 100C moved only -0.021.
  // Three fitter seeds could not recover it (4: -0.051, 5: -0.217, 6: -0.588),
  // which is the signature of a real cone, not placement luck.
  // exd_base + k >= gfx_bytes is exactly exd_base >= gfx_bytes - k, and gfx_bytes
  // is a per-title INPUT that only changes when game_id is loaded. Register the
  // two limits so the load cone sees three plain compares against one registered
  // base and NO adders. Saturating subtract: a title with gfx_bytes < 4 would
  // otherwise wrap and read the whole window in-range.
  logic [23:0] gfx_lim1, gfx_lim2;
  always_ff @(posedge clk) begin
    gfx_lim1 <= (gfx_bytes >= 24'd2) ? (gfx_bytes - 24'd2) : 24'd0;
    gfx_lim2 <= (gfx_bytes >= 24'd4) ? (gfx_bytes - 24'd4) : 24'd0;
  end
  wire exd_oor1 = !exd_isrom && (exd_base >= gfx_lim1);
  wire exd_oor2 = !exd_isrom && (exd_base >= gfx_lim2);
  // ---- ALIAS AT CAPTURE, not at the window load (timing retime) ------------
  // SRC-3 (making the 4bpp alias LIVE on the external path) put THREE gfx4_alias
  // evaluations plus three OOR muxes into the one M_GFX window-load cone -- the
  // same cone the word-0 bound was already moved off once (see :650-654).
  // Only ONE word is actually live at the load: gw0/gw1 are REGISTERED captures,
  // written one word per rack in M_GFX. AUDIT (file-wide, this is what gates the
  // transform): gw0/gw1 have exactly TWO readers, the two muxes below. The
  // stream buffer is fed RAW straight off gfx_rdata in the same rack branch, NOT
  // through gw0/gw1, so no R_ROM consumer ever sees these registers. Therefore
  // the alias may be applied where the word is CAPTURED instead of where the
  // window is LOADED.
  // SAFETY: exd_alias is latched-stable for the whole transaction -- exd_isrom is
  // written only in M_ACK's ext_fetch branch, and the M_ACK -> M_EXD -> M_GFX ->
  // M_SBH walk never re-enters M_ACK -- so the capture-time and load-time alias
  // decisions are the same value by construction, and an R_ROM word (exd_isrom=1
  // -> exd_alias=0) is never aliased at either site.
  // EFFECT: three alias evaluations become one shared node, and the registered
  // words reach the mux two logic levels earlier. No pipeline stage, no latency
  // change -- the gate asserts identical request->ack clock totals.
  wire [15:0] gfx_rd_a = exd_alias ? gfx4_alias(gfx_rdata) : gfx_rdata;
  // window words in fetch order (the LAST covered word is live on gfx_rdata;
  // gw0/gw1 already hold the earlier words in ALIASED form)
  wire [15:0] gxa0 = exd_gfx_oor ? 16'h0 : ((gfx_need == 2'd1) ? gfx_rd_a : gw0);
  wire [15:0] gxa1 = exd_oor1    ? 16'h0 : ((gfx_need == 2'd2) ? gfx_rd_a : gw1);
  wire [15:0] gxa2 = exd_oor2    ? 16'h0 : gfx_rd_a;
"""

# The M_GFX per-rack capture of window words 0/1. The FIXED side stores them
# ALREADY 4bpp-aliased (that is what collapses three alias evaluations in the
# load cone down to one); the LIVE side stores the RAW word, which is what the
# pre-fix OLD_WIN text below expects. Both sides MUST be part of the patch or the
# derived LIVE arm would double-alias gw0/gw1 and stop being a faithful pre-fix
# baseline -- i.e. this pairing is what keeps the LIVE arm honest.
OLD_CAP = """\
            if (gfx_cnt == 2'd0) gw0 <= gfx_rdata;
            if (gfx_cnt == 2'd1) gw1 <= gfx_rdata;
"""

NEW_CAP = """\
            if (gfx_cnt == 2'd0) gw0 <= gfx_rd_a;   // stored ALREADY aliased
            if (gfx_cnt == 2'd1) gw1 <= gfx_rd_a;   // (see the capture-alias note)
"""

OLD_WIN = """\
              win_s_q <= exd_gfx_oor ? 48'd0 :
                         exd_alias ?
                           ((gfx_need == 2'd1) ? {32'h0, gfx4_alias(gfx_rdata)} :
                            (gfx_need == 2'd2) ? {16'h0, gfx4_alias(gfx_rdata), gfx4_alias(gw0)} :
                                                 {gfx4_alias(gfx_rdata), gfx4_alias(gw1), gfx4_alias(gw0)}) :
                         (gfx_need == 2'd1) ? {32'h0, gfx_rdata} :
                         (gfx_need == 2'd2) ? {16'h0, gfx_rdata, gw0} :
                                              {gfx_rdata, gw1, gw0};
"""

NEW_WIN = """\
              win_s_q <= (gfx_need == 2'd1) ? {32'h0, gxa0} :
                         (gfx_need == 2'd2) ? {16'h0, gxa1, gxa0} :
                                              {gxa2, gxa1, gxa0};
"""

def need(text, anchor, what):
    if anchor not in text:
        sys.exit("PATCH ERROR: anchor missing (%s) -- a kill/pass here would be vacuous" % what)

def apply_fix(text):
    need(text, ANCHOR_ALIAS, "exd_alias")
    need(text, OLD_WIN, "M_GFX win_s_q load (pre-fix form)")
    need(text, OLD_CAP, "M_GFX gw0/gw1 capture (raw form)")
    t = text.replace(ANCHOR_ALIAS, ANCHOR_ALIAS + ADD_AFTER_ALIAS, 1)
    t = t.replace(OLD_CAP, NEW_CAP, 1)
    t = t.replace(OLD_WIN, NEW_WIN, 1)
    if "exd_oor2" not in t or "gxa2, gxa1, gxa0" not in t or "gw0 <= gfx_rd_a" not in t:
        sys.exit("PATCH ERROR: FIXED did not apply")
    return t

def revert_fix(text):
    need(text, ANCHOR_ALIAS + ADD_AFTER_ALIAS, "per-covered-word + capture-alias block")
    need(text, NEW_WIN, "M_GFX win_s_q load (fixed form)")
    need(text, NEW_CAP, "M_GFX gw0/gw1 capture (pre-aliased form)")
    t = text.replace(ANCHOR_ALIAS + ADD_AFTER_ALIAS, ANCHOR_ALIAS, 1)
    t = t.replace(NEW_CAP, OLD_CAP, 1)
    t = t.replace(NEW_WIN, OLD_WIN, 1)
    if "exd_oor2" in t or "gxa0" in t or "gfx_rd_a" in t:
        sys.exit("PATCH ERROR: LIVE (reverted) still carries fix text")
    return t

need(src, ANCHOR_OOR, "exd_gfx_oor")

if OLD_WIN in src:
    direction = "pre-fix tree: LIVE = shipping source, FIXED derived forward"
    live  = src
    fixed = apply_fix(src)
elif NEW_WIN in src:
    direction = "applied tree: FIXED = shipping source, LIVE derived backward"
    fixed = src
    live  = revert_fix(src)
    # ROUND TRIP: re-applying the fix to the derived LIVE must reproduce the
    # shipping file exactly. This is what makes the backward derivation as
    # trustworthy as the forward one -- it proves the in-tree edit IS the
    # gate's fix and nothing else.
    if apply_fix(live) != fixed:
        sys.exit("PATCH ERROR: round-trip mismatch -- in-tree edit is NOT the gate's fix")
else:
    sys.exit("PATCH ERROR: M_GFX win_s_q load matches neither the pre-fix nor the fixed form")

# positive control: same FIXED text with the word-0 bound defeated
mutw0 = fixed.replace(ANCHOR_OOR,
    "  wire exd_gfx_oor = 1'b0; // POSITIVE CONTROL: word-0 bound removed\n", 1)
if "POSITIVE CONTROL" not in mutw0:
    sys.exit("PATCH ERROR: MUTW0 did not apply")

for path, text in ((out_live, live), (out_fixed, fixed), (out_mutw0, mutw0)):
    open(path, 'w', encoding='utf-8', errors='surrogateescape').write(text)
print("PATCH OK:", direction, "--", os.path.basename(src_path))
