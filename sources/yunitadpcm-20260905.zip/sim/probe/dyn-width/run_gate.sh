#!/usr/bin/env bash
# GATE: the DYNAMIC video path honours the CRTC's runtime visible width.
# iverilog only. Mutation control runs on every invocation; the mutant MUST fail.
set -euo pipefail
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
D="$ROOT/sim/probe/dyn-width"
IV="${IV:-iverilog}"

command -v "$IV" >/dev/null 2>&1 || { echo "GATE_INCONCLUSIVE: no iverilog on PATH"; exit 77; }

SRC=("$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/yunit/yunit_video.sv" "$D/tb_dyn_width.sv")
for f in "${SRC[@]}"; do
  [ -f "$f" ] || { echo "GATE_INCONCLUSIVE: missing $f"; exit 77; }
done

"$IV" -g2012 -s tb_dyn_width -o "$D/tb.vvp"  "${SRC[@]}"
"$IV" -g2012 -DMUT_IGNORE_WIDTH -s tb_dyn_width -o "$D/tbm.vvp" "${SRC[@]}"
"$IV" -g2012 -DMUT_NO_FLIPX -s tb_dyn_width -o "$D/tbf.vvp" "${SRC[@]}"

vvp "$D/tb.vvp"  | tee "$D/dyn_width.log"
vvp "$D/tbm.vvp" | tee "$D/dyn_width_mutant.log" >/dev/null
vvp "$D/tbf.vvp" | tee "$D/dyn_flip_mutant.log" >/dev/null

grep -q "^PASS: DYN_WIDTH" "$D/dyn_width.log" \
  || { echo "GATE FAIL: dyn_width -- the fix does not hold"; exit 1; }
grep -q "^FAIL: DYN_WIDTH" "$D/dyn_width_mutant.log" \
  || { echo "GATE_INCONCLUSIVE: the MUT_IGNORE_WIDTH mutant SURVIVED"; exit 77; }
grep -q "^FAIL: DYN_WIDTH" "$D/dyn_flip_mutant.log" \
  || { echo "GATE_INCONCLUSIVE: the MUT_NO_FLIPX mutant SURVIVED -- the flip leg proves nothing"; exit 77; }

echo "DYN-WIDTH: PASS (width + flip mutants killed)"
