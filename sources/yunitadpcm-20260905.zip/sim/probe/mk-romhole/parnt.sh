#!/usr/bin/env bash
set -u
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$(cd "$(dirname "$0")" && pwd)"
g="$1"; secs="$2"; shift 2
pids=()
for L in "$@"; do
  tag="${g}_L${L}"
  rm -rf "$D/ntnv_$tag"; cp -r "$D/../p0038-sufficiency/nvram" "$D/ntnv_$tag"
  mkdir -p "$D/ntsnap_$tag"
  ( HOLE_LEN=$((16#$L)) HOLE_FILL=${HOLE_FILL:-0} HOLE_SECS=$secs \
    HOLE_OUT="$D/nt_res_$tag.txt" HOLE_SNAP="$D/ntsnap_$tag" \
    "$MAME" "$g" -rompath "$RP" -cfg_directory "$D/../p0038-sufficiency/cfg" \
      -nvram_directory "$D/ntnv_$tag" -snapshot_directory "$D/ntsnap_$tag" \
      -autoboot_script "$D/romhole.lua" -autoboot_delay 0 \
      -video none -sound none -seconds_to_run $((secs+8)) -nothrottle -skip_gameinfo \
      > "$D/nt_log_$tag.txt" 2>&1 ) &
  pids+=($!)
done
for p in "${pids[@]}"; do wait $p; done
echo ALLDONE
