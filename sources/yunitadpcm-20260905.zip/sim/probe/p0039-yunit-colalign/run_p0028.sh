#!/usr/bin/env bash
# SHARED-P0028 on Y-unit, verified by BEHAVIOUR (not by grepping for the fix).
# PROD must PASS and the mutant (fix removed) must FAIL, in this same run.
set -u
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
HERE="$(cd "$(dirname "$0")" && pwd)"
R="$HERE/../../.."
WORK="$HERE/work"; mkdir -p "$WORK"
PROD="$R/rtl/yunit/yunit_mem_cdc.sv"
MUT="$WORK/yunit_mem_cdc_MUT_P0028.sv"
FAILS=0

# Mutant = the pre-5821952 shape: reset gated by the clock enable.
sed -e "s/if ((ce_cpu !== 1'b0) || rst_cpu) begin/if (ce_cpu !== 1'b0) begin/" "$PROD" > "$MUT"
[ "$(grep -c "if (ce_cpu !== 1'b0) begin" "$MUT")" = "1" ] || { echo "MUTANT BUILD FAILED"; exit 9; }

run () { # $1 label  $2 src  $3 expect
  local log="$WORK/p28_$1.log"
  iverilog -g2012 -s tb_yunit_p0028_warm_reset -o "$WORK/p28_$1.vvp" \
           "$2" "$HERE/tb_yunit_p0028_warm_reset.sv" > "$log" 2>&1
  vvp "$WORK/p28_$1.vvp" >> "$log" 2>&1
  local res; res=$(grep -o "TEST_RESULT: \(PASS\|FAIL\)" "$log" | head -1 | awk '{print $2}')
  [ -z "$res" ] && res=NORESULT
  if [ "$res" = "$3" ]; then echo "  OK   $1 -> $res (expected $3)";
  else echo "  BAD  $1 -> $res (EXPECTED $3)"; FAILS=$((FAILS+1)); fi
  grep -E "^  (ok|MISMATCH)|TEST_RESULT" "$log" | sed 's/^/         /'
}

echo "=== SHARED-P0028 warm-reset gate (yunit_mem_cdc) ==="
run prod "$PROD" PASS
run mut  "$MUT"  FAIL
echo
if [ "$FAILS" -eq 0 ]; then echo "GATE_RESULT: ALL EXPECTATIONS MET (0 violations)"; exit 0
else echo "GATE_RESULT: $FAILS EXPECTATION(S) VIOLATED"; exit 1; fi
