#!/usr/bin/env bash
# P0039 back-port probe for Y-unit: does the scanout carry an un-gospelled
# column offset, and does anything constrain ABSOLUTE column alignment?
#
# Every verdict below is ASSERTED (this script exits non-zero if any expectation
# is violated), so a mutation KILL is proven in the SAME run as the PASS.
set -u
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
HERE="$(cd "$(dirname "$0")" && pwd)"
R="$HERE/../../.."
TB="$HERE/tb_yunit_scanout_column_align.sv"
PKG="$R/rtl/pkg/yunit_pkg.sv"
PROD="$R/rtl/yunit/yunit_video.sv"
WORK="$HERE/work"; rm -rf "$WORK"; mkdir -p "$WORK"
FAILS=0

# --- mutants: inject a constant on the SOURCE COLUMN in both expressions ------
# (built as COPIES; the tree is never modified)
mk_mutant () {  # $1 = offset literal, $2 = out file
  sed -e "s/(display_col + s0_x\[8:0\])/(display_col + s0_x[8:0] + 9'd$1)/" \
      -e "s/(s0_x & 12'h1ff)/((s0_x + 12'd$1) \& 12'h1ff)/" \
      -e "s/module yunit_video$/module yunit_video/" "$PROD" > "$2"
  grep -q "9'd$1" "$2" || { echo "MUTANT BUILD FAILED (offset $1)"; exit 9; }
}
mk_mutant 511 "$WORK/yunit_video_MUT_MINUS1.sv"   # candidate fix: -1 (mod 512)
mk_mutant 8   "$WORK/yunit_video_MUT_PLUS8.sv"    # T-unit's shipped P0039 value

run () {  # $1 = label  $2 = video source  $3 = ce_div  $4 = expect PASS|FAIL
  local out="$WORK/$1_$3.vvp" log="$WORK/$1_$3.log"
  iverilog -g2012 -DCE_DIV="$3" -s tb_yunit_scanout_column_align \
           -o "$out" "$PKG" "$2" "$TB" > "$log" 2>&1
  vvp "$out" >> "$log" 2>&1
  local res
  res=$(grep -o "TEST_RESULT: \(PASS\|FAIL\)" "$log" | head -1 | awk '{print $2}')
  [ -z "$res" ] && res=NORESULT
  local px
  px=$(grep -c "visible pixels checked" "$log")
  if [ "$res" = "$4" ]; then
    echo "  OK   $1 ce_div=$3 -> $res (expected $4, $px lines captured)"
  else
    echo "  BAD  $1 ce_div=$3 -> $res (EXPECTED $4)"
    FAILS=$((FAILS+1))
  fi
  grep -E "measured rotation|first bad|TEST_RESULT" "$log" | sed 's/^/         /'
}

echo "=== 1. PRODUCTION rtl/yunit/yunit_video.sv, palette modelled as SHIPPED"
echo "===    (yunit_palram.sv:79 = FULL-RATE clk, i.e. sub-pixel) ============"
for d in 12 6 4; do run prod "$PROD" "$d" FAIL; done

echo
echo "=== 2. MUTATION: does the gate discriminate the source-column term? ===="
echo "===    -1 (511) must PASS, +8 (T-unit's shipped P0039 value) must FAIL ="
for d in 12 6 4; do run mutMINUS1 "$WORK/yunit_video_MUT_MINUS1.sv" "$d" PASS; done
for d in 12; do run mutPLUS8  "$WORK/yunit_video_MUT_PLUS8.sv"  "$d" FAIL; done

echo
echo "=== 3. ALTERNATIVE FIX B: shorten the CONTROL path 3 -> 2 ce_pix stages ="
echo "===    (leaves the source-column arithmetic, and therefore"
echo "===     sim/tb_yunit_dynamic_video_cache.sv's address invariant, alone) ="
sed -e 's/de<=s2_de; hsync<=s2_hs; vsync<=s2_vs; hblank<=s2_hb; vblank<=s2_vb;/de<=s1_de; hsync<=s1_hs; vsync<=s1_vs; hblank<=s1_hb; vblank<=s1_vb;/' \
    -e 's/s2_de ? rgb/s1_de ? rgb/g' \
    "$PROD" > "$WORK/yunit_video_FIXB.sv"
grep -q "de<=s1_de" "$WORK/yunit_video_FIXB.sv" || { echo "FIX B BUILD FAILED"; exit 9; }
[ "$(grep -c "s1_de ? rgb" "$WORK/yunit_video_FIXB.sv")" = "3" ] || { echo "FIX B BUILD FAILED (blank gate)"; exit 9; }
for d in 12 6 4; do run fixB "$WORK/yunit_video_FIXB.sv" "$d" PASS; done

echo
if [ "$FAILS" -eq 0 ]; then
  echo "GATE_RESULT: ALL EXPECTATIONS MET (0 violations)"
  exit 0
else
  echo "GATE_RESULT: $FAILS EXPECTATION(S) VIOLATED"
  exit 1
fi
