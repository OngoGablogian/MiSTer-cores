#!/usr/bin/env bash
# GATE: the CRTC visible-width TRACKER survives the real init sequence.
#
# Companion to sim/probe/crtc-width, which proves the video module BLANKS beyond
# visible_px but drives visible_px directly -- so it cannot see a tracker that
# never produces the right value. That gap shipped a no-op fix once.
#
# The tracker is re-extracted VERBATIM from yunit_top_family2.sv on every run and
# driven with the real CRTC init ORDER, including the timing_start pulse that
# rides the HTOTAL write. Mutation control restores the shipped reset domain and
# MUST fail.
set -euo pipefail
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
D="$ROOT/sim/probe/crtc-track"
IV="${IV:-iverilog}"

command -v "$IV" >/dev/null 2>&1 || { echo "GATE_INCONCLUSIVE: no iverilog on PATH"; exit 77; }

python - "$ROOT" <<'PY'
import sys
root = sys.argv[1]
src = open(root+'/rtl/yunit/family2/yunit_top_family2.sv', encoding='utf8').read().splitlines()

beg = next(i for i,l in enumerate(src) if 'wire heblnk_we' in l)
end = next(i for i,l in enumerate(src) if i > beg and 'wire [11:0] visible_px' in l)
while '12\'(H_ACT) : crtc_px[11:0];' not in src[end]:
    end += 1
txt = "\n".join(src[beg:end+1])

A_RST = "if (video_rst) begin"
assert A_RST in txt, "extraction anchor moved (reset domain) -- refresh run_gate.sh"
assert 'visible_px' in txt, "extraction missed visible_px -- refresh the line range"

open(root+'/sim/probe/crtc-track/_track_asis.vh','w',encoding='utf8').write(txt+"\n")

# MUTANT: the reset domain that shipped. video_phase_rst pulses on the HTOTAL
# write, one register AFTER HEBLNK/HSBLNK, wiping them.
mut = txt.replace(A_RST, "if (video_phase_rst) begin")
assert mut != txt, "mutant identical to as-is -- the control is dead"
open(root+'/sim/probe/crtc-track/_track_mut.vh','w',encoding='utf8').write(mut+"\n")
PY

mkwrap () {  # $1 = include file, $2 = module name
cat > "$D/_wrap_$2.vh" <<SV
\`timescale 1ns/1ps
module $2 #(parameter int H_ACT = 410) (
  input  wire clk, input wire core_rst, input wire timing_start,
  input  wire tms_display_wr_valid, input wire [4:0] tms_display_wr_idx,
  input  wire [15:0] tms_display_wr_data,
  output wire [11:0] o_visible_px);
  localparam logic [4:0] IO_IDX_HEBLNK = 5'h01;   // tms34010_pkg.sv:288
  localparam logic [4:0] IO_IDX_HSBLNK = 5'h02;   // tms34010_pkg.sv:289
  localparam logic [4:0] IO_IDX_DPYCTL = 5'h08;   // tms34010_pkg.sv:295 (ENV tracker, 5788afe)
  wire video_rst       = core_rst;
  wire video_phase_rst = core_rst | timing_start; // as in the shipping top
  \`include "$1"
  assign o_visible_px = visible_px;
endmodule
SV
}
# as-is FIRST: both wrappers share a filename, so building the mutant here
# would silently make the as-is run test the mutant.
mkwrap _track_asis.vh crtc_track_dut

"$IV" -g2012 -I "$D" -s tb_crtc_track -o "$D/tb.vvp" "$D/_wrap_crtc_track_dut.vh" "$D/tb_crtc_track.sv"
vvp "$D/tb.vvp" | tee "$D/crtc_track.log"
grep -q "^PASS: CRTC_TRACK" "$D/crtc_track.log" || { echo "GATE FAIL: crtc_track"; exit 1; }

# rebuild the wrapper around the mutant extraction and re-run
mkwrap _track_mut.vh crtc_track_dut
"$IV" -g2012 -I "$D" -s tb_crtc_track -o "$D/tbm.vvp" "$D/_wrap_crtc_track_dut.vh" "$D/tb_crtc_track.sv"
vvp "$D/tbm.vvp" > "$D/crtc_track_mutant.log" 2>&1 || true
grep -q "^FAIL: CRTC_TRACK" "$D/crtc_track_mutant.log" \
  || { echo "GATE_INCONCLUSIVE: the video_phase_rst mutant SURVIVED -- this gate cannot see the defect that shipped"; exit 77; }

# leave the as-is wrapper in place so a later manual run tests the real thing
mkwrap _track_asis.vh crtc_track_dut
echo "CRTC-TRACK: PASS (video_phase_rst mutant killed)"
