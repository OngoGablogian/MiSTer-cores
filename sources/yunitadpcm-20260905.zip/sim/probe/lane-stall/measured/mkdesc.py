#!/usr/bin/env python3
# mkdesc.py -- turn a MEASURED MAME blit capture (sim/probe/busy-pacing/out/<game>.blits,
# frames 3000-3599, MAME 0.280) into a descriptor hex file the lane-stall bench replays.
#
# One PEAK frame per title (the frame with the most blits in the window) -- that is the
# operating point where the renderer's pace matters and where hiimpact/shimpact busy-spin.
#
# 8 words per blit, in the order the bench writes them:
#   cmd, w, h, rowbytes, x, y, offlo, offhi
# The OFF field is the REAL gfx bit-offset from the capture (the census used synthetic
# 0x0200k000 offsets, which give the source cache an unrealistically linear stream).
import re, sys, os

SRC = os.path.join(os.path.dirname(__file__), '..', '..', 'busy-pacing', 'out')
OUT = os.path.join(os.path.dirname(__file__), 'out')
PAT = re.compile(r'BLIT (\d+) (\d+) ([0-9A-F]+) CMD=([0-9A-F]+) W=(-?\d+) H=(-?\d+) '
                 r'RB=(-?\d+) X=(-?\d+) Y=(-?\d+) OFF=([0-9A-F]+)')

def u16(v):
    return int(v) & 0xFFFF

for game in sys.argv[1:]:
    frames = {}
    with open(os.path.join(SRC, game + '.blits')) as f:
        for line in f:
            m = PAT.match(line)
            if not m:
                continue
            fr = int(m.group(1))
            frames.setdefault(fr, []).append(m)
    peak = max(frames, key=lambda k: len(frames[k]))
    blits = frames[peak]
    px = 0
    maxoff = 0
    lines = []
    for m in blits:
        cmd = int(m.group(4), 16)
        w, h, rb, x, y = (int(m.group(i)) for i in (5, 6, 7, 8, 9))
        off = int(m.group(10), 16)
        px += max(w, 0) * max(h, 0)
        maxoff = max(maxoff, (off - 0x02000000) >> 3 if off >= 0x02000000 else 0)
        for v in (cmd, w, h, rb, x, y, off & 0xFFFF, (off >> 16) & 0xFFFF):
            lines.append('%04X' % u16(v))
    with open(os.path.join(OUT, 'desc_%s.hex' % game), 'w') as f:
        f.write('\n'.join(lines) + '\n')
    print('%-9s peak frame %d: %d blits, %d unclipped px, max gfx byte 0x%X'
          % (game, peak, len(blits), px, maxoff))
