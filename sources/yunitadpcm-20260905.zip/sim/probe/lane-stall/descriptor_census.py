#!/usr/bin/env python3
# descriptor_census.py -- lane-stall probe, step 1.
# Replays the REAL captured blit descriptor stream (sim/probe/busy-pacing/out/*.blits, captured
# from MAME) through the clip/address math of yunit_dma_family2.sv (lines 165-194, 419-449) and
# reports, per title, the properties that decide the two lane costs:
#   SOURCE lane : is the o_ptr stream contiguous across rows? (rowbytes vs width) -> src_cache
#                 hit rate ceiling, and how many stream RE-TARGETS (flushes) a frame costs.
#   FB lane     : dest beat (entry>>2) occupancy on real geometry -> full be=F beats (1 DDR3
#                 write) vs partial beats (RMW = read + write).
# No RTL is modified; this is a pure descriptor-stream census.
import sys, os, collections

BLITDIR = os.path.join(os.path.dirname(__file__), '..', 'busy-pacing', 'out')

def s32(v):
    v &= 0xFFFFFFFF
    return v - (1 << 32) if v & 0x80000000 else v

def parse(path):
    out = []
    for line in open(path):
        if not line.startswith('BLIT '):
            continue
        f = line.split()
        d = {}
        for tok in f[4:]:
            if '=' in tok:
                k, v = tok.split('=', 1)
                d[k] = v
        try:
            cmd = int(d['CMD'], 16)
            w = int(d['W']); h = int(d['H']); rb = int(d['RB'])
            x = int(d['X']); y = int(d['Y'])
            off = int(d['OFF'], 16)
        except (KeyError, ValueError):
            continue
        out.append((cmd, w, h, rb, x, y, off))
    return out

def clip(cmd, w_in, h_in, rb_in, xs_in, ys_in, gfxoff0):
    """yunit_dma_family2.sv:165-194 (== MAME dma_w:456-518)."""
    flipx = (cmd >> 4) & 1
    rb_in = s32(rb_in); xs_in = s32(xs_in); ys_in = s32(ys_in)
    if flipx:
        rb_adj = (rb_in - w_in + 3) & ~3
        xpos0  = xs_in + w_in - 1
        gfxoff1 = gfxoff0 - ((w_in - 1) << 3)
    else:
        rb_adj = (rb_in + w_in + 3) & ~3
        xpos0  = xs_in
        gfxoff1 = gfxoff0
    ypos1 = 0 if ys_in < 0 else ys_in
    h1a   = (h_in + ys_in) if ys_in < 0 else h_in
    height1 = (512 - ypos1) if (ypos1 + h1a) > 512 else h1a
    if not flipx:
        if xpos0 < 0:
            width_f = w_in + xpos0; xpos_f = 0
        else:
            width_f = w_in; xpos_f = xpos0
        if xpos_f + width_f > 512:
            width_f = 512 - xpos_f
    else:
        if xpos0 >= 512:
            width_f = w_in - (xpos0 - 511); xpos_f = 511
        else:
            width_f = w_in; xpos_f = xpos0
        if xpos_f - width_f < 0:
            width_f = xpos_f
    gfxoff2 = gfxoff1 + 0x02000000 if gfxoff1 < 0x02000000 else gfxoff1
    offbytes = (gfxoff2 - 0x02000000) >> 3
    return flipx, rb_adj, width_f, height1, xpos_f, ypos1, offbytes

def census(title, blits, limit=None):
    if limit:
        blits = blits[:limit]
    n_blit = 0; n_read = 0
    px_total = 0; px_read = 0
    rows_total = 0
    # source lane
    src_contig_rows = 0     # row start == previous row end (perfectly streaming)
    src_gap_rows = collections.Counter()  # gap in BYTES between prev row end and this row start
    src_words = 0
    # fb lane: beat occupancy (assume every pixel writes -- upper bound on full beats)
    beats_full = 0; beats_part = 0
    beat_runs = collections.Counter()   # consecutive-full-beat run lengths (rb burst potential)
    wdist = collections.Counter(); hdist = collections.Counter()
    modes = collections.Counter()
    for (cmd, w, h, rb, x, y, off) in blits:
        mode = cmd & 0xF
        modes[mode] += 1
        n_blit += 1
        flipx, rb_adj, width_c, height_c, xpos_c, ypos_c, offb = clip(cmd, w, h, rb, x, y, off)
        if width_c <= 0 or height_c <= 0:
            continue
        readmode = 1 <= mode <= 0xB
        px = width_c * height_c
        px_total += px
        wdist[min(width_c, 600)] += 1
        hdist[min(height_c, 600)] += 1
        if readmode:
            n_read += 1; px_read += px
        rows_total += height_c
        cur = offb
        prev_end = None
        for r in range(height_c):
            o_ptr = cur
            cur += rb_adj
            if readmode:
                if prev_end is not None:
                    gap = o_ptr - prev_end
                    src_gap_rows[gap if -8 <= gap <= 16 else 'far'] += 1
                    if gap == 0:
                        src_contig_rows += 1
                prev_end = o_ptr + width_c
                src_words += (width_c + 1) // 2
            # ---- fb beats for this row
            ty = (ypos_c + r) & 0x1FF
            if flipx:
                lo_tx = xpos_c - (width_c - 1); hi_tx = xpos_c
            else:
                lo_tx = xpos_c; hi_tx = xpos_c + width_c - 1
            lo_e = (ty << 9) | (lo_tx & 0x1FF)
            hi_e = (ty << 9) | (hi_tx & 0x1FF)
            b0 = lo_e >> 2; b1 = hi_e >> 2
            nb = b1 - b0 + 1
            if nb == 1:
                # single beat, partial unless it covers lanes 0..3
                if (lo_e & 3) == 0 and (hi_e & 3) == 3:
                    beats_full += 1; beat_runs[1] += 1
                else:
                    beats_part += 1
            else:
                first_full = (lo_e & 3) == 0
                last_full  = (hi_e & 3) == 3
                mid = nb - 2
                f = mid + (1 if first_full else 0) + (1 if last_full else 0)
                p = nb - f
                beats_full += f; beats_part += p
                if f > 0:
                    beat_runs[f] += 1
    return dict(title=title, n_blit=n_blit, n_read=n_read, px_total=px_total, px_read=px_read,
                rows_total=rows_total, src_contig_rows=src_contig_rows, src_gap_rows=src_gap_rows,
                src_words=src_words, beats_full=beats_full, beats_part=beats_part,
                beat_runs=beat_runs, wdist=wdist, hdist=hdist, modes=modes)

def report(c):
    print('=' * 78)
    print('TITLE %s   blits=%d  readmode=%d (%.1f%%)  px=%d  readpx=%d  rows=%d' % (
        c['title'], c['n_blit'], c['n_read'], 100.0 * c['n_read'] / max(1, c['n_blit']),
        c['px_total'], c['px_read'], c['rows_total']))
    print('  MODES: ' + ' '.join('%X:%d' % (k, v) for k, v in sorted(c['modes'].items())))
    tot_gap = sum(v for v in c['src_gap_rows'].values())
    print('  SRC row-to-row byte gap (readmode rows, n=%d):' % tot_gap)
    for k, v in sorted(c['src_gap_rows'].items(), key=lambda kv: (kv[0] == 'far', kv[0])):
        print('     gap %-5s %9d  %5.1f%%' % (k, v, 100.0 * v / max(1, tot_gap)))
    bf, bp = c['beats_full'], c['beats_part']
    print('  FB beats: full(be=F, 1 write)=%d  partial(RMW=read+write)=%d  -> %.1f%% full' % (
        bf, bp, 100.0 * bf / max(1, bf + bp)))
    print('  FB beats per written pixel: %.4f   (ideal 0.25)' % ((bf + bp) / max(1, c['px_total'])))
    runs = c['beat_runs']
    tr = sum(runs.values()); tb = sum(k * v for k, v in runs.items())
    print('  FB full-beat run lengths: n_runs=%d mean=%.2f  (RB_MAX=8 caps the burst)' % (
        tr, tb / max(1, tr)))
    hist = collections.Counter()
    for k, v in runs.items():
        hist[min(k, 8) if k < 8 else '>=8'] += v
    print('     ' + ' '.join('%s:%d' % (k, v) for k, v in sorted(hist.items(), key=lambda kv: str(kv[0]))))
    ws = sorted(c['wdist'].items(), key=lambda kv: -kv[1])[:8]
    print('  top widths: ' + ' '.join('%d(x%d)' % (k, v) for k, v in ws))
    hs = sorted(c['hdist'].items(), key=lambda kv: -kv[1])[:8]
    print('  top heights: ' + ' '.join('%d(x%d)' % (k, v) for k, v in hs))

if __name__ == '__main__':
    limit = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    for t in ['smashtv', 'trog', 'hiimpact', 'shimpact', 'totcarn']:
        p = os.path.join(BLITDIR, t + '.blits')
        if not os.path.exists(p):
            continue
        b = parse(p)
        if not b:
            print('%s: ZERO descriptors parsed -- FAIL (coverage 0)' % t)
            continue
        report(census(t, b, limit or None))
