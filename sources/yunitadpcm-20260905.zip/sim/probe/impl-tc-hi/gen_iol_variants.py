#!/usr/bin/env python3
"""gen_iol_variants.py -- build the iol/unpack ownership rigs by TRANSCRIBING the
real top-level source text, so the gate can never drift from the RTL it claims to test.

For each core top we lift TWO verbatim regions out of the file:

  region A : `localparam int IOL_AW` .. `assign unp_ack`
             (the download FIFO, its drain, the boot-channel mux and the unpack ack)
  region B : `logic ... unp_pending ...` .. the line before `yunit_gfx_unpack`
             (the `ifdef SYNTHESIS` arm/acquire block that fires unp_start)

and paste them, UNMODIFIED, into a rig module that supplies exactly the signals the
enclosing top would have supplied.  rig_body.svh (hand written, single sourced) adds
the production yunit_gfx_unpack + yunit_sdram_arb + yunit_sdram_adapter + sdram_stock
+ sdram_chip and the measurement counters.

Variants:
  <tag>_fixed   region text from the WORKING TREE  (the ported unp_owner fix)
  <tag>_prefix  region text from `git show HEAD:`  (the drifted, unfixed text)
  <tag>_mask    region text from HEAD with the WEAKER "mask the ack with ~boot_unp"
                proposal applied mechanically -- the alternative that must be refuted
  f2_base       region text from HEAD with SRC-1b applied mechanically, and NOTHING
                else.  This is the unp_owner-ISOLATION baseline: it differs from
                rig_f2_fixed by the unp_owner edit ALONE.  See SRC1B_SUBS below.
  f2_mut        region text from the WORKING TREE with the unp_owner RELEASE deleted
                (mechanically).  A deliberately broken unp_owner, used to prove the
                cycle-exact comparator still kills a wrong ownership latch.

Because the fix is left UNCOMMITTED, HEAD is a faithful "edit reverted" baseline and
the fixed / prefix rigs are compiled into the SAME simulation.
"""
import hashlib
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", "..", ".."))

TOPS = {
    "donor": "rtl/yunit/yunit_top.sv",
    "f2":    "rtl/yunit/family2/yunit_top_family2.sv",
    "ff":    "rtl/yunit/yunit_top_smash_firefix.sv",
}

A_START = re.compile(r"localparam int IOL_AW")
A_END = re.compile(r"assign unp_ack")
B_START = re.compile(r"^\s*logic .*unp_pending")
B_END = re.compile(r"^\s*yunit_gfx_unpack")


def read_worktree(rel):
    with open(os.path.join(ROOT, rel), "r", encoding="utf-8", errors="replace") as f:
        return f.read()


def read_head(rel):
    out = subprocess.run(["git", "show", "HEAD:" + rel], cwd=ROOT,
                         capture_output=True)
    if out.returncode != 0:
        raise SystemExit("git show HEAD:%s failed: %s" % (rel, out.stderr.decode()))
    return out.stdout.decode("utf-8", errors="replace")


def slice_region(text, rel, start_re, end_re, end_exclusive):
    lines = text.splitlines()
    s = None
    for i, ln in enumerate(lines):
        if start_re.search(ln):
            s = i
            break
    if s is None:
        raise SystemExit("%s: region start not found (%s)" % (rel, start_re.pattern))
    e = None
    for i in range(s, len(lines)):
        if end_re.search(lines[i]):
            e = i
            break
    if e is None:
        raise SystemExit("%s: region end not found (%s)" % (rel, end_re.pattern))
    body = lines[s:e] if end_exclusive else lines[s:e + 1]
    return "\n".join(body), s + 1, (e if end_exclusive else e + 1)


# the weaker proposal: gate the download drain with the COMBINATIONAL ~boot_unp
# (w_boot_unp is the rig's own alias, declared before region A so the substitution
#  does not depend on declaration order inside the transcribed text)
MASK_SUBS = [
    ("if (iol_hold && iol_ack) iol_hold <= 1'b0;",
     "if (iol_hold && iol_ack && !w_boot_unp) iol_hold <= 1'b0;"),
    ("if ((!iol_hold || (iol_hold && iol_ack)) && !iol_empty) begin",
     "if ((!iol_hold || (iol_hold && iol_ack && !w_boot_unp)) && !iol_empty && !w_boot_unp) begin"),
]


# ---------------------------------------------------------------------------
# SRC-1b, transcribed as a MECHANICAL substitution on the HEAD text of
# rtl/yunit/family2/yunit_top_family2.sv region B.
#
# WHY THIS EXISTS.  The working tree of that file carries TWO independent edits
# inside the transcribed regions:
#     unp_owner  (region A: the drain gate + the boot-channel mux + unp_ack)
#     SRC-1b     (region B: arm the unpack on the falling edge of sound_download,
#                 the LAST MRA part, instead of on every ioctl_download edge)
# The gate's serial-scenario comparator is scoped to unp_owner ONLY, so its
# baseline must already contain SRC-1b.  rig_f2_prefix (plain HEAD) contains
# NEITHER edit, which is why comparing against it measures SRC-1b, not unp_owner.
# rig_f2_base = HEAD + exactly the three lines below = unp_owner isolated.
#
# These three substitutions are the complete FUNCTIONAL content of SRC-1b.  The
# working tree's `& ~unp_owner` in the arm guard, the `unp_owner <= 1'b1` acquire
# and the release-on-completion-edge block are all part of the unp_owner edit, not
# SRC-1b, and are deliberately NOT reproduced here -- that is the whole point.
SRC1B_SUBS = [
    ("  logic dl_q, dl_seen, unp_pending, unp_start, unp_fsm_done;",
     "  logic sdl_q, dl_seen, unp_pending, unp_start, unp_fsm_done;   // SRC-1b"),
    ("    dl_q      <= ioctl_download;",
     "    sdl_q     <= sound_download;                                // SRC-1b"),
    ("      if (dl_q & ~ioctl_download)      unp_pending <= 1'b1; // download just ended",
     "      if (sdl_q & ~sound_download)     unp_pending <= 1'b1; // SRC-1b: LAST part ended"),
]

# ---------------------------------------------------------------------------
# The unp_owner MUTANT: acquire kept, RELEASE deleted.  Ownership latches high on
# the first unpack and is never given back, so the download FIFO drain stays gated
# off forever.  Used only as a discriminating instrument -- see tb_iol_ownership.sv.
MUTANT_SUBS = [
    ("      if (unp_owner && unp_fsm_done && !unp_done_q) unp_owner <= 1'b0;",
     "      // MUTANT (generated): the unp_owner release is deleted.\n"
     "      if (1'b0 && unp_owner && unp_fsm_done && !unp_done_q) unp_owner <= 1'b0;"),
]


def apply_subs(text, subs, tag, what):
    out = text
    for old, new in subs:
        if out.count(old) != 1:
            raise SystemExit("%s: %s substitution anchor not unique/found: %r"
                             % (tag, what, old))
        out = out.replace(old, new)
    return out


def apply_mask(region_a, tag):
    return apply_subs(region_a, MASK_SUBS, tag, "mask")


HEADER = """// GENERATED by sim/probe/impl-tc-hi/gen_iol_variants.py -- DO NOT EDIT BY HAND.
// Regions transcribed VERBATIM from %(src)s @ %(rev)s
//   region A  lines %(a0)d..%(a1)d   (download FIFO + drain + boot-channel mux + unp_ack)
//   region B  lines %(b0)d..%(b1)d   (SYNTHESIS arm/acquire block)
// source sha256 %(sha)s
// variant: %(variant)s
`timescale 1ns/1ps
`default_nettype none
module rig_%(name)s #(
  parameter [24:0] SCRATCH_WBASE = 25'h001000,
  parameter [24:0] GFXW_BASE     = 25'h000000,
  parameter [23:0] PW            = 24'd32,
  parameter [24:0] DLBASE        = 25'h004000,
  parameter int    NDL           = 96
)(
  input  wire        clk,
  input  wire        sdram_por,
  input  wire        ioctl_download,
  input  wire        gfx_download,
  input  wire        sound_download,
  input  wire        ioctl_wr,
  input  wire [24:0] ioctl_addr,
  input  wire [15:0] ioctl_dout,
  input  wire [1:0]  ioctl_be,
  output wire        ioctl_wait,
  input  wire        check_now,
  output reg  [31:0] m_pushed,
  output reg  [31:0] m_dropped,
  output reg  [31:0] m_popped,
  output reg  [31:0] m_committed,
  output reg  [31:0] m_presented,
  output reg  [31:0] m_presented_all,
  output reg  [31:0] m_expose,
  output reg  [31:0] m_unpxact,
  output reg  [31:0] m_err_phantom,
  output reg  [31:0] m_err_ackmis,
  output reg  [31:0] m_err_swap,
  output reg  [31:0] m_missing,
  output wire        unp_done_o,
  output wire        unp_busy_o,
  output wire        sdram_ready_o
);
  // ---- signals the real top declares OUTSIDE the transcribed regions ----
  wire iol_ack;                 // yunit_top*.sv: `logic iol_ack;` above the FIFO
  wire download_path_busy;      // donor only; undriven (and unused) in the forks
  wire w_boot_unp;              // rig alias used only by the *_mask variant

// ==================== BEGIN transcribed region A ====================
%(rega)s
// ===================== END transcribed region A =====================

// ==================== BEGIN transcribed region B ====================
%(regb)s
// ===================== END transcribed region B =====================

  assign w_boot_unp = unp_rd | unp_wr;
`include "rig_body.svh"
endmodule
`default_nettype wire
"""


def emit(name, variant, rel, rev, text, sha, mask=False, subs_b=None):
    rega, a0, a1 = slice_region(text, rel, A_START, A_END, False)
    regb, b0, b1 = slice_region(text, rel, B_START, B_END, True)
    if mask:
        rega = apply_mask(rega, name)
    if subs_b is not None:
        subs, what = subs_b
        regb = apply_subs(regb, subs, name, what)
    body = HEADER % dict(src=rel, rev=rev, a0=a0, a1=a1, b0=b0, b1=b1, sha=sha,
                         variant=variant, name=name, rega=rega, regb=regb)
    path = os.path.join(HERE, "rig_%s.sv" % name)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(body)
    print("  rig_%-12s %-46s regionA %d..%d  regionB %d..%d" %
          (name, "(%s @ %s)" % (os.path.basename(rel), rev), a0, a1, b0, b1))


def main():
    # REVERT CHECK: build the "_fixed" rigs from HEAD too, i.e. simulate the edit being
    # reverted.  The gate must then FAIL.  This is what proves the gate discriminates
    # instead of passing on stimulus that never exercises the change.
    revert = os.environ.get("IOL_FIXED_FROM", "").upper() == "HEAD"
    print("gen_iol_variants: root=%s%s" % (ROOT, "   [REVERT CHECK: _fixed := HEAD]" if revert else ""))
    for tag, rel in TOPS.items():
        wt = read_worktree(rel)
        hd = read_head(rel)
        src = hd if revert else wt
        emit("%s_fixed" % tag,
             "git HEAD (REVERT CHECK)" if revert else "working tree (fix applied)",
             rel, "HEAD-REVERTCHECK" if revert else "WORKTREE", src,
             hashlib.sha256(src.encode()).hexdigest()[:16])
        if tag != "donor":
            emit("%s_prefix" % tag, "git HEAD (edit reverted)", rel, "HEAD", hd,
                 hashlib.sha256(hd.encode()).hexdigest()[:16])
            emit("%s_mask" % tag, "git HEAD + weaker ~boot_unp mask proposal", rel,
                 "HEAD+mask", hd, hashlib.sha256(hd.encode()).hexdigest()[:16],
                 mask=True)
        if tag == "f2":
            # unp_owner-ISOLATION baseline: HEAD + SRC-1b and nothing else.  Built
            # from HEAD in BOTH modes (including the revert check) -- it is the
            # fixed reference the serial comparator is scoped against, not a variant
            # of the edit under test.
            emit("f2_base", "git HEAD + SRC-1b only (unp_owner-isolation baseline)",
                 rel, "HEAD+SRC-1b", hd,
                 hashlib.sha256(hd.encode()).hexdigest()[:16],
                 subs_b=(SRC1B_SUBS, "SRC-1b"))
            # Discriminating instrument: always from the WORKING TREE, so the mutant
            # is a broken unp_owner in both modes.
            emit("f2_mut", "working tree + unp_owner RELEASE DELETED (mutant)",
                 rel, "WORKTREE+mutant", wt,
                 hashlib.sha256(wt.encode()).hexdigest()[:16],
                 subs_b=(MUTANT_SUBS, "mutant"))
    print("gen_iol_variants: done")


if __name__ == "__main__":
    main()
