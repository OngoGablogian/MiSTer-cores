#!/usr/bin/env bash
# run_iol_ownership.sh -- regenerate the transcribed rigs from the live sources and run
# the unp_owner boot-channel ownership gate in BOTH scenarios.  iverilog only (no Questa).
#
#   run_iol_ownership.sh                 normal gate; both scenarios must PASS
#   run_iol_ownership.sh --revert-check  rebuild the "_fixed" rigs from git HEAD (i.e.
#                                        the edit reverted) and require the gate to FAIL
#   run_iol_ownership.sh --full          run the gate, then the revert check
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../../.." && pwd)"
cd "$ROOT"

MODE="${1:-normal}"

build_and_run() {   # $1 = IOL_FIXED_FROM value ("" or HEAD)
  IOL_FIXED_FROM="$1" python "$HERE/gen_iol_variants.py" || return 2
  local SRC=(
    "$HERE/rig_donor_fixed.sv" "$HERE/rig_f2_fixed.sv" "$HERE/rig_f2_prefix.sv"
    "$HERE/rig_f2_mask.sv" "$HERE/rig_f2_base.sv" "$HERE/rig_f2_mut.sv"
    "$HERE/rig_ff_fixed.sv" "$HERE/rig_ff_prefix.sv"
    "$HERE/rig_ff_mask.sv"
    "$ROOT/rtl/yunit/yunit_gfx_unpack.sv" "$ROOT/rtl/sdram/yunit_sdram_arb.sv"
    "$ROOT/rtl/sdram/yunit_sdram_adapter.sv" "$ROOT/rtl/sdram/sdram_stock.sv"
    "$ROOT/sim/sdram_chip.sv" "$HERE/tb_iol_ownership.sv"
  )
  echo "--- iverilog elaborate ---"
  iverilog -g2012 -I"$HERE" -o "$HERE/iolown.vvp" "${SRC[@]}" || return 2
  local rc=0
  for o in 1 0; do
    echo
    echo "=============== scenario: OVERLAP=$o ==============="
    vvp "$HERE/iolown.vvp" +OVERLAP=$o || rc=1
  done
  return $rc
}

case "$MODE" in
  --revert-check)
    echo "### REVERT CHECK: the _fixed rigs are rebuilt from git HEAD."
    echo "### The gate MUST FAIL here, otherwise it does not exercise the edit."
    if build_and_run HEAD; then
      echo; echo "REVERT CHECK FAILED: the gate PASSED with the edit reverted."
      exit 1
    else
      echo; echo "REVERT CHECK OK: the gate FAILS with the edit reverted."
      exit 0
    fi
    ;;
  --full)
    build_and_run "" ; rc=$?
    if [ $rc -ne 0 ]; then echo; echo "GATE FAILED"; exit $rc; fi
    echo; echo "ALL SCENARIOS PASS"
    echo; bash "$0" --revert-check
    ;;
  *)
    build_and_run ""
    rc=$?
    echo
    if [ $rc -eq 0 ]; then echo "ALL SCENARIOS PASS"; else echo "GATE FAILED"; fi
    exit $rc
    ;;
esac
