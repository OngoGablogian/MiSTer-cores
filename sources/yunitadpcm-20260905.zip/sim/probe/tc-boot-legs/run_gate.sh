#!/usr/bin/env bash
# Total Carnage boot-leg gates.  iverilog only (no Questa, no licence).
set -euo pipefail
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
D="$ROOT/sim/probe/tc-boot-legs"

# The IOL_ACK_STEAL leg is RETIRED (2026-08-16). It patched the pre-fix drain
# ("iol_ack & ~boot_unp") onto a verbatim extraction of the shipping text -- but
# the fix has since LANDED in a STRONGER form (the `!unp_owner` session-ownership
# drain gate, commit ee41a2b, present in the shipping ADPCM RBF), so the
# extraction was re-deriving a fix on top of the fix and its hardcoded [655:709]
# line window had gone stale besides. The landed gate is exercised by the
# romhole sufficiency sweep (sim/probe/mk-romhole) and by silicon. Keeping a
# mutation harness for a defect that no longer exists in the tree is scaffolding
# (DESIGN-RULES.md section 7); boot_rate below remains the live throughput leg.

COMMON=("$ROOT/rtl/sdram/yunit_sdram_arb.sv" "$ROOT/rtl/sdram/yunit_sdram_adapter.sv"
        "$ROOT/rtl/sdram/sdram_stock.sv" "$ROOT/rtl/yunit/yunit_gfx_unpack.sv"
        "$ROOT/sim/sdram_chip.sv")

iverilog -g2012 -s tb_boot_rate -o "$D/tb_boot_rate.vvp" "${COMMON[@]}" "$D/tb_boot_rate.sv" 2>&1 | grep -v "sorry:" || true
(cd "$ROOT/sim" && vvp "$D/tb_boot_rate.vvp") | tee "$D/boot_rate.log"

grep -q "^PASS: BOOT_RATE"      "$D/boot_rate.log"      || { echo "GATE FAIL: boot_rate"; exit 1; }
echo "TC-BOOT-LEGS: PASS (boot_rate; iol_ack_steal retired -- its fix landed as the unp_owner drain gate)"
