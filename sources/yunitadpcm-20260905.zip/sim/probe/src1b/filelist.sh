#!/usr/bin/env bash
# filelist.sh -- emit (NUL-separated) the SystemVerilog dependency set of
# yunit_top_family2, in the SAME dependency order quartus/build_sv2v.sh uses.
# The core top itself is NOT included: the caller supplies it, so the revert
# check can substitute a modified copy of exactly that one file.
#
# Usage:  mapfile -d '' SRC < <(bash filelist.sh "$ROOT")
ROOT="$1"
SV=( "$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SV+=("$f"); done \
  < <(find "$ROOT/rtl/tms34010/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SV+=( "$ROOT/rtl/yunit/yunit_protection.sv" "$ROOT/rtl/yunit/yunit_nvram_bridge.sv" \
      "$ROOT/rtl/yunit/yunit_mem.sv" "$ROOT/rtl/yunit/yunit_dma.sv" \
      "$ROOT/rtl/yunit/yunit_dma_logical_timer.sv" "$ROOT/rtl/yunit/yunit_dma_descriptor_fifo.sv" \
      "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
      "$ROOT/rtl/yunit/vram_sdram_scanout.sv" \
      "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
      "$ROOT/rtl/yunit/yunit_memsys.sv" \
      "$ROOT/rtl/yunit/yunit_display_address_sequencer.sv" \
      "$ROOT/rtl/yunit/yunit_autoerase_scheduler.sv" \
      "$ROOT/rtl/yunit/yunit_autoerase_sdram_backend.sv" \
      "$ROOT/rtl/yunit/yunit_shiftreg_engine.sv" \
      "$ROOT/rtl/yunit/yunit_vram_word_arb.sv" \
      "$ROOT/rtl/yunit/yunit_video.sv" "$ROOT/rtl/yunit/yunit_scanline.sv" \
      "$ROOT/rtl/yunit/yunit_video_top.sv" "$ROOT/rtl/yunit/yunit_palram.sv" \
      "$ROOT/rtl/sdram/yunit_sdram_arb.sv" "$ROOT/rtl/sdram/yunit_sdram_burst_arb.sv" \
      "$ROOT/rtl/sdram/sdram_stock.sv" "$ROOT/rtl/sdram/yunit_sdram_adapter.sv" \
      "$ROOT/rtl/sdram/yunit_src_cache.sv" \
      "$ROOT/rtl/yunit/yunit_gfx_unpack.sv" \
      "$ROOT/rtl/yunit/yunit_download_mapper.sv" \
      "$ROOT/rtl/video/crt_adjust.sv" "$ROOT/rtl/video/yunit_crt_adjust.sv" \
      "$ROOT/rtl/yunit/yunit_mem_cdc.sv" "$ROOT/rtl/yunit/yunit_sound_cdc.sv" \
      "$ROOT/rtl/yunit/yunit_sound_rom_cache.sv" "$ROOT/rtl/yunit/yunit_audio_mix.sv" \
      "$ROOT/rtl/yunit/yunit_adpcm_board.sv" "$ROOT/rtl/yunit/yunit_input_mapper.sv" \
      "$ROOT/rtl/yunit/yunit_cpu_cadence.sv" \
      "$ROOT/rtl/yunit/yunit_service_counters.sv" \
      "$ROOT/rtl/yunit/family2/family2_cabinet_inputs.sv" \
      "$ROOT/rtl/yunit/family2/family2_download_mapper.sv" \
      "$ROOT/rtl/yunit/family2/yunit_mem_family2.sv" "$ROOT/rtl/yunit/family2/yunit_dma_family2.sv" \
      "$ROOT/rtl/yunit/family2/yunit_memsys_family2.sv" "$ROOT/rtl/yunit/family2/yunit_video_family2.sv" \
      "$ROOT/rtl/yunit/family2/yunit_scanline_family2.sv" \
      "$ROOT/rtl/yunit/family2/yunit_video_top_family2.sv" )
printf '%s\0' "${SV[@]}"
