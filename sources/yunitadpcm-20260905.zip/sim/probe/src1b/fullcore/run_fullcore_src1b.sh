#!/usr/bin/env bash
# run_fullcore_src1b.sh -- SRC-1b gate on the FULL yunit_top_family2 hierarchy.
#
# The core is converted by sv2v with EXACTLY the shipping Family2 core-blob token set
#   -DSYNTHESIS -DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_CVSD_BRAM_SOUND
# (quartus/build_sv2v.sh:52 + quartus/build_hw.sh:204-215), then simulated with iverilog.
# No Questa.  Nothing is written outside sim/probe/src1b/fullcore/ (build_syn/ is shared
# with the Quartus flow and with sibling sessions -- never touched here).
#
# The core top under test is a SNAPSHOT (snap_fixed.sv), not the live file, so a
# concurrent editor cannot change what was gated.  snap_reverted.sv is produced from that
# same snapshot by a surgical, count-checked substitution of ONLY the SRC-1b arm.
#
#   run_fullcore_src1b.sh            gate + revert check
#   run_fullcore_src1b.sh --gate     gate only
set -uo pipefail
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../../../.." && pwd)"
SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
DEFS=(-DSYNTHESIS -DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_CVSD_BRAM_SOUND)
LIVE="$ROOT/rtl/yunit/family2/yunit_top_family2.sv"

# ---------------------------------------------------------------- snapshot + revert
if [ ! -f "$HERE/snap_fixed.sv" ]; then
  cp "$LIVE" "$HERE/snap_fixed.sv"
fi
echo "gated snapshot sha256: $(sha256sum "$HERE/snap_fixed.sv" | cut -d' ' -f1)"
echo "live file    sha256: $(sha256sum "$LIVE" | cut -d' ' -f1)"

# Surgical revert of ONLY SRC-1b: sample and edge-detect ioctl_download again.
# Each substitution MUST match exactly once, or the revert check is not a revert.
python - "$HERE/snap_fixed.sv" "$HERE/snap_reverted.sv" <<'PY' || exit 2
import sys, re
src, dst = sys.argv[1], sys.argv[2]
t = open(src, encoding='utf-8', errors='surrogateescape').read()
subs = [
  ("sdl_q     <= sound_download;", "sdl_q     <= ioctl_download;  // REVERTED"),
  ("if (sdl_q & ~sound_download)", "if (sdl_q & ~ioctl_download)"),
]
for a, b in subs:
    n = t.count(a)
    if n != 1:
        print(f"REVERT-GEN FAIL: {a!r} occurs {n} times, expected 1")
        sys.exit(2)
    t = t.replace(a, b)
open(dst, 'w', encoding='utf-8', errors='surrogateescape').write(t)
print("revert generated: 2/2 substitutions applied")
PY

# ---------------------------------------------------------------- vhdl stub (sound board)
[ -f "$HERE/../williams_cvsd_board_stub.v" ] || \
  python "$ROOT/tools/gen_vhdl_stub.py" \
    "$ROOT/rtl/sound/williams_cvsd/williams_cvsd_board.vhd" williams_cvsd_board \
    > "$HERE/williams_cvsd_board_stub.v"
STUB="$HERE/williams_cvsd_board_stub.v"
[ -f "$STUB" ] || STUB="$HERE/../williams_cvsd_board_stub.v"

# ---------------------------------------------------------------- build one flavour
build() {   # $1 = tag, $2 = core-top source file
  local tag="$1" top="$2"
  mapfile -d '' SRC < <(bash "$HERE/filelist.sh" "$ROOT")
  echo "--- sv2v ($tag): ${#SRC[@]} deps + $(basename "$top") ---"
  "$SV2V" "${DEFS[@]}" "${SRC[@]}" "$top" > "$HERE/core_$tag.v" 2> "$HERE/sv2v_$tag.err"
  local rc=$?
  if [ $rc -ne 0 ] || [ ! -s "$HERE/core_$tag.v" ]; then
    echo "sv2v FAILED for $tag"; sed -n '1,25p' "$HERE/sv2v_$tag.err"; return 2
  fi
  grep -q "module yunit_top_family2" "$HERE/core_$tag.v" || {
    echo "sv2v output lost yunit_top_family2 ($tag)"; return 2; }
  echo "--- iverilog ($tag) ---"
  iverilog -g2012 -s tb_arm_fullcore -o "$HERE/src1b_$tag.vvp" \
    "$HERE/core_$tag.v" "$STUB" \
    "$ROOT/sim/sdram_chip.sv" "$ROOT/sim/ddr3_avalon_model.sv" \
    "$HERE/tb_arm_fullcore.sv" || return 2
  return 0
}

run() {     # $1 = tag, $2.. = plusargs ; prints the log, returns 0 only on RESULT: PASS
  local tag="$1"; shift
  local log="$HERE/run_${tag}_$(echo "$*" | tr -c 'A-Za-z0-9' '_').log"
  ( cd "$HERE" && vvp "$HERE/src1b_$tag.vvp" "$@" ) > "$log" 2>&1
  grep -E "^\[src1b\]|^FAIL|^HAZARD|^RESULT" "$log" | head -40
  grep -q "^RESULT: PASS" "$log"
}

# ---------------------------------------------------------------- gate
rc=0
build fixed "$HERE/snap_fixed.sv" || exit 2

echo; echo "=========== FIXED / multi-index MRA (3,4,0,1,2) / fast HPS (BYTEPER=2) ==========="
run fixed +MODE=multi +BYTEPER=2 || rc=1
echo; echo "=========== FIXED / multi-index MRA (3,4,0,1,2) / slow HPS (BYTEPER=8) ==========="
run fixed +MODE=multi +BYTEPER=8 || rc=1
echo; echo "=========== FIXED / REGRESSION ARM: single-index MRA, no index 2 ==========="
run fixed +MODE=single +BYTEPER=2 || rc=1

if [ "${1:-}" = "--gate" ]; then
  echo; [ $rc -eq 0 ] && echo "GATE PASS" || echo "GATE FAIL"; exit $rc
fi

# ---------------------------------------------------------------- revert check
build reverted "$HERE/snap_reverted.sv" || exit 2
echo; echo "=========== REVERTED / multi-index MRA / fast HPS -- MUST FAIL ==========="
if run reverted +MODE=multi +BYTEPER=2; then
  echo "REVERT CHECK FAILED: the gate PASSED with SRC-1b reverted -- it does not exercise the edit."
  rc=1
else
  echo "REVERT CHECK OK: the gate FAILS with SRC-1b reverted."
fi
echo; echo "=========== REVERTED / single-index MRA (contrast, informational) ==========="
run reverted +MODE=single +BYTEPER=2 && echo "(reverted+single passes: the old arm did fire)" \
                                      || echo "(reverted+single did not pass -- see log)"

# ---------------------------------------------------------------- timing matrix
# GAP is the inter-part gap.  It must be >= the FIFO drain so the PRE-fix build can
# actually arm inside the gap; below that it arms fewer than 3 times and the pre-fix
# cost is understated.  BYTEPER=8 is the unsaturated-HPS point (no rate-mismatch
# backpressure), so every ioctl_wait cycle reported here is unpack-induced.
echo
echo "=========== boot-time / backpressure matrix (BYTEPER=8) ==========="
printf "%-8s %-9s %-8s %-9s %-12s %-12s\n" GAP build passes overlap boot_span wait_max
for g in 500 1000 2000 4000 12000; do
  for tag in reverted fixed; do
    o=$( cd "$HERE" && vvp "$HERE/src1b_$tag.vvp" +MODE=multi +BYTEPER=8 +GAP=$g 2>&1 )
    printf "%-8s %-9s %-8s %-9s %-12s %-12s\n" "$g" "$tag" \
      "$(echo "$o" | grep -o 'unp_start=[0-9]*' | head -1 | cut -d= -f2)" \
      "$(echo "$o" | grep -o 'overlap_cycles=[0-9]*' | cut -d= -f2)" \
      "$(echo "$o" | grep -o 'boot_span=[-0-9]*' | cut -d= -f2)" \
      "$(echo "$o" | grep -o 'longest_run=[0-9]*' | cut -d= -f2)"
  done
done

# ---------------------------------------------------------------- MRA contract
echo
echo "=========== MRA index-order contract (the arm's precondition) ==========="
python "$HERE/check_mra_contract.py" || rc=1

echo
[ $rc -eq 0 ] && echo "GATE PASS" || echo "GATE FAIL"
exit $rc
