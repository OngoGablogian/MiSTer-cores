#!/usr/bin/env python3
"""check_mra_index_contract.py -- SRC-1b MRA index-order contract gate.

SRC-1b (rtl/yunit/family2/yunit_top_family2.sv:~792) arms the boot gfx unpack on the
FALLING EDGE OF sound_download instead of on every ioctl_download falling edge, so no
unpack pass is ever concurrent with a download stream.  Under the shipping flavours
Arcade-SmashTV.sv:497 defines

    wire sound_download = ioctl_download & (ioctl_index == 8'd2);

so "sound_download falls" means "the index-2 part finished".  That is only equal to
"the WHOLE download finished" while index 2 is the LAST part in the MRA.

If a future MRA drops index 2, or emits it empty, or puts another part after it, then
sound_download never falls (or falls early):
  * never falls  -> unp_pending never sets -> the unpack never runs -> unp_done stays
                    low -> core_rst is held forever -> BLACK SCREEN, no diagnostic.
  * falls early  -> the unpack runs concurrently with the remaining stream, which is
                    exactly the exposure SRC-1b exists to remove.

Nothing else in the tree checks this, so the contract is machine-checked here.

CONTRACT, asserted per MRA:
  C1  an index-2 <rom> element exists
  C2  it carries at least one part (a non-empty download stream, so the ioctl pulse
      actually rises and can fall)
  C3  no <rom>/<nvram> element with a HIGHER index appears after it in document order
  C4  index 2 is the LAST download-bearing element in document order

...and once, on the generator itself:
  C5  tools/generate_yunit_mras.py emits index 2 last in its hardcoded part list

Usage:
    python sim/probe/src1b/check_mra_index_contract.py            # all known MRA sets
    python sim/probe/src1b/check_mra_index_contract.py DIR [DIR]  # explicit dirs
    python sim/probe/src1b/check_mra_index_contract.py --self-test
        mutate copies of a real MRA into each violating shape and require the gate to
        REJECT every one (coverage: proves the gate is not a rubber stamp)

Exit 0 = contract holds.  Non-zero = violation, or ZERO FILES FOUND.
iverilog/Questa not involved; pure file inspection.
"""
from __future__ import annotations

import re
import shutil
import sys
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]

# Every directory in the tree that holds a generated shipping MRA set.  The gate walks
# all of them: a stale set that still ships is just as fatal as a fresh bad one.
CANDIDATE_DIRS = [
    "staging/YUNIT-DELIVERY/_Arcade",
    "staging/_Arcade",
    "releases/yunit",
    "releases/family2",
    "releases/Y-unit",
    "releases/siblings",
    "sim/build/contract-mras",
    "staging/yunit-full-e519fcf/_Arcade",
    "staging/yunit-full-aa58db7/_Arcade",
    "staging/yunit-full-589e26e/_Arcade",
    "build_syn/package-input-aa58db7",
]

# The RECOVERY build is deliberately OUT OF SCOPE.  Its MRA carries gfx+program+sound
# in a SINGLE index 0 and it selects rtl/yunit/yunit_top_smash_firefix.sv, whose arm
# condition SRC-1b does not touch (Arcade-SmashTV.sv:569 derives sound_download from an
# ADDRESS WINDOW there, so its edges land mid-stream by design).  Gating it against this
# contract would be a false failure.
EXCLUDED_DIRS = {"releases", "releases/recovery", "staging/TEST-CVSD/_Arcade"}

REQUIRED_INDEX = 2
DOWNLOAD_TAGS = ("rom", "nvram")


class Violation(Exception):
    pass


def part_order(mra: Path) -> list[tuple[str, int, int]]:
    """Document-order list of (tag, index, n_parts) for every download-bearing element.

    Parsed from the XML tree, not by regex, so an index buried in an attribute string
    or a comment cannot spoof the order.
    """
    root = ET.parse(mra).getroot()
    out: list[tuple[str, int, int]] = []
    for el in root:
        if el.tag not in DOWNLOAD_TAGS:
            continue
        raw = el.get("index")
        if raw is None:
            continue
        # An element's stream is non-empty if it has <part> children, or (for <rom>)
        # inline text.  <nvram size=...> with no parts is a save-file slot, which
        # MiSTer may deliver as its own ioctl pulse -- it still counts for ORDER (C3),
        # so it is recorded with n_parts as measured.
        n_parts = len(el.findall("part"))
        if n_parts == 0 and (el.text or "").strip():
            n_parts = 1
        out.append((el.tag, int(raw, 0), n_parts))
    return out


def check_one(mra: Path) -> list[tuple[str, int, int]]:
    order = part_order(mra)
    if not order:
        raise Violation("no indexed <rom>/<nvram> elements at all")

    hits = [i for i, (_, idx, _) in enumerate(order) if idx == REQUIRED_INDEX]
    if not hits:                                                            # C1
        raise Violation(
            f"NO index-{REQUIRED_INDEX} part -> sound_download never pulses -> the "
            f"SRC-1b unpack never arms -> core_rst held -> black screen"
        )
    pos = hits[-1]
    tag, _, n_parts = order[pos]

    if n_parts == 0:                                                        # C2
        raise Violation(
            f"index-{REQUIRED_INDEX} <{tag}> carries ZERO parts -> empty stream -> "
            f"no ioctl_download pulse to fall on"
        )

    tail = order[pos + 1:]
    later_higher = [(t, i) for (t, i, _) in tail if i > REQUIRED_INDEX]
    if later_higher:                                                        # C3
        raise Violation(
            f"index {later_higher[0][1]} (<{later_higher[0][0]}>) appears AFTER "
            f"index {REQUIRED_INDEX}"
        )
    if tail:                                                                # C4
        raise Violation(
            f"index {REQUIRED_INDEX} is not last; followed by "
            + ", ".join(f"<{t}> index {i}" for (t, i, _) in tail)
        )
    return order


GEN = ROOT / "tools" / "generate_yunit_mras.py"
GEN_INDEX_RE = re.compile(r'index="(\d+)"')


def check_generator() -> str:
    """C5 -- the generator HARDCODES the part order in a literal list, so assert on the
    constant, not only on its outputs.  Outputs alone would pass a tree that was
    generated before a bad edit and regenerated wrong tomorrow."""
    if not GEN.exists():
        raise Violation(f"generator not found at {GEN}")
    text = GEN.read_text(encoding="utf-8")
    lines = text.splitlines()
    # The emitted MRA body is the `lines = [ ... ]` literal; take the index="N" tokens
    # in source order from the first `<misterromdescription>` to `</misterromdescription>`.
    try:
        lo = next(i for i, l in enumerate(lines) if "<misterromdescription>" in l)
        hi = next(i for i, l in enumerate(lines) if "</misterromdescription>" in l)
    except StopIteration:
        raise Violation("could not locate the emitted MRA literal in the generator")
    emitted = [int(m) for l in lines[lo:hi] for m in GEN_INDEX_RE.findall(l)]
    if not emitted:
        raise Violation("generator emits no index= tokens (structure changed)")
    if REQUIRED_INDEX not in emitted:
        raise Violation(f"generator never emits index {REQUIRED_INDEX}")
    if emitted[-1] != REQUIRED_INDEX:
        raise Violation(
            f"generator hardcodes {emitted} -- index {REQUIRED_INDEX} is NOT last "
            f"(last is {emitted[-1]}); generated MRAs will break SRC-1b"
        )
    return f"{GEN.relative_to(ROOT)}:{lo + 1}-{hi + 1} hardcodes {emitted}"


def run(dirs: list[Path], verbose: bool = True) -> int:
    files: list[Path] = []
    used: list[Path] = []
    for d in dirs:
        found = sorted(d.glob("*.mra"))
        if found:
            used.append(d)
            files.extend(found)

    if verbose:
        print("== SRC-1b MRA index-order contract gate")
        print(f"   root: {ROOT}")
        for d in used:
            try:
                rel = d.relative_to(ROOT)
            except ValueError:
                rel = d
            print(f"   set:  {rel}  ({len(sorted(d.glob('*.mra')))} MRA)")

    if not files:                                                # FAIL AT ZERO
        print(f"FAIL: ZERO MRA FILES FOUND in {[str(d) for d in dirs]} "
              f"-- a gate over nothing is not a gate")
        return 2

    fails = 0
    for f in files:
        try:
            rel = f.relative_to(ROOT)
        except ValueError:
            rel = f
        try:
            order = check_one(f)
            shape = " ".join(f"{t}:{i}" + ("" if n else "(empty)")
                             for (t, i, n) in order)
            if verbose:
                print(f"  OK    {rel}\n           order = [{shape}]")
        except Violation as e:
            fails += 1
            print(f"  FAIL  {rel}\n           {e}")
        except ET.ParseError as e:
            fails += 1
            print(f"  FAIL  {rel}\n           unparseable XML: {e}")

    try:
        where = check_generator()
        if verbose:
            print(f"  OK    generator constant: {where}")
    except Violation as e:
        fails += 1
        print(f"  FAIL  generator constant: {e}")

    print(f"\n   checked {len(files)} MRA across {len(used)} set(s) + 1 generator "
          f"constant; {fails} violation(s)")
    if fails:
        print("GATE FAILED -- SRC-1b's arm precondition is not universally true.")
        return 1
    print("GATE PASSED -- index 2 present, non-empty and last in every MRA.")
    return 0


# --------------------------------------------------------------------------- self-test
MUTATIONS = {
    "drop index 2 entirely":
        lambda s: re.sub(r'    <rom index="2".*?</rom>\n', "", s, flags=re.S),
    "index 2 present but EMPTY":
        lambda s: re.sub(r'(    <rom index="2"[^>]*>).*?(</rom>)', r"\1\2", s,
                         flags=re.S),
    "index 3 moved AFTER index 2":
        lambda s: re.sub(r'    <rom index="3">(.*?)</rom>\n', "", s, flags=re.S)
                    .replace("</misterromdescription>",
                             '    <rom index="3"><part>08</part></rom>\n'
                             "</misterromdescription>"),
    "index 1 moved AFTER index 2 (lower index, still not last)":
        lambda s: s.replace("</misterromdescription>",
                            '    <rom index="1" zip="z.zip">'
                            '<part repeat="0x10">00</part></rom>\n'
                            "</misterromdescription>"),
}


def self_test() -> int:
    src = next((ROOT / "staging/YUNIT-DELIVERY/_Arcade").glob("*.mra"), None)
    if src is None:
        print("FAIL: self-test needs at least one real MRA to mutate")
        return 2
    print(f"== self-test: mutating {src.name} into each violating shape")
    print("   the gate MUST REJECT every one\n")
    bad = 0
    with tempfile.TemporaryDirectory() as td:
        for name, mutate in MUTATIONS.items():
            d = Path(td) / re.sub(r"\W+", "_", name)
            d.mkdir()
            text = src.read_text(encoding="utf-8")
            mutated = mutate(text)
            if mutated == text:
                print(f"  INCONCLUSIVE  {name}: mutation did not change the file")
                bad += 1
                continue
            (d / src.name).write_text(mutated, encoding="utf-8")
            try:
                check_one(d / src.name)
            except (Violation, ET.ParseError) as e:
                print(f"  REJECTED  {name}\n              -> {e}")
                continue
            print(f"  ESCAPED   {name}  <-- the gate accepted a broken MRA")
            bad += 1

        # positive control: the unmutated file must still pass
        d = Path(td) / "control"
        d.mkdir()
        shutil.copy(src, d / src.name)
        try:
            check_one(d / src.name)
            print("  ACCEPTED  unmutated control (positive control)")
        except (Violation, ET.ParseError) as e:
            print(f"  BROKEN    unmutated control REJECTED: {e}")
            bad += 1

        # zero-files control: an empty directory must FAIL, not vacuously pass
        empty = Path(td) / "empty"
        empty.mkdir()
        if run([empty], verbose=False) == 0:
            print("  ESCAPED   zero-files directory passed vacuously")
            bad += 1
        else:
            print("  REJECTED  zero-files directory (fail-at-zero holds)")

    print(f"\n   {len(MUTATIONS)} mutations + 2 controls; {bad} escape(s)")
    if bad:
        print("SELF-TEST FAILED -- the gate does not discriminate.")
        return 1
    print("SELF-TEST PASSED -- every violating shape is caught.")
    return 0


def main(argv: list[str]) -> int:
    if "--self-test" in argv:
        return self_test()
    args = [a for a in argv if not a.startswith("--")]
    if args:
        dirs = [Path(a).resolve() for a in args]
    else:
        dirs = [ROOT / d for d in CANDIDATE_DIRS
                if d not in EXCLUDED_DIRS and (ROOT / d).is_dir()]
    return run(dirs)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
