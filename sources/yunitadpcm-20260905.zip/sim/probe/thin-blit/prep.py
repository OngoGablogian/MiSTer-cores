#!/usr/bin/env python3
"""Stage Total Carnage's captured ROAD blits for an RTL replay.

The road is drawn as ~49 blits per frame of w=200, h=1 -- one per scanline
(measured, MAME 0.289, mame-trace/blit_vram_oracle.lua -> tc_regs_oracle.txt).
Strike Force and Saurian Front use the same thin-blit shape in bursts (37.5 and
31.0 per frame in the frames that use it) while Smash T.V., the only
cabinet-proven control with a per-instruction golden, issues 1.2 -- so this
path is structurally under-exercised by our oracle title.

Emits three files:
  src.hex       the exact unpacked-gfx bytes the blits read, based at SRC_BASE
  desc.txt      the descriptors, one per line, in register order
  expected.txt  the pixel writes gospel produces, computed HERE from
                midyunit_v.cpp dma_draw -- an INDEPENDENT transcription, so a
                shared-convention error between bench and RTL cannot hide
                (the Gladiator lesson: oracle and RTL agreed for 1.16M pixels
                while both had the pen order reversed).
"""
import pathlib, sys, zipfile

# repo root = .../yunit-clean ; the trace + roms live beside it under fpga/
REPO = pathlib.Path(__file__).resolve().parents[3]     # .../yunit-clean
FPGA = REPO.parent                                     # .../fpga
TRACE = FPGA / "smash tv" / "mame-trace" / "tc_regs_oracle.txt"
OUT = pathlib.Path(__file__).resolve().parent
ROMS = FPGA / "smash tv" / "roms"

sys.path.insert(0, str(REPO / "tools"))
from yunit_rom_selftest import build_unpacked_gfx  # the validated 6bpp unpack

gfx = build_unpacked_gfx(ROMS / "totcarn.zip", "totcarn")
print(f"totcarn unpacked image: {len(gfx):#x} bytes")

descs = []
for line in TRACE.read_text().split("\n"):
    f = line.split()
    if len(f) != 11:
        continue
    bidx = int(f[0])
    r = [int(x, 16) for x in f[1:]]
    descs.append((bidx, r))
if not descs:
    raise SystemExit("no descriptors -- re-run blit_vram_oracle.lua")

def s16(v):
    return v - 0x10000 if v >= 0x8000 else v

# ---- gospel dma_w + dma_draw, transcribed here from midyunit_v.cpp ----------
lo = hi = None
writes = []
for bidx, r in descs:
    cmd, rowb, offlo, offhi = r[0], r[1], r[2], r[3]
    xs, ys, w, h = s16(r[4]), s16(r[5]), r[6], r[7]
    pal, col = r[8], r[9]
    gfxoffset = (offhi << 16) | offlo
    flipx = bool(cmd & 0x10)
    dx = -1 if flipx else 1
    if flipx:
        gfxoffset -= (w - 1) * 8
        rb = (rowb - w + 3) & ~3
        xs = xs + w - 1
    else:
        rb = (rowb + w + 3) & ~3
    # Y clip
    ypos, height = ys, h
    if ypos < 0:
        height -= -ypos
        ypos = 0
    if ypos + height > 512:
        height = 512 - ypos
    # X clip (non-flip path; all captured road blits are non-flip)
    xpos, width = xs, w
    if not flipx:
        if xpos < 0:
            width += xpos
            xpos = 0
        if xpos + width > 512:
            width = 512 - xpos
    # dma_w:515-518 -- the clip-time source adjustments are OVERWRITTEN here
    if gfxoffset < 0x02000000:
        gfxoffset += 0x02000000
    offset = gfxoffset - 0x02000000
    pal16 = (pal << 8) & 0xFFFF
    color16 = (pal16 | (col & 0xFF)) & 0xFFFF
    mode = cmd & 0x0F
    o_byte = offset >> 3
    if lo is None or o_byte < lo:
        lo = o_byte
    end = o_byte + rb * max(height, 0) + width
    if hi is None or end > hi:
        hi = end
    for y in range(height):
        ty = (ypos + y) & 0x1FF
        o = o_byte + rb * y
        tx = xpos
        for x in range(width):
            px = gfx[o + x]
            if mode == 2:
                if px != 0:
                    writes.append((bidx, ty * 512 + (tx & 0x1FF), pal16 | px))
            elif mode == 3:
                writes.append((bidx, ty * 512 + (tx & 0x1FF), pal16 | px))
            elif mode in (0xC, 0xD, 0xE, 0xF):
                writes.append((bidx, ty * 512 + (tx & 0x1FF), color16))
            tx += dx

SRC_BASE = lo & ~0xF
span = (hi - SRC_BASE) + 16
(OUT / "src.hex").write_text("\n".join(f"{b:02x}" for b in gfx[SRC_BASE:SRC_BASE + span]) + "\n")
(OUT / "desc.txt").write_text("".join(
    " ".join(f"{v:04x}" for v in r) + "\n" for _, r in descs))
(OUT / "expected.txt").write_text("".join(f"{b} {a:x} {v:04x}\n" for b, a, v in writes))
(OUT / "params.vh").write_text(
    f"localparam int SRC_BASE = 'h{SRC_BASE:x};\n"
    f"localparam int SRC_SPAN = {span};\n"
    f"localparam int NDESC    = {len(descs)};\n")
print(f"descriptors {len(descs)}  expected pixel writes {len(writes)}")
print(f"src window base {SRC_BASE:#x} span {span} bytes")
