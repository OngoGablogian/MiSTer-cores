#!/bin/bash
# Smash T.V. sound-command-port census. MAME 0.280.
#   phase 1: warm the NVRAM (no script) so the cold-boot "factory settings"
#            flow is not what we measure;
#   phase 2: install the tap and census.
set -u
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$D/out" "$D/cfg" "$D/nvram" "$D/snap"

ARM="${1:-attract}"      # attract | play
SECS="${2:-60}"
G="${3:-smashtv}"
WARM="${4:-45}"
PLAY=0; [ "$ARM" = "play" ] && PLAY=1

rm -rf "$D/nvram/$ARM"; mkdir -p "$D/nvram/$ARM"
if [ "$WARM" != "0" ]; then
  "$MAME" "$G" -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$D/nvram/$ARM" \
    -video none -sound none -seconds_to_run "$WARM" -nothrottle -skip_gameinfo \
    > "$D/out/${G}_${ARM}_warm.log" 2>&1
fi

SP_OUT="$D/out/${G}_${ARM}.txt" SP_TRACE="$D/out/${G}_${ARM}_trace.txt" \
SP_SECS="$SECS" SP_PLAY="$PLAY" SP_SNAP="${SP_SNAP:-0}" \
"$MAME" "$G" -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$D/nvram/$ARM" \
  -snapshot_directory "$D/snap/$ARM" \
  -autoboot_script "$D/capture_sndport.lua" -autoboot_delay 0 \
  -video none -sound none -seconds_to_run $((SECS+30)) -nothrottle -skip_gameinfo \
  > "$D/out/${G}_${ARM}.log" 2>&1
echo "== $G/$ARM"
head -8 "$D/out/${G}_${ARM}.txt" 2>/dev/null || tail -20 "$D/out/${G}_${ARM}.log"
