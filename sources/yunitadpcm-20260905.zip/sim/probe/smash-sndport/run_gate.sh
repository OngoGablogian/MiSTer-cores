#!/bin/bash
# Self-proving gate for the PROPOSED sound-board heartbeat counters.
# iverilog only -- no Questa licence, parallel-safe.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$D/work"
iverilog -g2012 -s tb_snd_heartbeat -o "$D/work/hb.vvp" \
  "$D/yunit_snd_heartbeat.sv" "$D/tb_snd_heartbeat.sv"
LOG="$D/work/hb.log"
vvp "$D/work/hb.vvp" | tee "$LOG"
grep -q "^PASS: SND_HEARTBEAT" "$LOG" || { echo "GATE FAILED"; exit 1; }
grep -q "MUTATION KILL" "$LOG" || { echo "GATE VACUOUS: no mutation kill reported"; exit 1; }
grep -q "^  FAIL" "$LOG" && { echo "GATE FAILED (assertion)"; exit 1; }
echo "GATE OK"
