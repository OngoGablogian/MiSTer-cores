#!/usr/bin/env python3
"""Compare the integrated-top DMA launch stream against MAME in order.

The Questa harness prints one ``[TOP-B]`` line at the production yunit_dma
launch boundary.  This checker streams MAME's large trace and reports the first
command-field divergence without loading the pixel records into memory.
"""

import argparse
import re


FIELDS = ("CMD", "X", "Y", "W", "H", "SAG", "RB", "COL", "PAL")
TOP_RE = re.compile(r"\[TOP-B\]\s+B=(\d+)\s+.*?\s+CMD=([0-9a-fA-F]+)\s+"
                    r"X=(-?\d+)\s+Y=(-?\d+)\s+W=(\d+)\s+H=(\d+)\s+"
                    r"SAG=([0-9a-fA-F]+)\s+RB=(-?\d+)\s+"
                    r"COL=([0-9a-fA-F]+)\s+PAL=([0-9a-fA-F]+)")


def normalize(name, value):
    if name in ("CMD", "SAG", "COL", "PAL"):
        return value.lower().lstrip("0") or "0"
    return str(int(value, 10))


def read_top(path):
    commands = {}
    with open(path, "r", encoding="ascii", errors="replace") as stream:
        for line in stream:
            match = TOP_RE.search(line)
            if match:
                values = match.groups()
                commands[int(values[0])] = tuple(
                    normalize(name, value) for name, value in zip(FIELDS, values[1:]))
    return commands


def compare(mame_path, top_path):
    top = read_top(top_path)
    if not top:
        print("TOP TRACE HAS NO LAUNCHES")
        return 2

    matched = 0
    with open(mame_path, "r", encoding="ascii", errors="replace", buffering=1024 * 1024) as stream:
        for line in stream:
            if not line.startswith("B|"):
                continue
            parts = line.rstrip().split("|")
            index = int(parts[1])
            if index not in top:
                if index > max(top):
                    break
                print(f"TOP TRACE MISSING B{index}; matched through B{index - 1}")
                return 2
            raw = dict(item.split("=", 1) for item in parts[3:] if "=" in item)
            expected = tuple(normalize(name, raw[name]) for name in FIELDS)
            if expected != top[index]:
                print(f"FIRST COMMAND DIVERGENCE B{index}")
                for name, reference, actual in zip(FIELDS, expected, top[index]):
                    verdict = "MATCH" if reference == actual else "DIFFER"
                    print(f"  {name}: MAME={reference} RTL={actual} {verdict}")
                return 1
            matched += 1

    print(f"MATCH B0..B{matched - 1}: {matched} integrated-top DMA launches")
    return 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mame")
    parser.add_argument("top")
    args = parser.parse_args()
    return compare(args.mame, args.top)


if __name__ == "__main__":
    raise SystemExit(main())
