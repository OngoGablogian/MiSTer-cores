#!/usr/bin/env bash
# Replay one real Strike Force gameplay frame (59 DMA packets captured by MAME)
# through the exact Family2 renderer and DDR framebuffer path.  The independent
# oracle is MAME's dma_expected_vram.hex, not a model copied from the RTL.
set -euo pipefail

export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CHECKPOINT="${SF_CHECKPOINT:-/d/deck/fpga/smash tv/Arcade-SmashTV_MiSTer/sim/build/mame-p6-checkpoint-strkforc-f7199-safe-r1}"
GFX="${SF_GFX_HEX:-/d/deck/fpga/smash tv/Arcade-SmashTV_MiSTer/sim/build/dense-p6-assets/strkforc/strkforc.gfx.hex}"
OUT="${SF_SCENE_OUT:-$ROOT/sim/build/sf_scene_replay_f7199}"
VVP="$OUT/tb_yunit_sf_scene_replay.vvp"
LOG="$OUT/replay.log"

for f in "$CHECKPOINT/dma.vec" "$CHECKPOINT/pre_vram.hex" \
         "$CHECKPOINT/dma_expected_vram.hex" "$GFX"; do
  [[ -f "$f" ]] || { echo "SF scene replay: missing $f" >&2; exit 2; }
done
mkdir -p "$OUT"

iverilog -g2012 -DYUNIT_NO_COMMITGATE -DYUNIT_FAMILY2_SCENE \
  -o "$VVP" \
  "$ROOT/rtl/pkg/yunit_pkg.sv" \
  "$ROOT/rtl/yunit/family2/yunit_dma_family2.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
  "$ROOT/rtl/yunit/vram_sdram.sv" \
  "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_yunit_scene_replay.sv"

cd "$ROOT/sim"
vvp "$VVP" \
  +SCENE=strkforc_f7199 \
  "+VEC=$CHECKPOINT/dma.vec" \
  +NV=591 \
  "+PRE_VRAM=$CHECKPOINT/pre_vram.hex" \
  "+POST_VRAM=$CHECKPOINT/dma_expected_vram.hex" \
  "+GFX=$GFX" \
  "+OUT_DIR=$OUT" | tee "$LOG"

grep -Fq "RESULT: DMA-WRITES-MATCH" "$LOG"
! grep -Fq "RESULT: FAIL" "$LOG"
echo "SF SCENE REPLAY: PASS -- Family2 renderer matches all touched MAME pixels"
