#!/usr/bin/env bash
# Fast all-title first-draw qualification for the exact FULL sv2v/Quartus blob.
# Compiles once, then boots each audited program ROM far enough to prove the
# live display origin and a completed DMA -> framebuffer -> DDR publication.
set -euo pipefail
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ROM_DIR="${1:?usage: $0 ROM_DIRECTORY [game ...]}"
shift
GAMES=("$@")
if [ "${#GAMES[@]}" -eq 0 ]; then
  GAMES=(trog smashtv hiimpact shimpact strkforc saurnfrnt mk term2 totcarn yunittst)
fi

for d in /c/altera/*/questa_fse/win64 /c/altera_pro/*/questa_fse/win64; do
  if [ -x "$d/vlog.exe" ]; then
    VLOG="$d/vlog"
    VSIM="$d/vsim"
    VLIB="$d/vlib"
    break
  fi
done
[ -n "${VLOG:-}" ] || { echo "ERROR: Questa not found"; exit 1; }
unset LM_LICENSE_FILE MGLS_LICENSE_FILE

. "$ROOT/sim/questa_lock.sh"
questa_lock_acquire "yunit:family2-profile-first-draw" || exit 3

BUILD="$ROOT/sim/build/family2_profile_boot_questa"
HEXDIR="$BUILD/program"
WORK="$BUILD/work"
NVRAM_DIR="${PROFILE_BOOT_NVRAM_DIR:-$ROOT/sim/build/mame_nvram_factory}"
mkdir -p "$BUILD" "$HEXDIR"
python "$ROOT/tools/make_yunit_program_hex.py" "$ROM_DIR" "$HEXDIR" "${GAMES[@]}"
if [ -z "${PROFILE_BOOT_NVRAM_DIR:-}" ]; then
  NVRAM_GAMES=()
  for game in "${GAMES[@]}"; do
    case "$game" in
      yunittst) ;;
      mk) NVRAM_GAMES+=(mkla4);;
      saurnfrnt) NVRAM_GAMES+=(strkforc);;
      *) NVRAM_GAMES+=("$game");;
    esac
  done
  [ "${#NVRAM_GAMES[@]}" -eq 0 ] || python \
    "$ROOT/tools/make_yunit_factory_nvram.py" "$ROM_DIR" "$NVRAM_DIR" \
    --mame "${PROFILE_BOOT_MAME:-C:\tools\mame\mame.exe}" \
    --games "${NVRAM_GAMES[@]}"
fi
FAST_SELFTEST_ARGS=()
if [ "${PROFILE_BOOT_EXACT_POST:-0}" != 1 ]; then
  python "$ROOT/tools/accelerate_yunit_profile_hex.py" "$HEXDIR" "${GAMES[@]}"
  FAST_SELFTEST_ARGS+=(+FAST_SELFTEST)
fi

export SV2V_EXTRA="-DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_FULL -DSIM_INIT_MEM -DPROFILE_BOOT_QUIET_SOUND"
bash "$ROOT/quartus/build_sv2v.sh"
python "$ROOT/tools/gen_vhdl_stub.py" \
  "$ROOT/rtl/sound/williams_cvsd/williams_cvsd_board.vhd" williams_cvsd_board \
  > "$BUILD/williams_cvsd_board.v"

case "$WORK" in
  "$ROOT"/sim/build/*/work) ;;
  *) echo "ERROR: refusing to replace unexpected work path: $WORK"; exit 1;;
esac
rm -rf "$WORK"
"$VLIB" "$WORK" >/dev/null
VENDOR=("$ROOT/rtl/sound/williams_cvsd/mc6809is.v")
for file in "$ROOT"/rtl/sound/jt51/hdl/*.v; do VENDOR+=("$file"); done
for file in "$ROOT"/rtl/sound/jt6295/*.v; do VENDOR+=("$file"); done

"$VLOG" -sv -quiet -svinputport=var -suppress 2892 \
  +define+PROFILE_BOOT_QUIET_SOUND -work "$WORK" \
  "$ROOT/build_syn/smashtv_core.v" \
  "${VENDOR[@]}" \
  "$BUILD/williams_cvsd_board.v" \
  "$ROOT/sim/sdram_chip.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_family2_profile_boot.sv"

profile_for() {
  case "$1" in
    smashtv) echo 0;; trog) echo 1;; hiimpact) echo 2;; shimpact) echo 3;;
    strkforc) echo 4;; mk) echo 5;; term2) echo 6;; totcarn) echo 7;;
    yunittst) echo 8;; saurnfrnt) echo 9;;
    *) echo "unknown game $1" >&2; return 2;;
  esac
}

start_for() {
  case "$1" in strkforc|saurnfrnt|term2) echo e00c;; *) echo fffc;; esac
}

vsblnk_for() {
  case "$1" in mk) echo 0112;; strkforc|saurnfrnt|term2) echo 0113;; *) echo 0114;; esac
}

row_for() {
  case "$1" in strkforc|saurnfrnt|term2) echo 1ff;; *) echo 000;; esac
}

nvram_set_for() {
  case "$1" in
    mk) echo mkla4;;
    saurnfrnt) echo strkforc;;
    *) echo "$1";;
  esac
}

for game in "${GAMES[@]}"; do
  log="$BUILD/$game.log"
  rom_hex="$(cygpath -m "$HEXDIR/$game.hex")"
  sim_args=(
    "+GAME=$(profile_for "$game")"
    "+NAME=$game"
    "+ROM=$rom_hex"
    "+EXPECT_START=$(start_for "$game")"
    "+EXPECT_VSBLNK=$(vsblnk_for "$game")"
    "+EXPECT_ROW=$(row_for "$game")"
    "+MAXC=${PROFILE_BOOT_MAXC:-180000000}"
    "${FAST_SELFTEST_ARGS[@]}"
  )
  if [ "$game" = yunittst ]; then
    sim_args+=(+PROGRAM_ONLY)
  else
    nvset="$(nvram_set_for "$game")"
    nvram_file="$NVRAM_DIR/$nvset/$nvset/nvram"
    [ -f "$nvram_file" ] || {
      echo "ERROR: missing initialized NVRAM for $game: $nvram_file" >&2
      exit 2
    }
    sim_args+=("+NVRAM=$(cygpath -m "$nvram_file")")
  fi
  if [ -n "${PROFILE_BOOT_MEMTRACE:-}" ]; then
    sim_args+=(+MEMTRACE)
  fi
  if [ "${PROFILE_BOOT_DMAREGTRACE:-0}" = "1" ]; then
    sim_args+=(+DMAREGTRACE)
  fi
  if [ -n "${PROFILE_BOOT_RUN_DEEP:-}" ]; then
    sim_args+=("+RUN_DEEP=${PROFILE_BOOT_RUN_DEEP}")
  fi
  echo "running: FAMILY2_PROFILE_BOOT $game"
  set +e
  "$VSIM" -c -quiet -work "$WORK" -do "run -all; quit -f" \
    tb_family2_profile_boot "${sim_args[@]}" >"$log" 2>&1
  status=$?
  set -e
  grep -E "PASS:|FAIL:|RESULT:|profile-summary" "$log" || true
  if grep -qE "lost connection|Exiting VSIM license process|Kernel lost connection|Fatal:" "$log"; then
    echo "FAMILY2 PROFILE BOOT: INCONCLUSIVE (simulator/license died; $game)" >&2
    exit 2
  fi
  if [ "$status" -ne 0 ] || grep -qE "^#? ?FAIL:|RESULT: FAIL" "$log" \
      || ! grep -q "PASS: FAMILY2_PROFILE_BOOT" "$log"; then
    echo "FAMILY2 PROFILE BOOT: FAIL ($game; transcript $log)" >&2
    exit 1
  fi
done

echo "FAMILY2 PROFILE BOOT: PASS (${#GAMES[@]} profiles, completed first-draw contract)"
