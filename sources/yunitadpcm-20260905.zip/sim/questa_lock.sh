#!/usr/bin/env bash
# Shared Questa interlock, sourced by every runner that starts a vsim.
#
# WHY: Questa FSE here is NODELOCKED to ONE vsim, and several sibling arcade-core
# sessions (Y-unit, Wolf, T-unit, Gladiator, NARC, Model 1) share this machine.
# Two concurrent vsim invocations reap each other and the loser dies with
# "Exiting VSIM license process" / "vish lost connection to vsim process". That
# looks exactly like simulator fragility or an RTL failure, and it is neither --
# it is contention. A 90M-cycle tb_yunit_top_boot run was lost to it.
#
# THE LOCK PATH IS A CROSS-SESSION CONTRACT. It is standardised on
# /tmp/umk3_questa.lock, the path the Wolf session already uses. Two sessions
# using DIFFERENT lock paths do not interlock at all -- which is the same as
# having no lock. Do not "improve" this string. If it ever changes, it must
# change in every session at once.
#
# Usage:
#   . "$(dirname "$0")/questa_lock.sh"
#   questa_lock_acquire "my-run-label"
#   ... run exactly one vsim ...
#   (release is automatic via trap EXIT)

QUESTA_LOCK="${QUESTA_LOCK:-/tmp/umk3_questa.lock}"
QUESTA_LOCK_TIMEOUT="${QUESTA_LOCK_TIMEOUT:-2400}"   # seconds; long runs are 25-60 min

questa_lock_release() {
  if [ -d "$QUESTA_LOCK" ] && [ -f "$QUESTA_LOCK/pid" ]; then
    if [ "$(cat "$QUESTA_LOCK/pid" 2>/dev/null)" = "$$" ]; then
      rm -rf "$QUESTA_LOCK"
    fi
  fi
}

questa_processes() {
  # A few older sibling runners still launch vsim without this lock.  The
  # nodelocked licence does not care: a second launch kills one or both jobs.
  # Check the Windows process table as well as the advisory directory so a
  # non-adopter cannot be mistaken for a free licence.
  local live
  live="$(ps -W 2>/dev/null | grep -iE '[\\/]vsim(k)?(\.exe)?([[:space:]]|$)' || true)"
  if [ -z "$live" ] && command -v powershell.exe >/dev/null 2>&1; then
    # MSYS ps -W has returned an empty list for live Questa 2025.2 processes
    # on this host.  The Windows process table is authoritative and prevents a
    # second simulator from killing or silently slowing another core's run.
    live="$(powershell.exe -NoProfile -Command \
      'Get-Process vsim,vsimk -ErrorAction SilentlyContinue | ForEach-Object { $_.Path }' \
      2>/dev/null | tr -d '\r' || true)"
  fi
  printf '%s' "$live"
}

questa_lock_acquire() {
  local label="${1:-$(basename "$0")}"
  local waited=0 holder pid owner live

  while :; do
    if mkdir "$QUESTA_LOCK" 2>/dev/null; then
      live="$(questa_processes)"
      if [ -z "$live" ]; then
        break
      fi
      rmdir "$QUESTA_LOCK" 2>/dev/null || true
      if [ $((waited % 60)) -eq 0 ]; then
        echo "questa-lock: live unregistered vsim process; waiting ... ${waited}s"
      fi
      if [ "$waited" -ge "$QUESTA_LOCK_TIMEOUT" ]; then
        echo "questa-lock: TIMEOUT after ${waited}s waiting for live unregistered vsim"
        echo "questa-lock: NOT starting a second vsim -- that would kill both runs."
        return 3
      fi
      sleep 5
      waited=$((waited + 5))
      continue
    fi

    # Reap an ORPHANED lock: the holder died without releasing (crash, kill,
    # session teardown). Without this a single crashed run wedges every other
    # session until someone notices and rm -rf's it by hand.
    pid="$(cat "$QUESTA_LOCK/pid" 2>/dev/null || true)"
    owner="$(cat "$QUESTA_LOCK/owner" 2>/dev/null || echo unknown)"
    if [ -n "$pid" ] && ! kill -0 "$pid" 2>/dev/null; then
      echo "questa-lock: reaping orphan lock (dead pid $pid, owner '$owner')"
      rm -rf "$QUESTA_LOCK"
      continue
    fi
    if [ "$waited" -ge "$QUESTA_LOCK_TIMEOUT" ]; then
      echo "questa-lock: TIMEOUT after ${waited}s waiting for '$owner' (pid $pid)"
      echo "questa-lock: NOT starting a second vsim -- that would kill both runs."
      return 3
    fi
    if [ $((waited % 60)) -eq 0 ]; then
      echo "questa-lock: waiting for '$owner' (pid $pid) ... ${waited}s"
    fi
    sleep 5
    waited=$((waited + 5))
  done

  echo "$$" > "$QUESTA_LOCK/pid"
  echo "$label" > "$QUESTA_LOCK/owner"
  trap questa_lock_release EXIT INT TERM
  echo "questa-lock: acquired by '$label' (pid $$)"
  return 0
}
