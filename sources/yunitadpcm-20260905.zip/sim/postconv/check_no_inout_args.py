#!/usr/bin/env python3
"""Ban `inout` arguments on tasks/functions in synthesized SystemVerilog.

sv2v lowers a SystemVerilog `inout` subroutine argument (copy-in AND copy-out)
to a plain Verilog `output` (copy-out ONLY).  The copy-in silently disappears,
so a read-modify-write of a shared vector is correct in every .sv simulation
and wrong in the synthesized core.  That shipped: the Y-unit input mappers
wrote their direction nibbles through such a task, and on the cabinet Smash
T.V. walked to the bottom-left while the 4-player profiles lost their whole
coin/start/service/tilt field.

Tri-state MODULE ports (`inout wire [15:0] SDRAM_DQ`) are legitimate and are
not what this checks -- only arguments inside a task/function header.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

# Strip line and block comments before scanning so commented-out examples and
# the explanatory comments in the mappers do not trip the check.
_LINE_COMMENT = re.compile(r"//[^\n]*")
_BLOCK_COMMENT = re.compile(r"/\*.*?\*/", re.S)
_SUBROUTINE = re.compile(r"\b(task|function)\b", re.I)
_INOUT_ARG = re.compile(r"\binout\b", re.I)


def strip_comments(text: str) -> str:
    text = _BLOCK_COMMENT.sub(" ", text)
    return _LINE_COMMENT.sub("", text)


def header_span(text: str, start: int) -> str:
    """Return the parenthesised argument list following a task/function keyword.

    ANSI style puts args in parens; non-ANSI style declares them in the body
    up to the first `;`, so fall back to that when no paren opens first.
    """
    paren = text.find("(", start)
    semi = text.find(";", start)
    if paren == -1 or (semi != -1 and semi < paren):
        # Non-ANSI: arguments are declared between the header `;` and `endtask`
        # / `endfunction`. Scan that whole body region.
        end = re.search(r"\bend(task|function)\b", text[start:], re.I)
        return text[start:start + end.start()] if end else text[start:]
    depth = 0
    for i in range(paren, len(text)):
        if text[i] == "(":
            depth += 1
        elif text[i] == ")":
            depth -= 1
            if depth == 0:
                return text[paren:i + 1]
    return text[paren:]


def scan(path: Path) -> list[str]:
    raw = path.read_text(encoding="utf-8", errors="replace")
    text = strip_comments(raw)
    hits: list[str] = []
    for m in _SUBROUTINE.finditer(text):
        args = header_span(text, m.end())
        if _INOUT_ARG.search(args):
            line = text.count("\n", 0, m.start()) + 1
            hits.append(f"{path}:{line}: `inout` argument on {m.group(1)}")
    return hits


def main() -> int:
    roots = [Path(a) for a in sys.argv[1:]] or [Path("rtl")]
    hits: list[str] = []
    files = 0
    for root in roots:
        # Fail closed: a mistyped root would otherwise scan nothing and "pass".
        if not root.is_dir():
            print(f"INOUT-ARG CHECK FAIL: root {root} is not a directory")
            return 1
        for sv in sorted(root.rglob("*.sv")):
            files += 1
            hits.extend(scan(sv))
    if hits:
        print("INOUT-ARG CHECK FAIL: sv2v drops the copy-in on these:")
        for h in hits:
            print("  " + h)
        return 1
    print(f"INOUT-ARG CHECK PASS: {files} SystemVerilog files, "
          "no `inout` subroutine arguments")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
