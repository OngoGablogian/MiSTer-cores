#!/usr/bin/env bash
# FULL graphics delivery gate: MRA byte stream -> the real family2_download_mapper
# -> memory -> the real yunit_gfx_unpack -> the game's own ROM checksum test.
#
# This is the gate HANDOFF section 8 requires. Unlike run_gfx_unpack_oracle.sh,
# nothing here is staged by $readmemh into the middle of the chain: the planes
# arrive one byte at a time through ioctl and the mapper decides where they land.
#
#   usage: sim/run_download_delivery.sh <smashtv|strkforc|term2|totcarn> [dlgap] [acklat] [stall]
#
# dlgap models idle cycles between ioctl bytes. hps_io does not deliver
# back-to-back forever, and the recorded download/unpack regression was a
# collision -- so run more than leg 1.
set -euo pipefail
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"

TITLE="${1:?usage: run_download_delivery.sh <smashtv|strkforc|term2|totcarn> [dlgap] [acklat] [stall]}"
DLGAP="${2:-0}"
ACKLAT="${3:-0}"
STALL="${4:-0}"

ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
ROMS="${YUNIT_ROMS:-}"
if [ -z "$ROMS" ]; then
  for cand in "$ROOT/../roms" "$ROOT/../smash tv/roms"; do
    [ -d "$cand" ] && { ROMS="$cand"; break; }
  done
fi
[ -d "$ROMS" ] || { echo "DL_DELIVERY_FAIL cannot find the ROM dir; set YUNIT_ROMS" >&2; exit 66; }
WORK="$ROOT/sim/build/download-delivery/$TITLE"
mkdir -p "$WORK"

case "$TITLE" in
  smashtv) PLANE_BYTES=$((0x60000)); BPP4=0 ;;
  strkforc) PLANE_BYTES=$((0xc0000)); BPP4=1 ;;
  term2)    PLANE_BYTES=$((0x200000)); BPP4=0 ;;
  totcarn) PLANE_BYTES=$((0x100000)); BPP4=0 ;;
  *) echo "DL_DELIVERY_FAIL unsupported title: $TITLE" >&2; exit 64 ;;
esac
PLANE_WORDS=$((PLANE_BYTES / 2))

BYTES_HEX="$WORK/gfx_bytes.hex"
DUMP="$WORK/unpacked.bin"

python - "$TITLE" "$ROMS" "$BYTES_HEX" <<'PY'
import sys, zipfile, pathlib
title, roms, out = sys.argv[1], pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[3])
SPEC = {
 "smashtv": ("la1_smash_tv_game_rom_{c}.{c}",
             [["u111","u112","u113"],["u95","u96","u97"],["u106","u107","u108"]]),
 "totcarn": ("la1_total_carnage_game_rom_{c}.{c}",
             [["u111","u112","u113","u114"],["u95","u96","u97","u98"],
              ["u106","u107","u108","u109"]]),
 "strkforc": ("la1_strike_force_game_rom_{c}.{c}",
              [["u111","u112","u113","u114","u106","u107"],
               ["u95","u96","u97","u98","u90","u91"]]),
 "term2": ("la1_terminator_2_game_rom_{c}.{c}",
            [["u111","u112","u113","u114"],["u95","u96","u97","u98"],
             ["u106","u107","u108","u109"]]),
}
pat, planes_spec = SPEC[title]
with zipfile.ZipFile(roms / f"{title}.zip") as zf:
    planes = [b"".join(zf.read(pat.format(c=c)) for c in row) for row in planes_spec]
assert len({len(p) for p in planes}) == 1, [hex(len(p)) for p in planes]
blob = b"".join(planes)          # exactly what MRA index 0 hands to ioctl
out.write_text("".join(f"{b:02x}\n" for b in blob))
print(f"staged {len(blob):#x} raw MRA bytes ({len(planes)} planes x {len(planes[0]):#x})")
PY

echo "=== delivery: $TITLE dlgap=$DLGAP acklat=$ACKLAT stall=1/$STALL ==="
bash "$ROOT/sim/run.sh" tb_yunit_download_delivery \
  "+BYTES=$BYTES_HEX" "+OUT=$DUMP" "+PW=$PLANE_WORDS" "+BPP4=$BPP4" \
  "+DLGAP=$DLGAP" "+ACKLAT=$ACKLAT" "+STALL=$STALL"

[ -s "$DUMP" ] || { echo "DL_DELIVERY_FAIL no dump produced" >&2; exit 1; }

echo "=== the game's own ROM self-test, against what the DOWNLOAD PATH delivered ==="
python "$ROOT/tools/yunit_rom_selftest.py" "$TITLE" --readback "$DUMP" \
  --diff-zip "$ROMS/$TITLE.zip"
