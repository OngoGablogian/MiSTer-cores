// yunit_dma_descriptor_fifo.sv
//
// Synthesizable single-clock FIFO for immutable Y-unit DMA register snapshots.
// It is a physical-render queue only: CPU-visible COMMAND busy/X1 timing belongs
// to yunit_dma_logical_timer and must never depend on this FIFO's occupancy.
//
// `push_ready` permits a push into a full FIFO when a pop occurs on the same
// edge.  A push attempted without push_ready is not accepted and sets the sticky
// overflow output; yunit_memsys prevents that condition by holding the CPU bus
// request until space is available.

`default_nettype none

module yunit_dma_descriptor_fifo #(
  parameter int WIDTH = 160,
  parameter int DEPTH = 512,
  parameter int AW = $clog2(DEPTH)
)(
  input  logic                 clk,
  input  logic                 rst,
  input  logic                 push,
  input  logic [WIDTH-1:0]     push_data,
  output logic                 push_ready,
  input  logic                 pop,
  output logic [WIDTH-1:0]     pop_data,
  output logic                 empty,
  output logic                 full,
  output logic [AW:0]          count,
  output logic [AW:0]          high_water,
  output logic                 overflow_sticky
);

  logic [WIDTH-1:0] mem [0:DEPTH-1];
  logic [AW-1:0] wr_ptr;
  logic [AW-1:0] rd_ptr;

  wire pop_accept  = pop && !empty;
  wire push_accept = push && push_ready;

  assign empty      = (count == 0);
  assign full       = (count == DEPTH);
  assign push_ready = !full || pop_accept;
  assign pop_data   = mem[rd_ptr];

  always_ff @(posedge clk) begin
    if (rst) begin
      wr_ptr          <= '0;
      rd_ptr          <= '0;
      count           <= '0;
      high_water      <= '0;
      overflow_sticky <= 1'b0;
    end else begin
      if (push && !push_ready)
        overflow_sticky <= 1'b1;

      if (push_accept) begin
        mem[wr_ptr] <= push_data;
        if (wr_ptr == DEPTH-1)
          wr_ptr <= '0;
        else
          wr_ptr <= wr_ptr + 1'b1;
      end

      if (pop_accept) begin
        if (rd_ptr == DEPTH-1)
          rd_ptr <= '0;
        else
          rd_ptr <= rd_ptr + 1'b1;
      end

      unique case ({push_accept, pop_accept})
        2'b10: count <= count + 1'b1;
        2'b01: count <= count - 1'b1;
        default: ;
      endcase

      if (push_accept && !pop_accept && ((count + 1'b1) > high_water))
        high_water <= count + 1'b1;
    end
  end

endmodule

`default_nettype wire
