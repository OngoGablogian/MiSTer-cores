// yunit_adpcm_board.sv - Williams D-11581 ADPCM sound board used by the
// later Midway Y-unit games (Mortal Kombat, Terminator 2, Total Carnage).
//
// The register map, ROM banking and delayed external-IRQ clear follow MAME's
// williams_adpcm_sound_device.  ROM data is read through the common Y-unit
// SDRAM sound region:
//   000000-03ffff  sound CPU U3 (expanded to 256 KiB by the MRA)
//   040000-13ffff  OKI sample image (expanded to 1 MiB by the MRA)
//
// The external ROM port is a cached-address interface. ext_rom_addr remains
// stable until ext_rom_ok, then this module retains the byte for the 6809 or
// JT6295 client. This lets one SDRAM byte port serve both devices safely.
`timescale 1ns/1ps
`default_nettype none
module yunit_adpcm_board (
  input  logic               clk,          // 12 MHz
  input  logic               reset_pon,
  input  logic               reset,
  input  logic [7:0]         sound_select,
  input  logic               sound_trig,   // main-board D9 level; low asserts IRQ
  input  logic [3:0]         game,         // selects the hidden-RAM window (below)

  output logic [20:0]        ext_rom_addr,
  input  logic [7:0]         ext_rom_data,
  input  logic               ext_rom_ok,

  // MRA sound-image download tap (ioctl clock domain). Fills the FIXED-BANK
  // BRAM below; writes land regardless of board reset (P0022 discipline: the
  // board is held in reset for the whole download).
  input  logic               snd_dl_clk,
  input  logic [17:0]        snd_dl_addr,
  input  logic [7:0]         snd_dl_data,
  input  logic               snd_dl_we,

  output logic signed [15:0] audio_l,
  output logic signed [15:0] audio_r,
  output logic               irq_state
);
  import yunit_pkg::*;   // YG_* profile ids, for the hidden-RAM window below

  // The existing CVSD board stretches POR because JT51's internal reset shift
  // chains need considerably more than one host reset cycle. Do the same here.
  logic [8:0] por_count = 9'h1ff;
  logic [15:0] cpu_addr;
  logic [7:0] cpu_din, cpu_dout;
  logic cpu_rnw;
  logic cpu_irq;
  always_ff @(posedge clk) begin
    if (reset_pon) por_count <= 9'h1ff;
    else if (por_count != 0) por_count <= por_count - 1'b1;
  end
  // MAME's williams_adpcm_sound_device::reset_write() resets the 6809, bank
  // and parent-device interrupt bookkeeping.  It does not reset the YM2151 or
  // OKI child devices.  Keep the CPU/board transport on the host-reset domain,
  // but let both sound chips and their clock phases see power-on reset only.
  wire board_reset = reset | reset_pon | (por_count != 0);
`ifdef MUT_ADPCM_CHILD_RESET_COUPLED
  // MUTANT: restores the old coupling that reset JT51/OKI on every host reset.
  wire child_reset = board_reset;
`else
  wire child_reset = reset_pon | (por_count != 0);
`endif

  // 6809E at 8 MHz / 4 = 2 MHz, represented as falling E/Q enables in the
  // 12 MHz host domain (the same proven cadence as williams_cvsd_board).
  logic en_half;
  logic [1:0] div_count;
  logic cpu_e_en, cpu_q_en, cpu_write;
  wire cpu_rom_ready;
  wire cpu_rom_wait;
  // STALL AT THE CONSUMPTION EDGE, NOT ON THE MISS (tb_adpcm_cpu_pace,
  // 2026-08-17). The old form gated the WHOLE divider on cpu_rom_wait, so
  // every external fetch froze the CPU for its full round trip -- measured
  // 1.70 MHz effective vs the 2.00 gospel rate, which eats the music driver's
  // entire 72 us FIRQ service budget (MAME adpcm_ym_cadence.lua: ~143 cycles
  // per tick). Real 6809 bus timing only needs the byte AT the E fall; the
  // ~5 host clocks between the address becoming valid and that edge are free
  // fetch latency. So: run the divider freely and hold ONLY the tick that
  // would fire cpu_e_en while the byte is still in flight.
`ifdef MUT_PACE_EAGER_STALL
  // MUTANT (sim/run_adpcm_pace_gate.sh kill control): the pre-fix whole-
  // divider freeze. Must fail the 1.9 MHz pace bar.
  wire e_hold = cpu_rom_wait;
`else
  wire e_hold = en_half && (div_count == 2'd0) && cpu_rom_wait;
`endif
  always_ff @(posedge clk) begin
    cpu_e_en <= 1'b0;
    cpu_q_en <= 1'b0;
    cpu_write <= 1'b0;
    if (board_reset) begin
      en_half <= 1'b0;
      div_count <= 2'd0;
    end else if (!e_hold) begin
      en_half <= ~en_half;
      if (en_half) begin
        div_count <= (div_count == 2'd2) ? 2'd0 : div_count + 1'b1;
        if (div_count == 2'd0) cpu_e_en <= 1'b1;
        if (div_count == 2'd2) begin
          cpu_q_en <= 1'b1;
          cpu_write <= ~cpu_rnw;
        end
      end
    end
  end

  logic ym_irq_n;

  mc6809is u_cpu (
    .CLK(clk), .fallE_en(cpu_e_en), .fallQ_en(cpu_q_en),
    .OP(cpu_din), .D(cpu_din), .DOut(cpu_dout), .ADDR(cpu_addr),
    .RnW(cpu_rnw), .BS(), .BA(), .nIRQ(~cpu_irq),
    .nFIRQ(ym_irq_n), .nNMI(1'b1), .AVMA(), .BUSY(), .LIC(),
    .nHALT(1'b1), .nRESET(~board_reset), .nDMABREQ(1'b1), .RegData()
  );

  // 8 KiB work RAM.
  logic [7:0] ram [0:8191];
  logic [7:0] ram_q;
  always_ff @(posedge clk) begin
    ram_q <= ram[cpu_addr[12:0]];
    if (cpu_write && cpu_addr < 16'h2000)
      ram[cpu_addr[12:0]] <= cpu_dout;
  end

  wire io_bank   = cpu_addr[15:10] == 6'b001000; // 2000-23ff
  wire io_ym     = cpu_addr[15:10] == 6'b001001; // 2400-27ff
  wire io_dac    = cpu_addr[15:10] == 6'b001010; // 2800-2bff
  wire io_oki    = cpu_addr[15:10] == 6'b001011; // 2c00-2fff
  wire io_cmd    = cpu_addr[15:10] == 6'b001100; // 3000-33ff
  wire io_okibnk = cpu_addr[15:10] == 6'b001101; // 3400-37ff
  wire io_talk   = cpu_addr[15:10] == 6'b001111; // 3c00-3fff
  wire cpu_rom   = cpu_addr >= 16'h4000;

  // ---- hidden ("protection") RAM in the sound CPU's ROM space ---------------
  // GOSPEL midyunit_m.cpp:239-245 install_hidden_ram(), invoked from
  // midyunit_adpcm_state::init_generic (midyunit_m.cpp:314-319) for every ADPCM
  // title:
  //     init_mkyunit  -> init_generic(6, 0xfb9c, 0xfbc6)   midyunit_m.cpp:457
  //     term2         -> init_generic(6, 0xfa8d, 0xfa9c)   midyunit_m.cpp:548
  //     init_totcarn  -> init_generic(6, 0xfc04, 0xfc2e)   midyunit_m.cpp:577
  // (mkyturbo / mkrep / mkla3bl all chain to init_mkyunit, so they share MK's
  // window.) The largest window is 43 bytes, so 64 entries covers every profile
  // -- the same sizing argument the CVSD board's prot_ram uses.
  //
  // WHY IT IS *PLAIN* RAM HERE, unlike the CVSD board. MAME calls install_ram(),
  // which REPLACES the ROM mapping over the window: reads come from the RAM
  // unconditionally and it is value-initialised to zero, so a read before any
  // write returns 0x00 -- NOT the underlying ROM byte. That is why this has no
  // "valid" bit. The CVSD *small* board is a genuinely different mechanism
  // (midyunit_m.cpp:230-237 cvsd_protection_w writes through into the bank-0 ROM
  // image), and williams_cvsd_board.vhd models that one separately. Collapsing
  // the two would be wrong in both directions.
  //
  // NOT REACHED BY SMASH T.V., which is a CVSD title -- this gap survived
  // precisely because the primary bring-up title cannot exercise it.
  // The bounds live in yunit_pkg so a testbench can check them against the
  // gospel table WITHOUT having to drive the internal 6809's address bus.
  localparam int PROT_N = 64;                    // >= the largest window (43)
  wire [15:0] prot_start = yunit_adpcm_prot_start(game);
  wire [15:0] prot_end   = yunit_adpcm_prot_end(game);
  wire        prot_en    = yunit_has_adpcm_prot(game);
  wire [15:0] prot_off   = cpu_addr - prot_start;
  // Bounded by the REAL end, not by PROT_N: see the note in yunit_pkg. An
  // address one past prot_end must fall through to ROM.
  wire prot_hit = prot_en && (cpu_addr >= prot_start) && (cpu_addr <= prot_end);

  logic [7:0] prot_ram [0:PROT_N-1];
  logic [7:0] prot_q;
  initial for (int i = 0; i < PROT_N; i++) prot_ram[i] = 8'h00;
  // Keep the standard single-write-port RAM inference form.  `always_ff`
  // forbids the separate power-up initializer above even though it becomes
  // memory initialization, not a second hardware write port (Questa
  // vopt-7061).  A plain clocked process preserves the initialized inferred
  // RAM and the one synchronous CPU write path.
  always @(posedge clk) begin
    prot_q <= prot_ram[prot_off[5:0]];
    if (cpu_write && prot_hit)
      prot_ram[prot_off[5:0]] <= cpu_dout;
  end

  logic [2:0] cpu_bank, oki_bank;
  logic [7:0] dac_data, talkback;
  logic [7:0] command_latch;
  logic [7:0] irq_clear_count;
  logic [8:0] command_seen;

  // The main CPU writes {D9,command}. A changed nine-bit tuple is a new command;
  // D9 low asserts the ADPCM CPU IRQ. Reading 0x3000 clears the CPU line
  // immediately, but keeps the main-board-visible IRQ high for 10 us.
  wire [8:0] command_now = {sound_trig, sound_select};
  always_ff @(posedge clk) begin
    if (board_reset) begin
      cpu_bank <= 3'd0;
      oki_bank <= 3'd0;
      dac_data <= 8'h80;
      talkback <= 8'h00;
      command_latch <= 8'h00;
      command_seen <= command_now;
      cpu_irq <= 1'b0;
      irq_state <= 1'b0;
      irq_clear_count <= 8'd0;
    end else begin
      if (command_now != command_seen) begin
        command_seen <= command_now;
        command_latch <= sound_select;
        if (!sound_trig) begin
          cpu_irq <= 1'b1;
          irq_state <= 1'b1;
          irq_clear_count <= 8'd0;
        end
      end

      if (irq_clear_count != 0) begin
        irq_clear_count <= irq_clear_count - 1'b1;
        if (irq_clear_count == 1) irq_state <= 1'b0;
      end

      if (cpu_write) begin
        if (io_bank)        cpu_bank <= cpu_dout[2:0];
        else if (io_dac)    dac_data <= cpu_dout;
        else if (io_okibnk) oki_bank <= cpu_dout[2:0];
        else if (io_talk)   talkback <= cpu_dout;
      end

      // MAME delays the externally visible clear by 10 us. At 12 MHz that is
      // 120 clocks; the local CPU IRQ itself clears on the command read.
      if (cpu_rnw && cpu_e_en && io_cmd) begin
        cpu_irq <= 1'b0;
        irq_clear_count <= 8'd120;
      end
    end
  end

  // YM2151 at NTSC colorburst (3.579545 MHz): exact 105/352 accumulator.
  logic [9:0] ym_acc;
  logic ym_cen, ym_cen_p1, ym_alt;
  always_ff @(posedge clk) begin
    ym_cen <= 1'b0;
    ym_cen_p1 <= 1'b0;
    if (child_reset) begin
      ym_acc <= 10'd0;
      ym_alt <= 1'b0;
    end else if (ym_acc + 10'd105 >= 10'd352) begin
      ym_acc <= ym_acc + 10'd105 - 10'd352;
      ym_cen <= 1'b1;
      ym_alt <= ~ym_alt;
      ym_cen_p1 <= ym_alt;
    end else begin
      ym_acc <= ym_acc + 10'd105;
    end
  end

  logic [7:0] ym_dout;
  logic signed [15:0] ym_left, ym_right;
  jt51 u_ym (
    .rst(child_reset), .clk(clk), .cen(ym_cen), .cen_p1(ym_cen_p1),
    .cs_n(~io_ym), .wr_n(~(cpu_write && io_ym)), .a0(cpu_addr[0]),
    .din(cpu_dout), .dout(ym_dout), .ct1(), .ct2(), .irq_n(ym_irq_n),
    .sample(), .left(), .right(), .xleft(ym_left), .xright(ym_right)
  );

  // OKI6295 input clock is 8 MHz / 8 = 1 MHz; pin 7 is high.
  logic [3:0] oki_div;
  logic oki_cen;
  always_ff @(posedge clk) begin
    oki_cen <= 1'b0;
    if (child_reset) oki_div <= 4'd0;
    else if (oki_div == 4'd11) begin
      oki_div <= 4'd0;
      oki_cen <= 1'b1;
    end else oki_div <= oki_div + 1'b1;
  end

  logic [7:0] oki_dout;
  logic [17:0] oki_addr;
  logic signed [13:0] oki_sound;
  logic [7:0] oki_rom_data;
  logic oki_rom_ok;
  // INTERPOL=1 (jt6295's own default): 4x upsampling + LPF at 0.25*pi.
  //
  // We ran INTERPOL=0 -- the raw stepped 7.576 kHz sample stream with NO
  // reconstruction filter anywhere downstream (yunit_audio_mix only scales and
  // sums; there is no analog LPF on a DE10 line out the way a real Y-unit board
  // has one after the OKI). That is textbook aliasing, and the cabinet report
  // for Mortal Kombat is verbatim "almost like a game gear going through an
  // apple ][e speaker" -- the sound of an unreconstructed low-rate DAC.
  // jt6295_acc.v:31-34 documents the choice outright: mode 2 exists for the
  // case where an antialiasing filter ALREADY follows the core; with none, 1 is
  // the intended setting. The sample RATE was already correct (12 MHz/12 = 1 MHz
  // into the OKI, pin 7 high -> /132 -> 7.576 kHz), so this is reconstruction,
  // not pitch.
  jt6295 #(.INTERPOL(1)) u_oki (
    .rst(child_reset), .clk(clk), .cen(oki_cen), .ss(1'b1),
    .wrn(~(cpu_write && io_oki)), .din(cpu_dout), .dout(oki_dout),
    .rom_addr(oki_addr), .rom_data(oki_rom_data), .rom_ok(oki_rom_ok),
    .sound(oki_sound), .sample()
  );

  // MAME CPU ROM layout after removing the unused 0x10000 region prefix.
  logic [20:0] cpu_rom_want;
  logic [14:0] cpu_bank_offset;
  always_comb begin
    cpu_bank_offset = cpu_addr - 16'h4000;
    if (cpu_addr < 16'hc000)
      cpu_rom_want = {3'd0, cpu_bank, cpu_bank_offset};
    else
      cpu_rom_want = 21'h3c000 + {7'd0, cpu_addr[13:0]};
  end

  // ---- FIXED-BANK BRAM (0xC000-0xFFFF = image bytes 0x3C000-0x3FFFF) -------
  // WHY (hostile-port pace measurement, 2026-08-18): the polite-SDRAM bench
  // said 2.000 MHz, but with scanout/blit-shaped port bursts the 6809
  // collapses -- 1.20 MHz at moderate hostility, 0.633 MHz with the FIRQ
  // count starved to ZERO at MK-class load. That is the cabinet: MK (heaviest
  // bus) "garbage", TC dragging drawn-out notes, Smash (BRAM-resident CVSD)
  // clean. The vectors, FIRQ handler and driver core live in the fixed bank;
  // serving them from BRAM takes SDRAM out of the interrupt path entirely.
  // Banked 0x4000-0xBFFF (song data) stays external -- a few latency-tolerant
  // byte reads per tick. Cost: 16 KB = 16 M10K.
  // SINGLE-clock RAM in the snd_dl_clk (system) domain: the RAM release gate
  // rejects every INFERRED dual-clock RAM (Warning 276027, undefined RDW).
  // The read address (cpu_addr) is quasi-static for a whole 6809 E cycle, so
  // the fast domain samples it, reads, and registers {fix_q, fix_aq}; the
  // board-domain fix_ready compare (fix_aq == cpu_addr) is the settledness
  // guard -- by the time it matches, fix_q holds the settled byte (the fast
  // domain is 8x quicker and updates both together).
  (* ramstyle = "M10K" *) logic [7:0] fixbank [0:16383];
`ifndef SYNTHESIS
  // Benches that predate the BRAM tie the dl port off; zero-init keeps their
  // fixed-bank reads at the 0x00 their synthetic ext-ROM models returned.
  initial for (int i = 0; i < 16384; i++) fixbank[i] = 8'h00;
`endif
  logic [7:0]  fix_q;
  logic [13:0] fix_aq;
  always_ff @(posedge snd_dl_clk) begin
    if (snd_dl_we && snd_dl_addr[17:14] == 4'hF)
      fixbank[snd_dl_addr[13:0]] <= snd_dl_data;
    fix_q  <= fixbank[cpu_addr[13:0]];
    fix_aq <= cpu_addr[13:0];
  end
`ifdef MUT_PACE_NO_FIXBANK
  // MUTANT (run_adpcm_pace_gate.sh hostile-leg kill control): disable the
  // fixed-bank BRAM -- every fetch external again. Must collapse under the
  // burst-hostile port profile the way the cabinet did.
  wire cpu_fixed  = 1'b0;
`else
  wire cpu_fixed  = (cpu_addr[15:14] == 2'b11);        // >= 0xC000
`endif
  wire fix_ready  = cpu_fixed && (fix_aq == cpu_addr[13:0]);

  // MAME's expanded OKI banking. Values are logical offsets within the
  // one-megabyte sample image; 0x40000 is added for the CPU-ROM prefix.
  logic [20:0] oki_logical;
  always_comb begin
    if (!oki_addr[17]) begin
      case (oki_bank)
        3'd0, 3'd1: oki_logical = 21'h40000 + {4'd0, oki_addr[16:0]};
        3'd2:       oki_logical = 21'h20000 + {4'd0, oki_addr[16:0]};
        3'd3:       oki_logical =           {4'd0, oki_addr[16:0]};
        3'd4:       oki_logical = 21'he0000 + {4'd0, oki_addr[16:0]};
        3'd5:       oki_logical = 21'hc0000 + {4'd0, oki_addr[16:0]};
        3'd6:       oki_logical = 21'ha0000 + {4'd0, oki_addr[16:0]};
        default:    oki_logical = 21'h80000 + {4'd0, oki_addr[16:0]};
      endcase
    end else begin
      // Fixed 0x20000-0x3ffff window maps to logical 0x60000-0x7ffff.
      oki_logical = 21'h40000 + {3'd0, oki_addr};
    end
  end
  wire [20:0] oki_rom_want = 21'h40000 + oki_logical;

  // Two-client WORD-HELD read cache over the one external SDRAM byte stream.
  //
  // WHY WORDS + PREFETCH (tb_adpcm_cpu_pace, 2026-08-17): the previous
  // one-byte-per-client tag cache made EVERY instruction byte an external
  // round trip, and cpu_rom_wait freezes the E/Q divider -- measured 1.70 MHz
  // effective 6809 vs the 2.00 MHz gospel rate (rom_wait 15% duty). That is
  // fatal at the music driver's own service budget: MAME (adpcm_ym_cadence.lua,
  // totcarn) shows the driver running YM timer A at a 72 us FIRQ tick -- ~143
  // CPU cycles per interrupt at full speed -- so a 15% pace deficit consumes
  // the entire budget: slow tempo, late/lost key-offs ("notes stuck").
  //
  // Shape: per client, two entries of {word tag, 16-bit data, per-byte valid}.
  //  - a DEMAND fetches exactly the wanted byte (ready the moment it lands);
  //    the consumption-edge stall above hides its latency, so no prefetch is
  //    needed (a prefetch variant measured identically and was deleted);
  //  - the OKI's two entries end the adpcm-vs-phrase-table thrash of the old
  //    single tag (jt6295_rom time-muxes those two streams by design):
  //    steady-state playback stops generating a refetch on every stream
  //    alternation. Stale-byte detector in tb_adpcm_cpu_pace reads ZERO.
  // The anti-starvation contract of b8b6f3d is preserved: every request is
  // for a byte some client lacks; when nothing is pending the address
  // FREEZES. sim/run_adpcm_starve_gate.sh (MUT_ADPCM_FREE_RUN) still guards
  // the arbiter-tax bar.
  logic [19:0] cpu_tag  [0:1];
  logic [15:0] cpu_dat  [0:1];
  logic [1:0]  cpu_v    [0:1];
  logic        cpu_lru;            // which entry to replace next
  logic [19:0] oki_tag  [0:1];
  logic [15:0] oki_dat  [0:1];
  logic [1:0]  oki_v    [0:1];
  logic        oki_lru;

  wire [19:0] cpu_word = cpu_rom_want[20:1];
  wire        cpu_bsel = cpu_rom_want[0];
  wire cpu_hit0 = (cpu_tag[0] == cpu_word) && cpu_v[0][cpu_bsel];
  wire cpu_hit1 = (cpu_tag[1] == cpu_word) && cpu_v[1][cpu_bsel];
  wire [15:0] cpu_hit_word = cpu_hit0 ? cpu_dat[0] : cpu_dat[1];
  wire [7:0]  cpu_rom_data = cpu_bsel ? cpu_hit_word[15:8] : cpu_hit_word[7:0];

  wire [19:0] oki_word = oki_rom_want[20:1];
  wire        oki_bsel = oki_rom_want[0];
  wire oki_hit0 = (oki_tag[0] == oki_word) && oki_v[0][oki_bsel];
  wire oki_hit1 = (oki_tag[1] == oki_word) && oki_v[1][oki_bsel];
  wire [15:0] oki_hit_word = oki_hit0 ? oki_dat[0] : oki_dat[1];

  assign cpu_rom_ready = cpu_fixed ? fix_ready : (cpu_hit0 || cpu_hit1);
  assign cpu_rom_wait = cpu_rnw && cpu_rom && !cpu_rom_ready;

  // DEMAND-GATED round-robin. The previous FSM presented an address and
  // switched clients EVERY CYCLE once both were valid, toggling ext_rom_addr
  // between two far-apart streams forever. The downstream word cache treats
  // every presented address as demand, at least one side of the toggle always
  // misses, and the sound client sits ABOVE the CPU window in the SDRAM
  // arbiter -- so the board generated continuous, content-independent SDRAM
  // traffic for bytes nobody needed and starved the main CPU to ~5% of its
  // pace (measured: totcarn profile boot 4.81M cycles sound-off vs 88.21M
  // sound-on, IDENTICAL with a real and an all-zero sound ROM -- the
  // signature of a request cadence independent of content). That is Total
  // Carnage's cabinet "barely loads": a ~25 s MAME boot at ~5% pace is
  // minutes, and TC's own software watchdog turns the crawl into restarts.
  //
  // Contract now: advance the mux ONLY toward a client that needs a byte
  // (want != held tag), latch only what was needed, and FREEZE the address
  // when neither client wants anything -- a stable, already-served address
  // generates no downstream fetches. Sound behaviour is unchanged: every
  // needed byte is still fetched, in the same round-robin order.
`ifdef MUT_ADPCM_FREE_RUN
  // MUTANT (tb_adpcm_arb_starve kill control): unconditional need restores the
  // pre-fix free-running fetch/alternate behaviour -- measured CPU grant
  // retention 0.0% vs the fix's 82.7%.
  wire cpu_need = 1'b1;
  wire oki_need = 1'b1;
`else
  wire cpu_need = cpu_rnw && cpu_rom && !cpu_fixed && !cpu_rom_ready;
  wire oki_need = !(oki_hit0 || oki_hit1);
`endif

  // Bounded prefetch scan for the 6809's sequential stream: the missing byte
  // of the CURRENT word first, then the two bytes of the NEXT word, ascending.
  // At most 3 bytes ahead of the wanted byte; nothing else is ever requested.
  // One outstanding fetch; the CPU outranks the OKI (the OKI demands a couple
  // of bytes per 264 us sample pair -- it waits at most one byte fetch; the
  // 6809 demands continuously when it misses).
  //
  // NO PREFETCH -- measured unnecessary (tb_adpcm_cpu_pace 2026-08-17): with
  // the consumption-edge stall above, demand-only fetching already runs the
  // 6809 at 2.000 MHz in both windows; a 3-byte-ahead prefetch variant
  // measured identically and was deleted rather than shipped ungated.
  typedef enum logic [1:0] {FK_CPU, FK_OKI} fetch_kind_t;
  fetch_kind_t fetch_kind;
  logic        fetch_on;
  logic [20:0] fetch_addr;
`ifdef MUT_ADPCM_FREE_RUN
  logic        rr_mut = 1'b0;
`endif
  assign ext_rom_addr = fetch_addr;

  // fill target: entry already holding the word, else the client's LRU entry
  wire [19:0] fill_word = fetch_addr[20:1];
  wire        fill_bsel = fetch_addr[0];
  wire fill_cpu = (fetch_kind != FK_OKI);
  wire cpu_fill_hit0 = (cpu_tag[0] == fill_word) && (cpu_v[0] != 2'b00);
  wire cpu_fill_hit1 = (cpu_tag[1] == fill_word) && (cpu_v[1] != 2'b00);
  wire cpu_fill_e = cpu_fill_hit0 ? 1'b0 : cpu_fill_hit1 ? 1'b1 : cpu_lru;
  wire cpu_fill_fresh = !(cpu_fill_hit0 || cpu_fill_hit1);
  wire oki_fill_hit0 = (oki_tag[0] == fill_word) && (oki_v[0] != 2'b00);
  wire oki_fill_hit1 = (oki_tag[1] == fill_word) && (oki_v[1] != 2'b00);
  wire oki_fill_e = oki_fill_hit0 ? 1'b0 : oki_fill_hit1 ? 1'b1 : oki_lru;
  wire oki_fill_fresh = !(oki_fill_hit0 || oki_fill_hit1);

  always_ff @(posedge clk) begin
    if (board_reset) begin
      fetch_on   <= 1'b0;
      fetch_kind <= FK_CPU;
      fetch_addr <= 21'd0;
      cpu_tag[0] <= 20'd0; cpu_tag[1] <= 20'd0;
      cpu_dat[0] <= 16'h0; cpu_dat[1] <= 16'h0;
      cpu_v[0]   <= 2'b00; cpu_v[1]   <= 2'b00;
      cpu_lru    <= 1'b0;
      oki_tag[0] <= 20'd0; oki_tag[1] <= 20'd0;
      oki_dat[0] <= 16'h0; oki_dat[1] <= 16'h0;
      oki_v[0]   <= 2'b00; oki_v[1]   <= 2'b00;
      oki_lru    <= 1'b0;
    end else begin
      // MRU tracking: the entry serving the current hit is the one to keep.
      if (cpu_hit0) cpu_lru <= 1'b1;
      else if (cpu_hit1) cpu_lru <= 1'b0;
      if (oki_hit0) oki_lru <= 1'b1;
      else if (oki_hit1) oki_lru <= 1'b0;

      if (fetch_on) begin
        if (ext_rom_ok) begin
          fetch_on <= 1'b0;
          if (fill_cpu) begin
            cpu_tag[cpu_fill_e] <= fill_word;
            if (fill_bsel) cpu_dat[cpu_fill_e][15:8] <= ext_rom_data;
            else           cpu_dat[cpu_fill_e][7:0]  <= ext_rom_data;
            cpu_v[cpu_fill_e] <= (cpu_fill_fresh ? 2'b00 : cpu_v[cpu_fill_e])
                                 | (fill_bsel ? 2'b10 : 2'b01);
          end else begin
            oki_tag[oki_fill_e] <= fill_word;
            if (fill_bsel) oki_dat[oki_fill_e][15:8] <= ext_rom_data;
            else           oki_dat[oki_fill_e][7:0]  <= ext_rom_data;
            oki_v[oki_fill_e] <= (oki_fill_fresh ? 2'b00 : oki_v[oki_fill_e])
                                 | (fill_bsel ? 2'b10 : 2'b01);
            if (oki_fill_fresh) oki_lru <= ~oki_fill_e;
          end
          if (fill_cpu && cpu_fill_fresh) cpu_lru <= ~cpu_fill_e;
        end
`ifdef MUT_ADPCM_FREE_RUN
      // Mutant issue policy: unconditional strict alternation between the two
      // clients' (forced-true) wants -- the pre-b8b6f3d interleave of two
      // far-apart streams that thrashed the downstream word cache and starved
      // the main CPU. Without the alternation the forced needs would re-request
      // the SAME byte (a downstream cache hit, no SDRAM traffic) and the
      // starve gate's kill would be vacuous.
      end else begin
        fetch_addr <= rr_mut ? oki_rom_want : cpu_rom_want;
        fetch_kind <= rr_mut ? FK_OKI : FK_CPU;
        rr_mut     <= ~rr_mut;
        fetch_on   <= 1'b1;
      end
`else
      end else if (cpu_need) begin
        fetch_addr <= cpu_rom_want;  fetch_kind <= FK_CPU;  fetch_on <= 1'b1;
      end else if (oki_need) begin
        fetch_addr <= oki_rom_want;  fetch_kind <= FK_OKI;  fetch_on <= 1'b1;
      end
      // nothing pending: HOLD -- the address freezes, no downstream traffic.
`endif
    end
  end

  always_comb begin
    oki_rom_ok   = oki_hit0 || oki_hit1;
    oki_rom_data = oki_bsel ? oki_hit_word[15:8] : oki_hit_word[7:0];
  end

  always_comb begin
    if (!cpu_rnw)                         cpu_din = cpu_dout;
    else if (cpu_addr < 16'h2000)         cpu_din = ram_q;
    else if (io_ym)                       cpu_din = ym_dout;
    else if (io_oki)                      cpu_din = oki_dout;
    else if (io_cmd)                      cpu_din = command_latch;
    // install_ram() OVERRIDES the ROM mapping, so this must outrank cpu_rom.
    else if (prot_hit)                    cpu_din = prot_q;
    else if (cpu_rom && cpu_rom_ready)     cpu_din = cpu_fixed ? fix_q : cpu_rom_data;
    else                                  cpu_din = 8'hff;
  end

  // MAME board gains: YM L/R 0.10 each, 8-bit DAC 0.10, OKI 0.15.
  // Use a wide signed accumulator and saturate once, then duplicate the mono
  // board output. The constants are close integer approximations of the gains.
  // REGISTERED OUTPUT (2026-08-18, the MK/TC "crinkling foil" fix). This
  // block was always_comb wired straight to the emu's AUDIO_L/R: sys_top
  // samples audio in ITS OWN clock domain, so every settling glitch of the
  // combinational multiply-accumulate below was capturable as a full-scale
  // transient -- wideband crackle over otherwise-correct audio. The CVSD
  // board's mixer output is registered (yunit_audio_mix.sv:81) and Smash is
  // clean on the same framework path -- the differential that located this.
  // One clk_snd flop restores parity; RTL sim cannot exercise the defect
  // (no async sampler exists in sim), so the evidence is the cab A/B.
  logic signed [17:0] dac_signed, oki_signed;
  // WIDTH FIX (cab crunch root cause): the per-term products (e.g. ym_left*26 =
  // 32767*26 = 851942) overflow a 20-bit signed context (max 524287) and SIGN-
  // FLIP on loud FM -> the "clipping/2-ohm-speaker" crunch. OKI (14-bit*152)
  // only truncates same-sign, so samples stayed mostly clean while FM crunched.
  // Full-precision 32-bit accumulator + 32-bit constants; max |mix| ~= 14848
  // (below 16-bit), so saturation is a guard, not the normal path.
`ifdef MUT_ADPCM_MIX_NARROW
  logic signed [19:0] mix;   // MUTANT (run_mutation_gates): the shipped 20-bit overflow
`else
  logic signed [31:0] mix;
`endif
  always_comb begin
    dac_signed = ($signed({1'b0, dac_data}) - 18'sd128) <<< 8;
    oki_signed = {{4{oki_sound[13]}}, oki_sound};
    // OKI gain (cab-tuned 2026-08-21 "samples too soft"): jt6295 DECODES 12-bit
    // ADPCM (jt6295.v:59 pipe_snd[11:0]) into a 14-bit accumulator, so a typical
    // 1-2 voice sample peaks ~+/-2048-4096, NOT the +/-8192 (14-bit rail) the old
    // 152/256*(8192/32768)=0.148 assumed -- it ran samples ~4x TOO SOFT. 614/256
    // restores the level (cross-validated: T-unit's cab-tuned OKI is 614/256 on
    // the same jt6295). Watch: a rare 4+voice passage toward the 14-bit rail plus
    // loud FM can reach the mix saturation -- a clean hard-clip (32-bit accum, no
    // wrap), not distortion; trim 614 if a dense passage clips on the cab.
`ifdef MUT_ADPCM_MIX_NARROW
    mix = ($signed(ym_left)  * 20'sd26 >>> 8)
        + ($signed(ym_right) * 20'sd26 >>> 8)
        + (dac_signed        * 20'sd26 >>> 8)
        + (oki_signed        * 20'sd614 >>> 8);
`else
    mix = ($signed(ym_left)  * 32'sd26 >>> 8)
        + ($signed(ym_right) * 32'sd26 >>> 8)
        + (dac_signed        * 32'sd26 >>> 8)
        + (oki_signed        * 32'sd614 >>> 8);
`endif
  end
  always_ff @(posedge clk) begin
    if (mix > 32'sd32767) begin
      audio_l <= 16'sh7fff;
      audio_r <= 16'sh7fff;
    end else if (mix < -32'sd32768) begin
      audio_l <= -16'sh8000;
      audio_r <= -16'sh8000;
    end else begin
      audio_l <= mix[15:0];
      audio_r <= mix[15:0];
    end
  end
endmodule
`default_nettype wire
