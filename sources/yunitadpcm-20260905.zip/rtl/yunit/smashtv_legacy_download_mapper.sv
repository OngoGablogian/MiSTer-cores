// Exact single-index ROM mapper used by the cabinet-good firefix/mixboot core.
//
// The legacy Smash MRA emits one index-0 stream:
//   000000..11ffff  raw 6bpp graphics planes
//   120000..13ffff  U105 program low lane
//   140000..15ffff  U89 program high lane
//   160000..18ffff  U4/U19/U20 CVSD ROMs
//
// This module has intentionally no game reset input. MiSTer commonly holds the
// emulated board in reset during download; the mapper itself must keep writing.
`timescale 1ns/1ps
`default_nettype none

module smashtv_legacy_download_mapper #(
  parameter logic [24:0] SCRATCH_WBASE = 25'h120000,
  parameter logic [24:0] ROMW_BASE     = 25'h0c0000
) (
  input  logic        clk,
  input  logic        ioctl_download,
  input  logic        ioctl_wr,
  input  logic  [7:0] ioctl_index,
  input  logic [24:0] ioctl_addr,
  input  logic  [7:0] ioctl_dout,

  output logic        rom_download,
  output logic        mapped_wr,
  output logic [24:0] mapped_addr,
  output logic [15:0] mapped_dout,
  output logic  [1:0] mapped_be,
  output logic        snd_wr,
  output logic [17:0] snd_addr,
  output logic  [7:0] snd_data
);
  localparam logic [24:0] DL_ROM_BASE   = 25'h120000;
  localparam logic [24:0] DL_ROMHI_BASE = 25'h140000;
  localparam logic [24:0] DL_SND_BASE   = 25'h160000;
  localparam logic [24:0] DL_END        = 25'h190000;

  logic [7:0] pair_lo;

  always_comb rom_download = ioctl_download && (ioctl_index == 8'd0);

  always_ff @(posedge clk) begin
    mapped_wr <= 1'b0;
    snd_wr    <= 1'b0;

    if (rom_download && ioctl_wr) begin
      if (ioctl_addr < DL_ROM_BASE) begin
        if (!ioctl_addr[0])
          pair_lo <= ioctl_dout;
        else begin
          mapped_addr <= SCRATCH_WBASE + {1'b0, ioctl_addr[24:1]};
          mapped_dout <= {ioctl_dout, pair_lo};
          mapped_be   <= 2'b11;
          mapped_wr   <= 1'b1;
        end
      end else if (ioctl_addr < DL_ROMHI_BASE) begin
        mapped_addr <= ROMW_BASE + (ioctl_addr - DL_ROM_BASE);
        mapped_dout <= {8'h00, ioctl_dout};
        mapped_be   <= 2'b01;
        mapped_wr   <= 1'b1;
      end else if (ioctl_addr < DL_SND_BASE) begin
        mapped_addr <= ROMW_BASE + (ioctl_addr - DL_ROMHI_BASE);
        mapped_dout <= {ioctl_dout, 8'h00};
        mapped_be   <= 2'b10;
        mapped_wr   <= 1'b1;
      end else if (ioctl_addr < DL_END) begin
        snd_addr <= ioctl_addr - DL_SND_BASE;
        snd_data <= ioctl_dout;
        snd_wr   <= 1'b1;
      end
    end
  end
endmodule

`default_nettype wire
