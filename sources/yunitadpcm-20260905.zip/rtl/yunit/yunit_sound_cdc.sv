// yunit_sound_cdc.sv -- lossless Y-unit sound-latch crossing (96 MHz -> 12 MHz).
//
// The main CPU writes each board action as two closely spaced 16-bit values.
// D[9] is the PIA CB1 level and D[8] is the active-low CPU reset. A plain 2-FF
// level synchronizer can miss either narrow level when both writes fit between
// clk_snd edges. Stretch only the active level long enough for the destination
// synchronizers; preserve the board-visible level/edge protocol.
`timescale 1ns/1ps
`default_nettype none
module yunit_sound_cdc #(
  // 1.33 us at 96 MHz: sixteen clk_snd periods and more than two complete
  // 2 MHz 6809 enable periods. Reset must reach the CPU, not merely its 12 MHz
  // domain synchronizer; the same width is harmless for the PIA CB1 command.
  parameter integer SYS_HOLD_CYCLES = 128
) (
  input  logic       clk_sys,
  input  logic       clk_snd,
  input  logic       rst_pon,
  input  logic [7:0] snd_select,
  input  logic       snd_trig,
  input  logic       snd_reset,
  output logic [7:0] sel_snd,
  output logic       trig_snd,
  output logic       reset_snd
);
  localparam integer HOLD_W = (SYS_HOLD_CYCLES < 2) ? 1 : $clog2(SYS_HOLD_CYCLES + 1);

  logic [HOLD_W-1:0] trig_hold;
  logic [HOLD_W-1:0] reset_hold;
  logic [7:0]         select_hold;

  // Source-domain minimum-width filters. Reloading while the active level is
  // present also handles the power-on defaults (CB1 low, reset asserted).
  always_ff @(posedge clk_sys) begin
    if (rst_pon) begin
      trig_hold   <= HOLD_W'(SYS_HOLD_CYCLES);
      reset_hold  <= HOLD_W'(SYS_HOLD_CYCLES);
      select_hold <= 8'h00;
    end else begin
      if (!snd_trig) begin
        trig_hold   <= HOLD_W'(SYS_HOLD_CYCLES);
        select_hold <= snd_select;
      end else if (trig_hold != 0) begin
        trig_hold <= trig_hold - 1'b1;
      end

      if (snd_reset)
        reset_hold <= HOLD_W'(SYS_HOLD_CYCLES);
      else if (reset_hold != 0)
        reset_hold <= reset_hold - 1'b1;
    end
  end

`ifdef MUT_SND_CDC_RAW_LEVEL
  // Discriminating mutation: the former raw level crossing. The close-pair CDC
  // gate must show that at least one legal clock phase loses the command/reset.
  wire trig_sys  = snd_trig;
  wire reset_sys = snd_reset;
  wire [7:0] select_sys = snd_select;
`else
  wire trig_sys  = snd_trig && (trig_hold == 0);
  wire reset_sys = snd_reset || (reset_hold != 0);
  wire [7:0] select_sys = select_hold;
`endif

  (* preserve *) logic [1:0] trig_sync = 2'b00;
  (* preserve *) logic [1:0] reset_sync = 2'b11;
  logic [7:0] sel_meta = 8'h00;

  always_ff @(posedge clk_snd) begin
    if (rst_pon) begin
      trig_sync  <= 2'b00;
      reset_sync <= 2'b11;
      sel_meta   <= 8'h00;
      sel_snd    <= 8'h00;
    end else begin
      trig_sync  <= {trig_sync[0], trig_sys};
      reset_sync <= {reset_sync[0], reset_sys};
      sel_meta   <= select_sys;
      sel_snd    <= sel_meta;
    end
  end

  assign trig_snd  = trig_sync[1];
  assign reset_snd = reset_sync[1];
endmodule
`default_nettype wire
