// yunit_autoerase_sdram_backend.sv
//
// Physical backend for yunit_autoerase_scheduler when VRAM lives in SDRAM.
// Each accepted immutable job copies one complete 512-word framebuffer row:
// first a page-mode burst read into a local row buffer, then a page-mode burst
// write to the destination. The buffer is intentional; opening source and
// destination rows at once is impossible on the single SDRAM data port, and
// buffering also makes the copied template immutable for the whole job.

`default_nettype none

module yunit_autoerase_sdram_backend #(
  // SDRAM word address of Y-unit VRAM. Each physical line is 512 words and the
  // controller port uses byte addresses.
  parameter logic [24:0] VRAM_WORD_BASE = 25'h0e0000
) (
  input  logic        clk,
  input  logic        rst,

  input  logic        job_valid,
  output logic        job_ready,
  input  logic [8:0]  job_src_row,
  input  logic [8:0]  job_dst_row,
  output logic        job_done,
  output logic        protocol_error,

  // sdram_stock page-mode burst-read port.
  output logic        brd_req,
  output logic [24:0] brd_addr,
  output logic [9:0]  brd_len,
  input  logic [15:0] brd_dout,
  input  logic        brd_dvalid,
  input  logic        brd_done,

  // sdram_stock page-mode burst-write stream.
  output logic        bwr_req,
  output logic [24:0] bwr_addr,
  output logic [9:0]  bwr_len,
  output logic [15:0] bwr_din,
  output logic [1:0]  bwr_wtbt,
  output logic        bwr_valid,
  input  logic        bwr_ready,
  input  logic        bwr_done
);

  localparam logic [9:0] ROW_WORDS = 10'd512;

  // row_buffer is a SIMPLE DUAL-PORT M10K: one write address, one read address,
  // both clocked, no asynchronous read. Written as three accesses inside the FSM
  // (write at read_count, read at 0, read at write_count+1) it presents THREE
  // addresses to one array and Quartus gives up on inference, unrolling it into
  // 512*16 = 8192 discrete flops plus the select tree -- ~4.1k ALMs of the fit
  // overage, for a block that costs a single M10K when inferred. Same failure
  // mode as the nvram: the defect is the PORT SHAPE, not the storage.
  //
  // Write and read must stay separate ports (not one muxed address): the final
  // read beat can assert brd_dvalid and brd_done in the SAME cycle, which wants
  // a write to read_count and a read of index 0 simultaneously.
  logic [15:0] row_buffer [0:511];
  logic [9:0]  read_count;
  logic [9:0]  write_count;
  logic [15:0] write_data_q;   // == the RAM's registered read port

  typedef enum logic [1:0] {
    B_IDLE,
    B_READ,
    B_WRITE
  } backend_state_t;
  backend_state_t state;

  wire [24:0] src_word_addr =
      VRAM_WORD_BASE + {{7{1'b0}}, job_src_row, 9'd0};
  wire [24:0] dst_word_addr =
      VRAM_WORD_BASE + {{7{1'b0}}, job_dst_row, 9'd0};
  wire write_beat = bwr_valid && bwr_ready;

  wire        rb_we    = (state == B_READ) && brd_dvalid && (read_count < ROW_WORDS);
  wire [8:0]  rb_waddr = read_count[8:0];

  // One-ahead prefetch, cycle-identical to the previous in-FSM reads: the address
  // is presented in the same cycle the old code performed the array read, so the
  // registered output lands on exactly the edge the old write_data_q did.
  wire        rb_re    = ((state == B_READ)  && brd_done)
                      || ((state == B_WRITE) && write_beat && (write_count < (ROW_WORDS - 10'd1)));
  wire [8:0]  rb_raddr = (state == B_READ) ? 9'd0 : (write_count[8:0] + 9'd1);

  // The RAM lives in its own process, with NO reset on the read port: resetting a
  // RAM output register is one of the things that quietly blocks M10K inference,
  // and write_data_q is don't-care until the first prefetch anyway (bwr_valid is
  // low outside B_WRITE, so nothing consumes it).
  always_ff @(posedge clk) begin
    if (rb_we) row_buffer[rb_waddr] <= brd_dout;
    if (rb_re) write_data_q <= row_buffer[rb_raddr];
  end

  assign job_ready = (state == B_IDLE);
  assign brd_len   = ROW_WORDS;
  assign bwr_len   = ROW_WORDS;
  assign bwr_wtbt  = 2'b11;
  assign bwr_din   = write_data_q;
  assign bwr_valid = (state == B_WRITE) && (write_count < ROW_WORDS);

  always_ff @(posedge clk) begin
    if (rst) begin
      state          <= B_IDLE;
      job_done       <= 1'b0;
      protocol_error <= 1'b0;
      brd_req        <= 1'b0;
      brd_addr       <= 25'd0;
      bwr_req        <= 1'b0;
      bwr_addr       <= 25'd0;
      read_count     <= 10'd0;
      write_count    <= 10'd0;
    end else begin
      job_done <= 1'b0;

      unique case (state)
        B_IDLE: begin
          brd_req <= 1'b0;
          bwr_req <= 1'b0;
          if (job_valid) begin
            brd_addr   <= src_word_addr << 1;
            bwr_addr   <= dst_word_addr << 1;
            read_count <= 10'd0;
            brd_req    <= 1'b1;
            // Reserve the write burst at the same time as the read burst.
            // sdram_stock gives the read priority, retains this pending write,
            // then launches it before any later single-beat request. This makes
            // one accepted row-copy job ordered as a unit at the SDRAM port.
            bwr_req    <= 1'b1;
            state      <= B_READ;
          end
        end

        B_READ: begin
          if (brd_dvalid) begin
            if (read_count < ROW_WORDS) begin
              // the store itself is done by the RAM process above (rb_we/rb_waddr)
              read_count <= read_count + 10'd1;
            end else begin
              protocol_error <= 1'b1;
            end
          end

          if (brd_done) begin
            brd_req <= 1'b0;
            if (read_count != ROW_WORDS)
              protocol_error <= 1'b1;
            write_count  <= 10'd0;
            // write_data_q <= row_buffer[0] is now the rb_re prefetch (same edge)
            state        <= B_WRITE;
          end
        end

        B_WRITE: begin
          if (write_beat) begin
            write_count <= write_count + 10'd1;
            // the next-word prefetch is now the rb_re read above (same condition)
          end

          if (bwr_done) begin
            bwr_req <= 1'b0;
            if (write_count != ROW_WORDS)
              protocol_error <= 1'b1;
            job_done <= 1'b1;
            state    <= B_IDLE;
          end
        end

        default: state <= B_IDLE;
      endcase
    end
  end

endmodule

`default_nettype wire
