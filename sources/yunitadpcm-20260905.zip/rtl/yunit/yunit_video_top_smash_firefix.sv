// yunit_video_top_smash_firefix.sv — Phase 6 W3: video subsystem. Combines yunit_video_smash_firefix (VRAM word ->
// pen_map6 -> palette -> RGB, external raster) with yunit_scanline_smash_firefix (double-buffered VRAM
// line fetch over the SDRAM scan_* channel). yunit_video_smash_firefix is UNCHANGED — the line-buffer
// transparently serves its per-pixel 1-clk VRAM read from SDRAM. The palette read port
// (pal_raddr/pal_rdata) passes through to a palette BRAM the emu provides.
`timescale 1ns/1ps
`default_nettype none
module yunit_video_top_smash_firefix
  import yunit_pkg::*;
#(
  parameter int H_ACT=410, H_FP=6, H_SYNC=40, H_BP=50,
  parameter int V_ACT=256, V_FP=13, V_SYNC=8, V_BP=12,
  parameter int DISP_ROW0=0,
  parameter int NCOL=512
)(
  input  logic        clk,
  input  logic        rst,
  input  logic        ce_pix,
  // Accepted DMA framebuffer write-through for prefetched-line coherency.
  input  logic        snoop_we,
  input  logic [17:0] snoop_addr,
  input  logic [15:0] snoop_data,
  // palette read (to the emu's palette BRAM; 1-clk registered)
  output logic [11:0] pal_raddr,
  input  logic [15:0] pal_rdata,
  // SDRAM scanout read channel (to yunit_sdram_arb / vram_sdram_top)
  output logic        scan_req,
  output logic [17:0] scan_addr,
  input  logic [15:0] scan_data,
  input  logic        scan_ack,
  // video output
  output logic [7:0]  vid_r, vid_g, vid_b,
  output logic        hsync, vsync, hblank, vblank, de,
  output logic        vblank_irq
);
  // yunit_video_smash_firefix <-> yunit_scanline_smash_firefix VRAM read
  logic [FB_ADDR_W-1:0] vram_raddr; logic [15:0] vram_rdata;
  logic vblank_i, vblank_scan;

  yunit_video_smash_firefix #(
    .H_ACT(H_ACT), .H_FP(H_FP), .H_SYNC(H_SYNC), .H_BP(H_BP),
    .V_ACT(V_ACT), .V_FP(V_FP), .V_SYNC(V_SYNC), .V_BP(V_BP), .DISP_ROW0(DISP_ROW0)
  ) u_video (
    .clk(clk), .rst(rst), .ce_pix(ce_pix),
    .vram_raddr(vram_raddr), .vram_rdata(vram_rdata),
    .pal_raddr(pal_raddr), .pal_rdata(pal_rdata),
    .vid_r(vid_r), .vid_g(vid_g), .vid_b(vid_b),
    .hsync(hsync), .vsync(vsync), .hblank(hblank), .vblank(vblank_i), .de(de),
    .vblank_raw(vblank_scan),
    .vblank_irq(vblank_irq));
  assign vblank = vblank_i;

`ifdef MUT_SCANLINE_DELAYED_VBLANK
  wire scanline_vblank = vblank_i;
`else
  // vram_raddr is stage 0, so line-buffer freeze/ownership must be stage 0 too.
  // vblank_i is intentionally three ce_pix stages late for RGB alignment.
  wire scanline_vblank = vblank_scan;
`endif

  yunit_scanline_smash_firefix #(.FB_ADDR_W(FB_ADDR_W), .NCOL(NCOL), .FIRST_ROW(DISP_ROW0)) u_scan (
    .clk(clk), .rst(rst), .ce_pix(ce_pix), .vblank(scanline_vblank),
    .vram_raddr(vram_raddr), .vram_rdata(vram_rdata),
    .snoop_we(snoop_we), .snoop_addr(snoop_addr), .snoop_data(snoop_data),
    .scan_req(scan_req), .scan_addr(scan_addr), .scan_data(scan_data), .scan_ack(scan_ack));
endmodule
`default_nettype wire

