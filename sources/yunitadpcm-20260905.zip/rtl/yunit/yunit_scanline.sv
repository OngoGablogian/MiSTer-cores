// yunit_scanline.sv — Phase 6 W3: double-buffered VRAM line fetch for scanout. Sits between
// yunit_video (per-pixel vram_raddr, expects vram_rdata 1 clk later) and the SDRAM scan_*
// read channel. Invariant: buf[disp] holds the exact descriptor row, while the
// other buffer holds the exact DPYADR lookahead row when it differs. A loader
// fills whichever buffer is stale; repeated rows do not trigger duplicate
// loads and arbitrary DPYADR jumps do not assume row+1.
//
// VRAM entry index = (row << 9) | col (512 cols/row); scan_addr reads VRAM entries.
`timescale 1ns/1ps
`default_nettype none
module yunit_scanline #(
  parameter int FB_ADDR_W = 18,
  parameter int NCOL      = 512,     // entries to prefetch per row (>= visible cols)
  parameter int FIRST_ROW = 0        // VRAM row displayed at frame top (= DISP_ROW0)
)(
  input  logic         clk,
  input  logic         rst,
  input  logic         ce_pix,                 // pixel-clock enable (gates the readout only)
  input  logic         vblank,                 // frame boundary: reprime for the top row
  input  logic         use_dynamic_display,
  input  logic         line_event,
  input  logic         current_line_valid,
  input  logic [8:0]   current_line_row,
  input  logic [8:0]   current_line_col,
  input  logic         prefetch_valid,
  input  logic [8:0]   prefetch_row,
  input  logic [8:0]   prefetch_col,
  output logic         current_row_ready,
  input  logic [FB_ADDR_W-1:0] vram_raddr,     // (row<<9)|col  (from yunit_video)
  output logic [15:0]  vram_rdata,             // registered, 1 ce_pix latency (matches BRAM model)
  // Accepted DMA framebuffer writes.  The next row is prefetched before it is
  // displayed, so it must be updated when a later blit lands in that row.
  input  logic         snoop_we,
  input  logic [FB_ADDR_W-1:0] snoop_addr,
  input  logic [15:0]  snoop_data,
  // A completed physical full-row replacement (autoerase).  Any cached copy
  // and any newer-write overlay for that row are stale and must be refetched.
  input  logic         invalidate_valid,
  input  logic [8:0]   invalidate_row,
  output logic         scan_req,
  output logic [17:0]  scan_addr,
  input  logic [15:0]  scan_data,
  input  logic         scan_ack
);
  localparam int ROWW = FB_ADDR_W - 9;
`ifdef MUT_DYNAMIC_FULL_ROW_REFILL
  // Cabinet regression: restore the 512-word refill that exceeds a physical
  // scanline on the single-word DDR path and starves/tears live rendering.
  localparam int REFILL_WORDS = 512;
`else
  localparam int REFILL_WORDS = NCOL;
`endif
  wire [ROWW-1:0] req_row = vram_raddr[FB_ADDR_W-1:9];
  wire [8:0]      req_col = vram_raddr[8:0];

  (* ramstyle = "no_rw_check" *) logic [15:0] lb0 [0:511];
  (* ramstyle = "no_rw_check" *) logic [15:0] lb1 [0:511];
  // One-write-port overlays hold logical DMA commits that are newer than a
  // prefetched line.  Keeping these separate avoids asking either line-buffer
  // M10K to perform a loader write and a snoop write at different addresses in
  // the same clock.  Valid bits are cleared whenever a buffer is repurposed.
  (* ramstyle = "no_rw_check" *) logic [15:0] ov0 [0:511];
  (* ramstyle = "no_rw_check" *) logic [15:0] ov1 [0:511];
  logic [511:0] ov0_valid, ov1_valid;
  logic disp_sel;
  logic [ROWW-1:0] disp_row;   // (declared before sel_now: Questa/Quartus need decl-before-use)
  logic [8:0] disp_col;
  // which row each buffer currently holds (+ valid)
  logic [ROWW-1:0] buf_row [0:1]; logic buf_valid [0:1];
  logic [8:0] buf_col [0:1];
  logic [ROWW-1:0] next_row_q;
  logic [8:0]       next_col_q;
  logic            next_valid_q;
  wire dynamic_display = (use_dynamic_display === 1'b1);
  wire line_event_on = (line_event === 1'b1);
  wire current_line_valid_on = (current_line_valid === 1'b1);
  wire prefetch_valid_on = (prefetch_valid === 1'b1);
  wire invalidate_on = (invalidate_valid === 1'b1);
  wire [ROWW-1:0] next_row =
      dynamic_display ? next_row_q : (disp_row + 1'b1);
  wire [8:0] next_col = dynamic_display ? next_col_q : 9'd0;
  wire next_valid = dynamic_display ? next_valid_q : 1'b1;

  // The physical line is a 512-word ring.  Dynamic DPYTAP may begin near its
  // end, so the H_ACT-word cache window can wrap through column zero.
  function automatic logic col_in_window(
    input logic [8:0] col,
    input logic [8:0] first_col
  );
    logic [8:0] delta;
    begin
      delta = col - first_col;
      if (REFILL_WORDS >= 512)
        col_in_window = 1'b1;
      else
        col_in_window = (delta < REFILL_WORDS);
    end
  endfunction

  wire ready0 = buf_valid[0] && (buf_row[0] == disp_row)
             && (!dynamic_display || (buf_col[0] == disp_col));
  wire ready1 = buf_valid[1] && (buf_row[1] == disp_row)
             && (!dynamic_display || (buf_col[1] == disp_col));
`ifdef MUT_SCANLINE_HIT_REGISTERED_ROW
  // Restore the 410-word-window regression: choose from the descriptor row
  // registered on the previous edge instead of the row requested by the
  // raster now.  The row-boundary live-write gate must reject this.
  wire hit0 = ready0 && col_in_window(req_col, buf_col[0]);
  wire hit1 = ready1 && col_in_window(req_col, buf_col[1]);
`else
  // Buffer readiness gates the descriptor contract, but the data mux must
  // follow the address being sampled on this edge.  At a row boundary
  // vram_raddr already names the prefetched row while disp_row is not updated
  // until the edge; using ready* here therefore replays the previous row and
  // assigns snoop ownership to the wrong buffer.  Dynamic mode additionally
  // requires the exact descriptor window because two windows of a repeated
  // physical row can overlap.
  wire hit0 = buf_valid[0] && (buf_row[0] == req_row)
             && (!dynamic_display || (buf_col[0] == disp_col))
             && col_in_window(req_col, buf_col[0]);
  wire hit1 = buf_valid[1] && (buf_row[1] == req_row)
             && (!dynamic_display || (buf_col[1] == disp_col))
             && col_in_window(req_col, buf_col[1]);
`endif
  // Select the buffer COMBINATIONALLY: if the raster row has already advanced past disp_row
  // (the registered swap lands next edge), read the prefetched (next-row) buffer NOW -- else
  // the first pixel of each row would read the stale buffer (1-clk swap latency artifact).
  wire sel_now = hit0 ? 1'b0 : hit1 ? 1'b1 : disp_sel;
  always_comb begin
    current_row_ready = ready0 || ready1;
  end

  // Logical ownership follows the row that the raster is using NOW, not the
  // registered swap from the previous clock.  This matters on the exact
  // row-advance edge: sel_now has already promoted the prefetched buffer to
  // the frozen/current row, while the old current buffer immediately becomes
  // the writable future row.  During vblank the two planned rows are fixed.
  wire [ROWW-1:0] planned_row0 = !dynamic_display
      ? (vblank ? ROWW'(FIRST_ROW)
                : (sel_now ? req_row + 1'b1 : req_row))
      : (disp_sel ? (next_valid ? next_row : disp_row) : disp_row);
  wire [ROWW-1:0] planned_row1 = !dynamic_display
      ? (vblank ? ROWW'(FIRST_ROW + 1)
                : (sel_now ? req_row : req_row + 1'b1))
      : (disp_sel ? disp_row : (next_valid ? next_row : disp_row));
  wire [8:0] planned_col0 = !dynamic_display ? 9'd0
      : (disp_sel ? (next_valid ? next_col : disp_col) : disp_col);
  wire [8:0] planned_col1 = !dynamic_display ? 9'd0
      : (disp_sel ? disp_col : (next_valid ? next_col : disp_col));
  // ce_pix-gated read: advance the readout once per pixel, exactly like the BRAM model that
  // yunit_video's 3-stage (vram_rdata -> pal_rdata -> vid) pipeline was validated against.
  // An every-clk read collapses the pipeline and shifts color vs de by ~2 pixels.
  // MUX AFTER THE REGISTER, not before. The previous form was
  //     vram_rdata <= ov0_valid[req_col] ? ov0[req_col] : lb0[req_col];
  // which needs BOTH arrays to present data COMBINATIONALLY so the select can
  // choose before the flop -- i.e. an asynchronous read, which no M10K can do.
  // Quartus said so outright: "RAM logic ...|lb0/lb1/ov0/ov1 is uninferred due
  // to asynchronous read logic", and the four 512x16 buffers landed in fabric:
  // yunit_scanline alone cost 15,063 ALMs, 36% of the whole design, on a fit
  // that overflowed by 4,492 (Error 170012: 4682 LABs needed, 4191 available).
  //
  // Registering each array's output and selecting afterwards gives every array
  // the plain `q <= mem[addr]` shape an M10K needs. LATENCY IS UNCHANGED: the
  // *_q flops capture on the same ce_pix edge the old single flop did, and the
  // output mux is combinational after it, so vram_rdata is still valid exactly
  // one ce_pix later. That matters -- the header contract at :28 and the note
  // above both pin this to 1 ce_pix, and yunit_video's 3-stage pipeline was
  // validated against it ("an every-clk read collapses the pipeline and shifts
  // color vs de by ~2 pixels").
  logic [15:0] lb0_q, lb1_q, ov0_q, ov1_q;
  logic        ovv0_q, ovv1_q, sel_q, hit_q;
  always_ff @(posedge clk) if (ce_pix) begin
    lb0_q  <= lb0[req_col];
    lb1_q  <= lb1[req_col];
    ov0_q  <= ov0[req_col];
    ov1_q  <= ov1[req_col];
    ovv0_q <= ov0_valid[req_col];
    ovv1_q <= ov1_valid[req_col];
    sel_q  <= sel_now;
    hit_q  <= hit0 || hit1;
  end
  assign vram_rdata = !hit_q ? 16'd0
                    : sel_q  ? (ovv1_q ? ov1_q : lb1_q)
                             : (ovv0_q ? ov0_q : lb0_q);

  wire  [ROWW-1:0] snoop_row = snoop_addr[FB_ADDR_W-1:9];
  wire  [8:0]      snoop_col = snoop_addr[8:0];

  // loader: bursts `tgt_row` into buffer `tgt_sel`
  logic loading, tgt_sel; logic [ROWW-1:0] tgt_row;
  logic [8:0] tgt_col, li;
  logic vbl_q;

  wire frame_start = !vbl_q && vblank;
  wire row_advance = !vblank && (req_row != disp_row);
  wire descriptor_advance = dynamic_display && line_event_on
                          && current_line_valid_on
                          && ((current_line_row[ROWW-1:0] != disp_row)
                           || (current_line_col != disp_col));
  wire blank_retarget = dynamic_display && line_event_on
                      && !current_line_valid_on && vblank
                      && prefetch_valid_on
                      && ((prefetch_row[ROWW-1:0] != disp_row)
                       || (prefetch_col != disp_col));
  // Use the same buffer selection for the descriptor and overlay ownership.
  wire descriptor_hit0 = buf_valid[0]
      && (buf_row[0] == current_line_row[ROWW-1:0])
      && (buf_col[0] == current_line_col);
  wire descriptor_hit1 = buf_valid[1]
      && (buf_row[1] == current_line_row[ROWW-1:0])
      && (buf_col[1] == current_line_col);
  wire descriptor_sel = descriptor_hit0 ? 1'b0 : descriptor_hit1 ? 1'b1
      : descriptor_advance ? ~disp_sel : disp_sel;
  // Preserve an overlay only when its planned row/window becomes current
  // in the opposite buffer. Stale cached tags do not establish overlay
  // ownership; selecting the old current buffer is not a promotion.
  wire promote_future_overlay = descriptor_advance && next_valid
      && (next_row == current_line_row[ROWW-1:0])
      && (next_col == current_line_col)
      && (descriptor_sel != disp_sel);
  wire prefetch_retarget = dynamic_display && line_event_on
                         && prefetch_valid_on
                         && (!next_valid_q
                             || (prefetch_row[ROWW-1:0] != next_row_q)
                             || (prefetch_col != next_col_q));
  wire snoop_to0 = snoop_we && col_in_window(snoop_col, planned_col0) &&
                   (snoop_row == planned_row0) && (vblank || sel_now);
  wire snoop_to1 = snoop_we && col_in_window(snoop_col, planned_col1) &&
                   (snoop_row == planned_row1) && (vblank || !sel_now);
  // is either buffer stale vs the current/exact-prefetch ownership contract?
  wire disp_stale = !buf_valid[disp_sel] || (buf_row[disp_sel] != disp_row)
                 || (dynamic_display && (buf_col[disp_sel] != disp_col));
  wire load_stale = next_valid
                 && ((next_row != disp_row)
                  || (dynamic_display && (next_col != disp_col)))
                 && (!buf_valid[~disp_sel]
                     || (buf_row[~disp_sel] != next_row)
                     || (dynamic_display && (buf_col[~disp_sel] != next_col)));
  wire loader_start_ok = !loading && !frame_start
                       && !(dynamic_display && line_event_on);
  wire start_disp_load = loader_start_ok && disp_stale;
  wire start_next_load = loader_start_ok && !disp_stale && load_stale;

  // Clear an overlay only when that physical buffer is reassigned to a new
  // planned row.  A same-edge snoop is applied after the clear here, so it is
  // retained deterministically.  Loader starts do not change ownership and
  // therefore must not erase logical writes already captured for the row.
  logic [511:0] ov0_valid_next, ov1_valid_next;
  always_comb begin
    ov0_valid_next = ov0_valid;
    ov1_valid_next = ov1_valid;
    if (frame_start) begin
      ov0_valid_next = '0;
      ov1_valid_next = '0;
    end else if (row_advance || descriptor_advance) begin
      if (disp_sel) ov1_valid_next = '0;
      else          ov0_valid_next = '0;
    end
    if (blank_retarget) begin
      if (buf_valid[0] && (buf_row[0] == prefetch_row[ROWW-1:0])
          && (buf_col[0] == prefetch_col)) begin
        // Cached ownership already matches the retarget; retain its overlay.
      end else if (buf_valid[1]
                   && (buf_row[1] == prefetch_row[ROWW-1:0])
                   && (buf_col[1] == prefetch_col)) begin
        // Cached ownership already matches the retarget; retain its overlay.
      end else if (disp_sel) begin
        ov1_valid_next = '0;
      end else begin
        ov0_valid_next = '0;
      end
    end
    if (prefetch_retarget
        && !promote_future_overlay
        && ((prefetch_row[ROWW-1:0] != disp_row)
         || (prefetch_col != disp_col))
        && (!buf_valid[~disp_sel]
            || (buf_row[~disp_sel] != prefetch_row[ROWW-1:0])
            || (buf_col[~disp_sel] != prefetch_col))) begin
      if (~disp_sel) ov1_valid_next = '0;
      else           ov0_valid_next = '0;
    end
    if (invalidate_on) begin
      if ((planned_row0 == invalidate_row[ROWW-1:0])
          || (buf_valid[0]
              && (buf_row[0] == invalidate_row[ROWW-1:0]))
          || (loading && !tgt_sel
              && (tgt_row == invalidate_row[ROWW-1:0])))
        ov0_valid_next = '0;
      if ((planned_row1 == invalidate_row[ROWW-1:0])
          || (buf_valid[1]
              && (buf_row[1] == invalidate_row[ROWW-1:0]))
          || (loading && tgt_sel
              && (tgt_row == invalidate_row[ROWW-1:0])))
        ov1_valid_next = '0;
    end
`ifndef MUT_SCANLINE_NO_SNOOP
    if (snoop_to0) ov0_valid_next[snoop_col] = 1'b1;
    if (snoop_to1) ov1_valid_next[snoop_col] = 1'b1;
`endif
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      loading<=1'b0; scan_req<=1'b0; disp_sel<=1'b0; disp_row<='0;
      disp_col<=9'd0;
      buf_valid[0]<=1'b0; buf_valid[1]<=1'b0;
      buf_col[0]<=9'd0; buf_col[1]<=9'd0;
      ov0_valid<='0; ov1_valid<='0;
      next_row_q<=ROWW'(FIRST_ROW + 1); next_col_q<=9'd0;
      next_valid_q<=1'b0;
      vbl_q<=1'b0;
    end else begin
      vbl_q <= vblank;
      ov0_valid <= ov0_valid_next;
      ov1_valid <= ov1_valid_next;
      // vblank START (rising): prime rows FIRST_ROW / FIRST_ROW+1 during the blank so they
      // are valid BEFORE the active region — which is at the top (vc=0), with no vertical
      // back porch, so row 0 displays immediately at frame top. Priming at vblank FALL would
      // race the load against the first pixels of row 0.
      if (frame_start) begin
        disp_sel<=1'b0;
        disp_row<=dynamic_display && next_valid_q
                ? next_row_q : ROWW'(FIRST_ROW);
        disp_col<=dynamic_display && next_valid_q ? next_col_q : 9'd0;
        buf_valid[0]<=1'b0; buf_valid[1]<=1'b0;
        loading<=1'b0; scan_req<=1'b0;   // drop req so the first new request re-edges (model edge-accepts)
      end else begin
        if (dynamic_display && line_event_on) begin
          next_valid_q <= prefetch_valid_on;
          if (prefetch_valid_on) begin
            next_row_q <= prefetch_row[ROWW-1:0];
            next_col_q <= prefetch_col;
          end

          if (current_line_valid_on) begin
            disp_row <= current_line_row[ROWW-1:0];
            disp_col <= current_line_col;
            disp_sel <= descriptor_sel;
          end else if (vblank && prefetch_valid_on
                       && ((prefetch_row[ROWW-1:0] != disp_row)
                        || (prefetch_col != disp_col))) begin
            // During blank, the repeated first-line descriptor may be
            // retargeted by a late DPYADR write.
            disp_row <= prefetch_row[ROWW-1:0];
            disp_col <= prefetch_col;
            if (buf_valid[0]
                && (buf_row[0] == prefetch_row[ROWW-1:0])
                && (buf_col[0] == prefetch_col))
              disp_sel <= 1'b0;
            else if (buf_valid[1]
                     && (buf_row[1] == prefetch_row[ROWW-1:0])
                     && (buf_col[1] == prefetch_col))
              disp_sel <= 1'b1;
          end
        end

        if (row_advance) begin
          // row advanced -> the prefetched next-row buffer becomes the display
          if (hit0) disp_sel<=1'b0;
          else if (hit1) disp_sel<=1'b1;
          else disp_sel<=~disp_sel;
          disp_row<=req_row;
        end

        // start a load when idle and a buffer is stale (display first, then next-row prefetch)
        if (!loading) begin
          // A completed or cancelled loader must never leave a request level
          // resident while idle; the downstream channel edge-accepts requests.
          scan_req <= 1'b0;
          // Descriptor ownership changes above use nonblocking assignments.
          // Wait one clock before choosing a target so the loader cannot start
          // against the previous line's row.
          if (start_disp_load) begin
            tgt_sel<=disp_sel; tgt_row<=disp_row; tgt_col<=disp_col;
            li<=9'd0; loading<=1'b1;
            buf_valid[disp_sel] <= 1'b0;
          end else if (start_next_load) begin
            tgt_sel<=~disp_sel; tgt_row<=next_row; tgt_col<=next_col;
            li<=9'd0; loading<=1'b1;
            buf_valid[~disp_sel] <= 1'b0;
          end
        end else begin
          if (scan_req && scan_ack) begin
            if (tgt_sel) lb1[tgt_col + li] <= scan_data;
            else         lb0[tgt_col + li] <= scan_data;
            scan_req <= 1'b0;
            if (li == REFILL_WORDS-1) begin
              loading<=1'b0;
              buf_row[tgt_sel]<=tgt_row;
              buf_col[tgt_sel]<=tgt_col;
              buf_valid[tgt_sel]<=1'b1;
            end
            else li <= li + 9'd1;
          end else if (!scan_req) scan_req <= 1'b1;
        end

        // Full-row replacement wins over a same-cycle loader completion.
        // Cancelling a matching outstanding scan request is safe: the lower
        // row cache completes any already accepted burst, then the stale flag
        // below forces this buffer to request the post-replacement row again.
        if (invalidate_on) begin
          if (buf_valid[0]
              && (buf_row[0] == invalidate_row[ROWW-1:0]))
            buf_valid[0] <= 1'b0;
          if (buf_valid[1]
              && (buf_row[1] == invalidate_row[ROWW-1:0]))
            buf_valid[1] <= 1'b0;
          if (loading && (tgt_row == invalidate_row[ROWW-1:0])) begin
            loading <= 1'b0;
            scan_req <= 1'b0;
            buf_valid[tgt_sel] <= 1'b0;
          end
        end
      end

`ifndef MUT_SCANLINE_NO_SNOOP
      // The active buffer is a frozen 34010 shift-register snapshot.  Only the
      // other, planned future row receives logical DMA commits.  The separate
      // overlays also make a snoop concurrent with a loader write single-port
      // safe: stale refill data lands in lb*, while the newer overlay wins.
      // During vblank neither row is active, so both planned rows are writable.
      if (snoop_to0) ov0[snoop_col] <= snoop_data;
      if (snoop_to1) ov1[snoop_col] <= snoop_data;
`endif
    end
  end
  assign scan_addr = {tgt_row[8:0], (tgt_col + li)};
endmodule
`default_nettype wire
