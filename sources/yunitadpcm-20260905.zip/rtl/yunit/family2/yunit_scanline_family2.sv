// yunit_scanline_family2.sv — Phase 6 W3: double-buffered VRAM line fetch for scanout. Sits between
// yunit_video_family2 (per-pixel vram_raddr, expects vram_rdata 1 clk later) and the SDRAM scan_*
// read channel. Invariant: buf[disp] holds the display row, buf[~disp] holds the NEXT row
// (prefetched). A loader fills whichever buffer is stale. On a row advance the buffers swap
// (the next-row prefetch becomes the display). yunit_video_family2 is UNCHANGED.
//
// VRAM entry index = (row << 9) | col (512 cols/row); scan_addr reads VRAM entries.
`timescale 1ns/1ps
`default_nettype none
module yunit_scanline_family2 #(
  parameter int FB_ADDR_W = 18,
  parameter int NCOL      = 512,     // entries to prefetch per row (>= visible cols)
  parameter int FIRST_ROW = 0        // VRAM row displayed at frame top (= DISP_ROW0)
)(
  input  logic         clk,
  input  logic         rst,
  input  logic         ce_pix,                 // pixel-clock enable (gates the readout only)
  input  logic         vblank,                 // frame boundary: reprime for the top row
  // Live display base (page flip). FIRST_ROW is the reset default; this is the
  // value in force for the frame being primed. Must track yunit_video_family2's
  // disp_row_dyn or the prefetcher primes a different page than scanout reads.
  input  logic [8:0]   first_row_dyn,
  input  logic [FB_ADDR_W-1:0] vram_raddr,     // (row<<9)|col  (from yunit_video_family2)
  output logic [15:0]  vram_rdata,             // registered, 1 ce_pix latency (matches BRAM model)
  // Accepted DMA framebuffer writes.  The next row is prefetched before it is
  // displayed, so it must be updated when a later blit lands in that row.
  input  logic         snoop_we,
  input  logic [FB_ADDR_W-1:0] snoop_addr,
  input  logic [15:0]  snoop_data,
  output logic         scan_req,
  output logic [17:0]  scan_addr,
  input  logic [15:0]  scan_data,
  input  logic         scan_ack
);
  localparam int ROWW = FB_ADDR_W - 9;
  wire [ROWW-1:0] req_row = vram_raddr[FB_ADDR_W-1:9];
  wire [8:0]      req_col = vram_raddr[8:0];

  (* ramstyle = "no_rw_check" *) logic [15:0] lb0 [0:511];
  (* ramstyle = "no_rw_check" *) logic [15:0] lb1 [0:511];
  // One-write-port overlays hold logical DMA commits that are newer than a
  // prefetched line.  Keeping these separate avoids asking either line-buffer
  // M10K to perform a loader write and a snoop write at different addresses in
  // the same clock.  Valid bits are cleared whenever a buffer is repurposed.
  (* ramstyle = "no_rw_check" *) logic [15:0] ov0 [0:511];
  (* ramstyle = "no_rw_check" *) logic [15:0] ov1 [0:511];
  logic [511:0] ov0_valid, ov1_valid;
  logic disp_sel;
  logic [ROWW-1:0] disp_row;   // (declared before sel_now: Questa/Quartus need decl-before-use)
  // Select the buffer COMBINATIONALLY: if the raster row has already advanced past disp_row
  // (the registered swap lands next edge), read the prefetched (next-row) buffer NOW -- else
  // the first pixel of each row would read the stale buffer (1-clk swap latency artifact).
  wire sel_now = (req_row == disp_row) ? disp_sel : ~disp_sel;

  // Logical ownership follows the row that the raster is using NOW, not the
  // registered swap from the previous clock.  This matters on the exact
  // row-advance edge: sel_now has already promoted the prefetched buffer to
  // the frozen/current row, while the old current buffer immediately becomes
  // the writable future row.  During vblank the two planned rows are fixed.
  wire [ROWW-1:0] planned_row0 = vblank ? ROWW'(first_row_dyn) :
                                    (sel_now ? req_row + 1'b1 : req_row);
  wire [ROWW-1:0] planned_row1 = vblank ? ROWW'(first_row_dyn + 9'd1) :
                                    (sel_now ? req_row : req_row + 1'b1);
  // ce_pix-gated read: advance the readout once per pixel, exactly like the BRAM model that
  // yunit_video_family2's 3-stage (vram_rdata -> pal_rdata -> vid) pipeline was validated against.
  // An every-clk read collapses the pipeline and shifts color vs de by ~2 pixels.
  always_ff @(posedge clk) if (ce_pix) begin
    if (sel_now)
      vram_rdata <= ov1_valid[req_col] ? ov1[req_col] : lb1[req_col];
    else
      vram_rdata <= ov0_valid[req_col] ? ov0[req_col] : lb0[req_col];
  end

  // which row each buffer currently holds (+ valid)
  logic [ROWW-1:0] buf_row [0:1]; logic buf_valid [0:1];
  wire  [ROWW-1:0] next_row = disp_row + 1'b1;
  wire  [ROWW-1:0] snoop_row = snoop_addr[FB_ADDR_W-1:9];
  wire  [8:0]      snoop_col = snoop_addr[8:0];

  // loader: bursts `tgt_row` into buffer `tgt_sel`
  logic loading, tgt_sel; logic [ROWW-1:0] tgt_row; logic [8:0] li;
  logic vbl_q;

  wire frame_start = !vbl_q && vblank;
  wire row_advance = !vblank && (req_row != disp_row);
  wire snoop_to0 = snoop_we && (snoop_col < NCOL) &&
                   (snoop_row == planned_row0) && (vblank || sel_now);
  wire snoop_to1 = snoop_we && (snoop_col < NCOL) &&
                   (snoop_row == planned_row1) && (vblank || !sel_now);

  // Clear an overlay only when that physical buffer is reassigned to a new
  // planned row.  A same-edge snoop is applied after the clear here, so it is
  // retained deterministically.  Loader starts do not change ownership and
  // therefore must not erase logical writes already captured for the row.
  logic [511:0] ov0_valid_next, ov1_valid_next;
  always_comb begin
    ov0_valid_next = ov0_valid;
    ov1_valid_next = ov1_valid;
    if (frame_start) begin
      ov0_valid_next = '0;
      ov1_valid_next = '0;
    end else if (row_advance) begin
      if (disp_sel) ov1_valid_next = '0;
      else          ov0_valid_next = '0;
    end
`ifndef MUT_SCANLINE_NO_SNOOP
    if (snoop_to0) ov0_valid_next[snoop_col] = 1'b1;
    if (snoop_to1) ov1_valid_next[snoop_col] = 1'b1;
`endif
  end

  // is either buffer stale vs the invariant (disp_sel=disp_row, ~disp_sel=next_row)?
  wire disp_stale = !buf_valid[disp_sel] || (buf_row[disp_sel] != disp_row);
  wire load_stale = !buf_valid[~disp_sel] || (buf_row[~disp_sel] != next_row);

  always_ff @(posedge clk) begin
    if (rst) begin
      loading<=1'b0; scan_req<=1'b0; disp_sel<=1'b0; disp_row<='0;
      buf_valid[0]<=1'b0; buf_valid[1]<=1'b0;
      ov0_valid<='0; ov1_valid<='0;
      vbl_q<=1'b0;
    end else begin
      vbl_q <= vblank;
      ov0_valid <= ov0_valid_next;
      ov1_valid <= ov1_valid_next;
      // vblank START (rising): prime rows FIRST_ROW / FIRST_ROW+1 during the blank so they
      // are valid BEFORE the active region — which is at the top (vc=0), with no vertical
      // back porch, so row 0 displays immediately at frame top. Priming at vblank FALL would
      // race the load against the first pixels of row 0.
      if (frame_start) begin
        disp_sel<=1'b0; disp_row<=ROWW'(first_row_dyn); buf_valid[0]<=1'b0; buf_valid[1]<=1'b0;
        loading<=1'b0; scan_req<=1'b0;   // drop req so the first new request re-edges (model edge-accepts)
      end else begin
        if (row_advance) begin
          // row advanced -> the prefetched next-row buffer becomes the display
          disp_sel<=~disp_sel; disp_row<=req_row;
        end

        // start a load when idle and a buffer is stale (display first, then next-row prefetch)
        if (!loading) begin
          if (disp_stale) begin
            tgt_sel<=disp_sel; tgt_row<=disp_row; li<=9'd0; loading<=1'b1;
          end else if (load_stale) begin
            tgt_sel<=~disp_sel; tgt_row<=next_row; li<=9'd0; loading<=1'b1;
          end
        end else begin
          if (scan_req && scan_ack) begin
            if (tgt_sel) lb1[li] <= scan_data; else lb0[li] <= scan_data;
            scan_req <= 1'b0;
            if (li == NCOL-1) begin loading<=1'b0; buf_row[tgt_sel]<=tgt_row; buf_valid[tgt_sel]<=1'b1; end
            else li <= li + 9'd1;
          end else if (!scan_req) scan_req <= 1'b1;
        end
      end

`ifndef MUT_SCANLINE_NO_SNOOP
      // The active buffer is a frozen 34010 shift-register snapshot.  Only the
      // other, planned future row receives logical DMA commits.  The separate
      // overlays also make a snoop concurrent with a loader write single-port
      // safe: stale refill data lands in lb*, while the newer overlay wins.
      // During vblank neither row is active, so both planned rows are writable.
      if (snoop_to0) ov0[snoop_col] <= snoop_data;
      if (snoop_to1) ov1[snoop_col] <= snoop_data;
`endif
    end
  end
  assign scan_addr = {tgt_row[8:0], li};
endmodule
`default_nettype wire

