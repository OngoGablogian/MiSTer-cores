// yunit_video_family2.sv — Williams Y-unit video scanout: frame buffer -> RGB.
//
// Faithful to MAME midyunit_v.cpp scanline_update (:543):
//   src   = local_videoram[(rowaddr << 9) & 0x3fe00]   // row base (pixel idx)
//   pixel = src[coladdr++ & 0x1ff]                      // 512-col wrap
//   dest  = pen_map[pixel]                              // 6bpp: pen_map6()
// then the pen indexes palette RAM (xRGB1555) -> RGB888 (paletteram_w:250,
// pal5bit). This block owns the raster.
//
// CORRECTED 2026-08-02 (audited against the original game assembly). The previous claim here
// -- "the game never programs the 34010 timing regs (measured 2026-07-04)" -- is FALSE and was
// load-bearing, because it is the reason nobody re-checked these constants. Smash's INITIO
// copies INITDATA into ALL of HESYNC..DPYTAP every boot (smashtv-src/MAIN.ASM:434-446,
// :503-531), and those written values are in fact the source of MAME's smashtv screen
// parameters. The raster constants below are hardcoded and happen to be exactly right, which
// is WHY the false premise survived: HESYNC=015H -> 42 dots at 2 pixels/clock, VESYNC=3 lines,
// HEBLNK/VEBLNK/HSBLNK/VSBLNK/HTOTAL/VTOTAL -> 506x289 active 410x256, = MAME's set_raw.
// The correct statement is: the game DOES program them, this block does not read them back,
// and the two agree by construction -- so any change to these constants must be re-checked
// against MAIN.ASM, not assumed free.
//
// Two-stage read pipeline: addr -> vram_rdata (1 clk) -> pen_map6 -> pal_raddr
// -> pal_rdata (1 clk) -> RGB. de/sync are delayed to match.
//
// Geometry is parameterized (Smash T.V. = stdres). DISP_ROW0 is the first VRAM
// row displayed (the 34010 DPYSTRT; the game leaves it at reset so 0).

`default_nettype none

module yunit_video_family2
  import yunit_pkg::*;
#(
  // Timing reconciled to MAME 0.280 `smashtv` set_raw (measured via -listxml):
  //   pixclock 8 MHz, htotal 506, hbend 90, hbstart 500, vtotal 289, vbend 20,
  //   vbstart 276, width 410, height 256, refresh 54.706840 Hz, rotate 0.
  //   => active 410x256; H_TOTAL 506, V_TOTAL 289; 8e6/(506*289)=54.71 Hz. ✓
  // (Phase 6 W3: was 512/616 x 256/288 = 616x288 which gave the wrong refresh.)
  parameter int H_ACT   = 410,   // visible pixels (MAME width; VRAM is 512 cols, cols 0..409 shown)
  parameter int H_FP    = 6,     // 506 - 410 active = 96 blank
  parameter int H_SYNC  = 40,
  parameter int H_BP    = 50,
  parameter int V_ACT   = 256,   // visible lines
  parameter int V_FP    = 13,    // 289 - 256 active = 33 blank
  parameter int V_SYNC  = 8,
  parameter int V_BP    = 12,
  parameter int DISP_ROW0 = 0    // first displayed VRAM row (DPYSTRT)
)(
  input  logic        clk,
  input  logic        rst,
  input  logic        ce_pix,       // pixel-clock enable
  input  logic        bpp4,         // runtime board profile: 4bpp pen map
                                    // (family2 P1; Trog/Strike Force/Saurian)

  // RUNTIME display base. DISP_ROW0 is the reset/default value; this port
  // carries the live one so a page flip is visible to scanout. 7 of 8 Y-unit
  // titles move DPYSTRT every frame (High Impact 4,784 flips / 5,200 frames);
  // only Smash and Trog hold it static, and for them the top drives this with
  // a delta pinned at zero, so their address math is unchanged.
  input  logic [8:0]  disp_row_dyn,

  // RUNTIME visible width, in pixels, from the CRTC: (HSBLNK-HEBLNK)*pixperclock.
  // MEASURED per title -- Smash 410, High Impact 396 -- so a compile-time H_ACT
  // paints columns the game never asked for. Clamped to H_ACT by the top; the
  // reset default is H_ACT so behaviour before the CRTC is programmed is
  // unchanged.
  input  logic [11:0] visible_px,

  // DISPLAY ENABLE (DPYCTL bit 15). Gospel emits a fully BLACK line when this
  // is clear (tms34010.cpp:1178-1194: the scanline callback is skipped and the
  // visible window collapses, so every pixel takes the black pen). Strike Force
  // clears it 584 times and Saurian Front 591 in live gameplay (MAME 0.289) --
  // without this the core keeps showing stale VRAM through a blank the game
  // requested, which reads as a frozen picture on the cabinet.
  // Z-safe: an unconnected legacy-bench input means ENABLED.
  input  logic        disp_enable,

  // Frame-buffer read (registered, 1-clk latency): pixel index -> videoram word.
  output logic [FB_ADDR_W-1:0] vram_raddr,
  input  logic [15:0]          vram_rdata,
  // Palette read (registered, 1-clk latency): 12-bit pen -> xRGB1555.
  output logic [11:0]          pal_raddr,
  input  logic [15:0]          pal_rdata,

  // Video output (aligned with the 2-stage pipeline).
  output logic [7:0]  vid_r, vid_g, vid_b,
  output logic        hsync, vsync,
  output logic        hblank, vblank,
  output logic        de,
  // Stage-0 vertical blank aligned with vram_raddr.  The public vblank output
  // is delayed three pixel clocks to match RGB; scanline-buffer ownership must
  // use this raw flag or row 0 is already being read while blank still appears
  // asserted at the output pipeline.
  output logic        vblank_raw,
  output logic        vblank_irq    // 1-clk pulse at start of vertical blank
);

  localparam int H_TOTAL = H_ACT + H_FP + H_SYNC + H_BP;
  localparam int V_TOTAL = V_ACT + V_FP + V_SYNC + V_BP;

  // ---- raster counters (stage 0) ---------------------------------------
  logic [11:0] hc, vc;
  logic        s0_de, s0_hs, s0_vs, s0_hb, s0_vb;
  logic [11:0] s0_x, s0_y;

  always_ff @(posedge clk) begin
    if (rst) begin
`ifdef MUT_YVIDEO_ZERO_PHASE
      hc <= '0; vc <= '0; vblank_irq <= 1'b0;
`else
      // The 34010 counters reset at the start of sync (HCOUNT=VCOUNT=0),
      // while this raster's zero is the first active pixel.  Horizontal
      // preload is the matching sync origin.  Vertical is one line earlier:
      // the 34010 advances VCOUNT at HCOUNT wrap (90 physical pixels before
      // active x=0), while this active-origin raster advances vc at x=0.
      hc <= 12'(H_ACT + H_FP);
      vc <= 12'(V_ACT + V_FP - 1);
      vblank_irq <= 1'b0;
`endif
    end else if (ce_pix) begin
      vblank_irq <= 1'b0;
      if (hc == H_TOTAL-1) begin
        hc <= '0;
        if (vc == V_TOTAL-1) vc <= '0;
        else begin
          vc <= vc + 12'd1;
          if (vc == V_ACT-1) vblank_irq <= 1'b1;   // entering vblank
        end
      end else hc <= hc + 12'd1;
    end
  end

  // active-region flags + pixel (x,y) at stage 0
  always_comb begin
    s0_x  = hc;
    s0_y  = vc;
    s0_de = (hc < H_ACT) && (vc < V_ACT);
    s0_hb = (hc >= H_ACT);
    s0_vb = (vc >= V_ACT);
    // sync sits after the front porch
    s0_hs = (hc >= H_ACT + H_FP) && (hc < H_ACT + H_FP + H_SYNC);
    s0_vs = (vc >= V_ACT + V_FP) && (vc < V_ACT + V_FP + V_SYNC);
  end

  // frame-buffer address: (disp_row_dyn + y)*512 + (x & 0x1ff)
  // The row base is the LIVE display base, not the compile-time DISP_ROW0 --
  // see the page-flip census in yunit_top_family2. Wraps in 9 bits, matching
  // gospel's rowaddr[8:0] mask (midyunit_v.cpp:545, (rowaddr<<9)&0x3fe00).
  wire [8:0] fb_row = 9'(disp_row_dyn + 9'(s0_y));
  assign vram_raddr = FB_ADDR_W'((fb_row << FB_ROWSHIFT) + (s0_x & 12'h1ff));
  assign vblank_raw = s0_vb;

  // The color path has THREE register stages from s0: vram_rdata (external),
  // pal_rdata (external), and the vid_* output register. Delay the control
  // signals by three to keep de/sync aligned with the pixel color.
  logic s1_de,s1_hs,s1_vs,s1_hb,s1_vb;
  logic s2_de,s2_hs,s2_vs,s2_hb,s2_vb;
  always_ff @(posedge clk) begin
    if (rst) begin
      s1_de<=0;s1_hs<=0;s1_vs<=0;s1_hb<=0;s1_vb<=0;
      s2_de<=0;s2_hs<=0;s2_vs<=0;s2_hb<=0;s2_vb<=0;
    end else if (ce_pix) begin
      s1_de<=s0_de; s1_hs<=s0_hs; s1_vs<=s0_vs; s1_hb<=s0_hb; s1_vb<=s0_vb;
      s2_de<=s1_de; s2_hs<=s1_hs; s2_vs<=s1_vs; s2_hb<=s1_hb; s2_vb<=s1_vb;
    end
  end

  // Pen map per runtime profile (midyunit_v.cpp): 6bpp for Smash-class boards,
  // 4bpp for Trog/Strike Force/Saurian Front. `=== 1'b1` keeps an unconnected
  // legacy-testbench input (Z) on the established 6bpp path, same as the
  // family implementation this is ported from.
  assign pal_raddr = (bpp4 === 1'b1) ? pen_map4(vram_rdata)
                                     : pen_map6(vram_rdata);

  logic [23:0] rgb;
  assign rgb = rgb555_to_888(pal_rdata);            // stage: xRGB1555 -> 888 (comb)

  // ---- RUNTIME VISIBLE WIDTH (CRTC HEBLNK/HSBLNK) ----------------------
  // MEASURED 2026-08-16 (MAME 0.280): the visible width is PER TITLE.
  //   smashtv  HEBLNK=45 HSBLNK=250 -> 410 px
  //   hiimpact HEBLNK=45 HSBLNK=243 -> 396 px
  // H_ACT is a compile-time 410 -- Smash's number -- so on High Impact the core
  // paints 14 columns the game never intended to show. Autoerase hides them by
  // clearing all 512 VRAM columns; with autoerase OFF they hold stale data that
  // differs between the two display pages, which is the flashing vertical strip
  // on the right edge reported from the cabinet.
  //
  // Gospel draws only x in [heblnk, hsblnk) (midyunit_v.cpp:550, bounds from
  // tms34010.cpp:1143-1144). We keep the RASTER at H_ACT -- changing it would
  // change the output video mode -- and blank the pixels outside the window,
  // which is what MAME's screen shows there. Left edge needs no adjust: HEBLNK
  // is 45 on both titles, so only the right edge moves.
  wire s0_vis = (s0_x < visible_px);
  logic s1_vis, s2_vis;
  always_ff @(posedge clk) begin
    if (rst)          begin s1_vis <= 1'b1; s2_vis <= 1'b1; end
    else if (ce_pix)  begin s1_vis <= s0_vis; s2_vis <= s1_vis; end
  end
  // ENV is sampled per pixel and pipelined with the rest of the control set;
  // gospel re-reads it per scanline, and a mid-line change cannot occur because
  // the CPU writes DPYCTL from the display ISR, not mid-scan.
  wire s0_env = (disp_enable === 1'b0) ? 1'b0 : 1'b1;
  logic s1_env, s2_env;
  always_ff @(posedge clk) begin
    if (rst)         begin s1_env <= 1'b1; s2_env <= 1'b1; end
    else if (ce_pix) begin s1_env <= s0_env; s2_env <= s1_env; end
  end
  wire pix_on = s2_de && s2_vis && s2_env;

  // ---- final output register (aligned with s2_*) -----------------------
  always_ff @(posedge clk) begin
    if (rst) begin
      de<=0; hsync<=0; vsync<=0; hblank<=0; vblank<=0;
      vid_r<=0; vid_g<=0; vid_b<=0;
    end else if (ce_pix) begin
      de<=s2_de; hsync<=s2_hs; vsync<=s2_vs; hblank<=s2_hb; vblank<=s2_vb;
      vid_r <= pix_on ? rgb[23:16] : 8'h00;
      vid_g <= pix_on ? rgb[15:8]  : 8'h00;
      vid_b <= pix_on ? rgb[7:0]   : 8'h00;
    end
  end

endmodule

`default_nettype wire

