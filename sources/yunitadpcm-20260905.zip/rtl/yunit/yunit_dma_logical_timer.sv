// yunit_dma_logical_timer.sv
//
// CPU-visible Williams/Midway Y-unit DMA COMMAND timing only.
//
// MAME's midyunit DMA handler draws synchronously when COMMAND bit 15 is
// written, then schedules one replaceable callback for:
//
//     41 ns * clipped_width * clipped_height
//
// The callback clears the CPU-visible COMMAND busy bit and asserts X1.  Any
// COMMAND write clears X1.  A trigger replaces the outstanding timer; a STOP
// (resulting COMMAND bit 15 = 0) clears visible busy but does not cancel it.
//
// Unlike MAME, the FPGA renderer is not instantaneous. completion_ready is the
// physical draw/commit barrier supplied by yunit_memsys. The logical deadline
// remains the minimum duration, but X1 must never precede the framebuffer
// pixels it announces. If the renderer is late, the due callback is retained
// until every accepted descriptor has reached the coherent framebuffer
// visibility point. CPU VRAM ordering may retain a separate backing-store
// drain fence above this timer.
//
// The surrounding DMA register block must provide `clipped_pixels` for the
// register image captured by this COMMAND write.  Its legal Y-unit range is
// 0..512*512, which fits in 19 bits.
//
// 96 MHz arithmetic, without a divider:
//
//     41 ns/pixel * 96 MHz = 3.936 clocks/pixel
//                           = 3936 milli-clocks/pixel
//
// Stage 0 captures clipped_pixels on the trigger edge and immediately cancels
// the previous deadline.  Stage 1 multiplies the registered count by 3936.  At
// that stage's landing edge one 1000-milli-clock quantum has already elapsed,
// so it is consumed immediately.  The counter then subtracts 1000 per clock.
// Completion therefore lands exactly
//
//     ceil(clipped_pixels * 3936 / 1000)
//
// clocks after the COMMAND edge.  A zero-area command has a mathematical delay
// of zero; a synchronous callback cannot occur after the handler on the same
// edge, so it completes on the next clock (the minimum representable delay).
//
// Same-edge priority is deterministic:
//   * a trigger supersedes an old expiry and starts a new deadline;
//   * a STOP clears busy/X1 and defers a coincident expiry until the first clock
//     without another COMMAND write, preserving the non-cancelled callback.
//
// This module is synthesizable.  It is intentionally isolated from yunit_dma
// until its contract regression is established.

`default_nettype none

module yunit_dma_logical_timer (
  input  logic        clk,
  input  logic        rst,              // synchronous, active high

  // One pulse for any write to DMA_COMMAND. command_start is the resulting
  // stored COMMAND bit 15 after write-data/mask combination.
  input  logic        command_we,
  input  logic        command_start,
  input  logic [18:0] clipped_pixels,
  input  logic        completion_ready,

  // MAME-visible state.
  output logic        busy,
  output logic        blit_irq,

  // Verification/integration observability. completion_pulse marks the clock
  // on which the callback is delivered; blit_irq remains asserted until the
  // next COMMAND write. timer_pending includes the arithmetic stage.
  output logic        completion_pulse,
  output logic        timer_pending
);

  localparam logic [30:0] MILLI_PER_PIXEL = 31'd3936;
  localparam logic [30:0] MILLI_PER_CLOCK = 31'd1000;

  // Arithmetic stage: registered command-side pixel count -> constant
  // multiplier -> countdown load on the following clock.
  logic [18:0] pixels_q;
  logic        calc_valid;
  wire [30:0] duration_milli =
      {{12{1'b0}}, pixels_q} * MILLI_PER_PIXEL;

  logic [30:0] remaining_milli;
  logic        count_valid;
  logic        due_deferred;

  wire calc_due  = calc_valid  && (duration_milli <= MILLI_PER_CLOCK);
  wire count_due = count_valid && (remaining_milli <= MILLI_PER_CLOCK);
  wire due_raw   = due_deferred || calc_due || count_due;
  wire due_now   = completion_ready && due_raw;

  assign timer_pending = calc_valid || count_valid || due_deferred;

  always_ff @(posedge clk) begin
    if (rst) begin
      pixels_q         <= 19'd0;
      calc_valid       <= 1'b0;
      remaining_milli  <= 31'd0;
      count_valid      <= 1'b0;
      due_deferred     <= 1'b0;
      busy             <= 1'b0;
      blit_irq         <= 1'b0;
      completion_pulse <= 1'b0;
    end else begin
      completion_pulse <= 1'b0;

      // A trigger has absolute priority over the previous timer.  This is the
      // hardware equivalent of adjusting MAME's one m_dma_timer object.
      if (command_we && command_start) begin
        pixels_q        <= clipped_pixels;
        calc_valid      <= 1'b1;
        remaining_milli <= 31'd0;
        count_valid     <= 1'b0;
        due_deferred    <= 1'b0;
      end else begin
        // STOP/non-trigger COMMAND writes do not alter any pending deadline.
        // If one coincides with expiry, retain it until X1 can be delivered on
        // a clock where the COMMAND-write clear is not taking priority.
        if (due_deferred) begin
          if (!command_we && completion_ready)
            due_deferred <= 1'b0;
        end else if (calc_valid) begin
          calc_valid <= 1'b0;
          if (calc_due) begin
            if (command_we || !completion_ready)
              due_deferred <= 1'b1;
          end else begin
            // One system clock elapsed between capture and this load.
            remaining_milli <= duration_milli - MILLI_PER_CLOCK;
            count_valid     <= 1'b1;
          end
        end else if (count_valid) begin
          if (count_due) begin
            count_valid <= 1'b0;
            if (command_we || !completion_ready)
              due_deferred <= 1'b1;
          end else begin
            remaining_milli <= remaining_milli - MILLI_PER_CLOCK;
          end
        end
      end

      // CPU-visible COMMAND/X1 priority.  Every COMMAND write clears X1 and
      // directly supplies the visible busy bit.  Otherwise a due callback is
      // delivered and held as a level until the next COMMAND write.
      if (command_we) begin
        busy     <= command_start;
        blit_irq <= 1'b0;
      end else if (due_now) begin
        busy             <= 1'b0;
        blit_irq         <= 1'b1;
        completion_pulse <= 1'b1;
      end
    end
  end

endmodule

`default_nettype wire
