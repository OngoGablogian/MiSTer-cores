// yunit_vram_word_arb.sv -- two-client local-VRAM word arbiter.
//
// The normal yunit_mem backend and the TMS34010 shift-register engine share
// yunit_sdram_arb's single-beat VSD port.  Payloads are latched at grant and
// held through the physical acknowledgement, so a core reset cannot abandon a
// transaction already accepted by the persistent SDRAM subsystem.

`default_nettype none

module yunit_vram_word_arb #(
  parameter int ADDR_WIDTH = 25
) (
  input  logic                  clk,
  input  logic                  rst,             // synchronous, active high

  // Normal yunit_mem/vram_sdram_top request-held-until-ack client.
  input  logic [ADDR_WIDTH-1:0] normal_addr,
  input  logic [15:0]           normal_din,
  input  logic [1:0]            normal_be,
  input  logic                  normal_rd,
  input  logic                  normal_wr,
  output logic [15:0]           normal_dout,
  output logic                  normal_ack,

  // Shift-register ready/valid word client.  Shift traffic has priority at
  // every idle boundary so one architectural 1024-word transfer is contiguous.
  input  logic                  shift_valid,
  input  logic                  shift_write,
  input  logic [17:0]           shift_addr,
  input  logic [15:0]           shift_wdata,
  output logic [15:0]           shift_rdata,
  output logic                  shift_ready,

  // Shared local-VRAM word channel into yunit_sdram_arb.
  output logic [ADDR_WIDTH-1:0] shared_addr,
  output logic [15:0]           shared_din,
  output logic [1:0]            shared_be,
  output logic                  shared_rd,
  output logic                  shared_wr,
  input  logic [15:0]           shared_dout,
  input  logic                  shared_ack,

  output logic                  shift_owned,
  output logic                  protocol_error
);

  typedef enum logic [1:0] {
    W_IDLE,
    W_NORMAL,
    W_SHIFT
  } owner_t;

  owner_t owner;
  logic [ADDR_WIDTH-1:0] addr_q;
  logic [15:0]           din_q;
  logic [1:0]            be_q;
  logic                  write_q;

  wire normal_request = normal_rd || normal_wr;

  assign shared_addr = addr_q;
  assign shared_din  = din_q;
  assign shared_be   = be_q;
  assign shared_rd   = (owner != W_IDLE) && !write_q;
  assign shared_wr   = (owner != W_IDLE) && write_q;

  assign normal_dout = shared_dout;
  assign normal_ack  = (owner == W_NORMAL) && shared_ack;
  assign shift_rdata = shared_dout;
  assign shift_ready = (owner == W_SHIFT) && shared_ack;
  assign shift_owned = (owner == W_SHIFT);

  always_ff @(posedge clk) begin
    if (rst) begin
      owner          <= W_IDLE;
      addr_q         <= '0;
      din_q          <= 16'd0;
      be_q           <= 2'd0;
      write_q        <= 1'b0;
      protocol_error <= 1'b0;
    end else begin
      if (normal_rd && normal_wr)
        protocol_error <= 1'b1;

      unique case (owner)
        W_IDLE: begin
          if (shift_valid) begin
            addr_q  <= {{(ADDR_WIDTH-18){1'b0}}, shift_addr};
            din_q   <= shift_wdata;
            be_q    <= 2'b11;
            write_q <= shift_write;
            owner   <= W_SHIFT;
          end else if (normal_request) begin
            addr_q  <= normal_addr;
            din_q   <= normal_din;
            be_q    <= normal_be;
            write_q <= normal_wr;
            owner   <= W_NORMAL;
          end
        end

        W_NORMAL,
        W_SHIFT: begin
          if (shared_ack)
            owner <= W_IDLE;
        end

        default: owner <= W_IDLE;
      endcase
    end
  end

endmodule

`default_nettype wire
