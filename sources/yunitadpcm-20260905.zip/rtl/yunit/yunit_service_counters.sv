// yunit_service_counters.sv — F4 cabinet service instrument (DIAG_SERVICE builds only).
//
// WHY THIS EXISTS. The e519fcf FULL family core passed every offline gate and failed on the
// cabinet: Trog plays but is silent, Smash is slow + smeared + silent, Total Carnage does an
// extremely slow ROM check, runs as a slideshow, reboots on start, and is silent. The audit
// (SHIP-SPEC-yunit-2026-08-02.md) refuted most of the attractive theories and left three
// questions that only real hardware can answer:
//
//   Q1  Is the main CPU being starved of SDRAM grants by the sound client?
//       The ADPCM board round-robins the 6809 and the OKI between two far-apart addresses,
//       while the cache's two entries (current + prefetch) track ONE sequential stream. So
//       interleaved access can miss on every lookup and hold snd_rd asserted continuously,
//       above G_CGFX in the arbiter.
//   Q2  Is the SDRAM sound region actually populated and served at all?
//       Silence is universal across BOTH codecs, which points upstream of either codec.
//   Q3  Why is Smash slow + smeared when Trog, on the identical sound/arbiter path, plays?
//
// This answers all three in ONE cabinet trip. It is OBSERVATION ONLY: every input is an
// existing top-level wire, nothing here drives the datapath, and the module is compiled out
// entirely unless DIAG_SERVICE is defined.
//
// TWO RULES THIS MODULE FOLLOWS, both learned the hard way:
//
//  1. EVERY COUNTER SATURATES, never wraps. A wrapped counter read off a screen is worse than
//     no counter: 0x0002 could mean "two grants" or "65538 grants", and that difference is the
//     entire diagnosis. A pegged counter is unambiguous.
//
//  2. NO AGGREGATE WITNESSES. Counts are per-event and per-board, never merged. The CVSD 6809
//     free-runs even on ADPCM titles, so a single merged "sound alive" number would be true
//     while the board that actually matters is dead.
//
// Ratios are left for the reader rather than computed here: misses vs. that board's address
// changes IS the cache hit rate, and no division has to happen in silicon to see it.
`timescale 1ns/1ps
`default_nettype none

module yunit_service_counters (
  input  logic        clk,
  input  logic        rst,
  input  logic        frame_tick,        // 1-clk pulse at the video frame boundary

  // ---- SDRAM arbiter observation (the arb already exposes per-client acks) ----
  input  logic        cgfx_rd,           // CPU gfx/ROM request, held until ack
  input  logic        cgfx_ack,          // CPU gfx/ROM grant completed
  input  logic        snd_rd,            // sound-ROM cache request, held until ack
  input  logic        snd_ack,           // sound-ROM grant completed

  // ---- sound service observation ----
  input  logic [15:0] snd_rdata,         // word returned by the SDRAM on snd_ack

  // ---- sound board liveness: address movement = that board's CPU is executing ----
  input  logic [20:0] cvsd_addr,
  input  logic [20:0] adpcm_addr,

  // ---- main CPU ----
  input  logic        cpu_ce,
  input  logic [31:0] pc,

  // ---- video ----
  input  logic        in_active,         // raster is inside the nominal active window
  input  logic        de,                // core's data-enable for this pixel
  input  logic        pix_ce,

  // ---- latched per-frame results ----
  output logic [15:0] cnt_cgfx_grants,   // CPU SDRAM grants this frame
  output logic [15:0] cnt_snd_grants,    // sound SDRAM grants this frame
  output logic [31:0] cnt_cgfx_maxwait,  // longest clk run with cgfx_rd high and no grant
  output logic [15:0] cnt_snd_miss,      // cache misses this frame (snd_rd rising edges)
  output logic [15:0] cnt_snd_busy16,    // clks snd_rd was asserted, in units of 16
  output logic [15:0] cnt_cvsd_moves,    // CVSD ext-ROM address changes this frame
  output logic [15:0] cnt_adpcm_moves,   // ADPCM ext-ROM address changes this frame
  output logic [15:0] cnt_blank_pix,     // pixels blanked by DE inside the active window
  output logic [31:0] cnt_cpu_pc_moves,  // PC transitions this frame (retired-instr proxy)
  output logic [31:0] cnt_snd_acks,      // free-running total sound acks, saturating
  output logic [31:0] snd_first_words,   // first TWO words ever read back from the sound region
  output logic        snd_region_seen    // any non-0000/non-FFFF word ever returned
);

  // Saturating increments. One rule, applied everywhere.
  function automatic logic [15:0] inc16(input logic [15:0] v);
    inc16 = (v == 16'hFFFF) ? 16'hFFFF : (v + 16'd1);
  endfunction
  function automatic logic [31:0] inc32(input logic [31:0] v);
    inc32 = (v == 32'hFFFFFFFF) ? 32'hFFFFFFFF : (v + 32'd1);
  endfunction

  // ---- accumulators (cleared each frame) ----
  logic [15:0] a_cgfx, a_snd, a_miss, a_blank, a_cvsd, a_adpcm;
  logic [31:0] a_pcmov, a_wait, a_waitmax, a_busy;

  logic        snd_rd_q;
  logic [20:0] cvsd_q, adpcm_q;
  logic [31:0] pc_q;
  logic [1:0]  first_words_got;

  wire snd_fetch_start = snd_rd & ~snd_rd_q;   // rising edge = one cache miss launched a fetch

  always_ff @(posedge clk) begin
    if (rst) begin
      a_cgfx<=16'd0; a_snd<=16'd0; a_miss<=16'd0; a_blank<=16'd0;
      a_cvsd<=16'd0; a_adpcm<=16'd0;
      a_pcmov<=32'd0; a_wait<=32'd0; a_waitmax<=32'd0; a_busy<=32'd0;
      snd_rd_q<=1'b0; cvsd_q<=21'd0; adpcm_q<=21'd0; pc_q<=32'hFFFFFFFF;
      cnt_cgfx_grants<=16'd0; cnt_snd_grants<=16'd0; cnt_cgfx_maxwait<=32'd0;
      cnt_snd_miss<=16'd0; cnt_snd_busy16<=16'd0;
      cnt_cvsd_moves<=16'd0; cnt_adpcm_moves<=16'd0;
      cnt_blank_pix<=16'd0; cnt_cpu_pc_moves<=32'd0; cnt_snd_acks<=32'd0;
      snd_first_words<=32'd0; first_words_got<=2'd0; snd_region_seen<=1'b0;
    end else begin
      snd_rd_q <= snd_rd;

      // ---- Q1: arbitration ----
      if (cgfx_ack) a_cgfx <= inc16(a_cgfx);
      if (snd_ack)  a_snd  <= inc16(a_snd);
      if (snd_rd)   a_busy <= inc32(a_busy);

      // cgfx_rd is held until ack, so this run length IS the CPU's stall.
      // a_wait deliberately survives the frame boundary: a stall can span one.
      if (cgfx_rd && !cgfx_ack) begin
        a_wait <= inc32(a_wait);
        if (a_wait > a_waitmax) a_waitmax <= a_wait;
      end else begin
        a_wait <= 32'd0;
      end

      // ---- Q2: sound service ----
      if (snd_fetch_start) a_miss <= inc16(a_miss);
      if (snd_ack) begin
        cnt_snd_acks <= inc32(cnt_snd_acks);
        // First two words ever returned. Reading back 0000/FFFF means the region was never
        // populated -- a download/mapper failure, not a codec failure. That distinction is
        // the whole point of this counter.
        if      (first_words_got == 2'd0) begin snd_first_words[31:16] <= snd_rdata; first_words_got <= 2'd1; end
        else if (first_words_got == 2'd1) begin snd_first_words[15:0]  <= snd_rdata; first_words_got <= 2'd2; end
        if (snd_rdata != 16'h0000 && snd_rdata != 16'hFFFF) snd_region_seen <= 1'b1;
      end

      // Per-board liveness, never merged (see rule 2 in the header).
      cvsd_q  <= cvsd_addr;
      adpcm_q <= adpcm_addr;
      if (cvsd_addr  != cvsd_q)  a_cvsd  <= inc16(a_cvsd);
      if (adpcm_addr != adpcm_q) a_adpcm <= inc16(a_adpcm);

      // ---- Q3: raster. Pixels the core blanked inside the nominal active window. ----
      if (pix_ce && in_active && !de) a_blank <= inc16(a_blank);

      // ---- main CPU progress ----
      if (cpu_ce) begin
        pc_q <= pc;
        if (pc != pc_q) a_pcmov <= inc32(a_pcmov);
      end

      // ---- latch + clear at the frame boundary ----
      // These assignments come last so they win over the per-event increments above.
      if (frame_tick) begin
        cnt_cgfx_grants  <= a_cgfx;   a_cgfx  <= 16'd0;
        cnt_snd_grants   <= a_snd;    a_snd   <= 16'd0;
        cnt_snd_miss     <= a_miss;   a_miss  <= 16'd0;
        cnt_blank_pix    <= a_blank;  a_blank <= 16'd0;
        cnt_cvsd_moves   <= a_cvsd;   a_cvsd  <= 16'd0;
        cnt_adpcm_moves  <= a_adpcm;  a_adpcm <= 16'd0;
        cnt_cpu_pc_moves <= a_pcmov;  a_pcmov <= 32'd0;
        // /16 so 16 bits spans a whole ~1.59M-clk frame; saturate above 0xFFFFF clks.
        cnt_snd_busy16   <= (a_busy > 32'h000FFFFF) ? 16'hFFFF : a_busy[19:4];
        a_busy           <= 32'd0;
        cnt_cgfx_maxwait <= (a_wait > a_waitmax) ? a_wait : a_waitmax;
        a_waitmax        <= 32'd0;
      end
    end
  end

endmodule

`default_nettype wire
