// yunit_shiftreg_engine.sv -- Y-unit TMS34010 shift-register transfers.
//
// Architectural source: TMS34010 User's Guide (1988), section 6,
// page 6-21.  DPYCTL.SRT converts a pixel read into a memory-to-register
// transfer and a pixel write into a register-to-memory transfer.
//
// Y-unit behavioral specialization:
//   MAME tms34010.cpp read_pixel_shiftreg/write_pixel_shiftreg
//   MAME 34010gfx.hxx shiftreg_r/shiftreg_w
//   MAME midyunit_v.cpp to_shiftreg/from_shiftreg
//
// The integration layer submits requests to this block only for an SRT-selected
// pixel operation.  A read loads all 1024 physical 16-bit VRAM words and returns
// shift_ram[0].  A write stores the prior 1024-word buffer and has no pixel-data
// input, because FromShiftReg ignores the PIXT operand.
//
// The backend is a single-word ready/valid channel.  mem_valid and its payload
// remain stable until mem_ready.  A future SDRAM adapter may combine these
// serial transactions into bursts without changing this architectural boundary.

`default_nettype none

module yunit_shiftreg_engine (
  input  logic        clk,
  input  logic        rst,              // synchronous, active high

  // SRT command from the TMS34010 pixel path.
  input  logic        req_valid,
  output logic        req_ready,
  input  logic        req_write,        // 0: ToShiftReg, 1: FromShiftReg
  input  logic [31:0] req_bit_addr,

  // Architectural result and operation diagnostics.
  output logic [15:0] read_data,
  output logic        busy,
  output logic        done,
  output logic        error,

  // Physical Y-unit VRAM word backend (512 rows x 512 words).
  output logic        mem_valid,
  input  logic        mem_ready,
  output logic        mem_write,
  output logic [17:0] mem_addr,
  output logic [15:0] mem_wdata,
  input  logic [15:0] mem_rdata,
  input  logic        mem_error
);

  localparam logic [9:0] SHIFT_LAST = 10'd1023;

  typedef enum logic [2:0] {
    ST_CLEAR,
    ST_IDLE,
    ST_READ_WAIT,
    ST_WRITE_FETCH,
    ST_WRITE_WAIT,
    ST_DONE
  } state_e;

  state_e state;
  state_e state_next;

  // 16 Kbits: intended to infer as synchronous embedded RAM (about two M10Ks).
  logic [15:0] shift_ram [0:1023];
  logic [15:0] ram_q;
  logic [9:0]  ram_addr;
  logic [15:0] ram_wdata;
  logic        ram_we;

  // State retained across the 1024 serialized backend transactions.
  logic [17:0] base_word;
  logic [9:0]  word_index;

  wire accept_req = req_valid && req_ready;
  wire mem_accept = mem_valid && mem_ready;
  wire last_word = (word_index == SHIFT_LAST);
  // Bit address -> physical 16-bit word index, masked to the 0x40000-word
  // Y-unit framebuffer.  The 18-bit addition below provides wrap masking.
  wire [17:0] request_base_word = req_bit_addr[20:3];
  wire [17:0] indexed_word = base_word
                           + {{8{1'b0}}, word_index};

  // State register.
  always_ff @(posedge clk) begin
    if (rst)
      state <= ST_CLEAR;
    else
      state <= state_next;
  end

  // Explicit hardwired transfer controller.
  always_comb begin
    state_next = state;
    case (state)
      ST_CLEAR: begin
        if (last_word)
          state_next = ST_IDLE;
      end

      ST_IDLE: begin
        if (accept_req) begin
          if (req_write)
            state_next = ST_WRITE_FETCH;
          else
            state_next = ST_READ_WAIT;
        end
      end

      ST_READ_WAIT: begin
        if (mem_accept && (mem_error || last_word))
          state_next = ST_DONE;
      end

      ST_WRITE_FETCH: begin
        state_next = ST_WRITE_WAIT;
      end

      ST_WRITE_WAIT: begin
        if (mem_accept) begin
          if (mem_error || last_word)
            state_next = ST_DONE;
          else
            state_next = ST_WRITE_FETCH;
        end
      end

      ST_DONE: begin
        state_next = ST_IDLE;
      end

      default: begin
        state_next = ST_CLEAR;
      end
    endcase
  end

  // Command/backend outputs.  No valid signal depends on its ready input.
  always_comb begin
    req_ready = 1'b0;
    busy      = 1'b1;
    done      = 1'b0;
    mem_valid = 1'b0;
    mem_write = 1'b0;
    mem_addr  = indexed_word;
    mem_wdata = 16'd0;

    case (state)
      ST_CLEAR: begin
        // Busy remains high while architectural shift-register contents clear.
      end

      ST_IDLE: begin
        req_ready = 1'b1;
        busy      = 1'b0;
      end

      ST_READ_WAIT: begin
        mem_valid = 1'b1;
      end

      ST_WRITE_FETCH: begin
        // One cycle supplies the synchronous shift-RAM read latency.
      end

      ST_WRITE_WAIT: begin
        mem_valid = 1'b1;
        mem_write = 1'b1;
        mem_wdata = ram_q;
      end

      ST_DONE: begin
        done = 1'b1;
      end

      default: begin
        // Safe outputs while invalid state recovery returns through ST_CLEAR.
      end
    endcase
  end

  // Shift-RAM port control.  Clearing is serialized to retain RAM inference.
  always_comb begin
    ram_addr  = word_index;
    ram_wdata = 16'd0;
    ram_we    = 1'b0;

    case (state)
      ST_CLEAR: begin
        ram_we = 1'b1;
      end

      ST_READ_WAIT: begin
        if (mem_accept && !mem_error) begin
          ram_wdata = mem_rdata;
          ram_we    = 1'b1;
        end
      end

      ST_IDLE,
      ST_WRITE_FETCH,
      ST_WRITE_WAIT,
      ST_DONE: begin
        // Read-only or idle shift-RAM access.
      end

      default: begin
        // No write during invalid-state recovery.
      end
    endcase
  end

  // Canonical synchronous single-port RAM: registered read, optional write.
  always_ff @(posedge clk) begin
    if (!rst) begin
      if (ram_we)
        shift_ram[ram_addr] <= ram_wdata;
      ram_q <= shift_ram[ram_addr];
    end
  end

  // Transfer index.  It doubles as the serialized reset-clear address.
  always_ff @(posedge clk) begin
    if (rst) begin
      word_index <= 10'd0;
    end else begin
      case (state)
        ST_CLEAR: begin
          if (last_word)
            word_index <= 10'd0;
          else
            word_index <= word_index + 10'd1;
        end

        ST_IDLE: begin
          if (accept_req)
            word_index <= 10'd0;
        end

        ST_READ_WAIT,
        ST_WRITE_WAIT: begin
          if (mem_accept && !mem_error) begin
            if (last_word)
              word_index <= 10'd0;
            else
              word_index <= word_index + 10'd1;
          end
        end

        ST_WRITE_FETCH,
        ST_DONE: begin
          // Hold the current transfer index.
        end

        default: begin
          word_index <= 10'd0;
        end
      endcase
    end
  end

  // Immutable operation base captured at the command handshake.
  always_ff @(posedge clk) begin
    if (rst)
      base_word <= 18'd0;
    else if (accept_req)
      base_word <= request_base_word;
  end

  // A ToShiftReg read returns the first physical word after the full load.
  always_ff @(posedge clk) begin
    if (rst)
      read_data <= 16'd0;
    else if ((state == ST_READ_WAIT) && mem_accept && !mem_error
             && (word_index == 10'd0))
      read_data <= mem_rdata;
  end

  // Error status describes the most recently completed/active command.
  always_ff @(posedge clk) begin
    if (rst)
      error <= 1'b0;
    else if (accept_req)
      error <= 1'b0;
    else if (mem_accept && mem_error)
      error <= 1'b1;
  end

endmodule

// CPU-to-engine command boundary.
//
// The TMS34010's memory/decode outputs are stable between cpu_ce pulses, but
// the shift-register engine advances every sysclk.  Capturing the command only
// on cpu_ce creates a real multicycle endpoint for the long CPU cone, while the
// engine sees only registered valid/write/address signals.  Completion crosses
// back through a second, preserved CPU-CE boundary: the full-rate engine first
// sets ack_pending_q, a cpu_ce edge promotes that held event into core_ack_q,
// and the core consumes the acknowledgement on the following cpu_ce edge.
module yunit_shiftreg_command_bridge #(
  parameter integer AW = 32
) (
  input  logic          clk,
  input  logic          rst,
  input  logic          cpu_ce,
  input  logic          cpu_req,
  input  logic          cpu_write,
  input  logic [AW-1:0] cpu_bit_addr,

  output logic          engine_req_valid,
  input  logic          engine_req_ready,
  output logic          engine_req_write,
  output logic [AW-1:0] engine_req_bit_addr,
  input  logic          engine_done,
  input  logic          engine_error,

  output logic          core_ack,
  output logic          error_sticky
);
  // These three registers are the intentional CPU-CE capture boundary.  Keep
  // them in the synthesized netlist so retiming cannot reconstruct the raw
  // decode-to-engine path.
  (* preserve *) logic          cmd_valid_q;
  (* preserve *) logic          cmd_write_q;
  (* preserve *) logic [AW-1:0] cmd_bit_addr_q;
  // These transaction-state registers must not be physically retimed through
  // the raw CPU request/decode cone.  The stronger Quartus fence is deliberately
  // local: disabling physical synthesis for the project would hide unrelated
  // timing defects.
  (* preserve, dont_merge,
     altera_attribute = "-name ADV_NETLIST_OPT_ALLOWED NEVER_ALLOW; -name DONT_MERGE_REGISTER ON; -name PRESERVE_REGISTER ON" *)
  logic command_issued_q;
  (* preserve, dont_merge,
     altera_attribute = "-name ADV_NETLIST_OPT_ALLOWED NEVER_ALLOW; -name DONT_MERGE_REGISTER ON; -name PRESERVE_REGISTER ON" *)
  logic ack_pending_q;
  (* preserve, dont_merge,
     altera_attribute = "-name ADV_NETLIST_OPT_ALLOWED NEVER_ALLOW; -name DONT_MERGE_REGISTER ON; -name PRESERVE_REGISTER ON" *)
  logic core_ack_q;

  wire capture_command = cpu_ce && cpu_req
                       && !cmd_valid_q && !command_issued_q;
  wire engine_accept = engine_req_valid && engine_req_ready;
  // cpu_req is architecturally held until acknowledgement, but it must not be
  // part of this full-rate transaction-state D cone.  The simulation assertion
  // below checks that protocol invariant without recreating the timing path.
  wire core_consume = cpu_ce && core_ack_q;

`ifdef MUT_SHIFTREG_RAW_COMMAND
  // Discriminating mutation: restore the full decode cone directly into the
  // engine's full-rate request/state input.
  always_comb begin
    engine_req_valid    = cpu_req && !command_issued_q;
    engine_req_write    = cpu_write;
    engine_req_bit_addr = cpu_bit_addr;
  end
`else
  always_comb begin
    engine_req_valid    = cmd_valid_q;
    engine_req_write    = cmd_write_q;
    engine_req_bit_addr = cmd_bit_addr_q;
  end
`endif

`ifdef MUT_SHIFTREG_DIRECT_ACK
  // Discriminating mutation: restore the live full-rate completion bypass.
  assign core_ack = engine_done || ack_pending_q;
`else
  assign core_ack = core_ack_q;
`endif

  always_ff @(posedge clk) begin
    if (rst) begin
      cmd_valid_q      <= 1'b0;
      cmd_write_q      <= 1'b0;
      cmd_bit_addr_q   <= '0;
      command_issued_q <= 1'b0;
      ack_pending_q    <= 1'b0;
      core_ack_q       <= 1'b0;
      error_sticky     <= 1'b0;
    end else begin
      if (capture_command) begin
        cmd_valid_q    <= 1'b1;
        cmd_write_q    <= cpu_write;
        cmd_bit_addr_q <= cpu_bit_addr;
      end
      if (engine_accept) begin
        cmd_valid_q      <= 1'b0;
        command_issued_q <= 1'b1;
      end
      if (engine_done)
        ack_pending_q <= 1'b1;
      if (engine_error)
        error_sticky <= 1'b1;

      // A cpu_ce edge that first observes the held completion raises the
      // architectural acknowledgement.  The core sees the old zero on that
      // edge, then sees the held one and consumes it on the next cpu_ce.
      // Clear wins on that consume edge, producing exactly one CE interval.
      if (cpu_ce) begin
        if (core_ack_q)
          core_ack_q <= 1'b0;
        else if (ack_pending_q || engine_done)
          core_ack_q <= 1'b1;
      end
      if (core_consume) begin
        command_issued_q <= 1'b0;
        ack_pending_q    <= 1'b0;
      end
    end
  end

`ifndef SYNTHESIS
  logic [AW-1:0] stalled_addr_q;
  logic          stalled_write_q;
  logic          stalled_q;
  always_ff @(posedge clk) begin
    if (rst) begin
      stalled_q       <= 1'b0;
      stalled_addr_q  <= '0;
      stalled_write_q <= 1'b0;
    end else begin
      if (capture_command && !cpu_ce)
        $fatal(1, "yunit_shiftreg_command_bridge: command captured without cpu_ce");
      if (engine_accept && !cmd_valid_q)
        $fatal(1, "yunit_shiftreg_command_bridge: engine accepted an unregistered command");
      if (core_consume && !cpu_req)
        $fatal(1, "yunit_shiftreg_command_bridge: CPU dropped request before acknowledgement");
      if (stalled_q
          && ((!engine_req_valid)
           || (engine_req_write != stalled_write_q)
           || (engine_req_bit_addr != stalled_addr_q)))
        $fatal(1, "yunit_shiftreg_command_bridge: command changed while stalled");
      stalled_q       <= engine_req_valid && !engine_req_ready;
      stalled_write_q <= engine_req_write;
      stalled_addr_q  <= engine_req_bit_addr;
    end
  end
`endif
endmodule

`default_nettype wire
