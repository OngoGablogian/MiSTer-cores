// yunit_display_address_sequencer.sv -- live TMS34010 Y-unit display address.
//
// Behavioral sources (pinned MAME):
//   tms34010.cpp:999-1133  VCOUNT, VSBLNK load, DPYADR line update
//   tms34010.cpp:1137-1155 ORG, row, column, y-offset extraction
//   midyunit_v.cpp:543-559 physical row mask and one-behind/final autoerase
//
// A line_tick denotes the start of the current physical scanline. Registered
// output events use the pre-tick DPYADR. DPYADR then advances for the following
// scanline, matching MAME's render-before-increment callback order.
//
// Same-cycle register write vs line_tick:
//   The write commits on its own edge and the line is DEFERRED by exactly one
//   cycle. No display state advances on the collision edge; on the next edge the
//   line is processed normally against register state that already includes the
//   collided write. This is deterministic and loses neither the write nor the
//   line -- ordering is defined as "write, then line".
//   Deferral is strictly one deep. A second line_tick arriving before the
//   pending line drains cannot be represented, so that case (and only that case)
//   raises a sticky sequence error and fails closed.
//   timing_conflict_* is therefore informational: it records that a collision
//   occurred and was resolved, and does not invalidate the contract.
//
// This block supports TMS34010 master, non-interlaced timing. MAME delegates
// slave-mode VCOUNT to screen().vpos() and rejects interlaced operation; those
// modes are diagnosed and never guessed here.

`default_nettype none

module yunit_display_address_sequencer (
  input  logic        clk,
  input  logic        rst,
  input  logic        line_tick,

  input  logic        dpyctl_we,
  input  logic [15:0] dpyctl_wdata,
  input  logic        dpystart_we,
  input  logic [15:0] dpystart_wdata,
  input  logic        dpytap_we,
  input  logic [15:0] dpytap_wdata,
  input  logic        dpyadr_we,
  input  logic [15:0] dpyadr_wdata,
  input  logic        veblnk_we,
  input  logic [15:0] veblnk_wdata,
  input  logic        vsblnk_we,
  input  logic [15:0] vsblnk_wdata,
  input  logic        vtotal_we,
  input  logic [15:0] vtotal_wdata,

  // Optional legacy flip deferral.  Production ties this LOW: fb_busy is a
  // global drain level and cannot identify whether the requested display page
  // is safe.  In particular, deferring A->B and then observing the next A
  // request makes B indistinguishable from a cancelled flip.  Keep the port only
  // for the regression that reproduces that failure mode.
  input  logic        flip_hold,

  output logic [15:0] vcount_live,
  output logic [15:0] dpyadr_live,

  // Registered copy of an accepted line_tick, aligned with scanout_* and
  // prefetch_*.  Consumers must use this event rather than the raw counter
  // wrap because all descriptors become visible after that wrap edge.
  output logic        line_event,

  output logic        scanout_valid,
  output logic [15:0] scanout_vcount,
  output logic [11:0] scanout_row_raw,
  output logic [8:0]  scanout_row_phys,
  output logic [17:0] scanout_base_word,
  output logic [13:0] scanout_coladdr,
  output logic [8:0]  scanout_col_word,
  output logic [1:0]  scanout_yoffset,

  // Descriptor for the line that the scanline cache should fetch next.  During
  // active display this is the next visible line after applying the DPYADR
  // update.  During vertical blank it repeatedly describes the first visible
  // line, so a late DPYADR/DPYTAP write retargets the cache before display.
  output logic        prefetch_valid,
  output logic [15:0] prefetch_vcount,
  output logic [11:0] prefetch_row_raw,
  output logic [8:0]  prefetch_row_phys,
  output logic [17:0] prefetch_base_word,
  output logic [13:0] prefetch_coladdr,
  output logic [8:0]  prefetch_col_word,
  output logic [1:0]  prefetch_yoffset,

  // Authoritative frame boundary: the vsblnk edge at which dpyadr reloads from
  // dpystart (MAME tms34010.cpp:999-1010). The erase engine previously INFERRED
  // this from a >=256 row delta, which a 511<->255 page flip aliases exactly.
  output logic        frame_start_o,
  output logic        line_consumed_valid,
  output logic [11:0] line_consumed_row_raw,
  output logic [8:0]  line_consumed_row_phys,
  output logic [17:0] line_consumed_base_word,

  output logic        contract_valid,
  output logic        unsupported_mode,
  output logic        config_invalid,
  output logic        timing_conflict_pulse,
  output logic        timing_conflict_sticky,
  // A collided line was resolved by one-cycle deferral. Informational.
  output logic        line_deferred_pulse,
  output logic        line_deferred_sticky,
  output logic        sequence_error_pulse,
  output logic        sequence_error_sticky
);

  logic [15:0] dpyctl;
  logic [15:0] dpystart;
  logic [15:0] dpytap;
  logic [15:0] dpyadr;
  logic [15:0] veblnk;
  logic [15:0] vsblnk;
  logic [15:0] vtotal;
  logic [15:0] vcount;

  logic        final_pending;
  logic [11:0] final_pending_row_raw;

  // One-deep deferral of a line that collided with a register write.
  logic        line_pending;

  // Commit-gated page-flip state. `dpystart` is the base the CPU most recently
  // requested; `dpystart_committed` is the base actually adopted into scanout.
  // They are equal except while a flip is being deferred because the back page
  // has not yet committed to the framebuffer (flip_hold high).
  logic [15:0] dpystart_committed;
  // Consecutive-deferral watchdog. A chronically stuck flip_hold (the DDR3
  // bandwidth-wall case, DESIGN-RULES.md §6) would otherwise freeze the display; after
  // FLIP_DEFER_MAX deferrals the flip is FORCED through (a mild mid-draw is
  // accepted over a hard freeze). MAX=2 bounds the worst case to 2 held frames
  // (~35 ms): the fb-combine drains in microseconds, so a real defer is 0-1
  // frames and 2 leaves margin for a single slow-drain frame before forcing.
  localparam logic [1:0] FLIP_DEFER_MAX = 2'd2;
  logic [1:0]  flip_defer_cnt;

  wire any_reg_write = dpyctl_we || dpystart_we || dpytap_we || dpyadr_we
                     || veblnk_we || vsblnk_we || vtotal_we;
  wire mode_supported = dpyctl[13] && dpyctl[14];
  wire timing_config_valid = (vtotal != 16'd0)
                           && (veblnk < vsblnk)
                           && (vsblnk <= vtotal);
  wire visible_line = (vcount >= veblnk) && (vcount < vsblnk);
  wire display_line = visible_line && dpyctl[15];

  // A collision defers the line; the pending line drains on the next edge.
  wire line_collision = line_tick && any_reg_write;
  // A second line arriving before the pending one drains is unrepresentable.
  wire line_overrun   = line_tick && line_pending;
  // Cycles on which a line is actually processed.
  wire tick_event = line_pending || (line_tick && !any_reg_write);

  wire safe_tick = tick_event && contract_valid && !line_overrun;
  wire pending_sequence_bad = safe_tick && final_pending
                            && (vcount != vsblnk);

  // ---- commit-gated page flip -------------------------------------------
  // The vblank edge at which dpyadr reloads the display base IS the page-flip
  // point (see the dpyadr always_ff below: `if (vcount == vsblnk) dpyadr <=
  // dpystart`). MAME loads DPYADR<-DPYSTRT at VSBLNK (tms34010.cpp:999-1010).
  // Guarded by !dpyadr_we to match the reload's own precedence (an explicit
  // DPYADR write wins over the flip), so the committed base and the watchdog
  // count only on cycles the dpystart-based reload actually happens.
  wire flip_reload_edge   = tick_event && !dpyadr_we && (vcount == vsblnk);
  // A newly requested page is waiting to be shown (dpystart moved off the base
  // currently on screen). Static-page titles (Smash/Trog: DPYSTRT written once)
  // hold this at 0 after the first adoption, so the gate never engages for them.
  assign frame_start_o = flip_reload_edge;
  wire flip_change_pending = (dpystart != dpystart_committed);
  // Force adoption once the deferral watchdog saturates.
  wire flip_wdog_force    = (flip_defer_cnt >= FLIP_DEFER_MAX);
  // Adopt the new base when the back page has committed (!flip_hold), or the
  // watchdog fires, or there is nothing new to adopt. flip_hold==0 (gate tied
  // off / SDRAM path) => adopt is always 1 => bit-identical to the old flip.
  wire flip_adopt = !flip_hold || flip_wdog_force || !flip_change_pending;
  // Base actually loaded into dpyadr at the flip edge: the new page when
  // adopting, otherwise hold the committed (on-screen) page for another frame.
  wire [15:0] dpystart_eff = flip_adopt ? dpystart : dpystart_committed;

  logic [15:0] display_dpyadr;
  logic [15:0] next_visible_dpyadr;
  logic [11:0] current_row_raw;
  logic [13:0] current_coladdr;
  logic [1:0]  current_yoffset;
  logic        prefetch_candidate_valid;
  logic [15:0] prefetch_candidate_vcount;
  logic [15:0] prefetch_candidate_dpyadr;
  logic [15:0] prefetch_display_dpyadr;
  logic [11:0] prefetch_candidate_row_raw;
  logic [13:0] prefetch_candidate_coladdr;
  logic [1:0]  prefetch_candidate_yoffset;
  wire [11:0] previous_row_raw = current_row_raw - 12'd1;

  always_comb begin
    if (dpyctl[10])
      display_dpyadr = dpyadr;
    else
      display_dpyadr = dpyadr ^ 16'hfffc;

    current_row_raw = display_dpyadr[15:4];
    current_coladdr = ((display_dpyadr & 16'h007c) << 4)
                    | (dpytap & 16'h3fff);
    current_yoffset = (dpystart - dpyadr) & 16'h0003;

    if (dpyadr[1:0] == 2'b00)
      next_visible_dpyadr = ((dpyadr & 16'hfffc)
                           - (dpyctl & 16'h03fc))
                          | (dpystart & 16'h0003);
    else
      next_visible_dpyadr = (dpyadr & 16'hfffc)
                          | ((dpyadr - 16'd1) & 16'h0003);

    prefetch_candidate_valid  = 1'b0;
    prefetch_candidate_vcount = 16'd0;
    prefetch_candidate_dpyadr = dpyadr;

    // A visible line predicts its immediate successor.  Blank lines describe
    // the next frame's first visible line on every boundary; this intentionally
    // refreshes the prediction after software changes DPYADR or DPYTAP in blank.
    if (display_line && ((vcount + 16'd1) < vsblnk)) begin
      prefetch_candidate_valid  = 1'b1;
      prefetch_candidate_vcount = vcount + 16'd1;
      prefetch_candidate_dpyadr = next_visible_dpyadr;
    end else if (!visible_line && dpyctl[15]) begin
      prefetch_candidate_valid  = 1'b1;
      prefetch_candidate_vcount = veblnk;
      prefetch_candidate_dpyadr = (vcount == vsblnk) ? dpystart : dpyadr;
    end

    if (dpyctl[10])
      prefetch_display_dpyadr = prefetch_candidate_dpyadr;
    else
      prefetch_display_dpyadr = prefetch_candidate_dpyadr ^ 16'hfffc;

    prefetch_candidate_row_raw = prefetch_display_dpyadr[15:4];
    prefetch_candidate_coladdr =
        ((prefetch_display_dpyadr & 16'h007c) << 4)
      | (dpytap & 16'h3fff);
    prefetch_candidate_yoffset =
        (dpystart - prefetch_candidate_dpyadr) & 16'h0003;
  end

  assign vcount_live = vcount;
  assign dpyadr_live = dpyadr;
  assign unsupported_mode = !mode_supported;
  assign config_invalid = !timing_config_valid;
  // A resolved collision no longer invalidates the contract; only a genuinely
  // unrepresentable sequence does.
  assign contract_valid = mode_supported && timing_config_valid
                        && !sequence_error_sticky;

  always_ff @(posedge clk) begin
    if (rst) begin
      dpyctl   <= 16'd0;
      dpystart <= 16'd0;
      dpytap   <= 16'd0;
      veblnk   <= 16'd0;
      vsblnk   <= 16'd0;
      vtotal   <= 16'd0;
    end else begin
      if (dpyctl_we)
        dpyctl <= dpyctl_wdata;
      if (dpystart_we)
        dpystart <= dpystart_wdata;
      if (dpytap_we)
        dpytap <= dpytap_wdata;
      if (veblnk_we)
        veblnk <= veblnk_wdata;
      if (vsblnk_we)
        vsblnk <= vsblnk_wdata;
      if (vtotal_we)
        vtotal <= vtotal_wdata;
    end
  end

  // Explicit DPYADR writes win over an ambiguous coincident raster update.
  always_ff @(posedge clk) begin
    if (rst) begin
      dpyadr <= 16'd0;
    end else if (dpyadr_we) begin
      dpyadr <= dpyadr_wdata;
    end else if (tick_event) begin
      if (vcount == vsblnk)
        dpyadr <= dpystart_eff;   // commit-gated flip (== dpystart when adopting)
      else if (visible_line)
        dpyadr <= next_visible_dpyadr;
    end
  end

  // Commit-gated page-flip bookkeeping. dpystart_committed follows the adopted
  // base; flip_defer_cnt counts consecutive deferrals so the watchdog can bound
  // the worst case. Both update only at the flip edge (the DPYADR reload). With
  // flip_hold tied 0, flip_adopt==1 so dpystart_committed tracks dpystart every
  // flip and flip_defer_cnt stays 0 -- inert, and dpyadr <= dpystart_eff above
  // reduces to the original dpyadr <= dpystart.
  always_ff @(posedge clk) begin
    if (rst) begin
      dpystart_committed <= 16'd0;
      flip_defer_cnt     <= 2'd0;
    end else if (flip_reload_edge) begin
      dpystart_committed <= dpystart_eff;
      if (flip_change_pending && !flip_adopt)
        flip_defer_cnt <= flip_defer_cnt + 2'd1;   // deferred this flip
      else
        flip_defer_cnt <= 2'd0;                     // adopted, or nothing pending
    end
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      vcount <= 16'd0;
    end else if (tick_event) begin
      // INITIO writes HTOTAL before the vertical registers.  Its timing_start
      // is nevertheless the real entry to line zero, so advance the
      // descriptor cursor even while VTOTAL is still zero/unknown.  The TMS
      // counter remains on line zero until its first wrap; keeping the next
      // descriptor at one makes that wrap describe line one instead of
      // replaying line zero and blanking the first 410-pixel active line.
`ifdef MUT_DISPLAY_START_REPLAY_LINE0
      if (vcount >= vtotal)
`else
      if (vtotal == 16'd0)
        vcount <= 16'd1;
      else if (vcount >= vtotal)
`endif
        vcount <= 16'd0;
      else
        vcount <= vcount + 16'd1;
    end
  end

  // One-deep line deferral. The collision edge advances no display state; the
  // pending line drains on the very next edge.
  always_ff @(posedge clk) begin
    if (rst)
      line_pending <= 1'b0;
    else if (line_overrun)
      line_pending <= 1'b0;
    else if (line_collision)
      line_pending <= 1'b1;
    else
      line_pending <= 1'b0;
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      timing_conflict_pulse  <= 1'b0;
      timing_conflict_sticky <= 1'b0;
      line_deferred_pulse    <= 1'b0;
      line_deferred_sticky   <= 1'b0;
      sequence_error_pulse   <= 1'b0;
      sequence_error_sticky  <= 1'b0;
    end else begin
      timing_conflict_pulse <= line_collision;
      line_deferred_pulse   <= line_collision && !line_overrun;
      sequence_error_pulse  <= pending_sequence_bad || line_overrun;
      if (line_collision)
        timing_conflict_sticky <= 1'b1;
      if (line_collision && !line_overrun)
        line_deferred_sticky <= 1'b1;
      if (pending_sequence_bad || line_overrun)
        sequence_error_sticky <= 1'b1;
    end
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      final_pending         <= 1'b0;
      final_pending_row_raw <= 12'd0;
    end else if (tick_event) begin
      if (!safe_tick || pending_sequence_bad) begin
        final_pending <= 1'b0;
      end else begin
        if (final_pending)
          final_pending <= 1'b0;

        if (display_line && (vcount == (vsblnk - 16'd1))) begin
          final_pending         <= 1'b1;
          final_pending_row_raw <= current_row_raw;
        end
      end
    end
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      scanout_valid           <= 1'b0;
      line_event              <= 1'b0;
      scanout_vcount          <= 16'd0;
      scanout_row_raw         <= 12'd0;
      scanout_row_phys        <= 9'd0;
      scanout_base_word       <= 18'd0;
      scanout_coladdr         <= 14'd0;
      scanout_col_word        <= 9'd0;
      scanout_yoffset         <= 2'd0;
      prefetch_valid           <= 1'b0;
      prefetch_vcount          <= 16'd0;
      prefetch_row_raw         <= 12'd0;
      prefetch_row_phys        <= 9'd0;
      prefetch_base_word       <= 18'd0;
      prefetch_coladdr         <= 14'd0;
      prefetch_col_word        <= 9'd0;
      prefetch_yoffset         <= 2'd0;
      line_consumed_valid     <= 1'b0;
      line_consumed_row_raw   <= 12'd0;
      line_consumed_row_phys  <= 9'd0;
      line_consumed_base_word <= 18'd0;
    end else begin
      line_event          <= 1'b0;
      scanout_valid       <= 1'b0;
      prefetch_valid      <= 1'b0;
      line_consumed_valid <= 1'b0;

      if (safe_tick && !pending_sequence_bad) begin
        line_event <= 1'b1;
        if (display_line) begin
          scanout_valid     <= 1'b1;
          scanout_vcount    <= vcount;
          scanout_row_raw   <= current_row_raw;
`ifdef MUT_DYNAMIC_ROW_ZERO
          // Cabinet regression: collapse every title onto Smash-style row
          // zero, hiding the E00C display-origin requirement.
          scanout_row_phys  <= 9'd0;
`elsif MUT_PAGE_INVERT
          // Double-buffer page inversion: flip physical-row bit 8, which for
          // Strike Force's two pages (E00C->row 511, F00C->row 255) swaps the
          // displayed buffer (511<->255, 0..253<->256..509). A pure
          // wrong-buffer-selected mutant.
          scanout_row_phys  <= current_row_raw[8:0] ^ 9'h100;
`else
          scanout_row_phys  <= current_row_raw[8:0];
`endif
          scanout_base_word <= {current_row_raw[8:0], 9'd0};
          scanout_coladdr   <= current_coladdr;
          scanout_col_word  <= {current_coladdr[7:0], 1'b0};
          scanout_yoffset   <= current_yoffset;
        end

        if (prefetch_candidate_valid) begin
          prefetch_valid     <= 1'b1;
          prefetch_vcount    <= prefetch_candidate_vcount;
          prefetch_row_raw   <= prefetch_candidate_row_raw;
`ifdef MUT_DYNAMIC_ROW_ZERO
          prefetch_row_phys  <= 9'd0;
`elsif MUT_PAGE_INVERT
          prefetch_row_phys  <= prefetch_candidate_row_raw[8:0] ^ 9'h100;
`else
          prefetch_row_phys  <= prefetch_candidate_row_raw[8:0];
`endif
          prefetch_base_word <= {prefetch_candidate_row_raw[8:0], 9'd0};
          prefetch_coladdr   <= prefetch_candidate_coladdr;
          prefetch_col_word  <= {prefetch_candidate_coladdr[7:0], 1'b0};
          prefetch_yoffset   <= prefetch_candidate_yoffset;
        end

        if (final_pending) begin
`ifdef YUNIT_ERASE_MASKED_PAGE_GUARD
          // CAB-DIRECTED VARIANT (2026-08-27). MAME's `scanline < 510` guard
          // (midyunit_v.cpp:538) tests the RAW 12-bit rowaddr, so a page whose
          // base exceeds 510 is never autoerased. Strike Force is a true
          // back-buffer title whose pages are raw 255 and raw 511, so the raw
          // guard erases one page and never the other -- exact per-frame
          // alternation, observed on the cabinet as a strobing, dimmer
          // background layer. Guard on the MASKED physical row instead (skip
          // only the 510/511 pattern rows), matching the BRAM path's long
          // standing reasoning at yunit_mem_family2.sv:1334-1344. Default build
          // keeps the raw guard so sim/probe/erase-base keeps its expectation.
          if ((final_pending_row_raw[8:0] != 9'd510)
              && (final_pending_row_raw[8:0] != 9'd511)) begin // latched, not in the live cone
`else
          if (final_pending_row_raw < 12'd510) begin
`endif
            line_consumed_valid     <= 1'b1;
            line_consumed_row_raw   <= final_pending_row_raw;
            line_consumed_row_phys  <= final_pending_row_raw[8:0];
            line_consumed_base_word <= {final_pending_row_raw[8:0], 9'd0};
          end
`ifdef YUNIT_ERASE_MASKED_PAGE_GUARD
        // Masked-row guard: the target is previous_row_raw, so skipping masked
        // 510/511 also subsumes the old current_row_raw>0 case (row 0's
        // predecessor masks to 511) -- equivalent by construction, per the
        // BRAM path's note.
        // Guard written on current_row_raw, NOT previous_row_raw: previous is
        // current-1, so gating on it drags a 12-bit borrow chain into the
        // enable cone and cost ~0.5 ns on the core clock across seeds 7/2/3.
        // Algebraically identical because previous[8:0]==510 <=> current[8:0]==511
        // and previous[8:0]==511 <=> current[8:0]==0. previous_row_raw is still
        // the DATA written below, where it has a full cycle to settle.
        end else if (display_line
                     && (current_row_raw[8:0] != 9'd511)
                     && (current_row_raw[8:0] != 9'd0)) begin
`else
        end else if (display_line
                     && (current_row_raw > 12'd0)
                     && (current_row_raw <= 12'd510)) begin
`endif
          line_consumed_valid     <= 1'b1;
          line_consumed_row_raw   <= previous_row_raw;
          line_consumed_row_phys  <= previous_row_raw[8:0];
          line_consumed_base_word <= {previous_row_raw[8:0], 9'd0};
        end
      end
    end
  end

endmodule

`default_nettype wire
