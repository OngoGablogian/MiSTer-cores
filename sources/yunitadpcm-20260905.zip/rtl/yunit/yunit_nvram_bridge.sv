// MiSTer index-4 persistence control for the 32 KiB Y-unit CMOS image.
//
// The byte stream is the four physical 0x1000-word CMOS pages concatenated
// in page order.  A memory-side adapter maps even byte addresses to word[7:0]
// and odd byte addresses to word[15:8].

`default_nettype none
module yunit_nvram_bridge #(
  parameter integer NVRAM_BYTES = 32768
)(
  input  wire logic        clk,
  input  wire logic        rst_pon,
  input  wire logic        ioctl_download,
  input  wire logic        ioctl_upload,
  input  wire logic        ioctl_wr,
  input  wire logic [7:0]  ioctl_index,
  input  wire logic [24:0] ioctl_addr,
  input  wire logic [7:0]  ioctl_dout,
  output logic [7:0]       ioctl_din,
  output logic             ioctl_upload_req,

  input  wire logic        autosave,
  input  wire logic        manual_save,
  input  wire logic        clear_nvram,
  input  wire logic        osd_status,
  input  wire logic        cpu_write_pulse,
  input  wire logic        cmos_cpu_busy,
  output logic             cmos_quiesce,

  output logic             nvram_ext_en,
  output logic             nvram_ext_wr,
  output logic [14:0]      nvram_ext_addr,
  output logic [7:0]       nvram_ext_wdata,
  input  wire logic [7:0]  nvram_ext_rdata,
  output logic             nvram_loading,
  output logic             nvram_dirty
);
  logic clearing;
  logic [14:0] clear_addr;
  logic old_clear, old_manual, old_osd;
  logic save_pending;
  // ~350 ms at 96 MHz. Long enough that a busy HPS is never cut off mid-handshake, short
  // enough that a player never perceives it, and finite so the game cannot wedge.
  localparam int SAVE_WATCHDOG_W   = 25;
  localparam logic [SAVE_WATCHDOG_W-1:0] SAVE_WATCHDOG_MAX = '1;
  logic [SAVE_WATCHDOG_W-1:0] save_watchdog;

  wire nvram_download = ioctl_download && (ioctl_index == 8'd4);
  wire nvram_upload = ioctl_upload && (ioctl_index == 8'd4);
  wire nvram_addr_valid = ioctl_addr < NVRAM_BYTES;

  // Restore and clear modify the live image and therefore reset the game.
  // Upload is read-only.  save_pending quiesces new CPU CMOS accesses before
  // hps_io is allowed to begin the upload, producing a coherent snapshot
  // without restarting the game.
  assign nvram_loading = nvram_download || clearing;
  assign cmos_quiesce = save_pending || nvram_upload || nvram_loading;
  assign ioctl_upload_req = save_pending && !cmos_cpu_busy && !nvram_loading;

  assign nvram_ext_en = nvram_loading || nvram_upload;
  assign nvram_ext_wr = clearing ||
                        (nvram_download && ioctl_wr && nvram_addr_valid);
  assign nvram_ext_addr = clearing ? clear_addr : ioctl_addr[14:0];
  assign nvram_ext_wdata = clearing ? 8'h00 : ioctl_dout;
  assign ioctl_din = (ioctl_index == 8'd4 && nvram_addr_valid)
                   ? nvram_ext_rdata : 8'h00;

  always_ff @(posedge clk) begin
    if (rst_pon) begin
      clearing <= 1'b0;
      clear_addr <= 15'd0;
      old_clear <= 1'b0;
      old_manual <= 1'b0;
      old_osd <= 1'b0;
      save_pending <= 1'b0;
      save_watchdog <= '0;
      nvram_dirty <= 1'b0;
    end else begin
      old_clear <= clear_nvram;
      old_manual <= manual_save;
      old_osd <= osd_status;

      if (cpu_write_pulse)
        nvram_dirty <= 1'b1;

      if (clear_nvram && !old_clear && !clearing &&
          !nvram_download && !nvram_upload) begin
        clearing <= 1'b1;
        clear_addr <= 15'd0;
      end else if (clearing) begin
        if (clear_addr == NVRAM_BYTES-1) begin
          clearing <= 1'b0;
          nvram_dirty <= 1'b1;
          save_pending <= 1'b1;
          save_watchdog <= '0;   // arm the watchdog on this path too
        end else begin
          clear_addr <= clear_addr + 1'b1;
        end
      end

      if ((manual_save && !old_manual) ||
          (autosave && nvram_dirty && osd_status && !old_osd)) begin
        save_pending <= 1'b1;
        save_watchdog <= '0;
      end

      // SAVE WATCHDOG. save_pending gates cmos_quiesce, and a quiesced CMOS request is
      // STALLED, not dropped -- mem_ack simply never comes. So if hps_io never begins the
      // upload (read-only or full SD, an MRA with no <nvram index="4">, a refused upload, or
      // cmos_cpu_busy stuck so ioctl_upload_req never goes out), save_pending latches high
      // and the 34010 hangs at its next CMOS touch. That is seconds away in attract: every
      // coin, credit, service credit and audit chalk goes through the game's single CMOS
      // write path (smashtv-src/HSTD.ASM:1679 WC_BYTE).
      //
      // Losing one autosave is strictly better than hanging the game, so bound the wait.
      // nvram_dirty is deliberately KEPT set, so the data is not forgotten and the next
      // save opportunity retries it.
      //
      // Absent from the cabinet-proven yunit_mem_smash_firefix path, so Recovery's cabinet
      // pass does not cover this construct -- it is genuinely new risk in the family tree.
      if (save_pending && !nvram_upload && !nvram_loading) begin
        if (save_watchdog == SAVE_WATCHDOG_MAX) save_pending <= 1'b0;
        else                                    save_watchdog <= save_watchdog + 1'b1;
      end

      // hps_io accepted the request and began the coherent index-4 upload.
      if (nvram_upload) begin
        save_pending <= 1'b0;
        nvram_dirty <= 1'b0;
      end

      // A restored image is authoritative and starts clean.
      if (nvram_download && ioctl_wr && nvram_addr_valid) begin
        save_pending <= 1'b0;
        nvram_dirty <= 1'b0;
      end
    end
  end
endmodule
`default_nettype wire
