// yunit_memsys.sv — Y-unit memory subsystem: yunit_mem + yunit_dma glued into
// one slave on the TMS34010 core's request-valid memory interface.
//
// This is the block the CPU talks to. It routes:
//   - the DMA blitter register region (0x01A00000, mirror +0x80000) -> yunit_dma
//   - everything else                                               -> yunit_mem
// and wires the blitter back into VRAM: yunit_dma.fb_* -> yunit_mem VRAM write
// port, yunit_dma.dma_palette -> yunit_mem CPU vram_w byte-lane.
//
// The unpacked gfx-ROM read (yunit_dma.src_*) is exposed as ports — on HW it is
// backed by SDRAM; in sim by a gfx model. (CPU reads of the gfx *window*
// 0x02000000, used only by the boot checksum, are still handled by yunit_mem
// and currently return 0 — wired when the boot checksum path is exercised.)
//
// Interrupts: the POST/self-test polls DMA_COMMAND bit15, while the game's
// per-frame queue is pumped by the INT1 ISR. yunit_dma_logical_timer owns the
// MAME-visible minimum deadline, but completion is fenced behind the physical
// renderer. MAME applies the draw synchronously before arming its callback, so
// exposing X1 while queued pixels have not reached the coherent framebuffer
// visibility point is not legal. A posted DDR bridge drain may finish later;
// CPU VRAM access remains fenced until that backing commit is complete.

`default_nettype none

// Mirror yunit_mem's synthesis auto-defines so the guarded ports/wiring here match
// (macros defined in yunit_mem.sv also persist in a single compile, but be explicit).
`ifdef SYNTHESIS
  `ifndef USE_EXT_GFX
    `define USE_EXT_GFX
  `endif
  `ifndef USE_EXT_ROM
    `define USE_EXT_ROM
  `endif
  // VRAM backend: default SDRAM, but -DUSE_HW_VRAM overrides (must mirror yunit_mem.sv's
  // guard exactly so the u_mem port set matches the instantiation). USE_DDR3_VRAM does
  // NOT skip this: DDR3 is a SUB-CASE nested inside USE_SDRAM_VRAM's own scope below
  // (scan_*/ddram_* ports only exist `ifdef USE_SDRAM_VRAM -> `ifdef USE_DDR3_VRAM), so
  // -DUSE_DDR3_VRAM alone REQUIRES USE_SDRAM_VRAM to also auto-define here.
  `ifndef USE_HW_VRAM
  `ifndef USE_SDRAM_VRAM
    `define USE_SDRAM_VRAM
  `endif
  `endif
  `ifndef USE_HW_RAM
    `define USE_HW_RAM
  `endif
`endif
`ifdef USE_EXT_GFX
  `define YM_EXT_RD
`endif
`ifdef USE_EXT_ROM
  `ifndef YM_EXT_RD
    `define YM_EXT_RD
  `endif
`endif

module yunit_memsys
  import yunit_pkg::*;
#(
  parameter ROM_HEX = "smashtv_maindata.hex",
  parameter int ROM_WORDS = 32'h20000,
  parameter int ROM_WORD_OFFSET = 32'h60000,
  parameter int GFX_PIXELS = 32'h180000,
  parameter int DMA_DESC_DEPTH = 512
)(
  input  logic        clk,
  input  logic        rst,

  // CPU (TMS34010 core) request-valid memory interface.
  input  logic        mem_req,
  input  logic        mem_we,
  input  logic [31:0] mem_addr,          // bit address
  input  logic  [5:0] mem_size,          // field width 1..32
  input  logic [31:0] mem_wdata,
  output logic [31:0] mem_rdata,
  output logic        mem_ack,

  // Unpacked-gfx source (to external gfx ROM / SDRAM): 1 byte/pixel.
  output logic        src_req,
  output logic [23:0] src_addr,
  input  logic  [7:0] src_data,
  input  logic        src_ack,

  // Player inputs (Phase 4): packed {DSW, IN2, IN1, IN0}, active-low.
  input  logic [63:0] inputs,
  input  logic [3:0]  game_id,
  input  logic [23:0] game_gfx_bytes,
  input  logic [7:0]  term2_adc,
  output logic [1:0]  term2_adc_sel,

  // MAME-visible DMA callback -> TMS34010 LINT1. Every COMMAND write clears
  // it; the replaceable 41 ns/pixel deadline asserts it only after the
  // corresponding physical render has reached the coherent scanout-visible
  // acceptance point.
  output logic        int1,

  // Sound latch (Phase 5) -> williams_cvsd_board (see yunit_mem).
  output logic [7:0]  snd_select,
  output logic        snd_trig,
  output logic        snd_reset,

  // DIAG fire-chain watches (pass-through from yunit_mem; see its port decl).
  output logic [31:0] dbg_p1ctrl,
  output logic [31:0] dbg_bdir,

  // MiSTer index-4 CMOS persistence side port. The bridge lives above this
  // module so the same memory image is used by every Y-unit profile.
  input  logic        cmos_quiesce,
  input  logic        nvram_ext_en,
  input  logic        nvram_ext_wr,
  input  logic [14:0] nvram_ext_addr,
  input  logic [7:0]  nvram_ext_wdata,
  output logic [7:0]  nvram_ext_rdata,
  output logic        cmos_cpu_busy,
  output logic        cmos_cpu_write_pulse,

  // Live enabled-sense CONTROL /autoerase level for the beam-locked physical
  // row-copy scheduler in yunit_top.
  output logic        autoerase_enable,

  // Autoerase sweep (SQUAD CHARLIE): frame-paced trigger into yunit_mem's
  // erase engine (MAME midyunit_v.cpp:534-560 semantics; see yunit_mem).
  // System-level intent: pulse from yunit_video's vblank_irq with
  // erase_row0 = DISP_ROW0 and erase_lines = V_ACT; Phase-6 form re-paces
  // this per scanline off the live raster. Left unconnected in legacy TBs.
  input  logic        erase_start,
  input  logic [8:0]  erase_row0,
  input  logic [9:0]  erase_lines,
  output logic        erase_busy,
  // c723379 fork-drift fix: sequencer raw-guarded per-line erase events -> C engine.
  input  logic        erase_line_valid,
  input  logic [8:0]  erase_line_row,

  // Observability
  output logic        blit_busy,
  // Physical renderer queue diagnostics. A full FIFO applies explicit CPU bus
  // backpressure before accepting a trigger, so an acknowledged command is
  // never silently dropped. overflow is nevertheless sticky as a structural
  // guard; level exposes family-trace high-water behavior.
  output logic        dma_render_overflow,
  output logic [9:0]  dma_render_level,
  // A CPU framebuffer request is held until every earlier acknowledged DMA
  // descriptor and write-behind framebuffer transaction has committed.
  output logic        dma_vram_order_stall,
  // DDR3 write-behind combiner drain-in-progress. This is backend
  // observability/ordering state, not an architectural display page token;
  // production must not gate DPYSTRT adoption on it. 0 on non-DDR3.
  output logic        fb_busy,
  // Accepted DMA pixel stream for the video prefetch-buffer snoop.  This is
  // the logical commit point: the framebuffer backend has accepted the pixel.
  output logic        fb_snoop_we,
  output logic [FB_ADDR_W-1:0] fb_snoop_addr,
  output logic [15:0] fb_snoop_data
  // cont.24 splash-capture diag: expose the raw DMA register-write stream so the emu overlay can
  // reconstruct + latch the title-splash blit commands (LEFT/RIGHT column) on the cab.
  , output logic        dbg_dma_we
  , output logic  [3:0] dbg_dma_addr
  , output logic [15:0] dbg_dma_wdata
`ifdef YM_EXT_RD
  // CPU read-only external port (gfx/ROM in SDRAM) — exposed to the top controller.
  , output logic        cpu_gfx_rd
  , output logic [23:0] cpu_gfx_raddr
  , input  logic [15:0] cpu_gfx_rdata   // PERF: word-wide (aligned word at raddr&~1)
  , input  logic        cpu_gfx_rack
`endif
`ifdef USE_SDRAM_VRAM
  // VRAM SDRAM channel + video scanout read port — exposed to the top controller/video.
  , input  logic        scan_req
  , input  logic [17:0] scan_addr
  , output logic [15:0] scan_data
  , output logic        scan_ack
`ifdef USE_DDR3_VRAM
  , input  logic        sdram_por
  , output logic [28:0] ddram_addr
  , output logic [7:0]  ddram_burstcnt
  , output logic        ddram_rd
  , output logic        ddram_we
  , output logic [63:0] ddram_din
  , output logic [7:0]  ddram_be
  , input  logic        ddram_busy
  , input  logic [63:0] ddram_dout
  , input  logic        ddram_dout_ready
`else
  , output logic [24:0] vsd_addr
  , output logic [15:0] vsd_din
  , output logic [1:0]  vsd_be
  , output logic        vsd_rd
  , output logic        vsd_wr
  , input  logic [15:0] vsd_dout
  , input  logic        vsd_ack
`endif
`endif
`ifdef USE_HW_RAM
  // W3: palette write-tap -> video scanout mirror (yunit_palram, in yunit_top).
  , output logic        palv_we_a
  , output logic [12:0] palv_aa
  , output logic [15:0] palv_awd
  , output logic        palv_we_b
  , output logic [12:0] palv_ba
  , output logic [15:0] palv_bwd
`endif
);

  // ---- DMA-region detect (0x01A00000 and its 0x080000 mirror) -----------
  wire is_dma_now = (mem_addr[31:20] == 12'h01A);

  // ---- yunit_mem (all non-DMA regions, incl. VRAM/PAL/RAM/ROM/CMOS/CTRL) --
  logic        mem_req_m;
  logic [31:0] mem_rdata_m;
  logic        mem_ack_m;

  // ---- Logical DMA front end + physical yunit_dma renderer --------------
  //
  // CPU writes land in dma_regf immediately. COMMAND writes feed the
  // MAME-visible logical timer and atomically enqueue an immutable descriptor.
  // The existing yunit_dma is retained only as a physical pixel renderer and
  // receives descriptors later from a private replay sequencer. Its raw
  // busy/IRQ are private, but the logical callback is physically fenced: X1
  // cannot advance the assembly queue pump ahead of scanout-visible pixels.
  logic [15:0] dma_regf [DMA_NREGS];
  logic        dma_cpu_reg_we;
  logic  [3:0] dma_cpu_reg_addr;
  logic [15:0] dma_cpu_reg_wdata;
  logic [15:0] dma_cpu_reg_rdata;

  logic        phys_reg_we;
  logic  [3:0] phys_reg_addr;
  logic [15:0] phys_reg_wdata;
  logic [15:0] phys_reg_rdata;
  logic        dma_fb_we;
  logic [FB_ADDR_W-1:0] dma_fb_addr;
  logic [15:0] dma_fb_wdata;
  logic [15:0] phys_dma_palette;
  logic        phys_busy;
  logic        phys_irq;
  wire [15:0]  dma_palette_live = dma_regf[DMA_PALETTE];

  // blitter fb write completion: SDRAM path drives it from yunit_mem; BRAM path = 1-cycle.
`ifdef USE_SDRAM_VRAM
  logic mem_fb_ack;
  wire  dma_fb_ack = mem_fb_ack;
  logic mem_fb_busy;                 // DDR3 fb-combine drain-in-progress (commit-gate); 0 on SDRAM
  wire  dma_fb_busy = mem_fb_busy;
`else
  wire  dma_fb_ack = 1'b1;
  wire  dma_fb_busy = 1'b0;
`endif
  logic dma_fb_flush;                // cont.24 done-flush: blit finished -> drain the combiner now
  assign fb_snoop_we   = dma_fb_we && dma_fb_ack;
  assign fb_snoop_addr = dma_fb_addr;
  assign fb_snoop_data = dma_fb_wdata;
  assign fb_busy       = dma_fb_busy;   // expose combiner drain for observability/ordering only

  yunit_mem #(
    .ROM_HEX(ROM_HEX), .ROM_WORDS(ROM_WORDS),
    .ROM_WORD_OFFSET(ROM_WORD_OFFSET), .GFX_PIXELS(GFX_PIXELS)
  ) u_mem (
    .clk(clk), .rst(rst),
    .mem_req(mem_req_m), .mem_we(mem_we), .mem_addr(mem_addr),
    .mem_size(mem_size), .mem_wdata(mem_wdata),
    .mem_rdata(mem_rdata_m), .mem_ack(mem_ack_m),
    .fb_we(dma_fb_we), .fb_addr(dma_fb_addr), .fb_wdata(dma_fb_wdata),
    .dma_palette(dma_palette_live),
    .inputs(inputs), .game_id(game_id), .game_gfx_bytes(game_gfx_bytes),
    .term2_adc(term2_adc), .term2_adc_sel(term2_adc_sel),
    .snd_select(snd_select), .snd_trig(snd_trig), .snd_reset(snd_reset),
    .dbg_p1ctrl(dbg_p1ctrl), .dbg_bdir(dbg_bdir),
    .cmos_quiesce(cmos_quiesce),
    .nvram_ext_en(nvram_ext_en), .nvram_ext_wr(nvram_ext_wr),
    .nvram_ext_addr(nvram_ext_addr), .nvram_ext_wdata(nvram_ext_wdata),
    .nvram_ext_rdata(nvram_ext_rdata),
    .cmos_cpu_busy(cmos_cpu_busy),
    .cmos_cpu_write_pulse(cmos_cpu_write_pulse),
    .autoerase_enable(autoerase_enable),
    .erase_start(erase_start), .erase_row0(erase_row0),
    .erase_lines(erase_lines), .erase_busy(erase_busy),
    .erase_line_valid(erase_line_valid), .erase_line_row(erase_line_row)
`ifdef YM_EXT_RD
    , .gfx_rd(cpu_gfx_rd), .gfx_raddr(cpu_gfx_raddr),
      .gfx_rdata(cpu_gfx_rdata), .gfx_rack(cpu_gfx_rack)
`endif
`ifdef USE_SDRAM_VRAM
    , .fb_ack(mem_fb_ack)
    , .fb_busy(mem_fb_busy)
    , .fb_flush(dma_fb_flush)
    , .scan_req(scan_req), .scan_addr(scan_addr), .scan_data(scan_data), .scan_ack(scan_ack)
`ifdef USE_DDR3_VRAM
    , .sdram_por(sdram_por)
    , .ddram_addr(ddram_addr), .ddram_burstcnt(ddram_burstcnt), .ddram_rd(ddram_rd), .ddram_we(ddram_we)
    , .ddram_din(ddram_din), .ddram_be(ddram_be)
    , .ddram_busy(ddram_busy), .ddram_dout(ddram_dout), .ddram_dout_ready(ddram_dout_ready)
`else
    , .vsd_addr(vsd_addr), .vsd_din(vsd_din), .vsd_be(vsd_be), .vsd_rd(vsd_rd), .vsd_wr(vsd_wr)
    , .vsd_dout(vsd_dout), .vsd_ack(vsd_ack)
`endif
`endif
`ifdef USE_HW_RAM
    , .palv_we_a(palv_we_a), .palv_aa(palv_aa), .palv_awd(palv_awd)
    , .palv_we_b(palv_we_b), .palv_ba(palv_ba), .palv_bwd(palv_bwd)
`endif
  );

  // ---- CPU-visible COMMAND timer ----------------------------------------
  wire timer_command_we =
      dma_cpu_reg_we && (dma_cpu_reg_addr == DMA_COMMAND);
  wire timer_command_start = dma_cpu_reg_wdata[DMA_CMD_TRIG_BIT];

  // MAME clips before loading its single completion timer. Reproduce only the
  // clipped dimensions here; the physical renderer independently performs the
  // full offset/rowbytes/position setup from the queued raw register snapshot.
  //
  // The register image is precomputed continuously for both FLIPX polarities.
  // After any DMA register write, D_ACKR and the ack-clear cycle guarantee that
  // both pipeline stages are fresh before another request can be accepted in
  // D_IDLE. That acceptance edge selects the incoming COMMAND polarity; the
  // unchanged D_LO/D_HI COMMAND edge then performs only the 10x10 product.
  // Timer busy/X1 timing therefore stays exact while no register-to-register
  // path contains the original clip-plus-multiply cone.
  // Eighteen signed bits cover the complete operation range:
  // signed 16-bit position + unsigned 16-bit extent - 1.
  logic signed [17:0] timer_nf_x_s1;
  logic signed [17:0] timer_nf_width_s1;
  logic signed [17:0] timer_flip_x_s1;
  logic signed [17:0] timer_flip_width_s1;
  logic signed [17:0] timer_y_s1;
  logic signed [17:0] timer_height_s1;
  (* preserve *) logic signed [17:0] timer_nf_x_s1_q;
  (* preserve *) logic signed [17:0] timer_nf_width_s1_q;
  (* preserve *) logic signed [17:0] timer_flip_x_s1_q;
  (* preserve *) logic signed [17:0] timer_flip_width_s1_q;
  (* preserve *) logic signed [17:0] timer_y_s1_q;
  (* preserve *) logic signed [17:0] timer_height_s1_q;
  logic signed [17:0] timer_nf_width_s2;
  logic signed [17:0] timer_flip_width_s2;
  logic signed [17:0] timer_height_s2;
  (* preserve *) logic [9:0] timer_nf_clipped_width_q;
  (* preserve *) logic [9:0] timer_nf_clipped_height_q;
  (* preserve *) logic [9:0] timer_flip_clipped_width_q;
  (* preserve *) logic [9:0] timer_flip_clipped_height_q;
  (* preserve *) logic [9:0] timer_clipped_width_q;
  (* preserve *) logic [9:0] timer_clipped_height_q;
  logic        [18:0] timer_clipped_pixels;
  wire                 timer_prepare_flip =
      (mem_addr[7:4] == 4'hf)
        ? mem_wdata[16 + DMA_CMD_FLIPX_BIT]
        : mem_wdata[DMA_CMD_FLIPX_BIT];

  always_comb begin
    timer_nf_x_s1 =
        $signed({{2{dma_regf[DMA_XSTART][15]}}, dma_regf[DMA_XSTART]});
    timer_nf_width_s1 = $signed({2'b00, dma_regf[DMA_WIDTH]});
    timer_flip_x_s1   = timer_nf_x_s1 + timer_nf_width_s1 - 18'sd1;
    timer_flip_width_s1 = timer_nf_width_s1;
    timer_y_s1 =
        $signed({{2{dma_regf[DMA_YSTART][15]}}, dma_regf[DMA_YSTART]});
    timer_height_s1 = $signed({2'b00, dma_regf[DMA_HEIGHT]});

    // First MAME clipping boundary: top/left for normal orientation, and the
    // right edge for FLIPX. The FLIPX width expression is the exact algebraic
    // reduction W - ((X + W - 1) - 511) = 512 - X.
    if (timer_y_s1 < 0) begin
      timer_height_s1 = timer_height_s1 + timer_y_s1;
      timer_y_s1 = 0;
    end
    if (timer_flip_x_s1 >= 18'sd512) begin
      timer_flip_width_s1 = 18'sd512 - timer_nf_x_s1;
      timer_flip_x_s1 = 18'sd511;
    end
    if (timer_nf_x_s1 < 0) begin
      timer_nf_width_s1 = timer_nf_width_s1 + timer_nf_x_s1;
      timer_nf_x_s1 = 0;
    end
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      timer_nf_x_s1_q      <= 18'sd0;
      timer_nf_width_s1_q  <= 18'sd0;
      timer_flip_x_s1_q    <= 18'sd0;
      timer_flip_width_s1_q <= 18'sd0;
      timer_y_s1_q         <= 18'sd0;
      timer_height_s1_q    <= 18'sd0;
    end else begin
      timer_nf_x_s1_q      <= timer_nf_x_s1;
      timer_nf_width_s1_q  <= timer_nf_width_s1;
      timer_flip_x_s1_q    <= timer_flip_x_s1;
      timer_flip_width_s1_q <= timer_flip_width_s1;
      timer_y_s1_q         <= timer_y_s1;
      timer_height_s1_q    <= timer_height_s1;
    end
  end

  always_comb begin
    timer_nf_width_s2   = timer_nf_width_s1_q;
    timer_flip_width_s2 = timer_flip_width_s1_q;
    timer_height_s2     = timer_height_s1_q;

    // Second MAME clipping boundary: bottom/right for normal orientation and
    // the left edge for FLIPX.
    if ((timer_y_s1_q + timer_height_s1_q) > 18'sd512)
      timer_height_s2 = 18'sd512 - timer_y_s1_q;
    if ((timer_nf_x_s1_q + timer_nf_width_s1_q) > 18'sd512)
      timer_nf_width_s2 = 18'sd512 - timer_nf_x_s1_q;
    if ((timer_flip_x_s1_q - timer_flip_width_s1_q) < 0)
      timer_flip_width_s2 = timer_flip_x_s1_q;
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      timer_nf_clipped_width_q     <= 10'd0;
      timer_nf_clipped_height_q    <= 10'd0;
      timer_flip_clipped_width_q   <= 10'd0;
      timer_flip_clipped_height_q  <= 10'd0;
    end else begin
      if ((timer_nf_width_s2 <= 0) || (timer_height_s2 <= 0)) begin
        timer_nf_clipped_width_q  <= 10'd0;
        timer_nf_clipped_height_q <= 10'd0;
      end else begin
        timer_nf_clipped_width_q  <= timer_nf_width_s2[9:0];
        timer_nf_clipped_height_q <= timer_height_s2[9:0];
      end
      if ((timer_flip_width_s2 <= 0) || (timer_height_s2 <= 0)) begin
        timer_flip_clipped_width_q  <= 10'd0;
        timer_flip_clipped_height_q <= 10'd0;
      end else begin
        timer_flip_clipped_width_q  <= timer_flip_width_s2[9:0];
        timer_flip_clipped_height_q <= timer_height_s2[9:0];
      end
    end
  end

  assign timer_clipped_pixels =
      {9'd0, timer_clipped_width_q}
    * {9'd0, timer_clipped_height_q};

  logic logical_completion_pulse;
  logic logical_timer_pending;
  logic physical_completion_ready;
  yunit_dma_logical_timer u_dma_logical_timer (
    .clk(clk),
    .rst(rst),
    .command_we(timer_command_we),
    .command_start(timer_command_start),
    .clipped_pixels(timer_clipped_pixels),
    .completion_ready(physical_completion_ready),
    .busy(blit_busy),
    .blit_irq(int1),
    .completion_pulse(logical_completion_pulse),
    .timer_pending(logical_timer_pending)
  );

  assign dma_cpu_reg_rdata =
      (dma_cpu_reg_addr == DMA_COMMAND)
        ? {blit_busy, dma_regf[DMA_COMMAND][14:0]}
        : dma_regf[dma_cpu_reg_addr];

  // ---- Immutable physical descriptor FIFO -------------------------------
  localparam int DMA_DESC_REGS = 10; // COMMAND through COLOR; 10..15 unused
  localparam int DMA_DESC_W  = DMA_DESC_REGS * 16;
  localparam int DMA_DESC_AW = $clog2(DMA_DESC_DEPTH);
  logic [DMA_DESC_W-1:0] desc_push_data;
  logic [DMA_DESC_W-1:0] desc_pop_data;
  logic                  desc_push;
  logic                  desc_pop;
  logic                  desc_push_ready;
  logic                  desc_empty;
  logic                  desc_full;
  logic [DMA_DESC_AW:0]  desc_count;
  logic [DMA_DESC_AW:0]  desc_high_water;
  integer desc_i;

  always_comb begin
    for (desc_i = 0; desc_i < DMA_DESC_REGS; desc_i = desc_i + 1)
      desc_push_data[desc_i*16 +: 16] =
          (desc_i == DMA_COMMAND) ? dma_cpu_reg_wdata : dma_regf[desc_i];
  end

  assign desc_push = timer_command_we && timer_command_start;
  assign dma_render_level = desc_count;

  yunit_dma_descriptor_fifo #(
    .WIDTH(DMA_DESC_W),
    .DEPTH(DMA_DESC_DEPTH),
    .AW(DMA_DESC_AW)
  ) u_dma_desc_fifo (
    .clk(clk),
    .rst(rst),
    .push(desc_push),
    .push_data(desc_push_data),
    .push_ready(desc_push_ready),
    .pop(desc_pop),
    .pop_data(desc_pop_data),
    .empty(desc_empty),
    .full(desc_full),
    .count(desc_count),
    .high_water(desc_high_water),
    .overflow_sticky(dma_render_overflow)
  );

  // Replay one immutable descriptor into the legacy yunit_dma register port.
  // Registers 1..9 are written first and COMMAND 0 last. The physical engine's
  // own busy/IRQ/timer are private implementation details and never feed the
  // CPU-visible COMMAND read or LINT1.
  typedef enum logic [1:0] { P_IDLE, P_REGS, P_COMMAND, P_WAIT } pstate_t;
  pstate_t pstate;
  logic [3:0] phys_reg_index;
  logic [DMA_DESC_W-1:0] phys_desc;

  assign desc_pop = (pstate == P_IDLE) && !desc_empty && !phys_busy;
  assign phys_reg_we =
      (pstate == P_REGS) || (pstate == P_COMMAND);
  assign phys_reg_addr =
      (pstate == P_COMMAND) ? DMA_COMMAND[3:0] : phys_reg_index;
  assign phys_reg_wdata = phys_desc[phys_reg_addr*16 +: 16];

  always_ff @(posedge clk) begin
    if (rst) begin
      pstate         <= P_IDLE;
      phys_reg_index <= 4'd1;
      phys_desc      <= '0;
    end else begin
      unique case (pstate)
        P_IDLE: if (desc_pop) begin
          phys_desc      <= desc_pop_data;
          phys_reg_index <= 4'd1;
          pstate         <= P_REGS;
        end
        P_REGS: begin
          if (phys_reg_index == 4'd9)
            pstate <= P_COMMAND;
          else
            phys_reg_index <= phys_reg_index + 4'd1;
        end
        P_COMMAND: pstate <= P_WAIT;
        P_WAIT: if (!phys_busy) pstate <= P_IDLE;
        default: pstate <= P_IDLE;
      endcase
    end
  end

  yunit_dma #(.RENDER_ONLY(1'b1)) u_dma (
    .clk(clk), .rst(rst),
    .reg_we(phys_reg_we), .reg_addr(phys_reg_addr),
    .reg_wdata(phys_reg_wdata), .reg_rdata(phys_reg_rdata),
    .src_req(src_req), .src_addr(src_addr), .src_data(src_data), .src_ack(src_ack),
    .fb_we(dma_fb_we), .fb_addr(dma_fb_addr), .fb_wdata(dma_fb_wdata),
    .fb_ack(dma_fb_ack),
    .fb_busy(dma_fb_busy),
    .fb_flush(dma_fb_flush),
    .busy(phys_busy), .trigger_blocked(),
    .blit_irq(phys_irq), .dma_palette(phys_dma_palette)
  );

  // ---- DMA register access FSM ------------------------------------------
  // The DMA registers are 16-bit at word-aligned bit addresses (reg index =
  // addr[7:4]). The 34010 memory system splits a >16-bit field write into
  // consecutive word writes, so a 32-bit field write to reg N updates reg N
  // (low word) AND reg N+1 (high word) — MAME calls dma_w twice. The custom-
  // chip test relies on this: `MOVE A14,@1A80060h,1` (32-bit) sets WIDTH(6)
  // AND HEIGHT(7). A 16-bit-only FSM dropped HEIGHT -> blit height 0 -> no-op.
  // So: writes visit D_LO (reg idx, wdata[15:0]) then, if size>16, D_HI
  // (reg idx+1, wdata[31:16]); reads go straight to D_ACKR (combinational
  // reg_rdata). One dma_ack pulse per access, after all register writes land.
  typedef enum logic [1:0] { D_IDLE, D_LO, D_HI, D_ACKR } dstate_t;
  dstate_t dstate;
  logic [31:0] d_addr_q;
  logic        d_we_q;
  logic [31:0] d_wd_q;
  logic  [5:0] d_sz_q;
  logic        dma_ack;

  wire d_second = (dstate == D_HI);
  assign dma_cpu_reg_addr  = d_second ? (d_addr_q[7:4] + 4'd1) : d_addr_q[7:4];
  assign dma_cpu_reg_wdata = d_second ? d_wd_q[31:16]          : d_wd_q[15:0];

  // cont.24 splash-capture: forward the DMA register-write stream to the emu overlay taps.
  assign dbg_dma_we    = dma_cpu_reg_we;
  assign dbg_dma_addr  = dma_cpu_reg_addr;
  assign dbg_dma_wdata = dma_cpu_reg_wdata;
  assign dma_cpu_reg_we = (dstate == D_LO) || (dstate == D_HI); // only entered on writes

  integer dma_reg_i;
  always_ff @(posedge clk) begin
    if (rst) begin
      for (dma_reg_i = 0; dma_reg_i < DMA_NREGS; dma_reg_i = dma_reg_i + 1)
        dma_regf[dma_reg_i] <= 16'h0000;
    end else if (dma_cpu_reg_we) begin
      dma_regf[dma_cpu_reg_addr] <= dma_cpu_reg_wdata;
    end else if (logical_completion_pulse) begin
      dma_regf[DMA_COMMAND][DMA_CMD_TRIG_BIT] <= 1'b0;
    end
  end

  // A full physical FIFO is the one explicit admission boundary. Hold the
  // request before D_LO/D_HI so no logical COMMAND side effect occurs until its
  // immutable draw descriptor can be preserved. Simultaneous renderer pop
  // supplies space and keeps the baseline access latency.
  wire request_triggers_lo =
      mem_we && (mem_addr[7:4] == DMA_COMMAND) &&
      mem_wdata[DMA_CMD_TRIG_BIT];
  wire request_triggers_hi =
      mem_we && (mem_size > 6'd16) && (mem_addr[7:4] == 4'hf) &&
      mem_wdata[16 + DMA_CMD_TRIG_BIT];
  wire request_needs_descriptor = request_triggers_lo || request_triggers_hi;
  wire timer_prepare_accept =
      (dstate == D_IDLE) && mem_req && is_dma_now && !mem_ack &&
      request_needs_descriptor && desc_push_ready;

  always_ff @(posedge clk) begin
    if (rst) begin
      timer_clipped_width_q  <= 10'd0;
      timer_clipped_height_q <= 10'd0;
    end else if (timer_prepare_accept) begin
      timer_clipped_width_q  <= timer_prepare_flip
                              ? timer_flip_clipped_width_q
                              : timer_nf_clipped_width_q;
      timer_clipped_height_q <= timer_prepare_flip
                              ? timer_flip_clipped_height_q
                              : timer_nf_clipped_height_q;
    end
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      dstate  <= D_IDLE;
      dma_ack <= 1'b0;
    end else begin
      unique case (dstate)
        D_IDLE: begin
          dma_ack <= 1'b0;
          if (mem_req && is_dma_now && !mem_ack) begin
            if (request_needs_descriptor && !desc_push_ready) begin
              // Hold: the CPU request-valid protocol keeps address/data stable.
              // No COMMAND write, timer update, or descriptor acceptance has
              // happened yet, so retry is lossless.
            end else begin
              d_addr_q <= mem_addr;
              d_we_q   <= mem_we;
              d_wd_q   <= mem_wdata;
              d_sz_q   <= mem_size;
              dstate   <= mem_we ? D_LO : D_ACKR;
            end
          end
        end
        D_LO:   dstate <= (d_sz_q > 6'd16) ? D_HI : D_ACKR; // reg idx written this edge
        D_HI:   dstate <= D_ACKR;                           // reg idx+1 written this edge
        D_ACKR: begin dma_ack <= 1'b1; dstate <= D_IDLE; end
        default: dstate <= D_IDLE;
      endcase
    end
  end

  // ---- CPU/framebuffer ordering fence ----------------------------------
  //
  // MAME applies the draw synchronously inside the COMMAND write, even though
  // its busy bit/interrupt complete later on a replaceable timer. Our renderer
  // is deliberately decoupled, so a later CPU VRAM access must not overtake an
  // accepted descriptor or its write-behind commit. Other memory regions stay
  // available while rendering continues.
  wire is_vram_now = (mem_addr[31:21] == 11'd0);
  // Two distinct ordering boundaries are intentional:
  //   * X1: every descriptor's pixels have been accepted by the coherent
  //     framebuffer path. With firefix_mixboot's NO_COMMITGATE flavor, the
  //     DDR D-lane may still be draining posted writes, but BSNOOP/write-through
  //     already makes those pixels visible to scanout.
  //   * CPU VRAM: backing memory is fully committed too, because a CPU field
  //     read/modify/write cannot rely only on the scanout cache's forwarded view.
  wire dma_descriptor_active =
      !desc_empty || (pstate != P_IDLE) || phys_busy;
  wire dma_render_active = dma_descriptor_active || dma_fb_busy;
  assign physical_completion_ready = !dma_descriptor_active;
  assign dma_vram_order_stall =
      mem_req && !is_dma_now && is_vram_now && dma_render_active;

  // ---- output mux -------------------------------------------------------
  // Route the request: DMA region -> the DMA FSM (mem_req_m held low so
  // yunit_mem ignores it); everything else -> yunit_mem.
  assign mem_req_m = mem_req && !is_dma_now && !dma_vram_order_stall;
  assign mem_ack   = is_dma_now ? dma_ack : mem_ack_m;
  assign mem_rdata = is_dma_now ? {16'h0000, dma_cpu_reg_rdata} : mem_rdata_m;

endmodule

`default_nettype wire
