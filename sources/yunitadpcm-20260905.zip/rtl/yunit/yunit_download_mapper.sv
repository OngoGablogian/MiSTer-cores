// MiSTer MRA byte streams -> Y-unit SDRAM/sound download transactions.
//
// The wrapper receives one byte per hps_io write.  Graphics and SDRAM-backed
// sound are packed into 16-bit words, while the two 0x80000-byte program lanes
// are written to opposite byte enables of the same TMS34010 word.  This module
// intentionally has no game-reset input: ROM download must remain live while
// the framework holds the emulated board in reset.
`timescale 1ns/1ps
`default_nettype none

module yunit_download_mapper #(
    parameter [24:0] DL_ROMHI_BASE = 25'h080000,
    parameter [24:0] SCRATCH_WBASE = 25'h500000,
    parameter [24:0] ROMW_BASE     = 25'h400000,
    parameter [24:0] SOUNDW_BASE   = 25'h800000
) (
    input  wire        clk,
    input  wire        ioctl_download,
    input  wire        ioctl_wr,
    input  wire  [7:0] ioctl_index,
    input  wire [24:0] ioctl_addr,
    input  wire  [7:0] ioctl_dout,

    output reg   [3:0] game_id = 4'd0,
    output wire        gfx_download,
    output wire        rom_download,

    output reg         mapped_wr,
    output reg  [24:0] mapped_addr,
    output reg  [15:0] mapped_dout,
    output reg   [1:0] mapped_be,

    output reg         snd_wr,
    output reg  [17:0] snd_addr,
    output reg   [7:0] snd_data
);

    wire prog_download = ioctl_download && (ioctl_index == 8'd1);
    wire snd_download  = ioctl_download && (ioctl_index == 8'd2);

`ifdef MUT_SNDADDR_TRUNC18
    // MUTANT (gate discrimination only): unqualified tap -- the 18-bit alias
    // clobbers the ADPCM fixbank. tb_adpcm_fixbank_seam MUST die on this.
    wire adpcm_snd_tap_ok = 1'b1;
`else
    wire adpcm_snd_tap_ok = (ioctl_addr[24:18] == 7'd0);   // < 25'h40000: U3 only
`endif
    assign gfx_download = ioctl_download && (ioctl_index == 8'd0);
    assign rom_download = gfx_download || prog_download || snd_download;

    reg [7:0] pair_lo;

    always @(posedge clk) begin
        mapped_wr <= 1'b0;
        snd_wr    <= 1'b0;

        if (ioctl_download && ioctl_wr &&
            (ioctl_index == 8'd3) && (ioctl_addr == 25'd0))
            game_id <= ioctl_dout[3:0];

        if (ioctl_wr) begin
            if (gfx_download) begin
                if (!ioctl_addr[0])
                    pair_lo <= ioctl_dout;
                else begin
                    mapped_addr <= SCRATCH_WBASE + {1'b0, ioctl_addr[24:1]};
                    mapped_dout <= {ioctl_dout, pair_lo};
                    mapped_be   <= 2'b11;
                    mapped_wr   <= 1'b1;
                end
            end
            else if (prog_download && (ioctl_addr < DL_ROMHI_BASE)) begin
                // MRA index 1 first half: U105, low byte of each TMS word.
                mapped_addr <= ROMW_BASE + ioctl_addr;
                mapped_dout <= {8'h00, ioctl_dout};
                mapped_be   <= 2'b01;
                mapped_wr   <= 1'b1;
            end
            else if (prog_download) begin
                // MRA index 1 second half: U89, high byte of the same TMS word.
                mapped_addr <= ROMW_BASE + (ioctl_addr - DL_ROMHI_BASE);
                mapped_dout <= {ioctl_dout, 8'h00};
                mapped_be   <= 2'b10;
                mapped_wr   <= 1'b1;
            end
            else if (snd_download) begin
                if (!ioctl_addr[0])
                    pair_lo <= ioctl_dout;
                else begin
                    mapped_addr <= SOUNDW_BASE + {1'b0, ioctl_addr[24:1]};
                    mapped_dout <= {ioctl_dout, pair_lo};
                    mapped_be   <= 2'b11;
                    mapped_wr   <= 1'b1;
                end
            end
        end

        // Small CVSD profiles also consume every canonical sound byte directly.
        // ADPCM profiles: ONLY the U3 CPU-ROM region (< 25'h40000) rides this
        // byte tap -- its sole consumer is the board's 16 KiB fixed-bank BRAM
        // (fill decode snd_dl_addr[17:14]==4'hF, U3 tail 0x3C000-0x3FFFF).
        // snd_addr is 18 bits; letting the 1.25 MB OKI region ride the tap
        // aliases 5x onto that decode and the LAST (OKI) writer wins -- the
        // 6809 reset vector became sample bytes (cab 2026-08-19, dead board).
        // Kept in LOCKSTEP with family2_download_mapper (same qualifier, same
        // MUT_SNDADDR_TRUNC18 mutant); tb_family2_download_mapper cross-checks.
        if (snd_download && ioctl_wr) begin
            if (yunit_pkg::yunit_sound_type(game_id) == yunit_pkg::YS_ADPCM) begin
                snd_addr <= ioctl_addr[17:0];
                snd_data <= ioctl_dout;
                snd_wr   <= adpcm_snd_tap_ok;
            end else begin
                snd_addr <= {ioctl_addr[18:17], ioctl_addr[15:0]};
                snd_data <= ioctl_dout;
                snd_wr   <= 1'b1;
            end
        end
    end

endmodule

`default_nettype wire
