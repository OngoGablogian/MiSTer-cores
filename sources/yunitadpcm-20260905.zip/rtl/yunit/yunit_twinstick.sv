// Twin-stick analog -> digital: move on the LEFT stick, fire on the RIGHT
// stick, as digital direction bits OR'd into the pad's joystick vector ahead
// of the cabinet input mapper. Smash T.V. and Total Carnage consume the full
// move/fire byte.  T2 consumes only left-stick direction bits, and only while
// its mapper is in Test mode, to provide the operator's Start1-up/Start2-down
// controls; its analog gun ADC path remains completely separate and unchanged.
// Every other profile gets all-zero contributions.
//
// WHY THE REST-BIAS LATCH (do not simplify to a bare threshold): the first
// analog-fire attempt used a fixed +48 deadzone and was CAB-REFUTED -- the
// cabinet's idle right-stick Y measured +119 (family2_cabinet_inputs.sv
// "SHIPPING FIRE FIX" note), pinning fire-down permanently and reducing the
// game to "only fires downwards" (FIRE_DIRECTION, SHOTS.ASM:892). An idle
// reading that large is a resting biased device (e.g. a pedal axis riding a
// stick channel), which NO fixed deadzone can clear while staying playable.
// Remedy: latch each axis's value once, shortly after core reset releases,
// as its zero reference; threshold the DELTA at +/-64 (half deflection).
// A +119-idle axis is nulled; a centered stick keeps its full throw.
// MUT_TWINSTICK_NO_REBIAS reverts to raw thresholds and must re-create the
// pinned-fire failure in tb_yunit_twinstick.
`default_nettype none
module yunit_twinstick
  import yunit_pkg::*;
(
  input  logic        clk,
  input  logic        reset,
  input  logic [3:0]  game_id,
  input  logic [15:0] l_analog_0,  // {Y[15:8], X[7:0]} signed, +X right, +Y down
  input  logic [15:0] r_analog_0,
  input  logic [15:0] l_analog_1,
  input  logic [15:0] r_analog_1,
  output logic [7:0]  joy0_or,     // bits 0..3 = R,L,D,U move; 4..7 = fire U,D,L,R
  output logic [7:0]  joy1_or
);
  // ~44 ms at 48 MHz between reset release and the one-shot reference latch:
  // long enough for hps_io to deliver real axis values, short enough that the
  // operator is still on the "insert coin" side of boot.
  localparam int REF_DELAY = 1 << 21;

  logic [21:0] ref_cnt;
  logic        ref_latched;
  logic signed [7:0] ref_l0x, ref_l0y, ref_r0x, ref_r0y;
  logic signed [7:0] ref_l1x, ref_l1y, ref_r1x, ref_r1y;

  always_ff @(posedge clk) begin
    if (reset) begin
      ref_cnt     <= '0;
      ref_latched <= 1'b0;
    end else if (!ref_latched) begin
      ref_cnt <= ref_cnt + 22'd1;
      if (ref_cnt == REF_DELAY[21:0]) begin
        ref_l0x <= l_analog_0[7:0];  ref_l0y <= l_analog_0[15:8];
        ref_r0x <= r_analog_0[7:0];  ref_r0y <= r_analog_0[15:8];
        ref_l1x <= l_analog_1[7:0];  ref_l1y <= l_analog_1[15:8];
        ref_r1x <= r_analog_1[7:0];  ref_r1y <= r_analog_1[15:8];
        ref_latched <= 1'b1;
      end
    end
  end

  function automatic logic [3:0] dirs(input logic [15:0] axes,
                                      input logic signed [7:0] refx,
                                      input logic signed [7:0] refy);
    logic signed [8:0] dx, dy;
`ifdef MUT_TWINSTICK_NO_REBIAS
    // MUTANT (sim/run_twinstick_gate.sh kill control): raw threshold, the
    // cab-refuted behaviour -- idle +119 must pin a bit.
    dx = {axes[7],  axes[7:0]};
    dy = {axes[15], axes[15:8]};
`else
    dx = {axes[7],  axes[7:0]}  - {refx[7], refx};
    dy = {axes[15], axes[15:8]} - {refy[7], refy};
`endif
    // bit0=R, bit1=L, bit2=D, bit3=U (MiSTer digital convention).
    dirs = { (dy < -9'sd64), (dy > 9'sd64), (dx < -9'sd64), (dx > 9'sd64) };
  endfunction

  wire twinstick_title = (game_id == YG_SMASHTV) || (game_id == YG_TOTCARN);
  wire term2_title = (game_id == YG_TERM2);
  wire live = (twinstick_title || term2_title) && ref_latched && !reset;

  // Move: left stick -> direction bits 0..3.
  // Fire: right stick -> virtual buttons 4..7 = Fire Up,Down,Left,Right
  // (the SMASHTV/TOTCARN MRA action order), i.e. {R,L,D,U} of the right
  // stick land on bits {7,6,5,4}.
  logic [3:0] m0, f0, m1, f1;
  always_comb begin
    m0 = dirs(l_analog_0, ref_l0x, ref_l0y);
    f0 = dirs(r_analog_0, ref_r0x, ref_r0y);
    m1 = dirs(l_analog_1, ref_l1x, ref_l1y);
    f1 = dirs(r_analog_1, ref_r1x, ref_r1y);
    joy0_or = 8'h00;
    joy1_or = 8'h00;
    if (live) begin
      if (twinstick_title) begin
        joy0_or = {f0[0], f0[1], f0[2], f0[3], m0};
        joy1_or = {f1[0], f1[1], f1[2], f1[3], m1};
      end else begin
        // T2: directions only.  The cabinet mapper ignores these outside Test
        // mode, and bits 4..7 stay zero so no analog motion can fire a gun.
        joy0_or = {4'h0, m0};
        joy1_or = {4'h0, m1};
      end
    end
  end
endmodule
`default_nettype wire
