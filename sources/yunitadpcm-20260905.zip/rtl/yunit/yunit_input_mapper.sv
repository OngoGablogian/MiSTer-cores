// Runtime control mapper for the complete Midway/Williams Y-unit family.
// MiSTer joystick convention: R,L,D,U in bits 0..3; per-title MRA actions in
// bits 4.., followed immediately by Start and Coin.
`default_nettype none
module yunit_input_mapper
  import yunit_pkg::*;
(
  input  logic [3:0]  game_id,
  input  logic [15:0] joy0, joy1, joy2, joy3,
  input  logic [15:0] dsw_raw,
  input  logic        adpcm_irq,
  output logic [63:0] inputs
);
  logic [15:0] in0, in1, in2, dsw;
  logic test_mode;
  logic [3:0] start_bit, coin_bit;

  // Directions are written FLAT -- do NOT reintroduce a task with an `inout`
  // argument.  sv2v lowers SystemVerilog `inout` (copy-in/copy-out) to Verilog
  // `output` (copy-out only), so a shared-vector read-modify-write is correct
  // in simulation and silently wrong in the synthesized core: the second call
  // clobbers the first call's nibble.  See family2_cabinet_inputs.sv for the
  // cabinet symptoms this produced.

  always_comb begin
    in0 = 16'hffff; in1 = 16'hffff; in2 = 16'hffff;
    dsw = dsw_raw;
    test_mode = yunit_test_mode(game_id, dsw_raw);
    start_bit = yunit_start_bit(game_id);
    coin_bit  = yunit_coin_bit(game_id);

    // Common cabinet inputs.
    in1[0]=~joy0[coin_bit]; in1[1]=~joy1[coin_bit];
    // Most Y-unit diagnostic menus use Start1/Start2/Service as their BUTTONS
    // mask, so their first action is mirrored onto Start while Test is active.
    // T2 is the exception documented by its operator manual: P1 Start moves
    // up, P2 Start moves down, and either gun Trigger selects.  Mirroring T2's
    // Trigger onto Start therefore performs two operations at once.  Give a
    // one-pad operator explicit D-pad Up/Down aliases instead while preserving
    // both cabinets' native Start buttons.
    in1[2]=~(joy0[start_bit]
             | (test_mode && ((game_id == YG_TERM2)
                              ? (joy0[3] | joy1[3]) : joy0[4])));
    in1[5]=~(joy1[start_bit]
             | (test_mode && ((game_id == YG_TERM2)
                              ? (joy0[2] | joy1[2]) : joy1[4])));
    // Service Credit is a named fifth action only in Smash. Do not alias it
    // onto another title's Start or Coin position.
    if (game_id == YG_SMASHTV) in1[6]=~joy0[8];

    case (game_id)
      YG_SMASHTV, YG_TOTCARN: begin
        in0[0]=~joy0[3]; in0[1]=~joy0[2]; in0[2]=~joy0[1]; in0[3]=~joy0[0];
        in0[8]=~joy1[3]; in0[9]=~joy1[2]; in0[10]=~joy1[1]; in0[11]=~joy1[0];
        in0[4]=~joy0[4]; in0[5]=~joy0[5]; in0[6]=~joy0[6]; in0[7]=~joy0[7];
        in0[12]=~joy1[4]; in0[13]=~joy1[5]; in0[14]=~joy1[6]; in0[15]=~joy1[7];
        in1[9]=~joy2[coin_bit]; // coin 3
        // SERVICE1 / IN1[6] is wired for the whole family in the common block
        // above, on the same joy0[8] the cabinet-good Smash MRA used.
        // SHIPPING FIRE FIX, half 1 of 2 (cab-confirmed). This core has no rotary
        // encoder, so DS2:2 must read Off or the game selects rotary fire decode.
        // Half 2 is structural rather than conditional: this module has NO analog
        // port at all, so the analog right stick cannot reach the fire nibble.
        // That mattered because the cabinet's idle right-stick Y measured +119,
        // well past the +48 deadzone the old guard used, which pinned the analog
        // "fire down" bit permanently on -- FIRE_DIRECTION (SHOTS.ASM:892) then
        // scored bit5 = +2 = DOWN and nothing else, i.e. "only fires downwards".
        // The mutant restores the pre-fix rotary DIP so tb_yunit_profiles proves
        // this line is load-bearing rather than decorative.
        if (game_id == YG_SMASHTV)
`ifdef MUT_SMASHTV_ROTARY_ON
          dsw = dsw_raw;                    // MUTANT: unsupported rotary mode ON
`else
          dsw = dsw_raw | 16'h4000; // unsupported rotary mode must remain off
`endif
        if (game_id == YG_TOTCARN) in1[14] = ~adpcm_irq;
      end

      YG_TROG, YG_HIIMPACT, YG_SHIMPACT, YG_YUNITTST: begin
        in0[0]=~joy0[3]; in0[1]=~joy0[2]; in0[2]=~joy0[1]; in0[3]=~joy0[0];
        in0[8]=~joy1[3]; in0[9]=~joy1[2]; in0[10]=~joy1[1]; in0[11]=~joy1[0];
        in0[4]=~joy0[4]; in0[12]=~joy1[4];
        in1[9]=~joy2[start_bit]; in1[10]=~joy3[start_bit];
        in1[11]=~joy2[3]; in1[12]=~joy2[2]; in1[13]=~joy2[1]; in1[14]=~joy2[0];
        in1[15]=~joy2[4];
        in2[0]=~joy3[3]; in2[1]=~joy3[2]; in2[2]=~joy3[1]; in2[3]=~joy3[0];
        in2[4]=~joy3[4];
        if (game_id == YG_TROG) in2[5]=~joy2[coin_bit];
        else begin in1[7]=~joy2[coin_bit]; in2[5]=~joy3[coin_bit]; end
      end

      YG_STRKFORC, YG_SAURNFRNT: begin
        in0[0]=~joy0[3]; in0[1]=~joy0[2]; in0[2]=~joy0[1]; in0[3]=~joy0[0];
        in0[8]=~joy1[3]; in0[9]=~joy1[2]; in0[10]=~joy1[1]; in0[11]=~joy1[0];
        in0[4]=~joy0[4]; in0[5]=~joy0[5]; in0[6]=~joy0[6];
        in0[12]=~joy1[4]; in0[13]=~joy1[5]; in0[14]=~joy1[6];
        in1[7]=~joy2[coin_bit]; in1[9]=~joy3[coin_bit];
      end

      YG_MK: begin
        in0[0]=~joy0[3]; in0[1]=~joy0[2]; in0[2]=~joy0[1]; in0[3]=~joy0[0];
        in0[8]=~joy1[3]; in0[9]=~joy1[2]; in0[10]=~joy1[1]; in0[11]=~joy1[0];
        // HP, LP, Block, HK, LK, Block2 are MiSTer buttons 4..9.
        in0[4]=~joy0[4]; in0[5]=~joy0[6]; in0[6]=~joy0[7];
        in0[12]=~joy1[4]; in0[13]=~joy1[6]; in0[14]=~joy1[7];
        in1[8]=~joy2[coin_bit]; // MAME mkla4 IN1 bit 8: coin 3
        in1[9]=~joy1[5]; in1[10]=~joy1[8]; in1[11]=~joy1[9];
        in1[12]=~joy0[5]; in1[13]=~joy0[8]; in1[14]=~adpcm_irq; in1[15]=~joy0[9];
      end

      YG_TERM2: begin
        in0[4]=~joy0[4]; in0[5]=~joy0[5];
        // Pad 1 is the native second gun.  Pad 0's dedicated P2 Trigger/Bomb
        // actions provide the one-controller calibration path without stealing
        // T2's Start/Coin slots (which now follow the four real actions).
        in0[12]=~(joy1[4]|joy0[6]); in0[13]=~(joy1[5]|joy0[7]);
        in1[7]=~joy2[coin_bit]; in1[9]=~joy3[coin_bit]; in1[14]=~adpcm_irq;
      end

      default: ;
    endcase
    inputs = {dsw, in2, in1, in0};
  end
endmodule
`default_nettype wire
