// Midway/Williams Y-unit protection sequencer.
//
// This is a direct hardware form of MAME midyunit_m.cpp:cmos_enable_w.  Most
// titles shift a three-word reset sequence and clock a title-specific response
// table on bit 11's falling edge.  Strike Force instead returns a nibble-shifted
// main-RAM word when it receives 0x0500.
`default_nettype none
module yunit_protection
  import yunit_pkg::*;
(
  input  logic        clk,
  input  logic        rst,
  input  logic [3:0]  game_id,
  input  logic        wr,
  input  logic [15:0] wdata,
  input  logic [15:0] strike_word,
  output logic [15:0] result
);
  logic [15:0] seq0, seq1, seq2;
  logic [4:0] index;

  function automatic [15:0] reset_word(input logic [3:0] game, input logic [1:0] n);
    begin
      reset_word = 16'h0000;
      case (game)
        YG_TROG:     reset_word = 16'h0f00;
        YG_HIIMPACT: reset_word = 16'h0b00;
        YG_SHIMPACT,
        YG_YUNITTST:case (n) 0: reset_word=16'h0f00; 1: reset_word=16'h0e00; default: reset_word=16'h0d00; endcase
        YG_STRKFORC,
        YG_SAURNFRNT:reset_word = (n == 0) ? 16'h1234 : 16'h0000;
        YG_MK:       case (n) 0: reset_word=16'h0d00; 1: reset_word=16'h0c00; default: reset_word=16'h0900; endcase
        YG_TERM2,
        YG_TOTCARN:  reset_word = 16'h0f00;
        default:     reset_word = 16'h0000;
      endcase
    end
  endfunction

  function automatic [15:0] data_word(input logic [3:0] game, input logic [4:0] n);
    begin
      data_word = 16'h0000;
      case (game)
        YG_TROG: case (n)
          0:data_word=16'h3000; 1:data_word=16'h1000; 2:data_word=16'h2000;
          3:data_word=16'h0000; 4:data_word=16'h2000; 5:data_word=16'h3000;
          6:data_word=16'h3000; 7:data_word=16'h1000; 8:data_word=16'h0000;
          9:data_word=16'h0000; 10:data_word=16'h2000; 11:data_word=16'h3000;
          12:data_word=16'h1000; 13:data_word=16'h1000; default:data_word=16'h2000;
        endcase
        YG_HIIMPACT: case (n)
          0:data_word=16'h2000; 1:data_word=16'h4000; 2:data_word=16'h4000;
          3:data_word=16'h0000; 4:data_word=16'h6000; 5:data_word=16'h6000;
          6:data_word=16'h2000; 7:data_word=16'h4000; 8:data_word=16'h2000;
          9:data_word=16'h4000; 10:data_word=16'h2000; 11:data_word=16'h0000;
          12:data_word=16'h4000; 13:data_word=16'h6000; default:data_word=16'h2000;
        endcase
        YG_SHIMPACT,
        YG_YUNITTST: case (n)
          0:data_word=16'h0000; 1:data_word=16'h4000; 2:data_word=16'h2000;
          3:data_word=16'h5000; 4:data_word=16'h2000; 5:data_word=16'h1000;
          6:data_word=16'h4000; 7:data_word=16'h6000; 8:data_word=16'h3000;
          9:data_word=16'h0000; 10:data_word=16'h2000; 11:data_word=16'h5000;
          12:data_word=16'h5000; 13:data_word=16'h5000; default:data_word=16'h2000;
        endcase
        YG_MK: case (n)
          0:data_word=16'h4600; 1:data_word=16'hf600; 2:data_word=16'ha600;
          3:data_word=16'h0600; 4:data_word=16'h2600; 5:data_word=16'h9600;
          6:data_word=16'hc600; 7:data_word=16'he600; 8:data_word=16'h8600;
          9:data_word=16'h7600; 10:data_word=16'h8600; 11:data_word=16'h8600;
          12:data_word=16'h9600; 13:data_word=16'hd600; 14:data_word=16'h6600;
          15:data_word=16'hb600; 16:data_word=16'hd600; 17:data_word=16'he600;
          18:data_word=16'hf600; 19:data_word=16'h7600; 20:data_word=16'hb600;
          21:data_word=16'ha600; default:data_word=16'h3600;
        endcase
        YG_TERM2: case (n)
          0:data_word=16'h4000; 1:data_word=16'hf000; default:data_word=16'ha000;
        endcase
        YG_TOTCARN: case (n)
          0:data_word=16'h4a00; 1:data_word=16'h6a00; 2:data_word=16'hda00;
          3:data_word=16'h6a00; 4:data_word=16'h9a00; 5:data_word=16'h4a00;
          6:data_word=16'h2a00; 7:data_word=16'h9a00; 8:data_word=16'h1a00;
          9:data_word=16'h8a00; default:data_word=16'haa00;
        endcase
        default: data_word = 16'h0000;
      endcase
    end
  endfunction

  wire [15:0] masked = wdata & 16'h0f00;
  wire reset_match = (seq1 == reset_word(game_id, 0)) &&
                     (seq2 == reset_word(game_id, 1)) &&
                     (masked == reset_word(game_id, 2));
  wire clock_edge = seq2[11] && !masked[11];

  always_ff @(posedge clk) begin
    if (rst) begin
      seq0 <= 16'h0000; seq1 <= 16'h0000; seq2 <= 16'h0000;
      index <= 5'd0; result <= 16'h0000;
    end else if (wr && yunit_has_protection(game_id)) begin
      seq0 <= seq1; seq1 <= seq2; seq2 <= masked;
      if (game_id == YG_STRKFORC || game_id == YG_SAURNFRNT) begin
        if (masked == 16'h0500) result <= strike_word << 4;
      end else begin
        if (reset_match) index <= 5'd0;
        if (clock_edge) begin
          result <= data_word(game_id, reset_match ? 5'd0 : index);
          index <= (reset_match ? 5'd0 : index) + 5'd1;
        end
      end
    end
  end
endmodule
`default_nettype wire
