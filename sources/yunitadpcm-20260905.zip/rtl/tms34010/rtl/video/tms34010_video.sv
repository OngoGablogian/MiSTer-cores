// -----------------------------------------------------------------------------
// tms34010_video.sv
//
// Video timing generator for the TMS34010 (1988 User's Guide §"Video Timing",
// the HESYNC/HEBLNK/HSBLNK/HTOTAL and V* registers). Free-running horizontal
// and vertical counters, advanced at the DOT rate by the `ce` enable, produce
// HSYNC/VSYNC and the blanking signal, plus a display-interrupt strobe.
//
//   HCOUNT increments once per `ce` (dot-clock enable) tick; when HCOUNT ==
//   HTOTAL it wraps to 0 and the horizontal sync interval restarts. On each
//   HCOUNT wrap, VCOUNT increments; when VCOUNT == VTOTAL it wraps to 0 (a new
//   frame). Because `ce` is the pixel-clock enable, HCOUNT runs at the pixel
//   clock and VCOUNT at the line rate. A fixed DPYINT value matches once per
//   frame; software may rewrite DPYINT after a match to schedule another event
//   in the same frame (Smash T.V. alternates scanlines 154 and 282).
//
//   HSYNC is asserted while HCOUNT <= HESYNC (the sync interval that begins at
//   the HTOTAL wrap). HESYNC is a duration-minus-one endpoint. HBLANK is
//   asserted while HCOUNT < HEBLNK (the leading
//   blank, including the sync interval) or HCOUNT >= HSBLNK (the trailing
//   blank); the visible region is HEBLNK..HSBLNK. The vertical signals are the
//   analogous compares on VCOUNT. BLANK is asserted when either axis is
//   blanking. Per User Guide section 9.7, DPYINT_PULSE occurs at the beginning
//   of horizontal blanking at the end of the selected DPYINT line.
//
// Scope (Task 0097 — standalone; P00xx — dot-clock `ce` gating): a clean,
// synthesizable timing block. The spec resets HCOUNT on the VCLK FALLING edge;
// this synchronous design uses the rising edge throughout (assumption A0003
// reset/clock style) and advances on the `ce` enable instead of a raw VCLK.
//
// Spec source:
//   third_party/TMS34010_Info/docs/ti-official/1988_TI_TMS34010_Users_Guide.pdf
//   §"Video Timing"; HESYNC page 5-?, HEBLNK page 5-?.
// -----------------------------------------------------------------------------

`default_nettype none
module tms34010_video
  import tms34010_pkg::*;
(
  input  wire logic        clk,        // core clock (clk_sys). Counters advance on `ce`, NOT every clk.
  input  wire logic        rst,
  // Rephase when a previously-disabled timing generator is activated by the
  // first zero->nonzero HTOTAL write. Unconnected legacy users default low.
  input  wire logic        timing_start,
  // Pixel-clock ENABLE. Real HW clocks these counters at VCLK;
  // here `clk` is the fast core clock and `ce` is a 1-clk-wide enable at the dot
  // rate (Arcade-SmashTV.sv: 96 MHz / 12 = 8 MHz = midwunit PIXEL_CLOCK). Gating
  // every counter on `ce` makes HCOUNT tick per DOT, VCOUNT per LINE, and
  // DPYINT_PULSE once for each programmed-line match -- matching the TMS34010
  // CRTC that MAME models. Without it (the fork-inherited bug) DPYINT fired at the
  // core clock = ~12x too fast, derailing NBA/UMK3 init before the RAM
  // interrupt-dispatch table is built. An UNCONNECTED `ce` (legacy unit TBs that
  // do not drive it) defaults HIGH = full-rate = the original behavior, so those
  // TBs are unaffected; the `=== 1'b0` guard collapses to plain equality in
  // synthesis (the real path always drives ce 0/1). Same pattern as `lint1_in`.
  input  wire logic        ce,

  // Horizontal timing registers.
  input  wire logic [15:0] hesync,     // end of horizontal sync
  input  wire logic [15:0] heblnk,     // end of horizontal blank (display starts)
  input  wire logic [15:0] hsblnk,     // start of horizontal blank
  input  wire logic [15:0] htotal,     // total - 1 line length (HCOUNT wrap)
  // Vertical timing registers.
  input  wire logic [15:0] vesync,     // end of vertical sync
  input  wire logic [15:0] veblnk,     // end of vertical blank
  input  wire logic [15:0] vsblnk,     // start of vertical blank
  input  wire logic [15:0] vtotal,     // total - frame length (VCOUNT wrap)
  // Display-interrupt scan line.
  input  wire logic [15:0] dpyint,

  output logic [15:0] hcount,
  output logic [15:0] vcount,
  output logic        hsync,      // 1 = within the horizontal sync interval
  output logic        vsync,      // 1 = within the vertical sync interval
  output logic        hblank,     // 1 = horizontal blanking
  output logic        vblank,     // 1 = vertical blanking
  output logic        blank,      // 1 = blanked (either axis)
  output logic        dpyint_pulse,// one-clock strobe at HSBLNK on the DPYINT line
  // One-clock pulse on the edge that wraps HCOUNT and enters the next line.
  // timing_start is a separate bootstrap event because it enters line zero
  // without an HCOUNT wrap.
  output logic        line_wrap_o
);

  logic hwrap;
  assign hwrap = (hcount == htotal);

  // Dot-clock enable. Unconnected `ce` (legacy TBs) -> HIGH (full rate); a driven
  // `ce` passes straight through. Synthesis sees `== 1'b0` (z/x cannot exist).
  logic ce_eff;
  assign ce_eff = (ce === 1'b0) ? 1'b0 : 1'b1;
  logic timing_start_eff;
  assign timing_start_eff = (timing_start === 1'b1);
  assign line_wrap_o = !rst && !timing_start_eff && (htotal != 16'd0)
                    && ce_eff && hwrap;

  always_ff @(posedge clk) begin
    if (rst || timing_start_eff) begin
      hcount <= 16'd0;
      vcount <= 16'd0;
    end else if (ce_eff) begin
      if (hwrap) begin
        hcount <= 16'd0;
        if (vcount == vtotal) begin
          vcount <= 16'd0;
        end else begin
          vcount <= vcount + 16'd1;
        end
      end else begin
        hcount <= hcount + 16'd1;
      end
    end
  end

  // Sync endpoints are inclusive. TI's 1988 TMS34010 User's Guide, figures
  // 9-2 and 9-5, defines HESYNC and VESYNC as pulse duration minus one.
  // Smash T.V. therefore gets (0x15+1)*2 = 44 physical HS pixels and
  // (3+1) = four VS lines. Keep the old exclusive interpretation armed as a
  // release mutation because it silently shortens both native pulses.
`ifdef MUT_TMS_SYNC_EXCLUSIVE
  assign hsync  = (hcount < hesync);
  assign vsync  = (vcount < vesync);
`else
  assign hsync  = (hcount <= hesync);
  assign vsync  = (vcount <= vesync);
`endif
  assign hblank = (hcount < heblnk) || (hcount >= hsblnk);
  assign vblank = (vcount < veblnk) || (vcount >= vsblnk);
  assign blank  = hblank || vblank;

  // Display interrupt: User Guide section 9.7 places it at the beginning of
  // horizontal blanking at the END of the selected line.  Consumers sample
  // this combinational pulse on the same edge that advances the counters, so
  // assert while the NEXT count will arrive at HSBLNK.  Comparing the current
  // count to HSBLNK would instead be sampled on the 250->251 edge -- one TMS
  // count (two physical pixels) late.  HSBLNK=0 arrives on the HTOTAL wrap.
  logic dpyint_arrival;
  logic [15:0] dpyint_arrival_vcount;
  assign dpyint_arrival = (hsblnk == 16'd0) ? hwrap
                                             : (hcount == (hsblnk - 16'd1));
  // If trailing blank begins at HCOUNT=0, that arrival is also a line wrap;
  // compare DPYINT against the VCOUNT that will exist after this same edge.
  assign dpyint_arrival_vcount = ((hsblnk == 16'd0) && hwrap)
                               ? ((vcount == vtotal) ? 16'd0 : vcount + 16'd1)
                               : vcount;
`ifdef MUT_DPYINT_LATE
  assign dpyint_pulse = ce_eff && (hcount == hsblnk) && (vcount == dpyint);
`else
  assign dpyint_pulse = ce_eff && dpyint_arrival &&
                        (dpyint_arrival_vcount == dpyint);
`endif

endmodule : tms34010_video

`default_nettype wire
