// TMS34010 instruction-retirement cadence scheduler.
//
// The RTL core is a multi-state microengine; one ce_cpu pulse is not one
// architectural TMS34010 cycle.  This module keeps those concepts separate:
// micro_tick is the fastest implementation step, while instr_cycles is the
// MAME/TI architectural budget for the instruction that just retired.
//
// Phase units use 384 per architectural cycle.  At a 96 MHz system clock the
// Y-unit 40/48/50 MHz master-clock classes advance 20/24/25 phase units per
// sysclk, exactly representing 5.0/6.0/6.25 MHz.  Fractional overshoot smaller
// than one architectural cycle is carried into the next instruction so a long
// stream is exact on average rather than rounded instruction-by-instruction.
//
// Timing architecture: yunit_cpu_cadence guarantees at least two idle sysclk
// edges between micro_tick pulses.  permit_q is computed one edge ahead from
// elapsed time two edges ahead, then combined with the now-registered
// micro_tick.  The high-fanout ce_cpu cone is consequently only two flop
// outputs and an AND gate.  Retirement/decode/budget signals update target
// state, but deliberately never feed permit_q combinationally.
//
// Source cross-check: MAME tms34010.h execute_clocks_to_cycles (master / 8)
// and 34010ops.hxx COUNT_CYCLES.  Dynamic budgets are supplied by the core at
// retirement; this scheduler deliberately does not decode opcodes.
`default_nettype none

module tms34010_cycle_scheduler (
  input  wire logic        clk,
  input  wire logic        rst,
  input  wire logic        micro_tick,
  input  wire logic [5:0]  arch_step,
  input  wire logic        instr_start,
  input  wire logic        instr_retire,
  input  wire logic [15:0] instr_cycles,
  output logic        ce_cpu,
  output logic        cadence_stall,
  output logic        cadence_overrun
);
  localparam logic [9:0]  PHASE_PER_CYCLE  = 10'd384;
  // 2^26 = 174762*384 + 256.  These constants preserve the legacy
  // elapsed_phase[25:0] modulo wrap exactly in split whole/fraction form.
  localparam logic [17:0] PHASE_MOD_CYCLES = 18'd174762;
  localparam logic [9:0]  PHASE_MOD_FRAC   = 10'd256;

  logic        active;
  logic        waiting;
  // Do not allow synthesis/retiming to collapse this state boundary back into
  // the high-fanout CPU-enable cone.
  (* preserve *) logic permit_q;
  logic [17:0] elapsed_cycles;
  logic [8:0]  elapsed_fraction;
  logic [15:0] target_cycles;
  logic [15:0] budget_cycles;
  // Retirement data crosses a true CPU-CE-to-CPU-CE boundary here.  The
  // toggle/budget bank captures only on instr_retire (which implies ce_cpu);
  // target_cycles then captures these registered values on the following
  // sysclk.  This prevents the instruction-decode cone from terminating at
  // the full-rate scheduler target register.
  (* preserve *) logic        retire_toggle_q;
  (* preserve *) logic [15:0] retire_cycles_q;
  logic                       retire_seen_q;
  logic                       retire_pending;

  logic [9:0]  fraction_sum_one;
  logic [9:0]  fraction_sum_two;
  logic [8:0]  fraction_after_one;
  logic [17:0] cycles_after_one;
  logic [17:0] cycles_after_two;
  logic [17:0] target_cycles_ext;
  logic [15:0] target_cycles_effective;
  logic        permit_next;

  always_comb begin
    budget_cycles = (instr_cycles == 16'd0) ? 16'd1 : instr_cycles;
    retire_pending = retire_toggle_q ^ retire_seen_q;
    target_cycles_effective = retire_pending ? retire_cycles_q
                                              : target_cycles;
    target_cycles_ext = {2'b00, target_cycles_effective};

    // Split phase into whole architectural cycles plus a 0..383 residue.
    // Two real Y-unit steps are at most 50, so each lookahead has at most one
    // carry.  The wider expressions also remain well-defined for any 6-bit
    // arch_step used by a focused test.
    fraction_sum_one = {1'b0, elapsed_fraction}
                     + {4'b0000, arch_step};
    cycles_after_one = elapsed_cycles;
    if ((elapsed_cycles == PHASE_MOD_CYCLES)
        && (fraction_sum_one >= PHASE_MOD_FRAC)) begin
      cycles_after_one = 18'd0;
      fraction_after_one = 9'(fraction_sum_one - PHASE_MOD_FRAC);
    end else if (fraction_sum_one >= PHASE_PER_CYCLE) begin
      cycles_after_one = elapsed_cycles + 18'd1;
      fraction_after_one = 9'(fraction_sum_one - PHASE_PER_CYCLE);
    end else begin
      fraction_after_one = fraction_sum_one[8:0];
    end

    // Two steps are at most 126 phase units for the full 6-bit input (50 for
    // real profiles), so the direct lookahead can cross at most one whole-cycle
    // or modulo boundary.  This keeps the permit_q input cone to one short
    // phase add plus the whole-cycle compare.
    fraction_sum_two = {1'b0, elapsed_fraction}
                     + {3'b000, arch_step, 1'b0};
    cycles_after_two = elapsed_cycles;
    if ((elapsed_cycles == PHASE_MOD_CYCLES)
        && (fraction_sum_two >= PHASE_MOD_FRAC)) begin
      cycles_after_two = 18'd0;
    end else if (fraction_sum_two >= PHASE_PER_CYCLE) begin
      cycles_after_two = elapsed_cycles + 18'd1;
    end

    cadence_stall = waiting && (cycles_after_one < target_cycles_ext);
    permit_next = !waiting || (cycles_after_two >= target_cycles_ext);
    ce_cpu = micro_tick && permit_q;
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      active           <= 1'b0;
      waiting          <= 1'b0;
      permit_q         <= 1'b1;
      elapsed_cycles   <= 18'd0;
      elapsed_fraction <= 9'd0;
      target_cycles    <= 16'd1;
      retire_toggle_q  <= 1'b0;
      retire_cycles_q  <= 16'd1;
      retire_seen_q    <= 1'b0;
      cadence_overrun  <= 1'b0;
    end else begin
      // Predict permission for the next edge.  instr_start/instr_retire and
      // instr_cycles are intentionally absent from this cone.  If either
      // handshake changes waiting/target on this edge, the cadence contract
      // provides two non-micro-tick edges in which permit_q is refreshed.
      permit_q <= permit_next;

      if (active || waiting) begin
        elapsed_cycles   <= cycles_after_one;
        elapsed_fraction <= fraction_after_one;
      end

      // Capture the decode-derived budget only at the CPU retirement edge.
      // target_cycles consumes that registered bank one full sysclk later.
      if (instr_retire) begin
        active           <= 1'b0;
        waiting          <= 1'b1;
        retire_toggle_q  <= ~retire_toggle_q;
        retire_cycles_q  <= budget_cycles;
      end
      if (retire_pending) begin
        target_cycles <= retire_cycles_q;
        retire_seen_q <= retire_toggle_q;
      end

      // instr_start can only occur on an allowed ce_cpu edge.  Preserve small
      // phase quantisation residue, but never "catch up" by a whole late CPU
      // cycle after a real implementation/memory overrun.
      if (instr_start) begin
        active  <= 1'b1;
        waiting <= 1'b0;
        if (waiting && (cycles_after_one >= target_cycles_ext)) begin
          if (cycles_after_one > target_cycles_ext) begin
            elapsed_cycles   <= 18'd0;
            elapsed_fraction <= 9'd0;
            cadence_overrun <= 1'b1;
          end else begin
            elapsed_cycles   <= 18'd0;
            elapsed_fraction <= fraction_after_one;
          end
        end else begin
          elapsed_cycles   <= 18'd0;
          elapsed_fraction <= 9'd0;
        end
      end
    end
  end

`ifndef SYNTHESIS
`ifndef TMS34010_SCHED_DISABLE_PROTOCOL_ASSERTS
  logic       protocol_seen_tick;
  logic [1:0] protocol_idle_edges;
  logic [5:0] protocol_arch_step;

  always_ff @(posedge clk) begin
    if (rst) begin
      protocol_seen_tick  <= 1'b0;
      protocol_idle_edges <= 2'd0;
      protocol_arch_step  <= arch_step;
    end else begin
      if (arch_step != protocol_arch_step)
        $fatal(1, "tms34010_cycle_scheduler: arch_step changed outside reset");
      if ((elapsed_cycles > PHASE_MOD_CYCLES)
          || ((elapsed_cycles == PHASE_MOD_CYCLES)
              && ({1'b0, elapsed_fraction} >= PHASE_MOD_FRAC)))
        $fatal(1, "tms34010_cycle_scheduler: invalid split phase state");
      if (instr_start && instr_retire)
        $fatal(1, "tms34010_cycle_scheduler: simultaneous start and retire");
      if ((instr_start || instr_retire) && !ce_cpu)
        $fatal(1, "tms34010_cycle_scheduler: handshake without ce_cpu");
      if (instr_start && active)
        $fatal(1, "tms34010_cycle_scheduler: start while instruction active");
      if (instr_retire && !active)
        $fatal(1, "tms34010_cycle_scheduler: retire while no instruction active");
      if (retire_pending && micro_tick)
        $fatal(1, "tms34010_cycle_scheduler: next micro_tick arrived before retirement capture settled");

      if (micro_tick) begin
        if (protocol_seen_tick && (protocol_idle_edges < 2))
          $fatal(1, "tms34010_cycle_scheduler: micro_tick spacing below three clocks");
        // This is the central retime proof obligation: on every legal capture
        // edge, registered lookahead permission equals the raw current-time
        // scheduler decision.
        if (permit_q !== !cadence_stall)
          $fatal(1, "tms34010_cycle_scheduler: permit lookahead mismatch");
        protocol_seen_tick  <= 1'b1;
        protocol_idle_edges <= 2'd0;
      end else if (protocol_idle_edges != 2'd3) begin
        protocol_idle_edges <= protocol_idle_edges + 2'd1;
      end
    end
  end
`endif
`endif
endmodule

`default_nettype wire
