// yunit_src_cache.sv — cont.24: blitter SOURCE-READ streaming cache (DDR3 config only).
//
// ROOT CAUSE (title-splash "sprites missing / flashing in and out", adversarially verified
// 2026-07-12): every readmode blit pixel cost one full single-word SDRAM round trip at the
// LOWEST arbiter priority (below the CPU's cgfx stream), discarding the unwanted byte —
// ~8-14+ clk/px vs the authored 41 ns/px (4 clk @96 MHz) that the game's done-IRQ-serialized
// DMA queue drain is written against (NDSP1.ASM DMAINT :84-101; MAME midyunit_v.cpp:523).
// The drain falls behind, the game's DMAQ overflows, and NDSP1.ASM:646-648 silently CANS
// the tail objects (OBJLST = the level overlay sprites, queued AFTER the backgrounds) — a
// different subset every frame = "sprites flashing in and out of existence".
//
// FIX (the UMK3 wolf_gfx_ddr_top remedy, SDRAM-flavored): a 16-word streaming ring filled by
// 8-word PAGE-MODE bursts on sdram_stock's brd_* port (P2b, ~1 clk/word after one ACTIVATE;
// FREE in the DDR3 config — the SDRAM scanout that owned it is compiled out). o_ptr ascends
// +1 byte/px within a blit row (yunit_dma.sv, flipx included — only the DEST descends), so
// hits stream at ~3 clk/px and the engine becomes PACE-limited (the MAME-faithful 41 ns/px
// floor), not fetch-limited. Row jumps / new objects MISS and re-target the stream.
//
// DMA-side contract unchanged (src_req held until src_ack; 1-cycle registered ack).
// RESET = CORE reset (the consumer's domain). Safe against the POR-domain controller because
// the brd burst FSM is edge-latched and SELF-COMPLETING (sdram_stock.sv STATE_BR_*: a dropped
// brd_req cannot wedge it), and a post-reset COOLDOWN outlasts any stale burst still draining
// (never sequence on / mistake a busy you do not own — the gate-the-FSM lesson).
`timescale 1ns/1ps
`default_nettype none
module yunit_src_cache #(
  parameter [23:0] GFXW_BASE = 24'h000000    // gfx WORD base in SDRAM (matches yunit_sdram_arb)
)(
  input  wire         clk,
  input  wire         rst,
  // DMA side (identical contract to yunit_dma's src port)
  input  wire         src_req,    // level, held until src_ack
  input  wire  [23:0] src_addr,   // BYTE address into unpacked gfx
  output logic  [7:0] src_data,
  output logic        src_ack,    // 1-cycle strobe
  // sdram_stock page-mode burst-read port (P2b)
  output logic        brd_req,    // edge-latched by the controller; held until brd_done
  output logic [24:0] brd_addr,   // controller BYTE address (word-aligned)
  output logic  [9:0] brd_len,    // words (col-boundary clamped: P2a col = addr[9:1])
  input  wire  [15:0] brd_dout,
  input  wire         brd_dvalid, // 1-cycle strobe per streamed word (in order)
  input  wire         brd_done    // 1-cycle burst-complete strobe
);
  localparam int   DEPTH = 16;    // ring words (32 source bytes ahead)
  localparam [9:0] FILL  = 10'd8; // sub-burst words (page-mode: ~1 clk/word after ACTIVATE)

  logic [15:0] ring [0:DEPTH-1];
  logic [22:0] rw0;               // gfx word address held at ring[head]
  logic [4:0]  cnt;               // valid words 0..16 (from rw0, ascending)
  logic [3:0]  head;              // ring slot of rw0
  logic [3:0]  st_idx;            // store slot for the streaming fill (head+cnt at issue;
                                  //  invariant under serve-pops: pops move head and cnt inversely)
  logic        retarget;          // a MISS re-aimed the stream mid-burst: drop its remaining words
  logic [5:0]  cool;              // post-reset quarantine (outlasts a stale burst drain)

  typedef enum logic [1:0] { F_IDLE, F_RUN, F_GAP } fill_t;
  fill_t fst;

  // ---- request decode (o_ptr ascends: q_off is 0 or 1 mid-stream; anything else = row jump)
  wire [22:0] q_word = src_addr[23:1];
  wire [22:0] q_off  = q_word - rw0;
  wire        in_win = (q_off < {18'd0, cnt});
  wire        serve  = src_req && !src_ack && in_win;
  wire        miss   = src_req && !src_ack && !in_win;
  // FLUSH = the re-aim EDGE only (a genuine stream jump: the request misses AND rw0 is not
  // yet pointed at it). After the flush lands, `miss` stays TRUE while the demand fill is
  // owed (in_win only turns on when the word stores) -- gating stores/cnt on the miss LEVEL
  // would drop every demand-fill word and refetch forever. Gate on the flush EDGE instead.
  wire        flush  = miss && (q_word != rw0);
  wire [3:0]  q_off4 = q_off[3:0];
  // a streamed word lands only while its burst is still on-target (flush same-cycle: drop too)
  wire        st     = brd_dvalid && (fst == F_RUN) && !retarget && !flush;
  // next fill target + P2a col-boundary clamp (col = word[8:0]; a burst must not wrap the row)
  wire [22:0] f_word   = rw0 + {18'd0, cnt};
  wire [9:0]  col_left = 10'd512 - {1'b0, f_word[8:0]};
  wire [9:0]  f_len    = (col_left < FILL) ? col_left : FILL;

  always_ff @(posedge clk) begin
    if (rst) begin
      cnt <= 5'd0;  head <= 4'd0;  rw0 <= 23'd0;  st_idx <= 4'd0;
      fst <= F_IDLE;  retarget <= 1'b0;
      brd_req <= 1'b0;  brd_addr <= 25'd0;  brd_len <= 10'd1;
      src_ack <= 1'b0;  src_data <= 8'h00;
      cool <= 6'd40;
    end else begin
      src_ack <= 1'b0;
      if (cool != 6'd0) cool <= cool - 6'd1;

      // ---- serve: registered 1-cycle ack (the DMA's S_FETCH/S_WRITE pipeline = ~3 clk/px)
      if (serve) begin
        src_data <= src_addr[0] ? ring[head + q_off4][15:8] : ring[head + q_off4][7:0];
        src_ack  <= 1'b1;
      end

      // ---- ring bookkeeping: written ONCE each (flush overrides; pops + stores compose)
      //   pop  = serve consumed past the head (q_off words are dead; the served word stays)
      //   st   = one streamed word landed
      rw0  <= flush ? q_word : (serve ? (rw0 + q_off)          : rw0);
      cnt  <= flush ? 5'd0   : (cnt - (serve ? {1'b0, q_off4} : 5'd0) + (st ? 5'd1 : 5'd0));
      head <= flush ? 4'd0   : (head + (serve ? q_off4 : 4'd0));
      if (st) begin
        ring[st_idx] <= brd_dout;
        st_idx       <= st_idx + 4'd1;
      end
      if (flush) st_idx <= 4'd0;             // st suppressed hereafter (retarget) -> safe

      // ---- fill FSM: one page-mode sub-burst at a time; F_GAP gives the controller its edge
      case (fst)
        F_IDLE: begin
          // Issue when free space >= FILL (cnt <= DEPTH-FILL = 8). Guard ONLY the flush
          // (re-aim) cycle: rw0 updates this edge, so f_word would target the STALE stream.
          // A plain !miss guard would DEADLOCK the demand path (miss holds until the fill
          // lands).
          if (cool == 6'd0 && (cnt <= 5'd8) && !flush) begin
            st_idx   <= head + cnt[3:0];     // store slot (invariant under pops)
            brd_addr <= {1'b0, (GFXW_BASE[22:0] + f_word), 1'b0};  // word -> controller byte addr
            brd_len  <= f_len;
            brd_req  <= 1'b1;
            fst      <= F_RUN;
          end
        end
        F_RUN: begin
          if (flush) retarget <= 1'b1;       // stream re-aimed: drop the rest of this burst
          if (brd_done) begin
            brd_req  <= 1'b0;
            retarget <= 1'b0;
            fst      <= F_GAP;
          end
        end
        F_GAP: fst <= F_IDLE;                // >=1 low cycle -> clean rising edge next burst
        default: fst <= F_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
