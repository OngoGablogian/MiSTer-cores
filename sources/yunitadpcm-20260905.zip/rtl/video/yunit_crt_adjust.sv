// Y-unit core-side glue for rmonic79/MiSTer-CRT-Adjust.
//
// The Y-unit family shares one native raster: 506 x 289 total at an 8 MHz
// pixel rate from the 96 MHz system clock (54.70684 Hz).  Keep that raster and
// its sync cadence native; this stage only changes how long buffered pixels are
// held and where the native-width sync pulses appear.
//
// The active window has a very asymmetric porch (HBEND=90, HBSTART=500), so
// HPOS_SYNCSHIFT is intentional.  Exact raster simulation constrains the
// coherent control range to -4..+44 and H-size to 0..-4.  A -5 shrink at +44
// reaches active data before the fixed-width HSync has ended.
`timescale 1ns/1ps
`default_nettype none

module yunit_crt_adjust (
    input  wire       clk,
    input  wire       ce_pix,

    // Raw MiSTer status fields.  The wrapper applies them only at safe raster
    // boundaries, so a menu update cannot split a source pixel or sync pulse.
    input  wire       active_in,
    input  wire [4:0] hsize_code,
    input  wire [6:0] hpos_code,
    input  wire [4:0] vshift_code,

    input  wire [7:0] r_in,
    input  wire [7:0] g_in,
    input  wire [7:0] b_in,
    input  wire       hs_in,
    input  wire       vs_in,
    input  wire       hb_in,
    input  wire       vb_in,

    output wire       ce_pix_out,
    output wire [7:0] r_out,
    output wire [7:0] g_out,
    output wire [7:0] b_out,
    output wire       hs_out,
    output wire       vs_out,
    output wire       hb_out,
    output wire       vb_out
);

    localparam integer H_TOTAL = 506;
    localparam integer V_TOTAL = 289;
    localparam [7:0] READ_PERIOD_BASE = 8'd48; // (96 MHz / 8 MHz) * 4 quarters
    // Keep the wrapper independent of crt_adjust.sv's preprocessor scope.
    // Questa compiles each source as a separate compilation unit, while sv2v
    // processes the source list together.  Both must select SYNCSHIFT (= 0).
    localparam integer CRT_HPOS_SYNCSHIFT = 0;

    // First-silicon H-size is the globally coherent Y-unit subset 0..-4.
    // At -5 with H-position +44 the buffered active window reaches HSync.
    // Invalid codes fail safely to zero.
    wire signed [5:0] hsize_request_wide =
        -$signed({1'b0, hsize_code});
    wire signed [4:0] hsize_request =
`ifdef MUT_CRT_HSIZE_MINUS5
        (hsize_code <= 5'd5) ? hsize_request_wide[4:0] : 5'sd0;
`else
        (hsize_code <= 5'd4) ? hsize_request_wide[4:0] : 5'sd0;
`endif

    // Exact output-phase Y-unit SYNCSHIFT range: 0,+1,...,+44,-4,...,-1.
    // Codes 45..48 therefore decode as code-49.  True -5 is nominally inside
    // the porch but loses an active pixel in the real buffered pipeline.
    wire signed [8:0] hpos_request =
        (hpos_code <= 7'd44) ? $signed({2'b00, hpos_code}) :
        (hpos_code <= 7'd48) ? $signed({2'b00, hpos_code}) - 9'sd49 :
`ifdef MUT_CRT_HPOS_PLUS45
        (hpos_code == 7'd49) ? 9'sd45 :
`endif
`ifdef MUT_CRT_HPOS_MINUS5
        (hpos_code == 7'd53) ? -9'sd5 :
`endif
                              9'sd0;
    // The upstream zero-offset SYNCSHIFT stage registers hs_in once.  Generate
    // one phase early so the actual hs_ref_out edge—not merely hs_pre—lands on
    // the user-selected offset.  Invalid codes still mean output offset zero.
    wire [8:0] hpos_phase_request =
        (hpos_code == 7'd0)  ? 9'd505 :
        (hpos_code <= 7'd44) ? ({2'b00, hpos_code} - 9'd1) :
        (hpos_code <= 7'd48) ? (9'd456 + {2'b00, hpos_code}) :
`ifdef MUT_CRT_HPOS_PLUS45
        (hpos_code == 7'd49) ? 9'd44 :
`endif
`ifdef MUT_CRT_HPOS_MINUS5
        (hpos_code == 7'd53) ? 9'd500 :
`endif
                              9'd505;

    // The line buffer delays output VBlank by one line.  The conservative
    // first-silicon range is 0,+1,...,+13,-12,...,-1: codes 14..25 decode as
    // code-26.  -13 is immediately unsafe; the first positive shift that
    // wraps VSync outside the delayed VBlank window is +18.
    wire signed [5:0] vshift_request =
        (vshift_code <= 5'd13) ? $signed({1'b0, vshift_code}) :
        (vshift_code <= 5'd25) ? $signed({1'b0, vshift_code}) - 6'sd26 :
`ifdef MUT_CRT_VSHIFT_MINUS13
        (vshift_code == 5'd26) ? -6'sd13 :
`endif
`ifdef MUT_CRT_VSHIFT_PLUS18
        (vshift_code == 5'd27) ? 6'sd18 :
`endif
                                 6'sd0;
    wire [8:0] vshift_phase_request =
        (vshift_code <= 5'd13) ? {4'd0, vshift_code} :
        (vshift_code <= 5'd25) ? (9'd263 + {4'd0, vshift_code}) :
`ifdef MUT_CRT_VSHIFT_MINUS13
        (vshift_code == 5'd26) ? 9'd276 :
`endif
`ifdef MUT_CRT_VSHIFT_PLUS18
        (vshift_code == 5'd27) ? 9'd18 :
`endif
                                 9'd0;

    reg              active_pending = 1'b0;
    reg              sync_active_q = 1'b0;
    reg signed [4:0] hsize_pending = 5'sd0;
    reg              active_q = 1'b0;
    reg signed [4:0] hsize_q = 5'sd0;
    reg signed [8:0] hpos_q = 9'sd0;
    reg        [8:0] hpos_phase_q = 9'd0;
    reg signed [5:0] vshift_q = 6'sd0;
    reg        [8:0] vshift_phase_q = 9'd0;

    // Lock an inexpensive Y-specific horizontal phase counter to native HS.
    // Feeding this pre-shifted sync into crt_adjust with constant hoffset=0
    // preserves HPOS_SYNCSHIFT behavior while allowing synthesis to prune the
    // upstream 506-bit runtime-tap shift register and its large mux.
    reg native_hs_d = 1'b0;
    reg native_vs_d = 1'b0;
    reg native_hb_d = 1'b1;
    reg native_vb_d = 1'b0;
    reg [1:0] mode_switch_delay = 2'd0;
    reg [8:0] hphase_q = 9'd0;
    wire native_hs_rise = ce_pix && hs_in && !native_hs_d;
    wire native_vs_rise = ce_pix && vs_in && !native_vs_d;
    wire native_active_start = ce_pix && !hb_in && native_hb_d;
    wire native_vblank_end = ce_pix && !vb_in && native_vb_d;
    wire [8:0] hphase_now =
        native_hs_rise ? 9'd0 :
        (hphase_q == 9'd505) ? 9'd0 : hphase_q + 9'd1;
    // MAIN.ASM HESYNC=0x15 means (0x15+1)*2 = 44 output pixels.
    wire [9:0] hsync_end = {1'b0, hpos_phase_q} + 10'd44;
    wire hs_pre =
        (hsync_end <= 10'd506) ?
            ((hphase_now >= hpos_phase_q) &&
             ({1'b0, hphase_now} < hsync_end)) :
            ((hphase_now >= hpos_phase_q) ||
             ({1'b0, hphase_now} < (hsync_end - 10'd506)));
    reg hs_pre_d = 1'b0;
    wire hs_pre_rise = ce_pix && hs_pre && !hs_pre_d;

    always @(posedge clk) if (ce_pix) begin
        native_hs_d <= hs_in;
        native_vs_d <= vs_in;
        native_hb_d <= hb_in;
        native_vb_d <= vb_in;
        hs_pre_d     <= hs_pre;
        hphase_q     <= hphase_now;

        // x=0 is phase 90 from native HS.  Every permitted shifted pulse has
        // ended by phase 87, so H-position can change here without a runt or
        // duplicate HSync.  Size/enable wait for the following shifted rise.
        if (native_active_start) begin
            hpos_q         <= hpos_request;
            hpos_phase_q   <= hpos_phase_request;
            hsize_pending  <= hsize_request;
            // Commit enable/disable one line after native VBlank ends.  Every
            // permitted raw/shifted HS and VS pulse is low there, so changing
            // the external sync mux cannot duplicate or drop a pulse.
            if (mode_switch_delay != 2'd0) begin
                if (mode_switch_delay == 2'd1) begin
                    sync_active_q  <= active_in;
                    active_pending <= active_in;
                end
                mode_switch_delay <= mode_switch_delay - 2'd1;
            end
        end
        if (native_vblank_end)
            mode_switch_delay <= 2'd2;

        // Enabling starts the buffered CE at its shifted line boundary.
        if (hs_pre_rise && active_pending) begin
            hsize_q <= hsize_pending;
            active_q <= 1'b1;
        end
        // Disabling returns to native CE one pixel before native HS rises.
        if (ce_pix && (hphase_now == 9'd505) && !active_pending) begin
            hsize_q <= hsize_pending;
            active_q <= 1'b0;
        end

        // Apply vertical phase only at the native frame boundary.
        if (native_vs_rise) begin
            vshift_q       <= vshift_request;
            vshift_phase_q <= vshift_phase_request;
        end
    end

    // Counter-based V-shift replaces the upstream 289-bit runtime-tap mux.
    // It advances only once per shifted line and keeps the native 4-line pulse.
    reg       native_vs_line_d = 1'b0;
    reg [8:0] vphase_q = 9'd0;
    reg       vs_pre_q = 1'b0;
    wire native_vs_line_rise = vs_in && !native_vs_line_d;
    wire [8:0] vphase_now =
        native_vs_line_rise ? 9'd0 :
        (vphase_q == 9'd288) ? 9'd0 : vphase_q + 9'd1;
    // MAIN.ASM VESYNC=3 means a four-scanline pulse.
    wire [9:0] vsync_end = {1'b0, vshift_phase_q} + 10'd4;
    wire vs_pre_now =
        (vsync_end <= 10'd289) ?
            ((vphase_now >= vshift_phase_q) &&
             ({1'b0, vphase_now} < vsync_end)) :
            ((vphase_now >= vshift_phase_q) ||
             ({1'b0, vphase_now} < (vsync_end - 10'd289)));
    always @(posedge clk) if (hs_pre_rise) begin
        native_vs_line_d <= vs_in;
        vphase_q <= vphase_now;
        vs_pre_q <= vs_pre_now;
    end

    wire [7:0] stretch_r;
    wire [7:0] stretch_g;
    wire [7:0] stretch_b;
    wire       stretch_hs_unused;
    wire       stretch_vs_unused;
    wire       stretch_hb;
    wire       stretch_vb_unused;
    wire       hs_ref;

    // Quarter-cycle read-rate generator.  The accumulator restart source is
    // deliberately hs_ref_out from crt_adjust, never the raw native HSync.
    // In SYNCSHIFT mode hs_ref_out is the shifted line reference; sharing it
    // is what prevents line-to-line phase drift while shrinking.
    reg hs_ref_d = 1'b0;
`ifdef MUT_CRT_RAW_HSYNC_RESET
    wire rate_hs_ref = hs_in;
`else
    wire rate_hs_ref = hs_ref;
`endif
    always @(posedge clk)
        hs_ref_d <= rate_hs_ref;
    wire hs_ref_rise = rate_hs_ref & ~hs_ref_d;

    wire [7:0] read_period =
        READ_PERIOD_BASE + {{3{hsize_q[4]}}, hsize_q};
    reg  [7:0] read_acc = 8'd0;
    wire       read_tick =
        ({1'b0, read_acc} + 9'd4) >= {1'b0, read_period};
    always @(posedge clk) begin
        if (hs_ref_rise)
            read_acc <= 8'd0;
        else if (read_tick)
            read_acc <= read_acc + 8'd4 - read_period;
        else
            read_acc <= read_acc + 8'd4;
    end

    assign ce_pix_out = active_q ? read_tick : ce_pix;

    crt_adjust #(
        .VTOTAL   (V_TOTAL),
        .HTOTAL   (H_TOTAL),
        .HPOS_MODE(CRT_HPOS_SYNCSHIFT)
    ) u_crt_adjust (
        .clk       (clk),
        .pxl_cen   (ce_pix),
        .pxl2_cen  (ce_pix_out),
        .active    (active_q),
        .hsize     (hsize_q),
        .hoffset   (9'sd0),
        .voffset   (6'sd0),
        .r_in      (r_in),
        .g_in      (g_in),
        .b_in      (b_in),
        .hs_in     (hs_pre),
        .vs_in     (vs_pre_q),
        // The module needs true vertical blank separately.  Its horizontal
        // blank input is the combined inactive region, as documented.
        .hb_in     (hb_in | vb_in),
        .vb_in     (vb_in),
        .r_out     (stretch_r),
        .g_out     (stretch_g),
        .b_out     (stretch_b),
        .hs_out    (stretch_hs_unused),
        .vs_out    (stretch_vs_unused),
        .hb_out    (stretch_hb),
        .vb_out    (stretch_vb_unused),
        .hs_ref_out(hs_ref)
    );

    // crt_adjust suppresses pass_q throughout vertical blank, which makes its
    // hb_out stay high for whole blanked lines.  arcade_video samples VBlank
    // only on an HBlank falling edge, so preserve a horizontal edge on every
    // vertical-blank line.  Match the line buffer's one-line RGB latency for
    // VBlank, then use the native per-line HBlank waveform while no pixels are
    // being displayed.
    reg hs_ref_full_d = 1'b0;
    reg vb_line_q = 1'b0;
    reg vb_active_q = 1'b0;
    reg vs_sync_q = 1'b0;
    always @(posedge clk) begin
        hs_ref_full_d <= hs_ref;
        if (hs_ref && !hs_ref_full_d) begin
            vb_line_q   <= vb_in;
            vb_active_q <= vb_line_q;
            vs_sync_q   <= vs_pre_q;
        end
    end

    // External bypass is intentional: with CRT Adjust Off, the stream entering
    // arcade_video is bit-for-bit native rather than the module's pipelined
    // internal bypass.  HDMI therefore remains untouched while the option is
    // Off; when On, HDMI follows the adjusted core-side stream.
    // H-size shrink can bring buffered content up to a shifted sync edge.
    // Sync is always blanked explicitly, so no active RGB reaches the DAC
    // during retrace even at the combined control extremes.
    wire adjusted_retrace = vb_active_q | hs_ref;
    assign r_out  = active_q ? (adjusted_retrace ? 8'd0 : stretch_r) : r_in;
    assign g_out  = active_q ? (adjusted_retrace ? 8'd0 : stretch_g) : g_in;
    assign b_out  = active_q ? (adjusted_retrace ? 8'd0 : stretch_b) : b_in;
    // Sync leaves at the native pixel cadence, not the variable read cadence.
    // This keeps the assembly-programmed pulse widths exactly 44 pixels /
    // four lines while the pixel hold time changes inside the line buffer.
    assign hs_out = sync_active_q ? hs_ref : hs_in;
    assign vs_out = sync_active_q ? vs_sync_q : vs_in;
`ifdef MUT_CRT_VB_NO_HB_EDGES
    assign hb_out = active_q ? (stretch_hb | hs_ref) : hb_in;
`else
    assign hb_out = active_q ?
        (vb_active_q ? (hb_in | hs_ref) : (stretch_hb | hs_ref)) :
        hb_in;
`endif
    assign vb_out = active_q ? vb_active_q : vb_in;

endmodule

`default_nettype wire
