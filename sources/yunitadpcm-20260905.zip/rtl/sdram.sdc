# SDRAM I/O timing (MT48LC16M16, ~96 MHz). The PLL hierarchy emu|pll|pll_inst|
# altera_pll_i matches this core (emu instantiates `pll pll`); general[1] = outclk_1
# = clk_sdram (the phase-shifted pin clock), general[0] = outclk_0 = clk_sys.
create_generated_clock -name SDRAM_CLK \
  -source [get_pins -compatibility_mode {emu|pll|pll_inst|altera_pll_i|general[1].gpll~PLL_OUTPUT_COUNTER|divclk}] \
  [get_ports {SDRAM_CLK}]

# data access delay (tAC): MT48LC16M16 CAS2 tAC = 6.0 ns (matches jtframe's proven
# MiSTer/MiST SDRAM constraint; Tecmo's extra +0.5 was over-conservative).
set_input_delay -clock SDRAM_CLK -max 6.0 [get_ports {SDRAM_DQ[*]}]

# data output hold time (tOH)
set_input_delay -clock SDRAM_CLK -min 2.5 [get_ports {SDRAM_DQ[*]}]

# data input setup time (tIS)
set_output_delay -clock SDRAM_CLK -max 1.5 [get_ports {SDRAM_A* SDRAM_BA* SDRAM_D* SDRAM_CKE SDRAM_n*}]

# data input hold time (tIH)
set_output_delay -clock SDRAM_CLK -min -0.8 [get_ports {SDRAM_A* SDRAM_BA* SDRAM_D* SDRAM_CKE SDRAM_n*}]

# use proper edges for the timing calculations
set_multicycle_path -setup -end \
  -rise_from [get_clocks {SDRAM_CLK}] \
  -rise_to [get_clocks {emu|pll|pll_inst|altera_pll_i|general[0].gpll~PLL_OUTPUT_COUNTER|divclk}] 2

# Clock domains (PLL outputs): general[0]=clk_sys 96, [1]=clk_sdram 96, [2]=clk_snd 12,
# [3]=clk_cpu 24 (LEGACY, UNUSED since P0019). *** The CPU no longer runs on general[3]. ***
# ROOT CAUSE of the black screen: the old design ran the CPU on a separate clk_cpu (general[3])
# and declared it ASYNCHRONOUS, so STA never timed the CPU<->memsys crossing (yunit_mem_cdc);
# the fitter routed those paths freely and they failed on real silicon while passing zero-delay
# sim. FIX (P0019): run the CPU on clk_sys (general[0]) with a synchronous clock-enable (cpu_ce),
# so the whole CPU<->memsys interface is a SINGLE-CLOCK path STA times natively -- no async CDC.
# general[3] now clocks nothing; keeping it in a group is vacuous but harmless. clk_snd
# (general[2], 12 MHz) keeps its own domain (its sound-latch CDC is separate).
set_clock_groups -asynchronous \
  -group [get_clocks [list \
     {emu|pll|pll_inst|altera_pll_i|general[0].gpll~PLL_OUTPUT_COUNTER|divclk} \
     {emu|pll|pll_inst|altera_pll_i|general[1].gpll~PLL_OUTPUT_COUNTER|divclk} \
     {emu|pll|pll_inst|altera_pll_i|general[3].gpll~PLL_OUTPUT_COUNTER|divclk} ]] \
  -group [get_clocks {emu|pll|pll_inst|altera_pll_i|general[2].gpll~PLL_OUTPUT_COUNTER|divclk}]

# ---- CPU clock-enable multicycle (P0019) ------------------------------------------------
# Every CPU-domain flop is gated by cpu_ce. Its fastest possible source,
# ce_micro, is an exact 25/96 MHz phase enable whose pulses are separated by at
# least three clk_sys cycles; the retirement scheduler can only suppress pulses.
# This is not the TMS34010 architectural cycle rate. The 3-cycle exception
# matches the minimum real capture-edge separation.
# The cpu_ce domain spans THREE groups, all enumerated below:
#   1. the architectural core state under *tms34010_core:u_core|*, EXCLUDING
#      tms34010_io_regs:u_io_regs and the MMFM commit boundary. The I/O register
#      file captures full-rate bus/device events, its child tms34010_video
#      advances on ce_pix, and mmfm_commit_* captures/commits on consecutive
#      sysclk edges; none is a cpu_ce-only endpoint. In particular timing_start_o,
#      live HCOUNT/VCOUNT, and both sides of the MMFM boundary must retain
#      ordinary one-cycle timing.
#   2. the yunit_mem_cdc CPU-side FSM (NOT the sys-side, which runs full-rate every clk)
#   3. the derail/reset-vector capture block in yunit_top (rd_cnt/ack_q/.../dbg_*), which I moved
#      onto cpu_ce -- its long combinational inputs come straight off the core, so it must relax too.
# NOTE: use ONE-LINE get_registers (space-separated patterns). A backslash-continuation INSIDE
# the {} braces is a Tcl trap -- it mangles the pattern list so nothing matches (that was the
# first-build -12.5ns miss). Entity:instance names are the post-sv2v Quartus form; a wrong
# pattern matches nothing and fails LOUDLY in the fitted constraint audit.
# The /4-clock-enable design family: the frozen Smash recovery top AND the
# family2 rebase share the same CE divider and therefore the same multicycle
# structure. Entity-keyed patterns list both names (-nowarn: the absent flavor
# contributes nothing); instance-keyed patterns (u_sys|u_dma|...) already match
# either hierarchy.
set smash_recovery_ce [get_registers -nowarn {*yunit_top_smash_firefix:yunit_top|ce_div* *yunit_top_family2:yunit_top|ce_div*}]
set smash_recovery [expr {[get_collection_size $smash_recovery_ce] > 0}]
set cpu_regs [get_registers {*tms34010_core:u_core|* *u_memcdc|cst* *u_memcdc|req_tgl* *u_memcdc|c_ack* *u_memcdc|c_rdata* *u_memcdc|ackt_sync* *u_memcdc|p_we* *u_memcdc|p_addr* *u_memcdc|p_size* *u_memcdc|p_wdata*}]
if {$smash_recovery} {
  set cpu_top_regs [get_registers -nowarn {*yunit_top_smash_firefix:yunit_top|rd_cnt* *yunit_top_smash_firefix:yunit_top|ack_q* *yunit_top_smash_firefix:yunit_top|d_started* *yunit_top_smash_firefix:yunit_top|d_prevpc* *yunit_top_smash_firefix:yunit_top|dbg_derailed* *yunit_top_smash_firefix:yunit_top|dbg_culprit_pc* *yunit_top_smash_firefix:yunit_top|dbg_culprit_instr* *yunit_top_smash_firefix:yunit_top|dbg_derail_pc* *yunit_top_family2:yunit_top|rd_cnt* *yunit_top_family2:yunit_top|ack_q* *yunit_top_family2:yunit_top|d_started* *yunit_top_family2:yunit_top|d_prevpc* *yunit_top_family2:yunit_top|dbg_derailed* *yunit_top_family2:yunit_top|dbg_culprit_pc* *yunit_top_family2:yunit_top|dbg_culprit_instr* *yunit_top_family2:yunit_top|dbg_derail_pc*}]
} else {
  set cpu_top_regs [get_registers -nowarn {*yunit_top:yunit_top|rd_cnt* *yunit_top:yunit_top|ack_q* *yunit_top:yunit_top|d_started* *yunit_top:yunit_top|d_prevpc* *yunit_top:yunit_top|dbg_derailed* *yunit_top:yunit_top|dbg_culprit_pc* *yunit_top:yunit_top|dbg_culprit_instr* *yunit_top:yunit_top|dbg_derail_pc*}]
}
set cpu_regs [add_to_collection $cpu_regs $cpu_top_regs]
set cpu_fullrate_io_regs [get_registers {*tms34010_core:u_core|*u_io_regs|*}]
set cpu_regs [remove_from_collection $cpu_regs $cpu_fullrate_io_regs]
set cpu_fullrate_mmfm_commit_data [get_registers -nowarn {*tms34010_core:u_core|mmfm_commit_data_q[*]*}]
set cpu_fullrate_mmfm_commit_target [get_registers -nowarn {*tms34010_core:u_core|mmfm_commit_target_q[*]*}]
set cpu_fullrate_mmfm_commit [add_to_collection $cpu_fullrate_mmfm_commit_data $cpu_fullrate_mmfm_commit_target]
set cpu_regs [remove_from_collection $cpu_regs $cpu_fullrate_mmfm_commit]
if {$smash_recovery} {
  # The cabinet-good path emits exactly one CPU step every four sysclk edges.
  set_multicycle_path -setup 4 -from $cpu_regs -to $cpu_regs
  set_multicycle_path -hold  3 -from $cpu_regs -to $cpu_regs
} else {
  # The family cadence generator can emit opportunities three sysclks apart.
  set_multicycle_path -setup 3 -from $cpu_regs -to $cpu_regs
  set_multicycle_path -hold  2 -from $cpu_regs -to $cpu_regs
}

# The shift-register bridge captures the core's combinational request payload
# only on cpu_ce.  These are the complete first-stage command bank; downstream
# command_issued/ack/engine registers are full-rate and are intentionally not
# relaxed.
set shiftreg_command_capture [get_registers -nowarn {*yunit_shiftreg_command_bridge:u_shiftreg_cmd|cmd_valid_q* *yunit_shiftreg_command_bridge:u_shiftreg_cmd|cmd_write_q* *yunit_shiftreg_command_bridge:u_shiftreg_cmd|cmd_bit_addr_q*}]
if {[get_collection_size $shiftreg_command_capture] > 0} {
  set_multicycle_path -setup 3 -from $cpu_regs -to $shiftreg_command_capture
  set_multicycle_path -hold  2 -from $cpu_regs -to $shiftreg_command_capture
}

# Engine completion is held at full rate in ack_pending_q, then sampled only on
# cpu_ce into the preserved core_ack_q.  The core sees that registered response
# on the following cpu_ce edge.  Relax ONLY core_ack_q -> CPU: engine_done,
# ack_pending_q, and command_issued_q remain ordinary one-cycle state.
set shiftreg_cpu_response [get_registers -nowarn {*yunit_shiftreg_command_bridge:u_shiftreg_cmd|core_ack_q}]
if {[get_collection_size $shiftreg_cpu_response] > 0} {
  if {$smash_recovery} {
    set_multicycle_path -setup 4 -from $shiftreg_cpu_response -to $cpu_regs
    set_multicycle_path -hold  3 -from $shiftreg_cpu_response -to $cpu_regs
  } else {
    set_multicycle_path -setup 3 -from $shiftreg_cpu_response -to $cpu_regs
    set_multicycle_path -hold  2 -from $shiftreg_cpu_response -to $cpu_regs
  }
}

# The cadence scheduler is instantiated beside u_core, so its retirement
# capture bank is not part of cpu_regs.  instr_retire is asserted only on a
# cpu_ce edge; these two registers capture the decode-derived retirement
# budget there, then the full-rate target_cycles register consumes only this
# registered bank one sysclk later.  Do not relax target_cycles or any other
# scheduler state from this broad cpu_regs collection.
set scheduler_retire_capture [get_registers -nowarn {*tms34010_cycle_scheduler:u_cpu_scheduler|retire_toggle_q* *tms34010_cycle_scheduler:u_cpu_scheduler|retire_cycles_q*}]
if {[get_collection_size $scheduler_retire_capture] > 0} {
  set_multicycle_path -setup 3 -from $cpu_regs -to $scheduler_retire_capture
  set_multicycle_path -hold  2 -from $cpu_regs -to $scheduler_retire_capture
}

# The CPU-domain INTENB, INTPEND, and HSTCTLH shadows can reach the scheduler's
# instruction-start state through interrupt priority/decode.  All three
# shadows change only on cpu_ce, and instruction_start_o is itself
# cpu_ce-qualified.
# The two intervening sysclk edges therefore cannot select any start-dependent
# scheduler assignment; the first possible capture of a newly launched shadow
# value is the next cpu_ce, at least three sysclks later.
#
# Keep this exception least-privilege: the exact three interrupt-shadow vectors
# are the only sources, and the targets are exactly the physical direct
# instruction-start fanout (phase accumulator plus active/waiting state).  The
# dangling debug output cadence_overrun is optimized away in production and is
# deliberately absent.  permit_q, target_cycles, retire_*, retire_seen_q, and
# every scheduler-local path remain single-cycle.
set scheduler_interrupt_shadow [get_registers {*tms34010_io_cpu_status:u_io_cpu_status|intenb[*] *tms34010_io_cpu_status:u_io_cpu_status|intpend[*] *tms34010_io_cpu_status:u_io_cpu_status|hstctlh[*]}]
set scheduler_start_elapsed_cycles [get_registers -nowarn {*tms34010_cycle_scheduler:u_cpu_scheduler|elapsed_cycles*}]
set scheduler_start_elapsed_fraction [get_registers -nowarn {*tms34010_cycle_scheduler:u_cpu_scheduler|elapsed_fraction*}]
set scheduler_start_active [get_registers -nowarn {*tms34010_cycle_scheduler:u_cpu_scheduler|active*}]
set scheduler_start_waiting [get_registers -nowarn {*tms34010_cycle_scheduler:u_cpu_scheduler|waiting*}]
if {[get_collection_size $scheduler_start_active] > 0} {
  set_multicycle_path -setup 3 -from $scheduler_interrupt_shadow -to $scheduler_start_elapsed_cycles
  set_multicycle_path -hold  2 -from $scheduler_interrupt_shadow -to $scheduler_start_elapsed_cycles
  set_multicycle_path -setup 3 -from $scheduler_interrupt_shadow -to $scheduler_start_elapsed_fraction
  set_multicycle_path -hold  2 -from $scheduler_interrupt_shadow -to $scheduler_start_elapsed_fraction
  set_multicycle_path -setup 3 -from $scheduler_interrupt_shadow -to $scheduler_start_active
  set_multicycle_path -hold  2 -from $scheduler_interrupt_shadow -to $scheduler_start_active
  set_multicycle_path -setup 3 -from $scheduler_interrupt_shadow -to $scheduler_start_waiting
  set_multicycle_path -hold  2 -from $scheduler_interrupt_shadow -to $scheduler_start_waiting
}

# int1 is a held level in both implementations. The recovery path sources it
# directly from the cabinet-proven blitter and samples it on the exact /4 CE;
# the family path sources it from the independently timed completion block.
if {$smash_recovery} {
  set recovery_dma_irq [get_registers -nowarn {*u_sys|u_dma|blit_irq*}]
  set_multicycle_path -setup 4 -from $recovery_dma_irq -to $cpu_regs
  set_multicycle_path -hold  3 -from $recovery_dma_irq -to $cpu_regs
} else {
  set family_dma_irq [get_registers -nowarn {*u_dma_logical_timer|blit_irq*}]
  set_multicycle_path -setup 3 -from $family_dma_irq -to $cpu_regs
  set_multicycle_path -hold  2 -from $family_dma_irq -to $cpu_regs
}

# game_id: the per-title profile selector. QUASI-STATIC -- written ONCE from the MRA
# during ioctl_download (Arcade-SmashTV.sv:365-367, ioctl_index==3 && ioctl_addr==0,
# the first word of the profile file) and constant for the entire run thereafter.
#
# It fans out to every per-title decision in the core, so its cone reaches deep into
# the CPU, and STA analysed it as an ordinary SINGLE-CYCLE path. Measured 2026-07-28
# on the first fit that ever placed: ALL 200 of the worst setup paths started at
# game_id and ended in tms34010_core register-file indices (rf_rs1_idx / rf_rs2_file),
# 19.077 ns of logic against a 10.416 ns period -> worst slack -8.950 ns and an Fmax
# of 51.64 MHz on a 96 MHz clock. Nothing else was close.
#
# A multicycle is an ANALYSIS directive only -- the flops still capture every clk. The
# claim being made is just that game_id has settled long before anything consumes it,
# which is true by construction: it is written before the ROM data it selects between
# has finished loading. Deliberately a multicycle rather than set_false_path: the
# weaker statement is the one that is provably true, and 3 cycles (31.25 ns vs the
# 19.08 ns path) leaves ~12 ns of margin -- far outside the ~1.35 ns placement spread
# T-unit measured across seeds, so it cannot be a one-sample illusion.
set game_id_regs [get_registers -nowarn {*game_id[*]}]
if {[get_collection_size $game_id_regs] > 0} {
  set_multicycle_path -setup 3 -from $game_id_regs
  set_multicycle_path -hold  2 -from $game_id_regs
}
# DIAG_BOOT overlay: a slow diagnostic display whose pixel datapath is ce_pix-gated (1-in-12) and
# whose inputs are stable/slow core+derail signals. Relax ALL paths INTO it. Safe because a
# multicycle is an ANALYSIS directive only (flops still capture every clk); the sole 1-cycle-real
# paths inside it (the toggle-detect ORs) are trivial and cannot hide a real violation. In the
# production (non-DIAG) build u_diag2 does not exist and this matches nothing (harmless).
set_multicycle_path -setup 3 -to [get_registers {*smashtv_diag2_overlay:u_diag2|*}]
set_multicycle_path -hold  2 -to [get_registers {*smashtv_diag2_overlay:u_diag2|*}]

# yunit_mem field-engine (RAM/PAL/CMOS) BRAM writes are MULTICYCLE by the FSM: the
# CPU address a_q is latched in M_IDLE and the write happens in M_HFIN, always 3
# states later (M_ACK->M_HR1->M_HR2->M_HFIN), with a_q stable throughout. So the
# a_q -> field-BRAM address/we combinational chain (region decode + hidx adder +
# hval compare, ~12.5 ns) has >=2 whole clk_sys periods available, not 1. Scoped to
# the ram/pal/nvram BRAM cells only (NOT mem_rdata, which is single-cycle). Safe:
# a wrong -to pattern matches nothing and the violation simply persists.
set_multicycle_path -setup -end 2 \
  -from [get_registers {*u_sys|u_mem|a_q[*]}] \
  -to   [get_registers {*u_sys|u_mem|ram_rtl_0* *u_sys|u_mem|pal_rtl_0* *u_sys|u_mem|nvram_rtl_0*}]
set_multicycle_path -hold -end 1 \
  -from [get_registers {*u_sys|u_mem|a_q[*]}] \
  -to   [get_registers {*u_sys|u_mem|ram_rtl_0* *u_sys|u_mem|pal_rtl_0* *u_sys|u_mem|nvram_rtl_0*}]

# ioctl_index -> CMOS/NVRAM BRAM: the MRA PART SELECTOR. QUASI-STATIC across a part,
# same class as game_id above, but proven from the yunit_nvram_bridge GATING rather than
# from "written once".
#
# MEASURED (build_syn/runs/20260804T161133Z-892576/constraint_audit.log): 19 of the 20
# worst setup paths in the whole design start at emu|hps_io|ioctl_index[2] and end on
# u_mem|nvram_rtl_0 porta_datain_reg*, ~18.46 ns arrival against a 10.416 ns period ->
# worst slack -0.175 (Slow 100C) / -0.055 (Slow -40C). Nothing else in the top 16 rows.
#
# WHERE THE PATH IS. ioctl_index reaches u_mem through EXACTLY ONE seam: the index-4
# decode in yunit_nvram_bridge.sv:48-49 (nvram_download/nvram_upload) -> nvram_ext_en
# (:56,:60) and nvram_ext_wr (:61-62), wired Arcade-SmashTV.sv:362-363 ->
# yunit_top_family2.sv:509 -> yunit_memsys_family2.sv:239 -> u_mem. Inside u_mem that
# single ownership qualifier selects the host-vs-engine muxes on the NVRAM port
# (yunit_mem_family2.sv:854-866: nv_ext_word_addr, nv_aa, nv_awd, nv_awe, nv_bwe), so it
# arrives at the BRAM datain through the fwd-address compare, the nv_ext_base mux, the
# byte-lane merge and the host/engine mux -- a deep unregistered cone crossing the die
# from hps_io to the CMOS M10Ks. yunit_top_family2 has no ioctl_index port at all: the
# other index-derived signals entering the core (rom_download/gfx_download/sound_download
# and the mapped ioctl_* ROM stream, family2_download_mapper.sv:54-56) land in the SDRAM
# loader FIFO and in flop reset/enable inputs (yunit_top_family2.sv:219, :678) -- none of
# them reaches a nvram_rtl_0 port, and the fitted netlist agrees: the whole worst-path
# table shows exactly one index endpoint class, the CMOS BRAM.
#
# WHY THE EXCEPTION IS TRUE -- ioctl_index CANNOT MOVE THE ENDPOINT BY ITSELF.
# This is a GATING argument. It does not depend on any FSM state, mux quiescence, or
# transaction length, which is exactly why it survives adversarial review.
#
#   yunit_nvram_bridge.sv:48-49, :56, :60-62
#     nvram_download = ioctl_download & (ioctl_index == 8'd4)
#     nvram_upload   = ioctl_upload   & (ioctl_index == 8'd4)
#     nvram_ext_en   = nvram_download | clearing | nvram_upload
#     nvram_ext_wr   = clearing | (nvram_download & ioctl_wr & nvram_addr_valid)
#
# ioctl_index reaches u_mem ONLY through those two AND gates and ONLY via those two
# signals: :63-64 prove nvram_ext_addr and nvram_ext_wdata carry no index term at all.
# In every AND, the other input is ioctl_download or ioctl_upload.
#
#  1. WHEN THE ENDPOINT ACTUALLY MOVES, ioctl_index IS NOT THE CAUSE. Every real edge on
#     nvram_ext_en / nvram_ext_wr is caused by an edge on ioctl_download, ioctl_upload,
#     clearing or ioctl_wr. NONE of those four is in the -from collection, so all four stay
#     SINGLE-CYCLE and keep pinning the whole shared downstream cone -- the fwd compare,
#     the nv_ext_base mux, the byte-lane merge and the host/engine mux are the SAME physical
#     cells on the ioctl_download path, and ioctl_download launches from the same hps_io
#     placement, so the die-crossing route is pinned too. This exception buys the fitter no
#     licence whatsoever to slow that cone down; it only stops STA charging the extra
#     8-bit index-compare levels at the front of it against a single period.
#
#  2. WHEN ioctl_index MOVES IN NORMAL OPERATION, THE ENDPOINT VALUE DOES NOT CHANGE AT
#     ALL. The HPS sends FIO_FILE_INDEX (hps_io.sv:657-660) before opening the transfer,
#     i.e. with ioctl_download and ioctl_upload both LOW -- they are set by a DIFFERENT
#     command, FIO_FILE_TX (hps_io.sv:662-679). With both AND gates held at their
#     controlling input 0, nvram_download and nvram_upload are 0 REGARDLESS of the index,
#     so nvram_ext_en is whatever `clearing` says and nvram_ext_wr is whatever `clearing`
#     says, before and after the index edge alike. A path whose endpoint value provably
#     cannot change has no setup requirement to meet. (This branch -- and only this branch
#     -- carries the firmware assumption stated below; the TIMING FLOOR is the RTL-only
#     fallback for the case where it does not hold.)
#
# TIMING FLOOR (the belt to that braces; holds even if the index moves mid-download).
# hps_io.sv:637 clears has_cmd on ~fp_enable, so FIO_FILE_INDEX (:657-660) and
# FIO_FILE_TX_DAT (:693-703) are not merely different strobes -- they are different
# CHIP-SELECT windows, each needing its own command word. sys_top.v:256-263 makes
# io_strobe a ONE-CYCLE pulse (rack <= io_clk one cycle after every strobe), with io_clk
# double-registered from gp_out (:265-270), so two strobes can NEVER be adjacent: the
# hardware floor on strobe spacing is 2 clk_sys cycles. Ledger, index strobe in cycle E:
#     edge  E+1   ioctl_index takes the new value                <- LAUNCH EDGE
#     ...         fp_enable must drop and re-rise (hps_io.sv:637 resets has_cmd)
#     cycle >=E+2 command strobe carrying FIO_FILE_TX_DAT
#     cycle >=E+4 data strobe                    (strobes >= 2 cycles apart)
#     edge  >=E+5 wr <= 1                        (hps_io.sv:697)
#     edge  >=E+6 ioctl_wr <= wr                 (hps_io.sv:634) -> nvram_ext_wr in E+6
#     edge  >=E+7 NVRAM port A captures                          <- CAPTURE EDGE
# Launch E+1 to capture E+7 = SIX clk_sys cycles of stability, not four, and that already
# ignores the FIO_FILE_TX address words the real HPS interposes. The real HPS word rate is
# orders of magnitude slower and the index is held for the whole part.
#
# WHAT IS *NOT* CLAIMED. An earlier revision of this comment argued that
# yunit_mem_family2.sv:1304-1316 "forces any in-flight CMOS transaction back to M_ACK" so
# the mux select can never move under a live engine write. THAT IS FALSE AS STATED and is
# recorded here so nobody re-derives it: the abort is a SYNCHRONOUS state assignment
# (:1309-1311) while eng_awe is COMBINATIONAL off `state` (:819-831), so in the cycle
# nvram_ext_en changes eng_awe is still asserted and nv_aa (:855), nv_awd (:857) and
# nv_awe (:864) all switch on the relaxed select. The existence of the abort proves the
# designer expected en to be able to rise mid-transaction; "the select never moves with a
# transfer open" is therefore not available as a premise, and the exception does not use
# it. What the abort DOES buy, correctly stated, is that no capture occurs on either
# ownership edge: on a RISE, nv_awe collapses to nvram_ext_wr_on (:864), which needs
# ioctl_wr in the same cycle the index lands -- impossible, since that needs strobes in
# adjacent cycles; on a FALL, state has been held in {M_IDLE, M_ACK} for the whole
# ownership window (:1309-1311 aborts every edge, :1316 refuses new requests), so eng_awe
# is 0 and the engine needs M_ACK->M_HR1->M_HR2->M_HFIN->M_HFIN2 (:825-829) before it
# writes again. That is a suppression argument, not a settling-time argument, and it is
# secondary: points 1 and 2 above stand without it.
#
# READ SIDE. nv_aq re-reads unconditionally every clk (:888), so a one-cycle unsettled read
# address self-heals on the next edge, and :1304-1308 restarts the whole field operation
# after host ownership ends precisely so no torn window is published.
#
# RESIDUAL ASSUMPTION, STATED PLAINLY. Point 2 rests on the HPS not moving ioctl_index in
# the middle of a part. That is FIRMWARE behaviour, NOT RTL-enforced -- nothing in hps_io
# forbids a FIO_FILE_INDEX while ioctl_download is high. It is also ALREADY load-bearing
# across this core at a FAR larger blast radius: Arcade-SmashTV.sv:497 (sound_download),
# :676 (sw[] DIP capture at index 254), :579 (the legacy mapper's index port),
# family2_download_mapper.sv:54-56 (prog/snd/gfx stream routing) and
# yunit_nvram_bridge.sv:48 ALL decode ioctl_index DURING ioctl_download to route the byte
# stream. If the index moved mid-part, megabytes of ROM would land in the wrong SDRAM
# region and the core would be dead long before one CMOS byte was at risk. This exception
# adds NO assumption the design is not already betting everything on -- and the TIMING
# FLOOR above covers it anyway, at 6 cycles against the 2 claimed.
#
# So: 2 cycles claimed, on a path whose endpoint value cannot move with the index at all,
# backed by a 6-cycle RTL protocol floor if you refuse that. Deliberately a bounded
# multicycle and NOT set_false_path: 2 is what the failing path needs, and a bounded claim
# survives a future revision that shortens the protocol.
#
# LEAST PRIVILEGE -- what this does NOT relax:
#  * ioctl_dout, ioctl_addr and ioctl_wr -> the same BRAM stay SINGLE-CYCLE. They change on
#    EVERY downloaded byte and are not quasi-static; only the part selector is relaxed.
#  * ioctl_download / ioctl_upload / clearing -> the same BRAM stay SINGLE-CYCLE, and per
#    point 1 they are the signals that actually toggle the endpoint, so the shared cone
#    they traverse remains fully constrained.
#  * ioctl_index -> the download mapper / SDRAM loader / DIP registers / core reset stay
#    single-cycle (different endpoints, not matched by -to).
#  * every engine and CPU path into nvram_rtl_0 stays as constrained as it was: they do
#    not start at ioctl_index, so -from excludes them.
# A wrong pattern here matches nothing and fails LOUDLY in audit_release_constraints.tcl
# (require_collection ioctl_index_source + require_setup_multicycle ioctl_index_to_nvram),
# which also proves the exception actually landed on the fitted path.
set ioctl_index_regs [get_registers -nowarn {*hps_io:hps_io|ioctl_index[*]}]
set nvram_bram_ports [get_registers -nowarn {*u_sys|u_mem|nvram_rtl_0*}]
if {[get_collection_size $ioctl_index_regs] == 0 ||
    [get_collection_size $nvram_bram_ports] == 0} {
  post_message -type critical_warning \
    "Y-unit ioctl_index quasi-static exception: endpoint collection EMPTY, not applied"
} else {
  set_multicycle_path -setup -end 2 -from $ioctl_index_regs -to $nvram_bram_ports
  set_multicycle_path -hold  -end 1 -from $ioctl_index_regs -to $nvram_bram_ports
}

# The former u_phy autoerase exception is intentionally gone.  The current
# sdram_stock path crosses registered request/address stages, so ordinary
# single-cycle timing is the conservative constraint.  Do not retarget the old
# selector to u_sdram without a new launch/capture protocol proof.

# DMA blitter setup clipping: the accepted-trigger launchf snapshot
# (WIDTH/HEIGHT/XSTART/YSTART/OFFSET/ROWBYTES) feeds width_f/height1/rb_adj/offbytes_c,
# then the S_SETUP state decision and its clipped-parameter latches (~12 ns). launchf is
# captured on IDLE->S_TRIG and S_TRIG provides one full wait cycle before S_SETUP consumes
# it, so these launchf paths have two clk_sys periods. Scope only the state decision and
# clip-cone targets latched in S_SETUP; per-pixel logic uses their registered values.
set_multicycle_path -setup -end 2 \
  -from [get_registers {*u_sys|u_dma|launchf[*][*]}] \
  -to   [get_registers {*u_sys|u_dma|state* *u_sys|u_dma|width_c[*] *u_sys|u_dma|height_c[*] *u_sys|u_dma|xpos_c[*] *u_sys|u_dma|ypos_c[*] *u_sys|u_dma|rowbytes_c[*] *u_sys|u_dma|cur_off[*]}]
set_multicycle_path -hold -end 1 \
  -from [get_registers {*u_sys|u_dma|launchf[*][*]}] \
  -to   [get_registers {*u_sys|u_dma|state* *u_sys|u_dma|width_c[*] *u_sys|u_dma|height_c[*] *u_sys|u_dma|xpos_c[*] *u_sys|u_dma|ypos_c[*] *u_sys|u_dma|rowbytes_c[*] *u_sys|u_dma|cur_off[*]}]

# ---------------------------------------------------------------------------
# YUNIT-P0047: fitter-only setup overconstraint on the CORE clock (clk_sys).
# EXACTLY the mechanism of YUNIT-P0036 below, aimed at the domain that owns the
# residual Family2 worst path once the ioctl_index exception above lands.
#
# WHAT IS LEFT AFTER THE ioctl_index EXCEPTION. In the last fit
# (build_syn/runs/20260804T161133Z-892576/constraint_audit.log) rows 1-16 and 18-20
# of the design-wide worst-path table were ioctl_index -> nvram_rtl_0 and are now
# excepted. Row 17 is not, and it becomes the new design-wide worst:
#     from stv_vram_ddr_top:u_vram_sdram|fill_row[2]
#     to   ...|altsyncram:rc_rtl_0|...|ram_block1a0~porta_datain_reg25
#     slack -0.023  arrival 18.426   (Slow 1100mV 100C)
# fill_row feeds bfill_bt (stv_vram_ddr_top.sv:1192) into SIX priority-ordered 16-bit
# beat compares that override the DDR fill beat (:1205-1212), so it reaches the
# row-cache datain through a compare plus a 6-level mux/lane-merge chain.
#
# A MULTICYCLE HERE IS FALSE AND IS REFUSED. Do not add one, and do not "rediscover"
# it: :631 advances fillbeat on EVERY b_rd_valid and :627 sizes sub-bursts up to BMAX,
# so b_rd_valid asserts on back-to-back cycles for the whole burst and the rc[] write
# at :667 has exactly ONE clk_sys period every beat. The correct lever is fitter
# effort, which is what this block buys.
#
# WHY THE FITTER LEVER IS HONEST HERE -- the cone is PLACEMENT-limited, not
# DEPTH-limited. This endpoint class has measured, across Family2 fits:
#     +0.120 / -0.023 / -0.025 / -0.096
# a 216 ps spread on the SAME logic, centred on zero, with one member ALREADY CLOSING
# POSITIVE. Identical LUT depth cannot produce a 216 ps spread; placement and routing
# can, and the +0.120 sample is an existence proof that a passing placement is inside
# the fitter's reachable space. A depth-limited cone misses by nanoseconds and closes
# on no seed. So a plain refit is a coin flip on luck; what the image needs is margin,
# i.e. bias the annealer to keep working this cone instead of stopping the instant it
# reads "barely met".
#
# SIZE = 0.150 ns, and why that number and not another:
#   * it must cover the WORST measured member of the class (-0.096), not just today's
#     -0.023. 0.150 leaves 54 ps on top of that worst case.
#   * 6.5x the present deficit, so it is margin rather than a nudge, and it also
#     covers Slow -40C, where this design has repeatedly RELOCATED its deficit between
#     corners rather than removing it (see P0036's three-seed table below).
#   * it is only 1.44% of the 10.416 ns period, so it is a UNIFORM shift that PRESERVES
#     the ordering of the clk_sys worst-path list -- the annealer still attacks this
#     same cone first, it just no longer gets to stop early. A larger value (P0036 uses
#     0.300, on a much bigger and genuinely chronic deficit) would promote unrelated
#     clk_sys paths into the worst list and spend effort away from the cone that fails.
#
# SCOPE = -from core -to core, i.e. clk_sys register-to-register only. Deliberately NOT
# a bare "-to": that would also tighten the SDRAM_CLK -> clk_sys DQ capture paths
# (set_input_delay at the top of this file), whose delay is set by pin placement and
# board I/O the fitter cannot improve. Promoting an unfixable I/O path to worst-in-domain
# is exactly how you get the annealer to give up on the domain.
#
# FITTER-ONLY, and that is load-bearing. quartus_sta does NOT take this branch, so
# sign-off runs the TRUE constraints, bit-identical to every previous build; timing.json
# and audit_release_constraints.tcl are unaffected. If this leaked into quartus_sta it
# would FABRICATE margin and the release gate would be signing off a lie. It buys fitter
# effort, not tolerance.
# ---------------------------------------------------------------------------
if {[info exists ::TimeQuestInfo(nameofexecutable)] &&
    $::TimeQuestInfo(nameofexecutable) eq "quartus_fit"} {
  set yunit_core_clk [get_clocks -nowarn {emu|pll|pll_inst|altera_pll_i|general[0].gpll~PLL_OUTPUT_COUNTER|divclk}]
  if {[get_collection_size $yunit_core_clk] == 0} {
    post_message -type info "Y-unit core fitter overconstraint: clock not found, skipped"
  } else {
    # +0.150 closed the ADPCM config through r6; db49db3's fixbank M10Ks plus
    # the park_row mirror (which killed the fill_row->o_ptr cone) left r9b
    # missing on THIS SDC block's own documented path (fillbeat->rc datain,
    # -0.169) and the display sequencer (-0.090). Raised to +0.300, the same
    # magnitude the HDMI domain (P0036) has carried since T-unit measured it.
    post_message -type info "Y-unit core fitter overconstraint: +0.300 ns setup uncertainty (fit only)"
    set_clock_uncertainty -setup -from $yunit_core_clk -to $yunit_core_clk -add 0.300
  }
}

# ---------------------------------------------------------------------------
# YUNIT-P0036: fitter-only setup overconstraint on the HDMI pixel clock.
# Ported from T-unit (TUNIT-P0036, commit 6135f08), which measured it and found
# it generalises to every core sharing sys/. Wolf-crt is applying it too.
#
# The chronic slow/-40C blocker is the shared ascal output stage, NOT this core's
# logic. Measured here across three seeds on the family2/CVSD sibling, worst
# setup parked within +/-50 ps of zero every time:
#     seed 4  -0.013 (Slow 100C)
#     seed 3  -0.026 (Slow -40C), while Slow 100C moved to +0.269
#     seed 2  -0.205
# The failing endpoints are ascal:ascal|o_v_poly_t.g0[15] -> o_v_poly_pix.g[*],
# i.e. the same cone T-unit and wolf-crt both land on regardless of what they
# add or remove. Reseeding only RELOCATES the deficit between corners, which is
# why three seeds all produced the same magnitude. The fitter stops optimising
# because the domain sits at its effort floor at "barely fails".
#
# Remedy: during quartus_fit ONLY, add setup uncertainty to paths latched by the
# HDMI divclk so the annealer keeps working this domain. quartus_sta does NOT
# take this branch -- sign-off runs the TRUE constraints, bit-identical to every
# previous build. This does not weaken the timing gate: a build still only ships
# if the real check passes. It buys fitter effort, not tolerance.
# ---------------------------------------------------------------------------
if {[info exists ::TimeQuestInfo(nameofexecutable)] &&
    $::TimeQuestInfo(nameofexecutable) eq "quartus_fit"} {
  set yunit_hdmi_clk [get_clocks -nowarn {*pll_hdmi*counter[0]*divclk}]
  if {[get_collection_size $yunit_hdmi_clk] == 0} {
    post_message -type info "Y-unit HDMI fitter overconstraint: clock not found, skipped"
  } else {
    # The page-publication Family2 seed ladder measured seed 7 with +0.300 as
    # core +0.224 ns and HDMI -0.035 ns. Raising this to +0.475 moved HDMI
    # positive but overcorrected placement: the same seed fell to core -0.505
    # / -0.119 ns at the two slow corners. Use the smallest useful nudge above
    # the measured 35 ps miss, preserving core placement freedom. quartus_sta
    # still sees the true constraints because this branch is quartus_fit-only.
    post_message -type info "Y-unit HDMI fitter overconstraint: +0.350 ns setup uncertainty (fit only)"
    set_clock_uncertainty -setup -to $yunit_hdmi_clk -add 0.350
  }
}
