#!/usr/bin/env python3
"""Build full 1 MiB Y-unit program images from the audited MRA recipes."""

from __future__ import annotations

import argparse
import zipfile
from pathlib import Path

from generate_yunit_mras import GAMES, PROGRAM_LANE_BYTES


def build_image(set_name: str, rom_dir: Path, out_dir: Path) -> Path:
    game = GAMES[set_name]
    archive_name = game.get("archive", set_name)
    archive = rom_dir / f"{archive_name}.zip"
    lo_name, hi_name, lane_offset = game["prog"]

    with zipfile.ZipFile(archive) as rom_zip:
        lo_data = rom_zip.read(lo_name)
        hi_data = rom_zip.read(hi_name)

    lanes: list[bytearray] = []
    for name, data in ((lo_name, lo_data), (hi_name, hi_data)):
        lane = bytearray(PROGRAM_LANE_BYTES)
        end = lane_offset + len(data)
        if end > len(lane):
            raise ValueError(
                f"{set_name}: {name} ends at {end:#x}, past lane {len(lane):#x}"
            )
        lane[lane_offset:end] = data
        lanes.append(lane)

    out_dir.mkdir(parents=True, exist_ok=True)
    output = out_dir / f"{set_name}.hex"
    with output.open("w", encoding="ascii", newline="\n") as hex_file:
        for lo_byte, hi_byte in zip(lanes[0], lanes[1], strict=True):
            hex_file.write(f"{lo_byte | (hi_byte << 8):04X}\n")

    reset_vector = (
        lanes[0][-2]
        | (lanes[1][-2] << 8)
        | (lanes[0][-1] << 16)
        | (lanes[1][-1] << 24)
    )
    if reset_vector >> 24 != 0xFF:
        raise ValueError(
            f"{set_name}: reset vector {reset_vector:08X} is outside program ROM"
        )
    print(
        f"YUNIT_PROGRAM set={set_name} profile={game['profile']} "
        f"words={PROGRAM_LANE_BYTES:#x} reset={reset_vector:08X} out={output}"
    )
    return output


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("rom_dir", type=Path)
    parser.add_argument("out_dir", type=Path)
    parser.add_argument("games", nargs="*", choices=tuple(GAMES), default=tuple(GAMES))
    args = parser.parse_args()

    for set_name in args.games:
        build_image(set_name, args.rom_dir, args.out_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
