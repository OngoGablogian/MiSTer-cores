#!/usr/bin/env python3
"""Fail if a mutation define exists in RTL/benches but no runner ever sets it.

WHY THIS EXISTS
---------------
A `MUT_*` / `PERF_*` ifdef in the RTL reads as coverage. Reviewers see the
guard and assume a runner arms it. If nothing does, the mutant is never
executed and the "mutation-tested" claim attached to it is false.

That is DESIGN-RULES.md section 5's "a gate that passes but does not exercise the
change" wearing a costume that is much harder to spot, because the evidence of
coverage is in the RTL rather than in the test suite. An unreferenced mutation
define is a lie of omission: it survives review, reads as rigour, and fails
silently forever.

Found the hard way. This repo's INTPEND write-mask carried a
MUT_IO_INTPEND_WHOLE_WRITE knob with nothing referencing it, so a
gospel-critical mask was unverified for its whole life. The NARC (Z-unit)
session then ran the same check and found ten in their tree, one of which
(MUT_BFILL_NOLOCK) had been cited as a required sign-off guard on
coherency-critical scanout merge logic while never having been executed.

USAGE
    python tools/check_mutation_gates.py            # report + exit 1 if orphans
    python tools/check_mutation_gates.py --list     # just list, always exit 0

A define counts as ARMED if any runner or gate script mentions it, on the
assumption that a runner naming a mutant either sets it or documents why not.
That is deliberately generous: the point is to catch defines nothing knows
about at all, not to police how each one is driven.
"""

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# Where mutation defines are DECLARED (consumed by the RTL/bench via ifdef).
SOURCE_GLOBS = ("rtl/**/*.sv", "rtl/**/*.v", "sim/**/*.sv")

# Where they must be ARMED (a runner, gate script, or qualification list).
RUNNER_GLOBS = ("sim/*.sh", "tools/*.py", "tools/*.ps1", "quartus/*.sh")

# NOTE THE MISSING LEADING \b, IT IS DELIBERATE AND WAS A BUG ONCE.
# Declarations read `ifdef MUT_X` (space before -> word boundary), but runners
# arm them as -DMUT_X, where 'D' and 'M' are both word characters so there is NO
# boundary. A leading \b therefore matched every DECLARATION and no ARMING, and
# this tool confidently reported 33 orphans when most were armed all along --
# reporting ABSENCE where there was only a different spelling, which is the same
# false-negative class it exists to catch. Keep the trailing \b only.
DEFINE_RE = re.compile(r"(MUT_[A-Z0-9_]+|PERF_[A-Z0-9_]+)\b")

# Defines that are structural rather than mutants. PERF_NO_WORDFETCH implies
# PERF_NO_STREAMBUF inside yunit_mem.sv, so the implication itself is a source
# reference, not an arming. Keep this list EMPTY unless there is a real reason;
# every entry is coverage you are choosing not to have.
NOT_MUTANTS: set[str] = set()


def collect(globs):
    out = {}
    for g in globs:
        for p in ROOT.glob(g):
            if not p.is_file():
                continue
            try:
                text = p.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            for m in DEFINE_RE.findall(text):
                out.setdefault(m, set()).add(p.relative_to(ROOT).as_posix())
    return out


def main() -> int:
    list_only = "--list" in sys.argv

    declared = collect(SOURCE_GLOBS)
    armed = collect(RUNNER_GLOBS)

    orphans = {
        name: files
        for name, files in sorted(declared.items())
        if name not in armed and name not in NOT_MUTANTS
    }

    print(f"mutation defines declared in RTL/benches: {len(declared)}")
    print(f"armed by at least one runner:             {len(declared) - len(orphans)}")
    print(f"ORPHANED (declared, never armed):         {len(orphans)}")

    if orphans:
        print()
        for name, files in orphans.items():
            print(f"  {name}")
            for f in sorted(files):
                print(f"      declared in {f}")

    if list_only:
        return 0

    if orphans:
        print()
        print("FAIL: the defines above read as mutation coverage but no runner arms them.")
        print("Either wire each into the gate that is supposed to kill it, or delete it.")
        print("Do NOT silence this by adding entries to NOT_MUTANTS.")
        return 1

    print()
    print("PASS: every mutation define is armed by a runner.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
