#!/usr/bin/env python3
"""Shorten the shared Y-unit RAMCHECK loops in generated simulation images.

This tool is deliberately limited to the ignored per-profile hex files used by
tb_family2_profile_boot.  It never touches an MRA, a ROM archive, or production
RTL.  The physical RAM path has separate exact read/write/coherency gates; the
profile boot gate needs to get past the games' multi-minute power-on RAM sweep
and exercise their real CPU -> DMA -> framebuffer -> scanout path.

The Williams RAMCHECK library copies the entry count into A9 twice: once for
the fill loop and once for the compare loop.  Each loop ends in a DSJS A9.  Set
those two copies to MOVK 1,A9.  The original loop body and original DSJS both
still execute once, so A9 reaches its natural terminal value (zero) and status
flags remain untouched.  A long surrounding signature and an exactly-one-pair
contract prevent an unrelated 4DA9/DSJS sequence from being patched.

The same shared library then clears 65,536 longwords before first draw.  That
path has already run unshortened through DDR in the per-title characterization
and has dedicated memory/coherency gates.  For the repeatable ten-title gate,
rewrite only its audited MOVI 0x00010000,B4 count to one.  Its store and DSJS
still execute once and B4 again reaches the natural terminal value zero.
"""

from __future__ import annotations

import argparse
from pathlib import Path


FIRST_BODY = (
    "09E7", "5A5A", "5A5A", "56A5", "2027", "CC03",
    "0BA7", "0002", "0000",
)
SECOND_BODY = (
    "09E7", "5A5A", "5A5A", "2027", "CC03",
    "0BA7", "0002", "0000",
)
MOV_A13_A9 = "4DA9"
MOVK_1_A9 = "1829"
FILL_DSJS = "3D29"
VERIFY_DSJS = "3EC9"
ROM_BIT_BASE = 0xFF800000
CLEAR_SIGNATURE = (
    "09F3", "0000", "0000",  # MOVI 0,B3 (screen pointer)
    "09F4", "0000", "0001",  # MOVI 0x00010000,B4 (count)
    "9253", "3C54",            # store; DSJS B4
)


def patch_image(path: Path) -> None:
    words = [line.strip().upper() for line in path.read_text(encoding="ascii").splitlines()]
    candidates: list[int] = []

    for loop in range(16, len(words) - 32):
        if words[loop] != FILL_DSJS or words[loop + 27] != VERIFY_DSJS:
            continue
        if tuple(words[loop - 12:loop - 3]) != FIRST_BODY:
            continue
        if tuple(words[loop + 3:loop + 11]) != SECOND_BODY:
            continue
        # Two compiler/library variants use different working registers, but
        # the three instructions immediately before each DSJS are constrained.
        if words[loop - 3] not in ("4CE6", "4CEB"):
            continue
        if words[loop - 2] not in ("42A6", "42AB"):
            continue
        if words[loop - 1] not in ("92C8", "9368"):
            continue
        candidates.append(loop)

    if len(candidates) != 1:
        raise ValueError(
            f"{path.name}: expected exactly one audited RAMCHECK pair, found {len(candidates)}"
        )

    loop = candidates[0]
    first_sources = [i for i in range(loop - 15, loop - 12) if words[i] == MOV_A13_A9]
    second_sources = [i for i in range(loop + 1, loop + 3) if words[i] == MOV_A13_A9]
    if len(first_sources) != 1 or len(second_sources) != 1:
        raise ValueError(
            f"{path.name}: RAMCHECK A9 producers are not unique "
            f"(fill={first_sources}, verify={second_sources})"
        )

    patched = (first_sources[0], second_sources[0])
    for index in patched:
        words[index] = MOVK_1_A9

    clear_candidates = [
        index for index in range(0, len(words) - len(CLEAR_SIGNATURE) + 1)
        if tuple(words[index:index + len(CLEAR_SIGNATURE)]) == CLEAR_SIGNATURE
    ]
    if len(clear_candidates) != 1:
        raise ValueError(
            f"{path.name}: expected exactly one audited screen-clear loop, "
            f"found {len(clear_candidates)}"
        )
    clear = clear_candidates[0]
    words[clear + 4] = "0001"  # MOVI B4 low word
    words[clear + 5] = "0000"  # MOVI B4 high word

    path.write_text("\n".join(words) + "\n", encoding="ascii", newline="\n")
    pcs = [ROM_BIT_BASE + index * 16 for index in patched]
    clear_pc = ROM_BIT_BASE + (clear + 3) * 16
    print(
        f"YUNIT_PROFILE_FFWD set={path.stem} pairs=1 "
        f"fill_pc={pcs[0]:08X} verify_pc={pcs[1]:08X} "
        f"clear_pc={clear_pc:08X} "
        f"patch={MOV_A13_A9}->{MOVK_1_A9},00010000->00000001"
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("hex_dir", type=Path)
    parser.add_argument("games", nargs="+")
    args = parser.parse_args()

    for game in args.games:
        path = args.hex_dir / f"{game}.hex"
        if not path.is_file():
            raise FileNotFoundError(path)
        patch_image(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
