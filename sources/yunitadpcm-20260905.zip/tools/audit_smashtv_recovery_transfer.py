#!/usr/bin/env python3
"""Fail-closed structural audit for the cabinet-good Smash T.V. recovery path.

This audit deliberately does not invoke Quartus or a simulator.  It proves that
the production selector, ROM/input wiring, and reachable recovery hierarchy
still describe the fe7f246 firefix/mixboot architecture, while the later shared
TMS34010 correctness fixes remain intact.
"""

from __future__ import annotations

import argparse
import hashlib
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from collections import deque
from pathlib import Path


FE7_COMMIT = "fe7f246677fc1790a64425f22ed20304d27dcc25"
B2_TMS_BASELINE = "b2e8367cc27ef74801bc640d1c6fd4bd988104df"
RECOVERY_MRA = (
    "releases/recovery/"
    "Smash T.V. (rev 8.00) [Y-unit firefix recovery].mra"
)
RECOVERY_RBF_STEM = "Arcade-SmashTV-YUnit-Recovery"

# These are Git blob IDs plus SHA-256 over the exact LF-normalized blob bytes at
# the cabinet-good source checkpoint.  Keeping both catches a wrong checkpoint
# as well as an unexpected object-format/content substitution.
FE7_BLOBS: dict[str, tuple[str, str]] = {
    "Arcade-SmashTV.sv": (
        "3217e26504ec4ccf5f5f80476d1ec5b4ac598e32",
        "D9A2E72F08E517D2F82FB76B5D02AC9BF053DA7BF2337590AD87CDD188EB4176",
    ),
    "quartus/build_hw.sh": (
        "5e7d4bdc0ad8f22ae1ca227b6d26efaae067f895",
        "AF6F00E3A31671CA6ED9A6B7BEE70209D262BA7841E8A42D4CF6B51A0717442E",
    ),
    "releases/Smash T.V. (rev 8.00).mra": (
        "197387d5982b65966b4f87b9caa4bfb1fcafec8e",
        "E9ABEC6C182EF18A418331877DA8383671B32A95A4CCA08F8266D6B47B8B6451",
    ),
    "rtl/yunit/yunit_top.sv": (
        "67f33cbf8f17d1967587d11bfb623be29b1e517a",
        "DCA4EEEA7BC70864FC5EB064BB14BA10FB3E24A9DD2CC5C7CFEA82463AABBEBB",
    ),
    "rtl/yunit/yunit_memsys.sv": (
        "7778ccc025da2291fad5ea809f0846933a7a32f2",
        "08ED06DA821B7F947A40DE9825D842B9841251D9DDFB4C1E2F7A344745A91533",
    ),
    "rtl/yunit/yunit_mem.sv": (
        "990b2856e79255467bb8236ee73872bb6d4473a3",
        "93D1B073FC9F0FF0DDC32C817FF7583D2B1772DC7D5F3E42373D29577EF68761",
    ),
    "rtl/yunit/yunit_dma.sv": (
        "4a5c9b50f545cebe7c559151661cfcc50fa6d0a8",
        "E6F59573C46EBDC5EC9C5AFB767930DCD9BD4C30BCB40C9A612D47134D115446",
    ),
    "rtl/yunit/yunit_video_top.sv": (
        "a057aa38d17a5f73d62db05c6caae946ed082dfb",
        "D190302EA70DD0F669B087CD140F462AC227300B9A8EBB7FBD022794EC7343BA",
    ),
    "rtl/yunit/yunit_video.sv": (
        "115648707f3f691bc268d211e150ef16c1ba576f",
        "C985F590363C25D1FEF4990290ACA62BB8F0C47B5A48419FF4C4FADC7BC7A867",
    ),
    "rtl/yunit/yunit_scanline.sv": (
        "9579eea9b626292c76b44730dd8b6e7a73cfa250",
        "991FF3A9F9B966C5D5F0A5B05DDDCFF356CA5070574C1A2C4A4567C07BABA994",
    ),
    "rtl/sdram/yunit_src_cache.sv": (
        "0d0db13fe728566912c2ce4d4aaf69f9c3fcccf6",
        "59DF2F9420B5787582285FF3E751ABC2109E9E0BB377336552220E4C9F7B73C4",
    ),
    "rtl/sdram/stv_vram_ddr_top.sv": (
        "add0b76b19783dcfa50035b379ff5744aeda19e7",
        "2BAB259B4C2465D295A2048CE291511B342E2C309DA874ACE7B19B9138416F83",
    ),
}

# The recovery transfer intentionally reuses the later, corrected shared CPU.
# Pin every TMS34010 RTL blob that changed after fe7f246 so copying the old top
# cannot silently roll back reset, SUBB carry, wide I/O, decode-snapshot, or
# inclusive-sync fixes.
B2_TMS_BLOBS: dict[str, tuple[str, str]] = {
    "rtl/tms34010/rtl/core/tms34010_alu.sv": (
        "70e061cdd15942ec48e5e9a815622a847784c402",
        "107C5D1A8C876E5FB5361C51D1733C704684C7594C46BFF96BA91A45D573335A",
    ),
    "rtl/tms34010/rtl/core/tms34010_core.sv": (
        "b79cc1a0591d75dfa9934a8b8b8d7aac361df7ae",
        # P0037 (MOVE *Rs(SOff),*Rd+,F) adds a class here; the worktree sha moved
        # forward deliberately. The blob id still pins the B2 checkpoint, and the
        # token checks below prove BOTH the later TMS fixes and P0037 survive.
        #
        # baddda0 (2026-08-17) moved it again: the display-write tap now
        # forwards HEBLNK/HSBLNK (the runtime-width tracker's producer -- the
        # cabinet's persistent right-edge columns). Gate sim/probe/display-tap
        # (mutant-killed) + the HEBLNK token check below prove the fix is
        # present rather than merely that the hash changed.
        # P0038-W forwards mem_size into both CPU-side I/O shadow blocks so
        # their retiring-edge value matches the physical field write.
        # The timing refactor also routes registered field metadata from the
        # existing write boundary into the physical I/O register stage.
        "0409DE6523FD075CAE29EF36B26D2E21E3DDAE0DDEDEA113D1A62FAC15D5262F",
    ),
    "rtl/tms34010/rtl/core/tms34010_cycle_budget.sv": (
        "119b9d5e6bf28e7a3b706c7e0f427c4c97343d57",
        # INSTR_MOVE_OFF_NI had no entry, so the P0037 class fell through to
        # `default: cycles = 1, valid = 0` -- retiring in ONE architectural cycle
        # instead of FIVE and raising budget_invalid, i.e. the CPU running 5x
        # fast on that opcode. The worktree sha moved forward deliberately; the
        # blob id still pins the B2 checkpoint and the token check below proves
        # the entry is present rather than merely that the hash changed.
        "1CE9656D895E199A85E2B15DFC9F2883C8D301BB6600D7D0E8DD6AA9AFED22D6",
    ),
    "rtl/tms34010/rtl/core/tms34010_cycle_scheduler.sv": (
        "4b2d2ae72152bb71f40c6113263def6793587551",
        "E8A5B417D855A07C9EE07D116C41E2A5E48A2182F7274D6E96C32F4029D5C0A5",
    ),
    "rtl/tms34010/rtl/core/tms34010_divider.sv": (
        "64c2d7aadcaeaa7ea4c307ac4b98f598314a45db",
        "CDBEDB948F56D9D29C2FAD7508E6779294155C5E664B5FE62B72DA813DB389F4",
    ),
    "rtl/tms34010/rtl/core/tms34010_gfx_cycle_counter.sv": (
        "01f749a2e85d7c2064943756939eb12ca0a4a41f",
        "B6ACC127F2B0BD9E4DF0B9ECD7D682EE29F74B3DCC02D9BB420B88D5D74AE728",
    ),
    "rtl/tms34010/rtl/core/tms34010_pc.sv": (
        "5a720268539982ded9bc437fff07bca896c5b512",
        "0A3849A351BEFF654F90AD3640C3CD4623615B0DB217EFEE053F7B4263BBFA59",
    ),
    "rtl/tms34010/rtl/core/tms34010_regfile.sv": (
        "163f06daaa301e26edf86ef940e84509331bd506",
        "4B47E47C9C138EAA571B2E249F58976B67F05E518F611612F789EECBBBE14A69",
    ),
    "rtl/tms34010/rtl/core/tms34010_status_reg.sv": (
        "80cc67872fb0c3eb73b3798096ec22930d082bf6",
        "8FA133B391F5CF4AD6A5758872AF56FE0E083F32A2BE7C9E195F5976A256878D",
    ),
    "rtl/tms34010/rtl/io/tms34010_io_regs.sv": (
        "b850741ab532c36416a61ee9c43d26be9eb85175",
        # P0038-W merges non-straddling fields instead of replacing the whole
        # addressed I/O register. The shipping integration consumes registered
        # mask/data/index metadata; the aligned FS32 high-word path is retained.
        "990DC0C05C44E6F638A803CB8FB9347DAE4E3B8E0E0D6A623616C13E9AC4B3CF",
    ),
    "rtl/tms34010/rtl/io/tms34010_io_cpu_config.sv": (
        "d9bffc8c3e1e0d80ca8faaacf28f4ab7cd7c0159",
        "3A16F236A6B3DD2818D214DCD426D29B39D973280CF404D16D66CEE71C3153C0",
    ),
    "rtl/tms34010/rtl/io/tms34010_io_cpu_status.sv": (
        "2cee54df480f4b8fd5f2e16b86e0c9b018cff8a5",
        "A6EB1BBCF7FC9FA2316734CB5CCE9D784B40ADF5C122E2FD92E88BF9B340D7D6",
    ),
    "rtl/tms34010/rtl/io/tms34010_io_write_boundary.sv": (
        "cc0912312093676acafc6ad53ab7b10771f187dc",
        # Field position, low-word mask/data, and FS32 indices are captured on
        # the existing command boundary; no additional architectural cycle.
        # The 43-bit metadata bank is preserved against physical retiming and
        # carries exact mutation anchors for shift, mask, and FS32 span.
        "DBC24E9CE736DAC9B410597D74850C77228E0988EFC8E94A9FF0DB54DA5028DA",
    ),
    "rtl/tms34010/rtl/tms34010_pkg.sv": (
        "f884af313f30d4abdcd681bc87853e121a25f07f",
        # P0037 adds INSTR_MOVE_OFF_NI to instr_class_t (see core.sv note).
        # P0038-W adds the clamped one-register field-mask/merge helpers.
        "286381DC1D3FD2D05B35C022EF575F85D04ECB132E0884AAF336629D02866795",
    ),
    "rtl/tms34010/rtl/video/tms34010_video.sv": (
        "142694f37ab96dbd30546a4892a2f290c18a9f52",
        "874AECED97576E1D4EB39CF80EF5D8D0521FF59D3580C0A5DBDC0886EE3963BD",
    ),
    # The opcode decoder was never pinned -- an omission this audit inherited.
    # It is the file where a whole instruction family can silently disappear
    # (P0037 found 1024 encodings falling through to the illegal arm), so it is
    # pinned now. Its B2 blob id predates P0037; the worktree sha includes it.
    "rtl/tms34010/rtl/core/tms34010_decode.sv": (
        None,
        "0EDDC5DAEABA489F727075E496A45707D6F75513142B41EC5986357518B9FD2D",
    ),
}

GOLDEN_ARTIFACTS: dict[str, tuple[int, str]] = {
    "releases/Arcade-SmashTV_firefix_mixboot.rbf": (
        4_282_144,
        "245D722DE68A78C83FB2066DB5AFA7456ED24BD641F26D94C21CB4156C4BB15D",
    ),
    "releases/Smash T.V. (rev 8.00) [firefix mixboot].mra": (
        2_045,
        "DA150310CF4CB18966B204C53420EEE983FEBBEBD13C8415A24995B70846FE0D",
    ),
}

REFERENCE_HASHES: dict[str, str] = {
    "docs/mame-ref/midyunit.cpp": "06B4968A23802C33E442EFB697BDBA4995C5DAA80E92B372ECC90FB7C4EA445B",
    "docs/mame-ref/midyunit_m.cpp": "E9B2F993F2973D7A5255247A8D489761D3CBDF720BD01E101057B8DAFF206A42",
    "docs/mame-ref/midyunit_v.cpp": "FAA6E64485F1048E67332E3509D73F975CD2E22F1A6690D5394E0BEA07B668C2",
    "docs/mame-ref/tms34010.cpp": "46E476D88156BF810FDD73C03E77E12E87DD0B0AE585543C75808F5305957FB3",
}

ASSEMBLY_HASHES: dict[str, str] = {
    "MAIN.ASM": "4F1DA570F13BB5FC497DC4A957400693BB7554909C1D020DBA802AAF70B70645",
    "NDSP1.ASM": "C0141954139B808A9B57DCEDB2E8A8FD6B35E9F9CB262F34F49D1EFE3E805500",
    "SHOTS.ASM": "CBB5737A142781324173E74C621DCA4E105CA7430495366A885B615FA0313472",
    "LINK.EQU": "7B977412A65E865E3AB23268A507D0FDFAA741DD0ECED3EEC1030618F2FF460E",
}

LEGACY_PARTS: tuple[tuple[str, str, int], ...] = (
    ("la1_smash_tv_game_rom_u111.u111", "72f0ba84", 0x20000),
    ("la1_smash_tv_game_rom_u112.u112", "436f0283", 0x20000),
    ("la1_smash_tv_game_rom_u113.u113", "4a4b8110", 0x20000),
    ("la1_smash_tv_game_rom_u95.u95", "e864a44b", 0x20000),
    ("la1_smash_tv_game_rom_u96.u96", "15555ea7", 0x20000),
    ("la1_smash_tv_game_rom_u97.u97", "ccac9d9e", 0x20000),
    ("la1_smash_tv_game_rom_u106.u106", "5c718361", 0x20000),
    ("la1_smash_tv_game_rom_u107.u107", "0fba1e36", 0x20000),
    ("la1_smash_tv_game_rom_u108.u108", "cb0a092f", 0x20000),
    ("la8_smash_tv_game_rom_u105.u105", "48cd793f", 0x20000),
    ("la8_smash_tv_game_rom_u89.u89", "8e7fe463", 0x20000),
    ("sl2_smash_tv_sound_rom_u4.u4", "29d3f6c8", 0x10000),
    ("sl2_smash_tv_sound_rom_u19.u19", "ac5a402a", 0x10000),
    ("sl2_smash_tv_sound_rom_u20.u20", "875c66d9", 0x10000),
)

RECOVERY_TO_FE7: dict[str, str] = {
    "rtl/yunit/yunit_dma_smash_firefix.sv": "rtl/yunit/yunit_dma.sv",
    "rtl/yunit/yunit_video_smash_firefix.sv": "rtl/yunit/yunit_video.sv",
    "rtl/yunit/yunit_scanline_smash_firefix.sv": "rtl/yunit/yunit_scanline.sv",
    "rtl/yunit/yunit_video_top_smash_firefix.sv": "rtl/yunit/yunit_video_top.sv",
}


class Audit:
    def __init__(self, root: Path, verbose: bool = False) -> None:
        self.root = root.resolve()
        self.verbose = verbose
        self.failures: list[str] = []
        self.passes = 0

    def check(self, condition: bool, label: str, detail: str = "") -> None:
        if condition:
            self.passes += 1
            if self.verbose:
                print(f"PASS: {label}")
            return
        suffix = f": {detail}" if detail else ""
        self.failures.append(f"{label}{suffix}")
        print(f"FAIL: {label}{suffix}", file=sys.stderr)

    def path(self, rel: str) -> Path:
        return self.root / Path(rel)

    def bytes(self, rel: str) -> bytes:
        path = self.path(rel)
        try:
            return path.read_bytes()
        except OSError as exc:
            self.check(False, f"required file exists: {rel}", str(exc))
            return b""

    def text(self, rel: str) -> str:
        return self.bytes(rel).decode("utf-8", errors="replace")

    def git(self, *args: str, binary: bool = False) -> bytes | str:
        try:
            data = subprocess.check_output(
                ["git", *args], cwd=self.root, stderr=subprocess.STDOUT
            )
        except (OSError, subprocess.CalledProcessError) as exc:
            output = getattr(exc, "output", b"")
            msg = output.decode("utf-8", errors="replace").strip() or str(exc)
            self.check(False, f"git {' '.join(args)}", msg)
            return b"" if binary else ""
        return data if binary else data.decode("utf-8", errors="replace").strip()


def lf(data: bytes) -> bytes:
    return data.replace(b"\r\n", b"\n").replace(b"\r", b"\n")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def canonical_source(data: bytes) -> bytes:
    return lf(data).rstrip(b"\n") + b"\n"


def require_tokens(audit: Audit, label: str, text: str, tokens: list[str]) -> None:
    missing = [token for token in tokens if token not in text]
    audit.check(not missing, label, f"missing {missing!r}")


def require_regex(audit: Audit, label: str, text: str, pattern: str) -> None:
    audit.check(
        re.search(pattern, text, flags=re.MULTILINE | re.DOTALL) is not None,
        label,
        f"pattern {pattern!r}",
    )


def forbid_regex(audit: Audit, label: str, text: str, pattern: str) -> None:
    """Fail if the pattern IS present -- the inverse of require_regex."""
    audit.check(
        re.search(pattern, text, flags=re.MULTILINE | re.DOTALL) is None,
        label,
        f"forbidden pattern present: {pattern!r}",
    )


def strip_sv_comments_and_strings(text: str) -> str:
    """Remove SV comments/strings while preserving token boundaries/newlines."""
    out: list[str] = []
    i = 0
    state = "code"
    while i < len(text):
        c = text[i]
        n = text[i + 1] if i + 1 < len(text) else ""
        if state == "code":
            if c == "/" and n == "/":
                out.extend("  ")
                i += 2
                state = "line"
            elif c == "/" and n == "*":
                out.extend("  ")
                i += 2
                state = "block"
            elif c == '"':
                out.append(" ")
                i += 1
                state = "string"
            else:
                out.append(c)
                i += 1
        elif state == "line":
            if c == "\n":
                out.append("\n")
                state = "code"
            else:
                out.append(" ")
            i += 1
        elif state == "block":
            if c == "*" and n == "/":
                out.extend("  ")
                i += 2
                state = "code"
            else:
                out.append("\n" if c == "\n" else " ")
                i += 1
        else:
            if c == "\\" and i + 1 < len(text):
                out.extend("  ")
                i += 2
            elif c == '"':
                out.append(" ")
                i += 1
                state = "code"
            else:
                out.append("\n" if c == "\n" else " ")
                i += 1
    return "".join(out)


def canonical_sv_code(text: str) -> str:
    """Return SV code with comments removed and insignificant spacing folded."""
    out: list[str] = []
    i = 0
    state = "code"
    while i < len(text):
        c = text[i]
        n = text[i + 1] if i + 1 < len(text) else ""
        if state == "code":
            if c == "/" and n == "/":
                out.extend("  ")
                i += 2
                state = "line"
            elif c == "/" and n == "*":
                out.extend("  ")
                i += 2
                state = "block"
            else:
                out.append(c)
                i += 1
                if c == '"':
                    state = "string"
        elif state == "line":
            if c == "\n":
                out.append("\n")
                state = "code"
            else:
                out.append(" ")
            i += 1
        elif state == "block":
            if c == "*" and n == "/":
                out.extend("  ")
                i += 2
                state = "code"
            else:
                out.append("\n" if c == "\n" else " ")
                i += 1
        else:
            out.append(c)
            i += 1
            if c == "\\" and i < len(text):
                out.append(text[i])
                i += 1
            elif c == '"':
                state = "code"
    return re.sub(r"\s+", " ", "".join(out)).strip()


def module_definitions(root: Path) -> dict[str, tuple[str, str]]:
    definitions: dict[str, tuple[str, str]] = {}
    for path in root.joinpath("rtl").rglob("*.sv"):
        clean = strip_sv_comments_and_strings(
            path.read_text(encoding="utf-8", errors="replace")
        )
        cursor = 0
        while True:
            match = re.search(r"\bmodule\s+([A-Za-z_][A-Za-z0-9_]*)\b", clean[cursor:])
            if match is None:
                break
            start = cursor + match.end()
            name = match.group(1)
            end_match = re.search(r"\bendmodule\b", clean[start:])
            if end_match is None:
                break
            end = start + end_match.start()
            definitions[name] = (path.relative_to(root).as_posix(), clean[start:end])
            cursor = start + end_match.end()
    return definitions


def skip_space(text: str, pos: int) -> int:
    while pos < len(text) and text[pos].isspace():
        pos += 1
    return pos


def skip_balanced(text: str, pos: int) -> int | None:
    if pos >= len(text) or text[pos] != "(":
        return None
    depth = 0
    while pos < len(text):
        if text[pos] == "(":
            depth += 1
        elif text[pos] == ")":
            depth -= 1
            if depth == 0:
                return pos + 1
        pos += 1
    return None


def instantiated_modules(body: str, known: set[str]) -> set[str]:
    children: set[str] = set()
    for match in re.finditer(r"\b([A-Za-z_][A-Za-z0-9_]*)\b", body):
        child = match.group(1)
        if child not in known:
            continue
        pos = skip_space(body, match.end())
        if pos < len(body) and body[pos] == "#":
            pos = skip_space(body, pos + 1)
            next_pos = skip_balanced(body, pos)
            if next_pos is None:
                continue
            pos = skip_space(body, next_pos)
        instance = re.match(r"[A-Za-z_][A-Za-z0-9_$]*", body[pos:])
        if instance is None:
            continue
        pos = skip_space(body, pos + instance.end())
        if pos < len(body) and body[pos] == "(":
            children.add(child)
    return children


def reachable_hierarchy(
    definitions: dict[str, tuple[str, str]], top: str
) -> tuple[set[str], dict[str, set[str]]]:
    known = set(definitions)
    graph: dict[str, set[str]] = {}
    reached: set[str] = set()
    queue: deque[str] = deque([top])
    while queue:
        module = queue.popleft()
        if module in reached or module not in definitions:
            continue
        reached.add(module)
        children = instantiated_modules(definitions[module][1], known)
        graph[module] = children
        queue.extend(sorted(children - reached))
    return reached, graph


def audit_pins(audit: Audit) -> None:
    resolved = audit.git("rev-parse", f"{FE7_COMMIT}^{{commit}}")
    audit.check(resolved == FE7_COMMIT, "cabinet-good fe7 commit pin", str(resolved))
    for path, (expected_oid, expected_sha) in FE7_BLOBS.items():
        spec = f"{FE7_COMMIT}:{path}"
        oid = audit.git("rev-parse", spec)
        data = audit.git("show", spec, binary=True)
        audit.check(oid == expected_oid, f"fe7 blob id: {path}", str(oid))
        audit.check(
            sha256(data if isinstance(data, bytes) else b"") == expected_sha,
            f"fe7 blob sha256: {path}",
        )

    resolved = audit.git("rev-parse", f"{B2_TMS_BASELINE}^{{commit}}")
    audit.check(
        resolved == B2_TMS_BASELINE, "later TMS correctness baseline pin", str(resolved)
    )
    for path, (expected_oid, expected_sha) in B2_TMS_BLOBS.items():
        work = canonical_source(audit.bytes(path))
        if expected_oid is not None:
            oid = audit.git("rev-parse", f"{B2_TMS_BASELINE}:{path}")
            audit.check(
                oid == expected_oid, f"later TMS blob id: {path}", str(oid)
            )
        audit.check(sha256(work) == expected_sha, f"later TMS retained: {path}")

    budget = audit.text("rtl/tms34010/rtl/core/tms34010_cycle_budget.sv")
    require_tokens(
        audit,
        "MOVE_OFF_NI has a cycle budget (P0037 5x-fast fix retained)",
        budget,
        ["INSTR_MOVE_OFF_NI:    cycles = 16'd5;"],
    )

    core = audit.text("rtl/tms34010/rtl/core/tms34010_core.sv")
    require_tokens(
        audit,
        "later TMS core correctness boundaries remain present",
        core,
        [
            "decoded_instr_t decoded_live;",
            "(* preserve *) decoded_instr_t decoded;",
            "decoded <= decoded_live;",
            "logic [31:0]           io_wr_data;",
            "logic [5:0]            io_wr_size;",
            ".wdata    (mem_wdata)",
            ".size     (mem_size)",
            ".wr_size  (io_wr_size)",
            "LOAD-BEARING FALLTHROUGH",
            # baddda0: the display tap forwards the horizontal-blank pair; the
            # runtime-width tracker is dead without them (silent no-op class).
            "|| (io_wr_idx == IO_IDX_HEBLNK)",
            "|| (io_wr_idx == IO_IDX_HSBLNK)",
        ],
    )
    audit.check(
        core.count("if ((ce_cpu !== 1'b0) || rst)") >= 15,
        "later TMS reset is not swallowed by a low CPU enable",
    )

    io_regs = audit.text("rtl/tms34010/rtl/io/tms34010_io_regs.sv")
    io_boundary = audit.text("rtl/tms34010/rtl/io/tms34010_io_write_boundary.sv")
    io_config = audit.text("rtl/tms34010/rtl/io/tms34010_io_cpu_config.sv")
    io_status = audit.text("rtl/tms34010/rtl/io/tms34010_io_cpu_status.sv")
    pkg_p0038 = audit.text("rtl/tms34010/rtl/tms34010_pkg.sv")
    require_tokens(
        audit,
        "P0038-W subword I/O write merge is retained",
        pkg_p0038 + io_boundary + io_regs + io_config + io_status + core,
        [
            "function automatic logic [15:0] io_field_merge",
            "(* preserve *)\n  output logic [IO_REG_IDX_W-1:0]      wr_idx,",
            "(* preserve *)\n  output logic [IO_REG_IDX_W-1:0]      wr_idx_hi,",
            "(* preserve *)\n  output logic                         wr_span2,",
            "(* preserve *)\n  output logic [15:0]                  wr_low_mask,",
            "(* preserve *)\n  output logic [15:0]                  wr_low_data,",
            "wr_low_mask <= low_mask;",
            "wr_low_data <= low_data;",
            ".PREDECODED_WRITE(1'b1)",
            "((io_reg[wr_idx] & ~low_write_mask) | low_write_data)",
            "psize_merged   = io_field_merge(psize,   wdata, addr[3:0], size)",
            "intenb_merged  = io_field_merge(intenb,  wdata, addr[3:0], size)",
            ".size         (mem_size)",
        ],
    )

    # P0037: MOVE *Rs(SOffset),*Rd+,F. The entire 0xD000-0xD3FF family used to
    # fall through to the illegal arm in every fork of this decoder (reported
    # from the NARC cabinet, independently reproduced here by an exhaustive
    # 65,536-opcode sweep). Pin the behaviour, not just the file hash.
    decode = audit.text("rtl/tms34010/rtl/core/tms34010_decode.sv")
    pkg = audit.text("rtl/tms34010/rtl/tms34010_pkg.sv")
    require_tokens(
        audit,
        "P0037 MOVE *Rs(off),*Rd+ is decoded, not illegal",
        decode,
        [
            "MOVE_OFF_NI_TOP6    = 6'b110100",
            "decoded.iclass          = INSTR_MOVE_OFF_NI",
            "decoded.move_mode       = MV_ADDR_POSTINC",
        ],
    )
    require_tokens(
        audit, "P0037 instruction class exists", pkg, ["INSTR_MOVE_OFF_NI"]
    )
    require_tokens(
        audit,
        "P0037 writes the BARE destination and post-increments by FS",
        core,
        [
            "mem_addr   = rf_rs2_data;           // BARE Rd (no displacement)",
            "INSTR_MOVE_OFF_NI:      rf_wr_data = mv_ptr_new;",
        ],
    )

    for path, (expected_size, expected_sha) in GOLDEN_ARTIFACTS.items():
        data = audit.bytes(path)
        audit.check(len(data) == expected_size, f"golden artifact size: {path}")
        audit.check(sha256(data) == expected_sha, f"golden artifact sha256: {path}")


def audit_build_selection(audit: Audit) -> None:
    build = audit.text("quartus/build_hw.sh")
    wrapper = audit.text("Arcade-SmashTV.sv")
    sv2v = audit.text("quartus/build_sv2v.sh")

    require_tokens(
        audit,
        "production build defaults to the recovery macro and exact memory flavor",
        build,
        [
            'MACRO="${1:-YUNIT_SMASH_RECOVERY}"',
            f'EXPECTED_RECOVERY_OUTNAME="{RECOVERY_RBF_STEM}"',
            'OUTNAME="${2:-$EXPECTED_RECOVERY_OUTNAME}"',
            'SV2V_EXTRA="-DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE"',
            "ALLOW_EXPERIMENTAL_FAMILY_CORE",
            "ALLOW_UNPROVEN_SDRAM_VRAM",
        ],
    )
    vulnerable_guards = [
        '"$MACRO" != *"YUNIT_SMASH_RECOVERY"*',
        '"$SV2V_EXTRA" != *"-DUSE_DDR3_VRAM"*',
        '"$SV2V_EXTRA" != *"-DYUNIT_NO_COMMITGATE"*',
    ]
    present_vulnerable = [token for token in vulnerable_guards if token in build]
    audit.check(
        not present_vulnerable,
        "production guards use exact shell tokens, never substring matches",
        f"vulnerable guards {present_vulnerable!r}",
    )
    require_tokens(
        audit,
        "production guards use the exact whitespace-token helper",
        build,
        [
            'local haystack="$1" needle="$2"',
            'case " $haystack " in',
            '*" $needle "*) return 0 ;;',
            'has_token "$SV2V_EXTRA" "-DUSE_DDR3_VRAM"',
            'has_token "$SV2V_EXTRA" "-DYUNIT_NO_COMMITGATE"',
            'has_token "$MACRO" "YUNIT_SMASH_RECOVERY"',
        ],
    )
    require_tokens(
        audit,
        "recovery build rejects extra macro tokens and a mismatched output stem",
        build,
        [
            "for token in $MACRO; do",
            '[[ "$token" == "YUNIT_SMASH_RECOVERY" ]]',
            '[[ "$recovery_macro_count" == 1 ]]',
            '[[ "$OUTNAME" == "$EXPECTED_RECOVERY_OUTNAME" ]]',
        ],
    )
    audit_call = build.find(
        '"$PYTHON" tools/audit_smashtv_recovery_transfer.py'
    )
    audit_record = build.find(
        "--manifest \"$MANIFEST\" --label recovery_transfer_audit"
    )
    lock_claim = build.find('if ! mkdir "$LOCK_DIR"; then')
    audit.check(
        0 <= audit_call < audit_record < lock_claim,
        "recovery transfer audit runs and is manifested before the Quartus lock",
        (
            f"audit={audit_call}, record={audit_record}, "
            f"lock={lock_claim}"
        ),
    )
    # The full selector chain is pinned EXACTLY, family2 arm included: the
    # recovery macro may select only the frozen suffixed top, and no other
    # flavor may reach it.  (family2 is the PLAN-family2-rebase.md hierarchy.)
    require_regex(
        audit,
        "wrapper recovery branch selects only the suffixed top",
        wrapper,
        r"`elsif\s+YUNIT_SMASH_RECOVERY\s+"
        r"`define\s+CORE_TOP\s+yunit_top_smash_firefix\s+"
        r"`elsif\s+YUNIT_F2_DATAPATH\s+"
        r"`define\s+CORE_TOP\s+yunit_top_family2\s+"
        r"`else\s+"
        r"`define\s+CORE_TOP\s+yunit_top\s+"
        r"`endif",
    )
    # YUNIT_F2_DATAPATH is a DERIVED macro selecting the rebased family2
    # hierarchy. Exactly two flavors may derive it -- family2 (CVSD, 4MB) and
    # adpcm (MK/T2/Total Carnage, 8MB). Pinning the derivation stops a third
    # flavor from silently inheriting the family2 datapath.
    require_regex(
        audit,
        "YUNIT_FULL derives the family2 datapath macro",
        wrapper,
        r"`ifdef\s+YUNIT_FULL\s+`define\s+YUNIT_F2_DATAPATH\s+`endif",
    )
    require_regex(
        audit,
        "YUNIT_FAMILY2 derives the family2 datapath macro",
        wrapper,
        r"`ifdef\s+YUNIT_FAMILY2\s+`define\s+YUNIT_F2_DATAPATH\s+`endif",
    )
    # The all-title flavor must NOT inherit the legacy Smash-only controller ABI:
    # its MRAs use the six-button family layout (Start bit 10, Coin bit 11).
    forbid_regex(
        audit,
        "full flavor does not derive the legacy Smash ABI",
        wrapper,
        r"`ifdef\s+YUNIT_FULL\s+`define\s+YUNIT_LEGACY_SMASH_ABI",
    )
    # The recovery macro must derive the legacy-ABI macro, because the shared
    # emu plumbing (CONF_STR, params, legacy download, cabinet inputs) is now
    # keyed on YUNIT_LEGACY_SMASH_ABI.  Without this derivation the recovery
    # build would silently fall onto the family plumbing.
    require_regex(
        audit,
        "recovery macro derives the legacy Smash ABI selector",
        wrapper,
        r"`ifdef\s+YUNIT_SMASH_RECOVERY\s+"
        r"`define\s+YUNIT_LEGACY_SMASH_ABI\s+"
        r"`endif",
    )
    require_tokens(
        audit,
        "sv2v source set contains the complete isolated recovery hierarchy",
        sv2v,
        [
            "smashtv_cabinet_inputs.sv",
            "smashtv_legacy_download_mapper.sv",
            "yunit_mem_smash_firefix.sv",
            "yunit_dma_smash_firefix.sv",
            "yunit_memsys_smash_firefix.sv",
            "yunit_video_smash_firefix.sv",
            "yunit_scanline_smash_firefix.sv",
            "yunit_video_top_smash_firefix.sv",
            "yunit_top_smash_firefix.sv",
        ],
    )


def audit_legacy_rom_and_inputs(audit: Audit) -> None:
    mapper = audit.text("rtl/yunit/smashtv_legacy_download_mapper.sv")
    wrapper = audit.text("Arcade-SmashTV.sv")
    inputs = audit.text("rtl/yunit/smashtv_cabinet_inputs.sv")
    inputs_code = strip_sv_comments_and_strings(inputs)

    require_tokens(
        audit,
        "legacy single-index mapper freezes exact stream boundaries and bases",
        mapper,
        [
            "SCRATCH_WBASE = 25'h120000",
            "ROMW_BASE     = 25'h0c0000",
            "DL_ROM_BASE   = 25'h120000",
            "DL_ROMHI_BASE = 25'h140000",
            "DL_SND_BASE   = 25'h160000",
            "DL_END        = 25'h190000",
            "ioctl_index == 8'd0",
            "mapped_be   <= 2'b01",
            "mapped_be   <= 2'b10",
            "snd_addr <= ioctl_addr - DL_SND_BASE",
        ],
    )
    require_regex(
        audit,
        "recovery wrapper uses the legacy mapper and fixed physical map",
        wrapper,
        r"`else.*?"
        r"localparam\s+\[24:0\]\s+SCRATCH_WBASE\s*=\s*25'h120000.*?"
        r"ROMW_BASE_DL\s*=\s*25'h0c0000.*?"
        r"smashtv_legacy_download_mapper",
    )
    top_match = re.search(
        r"`CORE_TOP\s*#\s*\((.*?)\)\s*yunit_top",
        wrapper,
        flags=re.MULTILINE | re.DOTALL,
    )
    top_params = top_match.group(1) if top_match is not None else ""
    # Three parameter branches since family2 P1.2: recovery keeps the exact
    # cabinet-good map, family2 carries the family map on the rebased top, and
    # the old family branch is unchanged.  All three are pinned.
    branch_match = re.search(
        r"`ifdef\s+YUNIT_SMASH_RECOVERY(.*?)"
        r"`elsif\s+YUNIT_FAMILY2(.*?)"
        r"`else(.*?)`endif",
        top_params,
        flags=re.MULTILINE | re.DOTALL,
    )
    recovery_params = branch_match.group(1) if branch_match is not None else ""
    family2_params = branch_match.group(2) if branch_match is not None else ""
    family_params = branch_match.group(3) if branch_match is not None else ""
    audit.check(
        top_match is not None and branch_match is not None,
        "wrapper has isolated recovery and family top parameter branches",
    )
    require_tokens(
        audit,
        "recovery top parameters retain only the cabinet-good physical layout",
        recovery_params,
        [
            ".GFXW_BASE(25'h000000)",
            ".ROMW_BASE(25'h0c0000)",
            ".VRAMW_BASE(25'h0e0000)",
            ".GFX_BYTES(24'h180000)",
            ".SCRATCH_WBASE(25'h120000)",
        ],
    )
    audit.check(
        "ROM_WORDS" not in recovery_params
        and "ROM_WORD_OFFSET" not in recovery_params,
        "recovery wrapper cannot select a hybrid program-ROM layout",
    )
    require_tokens(
        audit,
        "family2 wrapper selects the coherent family physical map",
        family2_params,
        [
            ".SCRATCH_WBASE(25'h500000)",
            ".SOUNDW_BASE(25'h800000)",
            ".ROM_WORDS(32'h80000)",
            ".ROM_WORD_OFFSET(32'h00000)",
        ],
    )
    # GFX_BYTES is SCOPE-SIZED (0x400000 for the CVSD titles, 0x800000 once the
    # ADPCM trio lands in P2), so pinning the literal would just have to be
    # edited again. Pin the INVARIANT instead -- the one that actually keeps the
    # download mapper, the memory region math and the SDRAM arbiter describing
    # the same map: ROMW_BASE == GFXW_BASE + GFX_BYTES/2, and VRAM immediately
    # after the program window. That is what silently breaks if someone retunes
    # one number, and it is exactly the section-3 mixed-layout failure shape.
    f2_gfxw = re.search(r"\.GFXW_BASE\(25'h([0-9a-fA-F]+)\)", family2_params)
    f2_romw = re.search(r"\.ROMW_BASE\(25'h([0-9a-fA-F]+)\)", family2_params)
    f2_vramw = re.search(r"\.VRAMW_BASE\(25'h([0-9a-fA-F]+)\)", family2_params)
    f2_gfxb = re.search(r"\.GFX_BYTES\(24'h([0-9a-fA-F]+)\)", family2_params)
    f2_romwords = re.search(r"\.ROM_WORDS\(32'h([0-9a-fA-F]+)\)", family2_params)
    if not all((f2_gfxw, f2_romw, f2_vramw, f2_gfxb, f2_romwords)):
        audit.check(False, "family2 map parameters are all parseable")
    else:
        gfxw = int(f2_gfxw.group(1), 16)
        romw = int(f2_romw.group(1), 16)
        vramw = int(f2_vramw.group(1), 16)
        gfxb = int(f2_gfxb.group(1), 16)
        romwords = int(f2_romwords.group(1), 16)
        audit.check(
            romw == gfxw + gfxb // 2,
            "family2 ROMW_BASE == GFXW_BASE + GFX_BYTES/2",
            f"gfxw=0x{gfxw:x} gfx_bytes=0x{gfxb:x} romw=0x{romw:x}",
        )
        audit.check(
            vramw == romw + romwords,
            "family2 VRAMW_BASE == ROMW_BASE + ROM_WORDS",
            f"romw=0x{romw:x} rom_words=0x{romwords:x} vramw=0x{vramw:x}",
        )
        # The scope must still cover the titles the build ships: the largest
        # CVSD unpacked image is Super High Impact, 0x80000 plane-words x 8.
        audit.check(
            gfxb >= 0x400000,
            "family2 gfx region covers the largest in-scope CVSD image",
            f"gfx_bytes=0x{gfxb:x}",
        )
    audit.check(
        "25'h0c0000" not in family2_params and "25'h0e0000" not in family2_params,
        "family2 wrapper does not reuse the legacy Smash bases",
    )
    require_tokens(
        audit,
        "family wrapper retains its independent full program-ROM layout",
        family_params,
        [
            ".ROM_WORDS(32'h80000)",
            ".ROM_WORD_OFFSET(32'h00000)",
        ],
    )

    mra_rel = RECOVERY_MRA
    try:
        mra_root = ET.fromstring(audit.bytes(mra_rel))
    except ET.ParseError as exc:
        audit.check(False, "legacy recovery MRA parses as XML", str(exc))
        mra_root = ET.Element("invalid")
    roms = mra_root.findall("rom")
    audit.check(
        len(roms) == 1 and roms[0].get("index") == "0",
        "recovery MRA has exactly one index-0 ROM stream",
    )
    actual_parts = (
        [(p.get("name"), (p.get("crc") or "").lower()) for p in roms[0].findall("part")]
        if roms
        else []
    )
    expected_parts = [(name, crc) for name, crc, _ in LEGACY_PARTS]
    audit.check(
        actual_parts == expected_parts,
        "legacy MRA part order and CRC list are exact",
        f"actual count {len(actual_parts)}",
    )
    buttons = mra_root.find("buttons")
    audit.check(
        buttons is not None
        and buttons.get("default") == "Y,A,X,B,Start,Select"
        and buttons.get("names")
        == "Fire Up,Fire Down,Fire Left,Fire Right,Start,Coin",
        "golden button order is Y,A,X,B with U,D,L,R semantic order",
    )
    rbf = mra_root.findtext("rbf")
    audit.check(
        rbf == RECOVERY_RBF_STEM,
        "recovery MRA targets the dedicated production RBF stem",
        str(rbf),
    )

    offsets: list[int] = []
    cursor = 0
    for _, _, size in LEGACY_PARTS:
        offsets.append(cursor)
        cursor += size
    audit.check(
        offsets[9] == 0x120000
        and offsets[10] == 0x140000
        and offsets[11] == 0x160000
        and cursor == 0x190000,
        "part sizes derive exact 0x120000/0x140000/0x160000/0x190000 boundaries",
    )

    expected_input_map = {
        0: ("joy0", 3),
        1: ("joy0", 2),
        2: ("joy0", 1),
        3: ("joy0", 0),
        4: ("joy0", 4),
        5: ("joy0", 5),
        6: ("joy0", 6),
        7: ("joy0", 7),
        8: ("joy1", 3),
        9: ("joy1", 2),
        10: ("joy1", 1),
        11: ("joy1", 0),
        12: ("joy1", 4),
        13: ("joy1", 5),
        14: ("joy1", 6),
        15: ("joy1", 7),
    }
    for bit, (joy, joy_bit) in expected_input_map.items():
        require_regex(
            audit,
            f"direct IN0 bit {bit} maps to {joy}[{joy_bit}]",
            inputs_code,
            rf"in0\s*\[\s*{bit}\s*\]\s*=\s*~\s*{joy}\s*\[\s*{joy_bit}\s*\]\s*;",
        )
    for in1_bit, joy, joy_bit in (
        (0, "joy0", 9),
        (1, "joy1", 9),
        (2, "joy0", 8),
        (5, "joy1", 8),
    ):
        require_regex(
            audit,
            f"direct IN1 bit {in1_bit} maps to {joy}[{joy_bit}]",
            inputs_code,
            rf"in1\s*\[\s*{in1_bit}\s*\]\s*=\s*~\s*{joy}\s*\[\s*{joy_bit}\s*\]\s*;",
        )
    require_tokens(
        audit,
        "cabinet input mapper forces unsupported rotary mode off",
        inputs_code,
        ["dsw = dsw_raw | 16'h4000", "inputs = {dsw, 16'hffff, in1, in0}"],
    )
    audit.check(
        "analog" not in inputs_code.lower(),
        "recovery input datapath has no analog-fire dependency",
    )
    # Since family2 P1.3 the mapper split lives on the multi-stream side
    # (family2 clone vs family mapper); the legacy-ABI `else` leg is recovery
    # only and must still reach the frozen smashtv_cabinet_inputs directly.
    require_regex(
        audit,
        "recovery wrapper bypasses the family mapper for direct cabinet inputs",
        wrapper,
        r"`ifndef\s+YUNIT_LEGACY_SMASH_ABI.*?"
        r"`ifdef\s+YUNIT_F2_DATAPATH.*?"
        r"family2_cabinet_inputs.*?"
        r"`else.*?"
        r"yunit_input_mapper.*?"
        r"`endif.*?"
        r"`else.*?"
        r"smashtv_cabinet_inputs",
    )


def audit_recovery_rtl(audit: Audit) -> None:
    # These four behavior-heavy recovery modules must remain a mechanical
    # suffix copy of the cabinet-good blobs.  Interface adapters live above
    # them and are audited semantically below.
    for recovery, old in RECOVERY_TO_FE7.items():
        current = canonical_source(audit.bytes(recovery)).replace(
            b"_smash_firefix", b""
        )
        old_data = audit.git("show", f"{FE7_COMMIT}:{old}", binary=True)
        expected = canonical_source(old_data if isinstance(old_data, bytes) else b"")
        audit.check(
            current == expected,
            f"recovery module is exact fe7 logic plus suffix: {recovery}",
        )

    mem_rel = "rtl/yunit/yunit_mem_smash_firefix.sv"
    mem_now = audit.text(mem_rel)
    mem_old_data = audit.git(
        "show", f"{FE7_COMMIT}:rtl/yunit/yunit_mem.sv", binary=True
    )
    mem_old = (
        mem_old_data.decode("utf-8", errors="replace")
        if isinstance(mem_old_data, bytes)
        else ""
    )
    cmos_decl = r"(parameter\s+int\s+CMOS_WORDS\s*=\s*)32'h8000"
    audit.check(
        len(re.findall(cmos_decl, mem_old)) == 1,
        "fe7 memory contains one auditable CMOS depth declaration",
    )
    mem_expected = re.sub(cmos_decl, r"\g<1>32'h4000", mem_old, count=1)
    mem_now_code = canonical_sv_code(mem_now).replace("_smash_firefix", "")
    mem_expected_code = canonical_sv_code(mem_expected)
    audit.check(
        mem_now_code == mem_expected_code,
        "recovery memory is exact fe7 code with CMOS_WORDS 0x4000 as its sole deviation",
    )

    cache_now = canonical_source(audit.bytes("rtl/sdram/yunit_src_cache.sv"))
    cache_old = audit.git(
        "show", f"{FE7_COMMIT}:rtl/sdram/yunit_src_cache.sv", binary=True
    )
    audit.check(
        cache_now
        == canonical_source(cache_old if isinstance(cache_old, bytes) else b""),
        "shipping source cache is byte-exact fe7 logic",
    )

    top = audit.text("rtl/yunit/yunit_top_smash_firefix.sv")
    memsys = audit.text("rtl/yunit/yunit_memsys_smash_firefix.sv")
    mem = audit.text("rtl/yunit/yunit_mem_smash_firefix.sv")
    dma = audit.text("rtl/yunit/yunit_dma_smash_firefix.sv")
    scanline = audit.text("rtl/yunit/yunit_scanline_smash_firefix.sv")
    recovery_rom_tb = audit.text("sim/tb_yunit_smash_firefix_rom_layout.sv")
    sim_runner = audit.text("sim/run.sh")

    audit.check(
        "ROM_WORD_OFFSET" not in top
        and "ROM_WORD_OFFSET" not in memsys
        and "ROM_WORD_OFFSET" not in mem,
        "recovery hierarchy has no configurable program-ROM offset",
    )
    audit.check(
        "ROM_WORDS" not in top and "ROM_WORDS" not in memsys,
        "recovery hierarchy inherits fe7's 0x20000 program depth at the memory block",
    )
    require_tokens(
        audit,
        "recovery ROM boundary regression freezes the compact fe7 mapping",
        recovery_rom_tb,
        [
            ".ROM_WORDS(32'h20000)",
            "rel - 28'h60000",
            'check_word(28\'h60000, "Smash live ROM base")',
            'check_word(28\'h7fffe, "Smash reset vector")',
        ],
    )
    audit.check(
        "ROM_WORD_OFFSET" not in recovery_rom_tb
        and "padded-window base" not in recovery_rom_tb,
        "recovery ROM regression cannot exercise the removed full-window hybrid",
    )
    require_tokens(
        audit,
        "focused recovery ROM regression is runnable under the offline simulator",
        sim_runner,
        [
            "tb_yunit_smash_firefix_rom_layout)",
            '"$ROOT/rtl/yunit/yunit_mem_smash_firefix.sv"',
        ],
    )

    require_tokens(
        audit,
        "recovery core uses the proven /4 cadence",
        top,
        [
            "3'd0: cpu_ce_div = 5'd4",
            "wire cpu_ce = (ce_div == 5'd0)",
            ".clk_cpu(clk), .ce_cpu(cpu_ce)",
        ],
    )
    require_tokens(
        audit,
        "recovery memsys connects the old direct DMA",
        memsys,
        ["yunit_dma_smash_firefix u_dma", ".fb_ack(dma_fb_ack)"],
    )
    require_tokens(
        audit,
        "old DMA completion and stop behavior remain selected",
        dma,
        [
            "`ifdef YUNIT_NO_COMMITGATE",
            "wire dma_done_ok = (pace_cnt == 26'd0);",
            "S_DONE:  if (dma_done_ok) state_n = S_IDLE;",
        ],
    )
    require_tokens(
        audit,
        "recovery scanout is the old static two-buffer design",
        scanline,
        [
            "logic [15:0] lb0 [0:511]",
            "logic [15:0] lb1 [0:511]",
            "logic loading, tgt_sel",
            "logic disp_sel",
        ],
    )
    require_tokens(
        audit,
        "recovery source path directly uses the old cache and SDRAM burst port",
        top,
        [
            "yunit_src_cache #(.GFXW_BASE(GFXW_BASE[23:0])) u_srccache",
            ".src_req(src_req), .src_addr(src_addr), .src_data(src_data), .src_ack(src_ack)",
            ".brd_req(brd_req), .brd_addr(brd_addr), .brd_len(brd_len)",
        ],
    )
    require_tokens(
        audit,
        "recovery framebuffer is the DDR3 backend",
        mem,
        [
            "`ifdef USE_DDR3_VRAM",
            "stv_vram_ddr_top #(.VRAMW(VRAM_WORDS), .VRAM_DDR_BASE(29'h6400000))",
            ".ddram_addr(ddram_addr)",
            ".scan_req(scan_req)",
        ],
    )
    require_tokens(
        audit,
        "recovery top retains the later shared TMS core",
        top,
        [
            "tms34010_core u_core",
            ".instruction_start_o()",
            ".display_wr_valid_o()",
            ".shiftreg_req_o()",
        ],
    )
    audit.check(
        "srt_legacy_passthrough" not in top
        and "srt_legacy_passthrough" not in audit.text(
            "rtl/tms34010/rtl/core/tms34010_core.sv"
        ),
        "recovery does not modify the shared TMS with an SRT compatibility port",
    )
    require_regex(
        audit,
        "recovery leaves all SRT observation sidebands open",
        top,
        r"\.shiftreg_req_o\(\)\s*,\s*"
        r"\.shiftreg_write_o\(\)\s*,\s*"
        r"\.shiftreg_bit_addr_o\(\)",
    )
    require_regex(
        audit,
        "recovery routes the TMS ordinary request/data/ack path directly",
        top,
        r"tms34010_core\s+u_core\s*\(.*?"
        r"\.mem_req\(cpu_req\).*?"
        r"\.mem_rdata\(cpu_rdata\)\s*,\s*\.mem_ack\(cpu_ack\).*?"
        r"yunit_mem_cdc.*?"
        r"\.c_req\(cpu_req\)\s*,\s*\.c_we\(cpu_we\).*?"
        r"\.c_ack\(cpu_ack\)\s*,\s*\.c_rdata\(cpu_rdata\)",
    )
    audit.check(
        "cpu_shiftreg" not in top,
        "recovery has no family shift-register diversion between TMS and memcdc",
    )

    definitions = module_definitions(audit.root)
    reached, graph = reachable_hierarchy(definitions, "yunit_top_smash_firefix")
    required = {
        "yunit_top_smash_firefix",
        "yunit_memsys_smash_firefix",
        "yunit_mem_smash_firefix",
        "yunit_dma_smash_firefix",
        "yunit_video_top_smash_firefix",
        "yunit_video_smash_firefix",
        "yunit_scanline_smash_firefix",
        "yunit_src_cache",
        "stv_vram_ddr_top",
        "tms34010_core",
    }
    audit.check(
        required <= reached,
        "recovery hierarchy reaches every required legacy block",
        f"missing {sorted(required - reached)}",
    )
    forbidden = {
        "yunit_cpu_cadence",
        "yunit_dma_logical_timer",
        "yunit_dma_descriptor_fifo",
        "yunit_display_address_sequencer",
        "yunit_shiftreg_engine",
    }
    audit.check(
        not (forbidden & reached),
        "experimental scheduler/timer/FIFO/dynamic-display/shift-engine are unreachable",
        f"reached {sorted(forbidden & reached)}",
    )
    reachable_text = "\n".join(
        definitions[name][1] for name in sorted(reached) if name in definitions
    )
    audit.check(
        "use_dynamic_display" not in reachable_text,
        "no dynamic-display selector is reachable from the recovery top",
    )
    if audit.verbose:
        print("Recovery hierarchy:")
        for parent in sorted(graph):
            print(f"  {parent}: {', '.join(sorted(graph[parent]))}")


def extract_block(text: str, start: str, end_pattern: str) -> str:
    start_pos = text.find(start)
    if start_pos < 0:
        return ""
    match = re.search(end_pattern, text[start_pos:], flags=re.MULTILINE)
    if match is None:
        return ""
    return text[start_pos : start_pos + match.end()]


def audit_gospels(audit: Audit) -> None:
    for path, expected_sha in REFERENCE_HASHES.items():
        audit.check(
            sha256(canonical_source(audit.bytes(path))) == expected_sha,
            f"pinned MAME mirror retained: {path}",
        )

    mame_v = audit.text("docs/mame-ref/midyunit_v.cpp")
    mame_m = audit.text("docs/mame-ref/midyunit_m.cpp")
    mame_driver = audit.text("docs/mame-ref/midyunit.cpp")
    mame_tms = audit.text("docs/mame-ref/tms34010.cpp")
    recovery_mem = audit.text("rtl/yunit/yunit_mem_smash_firefix.sv")
    cmos_test = audit.text("tools/tests/test_smash_firefix_cmos_contract.py")

    require_tokens(
        audit,
        "recovery CMOS implementation is exactly four 0x1000-word pages",
        recovery_mem,
        [
            "parameter int CMOS_WORDS = 32'h4000",
            "logic  [1:0] cmos_page",
            "nvram[{cmos_page, rel[11:0]}]",
            "hidx[j]={4'd0, cmos_page, hr[11:0]}",
        ],
    )
    require_regex(
        audit,
        "MAME CONTROL bits 7:6 select one of four 0x1000-word CMOS pages",
        mame_v,
        r"m_cmos_page\s*=\s*BIT\(data,\s*6,\s*2\)\s*\*\s*0x1000\s*;",
    )
    require_regex(
        audit,
        "MAME allocates exactly 0x4000 16-bit CMOS words",
        mame_m,
        r"m_cmos_ram\s*=\s*std::make_unique<uint16_t\[\]>\s*"
        r"\(\s*\(0x2000\s*\*\s*4\)\s*/\s*2\s*\)\s*;.*?"
        r"m_nvram->set_base\s*\(\s*m_cmos_ram\.get\(\),\s*"
        r"0x2000\s*\*\s*4\s*\)\s*;",
    )
    require_regex(
        audit,
        "MAME CMOS reads and writes index offset plus selected page",
        mame_m,
        r"COMBINE_DATA\(&m_cmos_ram\[offset\s*\+\s*m_cmos_page\]\);.*?"
        r"return\s+m_cmos_ram\[offset\s*\+\s*m_cmos_page\];",
    )
    require_regex(
        audit,
        "MAME maps the 0x10000-bit CMOS CPU window",
        mame_driver,
        r"map\(0x01400000,\s*0x0140ffff\)\.rw",
    )
    cmos_words = (0x2000 * 4) // 2
    largest_index = max(
        (page << 12) | offset
        for page in range(4)
        for offset in range(0x1000)
    )
    audit.check(
        cmos_words == 0x4000
        and largest_index == 0x3FFF
        and largest_index < cmos_words,
        "MAME byte allocation and page-index cross-product prove 0x4000 words",
        f"words=0x{cmos_words:x}, max_index=0x{largest_index:x}",
    )
    logical_bits = cmos_words * 16
    bit_equivalent_m10ks = logical_bits / 10_240
    tdp_geometry_blocks = (cmos_words + 511) // 512
    old_tdp_geometry_blocks = ((2 * cmos_words) + 511) // 512
    audit.check(
        logical_bits == 262_144
        and bit_equivalent_m10ks == 25.6
        and tdp_geometry_blocks == 32
        and old_tdp_geometry_blocks == 64,
        "CMOS resource math distinguishes bit-equivalent minimum from 16-bit TDP geometry",
        (
            f"bits={logical_bits}, bit_equivalent={bit_equivalent_m10ks}, "
            f"geometry={tdp_geometry_blocks}, old_geometry={old_tdp_geometry_blocks}"
        ),
    )
    require_tokens(
        audit,
        "focused CMOS contract test independently freezes the same bound",
        cmos_test,
        [
            "CMOS_WORDS\\s*=\\s*32'h4000",
            'self.assertIn("nvram[{cmos_page, rel[11:0]}]", text)',
            'self.assertIn("hidx[j]={4\'d0, cmos_page, hr[11:0]}", text)',
            "self.assertEqual(largest_index, 0x3FFF)",
            "self.assertLess(largest_index, 0x4000)",
        ],
    )

    require_regex(
        audit,
        "MAME draws DMA pixels synchronously before scheduling completion",
        mame_v,
        r"dma_draw\(command\);.*?"
        r"m_dma_timer->adjust\(attotime::from_nsec"
        r"\(41 \* m_dma_state\.width \* m_dma_state\.height\)\);",
    )
    require_regex(
        audit,
        "MAME DMA callback clears busy then asserts X1/LINT1",
        mame_v,
        r"TIMER_CALLBACK_MEMBER\(midyunit_base_state::dma_callback\).*?"
        r"m_dma_register\[DMA_COMMAND\]\s*&=\s*~0x8000;.*?"
        r"m_maincpu->set_input_line\(0,\s*ASSERT_LINE\);",
    )
    require_regex(
        audit,
        "MAME COMMAND write clears X1 before accepting a new trigger",
        mame_v,
        r"int const command = m_dma_register\[DMA_COMMAND\];.*?"
        r"m_maincpu->set_input_line\(0,\s*CLEAR_LINE\);.*?"
        r"if \(!\(command & 0x8000\)\)",
    )
    require_regex(
        audit,
        "MAME selects the shift-register pixel-read callback when DPYCTL.SRT is set",
        mame_tms,
        r"if\s*\(IOREG\(REG_DPYCTL\)\s*&\s*0x0800\).*?"
        r"m_pixel_read\s*=\s*&tms340x0_device::read_pixel_shiftreg",
    )
    require_regex(
        audit,
        "MAME SRT pixel read invokes the board callback and returns shift word zero",
        mame_tms,
        r"read_pixel_shiftreg\(offs_t offset\).*?"
        r"m_to_shiftreg_cb\(offset,\s*&m_shiftreg\[0\]\);.*?"
        r"return\s+m_shiftreg\[0\];",
    )
    require_regex(
        audit,
        "MAME Y-unit SRT callback bulk-loads the internal shift register from VRAM",
        mame_v,
        r"TMS340X0_TO_SHIFTREG_CB_MEMBER\(midyunit_base_state::to_shiftreg\).*?"
        r"memcpy\(shiftreg,\s*&m_local_videoram\[address\s*>>\s*3\],\s*"
        r"2\s*\*\s*512\s*\*\s*sizeof\(uint16_t\)\);",
    )
    require_regex(
        audit,
        "MAME identifies Smash as 6bpp small-CVSD with no main protection",
        mame_m,
        r"void midyunit_cvsd_state::init_smashtv\(\).*?"
        r"init_generic\(6,\s*SOUND_CVSD_SMALL,\s*0x9cf6,\s*0x9d21\);.*?"
        r"m_prot_data\s*=\s*nullptr;",
    )
    require_regex(
        audit,
        "MAME CVSD write uses reset bit 8 and command/talkback bit 9",
        mame_m,
        r"void midyunit_cvsd_state::cvsd_sound_w.*?"
        r"m_cvsd_sound->reset_write\(BIT\(~data,\s*8\)\);.*?"
        r"m_cvsd_sound->write\(\(data & 0xff\) \| \(\(data & 0x200\) >> 1\)\);",
    )

    smashtv_rom = extract_block(
        mame_driver, "ROM_START( smashtv )", r"^ROM_END\s*$"
    )
    audit.check(bool(smashtv_rom), "MAME Smash ROM block is present")
    for name, _, size in LEGACY_PARTS:
        require_regex(
            audit,
            f"MAME ROM size agrees for {name}",
            smashtv_rom,
            rf'"{re.escape(name)}".*?0x{size:x}',
        )
    smashtv_inputs = extract_block(
        mame_driver, "static INPUT_PORTS_START( smashtv )", r"^INPUT_PORTS_END\s*$"
    )
    for mask, semantic in (
        ("0x0010", "P1 Fire Up"),
        ("0x0020", "P1 Fire Down"),
        ("0x0040", "P1 Fire Left"),
        ("0x0080", "P1 Fire Right"),
        ("0x1000", "P2 Fire Up"),
        ("0x2000", "P2 Fire Down"),
        ("0x4000", "P2 Fire Left"),
        ("0x8000", "P2 Fire Right"),
    ):
        require_regex(
            audit,
            f"MAME input mask {mask} is {semantic}",
            smashtv_inputs,
            rf"{mask}.*?PORT_NAME\(\"{re.escape(semantic)}\"\)",
        )

    asm_root = audit.root.parent / "smashtv-src"
    for name, expected_sha in ASSEMBLY_HASHES.items():
        path = asm_root / name
        try:
            data = lf(path.read_bytes())
        except OSError as exc:
            audit.check(False, f"Smash assembly source exists: {name}", str(exc))
            data = b""
        audit.check(
            sha256(data) == expected_sha,
            f"pinned Smash assembly retained: {name}",
        )

    def asm_text(name: str) -> str:
        try:
            return (asm_root / name).read_text(
                encoding="latin-1", errors="replace"
            )
        except OSError:
            return ""

    main_asm = asm_text("MAIN.ASM")
    ndsp = asm_text("NDSP1.ASM")
    shots = asm_text("SHOTS.ASM")
    link = asm_text("LINK.EQU")
    main_live = "\n".join(
        raw.split(";", 1)[0].strip()
        for raw in main_asm.splitlines()
        if raw.strip() and not raw.lstrip().startswith("*")
    )
    require_regex(
        audit,
        "Smash end-of-screen IRQ has one bounded SRT PIXT-load window",
        main_live,
        r"MOVE\s+@DPYCTL,A0,W\s*"
        r"ORI\s+SRT,A0\s*"
        r"MOVE\s+A0,@DPYCTL,W\s*"
        r"MOVI\s+400\*1000H,A1\s*"
        r"PIXT\s+\*A1,A2\s*"
        r"ANDNI\s+SRT,A0\s*"
        r"MOVE\s+A0,@DPYCTL,W",
    )

    live_srt: list[tuple[str, str]] = []
    try:
        asm_files = sorted(asm_root.glob("*.ASM"))
    except OSError as exc:
        audit.check(False, "enumerate live Smash assembly", str(exc))
        asm_files = []
    for path in asm_files:
        try:
            lines = path.read_text(encoding="latin-1", errors="replace").splitlines()
        except OSError as exc:
            audit.check(False, f"read Smash assembly for SRT census: {path.name}", str(exc))
            continue
        for raw in lines:
            stripped = raw.lstrip()
            if not stripped or stripped.startswith("*"):
                continue
            code = raw.split(";", 1)[0].strip()
            if re.search(r"\bSRT\b", code, flags=re.IGNORECASE):
                live_srt.append((path.name, re.sub(r"\s+", " ", code).upper()))
    audit.check(
        live_srt
        == [
            ("MAIN.ASM", "ORI SRT,A0"),
            ("MAIN.ASM", "ANDNI SRT,A0"),
        ],
        "Smash assembly has no live SRT use outside the single MAIN load window",
        repr(live_srt),
    )

    require_regex(
        audit,
        "NDSP1 X1 ISR retires one queue entry and launches only its successor",
        ndsp,
        r"DMAINT:.*?DEC\s+B13.*?JRNZ\s+DMAINTX.*?"
        r"DMAINT1:.*?CALLR\s+DMANUQ.*?RETI",
    )
    require_regex(
        audit,
        "NDSP1 DMASTRT refuses restart while hardware busy",
        ndsp,
        r"DMASTRT:.*?MOVE\s+@DMACTRL,A0,W.*?JRN\s+DMASTRTX",
    )
    require_tokens(
        audit,
        "NDSP1 explicitly enables the X1 DMA interrupt",
        ndsp,
        ["ORI\tX1E,A0", "MOVE\tA0,@INTENB,W"],
    )
    require_regex(
        audit,
        "SHOTS records four-way fire direction in B_DIR",
        shots,
        r"\.BSS\s+B_DIR,16.*?FIRE_DIRECTION:.*?MOVE\s+A6,@B_DIR",
    )
    require_regex(
        audit,
        "SHOTS normal fire emits the SHOT CVSD command",
        shots,
        r"MOVI\s+SHOT,A0.*?CALLA\s+ONESND",
    )
    require_regex(
        audit,
        "LINK.EQU pins sound-board talkback address",
        link,
        r"^SND_TALK\s+EQU\s+1C00020H\b",
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root",
        type=Path,
        default=Path(__file__).resolve().parents[1],
        help="repository root (defaults to this script's parent repository)",
    )
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args()

    audit = Audit(args.root, verbose=args.verbose)
    print(f"Smash recovery transfer audit: {audit.root}")
    print(f"  cabinet-good source: {FE7_COMMIT}")
    print(f"  later TMS baseline:  {B2_TMS_BASELINE}")

    audit_pins(audit)
    audit_build_selection(audit)
    audit_legacy_rom_and_inputs(audit)
    audit_recovery_rtl(audit)
    audit_gospels(audit)

    if audit.failures:
        print(
            f"SMASH RECOVERY AUDIT FAIL: {len(audit.failures)} failure(s), "
            f"{audit.passes} checks passed",
            file=sys.stderr,
        )
        for failure in audit.failures:
            print(f"  - {failure}", file=sys.stderr)
        return 1

    print(f"SMASH RECOVERY AUDIT PASS: {audit.passes} fail-closed checks")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
