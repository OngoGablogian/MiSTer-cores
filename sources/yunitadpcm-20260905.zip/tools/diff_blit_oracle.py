#!/usr/bin/env python3
r"""PIXEL-BYTE diff. MAME exposes only one plane through the CPU window
(m_local_videoram is a unique_ptr, not a share), so the comparison is on the
pixel byte -- which is exactly the class a pen bit-order error lives in.

Diff the SV golden's blitter writes against MAME'S OWN vram deltas.

This is the only check in the tree that can catch a convention error shared by
the DUT, the SV golden and the lua capture -- all three of which are one
person's reading of midyunit_v.cpp. Gladiator's session proved the need: their
oracle and RTL agreed across 1.16 MILLION pixels through SIX mutation kills
while BOTH had the pen bit order reversed.

INPUTS
  mame-trace/blit_pix_oracle.txt   MAME's REAL vram deltas  "bidx addr val"
  sim/build/oracle_golden.txt      the SV golden's writes   "bidx addr val"
                                   (produced by tb_yunit_dma_matrix +ORACLE,
                                    fed the SAME source bytes MAME read)

WHAT IS JUDGEABLE, and what is not
  A golden write of a value already present produces NO MAME delta, so
  golden-only writes cannot be called wrong without the pre-state. Two things
  CAN be judged, and they are the ones that matter:
    1. COVERAGE  every MAME delta address must be written by the golden.
                 A missing one means the golden did not draw a pixel MAME drew.
    2. VALUE     at those addresses the golden's LAST write must equal MAME's
                 final value. A pen/palette/convention error shows up here.

  python tools/diff_blit_oracle.py
"""

import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MAME = ROOT.parent / "mame-trace" / "blit_pix_oracle.txt"
GOLD = ROOT / "sim" / "build" / "oracle_golden.txt"


def load(path):
    d = defaultdict(dict)          # bidx -> {addr: last value}
    with open(path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            p = line.split()
            if len(p) == 3:
                try:
                    d[int(p[0])][int(p[1], 16)] = int(p[2], 16)
                except ValueError:
                    pass
    return d


def main():
    for p in (MAME, GOLD):
        if not p.exists():
            print(f"MISSING: {p}")
            return 2
    mame, gold = load(MAME), load(GOLD)
    blits = sorted(set(mame) & set(gold))
    if not blits:
        print("FAIL: no overlapping blits -- vacuous comparison")
        return 2

    miss = valdiff = matched = 0
    shown = 0
    for b in blits:
        m, g = mame[b], gold[b]
        for addr, mval in m.items():
            if addr not in g:
                miss += 1
                if shown < 8:
                    print(f"  COVERAGE b{b}: MAME wrote {addr:X}={mval:04X}, "
                          f"golden never wrote it")
                    shown += 1
            elif (g[addr] & 0xFF) != (mval & 0xFF):
                valdiff += 1
                if shown < 8:
                    print(f"  VALUE    b{b}: addr {addr:X} "
                          f"golden_px={g[addr]&0xFF:02X} MAME_px={mval&0xFF:02X}")
                    shown += 1
            else:
                matched += 1

    total = matched + miss + valdiff
    print(f"\nblits compared     : {len(blits)}")
    print(f"MAME deltas checked : {total}")
    print(f"  matched exactly   : {matched}")
    print(f"  coverage misses   : {miss}")
    print(f"  value mismatches  : {valdiff}")

    if total == 0:
        print("\nFAIL: zero deltas compared -- vacuous")
        return 2
    if miss or valdiff:
        print("\nFAIL: the golden disagrees with MAME's own blitter output.")
        return 1
    print("\nPASS: every MAME vram delta is reproduced EXACTLY by the golden.")
    print("      The shared reading of dma_draw is validated against MAME's")
    print("      actual output, not against another transcription of it.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
