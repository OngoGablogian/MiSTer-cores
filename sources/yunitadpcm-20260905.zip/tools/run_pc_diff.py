#!/usr/bin/env python3
"""Per-instruction PC diff of the Y-unit core against a MAME golden.

WHY: "illegal=0, memreq==mem_ack, GAMELOOP reached" is a LIVENESS result. It
proves the CPU did not wedge and the memory handshake balanced. It does NOT
prove the executed instruction stream matches MAME. The NARC (Z-unit) session
made that objection; their RUNG-3 boff bug was a two-sided data divergence at
golden index 1,829,971 that any liveness gate sails past forever. This closes it.

GENERATING THE GOLDEN -- USE noloop, THIS IS NOT OPTIONAL:
    cd "D:/deck/fpga/smash tv/mame-trace"
    cat > dbg_bootnl.txt <<EOF
    trace stv_bootnl.log,maincpu,noloop
    go
    EOF
    mame.exe smashtv -rompath "D:/deck/fpga/smash tv/roms" -debug \
      -debugscript dbg_bootnl.txt -video none -sound none -nothrottle -seconds_to_run 2

WITHOUT `noloop` MAME COLLAPSES LOOPS as "(loops for N instructions)" and the
exact stream CANNOT be reconstructed. Two separate attempts to expand it here
produced FALSE DIVERGENCES: the naive model (repeat the last PC N times) is
correct only for a DSJS self-loop, and the refined model (infer the body from
the last repeat distance) still mis-modelled nested/multi-exit loops. Both
reported the RTL as wrong when it was right. Do not reconstruct -- regenerate.

GENERATING THE RTL SIDE:
    EXTRA_DEFINES="+define+PC_TRACE +define+ROM_UNPATCHED" ./sim/run_top.sh \
      tb_yunit_top_boot +MAXK=<n>
ROM_UNPATCHED matters: the default sim image is patched by make_ffwd_hex.py
(0xfff4ebf0 SETF -> EXGPC B5, skipping RAMCHECK), so it diverges from an
unpatched golden AT THAT ADDRESS BY CONSTRUCTION.

CALIBRATION (measured, not assumed): the bench logs pc_dbg on entry to
CORE_DECODE, at which point the core has already advanced PC past the opcode
word, and it emits one extra leading entry. So rtl[i+1] - 0x10 == golden[i].
Both constants are asserted below -- if the core's PC timing changes, this
fails loudly rather than silently mis-aligning.
"""

import sys
from pathlib import Path

SHIFT = 1        # RTL emits one extra leading entry
OFFSET = 0x10    # pc_dbg at DECODE is one instruction-word ahead of the opcode
MIN_MATCHED = 50_000  # measured floor for the release +MAXK=4000 trace


def load(p, mame):
    out = []
    for line in Path(p).read_text(encoding="utf-8", errors="replace").splitlines():
        s = line.strip()
        if not s:
            continue
        if mame:
            if len(s) > 8 and s[8] == ":" and all(c in "0123456789abcdefABCDEF" for c in s[:8]):
                out.append(int(s[:8], 16))
        else:
            out.append(int(s, 16))
    return out


def main() -> int:
    if len(sys.argv) < 3:
        print(__doc__)
        print("usage: run_pc_diff.py <mame_noloop.log> <rtl_bootpc.log>")
        return 2

    gold_p, rtl_p = sys.argv[1], sys.argv[2]
    raw = Path(gold_p).read_text(encoding="utf-8", errors="replace")
    if "loops for" in raw:
        print("FAIL: the golden contains collapsed loops ('loops for N instructions').")
        print("      Regenerate it with the `noloop` flag. Reconstruction is NOT reliable")
        print("      and has produced false divergences twice.")
        return 1

    g = load(gold_p, mame=True)
    r = load(rtl_p, mame=False)
    avail = len(r) - SHIFT
    if avail <= 0:
        print("FAIL: RTL trace too short")
        return 1

    n = 0
    lim = min(len(g), avail)
    for i in range(lim):
        if r[i + SHIFT] - OFFSET != g[i]:
            break
        n += 1

    print(f"golden instructions : {len(g)}")
    print(f"RTL instructions    : {avail}")
    print(f"MATCHED             : {n}")

    if n < lim:
        lo = max(0, n - 3)
        print(f"\nFIRST DIVERGENCE at index {n}")
        print("  golden :", " ".join(f"{x:08x}" for x in g[lo:n + 3]))
        print("  rtl-adj:", " ".join(f"{x - OFFSET:08x}" for x in r[lo + SHIFT:n + 3 + SHIFT]))
        print("\nBefore calling this an RTL bug, check the instrument:")
        print("  - is the golden `noloop`?")
        print("  - was the RTL built with +define+ROM_UNPATCHED?")
        print("  - does the divergence sit at 0xfff4ebf0 (the RAMCHECK patch point)?")
        return 1

    if n < MIN_MATCHED:
        print(
            f"\nFAIL: clean prefix is only {n} instructions; "
            f"release floor is {MIN_MATCHED}."
        )
        print("      The trace may have ended early before exercising the real RAMCHECK path.")
        return 1

    print(f"\nPASS: the RTL stream is a CLEAN PREFIX of the MAME golden "
          f"({n} instructions, no divergence).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
