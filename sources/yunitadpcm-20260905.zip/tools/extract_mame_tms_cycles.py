#!/usr/bin/env python3
"""Inventory TMS34010 opcode handlers and their MAME cycle expressions.

This is an audit aid, not a code generator.  It follows direct macro calls
from each opcode handler so that conditional/variable expressions remain
visible for manual RTL mapping instead of being flattened incorrectly.
"""

from __future__ import annotations

import argparse
import collections
import pathlib
import re


TABLE_MARKER = "const tms34010_device::opcode_func"
TABLE_END_MARKER = "const tms34020_device::opcode_func"
HANDLER_RE = re.compile(r"&tms34010_device::([A-Za-z0-9_]+)")
FUNCTION_RE = re.compile(
    r"void\s+(?:tms340x0_device|tms34010_device)::([A-Za-z0-9_]+)"
    r"\s*\([^)]*\)\s*\{"
)
COUNT_RE = re.compile(r"COUNT_(?:UNKNOWN_)?CYCLES\s*\(([^)]*)\)")
MACRO_CALL_RE = re.compile(r"\b([A-Z][A-Z0-9_]*)\s*\(")


def macro_bodies(text: str) -> dict[str, str]:
    lines = text.splitlines()
    result: dict[str, str] = {}
    index = 0
    while index < len(lines):
        match = re.match(r"\s*#define\s+([A-Z][A-Z0-9_]*)\b(.*)", lines[index])
        if not match:
            index += 1
            continue
        name = match.group(1)
        body_parts = [match.group(2).rstrip("\\").strip()]
        while lines[index].rstrip().endswith("\\") and index + 1 < len(lines):
            index += 1
            body_parts.append(lines[index].rstrip("\\").strip())
        result[name] = " ".join(body_parts)
        index += 1
    return result


def function_bodies(text: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for match in FUNCTION_RE.finditer(text):
        depth = 1
        cursor = match.end()
        while cursor < len(text) and depth:
            if text[cursor] == "{":
                depth += 1
            elif text[cursor] == "}":
                depth -= 1
            cursor += 1
        result[match.group(1)] = text[match.end() : cursor - 1]
    return result


def collect_counts(
    body: str, macros: dict[str, str], visited: frozenset[str] = frozenset()
) -> tuple[set[str], set[str]]:
    counts = {item.strip() for item in COUNT_RE.findall(body)}
    calls: set[str] = set()
    for name in MACRO_CALL_RE.findall(body):
        if name.startswith("COUNT_") or name in visited or name not in macros:
            continue
        calls.add(name)
        nested_counts, nested_calls = collect_counts(
            macros[name], macros, visited | {name}
        )
        counts.update(nested_counts)
        calls.update(nested_calls)
    return counts, calls


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("mame_root", type=pathlib.Path)
    parser.add_argument("--handler", help="show only one handler")
    args = parser.parse_args()

    cpu_root = args.mame_root / "src" / "devices" / "cpu" / "tms34010"
    ops_path = cpu_root / "34010ops.hxx"
    table_path = cpu_root / "34010tbl.hxx"
    ops = ops_path.read_text(encoding="utf-8")
    table = table_path.read_text(encoding="utf-8")

    table_34010 = table.split(TABLE_MARKER, 1)[1].split(TABLE_END_MARKER, 1)[0]
    handlers = HANDLER_RE.findall(table_34010)
    if len(handlers) != 4096:
        raise SystemExit(f"expected 4096 TMS34010 table entries, found {len(handlers)}")

    macros = macro_bodies(ops)
    functions = function_bodies(ops)
    usage = collections.Counter(handlers)
    unresolved = 0
    dynamic = 0

    for name in sorted(usage):
        if args.handler and name != args.handler:
            continue
        body = functions.get(name, "")
        counts, calls = collect_counts(body, macros)
        if not counts:
            unresolved += 1
        if len(counts) > 1 or any(not item.isdecimal() for item in counts):
            dynamic += 1
        count_text = ",".join(sorted(counts)) if counts else "UNRESOLVED"
        call_text = ",".join(sorted(calls)) if calls else "-"
        print(
            f"{name:<24} entries={usage[name]:4d} cycles={count_text:<18} "
            f"macros={call_text}"
        )

    if not args.handler:
        print(
            f"SUMMARY table_entries={len(handlers)} unique_handlers={len(usage)} "
            f"unresolved={unresolved} dynamic_or_expression={dynamic}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
