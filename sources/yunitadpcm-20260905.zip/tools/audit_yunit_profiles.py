#!/usr/bin/env python3
r"""Audit the Y-unit profile table against MAME's driver, for ALL ten profiles.

WHY THIS EXISTS
---------------
This is ONE core for the whole Y-unit family, but only Smash T.V. and Total
Carnage have original source, and only Smash T.V. has a per-instruction golden.
Every disposition reached by reading assembly is therefore scoped to two titles
of ten -- the other eight have been carried on inheritance from the donor, which
is exactly the DESIGN-RULES.md section 4 trap (a fork inherits the donor's SIZE
CONSTANTS and ENUM ORDER, and the classic bug is an inherited value nobody
re-derived).

MAME's driver settles all ten at once, because the machine-config NAME encodes
the three fields the profile table carries:

    yunit_cvsd_4bit_slow
          |    |    |
          |    |    +-- clock class   slow / fast / faster
          |    +------- pixel depth   4bit / 6bit
          +------------ sound board   cvsd / adpcm

and init_generic() carries the CVSD sub-type and the protection window:

    init_generic(bpp, SOUND_CVSD_SMALL, prot_start, prot_end)   cvsd small
    init_generic(bpp, SOUND_CVSD,       prot_start, prot_end)   cvsd large
    init_generic(bpp, prot_start, prot_end)                     adpcm

So the whole family is a text extraction rather than ten separate measurements.

WHAT IT COMPARES
    MAME driver  ->  expected {bpp, sound, clock} per title
    yunit_pkg.sv ->  yunit_is_4bpp / yunit_sound_type / yunit_clock_class
and FAILS on any disagreement.

VALIDATED: --self-test mutates the expected table and requires a mismatch, so a
clean run is not merely the parser finding nothing.

  python tools/audit_yunit_profiles.py
  python tools/audit_yunit_profiles.py --self-test
"""

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MAME = Path(r"D:/deck/fpga/smash tv/mame-yunit-audit/src/mame/williams/midyunit.cpp")
MAME_M = MAME.parent / "midyunit_m.cpp"
PKG = ROOT / "rtl" / "pkg" / "yunit_pkg.sv"

# The core's ten profiles -> the MAME driver set that represents each.
PROFILES = {
    "YG_SMASHTV":   "smashtv",
    "YG_TROG":      "trog",
    "YG_HIIMPACT":  "hiimpact",
    "YG_SHIMPACT":  "shimpact",
    "YG_STRKFORC":  "strkforc",
    "YG_MK":        "mkla4",       # shipping MK rev; mkprot4 is a prototype
    "YG_TERM2":     "term2",
    "YG_TOTCARN":   "totcarn",
    "YG_SAURNFRNT": "saurnfrnt",
    "YG_YUNITTST":  "yunittst",    # GAME entry uses init_shimpact
}

# MAME's house test ROM uses the deliberately unknown year token `199?`.
GAME_RE = re.compile(r"^GAME\(\s*[^,]+\s*,\s*(\w+)\s*,\s*\w+\s*,\s*(\w+)\s*,")


def mame_machines():
    txt = MAME.read_text(encoding="utf-8", errors="replace")
    out = {}
    for line in txt.splitlines():
        m = GAME_RE.match(line)
        if m:
            out[m.group(1)] = m.group(2)
    return out


def decode(machine):
    """machine-config name -> (bpp, sound, clock)."""
    if machine == "term2":
        # term2() is its own config; the driver builds it on the adpcm core at
        # the highest clock, and it is 6bpp (init_generic(6, ...) at :548).
        return (6, "ADPCM", "FASTER")
    bpp = 4 if "4bit" in machine else 6 if "6bit" in machine else None
    sound = "ADPCM" if "adpcm" in machine else "CVSD" if "cvsd" in machine else None
    if "faster" in machine:
        clock = "FASTER"
    elif "fast" in machine:
        clock = "FAST"
    elif "slow" in machine:
        clock = "SLOW"
    else:
        clock = None
    return (bpp, sound, clock)


def cvsd_subtype():
    """init_generic's SOUND_CVSD vs SOUND_CVSD_SMALL, per init_ function."""
    txt = MAME_M.read_text(encoding="utf-8", errors="replace")
    out = {}
    cur = None
    for line in txt.splitlines():
        f = re.match(r"\s*void\s+\w+::init_(\w+)\(\)", line)
        if f:
            cur = f.group(1)
        if cur and "init_generic(" in line:
            if "SOUND_CVSD_SMALL" in line:
                out[cur] = "CVSD_SMALL"
            elif "SOUND_CVSD" in line:
                out[cur] = "CVSD_LARGE"
            else:
                out[cur] = "ADPCM"
            cur = None
    return out


def pkg_tables():
    """Parse the three profile functions out of yunit_pkg.sv."""
    txt = PKG.read_text(encoding="utf-8", errors="replace")

    def body(name):
        m = re.search(r"function automatic .*?" + name + r"\b(.*?)endfunction",
                      txt, re.S)
        return m.group(1) if m else ""

    four = set(re.findall(r"YG_\w+", body("yunit_is_4bpp")))

    sb = body("yunit_sound_type")
    adpcm, large = set(), set()
    for chunk, tag in re.findall(r"(.*?)yunit_sound_type = (YS_\w+);", sb, re.S):
        names = set(re.findall(r"YG_\w+", chunk))
        if tag == "YS_ADPCM":
            adpcm |= names
        elif tag == "YS_CVSD_LARGE":
            large |= names - adpcm

    cb = body("yunit_clock_class")
    faster, fast = set(), set()
    for chunk, tag in re.findall(r"(.*?)yunit_clock_class = (YC_\w+);", cb, re.S):
        names = set(re.findall(r"YG_\w+", chunk))
        if tag == "YC_FASTER":
            faster |= names
        elif tag == "YC_FAST":
            fast |= names - faster
    return four, adpcm, large, faster, fast


def run(mutate=False):
    machines = mame_machines()
    subtype = cvsd_subtype()
    four, adpcm, large, faster, fast = pkg_tables()

    bad = 0
    print(f"{'profile':<13}{'driver':<11}{'MAME machine':<26}"
          f"{'bpp':<5}{'sound':<12}{'clock'}")
    for prof, drv in PROFILES.items():
        if drv is None:
            print(f"{prof:<13}{'-':<11}{'(no MAME entry: house test ROM)':<26}")
            continue
        mach = machines.get(drv)
        if not mach:
            print(f"{prof:<13}{drv:<11}NOT FOUND IN DRIVER")
            bad += 1
            continue
        bpp, snd, clk = decode(mach)

        # refine CVSD into small/large via init_generic
        init_key = {
            "strkforc": "strkforc",
            "saurnfrnt": "strkforc",
            "yunittst": "shimpact",
        }.get(drv, drv)
        init_key = re.sub(r"(la\d+|prot\d+|\d+)$", "", init_key)
        if snd == "CVSD":
            snd = subtype.get(init_key, "CVSD_?")
        if drv.startswith("mk"):
            snd = "ADPCM"

        if mutate and prof == "YG_TROG":
            bpp = 6  # deliberate corruption for --self-test

        exp_four = (bpp == 4)
        got_four = prof in four
        exp_adpcm = snd == "ADPCM"
        got_adpcm = prof in adpcm
        exp_large = snd == "CVSD_LARGE"
        got_large = prof in large
        got_clk = "FASTER" if prof in faster else "FAST" if prof in fast else "SLOW"

        errs = []
        if exp_four != got_four:
            errs.append(f"bpp MAME={bpp} pkg={'4' if got_four else '6'}")
        if exp_adpcm != got_adpcm:
            errs.append(f"adpcm MAME={exp_adpcm} pkg={got_adpcm}")
        if exp_large != got_large:
            errs.append(f"cvsd_large MAME={exp_large} pkg={got_large}")
        if clk != got_clk:
            errs.append(f"clock MAME={clk} pkg={got_clk}")

        flag = "" if not errs else "   <== " + "; ".join(errs)
        print(f"{prof:<13}{drv:<11}{mach:<26}{bpp:<5}{snd:<12}{clk}{flag}")
        bad += len(errs)

    print()
    if bad:
        print(f"FAIL: {bad} profile field(s) disagree with the MAME driver.")
        return 1
    print("PASS: every supported profile's bpp / sound / clock matches MAME.")
    return 0


def main():
    if "--self-test" in sys.argv:
        print("-- self-test: corrupting TROG's expected bpp, a mismatch is REQUIRED --")
        rc = run(mutate=True)
        if rc == 0:
            print("SELF-TEST FAIL: corruption went undetected; the audit is blind.")
            return 1
        print("SELF-TEST PASS: the audit detects a corrupted expectation.")
        return 0
    return run()


if __name__ == "__main__":
    sys.exit(main())
