#!/usr/bin/env python3
"""Validate and stage a fail-closed MiSTer Y-unit hardware release."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any


# The generated MRAs use a stable source stem so they can be audited before a
# build exists. A publishable package NEVER installs that unsuffixed stem: its
# target is suffixed with the exact source commit used for the fit. This makes
# an old Arcade-SmashTV-YUnit-Full.rbf harmless instead of silently selectable.
CANONICAL_MRA_STEM = "Arcade-SmashTV-YUnit-Full"
VARIANT_BASE_STEMS = {
    "production": CANONICAL_MRA_STEM,
    "diag-boot": "Arcade-SmashTV-YUnit-Full-DIAG_BOOT",
}
VARIANT_BUILD_DEFINES = {
    "production": [],
    "diag-boot": ["DIAG_BOOT"],
}

# This contract is deliberately independent of generate_yunit_mras.py.  A
# generator regression must not be able to redefine what a releasable family is.
EXPECTED_SETS = {
    "smashtv": {"profile": 0, "archive": "smashtv.zip"},
    "trog": {"profile": 1, "archive": "trog.zip"},
    "hiimpact": {"profile": 2, "archive": "hiimpact.zip"},
    "shimpact": {"profile": 3, "archive": "shimpact.zip"},
    "strkforc": {"profile": 4, "archive": "strkforc.zip"},
    "mk": {"profile": 5, "archive": "mk.zip"},
    "term2": {"profile": 6, "archive": "term2.zip"},
    "totcarn": {"profile": 7, "archive": "totcarn.zip"},
    "yunittst": {"profile": 8, "archive": "yunittst.zip"},
    "saurnfrnt": {"profile": 9, "archive": "strkforc.zip"},
}
EXPECTED_ROM_INDEX_ORDER = [3, 0, 1, 2]
EXPECTED_NVRAM = {"index": "4", "size": "32768"}
FORBIDDEN_MRA_DIR_SUFFIXES = {".rbf", ".sof", ".pof"}
MIN_RBF_BYTES = 1_000_000
SHA256_RE = re.compile(r"[0-9a-fA-F]{64}")
RELEASE_ID_RE = re.compile(r"[0-9a-f]{7,12}")
RBF_TAG_RE = re.compile(rb"(<rbf>)([^<]*)(</rbf>)")

# Independent of generate_yunit_mras.py by design. Start and Coin occupy the
# two joystick bits immediately after each title's real action list; padding
# that list with "Unused" was the cabinet bug that moved Total Carnage Start
# from bit 8 to bit 10.
EXPECTED_CONTROLS = {
    "trog": (4, "Punch,Start,Coin", "A,Start,Select", "1"),
    "smashtv": (
        2,
        "Fire Up,Fire Down,Fire Left,Fire Right,Service Credit,Start,Coin",
        "Y,A,X,B,L,Start,Select",
        "5",
    ),
    "hiimpact": (4, "Action,Start,Coin", "A,Start,Select", "1"),
    "shimpact": (4, "Action,Start,Coin", "A,Start,Select", "1"),
    "strkforc": (
        2,
        "Fire,Weapon,Weapon Select,Start,Coin",
        "A,B,X,Start,Select",
        "3",
    ),
    "saurnfrnt": (
        2,
        "Fire,Weapon,Weapon Select,Start,Coin",
        "A,B,X,Start,Select",
        "3",
    ),
    "mk": (
        2,
        "High Punch,Low Punch,Block,High Kick,Low Kick,Block 2,Start,Coin",
        "X,A,L,Y,B,R,Start,Select",
        "6",
    ),
    "term2": (2, "Trigger,Bomb,Start,Coin", "A,B,Start,Select", "2"),
    "totcarn": (
        2,
        "Fire Up,Fire Down,Fire Left,Fire Right,Start,Coin",
        "A,B,X,Y,Start,Select",
        "4",
    ),
    "yunittst": (2, "Action,Start,Coin", "A,Start,Select", "1"),
}


class ReleaseError(RuntimeError):
    """A release policy or input validation failure."""


@dataclass(frozen=True)
class MraInput:
    path: Path
    raw: bytes
    setname: str
    profile: int
    archive: str
    mtime_ns: int

    def rendered(self, target_stem: str) -> bytes:
        replacement = target_stem.encode("ascii")
        rendered, count = RBF_TAG_RE.subn(
            lambda match: match.group(1) + replacement + match.group(3),
            self.raw,
        )
        if count != 1:
            raise ReleaseError(
                f"{self.path}: expected exactly one simple <rbf> element, found {count}"
            )
        return rendered


@dataclass(frozen=True)
class RbfInput:
    path: Path
    sha256: str
    size: int
    mtime_ns: int


@dataclass(frozen=True)
class ReleasePlan:
    variant: str
    target_stem: str
    mras: tuple[MraInput, ...]
    rendered_mras: tuple[bytes, ...]
    rbf: RbfInput | None
    manifest: dict[str, Any]


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def one_text(root: ET.Element, tag: str, source: Path) -> str:
    nodes = root.findall(f"./{tag}")
    if len(nodes) != 1:
        raise ReleaseError(
            f"{source}: expected exactly one <{tag}> element, found {len(nodes)}"
        )
    return (nodes[0].text or "").strip()


def target_stem_for(variant: str, release_id: str) -> str:
    if variant not in VARIANT_BASE_STEMS:
        raise ReleaseError(f"unknown release variant: {variant}")
    normalized = release_id.lower()
    if not RELEASE_ID_RE.fullmatch(normalized):
        raise ReleaseError(
            "release id must be the 7-12 lowercase hexadecimal source commit"
        )
    return f"{VARIANT_BASE_STEMS[variant]}-{normalized}"


def parse_mra(path: Path, expected_rbf_stem: str = CANONICAL_MRA_STEM) -> MraInput:
    if path.is_symlink():
        raise ReleaseError(f"{path}: symlinked MRAs are not releasable")
    try:
        raw = path.read_bytes()
        root = ET.fromstring(raw)
    except (OSError, ET.ParseError) as exc:
        raise ReleaseError(f"{path}: cannot read valid MRA XML: {exc}") from exc

    if root.tag != "misterromdescription":
        raise ReleaseError(
            f"{path}: root must be <misterromdescription>, got <{root.tag}>"
        )

    setname = one_text(root, "setname", path)
    if setname not in EXPECTED_SETS:
        raise ReleaseError(
            f"{path}: unexpected setname {setname!r}; legacy/monolithic MRAs "
            "are not part of the Y-unit family release"
        )
    expected = EXPECTED_SETS[setname]

    rbf_stem = one_text(root, "rbf", path)
    if rbf_stem != expected_rbf_stem:
        raise ReleaseError(
            f"{path}: <rbf> is {rbf_stem!r}, expected {expected_rbf_stem!r}; "
            "legacy or mixed-core MRAs are forbidden"
        )
    if one_text(root, "mameversion", path) != "0280":
        raise ReleaseError(f"{path}: family MRA must declare MAME version 0280")

    roms = root.findall("./rom")
    try:
        indexes = [int(rom.attrib["index"], 10) for rom in roms]
    except (KeyError, ValueError) as exc:
        raise ReleaseError(f"{path}: every <rom> needs a decimal index") from exc
    if indexes != EXPECTED_ROM_INDEX_ORDER:
        raise ReleaseError(
            f"{path}: ROM index order is {indexes}, expected "
            f"{EXPECTED_ROM_INDEX_ORDER} (profile, graphics, program, sound)"
        )

    profile_rom = roms[0]
    if profile_rom.attrib != {"index": "3"}:
        raise ReleaseError(
            f"{path}: profile ROM must have only index=\"3\", got "
            f"{profile_rom.attrib}"
        )
    profile_parts = profile_rom.findall("./part")
    if (
        len(profile_parts) != 1
        or profile_parts[0].attrib
        or list(profile_parts[0])
    ):
        raise ReleaseError(
            f"{path}: profile ROM must contain one literal, attribute-free <part>"
        )
    profile_text = (profile_parts[0].text or "").strip()
    expected_profile = int(expected["profile"])
    if profile_text.lower() != f"{expected_profile:02x}":
        raise ReleaseError(
            f"{path}: profile byte is {profile_text!r}, expected "
            f"{expected_profile:02x} for {setname}"
        )

    expected_archive = str(expected["archive"])
    for rom in roms[1:]:
        index = int(rom.attrib["index"], 10)
        if set(rom.attrib) != {"index", "zip"}:
            raise ReleaseError(
                f"{path}: ROM index {index} must have only index and zip attributes"
            )
        if rom.attrib["zip"] != expected_archive:
            raise ReleaseError(
                f"{path}: ROM index {index} uses {rom.attrib['zip']!r}, "
                f"expected {expected_archive!r}"
            )
        if not rom.findall("./part"):
            raise ReleaseError(f"{path}: ROM index {index} has no <part> payload")

    nvrams = root.findall("./nvram")
    if len(nvrams) != 1 or nvrams[0].attrib != EXPECTED_NVRAM:
        attrs = [node.attrib for node in nvrams]
        raise ReleaseError(
            f"{path}: expected exactly <nvram index=\"4\" size=\"32768\">, "
            f"got {attrs}"
        )

    if one_text(root, "joystick", path) != "8":
        raise ReleaseError(f"{path}: family MRA must declare <joystick>8</joystick>")
    expected_players, names, defaults, count = EXPECTED_CONTROLS[setname]
    if one_text(root, "players", path) != str(expected_players):
        raise ReleaseError(
            f"{path}: players does not match the {setname} cabinet contract"
        )
    buttons = root.findall("./buttons")
    expected_buttons = {
        "names": names,
        "default": defaults,
        "count": count,
    }
    if len(buttons) != 1 or buttons[0].attrib != expected_buttons:
        attrs = [node.attrib for node in buttons]
        raise ReleaseError(
            f"{path}: buttons are {attrs}, expected {expected_buttons}; "
            "Start/Coin must immediately follow the real action buttons"
        )
    if "Unused" in names or "Unused" in defaults:
        raise ReleaseError(f"{path}: Unused control labels are forbidden")

    return MraInput(
        path=path,
        raw=raw,
        setname=setname,
        profile=expected_profile,
        archive=expected_archive,
        mtime_ns=path.stat().st_mtime_ns,
    )


def path_is_quarantined(path: Path) -> bool:
    return any("quarantine" in part.lower() for part in path.resolve().parts)


def load_mra_family(mra_dir: Path) -> tuple[MraInput, ...]:
    if not mra_dir.is_dir():
        raise ReleaseError(f"MRA directory does not exist: {mra_dir}")
    if mra_dir.is_symlink():
        raise ReleaseError(f"MRA directory may not be a symlink: {mra_dir}")
    if path_is_quarantined(mra_dir):
        raise ReleaseError(f"quarantined MRA inputs are forbidden: {mra_dir}")

    all_files = [path for path in mra_dir.rglob("*") if path.is_file()]
    stale_fpga = sorted(
        path
        for path in all_files
        if path.suffix.lower() in FORBIDDEN_MRA_DIR_SUFFIXES
    )
    if stale_fpga:
        names = ", ".join(str(path.relative_to(mra_dir)) for path in stale_fpga)
        raise ReleaseError(
            f"{mra_dir}: stale FPGA artifact(s) found alongside MRAs: {names}; "
            "use the dedicated generated-family MRA directory"
        )

    mra_paths = sorted(
        (path for path in all_files if path.suffix.lower() == ".mra"),
        key=lambda path: str(path).casefold(),
    )
    nested = [path for path in mra_paths if path.parent.resolve() != mra_dir.resolve()]
    if nested:
        names = ", ".join(str(path.relative_to(mra_dir)) for path in nested)
        raise ReleaseError(f"{mra_dir}: nested MRA inputs are forbidden: {names}")
    if len(mra_paths) != len(EXPECTED_SETS):
        raise ReleaseError(
            f"{mra_dir}: found {len(mra_paths)} MRAs, expected exactly "
            f"{len(EXPECTED_SETS)} family MRAs; legacy, missing, or extra MRAs "
            "must not be packaged"
        )

    mras = tuple(parse_mra(path) for path in mra_paths)
    by_set: dict[str, MraInput] = {}
    for mra in mras:
        if mra.setname in by_set:
            raise ReleaseError(
                f"duplicate family set {mra.setname!r}: "
                f"{by_set[mra.setname].path} and {mra.path}"
            )
        by_set[mra.setname] = mra
    missing = sorted(set(EXPECTED_SETS) - set(by_set))
    extra = sorted(set(by_set) - set(EXPECTED_SETS))
    if missing or extra:
        raise ReleaseError(
            f"MRA family mismatch: missing={missing or 'none'}, "
            f"extra={extra or 'none'}"
        )
    return mras


def validate_approved_hash(value: str) -> str:
    if not SHA256_RE.fullmatch(value):
        raise ReleaseError("approved RBF SHA-256 must be exactly 64 hex digits")
    return value.upper()


def validate_rbf(
    path: Path,
    approved_sha256: str,
    target_stem: str,
    newest_mra_mtime_ns: int,
) -> RbfInput:
    if not path.is_file():
        raise ReleaseError(f"RBF does not exist: {path}")
    if path.is_symlink():
        raise ReleaseError(f"symlinked RBF inputs are forbidden: {path}")
    if path_is_quarantined(path):
        raise ReleaseError(f"quarantined RBF inputs are forbidden: {path}")
    if path.name != f"{target_stem}.rbf":
        raise ReleaseError(
            f"RBF name is {path.name!r}, expected exactly "
            f"{target_stem + '.rbf'!r} for this variant"
        )

    stat = path.stat()
    if stat.st_size < MIN_RBF_BYTES:
        raise ReleaseError(
            f"{path}: only {stat.st_size} bytes; expected a complete MiSTer RBF "
            f"of at least {MIN_RBF_BYTES} bytes"
        )
    if stat.st_mtime_ns < newest_mra_mtime_ns:
        raise ReleaseError(
            f"{path}: RBF is older than the generated MRA family; refusing a "
            "potentially stale hardware artifact"
        )

    approved = validate_approved_hash(approved_sha256)
    actual = sha256_file(path)
    if actual != approved:
        raise ReleaseError(
            f"{path}: SHA-256 {actual} does not match signed-off value {approved}"
        )
    return RbfInput(
        path=path,
        sha256=actual,
        size=stat.st_size,
        mtime_ns=stat.st_mtime_ns,
    )


def manifest_file_entry(
    relative_path: PurePosixPath,
    data: bytes,
    *,
    kind: str,
    **metadata: Any,
) -> dict[str, Any]:
    return {
        "path": str(relative_path),
        "kind": kind,
        "size": len(data),
        "sha256": sha256_bytes(data),
        **metadata,
    }


def make_release_plan(
    mra_dir: Path,
    variant: str,
    release_id: str,
    *,
    rbf_path: Path | None = None,
    approved_rbf_sha256: str | None = None,
) -> ReleasePlan:
    if (rbf_path is None) != (approved_rbf_sha256 is None):
        raise ReleaseError(
            "--rbf and --approved-rbf-sha256 must be supplied together"
        )

    target_stem = target_stem_for(variant, release_id)
    mras = load_mra_family(mra_dir)
    rendered_mras = tuple(mra.rendered(target_stem) for mra in mras)
    newest_mra_mtime_ns = max(mra.mtime_ns for mra in mras)

    rbf = None
    if rbf_path is not None and approved_rbf_sha256 is not None:
        rbf = validate_rbf(
            rbf_path,
            approved_rbf_sha256,
            target_stem,
            newest_mra_mtime_ns,
        )

    entries: list[dict[str, Any]] = []
    if rbf is not None:
        entries.append(
            {
                "path": f"_Arcade/cores/{target_stem}.rbf",
                "kind": "rbf",
                "size": rbf.size,
                "sha256": rbf.sha256,
                "approval": "operator-supplied-signed-off-sha256",
            }
        )
    for mra, rendered in sorted(
        zip(mras, rendered_mras), key=lambda item: item[0].setname
    ):
        entries.append(
            manifest_file_entry(
                PurePosixPath("_Arcade", mra.path.name),
                rendered,
                kind="mra",
                setname=mra.setname,
                profile=mra.profile,
                rom_archive=mra.archive,
                rbf_stem=target_stem,
            )
        )

    archives = sorted({str(info["archive"]) for info in EXPECTED_SETS.values()})
    manifest: dict[str, Any] = {
        "schema_version": 1,
        "package_kind": "mister-yunit-sd-staging",
        "generated_utc": datetime.now(timezone.utc)
        .isoformat(timespec="seconds")
        .replace("+00:00", "Z"),
        "publishable": rbf is not None,
        "variant": variant,
        "release_id": release_id.lower(),
        "build_defines": VARIANT_BUILD_DEFINES[variant],
        "rbf_stem": target_stem,
        "source_mra_stem": CANONICAL_MRA_STEM,
        "policy": {
            "exact_rbf_count": 1,
            "exact_mra_count": len(EXPECTED_SETS),
            "legacy_mras_allowed": False,
            "quarantined_artifacts_allowed": False,
            "rbf_must_not_predate_mras": True,
            "rbf_approval": "exact SHA-256 supplied by release operator",
        },
        "sd_layout": {
            "rbf": f"_Arcade/cores/{target_stem}.rbf",
            "mras": "_Arcade/*.mra",
            "roms": "/games/mame/*.zip (not included in this package)",
        },
        "files": entries,
        "required_rom_archives": [
            {
                "archive": archive,
                "install_path": f"/games/mame/{archive}",
                "included": False,
            }
            for archive in archives
        ],
    }
    return ReleasePlan(
        variant=variant,
        target_stem=target_stem,
        mras=mras,
        rendered_mras=rendered_mras,
        rbf=rbf,
        manifest=manifest,
    )


def verify_staged_tree(stage: Path, plan: ReleasePlan) -> None:
    if plan.rbf is None:
        raise ReleaseError("internal error: an MRA-only plan cannot be published")

    file_entries = plan.manifest["files"]
    expected = {str(PurePosixPath(entry["path"])) for entry in file_entries}
    expected.add("release-manifest.json")
    actual = {
        str(PurePosixPath(*path.relative_to(stage).parts))
        for path in stage.rglob("*")
        if path.is_file()
    }
    if actual != expected:
        raise ReleaseError(
            f"staged file set mismatch: missing={sorted(expected - actual)}, "
            f"extra={sorted(actual - expected)}"
        )

    rbfs = list(stage.rglob("*.rbf"))
    if len(rbfs) != 1:
        raise ReleaseError(f"staged package contains {len(rbfs)} RBFs, expected one")
    mra_paths = list((stage / "_Arcade").glob("*.mra"))
    if len(mra_paths) != len(EXPECTED_SETS):
        raise ReleaseError(
            f"staged package contains {len(mra_paths)} MRAs, expected "
            f"{len(EXPECTED_SETS)}"
        )

    for entry in file_entries:
        path = stage.joinpath(*PurePosixPath(entry["path"]).parts)
        if path.stat().st_size != entry["size"]:
            raise ReleaseError(f"staged size mismatch: {entry['path']}")
        if sha256_file(path) != entry["sha256"]:
            raise ReleaseError(f"staged SHA-256 mismatch: {entry['path']}")
    for path in mra_paths:
        parse_mra(path, expected_rbf_stem=plan.target_stem)

    manifest_on_disk = json.loads(
        (stage / "release-manifest.json").read_text(encoding="utf-8")
    )
    if manifest_on_disk != plan.manifest:
        raise ReleaseError("staged release-manifest.json does not match release plan")


def publish_release(plan: ReleasePlan, output: Path) -> Path:
    if plan.rbf is None:
        raise ReleaseError(
            "publishing requires one RBF and its signed-off SHA-256; "
            "MRA-only dry runs are never publishable"
        )
    output = output.resolve()
    if output.exists():
        raise ReleaseError(
            f"output already exists: {output}; refusing to mix with stale artifacts"
        )
    output.parent.mkdir(parents=True, exist_ok=True)

    stage = Path(
        tempfile.mkdtemp(prefix=f".{output.name}.tmp-", dir=str(output.parent))
    )
    try:
        arcade_dir = stage / "_Arcade"
        cores_dir = arcade_dir / "cores"
        cores_dir.mkdir(parents=True)

        staged_rbf = cores_dir / f"{plan.target_stem}.rbf"
        shutil.copyfile(plan.rbf.path, staged_rbf)
        for mra, rendered in zip(plan.mras, plan.rendered_mras):
            (arcade_dir / mra.path.name).write_bytes(rendered)
        (stage / "release-manifest.json").write_text(
            json.dumps(plan.manifest, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
            newline="\n",
        )

        verify_staged_tree(stage, plan)
        if output.exists():
            raise ReleaseError(
                f"output appeared while staging: {output}; refusing to overwrite it"
            )
        stage.rename(output)
    except Exception:
        if stage.exists():
            shutil.rmtree(stage)
        raise
    return output


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Validate the exact ten-game Y-unit MRA ABI and stage one explicitly "
            "approved RBF as a MiSTer SD-card release."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"""\
Normal MiSTer SD layout (copy the staged tree's contents to the SD root):
  _Arcade/cores/{VARIANT_BASE_STEMS['production']}-<source-commit>.rbf
  _Arcade/<generated family MRAs>.mra
  /games/mame/<legally sourced ROM archives>.zip   (not packaged here)

The DIAG_BOOT variant uses a separate, non-colliding core stem:
  _Arcade/cores/{VARIANT_BASE_STEMS['diag-boot']}-<source-commit>.rbf

MRA-only validation (no RBF is trusted or written):
  python tools/package_yunit_release.py --mra-dir releases/yunit \\
      --variant production --release-id <source-commit> --dry-run

Publish after hardware qualification and explicit hash sign-off:
  python tools/package_yunit_release.py --mra-dir releases/yunit \\
      --variant production --release-id <source-commit> \\
      --rbf releases/{VARIANT_BASE_STEMS['production']}-<source-commit>.rbf \\
      --approved-rbf-sha256 <64-hex-signed-off-value> --output staging/yunit-prod

Use --variant diag-boot and an RBF named
{VARIANT_BASE_STEMS['diag-boot']}-<source-commit>.rbf for a diagnostic package.
""",
    )
    parser.add_argument(
        "--mra-dir",
        type=Path,
        required=True,
        help="directory containing exactly the ten generated Y-unit family MRAs",
    )
    parser.add_argument(
        "--variant",
        choices=sorted(VARIANT_BASE_STEMS),
        required=True,
        help="production or the separately named DIAG_BOOT hardware image",
    )
    parser.add_argument(
        "--release-id",
        required=True,
        help="7-12 hex source commit; appended to the installed RBF stem",
    )
    parser.add_argument(
        "--rbf",
        type=Path,
        help="single qualified RBF; its file name must match the variant stem",
    )
    parser.add_argument(
        "--approved-rbf-sha256",
        help=(
            "exact SHA-256 copied from the completed hardware sign-off record; "
            "required with --rbf"
        ),
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="new staging directory; required to publish and never overwritten",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="validate and preview only; never create or modify files",
    )
    return parser


def run_cli(args: argparse.Namespace) -> int:
    if not args.dry_run:
        if args.output is None:
            raise ReleaseError("--output is required unless --dry-run is used")
        if args.rbf is None or args.approved_rbf_sha256 is None:
            raise ReleaseError(
                "publishing requires --rbf and --approved-rbf-sha256"
            )
    if args.output is not None and args.output.exists():
        raise ReleaseError(
            f"output already exists: {args.output}; stale output is never reused"
        )

    plan = make_release_plan(
        args.mra_dir,
        args.variant,
        args.release_id,
        rbf_path=args.rbf,
        approved_rbf_sha256=args.approved_rbf_sha256,
    )
    if args.dry_run:
        print("DRY RUN: validation passed; no files were written.")
        print(f"Variant: {plan.variant}")
        print(f"RBF stem: {plan.target_stem}")
        print(f"Family MRAs: {len(plan.mras)}")
        if plan.rbf is None:
            print("RBF: omitted (this plan is intentionally not publishable)")
        else:
            print(f"RBF: approved {plan.rbf.sha256}")
        output = str(args.output) if args.output is not None else "<new staging dir>"
        print(f"Would stage under: {output}")
        print(f"  _Arcade/cores/{plan.target_stem}.rbf")
        print("  _Arcade/<10 family MRAs>.mra")
        print("ROM archives remain external under /games/mame/.")
        return 0

    published = publish_release(plan, args.output)
    print(f"Release staged and re-verified: {published}")
    print(f"RBF: {published / '_Arcade' / 'cores' / (plan.target_stem + '.rbf')}")
    print(f"Manifest: {published / 'release-manifest.json'}")
    return 0


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    try:
        return run_cli(args)
    except ReleaseError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
