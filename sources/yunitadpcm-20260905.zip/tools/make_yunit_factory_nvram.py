#!/usr/bin/env python3
"""Create factory-accepted Y-unit CMOS images reproducibly with MAME.

The all-profile RTL boot gate restores CMOS through the same index-4 byte port
used on MiSTer.  A clean checkout therefore needs a reproducible way to create
the accepted factory state instead of depending on an ignored local artifact.
"""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
import shutil
import subprocess
import tempfile


PROJECT_ROOT = Path(__file__).resolve().parents[1]
INIT_SCRIPT = PROJECT_ROOT / "tools" / "initialize_yunit_factory_nvram.lua"
GAMES = (
    "trog",
    "smashtv",
    "hiimpact",
    "shimpact",
    "strkforc",
    "mkla4",
    "term2",
    "totcarn",
)
NVRAM_BYTES = 32768


def generate_one(mame: Path, rom_dir: Path, out_dir: Path, game: str) -> None:
    target = out_dir / game / game / "nvram"
    if target.is_file() and target.stat().st_size == NVRAM_BYTES:
        digest = hashlib.sha256(target.read_bytes()).hexdigest()[:12]
        print(f"YUNIT_FACTORY_NVRAM reuse set={game} bytes={NVRAM_BYTES} sha256={digest}")
        return

    with tempfile.TemporaryDirectory(prefix=f"yunit-nvram-{game}-") as temp_name:
        temp = Path(temp_name)
        command = [
            str(mame),
            game,
            "-rompath",
            str(rom_dir),
            "-cfg_directory",
            str(temp / "cfg"),
            "-nvram_directory",
            str(temp / "nvram"),
            "-snapshot_directory",
            str(temp / "snap"),
            "-video",
            "none",
            "-sound",
            "none",
            "-nothrottle",
            "-skip_gameinfo",
            "-autoboot_script",
            str(INIT_SCRIPT),
        ]
        result = subprocess.run(
            command,
            cwd=temp,
            capture_output=True,
            text=True,
            timeout=120,
            check=False,
        )
        combined = result.stdout + "\n" + result.stderr
        produced = temp / "nvram" / game / "nvram"
        if (
            result.returncode != 0
            or "YUNIT_FACTORY_NVRAM_INIT complete" not in combined
            or not produced.is_file()
            or produced.stat().st_size != NVRAM_BYTES
        ):
            tail = "\n".join(combined.splitlines()[-20:])
            raise RuntimeError(
                f"{game}: MAME factory initialization failed "
                f"(exit={result.returncode}, output={produced})\n{tail}"
            )
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(produced, target)

    digest = hashlib.sha256(target.read_bytes()).hexdigest()[:12]
    print(f"YUNIT_FACTORY_NVRAM made set={game} bytes={NVRAM_BYTES} sha256={digest}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("rom_dir", type=Path)
    parser.add_argument("out_dir", type=Path)
    parser.add_argument(
        "--mame", type=Path, default=Path(r"C:\tools\mame\mame.exe")
    )
    parser.add_argument("--games", nargs="+", choices=GAMES, default=list(GAMES))
    args = parser.parse_args()

    if not args.mame.is_file():
        raise SystemExit(f"MAME executable not found: {args.mame}")
    if not args.rom_dir.is_dir():
        raise SystemExit(f"ROM directory not found: {args.rom_dir}")
    if not INIT_SCRIPT.is_file():
        raise SystemExit(f"factory initialization script not found: {INIT_SCRIPT}")

    # Preserve request order while removing aliases such as Strike Force being
    # requested both directly and as Saurian Front's factory CMOS donor.
    for game in dict.fromkeys(args.games):
        generate_one(args.mame, args.rom_dir, args.out_dir, game)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
