#!/usr/bin/env python3
"""Cross-diff the core's graphics unpack against MAME's, on REAL ROM bytes.

Smash T.V. is the only Y-unit title with a per-instruction MAME golden, so it
is the only one whose graphics path has ever been exercised. Every other
title's plane geometry came from a profile table that has never been checked
against actual ROM data -- which is exactly why nine of ten titles fail their
own ROM test while Smash boots.

Two INDEPENDENT transcriptions (DESIGN-RULES.md section 5), from the same gospel:

  MAME  midyunit_m.cpp init_gfxrom(): reads the SPARSE ROM_REGION("gfx") with
        a FIXED plane stride gfx_chunk = m_gfx_rom.bytes() / 4. Every Y-unit
        region is 0x800000, so gfx_chunk is 0x200000 for every title.

  CORE  yunit_gfx_unpack.sv: reads a COMPRESSED SDRAM scratch image where the
        MRA packed each plane's chips contiguously, striding by PLANE_WORDS
        words (= plane_words*2 bytes), which VARIES per title.

Both must yield the same unpacked pixels over the range the game actually
reads. Where they diverge, the core is wrong -- and the first differing byte
localises which plane and which chip.

Pixel math is identical in both (init_gfxrom 6bpp / 4bpp):
    pixel = p0 | p1<<2 | p2<<4,  with bits = (byte >> 2*(i%4)) & 3
so any divergence is a LAYOUT fault, not an arithmetic one.
"""
from __future__ import annotations

import re
import sys
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tools import generate_yunit_mras as g  # noqa: E402

REPO = Path(__file__).resolve().parents[1]
MAME_SRC = REPO / "docs/mame-ref/midyunit.cpp"
ALIAS = {"mk": "mkla4"}


def mame_gfx_region(setname: str):
    """(region_size, [(filename, offset, size)]) from ROM_REGION("gfx")."""
    src = MAME_SRC.read_text(encoding="utf-8", errors="replace")
    m = re.search(r'ROM_START\(\s*%s\s*\)(.*?)ROM_END' % re.escape(setname),
                  src, re.S)
    if not m:
        return None, []
    body = m.group(1)
    parts = re.split(r'ROM_REGION\w*\(([^)]*)\)', body)
    for i in range(1, len(parts), 2):
        if '"gfx"' in parts[i]:
            size = int(re.search(r'(0x[0-9a-fA-F]+)', parts[i]).group(1), 16)
            loads = [(mm.group(1), int(mm.group(2), 16), int(mm.group(3), 16))
                     for mm in re.finditer(
                         r'ROM_LOAD\s*\(\s*"([^"]+)"\s*,\s*(0x[0-9a-fA-F]+)'
                         r'\s*,\s*(0x[0-9a-fA-F]+)', parts[i + 1])]
            return size, loads
    return None, []


def zip_bytes(zf, names, fname):
    base = fname.split("/")[-1]
    return zf.read(names[base]) if base in names else b""


def build_mame_region(setname, zf, names):
    """The SPARSE region MAME's init_gfxrom reads from."""
    size, loads = mame_gfx_region(setname)
    if size is None:
        return None
    buf = bytearray(size)
    for fname, off, sz in loads:
        data = zip_bytes(zf, names, fname)
        if not data:
            return None
        buf[off:off + len(data)] = data
    return bytes(buf)


def build_core_scratch(game, zf, names):
    """The COMPRESSED scratch image the MRA writes, in generator order."""
    buf = bytearray()
    for e in game["gfx"]:
        if isinstance(e, int):
            buf.extend(b"\x00" * e)
        else:
            d = zip_bytes(zf, names, e)
            if not d:
                return None
            buf.extend(d)
    return bytes(buf)


def unpack(planes, nbytes, bpp):
    """Shared pixel math; `planes` supplies plane n's byte at a raw index."""
    out = bytearray(nbytes)
    for i in range(0, nbytes, 2):
        vals = []
        for half in (0, 1):
            j = i + half
            px = 0
            for p in range(3 if bpp == 6 else 2):
                b = planes(p, j // 4)
                px |= (((b >> (2 * (j % 4))) & 3) << (2 * p))
            vals.append(px)
        out[i] = vals[0]
        out[i + 1] = vals[1]
    return bytes(out)


def main() -> int:
    rom_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else REPO.parent / "roms"
    only = sys.argv[2] if len(sys.argv) > 2 else None
    worst = 0
    print(f"{'title':<11} {'bpp':>3} {'compared':>10}  result")
    print("-" * 74)
    for k, v in g.GAMES.items():
        if only and k != only:
            continue
        setname = ALIAS.get(k, k)
        arch = v.get("archive", k)
        zp = rom_dir / f"{arch}.zip"
        if not zp.exists():
            print(f"{k:<11} {'':>3} {'':>10}  SKIP (no {zp.name})")
            continue
        zf = zipfile.ZipFile(zp)
        names = {n.split("/")[-1]: n for n in zf.namelist()}
        region = build_mame_region(setname, zf, names)
        scratch = build_core_scratch(v, zf, names)
        if region is None or scratch is None:
            print(f"{k:<11} {'':>3} {'':>10}  SKIP (rom set incomplete)")
            continue
        pw = g.PROFILE_PLANE_WORDS[v["profile"]]
        bpp = 4 if v["profile"] in (1, 4, 9) else 6
        chunk = len(region) // 4                 # MAME: fixed 0x200000
        stride = pw * 2                          # core: per-title
        n = pw * 8                               # unpacked bytes the core makes

        mame_img = unpack(lambda p, idx: region[p * chunk + idx]
                          if p * chunk + idx < len(region) else 0, n, bpp)
        core_img = unpack(lambda p, idx: scratch[p * stride + idx]
                          if p * stride + idx < len(scratch) else 0, n, bpp)

        if mame_img == core_img:
            print(f"{k:<11} {bpp:>3} {n:>10,}  MATCH")
            continue
        diff = next(i for i in range(n) if mame_img[i] != core_img[i])
        pct = sum(1 for a, b in zip(mame_img, core_img) if a != b) * 100.0 / n
        plane = diff // (2 * stride) if stride else -1
        print(f"{k:<11} {bpp:>3} {n:>10,}  DIVERGE at {diff:#x} "
              f"({pct:.1f}% differ, first in plane-slot {plane})")
        worst += 1
    print()
    print(f"{worst} title(s) diverge from MAME's decode")
    return 1 if worst else 0


if __name__ == "__main__":
    raise SystemExit(main())
