#!/usr/bin/env python3
"""Distill MAME TMS34010 debugger traces into observed opcode cycle costs.

Capture format (emitted before the instruction on the same line executes):

    TC=<total> LIC=<previous instruction cycles> PC=<pc> OP=<opcode> ...

Consequently line N's LIC belongs to line N-1's opcode.  The analyser keeps
that boundary explicit and verifies that successive total-cycle deltas agree
with MAME's lastinstructioncycles symbol.
"""

from __future__ import annotations

import argparse
import collections
import pathlib
import re


LINE_RE = re.compile(
    r"^TC=(?P<total>\d+) LIC=(?P<last>\d+) "
    r"PC=(?P<pc>[0-9A-Fa-f]{8}) OP=(?P<op>[0-9A-Fa-f]{4}) "
    r"(?P<dispc>[0-9A-Fa-f]{8}):\s*(?P<asm>.*)$"
)


def mnemonic(assembly: str) -> str:
    return assembly.split(None, 1)[0].upper() if assembly.strip() else "?"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("trace", type=pathlib.Path)
    parser.add_argument(
        "--all",
        action="store_true",
        help="print every observed opcode, not only dynamic/multi-cycle entries",
    )
    args = parser.parse_args()

    by_opcode: dict[int, collections.Counter[int]] = collections.defaultdict(
        collections.Counter
    )
    names: dict[int, collections.Counter[str]] = collections.defaultdict(
        collections.Counter
    )
    retired = 0
    malformed = 0
    delta_mismatches = 0
    previous: tuple[int, int, int, str] | None = None

    with args.trace.open("r", encoding="utf-8", errors="replace") as stream:
        for raw in stream:
            match = LINE_RE.match(raw.rstrip())
            if not match:
                if raw.strip():
                    malformed += 1
                continue

            total = int(match.group("total"))
            last = int(match.group("last"))
            pc = int(match.group("pc"), 16)
            op = int(match.group("op"), 16)
            assembly = match.group("asm").strip()

            if previous is not None:
                prev_total, prev_pc, prev_op, prev_asm = previous
                delta = total - prev_total
                if delta != last:
                    delta_mismatches += 1
                by_opcode[prev_op][last] += 1
                names[prev_op][mnemonic(prev_asm)] += 1
                retired += 1

            previous = (total, pc, op, assembly)

    dynamic = sum(1 for costs in by_opcode.values() if len(costs) > 1)
    print(
        f"TRACE {args.trace}: retired={retired} unique_opcodes={len(by_opcode)} "
        f"dynamic_opcodes={dynamic} malformed={malformed} "
        f"cycle_delta_mismatches={delta_mismatches}"
    )

    for op in sorted(by_opcode):
        costs = by_opcode[op]
        if not args.all and len(costs) == 1:
            continue
        label = names[op].most_common(1)[0][0]
        rendered = ",".join(f"{cost}:{count}" for cost, count in sorted(costs.items()))
        print(f"OP={op:04X} {label:<9} cycles[count]={rendered}")

    return 1 if malformed or delta_mismatches else 0


if __name__ == "__main__":
    raise SystemExit(main())
