#!/usr/bin/env python3
"""Fail-closed hierarchy gate over an ELABORATED design, not over source text.

WHY NOT GREP THE RTL
--------------------
tools/audit_smashtv_recovery_transfer.py already proves module reachability by
parsing source.  That is a static argument about what *could* be instantiated.
This gate reads the module scope table out of an Icarus `.vvp` image, which is
the tool's own record of what actually got elaborated after every `ifdef`,
parameter, and generate condition resolved.  The two instruments disagree in
exactly the cases that matter (a stale define, a wrong CORE_TOP macro, a
generate block that did not take), so both are kept.

The `.vvp` scope table lines look like:

    S_<id> .scope module, "<instance>" "<type>" <file> <line>, ... , S_<parent>;

Usage:
  check_elab_hierarchy.py IMAGE.vvp --top emu \
      --require yunit_top_smash_firefix --require ... \
      --forbid yunit_top --forbid ...

Exits non-zero if the root type is wrong, a required type is absent, or a
forbidden type is present.  Prints the full elaborated hierarchy so a failure
is diagnosable without re-running the elaboration.
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

# The parent scope id is the LAST comma-separated field, and it is absent on the
# elaboration root. Everything between the type name and the terminating `;` is
# file/line bookkeeping, so it has to be skipped explicitly -- an earlier version
# anchored `\s*;` straight after the optional parent group and therefore silently
# dropped the root scope, which made the --root-type check unsatisfiable.
SCOPE_RE = re.compile(
    r'^(S_[0-9a-fA-Fx]+)\s+\.scope\s+(\w+),\s*"([^"]+)"\s+"([^"]+)"'
    r'(?:[^;]*?,\s*(S_[0-9a-fA-Fx]+))?[^;]*;',
    re.MULTILINE)


def load_scopes(image: Path) -> tuple[dict, dict]:
    """Return (module_scopes, all_scopes).

    Two dicts, because they answer different questions. `module_scopes` is what
    the require/forbid checks run over. `all_scopes` also holds generate/begin/
    function scopes, and exists only so a hierarchy path can be walked to the
    root: a module instantiated inside `generate if (...)` has a generate scope
    as its parent, and resolving parents against modules alone silently truncates
    that path to a bare leaf -- which is exactly the case a failure report needs
    to be able to point at.

    The parent scope id is the LAST comma-separated field and is absent on the
    elaboration root. Everything between the type name and the terminating `;` is
    file/line bookkeeping, so it has to be skipped explicitly -- an earlier
    version anchored `\\s*;` straight after the optional parent group and
    therefore dropped the root scope, making --root-type unsatisfiable.
    """
    text = image.read_text(encoding="utf-8", errors="replace")
    modules: dict[str, tuple[str, str, str | None]] = {}
    every: dict[str, tuple[str, str, str | None]] = {}
    for m in SCOPE_RE.finditer(text):
        sid, kind, inst, typ, parent = m.groups()
        every[sid] = (inst, typ, parent)
        if kind == "module":
            modules[sid] = (inst, typ, parent)
    if not modules:
        raise SystemExit(
            f"{image}: no module scopes found -- the instrument is broken, "
            "not the design (check the .vvp was written by iverilog)")
    return modules, every


def path_of(every: dict[str, tuple[str, str, str | None]], sid: str) -> str:
    parts: list[str] = []
    seen: set[str] = set()
    while sid in every and sid not in seen:
        seen.add(sid)
        inst, typ, parent = every[sid]
        parts.append(inst if inst == typ and inst.startswith("$") else f"{inst}:{typ}")
        sid = parent  # type: ignore[assignment]
    return "/".join(reversed(parts))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("image", type=Path)
    ap.add_argument("--top", required=True,
                    help="expected instance name of the elaboration root")
    ap.add_argument("--root-type",
                    help="expected module type of the elaboration root")
    ap.add_argument("--require", action="append", default=[],
                    metavar="MODULE", help="module type that must be present")
    ap.add_argument("--forbid", action="append", default=[],
                    metavar="MODULE", help="module type that must be absent")
    args = ap.parse_args()

    scopes, every = load_scopes(args.image)
    types = {typ for _, typ, _ in scopes.values()}
    roots = [sid for sid, (_, _, parent) in scopes.items() if parent is None]

    paths = sorted(path_of(every, sid) for sid in scopes)
    print(f"elaborated module scopes: {len(paths)}")
    for p in paths:
        print(f"  {p}")

    failures: list[str] = []

    root_types = {scopes[sid][1] for sid in roots}
    root_insts = {scopes[sid][0] for sid in roots}
    if args.top not in root_insts:
        failures.append(
            f"elaboration root instance {args.top!r} not found; roots={sorted(root_insts)}")
    if args.root_type and args.root_type not in root_types:
        failures.append(
            f"root type {args.root_type!r} not found; root types={sorted(root_types)}")

    for module in args.require:
        if module not in types:
            failures.append(f"REQUIRED module absent from elaboration: {module}")
    for module in args.forbid:
        if module in types:
            hits = [p for p in paths if p.endswith(f":{module}") or f":{module}/" in p]
            failures.append(
                f"FORBIDDEN module present in elaboration: {module} "
                f"(at {hits[0] if hits else '?'})")

    if failures:
        print()
        for f in failures:
            print(f"FAIL: {f}", file=sys.stderr)
        print(f"elaborated-hierarchy gate FAILED: {len(failures)} problem(s)",
              file=sys.stderr)
        return 1

    print(f"\nelaborated-hierarchy gate PASS: root {args.top}"
          f"{':' + args.root_type if args.root_type else ''}, "
          f"{len(args.require)} required present, "
          f"{len(args.forbid)} forbidden absent")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
