#!/usr/bin/env python3
"""Generate and validate the parent-set MRAs for the runtime Y-unit core."""
from __future__ import annotations

import argparse
import html
import zipfile
from pathlib import Path

MAX_ACTION_BUTTONS = 6

# ONE core serves every Y-unit title. It carries the 8 MB graphics region that
# Mortal Kombat and Terminator 2 need (PLANE_WORDS 0x100000) and BOTH sound
# boards, selected per title at runtime by the MRA's index-3 profile byte.
#
# Carrying both boards only became affordable once CVSD sound moved from BRAM
# to SDRAM: the three 64 KiB sample BRAMs measured 192 of 553 device M10Ks,
# whereas the ADPCM board's second YM2151 costs ~9 because its samples already
# stream from SDRAM.
FULL_RBF_STEM = "Arcade-SmashTV-YUnit-Full"
# AUDIO-SPLIT SIBLINGS. The all-title FULL core was rejected on the cabinet; carrying both
# sound boards is what forced CVSD sound off its cabinet-proven BRAM residence. The family is
# now two cores divided by sound board, so the MRA/core pairing varies by sound board again.
CVSD_RBF_STEM  = "Arcade-SmashTV-YUnit-Family2"
ADPCM_RBF_STEM = "Arcade-SmashTV-YUnit-ADPCM"
# Reduced-scope fallback: the 4 MB CVSD-only core, buildable if the full core
# has trouble. Its MRAs are not shipped by default -- regenerate with
# --rbf-stem Arcade-SmashTV-YUnit-Family2 (CVSD titles only).
FALLBACK_CVSD_RBF_STEM = "Arcade-SmashTV-YUnit-Family2"


def rbf_stem_for(game: dict) -> str:
    """Which core this title's MRA must name.

    Derived from the title's SOUND BOARD, because the family is now two sibling cores.
    This must stay DERIVED rather than passed: a stale global stem silently produces MRAs
    naming a core that is not on the SD card, and those simply fail to load.

    Worse than failing to load: while this returned one stem for every title, the ten
    generated MRAs pointed Mortal Kombat, Terminator 2 and Total Carnage at the CVSD
    sibling -- a core with NO ADPCM board -- so those three would have loaded against
    hardware physically incapable of running their sound.
    """
    return ADPCM_RBF_STEM if game["sound"][0] == "adpcm" else CVSD_RBF_STEM

PROGRAM_LANE_BYTES = 0x80000

# Assembly/MAME release oracle.  The generic high-byte check below catches an
# obviously unmapped vector for every title; Smash T.V. additionally has an
# exact, source-grounded first-silicon contract.
EXPECTED_RESET_VECTORS = {
    "smashtv": 0xFFE0F5C0,
}

GAMES = {
    "trog": dict(
        title="Trog (rev LA5 3/29/91)", year=1990, maker="Midway", profile=1,
        gfx=[
            "trog_ii_u-111_la-1.u111", "trog_ii_u-112_la-1.u112", "trog_ii_u-113_la-1.u113", 0x20000,
            "trog_ii_u-106_la-1.u106", "trog_ii_u-107_la-1.u107",
            "trog_ii_u-95_la-1.u95", "trog_ii_u-96_la-1.u96", "trog_ii_u-97_la-1.u97", 0x20000,
            "trog_ii_u-90_la-1.u90", "trog_ii_u-91_la-1.u91",
        ],
        prog=("trog_ii_u-105_la-5.u105", "trog_ii_u-89_la-5.u89", 0x60000),
        sound=("cvsd", ["trog_ii_u-4_sl_1.u4", "trog_ii_u-19_sl_1.u19", "trog_ii_u-20_sl_1.u20"]),
        players=4, buttons="Punch,Start,Coin",
        button_defaults=("B",),  # Xbox-positional: A=Punch
        dsw="FF,DF", test_bit=8,
    ),
    "smashtv": dict(
        title="Smash T.V. (rev 8.00)", year=1990, maker="Williams", profile=0,
        gfx=[
            "la1_smash_tv_game_rom_u111.u111", "la1_smash_tv_game_rom_u112.u112", "la1_smash_tv_game_rom_u113.u113",
            "la1_smash_tv_game_rom_u95.u95", "la1_smash_tv_game_rom_u96.u96", "la1_smash_tv_game_rom_u97.u97",
            "la1_smash_tv_game_rom_u106.u106", "la1_smash_tv_game_rom_u107.u107", "la1_smash_tv_game_rom_u108.u108",
        ],
        prog=("la8_smash_tv_game_rom_u105.u105", "la8_smash_tv_game_rom_u89.u89", 0x60000),
        sound=("cvsd", ["sl2_smash_tv_sound_rom_u4.u4", "sl2_smash_tv_sound_rom_u19.u19", "sl2_smash_tv_sound_rom_u20.u20"]),
        # Keep the cabinet-proven firefix/mixboot diamond: the four face
        # buttons are spatially Up/Down/Left/Right, not alphabetically mapped.
        # Smash's source SWTAB also assigns IN1 bit 6 to Service Credit, so
        # expose that otherwise-unreachable cabinet input on L.
        players=2,
        buttons="Fire Up,Fire Down,Fire Left,Fire Right,Service Credit,Start,Coin",
        button_defaults=("X", "B", "Y", "A", "L"),  # Xbox-positional fire diamond
        dsw="FF,FF", test_bit=15,
    ),
    "hiimpact": dict(
        title="High Impact Football (rev LA5 02/15/91)", year=1990, maker="Williams", profile=2,
        gfx=[f"la1_high_impact_game_rom_u{n}.u{n}" for n in (111,112,113,114,95,96,97,98,106,107,108,109)],
        prog=("la5_high_impact_game_rom_u105.u105", "la5_high_impact_game_rom_u89.u89", 0x60000),
        sound=("cvsd", ["sl1_high_impact_sound_u4.u4", "sl1_high_impact_sound_u19.u19", "sl1_high_impact_sound_u20.u20"]),
        players=4, buttons="Action,Start,Coin",
        button_defaults=("B",),  # Xbox-positional: A=Action
        dsw="FF,FF", test_bit=8,
    ),
    "shimpact": dict(
        title="Super High Impact (rev LA2 10/22/91)", year=1991, maker="Midway", profile=3,
        gfx=[f"la1_super_high_impact_game_rom_u{n}.u{n}" for n in (111,112,113,114,95,96,97,98,106,107,108,109)],
        prog=("la2_super_high_impact_game_rom_u105.u105", "la2_super_high_impact_game_rom_u89.u89", 0x60000),
        sound=("cvsd", ["sl1_super_high_impact_u4_sound_rom.u4", "sl1_super_high_impact_u19_sound_rom.u19", "sl1_super_high_impact_u20_sound_rom.u20"]),
        players=4, buttons="Action,Start,Coin",
        button_defaults=("B",),  # Xbox-positional: A=Action
        dsw="FE,FF", test_bit=8,
    ),
    "strkforc": dict(
        title="Strike Force (rev 1 02/25/91)", year=1991, maker="Midway", profile=4,
        gfx=[f"la1_strike_force_game_rom_u{n}.u{n}" for n in (111,112,113,114,106,107,95,96,97,98,90,91)],
        prog=("la1_strike_force_game_rom_u105.u105", "la1_strike_force_game_rom_u89.u89", 0x60000),
        sound=("cvsd", ["sl1_strike_force_sound_rom_u4.u4", "sl1_strike_force_sound_rom_u19.u19", "sl1_strike_force_sound_rom_u20.u20"]),
        players=2, buttons="Fire,Weapon,Weapon Select,Start,Coin",
        button_defaults=("B", "A", "Y"),  # Xbox-positional: A=Fire B=Weapon X=Select
        dsw="FF,FF", test_bit=15,
    ),
    "saurnfrnt": dict(
        title="Saurian Front (proto v5.0 08/07/90)", year=1991, maker="Williams", profile=9,
        archive="strkforc",
        gfx=[f"saurnfrnt/pa1_saurian_front_game_rom_u{n}.u{n}"
             for n in (111,112,113,114,106,107,95,96,97,98,90,91)],
        prog=("saurnfrnt/pa1_saurian_front_game_rom_u105.u105",
              "saurnfrnt/pa1_saurian_front_game_rom_u89.u89", 0x60000),
        sound=("cvsd", [
            "saurnfrnt/pa1_saurian_front_sound_rom_u4.u4",
            "saurnfrnt/pa1_saurian_front_sound_rom_u19.u19",
            "saurnfrnt/pa1_saurian_front_sound_rom_u20.u20",
        ]),
        players=2, buttons="Fire,Weapon,Weapon Select,Start,Coin",
        button_defaults=("B", "A", "Y"),  # Xbox-positional: A=Fire B=Weapon X=Select
        dsw="FF,36", test_bit=14,
    ),
    "mk": dict(
        title="Mortal Kombat (rev 4.0 09/28/92, Y-Unit)", year=1992, maker="Midway", profile=5,
        gfx=[f"mkla1/l1_mortal_kombat_game_rom_u-{n}.u{n}" for n in (111,112,113,114,95,96,97,98,106,107,108,109)],
        prog=("mkla4/l4_mortal_kombat_game_rom_u-105.u105", "mkla4/l4_mortal_kombat_game_rom_u-89.u89", 0),
        sound=("adpcm", ["sl1_mortal_kombat_u3_sound_rom.u3", "sl1_mortal_kombat_u12_sound_rom.u12", "sl1_mortal_kombat_u13_sound_rom.u13"]),
        players=2, buttons="High Punch,Low Punch,Block,High Kick,Low Kick,Block 2,Start,Coin",
        # Xbox-pad layout the operator asked for: punches on the left column,
        # kicks on the right, block on the bumpers.
        #   High Punch X   Low Punch A   Block      L
        #   High Kick  Y   Low Kick  B   Block 2    R
        button_defaults=("Y", "B", "L", "X", "A", "R"),  # Xbox-positional: X=HP A=LP LB=BLK Y=HK B=LK RB=BLK2
        dsw="FF,DF", test_bit=8,
    ),
    "term2": dict(
        title="Terminator 2 - Judgment Day (rev LA4 08/03/92)", year=1991, maker="Midway", profile=6,
        gfx=[f"la1_terminator_2_game_rom_u{n}.u{n}" for n in (111,112,113,114,95,96,97,98,106,107,108,109)],
        prog=("la4_terminator_2_game_rom_u105.u105", "la4_terminator_2_game_rom_u89.u89", 0),
        sound=("adpcm", ["sl1_terminator_2_u3_sound_rom.u3", "sl1_terminator_2_u12_sound_rom.u12", "sl1_terminator_2_u13_sound_rom.u13"]),
        players=2, buttons="Trigger,Bomb,P2 Trigger,P2 Bomb,Start,Coin",
        # MiSTer A/B tokens are SNES-position names: B/A put T2's primary
        # Trigger/Bomb on the Xbox-position A/B buttons.  X/Y are dedicated
        # one-pad aliases for gun 2; the second controller's primary pair also
        # continues to drive gun 2 normally.
        button_defaults=("B", "A", "X", "Y"),
        dsw="FB,DF", test_bit=8,
    ),
    "totcarn": dict(
        title="Total Carnage (rev LA1 03/10/92)", year=1992, maker="Midway", profile=7,
        gfx=[f"la1_total_carnage_game_rom_u{n}.u{n}" for n in (111,112,113,114,95,96,97,98,106,107,108,109)],
        prog=("la1_total_carnage_game_rom_u105.u105", "la1_total_carnage_game_rom_u89.u89", 0x40000),
        sound=("adpcm", ["sl1_total_carnage_sound_rom_u3.u3", "sl1_total_carnage_sound_rom_u12.u12", "sl1_total_carnage_sound_rom_u13.u13"]),
        players=2, buttons="Fire Up,Fire Down,Fire Left,Fire Right,Start,Coin",
        button_defaults=("X", "B", "Y", "A"),  # Xbox-positional fire diamond
        dsw="BF,FF", test_bit=8,
    ),
    "yunittst": dict(
        title="Y-Unit Test ROM", year=1991, maker="Williams", profile=8,
        gfx=[0x120000],
        prog=("y_unit_test_u105.u105", "y_unit_test_u89.u89", 0x60000),
        sound=("none", []), players=2,
        # MAME's yunittst port definition includes the High Impact panel:
        # directions plus one action per player.
        buttons="Action,Start,Coin",
        dsw="FF,FF", test_bit=None,
    ),
}

PROFILE_PLANE_WORDS = {
    0: 0x30000,  # Smash TV
    1: 0x60000,  # Trog (includes the per-plane ROM hole)
    2: 0x40000,  # High Impact
    3: 0x80000,  # Super High Impact
    4: 0x60000,  # Strike Force
    5: 0x100000, # Mortal Kombat
    6: 0x100000, # Terminator 2
    7: 0x80000,  # Total Carnage
    8: 0x30000,  # Y-unit test placeholder
    9: 0x60000,  # Saurian Front (Strike Force silicon, distinct DIP contract)
}


def part(info: dict[str, zipfile.ZipInfo], name: str) -> str:
    if name not in info:
        raise KeyError(f"missing ROM member: {name}")
    return f'        <part name="{html.escape(name)}" crc="{info[name].CRC:08x}"/>'


def fill(count: int) -> str:
    return f'        <part repeat="0x{count:x}">00</part>'


def sound_parts(kind: str, names: list[str], info: dict[str, zipfile.ZipInfo]) -> list[str]:
    if kind == "none":
        return [fill(0x60000)]
    if kind == "cvsd":
        out = []
        for name in names:
            size = info[name].file_size
            if size not in (0x10000, 0x20000):
                raise ValueError(f"{name}: unexpected CVSD size {size:#x}")
            out.append(part(info, name))
            if size == 0x10000:  # 64K EPROM mirrors into the A16 half
                out.append(part(info, name))
        return out
    cpu, u12, u13 = names
    out = [part(info, cpu)]
    if info[cpu].file_size == 0x20000:
        out.append(part(info, cpu))
    elif info[cpu].file_size != 0x40000:
        raise ValueError(f"{cpu}: unexpected ADPCM CPU size")
    # Canonical OKI region is 1MB: U12 at 0/0x40000, U13 at 0x80000/0xc0000.
    out.extend((part(info, u12), part(info, u12), part(info, u13), part(info, u13)))
    return out


def generate(setname: str, game: dict, rom_dir: Path, out_dir: Path, rbf_stem=FULL_RBF_STEM) -> Path:
    archive_set = game.get("archive", setname)
    archive = rom_dir / f"{archive_set}.zip"
    with zipfile.ZipFile(archive) as zf:
        info = {z.filename: z for z in zf.infolist()}
        gfx = [fill(x) if isinstance(x, int) else part(info, x) for x in game["gfx"]]
        raw_gfx_bytes = sum(x if isinstance(x, int) else info[x].file_size
                            for x in game["gfx"])
        planes = 2 if game["profile"] in (1, 4, 9) else 3
        expected_gfx_bytes = PROFILE_PLANE_WORDS[game["profile"]] * 2 * planes
        if raw_gfx_bytes != expected_gfx_bytes:
            raise ValueError(
                f"{setname}: raw graphics stream is {raw_gfx_bytes:#x}, "
                f"expected {expected_gfx_bytes:#x}"
            )
        lo, hi, offset = game["prog"]
        prog = []
        lane_images = []
        for name in (lo, hi):
            lane = bytearray(PROGRAM_LANE_BYTES)
            image = zf.read(name)
            lane[offset:offset + len(image)] = image
            lane_images.append(lane)
            if offset: prog.append(fill(offset))
            prog.append(part(info, name))
            remain = PROGRAM_LANE_BYTES - offset - info[name].file_size
            if remain < 0:
                raise ValueError(
                    f"{name}: lane exceeds {PROGRAM_LANE_BYTES:#x}"
                )
            if remain: prog.append(fill(remain))
        reset_vector = (
            lane_images[0][-2] | (lane_images[1][-2] << 8)
            | (lane_images[0][-1] << 16) | (lane_images[1][-1] << 24)
        )
        if reset_vector >> 24 != 0xff:
            raise ValueError(f"{setname}: bad TMS34010 reset vector {reset_vector:08x}")
        expected_reset_vector = EXPECTED_RESET_VECTORS.get(setname)
        if (
            expected_reset_vector is not None
            and reset_vector != expected_reset_vector
        ):
            raise ValueError(
                f"{setname}: reset vector {reset_vector:08x} != "
                f"assembly/MAME oracle {expected_reset_vector:08x}"
            )
        skind, snames = game["sound"]
        sound = sound_parts(skind, snames, info)

    # The MRA override is the live MiSTer button list. Entry N binds joystick
    # bit 4+N, with Start/Coin immediately after the title's real actions. The
    # RTL derives the same positions from game_id (yunit_action_buttons).
    action_names = [
        name for name in game["buttons"].split(",")
        if name not in ("Start", "Coin")
    ]
    if len(action_names) > MAX_ACTION_BUTTONS:
        raise ValueError(
            f"{setname}: buttons table declares {len(action_names)} action "
            f"slots, above the core maximum {MAX_ACTION_BUTTONS}"
        )
    button_names = ",".join((*action_names, "Start", "Coin"))
    action_defaults = list(game.get("button_defaults", ()))
    # Fill defaults only for the real actions, keeping one token per name.
    for tok in ("A", "B", "X", "Y", "L", "R"):
        if len(action_defaults) >= len(action_names):
            break
        if tok not in action_defaults:
            action_defaults.append(tok)
    if len(action_defaults) != len(action_names):
        raise ValueError(
            f"{setname}: {len(action_names)} actions but "
            f"{len(action_defaults)} button defaults"
        )
    button_defaults = ",".join((*action_defaults, "Start", "Select"))
    # MiSTer DIP ids are ordered for bit value 0, then bit value 1.
    test_ids = "Off,On" if game["profile"] == 9 else "On,Off"

    lines = [
        "<misterromdescription>",
        '    <about author="rejectedcoins"/>',
        "    <rotation>horizontal</rotation>",
        f"    <name>{html.escape(game['title'])}</name>",
        f"    <setname>{setname}</setname>",
        "    <mameversion>0280</mameversion>",
        f"    <year>{game['year']}</year>",
        f"    <manufacturer>{game['maker']}</manufacturer>",
        f"    <players>{game['players']}</players>",
        f"    <rbf>{rbf_stem}</rbf>",
        "    <joystick>8</joystick>",
        f'    <rom index="3"><part>{game["profile"]:02x}</part></rom>',
        '    <nvram index="4" size="32768"></nvram>',
        f'    <rom index="0" zip="{archive_set}.zip">',
        *gfx, "    </rom>",
        f'    <rom index="1" zip="{archive_set}.zip">',
        *prog, "    </rom>",
        f'    <rom index="2" zip="{archive_set}.zip">',
        *sound, "    </rom>",
        (f'    <switches default="{game["dsw"]}"><dip name="Test Switch" '
         f'bits="{game["test_bit"]}" ids="{test_ids}"/></switches>'
         if game["test_bit"] is not None
         else f'    <switches default="{game["dsw"]}"/>'),
        f'    <buttons names="{button_names}" default="{button_defaults}" count="{len(action_names)}"/>',
        "</misterromdescription>",
        "",
    ]
    safe_title = game["title"].replace("/", "-").replace("\\", "-")
    path = out_dir / f"{safe_title}.mra"
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("rom_dir", type=Path)
    ap.add_argument("--out", type=Path, default=Path("releases/yunit"))
    # The MRA names the core it loads. Family MRAs keep the historical stem;
    # family2 MRAs (PLAN-family2-rebase.md) must name the family2 RBF so the
    # coherent triple (MRA layout + mapper + physical map) cannot be split
    # across cores by a stale descriptor.
    #
    # The stem is DERIVED PER TITLE, not passed globally. The CVSD titles and
    # the ADPCM titles are served by two different cores, so a single global
    # stem is always wrong for one of them -- and a stale one is silently fatal:
    # an MRA naming a core that is not on the SD card simply fails to load.
    # Deriving it from the title's own sound board makes the MRA/core pairing
    # unbreakable by a forgotten command-line flag.
    ap.add_argument("--rbf-stem", default=None,
                    help="override the derived per-title RBF stem "
                         "(diagnostic use only)")
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    for setname, game in GAMES.items():
        stem = args.rbf_stem or rbf_stem_for(game)
        path = generate(setname, game, args.rom_dir, args.out, rbf_stem=stem)
        print(f"{path}  [{stem}]")


if __name__ == "__main__":
    main()
