#!/usr/bin/env bash
# Assemble a DIAGNOSTIC RBF from a retained fit that FAILED the timing gate.
#
# This is deliberately a SEPARATE, MANUAL step. The timing gate is not relaxed
# and build_hw.sh is not modified: a build that misses setup must still fail.
# Producing an instrument image from that fit is an explicit human decision, and
# this script exists so the decision is recorded rather than smuggled in.
#
# WHY IT IS DEFENSIBLE FOR AN INSTRUMENT, AND ONLY AN INSTRUMENT
#   * The failing corners are Slow 1100mV at 100C and -40C -- worst-case silicon
#     at temperature extremes. A bench DE10-Nano is typical silicon at room
#     temperature, nowhere near either.
#   * dbg_iol_drop is a sticky counter latched during the ROM download, which
#     happens once at boot over hundreds of milliseconds. It is not a per-frame
#     hot path.
#   * The failing paths are in yunit_mem / yunit_dma (a_q -> win_s_q,
#     o_ptr -> brd_len), not in the counter block or the overlay.
#
# HOW TO READ THE RESULT HONESTLY
#   A NON-ZERO row1 is strong evidence: download words were dropped.
#   A ZERO row1 is SUGGESTIVE ONLY -- zero is also what a subtly broken counter
#   reads. Before believing a zero, confirm the instrument is alive:
#     row3 (dbg_iol_wrs) must climb to a sane accepted-push count, and
#     row4 bit0 (unp_done) must be set.
#   That is the built-in responsiveness check. A zero with a dead row3 means
#   nothing at all.
#
# THIS RBF MUST NEVER BE TREATED AS A RELEASE.
set -euo pipefail

PROJECT="$(cd "$(dirname "$0")/.." && pwd -P)"
QBIN="${QBIN:-/c/intelFPGA_lite/17.0/quartus/bin64}"
REV=Arcade-SmashTV
STEM="${1:?usage: assemble_waived_diag.sh <output-stem>}"
LOCK_DIR=/tmp/fpga_quartus.lock

[ -f "$PROJECT/output_files/$REV.fit.rpt" ] || {
  echo "WAIVED_ASM_FAIL no retained fit at $PROJECT/output_files/$REV.fit.rpt" >&2; exit 66; }

# Refuse to assemble a fit whose timing we have not actually looked at.
STA="$PROJECT/output_files/$REV.sta.rpt"
[ -f "$STA" ] || { echo "WAIVED_ASM_FAIL no STA report to quote" >&2; exit 66; }

acquire() {
  local waited=0
  while ! mkdir "$LOCK_DIR" 2>/dev/null; do
    sleep 10; waited=$((waited+10))
    [ "$waited" -ge 3600 ] && { echo "WAIVED_ASM_FAIL lock wait timed out" >&2; exit 75; }
  done
  printf 'session=yunit:waived-asm\npid=%s\ncmd=assemble timing-WAIVED diagnostic\n' \
    "$$" > "$LOCK_DIR/owner"
}
release() {
  # rm the owner file FIRST: a bare rmdir on a non-empty directory fails
  # silently and leaks the lock. That exact bug blocked a sibling session for
  # 45 minutes on 2026-08-15.
  rm -f "$LOCK_DIR/owner" 2>/dev/null || true
  rmdir "$LOCK_DIR" 2>/dev/null || rm -rf "$LOCK_DIR" 2>/dev/null || true
}
trap release EXIT INT TERM

n=$(powershell.exe -NoProfile -Command \
      "@(Get-CimInstance Win32_Process -Filter \"Name LIKE 'quartus%'\").Count" \
      2>/dev/null | tr -d '\r\n ')
[ "${n:-0}" = "0" ] || { echo "WAIVED_ASM_FAIL $n Quartus process(es) already running" >&2; exit 75; }

acquire
echo "lock acquired"

"$QBIN/quartus_asm" "$REV" -c "$REV" | tail -4

RBF="$PROJECT/output_files/$REV.rbf"
[ -s "$RBF" ] || { echo "WAIVED_ASM_FAIL assembler produced no RBF" >&2; exit 1; }

mkdir -p "$PROJECT/releases"
cp -- "$RBF" "$PROJECT/releases/$STEM.rbf"
cmp -s "$RBF" "$PROJECT/releases/$STEM.rbf" || { echo "WAIVED_ASM_FAIL copy verify" >&2; exit 1; }
H=$(sha256sum "$PROJECT/releases/$STEM.rbf" | awk '{print toupper($1)}')

{
  echo "$STEM -- DIAGNOSTIC INSTRUMENT, TIMING WAIVED"
  echo
  echo "sha256 $H"
  echo "bytes  $(stat -c%s "$PROJECT/releases/$STEM.rbf")"
  echo "built  $(date -u +%Y-%m-%dT%H:%M:%SZ)  Quartus 17.0.2  device 5CSEBA6U23I7"
  echo
  echo "*** THIS BUILD FAILED THE TIMING GATE. IT IS NOT A RELEASE. ***"
  echo "Four-corner setup slack, quoted from the retained fit's STA:"
  grep -E "Analyzing|Worst-case setup slack" "$STA" 2>/dev/null \
    | paste - - 2>/dev/null | sed 's/Info[^:]*: */  /g' || true
  echo
  echo "Waiver rationale: the failing corners are worst-case silicon at 100C and"
  echo "-40C. A bench DE10-Nano is typical silicon at room temperature, nowhere"
  echo "near either. Accepted deliberately to obtain a cabinet reading from an"
  echo "instrument; this image is NOT and must never become a release."
  echo
  echo "READING IT HONESTLY -- the rule that applies to every counter here:"
  echo "  a NON-ZERO / MOVING counter is evidence."
  echo "  a ZERO / FROZEN counter is SUGGESTIVE ONLY, because zero is also what a"
  echo "  dead counter reads. Always confirm a companion counter is alive before"
  echo "  concluding anything from a zero."
  echo
  echo "Note these are PER-FRAME or BOOT-STICKY counters depending on the flavour."
  echo "Boot-sticky counters FREEZE once the download completes -- frozen is"
  echo "correct, not a fault."
} > "$PROJECT/releases/$STEM.provenance.txt"

echo "WAIVED_ASM_PASS $STEM.rbf sha256=$H"
