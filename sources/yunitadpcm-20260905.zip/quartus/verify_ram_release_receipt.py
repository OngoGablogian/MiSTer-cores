#!/usr/bin/env python3
"""Verify a RAM-gate receipt without pinning a fitter-dependent RAM total.

``ram_release_gate.py`` is the authority for fitted RAM safety.  This consumer
recomputes that gate from the exact evidence named on the command line, checks
that the saved JSON receipt is an untampered representation of the result, and
prints the measured total in one stable, machine-readable line.

The consumer-script lint is intentional.  A post-gate assertion such as
``"total_m10ks": 309`` turns a safe fitter-dependent implementation choice
into a false release failure.  Policy values (the 512/553 release ceiling) stay
fixed and fail closed; measured totals must remain dynamic.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import sys
from typing import Any, Iterable

import ram_release_gate


RECEIPT_PREFIX = "RAM_GATE_RECEIPT_V1"
FIXED_TOTAL_PATTERNS = (
    re.compile(r'"(?:hierarchy_)?total_m10ks"\s*:\s*\d+'),
    re.compile(r"\b(?:hierarchy_)?total_m10ks\s*=\s*\d+"),
)


def _load_json_object(path: Path, label: str) -> tuple[dict[str, Any] | None, list[str]]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        return None, [f"could not read {label}: {exc}"]
    if not isinstance(value, dict):
        return None, [f"{label} root is not a JSON object"]
    return value, []


def lint_consumer_script(path: Path) -> list[str]:
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        return [f"could not read consumer script: {exc}"]

    errors: list[str] = []
    for pattern in FIXED_TOTAL_PATTERNS:
        for match in pattern.finditer(text):
            line = text.count("\n", 0, match.start()) + 1
            errors.append(
                "consumer script pins fitted RAM total at "
                f"{path}:{line}: {match.group(0)!r}"
            )
    return errors


def _compare_input_record(
    label: str,
    receipt_record: Any,
    observed_record: dict[str, Any] | None,
) -> list[str]:
    errors: list[str] = []
    if not isinstance(receipt_record, dict):
        return [f"receipt has no valid {label} input record"]
    if observed_record is None:
        return [f"could not produce observed {label} input record"]

    for field in ("bytes", "sha256"):
        expected = receipt_record.get(field)
        observed = observed_record.get(field)
        if field == "sha256" and isinstance(expected, str):
            expected = expected.upper()
        if expected != observed:
            errors.append(
                f"{label} {field} disagrees with receipt: "
                f"{observed!r} vs {expected!r}"
            )
    return errors


def verify_receipt(
    receipt: dict[str, Any],
    fit_text: str,
    map_log: str,
    map_report: str,
    observed_inputs: dict[str, dict[str, Any]],
) -> tuple[dict[str, Any] | None, list[str]]:
    errors: list[str] = []
    recomputed = ram_release_gate.evaluate_evidence(fit_text, map_log, map_report)

    if recomputed.get("passed") is not True:
        errors.append("recomputed RAM release gate did not pass")
        for error in recomputed.get("errors", []):
            errors.append(f"recomputed gate: {error}")

    if receipt.get("passed") is not True:
        errors.append("receipt passed flag is not exactly true")
    if receipt.get("errors") != []:
        errors.append("receipt top-level errors are not exactly empty")

    for field in ("limits", "fitted", "ram_semantics"):
        if receipt.get(field) != recomputed.get(field):
            errors.append(f"receipt {field} disagrees with recomputed gate")

    receipt_inputs = receipt.get("inputs")
    if not isinstance(receipt_inputs, dict):
        errors.append("receipt inputs field is not an object")
        receipt_inputs = {}
    for label in ("fit_report", "map_log", "map_report"):
        errors.extend(
            _compare_input_record(
                label,
                receipt_inputs.get(label),
                observed_inputs.get(label),
            )
        )

    fitted = recomputed.get("fitted")
    limits = recomputed.get("limits")
    if not isinstance(fitted, dict) or not isinstance(limits, dict):
        errors.append("recomputed gate lacks fitted or limits object")
        return None, errors

    values = {
        "total_m10ks": fitted.get("total_m10ks"),
        "hierarchy_total_m10ks": fitted.get("hierarchy_total_m10ks"),
        "device_m10ks": fitted.get("device_m10ks"),
        "max_release_m10ks": limits.get("max_release_m10ks"),
    }
    for name, value in values.items():
        if isinstance(value, bool) or not isinstance(value, int):
            errors.append(f"recomputed {name} is not an integer")

    if not errors:
        total = values["total_m10ks"]
        hierarchy_total = values["hierarchy_total_m10ks"]
        device = values["device_m10ks"]
        limit = values["max_release_m10ks"]
        if total != hierarchy_total:
            errors.append(
                "recomputed fitted and hierarchy totals disagree: "
                f"{total} vs {hierarchy_total}"
            )
        if device != ram_release_gate.EXPECTED_DEVICE_M10KS:
            errors.append(
                f"recomputed device capacity is {device}, expected "
                f"{ram_release_gate.EXPECTED_DEVICE_M10KS}"
            )
        if limit != ram_release_gate.MAX_RELEASE_M10KS:
            errors.append(
                f"recomputed release limit is {limit}, expected "
                f"{ram_release_gate.MAX_RELEASE_M10KS}"
            )
        if total > limit:
            errors.append(f"recomputed fitted total {total} exceeds limit {limit}")

    return values if not errors else None, errors


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--receipt", type=Path, required=True)
    parser.add_argument("--fit-report", type=Path, required=True)
    parser.add_argument("--map-log", type=Path, required=True)
    parser.add_argument("--map-report", type=Path, required=True)
    parser.add_argument("--consumer-script", type=Path, required=True)
    args = parser.parse_args(argv)

    receipt, errors = _load_json_object(args.receipt, "RAM gate receipt")
    errors.extend(lint_consumer_script(args.consumer_script))

    fit_text, fit_record, fit_errors = ram_release_gate.read_evidence(
        args.fit_report, "fit report", ram_release_gate.MIN_REPORT_BYTES
    )
    map_log, map_log_record, map_log_errors = ram_release_gate.read_evidence(
        args.map_log, "map log", ram_release_gate.MIN_MAP_LOG_BYTES
    )
    map_report, map_report_record, map_report_errors = ram_release_gate.read_evidence(
        args.map_report, "map report", ram_release_gate.MIN_REPORT_BYTES
    )
    errors.extend(fit_errors)
    errors.extend(map_log_errors)
    errors.extend(map_report_errors)

    values: dict[str, Any] | None = None
    if receipt is not None and not errors:
        observed_inputs = {
            label: record
            for label, record in (
                ("fit_report", fit_record),
                ("map_log", map_log_record),
                ("map_report", map_report_record),
            )
            if record is not None
        }
        values, verify_errors = verify_receipt(
            receipt,
            fit_text,
            map_log,
            map_report,
            observed_inputs,
        )
        errors.extend(verify_errors)

    if errors or values is None:
        print("RAM_GATE_RECEIPT RESULT: FAIL", file=sys.stderr)
        for error in errors or ["receipt verification produced no result"]:
            print(f"  - {error}", file=sys.stderr)
        return 2

    print(
        f"{RECEIPT_PREFIX} "
        f"total_m10ks={values['total_m10ks']} "
        f"hierarchy_total_m10ks={values['hierarchy_total_m10ks']} "
        f"device_m10ks={values['device_m10ks']} "
        f"max_release_m10ks={values['max_release_m10ks']}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
