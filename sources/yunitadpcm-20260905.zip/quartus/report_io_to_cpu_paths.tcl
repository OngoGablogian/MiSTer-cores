# Read-only fitted-netlist audit of every reachable CPU/CDC endpoint launched by
# the TMS34010 I/O-register block.  One row is emitted for the worst setup path
# to each endpoint, for each logical source register and timing corner.

project_open -force -revision Arcade-SmashTV Arcade-SmashTV
create_timing_netlist -no_report

set out_path "quartus/io_to_cpu_paths.tsv"
set out [open $out_path w]
puts $out "record\tcorner\tsource_index\tsource_name\tsource_node\tpath_class\tconsumer\tdestination_node\tslack_ns\tdata_delay_ns\tlogic_levels\tstart_mc\tend_mc\tfrom_clock\tto_clock"

proc empty_register_collection {} {
    return [get_registers -nowarn {__codex_no_such_register__}]
}

proc append_to_collection {base register_name} {
    # foreach_in_collection yields an internal object id.  Resolve the stable
    # fitted register name back to a one-object collection before appending.
    # Quartus 17 treats a complete fitted name (including [bit] suffixes) as
    # a literal register filter; Tcl-style bracket escaping makes it miss.
    set item [get_registers -no_duplicates -nowarn $register_name]
    return [add_to_collection $base $item]
}

proc io_source_name {index} {
    set names {
        HESYNC HEBLNK HSBLNK HTOTAL VESYNC VEBLNK VSBLNK VTOTAL
        DPYCTL DPYSTRT DPYINT CONTROL HSTDATA HSTADRL HSTADRH HSTCTLL
        HSTCTLH INTENB INTPEND CONVSP CONVDP PSIZE PMASK RESERVED23
        RESERVED24 RESERVED25 RESERVED26 DPYTAP HCOUNT VCOUNT DPYADR REFCNT
    }
    return [lindex $names $index]
}

proc classify_path {source_index source_name destination} {
    if {($source_name eq "HCOUNT_LIVE" || $source_name eq "VCOUNT_LIVE") &&
        ([string match "*|io_rdata_q*" $destination] ||
         [string match "*|io_is_io_q*" $destination])} {
        return "live_counter_to_io_read_latch"
    }
    if {[string match "*|io_rdata_q*" $destination] ||
        [string match "*|io_is_io_q*" $destination]} {
        return "async_io_read_latch"
    }
    if {[string match "*|*:u_memcdc|*" $destination] ||
        [string match "*|u_memcdc|*" $destination]} {
        return "memory_cdc"
    }
    if {$source_index eq "16" || $source_index eq "17" || $source_index eq "18"} {
        return "interrupt_status"
    }
    if {$source_index eq "11" || $source_index eq "19" ||
        $source_index eq "20" || $source_index eq "21" ||
        $source_index eq "22"} {
        return "control_tap"
    }
    if {$source_name eq "HCOUNT_LIVE" || $source_name eq "VCOUNT_LIVE"} {
        return "live_counter_readback"
    }
    if {$source_name eq "TIMING_START"} {
        return "timing_start"
    }
    return "other_io_register"
}

proc consumer_name {destination} {
    foreach block {u_memcdc u_io_write_boundary u_regfile u_shiftreg u_alu u_divider u_video} {
        if {[string match "*|*:${block}|*" $destination] ||
            [string match "*|${block}|*" $destination]} {
            return $block
        }
    }
    if {[regexp {tms34010_core:u_core\|([^|\[]+)} $destination -> leaf]} {
        return "u_core/$leaf"
    }
    if {[regexp {([^|]+)\|([^|\[]+)} $destination -> block leaf]} {
        return "$block/$leaf"
    }
    return "unclassified"
}

proc emit_source_paths {out corner source_index source_name source_collection cpu_destinations} {
    set source_count [get_collection_size $source_collection]
    if {$source_count == 0} {
        puts $out "SOURCE\t$corner\t$source_index\t$source_name\t<none>\tno_fitted_source\t<none>\t<none>\t\t\t\t\t\t\t"
        return 0
    }

    set paths [get_timing_paths -setup -from $source_collection -to $cpu_destinations -npaths 5000 -nworst 1]
    set path_count [get_collection_size $paths]
    if {$path_count == 0} {
        puts $out "SOURCE\t$corner\t$source_index\t$source_name\t<collection:$source_count>\tno_reachable_cpu_endpoint\t<none>\t<none>\t\t\t\t\t\t\t"
        return 0
    }

    foreach_in_collection path $paths {
        set source [get_node_info [get_path_info -from $path] -name]
        set destination [get_node_info [get_path_info -to $path] -name]
        set path_class [classify_path $source_index $source_name $destination]
        set consumer [consumer_name $destination]
        set slack [get_path_info -slack $path]
        set data_delay [get_path_info -data_delay $path]
        set levels [get_path_info -num_logic_levels $path]
        set start_mc [get_path_info -setup_start_multicycle $path]
        set end_mc [get_path_info -setup_end_multicycle $path]
        set from_clock [get_clock_info -name [get_path_info -from_clock $path]]
        set to_clock [get_clock_info -name [get_path_info -to_clock $path]]
        puts $out "PATH\t$corner\t$source_index\t$source_name\t$source\t$path_class\t$consumer\t$destination\t$slack\t$data_delay\t$levels\t$start_mc\t$end_mc\t$from_clock\t$to_clock"
    }
    return $path_count
}

# Recreate exactly the CPU collection used by rtl/sdram.sdc, then remove every
# fitted register nested in u_io_regs.  This ensures the audit asks only about
# paths leaving the full-rate I/O block and entering CPU/CDC consumers.
set raw_cpu [get_registers {*tms34010_core:u_core|* *u_memcdc|cst* *u_memcdc|req_tgl* *u_memcdc|c_ack* *u_memcdc|c_rdata* *u_memcdc|ackt_sync* *u_memcdc|p_we* *u_memcdc|p_addr* *u_memcdc|p_size* *u_memcdc|p_wdata* *yunit_top:yunit_top|rd_cnt* *yunit_top:yunit_top|ack_q* *yunit_top:yunit_top|d_started* *yunit_top:yunit_top|d_prevpc* *yunit_top:yunit_top|dbg_derailed* *yunit_top:yunit_top|dbg_culprit_pc* *yunit_top:yunit_top|dbg_culprit_instr* *yunit_top:yunit_top|dbg_derail_pc*}]
set io_all [get_registers {*tms34010_core:u_core|*u_io_regs|*}]
set cpu_destinations [remove_from_collection $raw_cpu $io_all]

for {set i 0} {$i < 32} {incr i} {
    set io_sources($i) [empty_register_collection]
}
set hcount_sources [empty_register_collection]
set vcount_sources [empty_register_collection]
set timing_start_sources [empty_register_collection]
set dpyint_event_q_sources [empty_register_collection]
set wvp_set_q_sources [empty_register_collection]
set nmi_clear_q_sources [empty_register_collection]
set unparsed_sources [empty_register_collection]

foreach_in_collection node $io_all {
    set name [get_node_info $node -name]
    if {[regexp {\|io_reg\[([0-9]+)\]\[[0-9]+\]} $name -> index]} {
        set io_sources($index) [append_to_collection $io_sources($index) $name]
    } elseif {[string match "*|*:u_video|hcount*" $name] ||
              [string match "*|u_video|hcount*" $name]} {
        set hcount_sources [append_to_collection $hcount_sources $name]
    } elseif {[string match "*|*:u_video|vcount*" $name] ||
              [string match "*|u_video|vcount*" $name]} {
        set vcount_sources [append_to_collection $vcount_sources $name]
    } elseif {[string match "*|timing_start*" $name]} {
        set timing_start_sources [append_to_collection $timing_start_sources $name]
    } elseif {[string match "*|dpyint_event_q*" $name]} {
        set dpyint_event_q_sources [append_to_collection $dpyint_event_q_sources $name]
    } elseif {[string match "*|wvp_set_q*" $name]} {
        set wvp_set_q_sources [append_to_collection $wvp_set_q_sources $name]
    } elseif {[string match "*|nmi_clear_q*" $name]} {
        set nmi_clear_q_sources [append_to_collection $nmi_clear_q_sources $name]
    } else {
        set unparsed_sources [append_to_collection $unparsed_sources $name]
    }
}

puts $out "META\tALL\t\tCPU_DESTINATIONS\t[get_collection_size $cpu_destinations]\t\t\t\t\t\t\t\t\t\t"
puts $out "META\tALL\t\tIO_ALL\t[get_collection_size $io_all]\t\t\t\t\t\t\t\t\t\t"
puts $out "META\tALL\t\tHCOUNT_FITTED\t[get_collection_size $hcount_sources]\t\t\t\t\t\t\t\t\t\t"
puts $out "META\tALL\t\tVCOUNT_FITTED\t[get_collection_size $vcount_sources]\t\t\t\t\t\t\t\t\t\t"
puts $out "META\tALL\t\tTIMING_START_FITTED\t[get_collection_size $timing_start_sources]\t\t\t\t\t\t\t\t\t\t"
puts $out "META\tALL\t\tDPYINT_EVENT_Q_FITTED\t[get_collection_size $dpyint_event_q_sources]\t\t\t\t\t\t\t\t\t\t"
puts $out "META\tALL\t\tWVP_SET_Q_FITTED\t[get_collection_size $wvp_set_q_sources]\t\t\t\t\t\t\t\t\t\t"
puts $out "META\tALL\t\tNMI_CLEAR_Q_FITTED\t[get_collection_size $nmi_clear_q_sources]\t\t\t\t\t\t\t\t\t\t"
puts $out "META\tALL\t\tUNPARSED_IO_REGISTERS\t[get_collection_size $unparsed_sources]\t\t\t\t\t\t\t\t\t\t"
for {set i 0} {$i < 32} {incr i} {
    puts $out "META\tALL\t$i\t[io_source_name $i]\t[get_collection_size $io_sources($i)]\t\t\t\t\t\t\t\t\t\t"
}
flush $out

set total_paths 0
set operating_conditions [get_available_operating_conditions -all]
foreach_in_collection op $operating_conditions {
    set_operating_conditions $op
    read_sdc
    update_timing_netlist
    set corner [get_operating_conditions_info $op -display_name]
    regsub -all {\t} $corner { } corner
    puts "Auditing I/O-register paths at corner: $corner"

    for {set i 0} {$i < 32} {incr i} {
        incr total_paths [emit_source_paths $out $corner $i [io_source_name $i] $io_sources($i) $cpu_destinations]
    }
    incr total_paths [emit_source_paths $out $corner LIVE_HCOUNT HCOUNT_LIVE $hcount_sources $cpu_destinations]
    incr total_paths [emit_source_paths $out $corner LIVE_VCOUNT VCOUNT_LIVE $vcount_sources $cpu_destinations]
    incr total_paths [emit_source_paths $out $corner TIMING_START TIMING_START $timing_start_sources $cpu_destinations]
    incr total_paths [emit_source_paths $out $corner DPYINT_EVENT_Q DPYINT_EVENT_Q $dpyint_event_q_sources $cpu_destinations]
    incr total_paths [emit_source_paths $out $corner WVP_SET_Q WVP_SET_Q $wvp_set_q_sources $cpu_destinations]
    incr total_paths [emit_source_paths $out $corner NMI_CLEAR_Q NMI_CLEAR_Q $nmi_clear_q_sources $cpu_destinations]
    flush $out
}

puts $out "META\tALL\t\tTOTAL_PATH_ROWS\t$total_paths\t\t\t\t\t\t\t\t\t\t"
close $out
puts "Wrote $total_paths endpoint path rows to $out_path"
project_close
