#!/usr/bin/env bash
# build_sv2v.sh — Phase 6: down-convert all SystemVerilog to Quartus-17-friendly
# plain Verilog via sv2v, then Quartus synthesizes the .v output.
#
# WHY: Quartus Prime 17.0 Lite (the MiSTer-pinned version for Cyclone V) has a weak
# SystemVerilog front-end — it rejects size-casts `N'(...)`, header package-imports,
# and other constructs the vendored birdybro TMS34010 core + the Y-unit wrapper use
# (Questa/Icarus accept them). sv2v (github.com/zachjs/sv2v) resolves packages,
# params, and casts into Verilog-2005 that Quartus swallows cleanly — so the
# vendored core stays PRISTINE and we don't hand-patch casts. `-DSYNTHESIS` reuses
# the `ifndef SYNTHESIS` guard so the sim-only $readmemh/array-init loops are skipped.
#
# Usage:  SV2V=/path/to/sv2v.exe ./build_sv2v.sh   (default sv2v in /c/tools/sv2v)
set -e
# Codex/PowerShell may launch Git Bash without its own POSIX directories in PATH.
export PATH="/usr/bin:/mingw64/bin:$PATH"
SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/build_syn/smashtv_core.v"
mkdir -p "$ROOT/build_syn"

# SV set in dependency order: packages FIRST, then core, wrapper, sound-side SV.
SV=( "$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SV+=("$f"); done \
  < <(find "$ROOT/rtl/tms34010/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SV+=( "$ROOT/rtl/yunit/yunit_protection.sv" "$ROOT/rtl/yunit/yunit_nvram_bridge.sv" \
      "$ROOT/rtl/yunit/yunit_mem.sv" "$ROOT/rtl/yunit/yunit_dma.sv" \
      "$ROOT/rtl/yunit/yunit_dma_logical_timer.sv" "$ROOT/rtl/yunit/yunit_dma_descriptor_fifo.sv" \
      "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
      "$ROOT/rtl/yunit/vram_sdram_scanout.sv" \
      "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
      "$ROOT/rtl/yunit/yunit_memsys.sv" \
      "$ROOT/rtl/yunit/yunit_display_address_sequencer.sv" \
      "$ROOT/rtl/yunit/yunit_autoerase_scheduler.sv" \
      "$ROOT/rtl/yunit/yunit_autoerase_sdram_backend.sv" \
      "$ROOT/rtl/yunit/yunit_shiftreg_engine.sv" \
      "$ROOT/rtl/yunit/yunit_vram_word_arb.sv" \
      "$ROOT/rtl/yunit/yunit_video.sv" "$ROOT/rtl/yunit/yunit_scanline.sv" \
      "$ROOT/rtl/yunit/yunit_video_top.sv" "$ROOT/rtl/yunit/yunit_palram.sv" \
      "$ROOT/rtl/sdram/yunit_sdram_arb.sv" "$ROOT/rtl/sdram/yunit_sdram_burst_arb.sv" \
      "$ROOT/rtl/sdram/sdram_stock.sv" "$ROOT/rtl/sdram/yunit_sdram_adapter.sv" \
      "$ROOT/rtl/sdram/yunit_src_cache.sv" \
      "$ROOT/rtl/yunit/yunit_gfx_unpack.sv" \
      "$ROOT/rtl/yunit/yunit_download_mapper.sv" \
      "$ROOT/rtl/video/crt_adjust.sv" "$ROOT/rtl/video/yunit_crt_adjust.sv" \
      "$ROOT/rtl/yunit/yunit_mem_cdc.sv" "$ROOT/rtl/yunit/yunit_sound_cdc.sv" "$ROOT/rtl/yunit/yunit_sound_rom_cache.sv" "$ROOT/rtl/yunit/yunit_audio_mix.sv" "$ROOT/rtl/yunit/yunit_adpcm_board.sv" "$ROOT/rtl/yunit/yunit_input_mapper.sv" "$ROOT/rtl/yunit/yunit_twinstick.sv" "$ROOT/rtl/yunit/yunit_cpu_cadence.sv" "$ROOT/rtl/yunit/yunit_top.sv" \
      "$ROOT/rtl/yunit/smashtv_cabinet_inputs.sv" "$ROOT/rtl/yunit/smashtv_legacy_download_mapper.sv" \
      "$ROOT/rtl/yunit/yunit_mem_smash_firefix.sv" "$ROOT/rtl/yunit/yunit_dma_smash_firefix.sv" \
      "$ROOT/rtl/yunit/yunit_memsys_smash_firefix.sv" "$ROOT/rtl/yunit/yunit_video_smash_firefix.sv" \
      "$ROOT/rtl/yunit/yunit_scanline_smash_firefix.sv" "$ROOT/rtl/yunit/yunit_video_top_smash_firefix.sv" \
      "$ROOT/rtl/yunit/yunit_top_smash_firefix.sv" \
      "$ROOT/rtl/yunit/yunit_service_counters.sv" \
      "$ROOT/rtl/yunit/family2/family2_cabinet_inputs.sv" "$ROOT/rtl/yunit/family2/family2_download_mapper.sv" \
      "$ROOT/rtl/yunit/family2/yunit_mem_family2.sv" "$ROOT/rtl/yunit/family2/yunit_dma_family2.sv" \
      "$ROOT/rtl/yunit/family2/yunit_memsys_family2.sv" "$ROOT/rtl/yunit/family2/yunit_video_family2.sv" \
      "$ROOT/rtl/yunit/family2/yunit_scanline_family2.sv" "$ROOT/rtl/yunit/family2/yunit_video_top_family2.sv" \
      "$ROOT/rtl/yunit/family2/yunit_top_family2.sv" \
      "$ROOT/rtl/diag/smashtv_diag_top.sv" "$ROOT/rtl/diag/smashtv_diag2_overlay.sv" \
      "$ROOT/rtl/diag/yunit_diag_service_overlay.sv" \
      "$ROOT/rtl/diag/smashtv_diag_rom.sv" \
      "$ROOT/rtl/sound/smashtv_snd_rom.sv" )
# emu.sv (Arcade-SmashTV.sv) is Quartus-native SV (NOT sv2v'd): it instantiates
# yunit_top from this blob + sys/ modules by name; listed directly in files.qip.

echo "sv2v: ${#SV[@]} SV files -> $OUT ${SV2V_EXTRA:+(extra: $SV2V_EXTRA)}"
"$SV2V" -DSYNTHESIS ${SV2V_EXTRA:-} "${SV[@]}" > "$OUT"
echo "  $(wc -l < "$OUT") lines; size-casts remaining: $(grep -cE "[0-9A-Za-z_]+'\(" "$OUT")"
echo "Quartus reads build_syn/smashtv_core.v (Verilog) + the VHDL sound board + jt51/mc6809/pia (Verilog/VHDL)."
