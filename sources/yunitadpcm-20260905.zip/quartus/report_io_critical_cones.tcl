# Read-only full arrival-point dump for the cabmarch5 I/O-read timing evidence.
project_open -force -revision Arcade-SmashTV Arcade-SmashTV
create_timing_netlist -model slow -no_report
read_sdc
update_timing_netlist

set out [open "quartus/io_critical_cones.tsv" w]
puts $out "record\tlabel\tslack_ns\tdata_delay_ns\tlogic_levels\tpoint_index\tpoint_type\tincremental_delay_ns\tlocation\tfanout\tnode\tcell"

proc dump_cone {out label from_name to_name} {
    set from [get_registers -nowarn $from_name]
    set to [get_registers -nowarn $to_name]
    set paths [get_timing_paths -setup -from $from -to $to -npaths 1 -nworst 1]
    if {[get_collection_size $paths] == 0} {
        puts $out "MISSING\t$label\t\t\t\t\t\t\t\t\t$from_name\t$to_name"
        return
    }
    foreach_in_collection path $paths {
        set slack [get_path_info -slack $path]
        set delay [get_path_info -data_delay $path]
        set levels [get_path_info -num_logic_levels $path]
        set n 0
        foreach_in_collection point [get_path_info -arrival_points $path] {
            set type [get_point_info $point -type]
            set incr [get_point_info $point -incremental_delay]
            set location [get_point_info $point -location]
            set fanout [get_point_info $point -number_of_fanout]
            set node_id [get_point_info $point -node]
            set node_name ""
            set cell_name ""
            if {$node_id ne ""} {
                if {[catch {set node_name [get_node_info $node_id -name]}]} {
                    set node_name $node_id
                }
                if {![catch {set cell_id [get_node_info $node_id -cell]}] && $cell_id ne ""} {
                    catch {set cell_name [get_cell_info $cell_id -name]}
                }
            }
            puts $out "POINT\t$label\t$slack\t$delay\t$levels\t$n\t$type\t$incr\t$location\t$fanout\t$node_name\t$cell_name"
            incr n
        }
    }
}

set prefix {emu:emu|yunit_top:yunit_top|tms34010_core:u_core|}
set io_prefix "${prefix}tms34010_io_regs:u_io_regs|"
set rf_dest "${prefix}tms34010_regfile:u_regfile|a_regs\[13\]\[15\]"

dump_cone $out HSTCTLH_READ_FANOUT "${io_prefix}io_reg\[16\]\[8\]" $rf_dest
dump_cone $out INTENB_READ_FANOUT  "${io_prefix}io_reg\[17\]\[11\]" $rf_dest
dump_cone $out INTPEND_READ_FANOUT "${io_prefix}io_reg\[18\]\[11\]" $rf_dest
dump_cone $out REFCNT_ASYNC_LATCH  "${io_prefix}io_reg\[31\]\[2\]" "${prefix}io_rdata_q\[2\]_OTERM5183_OTERM6853"

set cdc_wdata3 {emu:emu|yunit_top:yunit_top|yunit_mem_cdc:u_memcdc|p_wdata[3]_OTERM907_OTERM4103}
dump_cone $out HSTCTLH_TO_CDC "${io_prefix}io_reg\[16\]\[8\]" $cdc_wdata3
dump_cone $out INTENB_TO_CDC  "${io_prefix}io_reg\[17\]\[11\]" $cdc_wdata3
dump_cone $out INTPEND_TO_CDC "${io_prefix}io_reg\[18\]\[11\]" $cdc_wdata3

close $out
project_close
