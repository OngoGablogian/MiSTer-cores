`default_nettype none
`default_nettype wire
`default_nettype none
`default_nettype wire
`default_nettype none
module tms34010_alu (
	op,
	a,
	b,
	cin,
	result,
	flags
);
	reg _sv2v_0;
	input wire [3:0] op;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	input wire [31:0] a;
	input wire [31:0] b;
	input wire cin;
	output reg [31:0] result;
	output reg [3:0] flags;
	wire [tms34010_pkg_DATA_WIDTH:0] add_ext;
	wire [tms34010_pkg_DATA_WIDTH:0] sub_ext;
	wire [31:0] not_b;
	wire add_cin;
	wire sub_cin;
	assign not_b = ~b;
	assign add_cin = (op == 4'd1 ? cin : 1'b0);
	assign sub_cin = (op == 4'd3 ? !cin : 1'b1);
	assign add_ext = ({1'b0, a} + {1'b0, b}) + {{tms34010_pkg_DATA_WIDTH {1'b0}}, add_cin};
	assign sub_ext = ({1'b0, a} + {1'b0, not_b}) + {{tms34010_pkg_DATA_WIDTH {1'b0}}, sub_cin};
	wire [31:0] add_result;
	wire [31:0] sub_result;
	wire [31:0] neg_result;
	wire [tms34010_pkg_DATA_WIDTH:0] neg_ext;
	wire [31:0] not_a;
	assign add_result = add_ext[31:0];
	assign sub_result = sub_ext[31:0];
	assign not_a = ~a;
	assign neg_ext = ({1'b0, {tms34010_pkg_DATA_WIDTH {1'b0}}} + {1'b0, not_a}) + 33'd1;
	assign neg_result = neg_ext[31:0];
	always @(*) begin
		if (_sv2v_0)
			;
		result = 1'sb0;
		flags[3] = 1'b0;
		flags[2] = 1'b0;
		flags[1] = 1'b0;
		flags[0] = 1'b0;
		(* full_case, parallel_case *)
		case (op)
			4'd0, 4'd1: begin
				result = add_result;
				flags[3] = add_result[31];
				flags[1] = add_result == {32 {1'sb0}};
				flags[2] = add_ext[tms34010_pkg_DATA_WIDTH];
				flags[0] = (a[31] == b[31]) && (add_result[31] != a[31]);
			end
			4'd2, 4'd3, 4'd4: begin
				result = sub_result;
				flags[3] = sub_result[31];
				flags[1] = sub_result == {32 {1'sb0}};
				flags[2] = b > a;
				flags[0] = (a[31] != b[31]) && (sub_result[31] != a[31]);
			end
			4'd10: begin
				result = neg_result;
				flags[3] = neg_result[31];
				flags[1] = neg_result == {32 {1'sb0}};
				flags[2] = !neg_ext[tms34010_pkg_DATA_WIDTH];
				flags[0] = a[31] && neg_result[31];
			end
			4'd5: begin
				result = a & b;
				flags[3] = result[31];
				flags[1] = result == {32 {1'sb0}};
			end
			4'd6: begin
				result = a & ~b;
				flags[3] = result[31];
				flags[1] = result == {32 {1'sb0}};
			end
			4'd7: begin
				result = a | b;
				flags[3] = result[31];
				flags[1] = result == {32 {1'sb0}};
			end
			4'd8: begin
				result = a ^ b;
				flags[3] = result[31];
				flags[1] = result == {32 {1'sb0}};
			end
			4'd9: begin
				result = ~a;
				flags[3] = result[31];
				flags[1] = result == {32 {1'sb0}};
			end
			4'd11: begin
				result = a;
				flags[3] = a[31];
				flags[1] = a == {32 {1'sb0}};
			end
			4'd12: begin
				result = b;
				flags[3] = b[31];
				flags[1] = b == {32 {1'sb0}};
			end
			4'd13: begin
				result = (neg_result[31] ? a : neg_result);
				flags[3] = neg_result[31];
				flags[1] = a == {32 {1'sb0}};
				flags[2] = 1'b0;
				flags[0] = a == 32'h80000000;
			end
			default:
				;
		endcase
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_core (
	clk,
	ce_cpu,
	ce_pix,
	rst,
	mem_req,
	mem_we,
	mem_addr,
	mem_size,
	mem_wdata,
	mem_rdata,
	mem_ack,
	state_o,
	pc_o,
	instr_word_o,
	illegal_opcode_o,
	instruction_start_o,
	instruction_retire_o,
	instruction_cycles_o,
	instruction_cycles_valid_o,
	timing_start_o,
	display_wr_valid_o,
	display_wr_idx_o,
	display_wr_data_o,
	display_line_wrap_o,
	display_dpyadr_live_i,
	display_dpyadr_live_valid_i,
	srt_fill_exact_enable_i,
	srt_fill_ack_i,
	shiftreg_req_o,
	shiftreg_write_o,
	shiftreg_bit_addr_o,
	lint1_in
);
	reg _sv2v_0;
	input wire clk;
	input wire ce_cpu;
	input wire ce_pix;
	input wire rst;
	output reg mem_req;
	output wire mem_we;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	output reg [31:0] mem_addr;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	output reg [5:0] mem_size;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	output reg [31:0] mem_wdata;
	input wire [31:0] mem_rdata;
	input wire mem_ack;
	output wire [5:0] state_o;
	output wire [31:0] pc_o;
	localparam [31:0] tms34010_pkg_INSTR_WORD_WIDTH = 16;
	output wire [15:0] instr_word_o;
	output wire illegal_opcode_o;
	output reg instruction_start_o;
	output reg instruction_retire_o;
	output wire [15:0] instruction_cycles_o;
	output wire instruction_cycles_valid_o;
	output wire timing_start_o;
	output wire display_wr_valid_o;
	localparam [31:0] tms34010_pkg_IO_REG_IDX_W = 5;
	output wire [4:0] display_wr_idx_o;
	output wire [15:0] display_wr_data_o;
	output wire display_line_wrap_o;
	input wire [15:0] display_dpyadr_live_i;
	input wire display_dpyadr_live_valid_i;
	input wire srt_fill_exact_enable_i;
	input wire srt_fill_ack_i;
	output wire shiftreg_req_o;
	output wire shiftreg_write_o;
	output wire [31:0] shiftreg_bit_addr_o;
	input wire lint1_in;
	reg pblt_w2_q;
	reg pblt_w1_q;
	wire pblt_array_hit;
	reg [1:0] drav_w_q;
	reg drav_inside_q;
	reg line_last_inside_q;
	reg line_aborted_q;
	wire line_win_en;
	wire [31:0] rf_rs1_data;
	wire [31:0] rf_rs2_data;
	wire [31:0] rf_rs3_data;
	wire is_fill;
	wire fill_is_xy;
	wire is_pblt;
	wire is_drav;
	wire is_line;
	wire pixt_rmw;
	reg [31:0] pix_dest_q;
	wire pixt_xy_win;
	reg pixt_inside_q;
	reg [4:0] pix_xy_xsh;
	wire [31:0] pix_xy_dst_linear;
	wire is_mpy;
	wire mpy_signed;
	wire mpy_rd_even;
	wire is_div;
	wire is_divu;
	wire is_modu;
	wire is_divs;
	wire is_mods;
	wire div_signed_ovf;
	wire div_v;
	wire is_pair_wb;
	wire pair_second_pass;
	reg pair_wb_step;
	wire [15:0] io_psize;
	wire [15:0] io_convdp;
	wire [15:0] io_convsp;
	wire [15:0] io_control;
	wire [15:0] io_pmask;
	wire [15:0] io_psize_live;
	wire [15:0] io_convdp_live;
	wire [15:0] io_convsp_live;
	wire [15:0] io_control_live;
	wire [15:0] io_pmask_live;
	wire [15:0] io_dpyctl_live;
	wire srt_pixt;
	wire wvp_set;
	wire [31:0] mem_rdata_eff;
	reg int_push_q;
	function automatic [31:0] ppop_apply;
		input reg [31:0] src;
		input reg [31:0] dest;
		input reg [4:0] ppop;
		input reg [31:0] fmask;
		reg [31:0] sp;
		reg [31:0] dp;
		reg [31:0] addsum;
		begin
			sp = src & fmask;
			dp = dest & fmask;
			addsum = dp + sp;
			(* full_case, parallel_case *)
			case (ppop)
				5'h00: ppop_apply = src;
				5'h01: ppop_apply = src & dest;
				5'h02: ppop_apply = src & ~dest;
				5'h03: ppop_apply = 1'sb0;
				5'h04: ppop_apply = src | ~dest;
				5'h05: ppop_apply = ~(src ^ dest);
				5'h06: ppop_apply = ~dest;
				5'h07: ppop_apply = ~(src | dest);
				5'h08: ppop_apply = src | dest;
				5'h09: ppop_apply = dest;
				5'h0a: ppop_apply = src ^ dest;
				5'h0b: ppop_apply = ~src & dest;
				5'h0c: ppop_apply = 1'sb1;
				5'h0d: ppop_apply = ~src | dest;
				5'h0e: ppop_apply = ~(src & dest);
				5'h0f: ppop_apply = ~src;
				5'h10: ppop_apply = addsum;
				5'h11: ppop_apply = (addsum > fmask ? fmask : addsum);
				5'h12: ppop_apply = dp - sp;
				5'h13: ppop_apply = (dp >= sp ? dp - sp : {32 {1'sb0}});
				5'h14: ppop_apply = (dp >= sp ? dp : sp);
				5'h15: ppop_apply = (dp <= sp ? dp : sp);
				default: ppop_apply = src;
			endcase
		end
	endfunction
	reg pc_advance_en;
	reg pc_load_en;
	reg [31:0] pc_load_value;
	wire [31:0] pc_value;
	localparam [5:0] tms34010_pkg_INSTR_WORD_BITS = 6'd16;
	localparam [31:0] tms34010_pkg_PC_ADVANCE_WIDTH = 8;
	function automatic [7:0] sv2v_cast_4E301;
		input reg [7:0] inp;
		sv2v_cast_4E301 = inp;
	endfunction
	tms34010_pc u_pc(
		.clk(clk),
		.ce_cpu(ce_cpu),
		.rst(rst),
		.load_en(pc_load_en),
		.load_value(pc_load_value),
		.advance_en(pc_advance_en),
		.advance_amount(sv2v_cast_4E301(tms34010_pkg_INSTR_WORD_BITS)),
		.pc_o(pc_value)
	);
	reg [5:0] state_q;
	reg [5:0] state_d;
	reg instruction_active_q;
	reg timing_interrupt_q;
	reg interrupt_timing_start;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				state_q <= 6'd0;
				instruction_active_q <= 1'b0;
				timing_interrupt_q <= 1'b0;
			end
			else begin
				state_q <= state_d;
				if (instruction_retire_o) begin
					instruction_active_q <= 1'b0;
					timing_interrupt_q <= 1'b0;
				end
				else if (instruction_start_o) begin
					instruction_active_q <= 1'b1;
					timing_interrupt_q <= interrupt_timing_start;
				end
			end
		end
	always @(*) begin
		if (_sv2v_0)
			;
		interrupt_timing_start = (ce_cpu && (state_q == 6'd1)) && ((state_d == 6'd18) || (state_d == 6'd19));
		instruction_start_o = (ce_cpu && (state_q == 6'd1)) && (((state_d == 6'd2) || (state_d == 6'd18)) || (state_d == 6'd19));
		instruction_retire_o = ((ce_cpu && instruction_active_q) && (state_q != 6'd1)) && (state_d == 6'd1);
	end
	reg [15:0] instr_word_q;
	wire [52:0] decoded_live;
	(* preserve *) reg [52:0] decoded;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				instr_word_q <= 1'sb0;
				decoded <= 1'sb0;
			end
			else if ((state_q == 6'd1) && mem_ack)
				instr_word_q <= mem_rdata_eff[15:0];
			else if (state_q == 6'd2)
				decoded <= decoded_live;
		end
	tms34010_decode u_decode(
		.instr(instr_word_q),
		.decoded(decoded_live)
	);
	reg illegal_q;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst)
				illegal_q <= 1'b0;
			else if ((state_q == 6'd2) && decoded_live[52])
				illegal_q <= 1'b1;
		end
	wire [31:0] branch_target_short;
	wire signed [15:0] disp_signed_12;
	assign disp_signed_12 = $signed({instr_word_q[7:0], 4'h0});
	function automatic signed [31:0] sv2v_cast_DEBC9_signed;
		input reg signed [31:0] inp;
		sv2v_cast_DEBC9_signed = inp;
	endfunction
	assign branch_target_short = pc_value + sv2v_cast_DEBC9_signed(disp_signed_12);
	reg [15:0] imm_lo_q;
	reg [15:0] imm_hi_q;
	reg [15:0] imm2_lo_q;
	reg [15:0] imm2_hi_q;
	wire [31:0] imm2_32 = {imm2_hi_q, imm2_lo_q};
	wire is_mv_abs_m2m = decoded[51-:7] == 7'd99;
	wire is_mv_off_m2m = decoded[51-:7] == 7'd100;
	wire is_mv_abs_ni = decoded[51-:7] == 7'd102;
	wire [31:0] imm2_off_sext = {{tms34010_pkg_DATA_WIDTH - tms34010_pkg_INSTR_WORD_WIDTH {imm2_lo_q[15]}}, imm2_lo_q};
	wire [31:0] branch_target_long;
	wire signed [19:0] disp_signed_20;
	assign disp_signed_20 = $signed({imm_lo_q, 4'h0});
	assign branch_target_long = pc_value + sv2v_cast_DEBC9_signed(disp_signed_20);
	wire [31:0] branch_target_jacc;
	assign branch_target_jacc = {imm_hi_q, imm_lo_q[15:4], 4'h0};
	wire [31:0] branch_target_dsjs;
	wire signed [9:0] dsjs_disp_bits;
	function automatic signed [9:0] sv2v_cast_10_signed;
		input reg signed [9:0] inp;
		sv2v_cast_10_signed = inp;
	endfunction
	assign dsjs_disp_bits = (instr_word_q[10] ? -sv2v_cast_10_signed($signed({1'b0, instr_word_q[9:5], 4'h0})) : sv2v_cast_10_signed($signed({1'b0, instr_word_q[9:5], 4'h0})));
	assign branch_target_dsjs = pc_value + sv2v_cast_DEBC9_signed(dsjs_disp_bits);
	reg [1:0] mem_op_step;
	reg [31:0] popped_st_q;
	reg [31:0] popped_pc_q;
	reg [31:0] move_data_q;
	reg [31:0] mv_load_data_q;
	wire trap_skip_push;
	assign trap_skip_push = (decoded[51-:7] == 7'd71) && (decoded[23-:5] == 5'd0);
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				mem_op_step <= 2'd0;
				popped_st_q <= 1'sb0;
				popped_pc_q <= 1'sb0;
				move_data_q <= 1'sb0;
				pix_dest_q <= 1'sb0;
			end
			else if ((state_q == 6'd6) && mem_ack) begin
				if ((decoded[51-:7] == 7'd76) && (mem_op_step == 2'd0))
					move_data_q <= mem_rdata_eff;
				if (((((decoded[51-:7] == 7'd99) || (decoded[51-:7] == 7'd100)) || (decoded[51-:7] == 7'd101)) || (decoded[51-:7] == 7'd102)) && (mem_op_step == 2'd0))
					move_data_q <= mem_rdata_eff;
				if (((decoded[51-:7] == 7'd74) && pixt_rmw) && (mem_op_step == 2'd0))
					pix_dest_q <= mem_rdata_eff;
				if (decoded[51-:7] == 7'd70) begin
					if (mem_op_step == 2'd0)
						popped_st_q <= mem_rdata_eff;
					if (mem_op_step == 2'd1)
						popped_pc_q <= mem_rdata_eff;
				end
				if (decoded[51-:7] == 7'd71) begin
					if (trap_skip_push) begin
						if (mem_op_step == 2'd0)
							popped_pc_q <= mem_rdata_eff;
					end
					else if (mem_op_step == 2'd2)
						popped_pc_q <= mem_rdata_eff;
				end
				(* full_case, parallel_case *)
				case (decoded[51-:7])
					7'd70: mem_op_step <= (mem_op_step == 2'd1 ? 2'd0 : mem_op_step + 2'd1);
					7'd71: mem_op_step <= (trap_skip_push || (mem_op_step == 2'd2) ? 2'd0 : mem_op_step + 2'd1);
					7'd76, 7'd99, 7'd100, 7'd101, 7'd102: mem_op_step <= (mem_op_step == 2'd1 ? 2'd0 : mem_op_step + 2'd1);
					7'd74: mem_op_step <= (pixt_rmw && (mem_op_step == 2'd0) ? 2'd1 : 2'd0);
					default: mem_op_step <= 2'd0;
				endcase
			end
			else if ((state_q == 6'd19) && mem_ack) begin
				popped_pc_q <= mem_rdata_eff;
				mem_op_step <= 2'd0;
			end
			else if (state_q != 6'd6)
				mem_op_step <= 2'd0;
		end
	reg [31:0] fill_dptch_q;
	reg [31:0] fill_color_q;
	reg [31:0] fill_daddr_raw_q;
	reg [15:0] fill_dx_q;
	reg [15:0] fill_dy_q;
	reg [31:0] fill_addr_q;
	reg [31:0] fill_row_base_q;
	reg [15:0] fill_x_q;
	reg [15:0] fill_y_q;
	localparam [6:0] SRT_FILL_FIRST_PAIR = 7'd22;
	localparam [6:0] SRT_FILL_LAST_PAIR = 7'd126;
	localparam [31:0] SRT_FILL_FINAL_DADDR = 32'h000fc008;
	(* preserve, dont_merge, altera_attribute = "-name ADV_NETLIST_OPT_ALLOWED NEVER_ALLOW; -name DONT_MERGE_REGISTER ON; -name PRESERVE_REGISTER ON" *) reg [6:0] srt_fill_pair_q;
	reg srt_fill_page_q;
	wire [31:0] fill_psize_ext;
	wire fill_row_end;
	wire fill_done;
	function automatic [31:0] sv2v_cast_DEBC9;
		input reg [31:0] inp;
		sv2v_cast_DEBC9 = inp;
	endfunction
	assign fill_psize_ext = sv2v_cast_DEBC9(io_psize[5:0]);
	assign fill_row_end = fill_x_q == (fill_dx_q - 16'd1);
	assign fill_done = fill_row_end && (fill_y_q == (fill_dy_q - 16'd1));
	wire [4:0] fill_xy_yshift;
	wire [31:0] fill_xy_linear;
	wire [31:0] fill_start;
	assign fill_xy_yshift = 5'd31 - io_convdp[4:0];
	assign fill_xy_linear = (({{16 {fill_daddr_raw_q[31]}}, fill_daddr_raw_q[31:16]} << fill_xy_yshift) | ({16'b0000000000000000, fill_daddr_raw_q[15:0]} << pix_xy_xsh)) + rf_rs3_data;
	assign fill_start = (fill_is_xy ? fill_xy_linear : fill_daddr_raw_q);
	wire srt_fill_exact_match;
	localparam [31:0] tms34010_pkg_CTRL_W_HI = 7;
	localparam [31:0] tms34010_pkg_CTRL_W_LO = 6;
	localparam [31:0] tms34010_pkg_DPYCTL_SRT_BIT = 11;
	assign srt_fill_exact_match = ((((((((srt_fill_exact_enable_i === 1'b1) && fill_is_xy) && io_dpyctl_live[tms34010_pkg_DPYCTL_SRT_BIT]) && ((fill_start == 32'h0002c000) || (fill_start == 32'h0012c000))) && (io_psize == 16'd8)) && (fill_dx_q == 16'd1)) && (fill_dy_q == 16'd105)) && (fill_dptch_q == 32'h00002000)) && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd0);
	reg fill_substep_q;
	reg [31:0] fill_dest_q;
	wire [31:0] fill_pixel_mask;
	wire [31:0] fill_pmask_field;
	wire [31:0] fill_processed;
	wire [31:0] fill_merged;
	wire fill_transp;
	reg [31:0] fill_wstart_q;
	reg [31:0] fill_wend_q;
	reg fill_win_en_q;
	reg fill_w2_q;
	wire [15:0] fill_px;
	wire [15:0] fill_py;
	wire fill_in_window;
	wire fill_clip_out;
	assign fill_px = fill_daddr_raw_q[15:0] + fill_x_q;
	assign fill_py = fill_daddr_raw_q[31:16] + fill_y_q;
	assign fill_in_window = (((fill_px >= fill_wstart_q[15:0]) && (fill_px <= fill_wend_q[15:0])) && (fill_py >= fill_wstart_q[31:16])) && (fill_py <= fill_wend_q[31:16]);
	assign fill_clip_out = fill_win_en_q && !fill_in_window;
	wire fill_array_inside;
	wire [15:0] fill_arr_x0;
	wire [15:0] fill_arr_y0;
	wire [15:0] fill_arr_x1;
	wire [15:0] fill_arr_y1;
	assign fill_arr_x0 = fill_daddr_raw_q[15:0];
	assign fill_arr_y0 = fill_daddr_raw_q[31:16];
	assign fill_arr_x1 = (fill_arr_x0 + fill_dx_q) - 16'd1;
	assign fill_arr_y1 = (fill_arr_y0 + fill_dy_q) - 16'd1;
	assign fill_array_inside = (((fill_arr_x0 >= rf_rs1_data[15:0]) && (fill_arr_x1 <= rf_rs2_data[15:0])) && (fill_arr_y0 >= rf_rs1_data[31:16])) && (fill_arr_y1 <= rf_rs2_data[31:16]);
	reg fill_w1_q;
	wire fill_array_hit;
	assign fill_array_hit = !((((fill_arr_x1 < fill_wstart_q[15:0]) || (fill_arr_x0 > fill_wend_q[15:0])) || (fill_arr_y1 < fill_wstart_q[31:16])) || (fill_arr_y0 > fill_wend_q[31:16]));
	wire fill_win_flag_wb;
	wire fill_win_violation;
	wire drav_win_wb;
	assign drav_win_wb = ((state_q == 6'd7) && is_drav) && (drav_w_q != 2'd0);
	wire line_win_wb;
	assign line_win_wb = (state_q == 6'd33) && line_win_en;
	wire pixt_win_wb;
	assign pixt_win_wb = (state_q == 6'd7) && pixt_xy_win;
	assign fill_win_violation = ((((((state_q == 6'd23) || (state_q == 6'd24)) || ((state_q == 6'd25) && !fill_array_hit)) || ((state_q == 6'd26) && !pblt_array_hit)) || (drav_win_wb && !drav_inside_q)) || (line_win_wb && !line_last_inside_q)) || (pixt_win_wb && !pixt_inside_q);
	assign fill_win_flag_wb = ((((((((state_q == 6'd23) || ((state_q == 6'd11) && fill_w2_q)) || (state_q == 6'd24)) || ((state_q == 6'd15) && pblt_w2_q)) || (state_q == 6'd25)) || (state_q == 6'd26)) || drav_win_wb) || line_win_wb) || pixt_win_wb;
	assign wvp_set = ((((((state_q == 6'd23) || (state_q == 6'd24)) || ((state_q == 6'd25) && fill_array_hit)) || ((state_q == 6'd26) && pblt_array_hit)) || (drav_win_wb && (((drav_w_q == 2'd1) && drav_inside_q) || ((drav_w_q == 2'd2) && !drav_inside_q)))) || (line_win_wb && line_aborted_q)) || (pixt_win_wb && (((io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd1) && pixt_inside_q) || ((io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd2) && !pixt_inside_q)));
	assign fill_pixel_mask = (32'd1 << io_psize[5:0]) - 32'd1;
	assign fill_pmask_field = {{16 {1'b0}}, io_pmask} & fill_pixel_mask;
	localparam [31:0] tms34010_pkg_CTRL_PPOP_HI = 14;
	localparam [31:0] tms34010_pkg_CTRL_PPOP_LO = 10;
	assign fill_processed = ppop_apply(fill_color_q, fill_dest_q, io_control[tms34010_pkg_CTRL_PPOP_HI:tms34010_pkg_CTRL_PPOP_LO], fill_pixel_mask);
	localparam [31:0] tms34010_pkg_CTRL_T_BIT = 5;
	assign fill_transp = io_control[tms34010_pkg_CTRL_T_BIT] && ((fill_processed & fill_pixel_mask) == {32 {1'sb0}});
	assign fill_merged = (fill_transp || fill_clip_out ? fill_dest_q : (fill_processed & ~fill_pmask_field) | (fill_dest_q & fill_pmask_field));
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				fill_dptch_q <= 1'sb0;
				fill_color_q <= 1'sb0;
				fill_daddr_raw_q <= 1'sb0;
				fill_dx_q <= 1'sb0;
				fill_dy_q <= 1'sb0;
				fill_addr_q <= 1'sb0;
				fill_row_base_q <= 1'sb0;
				fill_x_q <= 1'sb0;
				fill_y_q <= 1'sb0;
				fill_substep_q <= 1'b0;
				srt_fill_pair_q <= SRT_FILL_FIRST_PAIR;
				srt_fill_page_q <= 1'b0;
				fill_dest_q <= 1'sb0;
				fill_wstart_q <= 1'sb0;
				fill_wend_q <= 1'sb0;
				fill_win_en_q <= 1'b0;
				fill_w2_q <= 1'b0;
				fill_w1_q <= 1'b0;
			end
			else begin
				if ((state_q == 6'd5) && is_fill) begin
					fill_daddr_raw_q <= rf_rs1_data;
					fill_dptch_q <= rf_rs2_data;
					fill_dx_q <= rf_rs3_data[15:0];
					fill_dy_q <= rf_rs3_data[31:16];
					fill_x_q <= 16'd0;
					fill_y_q <= 16'd0;
					fill_win_en_q <= fill_is_xy && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd3);
					fill_w2_q <= fill_is_xy && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd2);
					fill_w1_q <= fill_is_xy && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd1);
				end
				if (state_q == 6'd21) begin
					fill_wstart_q <= rf_rs1_data;
					fill_wend_q <= rf_rs2_data;
				end
				if (state_q == 6'd9) begin
					fill_color_q <= rf_rs1_data;
					fill_addr_q <= (srt_fill_exact_match ? SRT_FILL_FINAL_DADDR | {11'd0, fill_start[20], 20'd0} : fill_start);
					fill_row_base_q <= fill_start;
					fill_substep_q <= 1'b0;
					srt_fill_pair_q <= SRT_FILL_FIRST_PAIR;
					srt_fill_page_q <= fill_start[20];
				end
				if ((state_q == 6'd10) && mem_ack) begin
					fill_substep_q <= ~fill_substep_q;
					if (!fill_substep_q)
						fill_dest_q <= mem_rdata_eff;
					else begin
						fill_addr_q <= fill_addr_q + fill_psize_ext;
						if (fill_row_end && !fill_done) begin
							fill_y_q <= fill_y_q + 16'd1;
							fill_row_base_q <= fill_row_base_q + fill_dptch_q;
							fill_addr_q <= fill_row_base_q + fill_dptch_q;
							fill_x_q <= 16'd0;
						end
						else if (!fill_done)
							fill_x_q <= fill_x_q + 16'd1;
					end
				end
				if (((state_q == 6'd42) && (srt_fill_ack_i === 1'b1)) && (srt_fill_pair_q != SRT_FILL_LAST_PAIR))
					srt_fill_pair_q <= srt_fill_pair_q + 7'd1;
			end
		end
	reg [31:0] pblt_sptch_q;
	reg [31:0] pblt_dptch_q;
	reg [15:0] pblt_dx_q;
	reg [15:0] pblt_dy_q;
	reg [31:0] pblt_src_addr_q;
	reg [31:0] pblt_dst_addr_q;
	reg [31:0] pblt_src_row_q;
	reg [31:0] pblt_dst_row_q;
	reg [15:0] pblt_x_q;
	reg [15:0] pblt_y_q;
	reg [1:0] pblt_substep_q;
	reg [31:0] pblt_src_pix_q;
	reg [31:0] pblt_dst_pix_q;
	wire [31:0] pblt_psize_ext;
	wire [31:0] pblt_pixel_mask;
	wire [31:0] pblt_pmask_field;
	wire [31:0] pblt_processed;
	wire [31:0] pblt_merged;
	wire pblt_row_end;
	wire pblt_done;
	wire pblt_transp;
	reg [31:0] pblt_color0_q;
	reg [31:0] pblt_color1_q;
	wire [31:0] pblt_src_eff;
	wire [31:0] pblt_src_step;
	assign pblt_psize_ext = sv2v_cast_DEBC9(io_psize[5:0]);
	assign pblt_pixel_mask = (32'd1 << io_psize[5:0]) - 32'd1;
	assign pblt_pmask_field = {{16 {1'b0}}, io_pmask} & pblt_pixel_mask;
	assign pblt_row_end = pblt_x_q == (pblt_dx_q - 16'd1);
	assign pblt_done = pblt_row_end && (pblt_y_q == (pblt_dy_q - 16'd1));
	assign pblt_src_eff = (decoded[0] ? (pblt_src_pix_q[0] ? pblt_color1_q : pblt_color0_q) : pblt_src_pix_q);
	assign pblt_src_step = (decoded[0] ? 32'd1 : pblt_psize_ext);
	assign pblt_processed = ppop_apply(pblt_src_eff, pblt_dst_pix_q, io_control[tms34010_pkg_CTRL_PPOP_HI:tms34010_pkg_CTRL_PPOP_LO], pblt_pixel_mask);
	assign pblt_transp = io_control[tms34010_pkg_CTRL_T_BIT] && ((pblt_processed & pblt_pixel_mask) == {32 {1'sb0}});
	reg [31:0] pblt_dst_xy_raw_q;
	reg [31:0] pblt_wstart_q;
	reg [31:0] pblt_wend_q;
	reg pblt_win_en_q;
	wire [15:0] pblt_px;
	wire [15:0] pblt_py;
	wire pblt_in_window;
	wire pblt_clip_out;
	assign pblt_px = pblt_dst_xy_raw_q[15:0] + pblt_x_q;
	assign pblt_py = pblt_dst_xy_raw_q[31:16] + pblt_y_q;
	assign pblt_in_window = (((pblt_px >= pblt_wstart_q[15:0]) && (pblt_px <= pblt_wend_q[15:0])) && (pblt_py >= pblt_wstart_q[31:16])) && (pblt_py <= pblt_wend_q[31:16]);
	assign pblt_clip_out = pblt_win_en_q && !pblt_in_window;
	wire pblt_array_inside;
	wire [15:0] pblt_arr_x0;
	wire [15:0] pblt_arr_y0;
	wire [15:0] pblt_arr_x1;
	wire [15:0] pblt_arr_y1;
	assign pblt_arr_x0 = pblt_dst_xy_raw_q[15:0];
	assign pblt_arr_y0 = pblt_dst_xy_raw_q[31:16];
	assign pblt_arr_x1 = (pblt_arr_x0 + pblt_dx_q) - 16'd1;
	assign pblt_arr_y1 = (pblt_arr_y0 + pblt_dy_q) - 16'd1;
	assign pblt_array_inside = (((pblt_arr_x0 >= rf_rs1_data[15:0]) && (pblt_arr_x1 <= rf_rs2_data[15:0])) && (pblt_arr_y0 >= rf_rs1_data[31:16])) && (pblt_arr_y1 <= rf_rs2_data[31:16]);
	assign pblt_array_hit = !((((pblt_arr_x1 < pblt_wstart_q[15:0]) || (pblt_arr_x0 > pblt_wend_q[15:0])) || (pblt_arr_y1 < pblt_wstart_q[31:16])) || (pblt_arr_y0 > pblt_wend_q[31:16]));
	assign pblt_merged = (pblt_transp || pblt_clip_out ? pblt_dst_pix_q : (pblt_processed & ~pblt_pmask_field) | (pblt_dst_pix_q & pblt_pmask_field));
	wire [31:0] pblt_src_conv;
	wire [31:0] pblt_dst_conv;
	assign pblt_src_conv = (({{16 {pblt_src_addr_q[31]}}, pblt_src_addr_q[31:16]} << (5'd31 - io_convsp[4:0])) | ({16'b0000000000000000, pblt_src_addr_q[15:0]} << pix_xy_xsh)) + rf_rs3_data;
	assign pblt_dst_conv = (({{16 {pblt_dst_addr_q[31]}}, pblt_dst_addr_q[31:16]} << (5'd31 - io_convdp[4:0])) | ({16'b0000000000000000, pblt_dst_addr_q[15:0]} << pix_xy_xsh)) + rf_rs3_data;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				pblt_sptch_q <= 1'sb0;
				pblt_dptch_q <= 1'sb0;
				pblt_dx_q <= 1'sb0;
				pblt_dy_q <= 1'sb0;
				pblt_src_addr_q <= 1'sb0;
				pblt_dst_addr_q <= 1'sb0;
				pblt_src_row_q <= 1'sb0;
				pblt_dst_row_q <= 1'sb0;
				pblt_x_q <= 1'sb0;
				pblt_y_q <= 1'sb0;
				pblt_substep_q <= 2'd0;
				pblt_src_pix_q <= 1'sb0;
				pblt_dst_pix_q <= 1'sb0;
				pblt_color0_q <= 1'sb0;
				pblt_color1_q <= 1'sb0;
				pblt_dst_xy_raw_q <= 1'sb0;
				pblt_wstart_q <= 1'sb0;
				pblt_wend_q <= 1'sb0;
				pblt_win_en_q <= 1'b0;
				pblt_w2_q <= 1'b0;
				pblt_w1_q <= 1'b0;
			end
			else begin
				if ((state_q == 6'd5) && is_pblt) begin
					pblt_src_addr_q <= rf_rs1_data;
					pblt_src_row_q <= rf_rs1_data;
					pblt_dst_addr_q <= rf_rs2_data;
					pblt_dst_row_q <= rf_rs2_data;
					pblt_dst_xy_raw_q <= rf_rs2_data;
					pblt_dx_q <= rf_rs3_data[15:0];
					pblt_dy_q <= rf_rs3_data[31:16];
					pblt_x_q <= 16'd0;
					pblt_y_q <= 16'd0;
					pblt_substep_q <= 2'd0;
					pblt_win_en_q <= decoded[1] && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd3);
					pblt_w2_q <= decoded[1] && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd2);
					pblt_w1_q <= decoded[1] && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd1);
				end
				if (state_q == 6'd22) begin
					pblt_wstart_q <= rf_rs1_data;
					pblt_wend_q <= rf_rs2_data;
				end
				if (state_q == 6'd12) begin
					pblt_sptch_q <= rf_rs1_data;
					pblt_dptch_q <= rf_rs2_data;
					if (decoded[2]) begin
						pblt_src_addr_q <= pblt_src_conv;
						pblt_src_row_q <= pblt_src_conv;
					end
					if (decoded[1]) begin
						pblt_dst_addr_q <= pblt_dst_conv;
						pblt_dst_row_q <= pblt_dst_conv;
					end
				end
				if (state_q == 6'd16) begin
					pblt_color0_q <= rf_rs1_data;
					pblt_color1_q <= rf_rs2_data;
				end
				if ((state_q == 6'd13) && mem_ack) begin
					if (pblt_substep_q == 2'd0) begin
						pblt_src_pix_q <= mem_rdata_eff;
						pblt_substep_q <= 2'd1;
					end
					else if (pblt_substep_q == 2'd1) begin
						pblt_dst_pix_q <= mem_rdata_eff;
						pblt_substep_q <= 2'd2;
					end
					else begin
						pblt_substep_q <= 2'd0;
						pblt_src_addr_q <= pblt_src_addr_q + pblt_src_step;
						pblt_dst_addr_q <= pblt_dst_addr_q + pblt_psize_ext;
						if (pblt_done) begin
							pblt_src_addr_q <= pblt_src_row_q + pblt_sptch_q;
							pblt_dst_addr_q <= pblt_dst_row_q + pblt_dptch_q;
						end
						else if (pblt_row_end) begin
							pblt_y_q <= pblt_y_q + 16'd1;
							pblt_src_row_q <= pblt_src_row_q + pblt_sptch_q;
							pblt_dst_row_q <= pblt_dst_row_q + pblt_dptch_q;
							pblt_src_addr_q <= pblt_src_row_q + pblt_sptch_q;
							pblt_dst_addr_q <= pblt_dst_row_q + pblt_dptch_q;
							pblt_x_q <= 16'd0;
						end
						else
							pblt_x_q <= pblt_x_q + 16'd1;
					end
				end
			end
		end
	reg [31:0] drav_rd_q;
	reg [31:0] drav_rs_q;
	reg [31:0] drav_linear_q;
	reg [31:0] drav_dest_q;
	reg drav_substep_q;
	wire drav_in_window;
	wire drav_draw;
	assign drav_in_window = (((drav_rd_q[15:0] >= rf_rs1_data[15:0]) && (drav_rd_q[15:0] <= rf_rs2_data[15:0])) && (drav_rd_q[31:16] >= rf_rs1_data[31:16])) && (drav_rd_q[31:16] <= rf_rs2_data[31:16]);
	assign drav_draw = (drav_w_q == 2'd0) || (((drav_w_q == 2'd2) || (drav_w_q == 2'd3)) && drav_inside_q);
	wire [31:0] drav_pixel_mask;
	wire [31:0] drav_pmask_field;
	wire [31:0] drav_processed;
	wire [31:0] drav_merged;
	wire drav_transp;
	wire [31:0] drav_advance;
	assign drav_pixel_mask = (32'd1 << io_psize[5:0]) - 32'd1;
	assign drav_pmask_field = {{16 {1'b0}}, io_pmask} & drav_pixel_mask;
	assign drav_processed = ppop_apply(rf_rs1_data, drav_dest_q, io_control[tms34010_pkg_CTRL_PPOP_HI:tms34010_pkg_CTRL_PPOP_LO], drav_pixel_mask);
	assign drav_transp = io_control[tms34010_pkg_CTRL_T_BIT] && ((drav_processed & drav_pixel_mask) == {32 {1'sb0}});
	assign drav_merged = (drav_transp ? drav_dest_q : (drav_processed & ~drav_pmask_field) | (drav_dest_q & drav_pmask_field));
	assign drav_advance = {drav_rd_q[31:16] + drav_rs_q[31:16], drav_rd_q[15:0] + drav_rs_q[15:0]};
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				drav_rd_q <= 1'sb0;
				drav_rs_q <= 1'sb0;
				drav_linear_q <= 1'sb0;
				drav_dest_q <= 1'sb0;
				drav_substep_q <= 1'b0;
				drav_w_q <= 2'd0;
				drav_inside_q <= 1'b0;
			end
			else begin
				if ((state_q == 6'd5) && is_drav) begin
					drav_rd_q <= rf_rs2_data;
					drav_rs_q <= rf_rs1_data;
					drav_linear_q <= pix_xy_dst_linear;
					drav_substep_q <= 1'b0;
					drav_w_q <= io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO];
				end
				if (state_q == 6'd28)
					drav_inside_q <= drav_in_window;
				if ((state_q == 6'd27) && mem_ack) begin
					drav_substep_q <= ~drav_substep_q;
					if (!drav_substep_q)
						drav_dest_q <= mem_rdata_eff;
				end
			end
		end
	reg [31:0] line_d_q;
	reg [31:0] line_count_q;
	reg [31:0] line_initial_count_q;
	reg [31:0] line_inc1_q;
	reg [31:0] line_inc2_q;
	reg [31:0] line_offset_q;
	reg [31:0] line_daddr_q;
	reg [31:0] line_color_q;
	reg [31:0] line_dest_q;
	reg [15:0] line_b_q;
	reg [15:0] line_a_q;
	reg line_substep_q;
	wire [31:0] line_linear;
	assign line_linear = (({{16 {line_daddr_q[31]}}, line_daddr_q[31:16]} << (5'd31 - io_convdp[4:0])) | ({16'b0000000000000000, line_daddr_q[15:0]} << pix_xy_xsh)) + line_offset_q;
	wire [31:0] line_pixel_mask;
	wire [31:0] line_pmask_field;
	wire [31:0] line_processed;
	wire [31:0] line_merged;
	wire line_transp;
	assign line_pixel_mask = (32'd1 << io_psize[5:0]) - 32'd1;
	assign line_pmask_field = {{16 {1'b0}}, io_pmask} & line_pixel_mask;
	assign line_processed = ppop_apply(line_color_q, line_dest_q, io_control[tms34010_pkg_CTRL_PPOP_HI:tms34010_pkg_CTRL_PPOP_LO], line_pixel_mask);
	assign line_transp = io_control[tms34010_pkg_CTRL_T_BIT] && ((line_processed & line_pixel_mask) == {32 {1'sb0}});
	reg [31:0] line_wstart_q;
	reg [31:0] line_wend_q;
	wire [1:0] line_w_mode;
	wire line_in_window;
	wire line_draw_pixel;
	wire line_clip_out;
	wire line_abort;
	assign line_w_mode = io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO];
	assign line_win_en = line_w_mode != 2'd0;
	assign line_in_window = (((line_daddr_q[15:0] >= line_wstart_q[15:0]) && (line_daddr_q[15:0] <= line_wend_q[15:0])) && (line_daddr_q[31:16] >= line_wstart_q[31:16])) && (line_daddr_q[31:16] <= line_wend_q[31:16]);
	assign line_draw_pixel = (line_w_mode == 2'd1 ? !line_in_window : line_in_window);
	assign line_clip_out = line_win_en && !line_draw_pixel;
	assign line_abort = ((line_w_mode == 2'd1) && line_in_window) || ((line_w_mode == 2'd2) && !line_in_window);
	assign line_merged = (line_transp || line_clip_out ? line_dest_q : (line_processed & ~line_pmask_field) | (line_dest_q & line_pmask_field));
	wire line_branch;
	wire [31:0] line_2b;
	wire [31:0] line_2a;
	wire [31:0] line_d_next;
	wire [31:0] line_daddr_next;
	wire [31:0] line_count_next;
	assign line_branch = (instr_word_q[7] ? !line_d_q[31] : !line_d_q[31] && (line_d_q != {32 {1'sb0}}));
	assign line_2b = {16'b0000000000000000, line_b_q} << 1;
	assign line_2a = {16'b0000000000000000, line_a_q} << 1;
	assign line_d_next = (line_branch ? (line_d_q + line_2b) - line_2a : line_d_q + line_2b);
	assign line_daddr_next = (line_branch ? {line_daddr_q[31:16] + line_inc1_q[31:16], line_daddr_q[15:0] + line_inc1_q[15:0]} : {line_daddr_q[31:16] + line_inc2_q[31:16], line_daddr_q[15:0] + line_inc2_q[15:0]});
	assign line_count_next = line_count_q - 32'd1;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				line_d_q <= 1'sb0;
				line_count_q <= 1'sb0;
				line_initial_count_q <= 1'sb0;
				line_inc1_q <= 1'sb0;
				line_inc2_q <= 1'sb0;
				line_offset_q <= 1'sb0;
				line_daddr_q <= 1'sb0;
				line_color_q <= 1'sb0;
				line_dest_q <= 1'sb0;
				line_b_q <= 1'sb0;
				line_a_q <= 1'sb0;
				line_substep_q <= 1'b0;
				line_wstart_q <= 1'sb0;
				line_wend_q <= 1'sb0;
				line_last_inside_q <= 1'b0;
				line_aborted_q <= 1'b0;
			end
			else begin
				if ((state_q == 6'd5) && is_line)
					line_aborted_q <= 1'b0;
				if (state_q == 6'd36) begin
					line_wstart_q <= rf_rs1_data;
					line_wend_q <= rf_rs2_data;
				end
				if (state_q == 6'd29) begin
					line_d_q <= rf_rs1_data;
					line_b_q <= rf_rs2_data[31:16];
					line_a_q <= rf_rs2_data[15:0];
					line_count_q <= rf_rs3_data;
					line_initial_count_q <= rf_rs3_data;
				end
				if (state_q == 6'd30) begin
					line_inc1_q <= rf_rs1_data;
					line_inc2_q <= rf_rs2_data;
					line_offset_q <= rf_rs3_data;
				end
				if (state_q == 6'd31) begin
					line_daddr_q <= rf_rs1_data;
					line_color_q <= rf_rs2_data;
					line_substep_q <= 1'b0;
				end
				if ((state_q == 6'd32) && mem_ack) begin
					line_substep_q <= ~line_substep_q;
					if (!line_substep_q)
						line_dest_q <= mem_rdata_eff;
					else begin
						line_last_inside_q <= line_in_window;
						if (line_abort)
							line_aborted_q <= 1'b1;
						line_d_q <= line_d_next;
						line_daddr_q <= line_daddr_next;
						line_count_q <= line_count_next;
					end
				end
			end
		end
	reg [31:0] mm_rp_q;
	(* preserve, dont_merge, altera_attribute = "-name ADV_NETLIST_OPT_ALLOWED NEVER_ALLOW; -name DONT_MERGE_REGISTER ON; -name PRESERVE_REGISTER ON" *) reg [15:0] mm_mask_q;
	reg [3:0] mm_iter_idx;
	wire [3:0] mm_reg_idx;
	wire mm_mask_will_be_empty;
	wire is_mmtm;
	wire is_mmfm;
	wire is_mm;
	(* preserve, dont_merge, altera_attribute = "-name ADV_NETLIST_OPT_ALLOWED NEVER_ALLOW; -name DONT_MERGE_REGISTER ON; -name PRESERVE_REGISTER ON" *) reg mmfm_issue_active_q;
	(* preserve, dont_merge, altera_attribute = "-name ADV_NETLIST_OPT_ALLOWED NEVER_ALLOW; -name DONT_MERGE_REGISTER ON; -name PRESERVE_REGISTER ON" *) reg mmfm_issue_file_q;
	(* preserve, dont_merge, altera_attribute = "-name ADV_NETLIST_OPT_ALLOWED NEVER_ALLOW; -name DONT_MERGE_REGISTER ON; -name PRESERVE_REGISTER ON" *) reg [30:0] mmfm_issue_target_q;
	wire [15:0] mm_mask_after_current;
	reg [3:0] mmfm_entry_idx;
	reg [3:0] mmfm_next_idx;
	reg [30:0] mmfm_entry_target;
	reg [30:0] mmfm_next_target;
	assign is_mmtm = decoded[51-:7] == 7'd72;
	assign is_mmfm = decoded[51-:7] == 7'd73;
	assign is_mm = is_mmtm || is_mmfm;
	function automatic signed [3:0] sv2v_cast_4_signed;
		input reg signed [3:0] inp;
		sv2v_cast_4_signed = inp;
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		mm_iter_idx = 4'd0;
		begin : sv2v_autoblock_1
			reg signed [31:0] i;
			for (i = 0; i < 16; i = i + 1)
				if (mm_mask_q[i])
					mm_iter_idx = sv2v_cast_4_signed(i);
		end
	end
	assign mm_reg_idx = (is_mmtm ? 4'd15 - mm_iter_idx : mm_iter_idx);
	assign mm_mask_will_be_empty = (mm_mask_q & ~(16'd1 << mm_iter_idx)) == 16'd0;
	assign mm_mask_after_current = mm_mask_q & ~(16'd1 << mm_iter_idx);
	localparam [3:0] tms34010_pkg_REG_SP_IDX = 4'hf;
	always @(*) begin
		if (_sv2v_0)
			;
		mmfm_entry_idx = 4'd0;
		mmfm_next_idx = 4'd0;
		begin : sv2v_autoblock_2
			reg signed [31:0] i;
			for (i = 0; i < 16; i = i + 1)
				begin
					if (imm_lo_q[i])
						mmfm_entry_idx = sv2v_cast_4_signed(i);
					if (mm_mask_after_current[i])
						mmfm_next_idx = sv2v_cast_4_signed(i);
				end
		end
		mmfm_entry_target = 31'd0;
		if (mmfm_entry_idx == tms34010_pkg_REG_SP_IDX)
			mmfm_entry_target[30] = 1'b1;
		else if (decoded[44] == 1'b1)
			mmfm_entry_target[15 + mmfm_entry_idx] = 1'b1;
		else
			mmfm_entry_target[mmfm_entry_idx] = 1'b1;
		mmfm_next_target = 31'd0;
		if (mmfm_next_idx == tms34010_pkg_REG_SP_IDX)
			mmfm_next_target[30] = 1'b1;
		else if (mmfm_issue_file_q == 1'b1)
			mmfm_next_target[15 + mmfm_next_idx] = 1'b1;
		else
			mmfm_next_target[mmfm_next_idx] = 1'b1;
	end
	localparam [31:0] tms34010_pkg_WORD_BIT_SIZE = sv2v_cast_DEBC9(tms34010_pkg_DATA_WIDTH);
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				mm_rp_q <= 1'sb0;
				mm_mask_q <= 1'sb0;
			end
			else if (((state_q == 6'd5) && (state_d == 6'd6)) && is_mm) begin
				mm_rp_q <= (is_mmtm ? rf_rs2_data - tms34010_pkg_WORD_BIT_SIZE : rf_rs2_data);
				mm_mask_q <= imm_lo_q;
			end
			else if (((state_q == 6'd6) && is_mm) && mem_ack) begin
				mm_mask_q[mm_iter_idx] <= 1'b0;
				if (is_mmfm)
					mm_rp_q <= mm_rp_q + tms34010_pkg_WORD_BIT_SIZE;
				else if (!mm_mask_will_be_empty)
					mm_rp_q <= mm_rp_q - tms34010_pkg_WORD_BIT_SIZE;
			end
		end
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				mmfm_issue_active_q <= 1'b0;
				mmfm_issue_file_q <= 1'b0;
				mmfm_issue_target_q <= 31'd0;
			end
			else if (((state_q == 6'd5) && (state_d == 6'd6)) && is_mmfm) begin
				mmfm_issue_active_q <= 1'b1;
				mmfm_issue_file_q <= decoded[44];
				mmfm_issue_target_q <= mmfm_entry_target;
			end
			else if (mmfm_issue_active_q && mem_ack) begin
				if (mm_mask_will_be_empty) begin
					mmfm_issue_active_q <= 1'b0;
					mmfm_issue_target_q <= 31'd0;
				end
				else
					mmfm_issue_target_q <= mmfm_next_target;
			end
		end
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				imm_lo_q <= 1'sb0;
				imm_hi_q <= 1'sb0;
			end
			else begin
				if ((state_q == 6'd3) && mem_ack)
					imm_lo_q <= mem_rdata_eff[15:0];
				if ((state_q == 6'd4) && mem_ack)
					imm_hi_q <= mem_rdata_eff[15:0];
				if ((state_q == 6'd39) && mem_ack)
					imm2_lo_q <= mem_rdata_eff[15:0];
				if ((state_q == 6'd40) && mem_ack)
					imm2_hi_q <= mem_rdata_eff[15:0];
			end
		end
	wire rf_rs1_file;
	wire [3:0] rf_rs1_idx;
	wire rf_rs2_file;
	wire [3:0] rf_rs2_idx;
	wire rf_rs3_file;
	wire [3:0] rf_rs3_idx;
	wire rf_wr_en;
	wire rf_wr_file;
	wire [3:0] rf_wr_idx;
	reg [31:0] rf_wr_data;
	wire [31:0] rf_sp;
	wire [3:0] alu_op;
	reg [31:0] alu_a;
	reg [31:0] alu_b;
	wire alu_cin;
	wire [31:0] alu_result;
	wire [3:0] alu_flags;
	wire st_flag_update_en;
	wire st_write_en;
	reg [31:0] st_write_data;
	wire [31:0] st_value;
	wire st_n;
	wire st_c;
	wire st_z;
	wire st_v;
	wire [31:0] shifter_result;
	wire [3:0] shifter_flags;
	reg [31:0] imm32;
	always @(*) begin
		if (_sv2v_0)
			;
		if (decoded[33])
			imm32 = {imm_hi_q, imm_lo_q};
		else if (decoded[32])
			imm32 = {{tms34010_pkg_DATA_WIDTH - tms34010_pkg_INSTR_WORD_WIDTH {imm_lo_q[15]}}, imm_lo_q};
		else
			imm32 = {{tms34010_pkg_DATA_WIDTH - tms34010_pkg_INSTR_WORD_WIDTH {1'b0}}, imm_lo_q};
	end
	assign is_fill = (decoded[51-:7] == 7'd94) || (decoded[51-:7] == 7'd95);
	assign fill_is_xy = decoded[51-:7] == 7'd95;
	assign is_pblt = decoded[51-:7] == 7'd96;
	assign is_drav = decoded[51-:7] == 7'd97;
	assign is_line = decoded[51-:7] == 7'd98;
	wire line_rd_b;
	assign line_rd_b = is_line && ((((state_q == 6'd29) || (state_q == 6'd30)) || (state_q == 6'd31)) || (state_q == 6'd36));
	assign rf_rs1_file = (line_rd_b ? 1'b1 : (state_q == 6'd37 ? 1'b1 : (is_drav && ((state_q == 6'd27) || (state_q == 6'd28)) ? 1'b1 : (is_fill || is_pblt ? 1'b1 : (decoded[51-:7] == 7'd30 ? decoded[35] : decoded[44])))));
	localparam [3:0] tms34010_pkg_B_COLOR0_IDX = 4'd8;
	localparam [3:0] tms34010_pkg_B_COLOR1_IDX = 4'd9;
	localparam [3:0] tms34010_pkg_B_DADDR_IDX = 4'd2;
	localparam [3:0] tms34010_pkg_B_INC1_IDX = 4'd11;
	localparam [3:0] tms34010_pkg_B_SADDR_IDX = 4'd0;
	localparam [3:0] tms34010_pkg_B_SPTCH_IDX = 4'd1;
	localparam [3:0] tms34010_pkg_CPW_WSTART_IDX = 4'd5;
	assign rf_rs1_idx = (is_fill ? (state_q == 6'd21 ? tms34010_pkg_CPW_WSTART_IDX : (state_q == 6'd9 ? tms34010_pkg_B_COLOR1_IDX : tms34010_pkg_B_DADDR_IDX)) : (is_pblt ? (state_q == 6'd22 ? tms34010_pkg_CPW_WSTART_IDX : (state_q == 6'd16 ? tms34010_pkg_B_COLOR0_IDX : (state_q == 6'd12 ? tms34010_pkg_B_SPTCH_IDX : tms34010_pkg_B_SADDR_IDX))) : ((state_q == 6'd6) && is_mmtm ? mm_reg_idx : (is_drav && (state_q == 6'd28) ? tms34010_pkg_CPW_WSTART_IDX : (is_drav && (state_q == 6'd27) ? tms34010_pkg_B_COLOR1_IDX : (is_line && (state_q == 6'd29) ? tms34010_pkg_B_SADDR_IDX : (is_line && (state_q == 6'd30) ? tms34010_pkg_B_INC1_IDX : (is_line && (state_q == 6'd31) ? tms34010_pkg_B_DADDR_IDX : (is_line && (state_q == 6'd36) ? tms34010_pkg_CPW_WSTART_IDX : (state_q == 6'd37 ? tms34010_pkg_CPW_WSTART_IDX : decoded[39-:4]))))))))));
	assign rf_rs2_file = (((((line_rd_b || is_fill) || is_pblt) || (decoded[51-:7] == 7'd86)) || (state_q == 6'd37)) || (is_drav && (state_q == 6'd28)) ? 1'b1 : decoded[44]);
	localparam [3:0] tms34010_pkg_B_DPTCH_IDX = 4'd3;
	localparam [3:0] tms34010_pkg_B_DYDX_IDX = 4'd7;
	localparam [3:0] tms34010_pkg_B_INC2_IDX = 4'd12;
	localparam [3:0] tms34010_pkg_CPW_WEND_IDX = 4'd6;
	assign rf_rs2_idx = (is_fill ? (state_q == 6'd21 ? tms34010_pkg_CPW_WEND_IDX : tms34010_pkg_B_DPTCH_IDX) : (is_pblt ? (state_q == 6'd22 ? tms34010_pkg_CPW_WEND_IDX : (state_q == 6'd16 ? tms34010_pkg_B_COLOR1_IDX : (state_q == 6'd12 ? tms34010_pkg_B_DPTCH_IDX : tms34010_pkg_B_DADDR_IDX))) : (is_drav && (state_q == 6'd28) ? tms34010_pkg_CPW_WEND_IDX : (is_line && (state_q == 6'd29) ? tms34010_pkg_B_DYDX_IDX : (is_line && (state_q == 6'd30) ? tms34010_pkg_B_INC2_IDX : (is_line && (state_q == 6'd31) ? tms34010_pkg_B_COLOR1_IDX : (is_line && (state_q == 6'd36) ? tms34010_pkg_CPW_WEND_IDX : (state_q == 6'd37 ? tms34010_pkg_CPW_WEND_IDX : (decoded[51-:7] == 7'd86 ? tms34010_pkg_CPW_WSTART_IDX : decoded[43-:4])))))))));
	assign rf_rs3_file = ((decoded[51-:7] == 7'd89) || (decoded[51-:7] == 7'd91) ? decoded[44] : 1'b1);
	localparam [3:0] tms34010_pkg_B_COUNT_IDX = 4'd10;
	localparam [3:0] tms34010_pkg_B_OFFSET_IDX = 4'd4;
	assign rf_rs3_idx = ((decoded[51-:7] == 7'd89) || (decoded[51-:7] == 7'd91) ? decoded[43-:4] + 4'd1 : (is_fill ? (state_q == 6'd9 ? tms34010_pkg_B_OFFSET_IDX : tms34010_pkg_B_DYDX_IDX) : (is_pblt ? (state_q == 6'd12 ? tms34010_pkg_B_OFFSET_IDX : tms34010_pkg_B_DYDX_IDX) : (is_line && (state_q == 6'd29) ? tms34010_pkg_B_COUNT_IDX : (is_line && (state_q == 6'd30) ? tms34010_pkg_B_OFFSET_IDX : (((decoded[51-:7] == 7'd93) || decoded[3]) || is_drav ? tms34010_pkg_B_OFFSET_IDX : tms34010_pkg_CPW_WEND_IDX))))));
	reg dsj_precondition;
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (decoded[51-:7])
			7'd36, 7'd40: dsj_precondition = 1'b1;
			7'd37: dsj_precondition = st_z;
			7'd38: dsj_precondition = !st_z;
			default: dsj_precondition = 1'b1;
		endcase
	end
	wire dsj_rd_nonzero;
	assign dsj_rd_nonzero = alu_result != {32 {1'sb0}};
	wire mmfm_pop_accept;
	(* preserve, dont_merge, altera_attribute = "-name ADV_NETLIST_OPT_ALLOWED NEVER_ALLOW; -name DONT_MERGE_REGISTER ON; -name PRESERVE_REGISTER ON" *) reg [31:0] mmfm_commit_data_q;
	(* preserve, dont_merge, altera_attribute = "-name ADV_NETLIST_OPT_ALLOWED NEVER_ALLOW; -name DONT_MERGE_REGISTER ON; -name PRESERVE_REGISTER ON" *) reg [30:0] mmfm_commit_target_q;
	assign mmfm_pop_accept = ((ce_cpu !== 1'b0) && mmfm_issue_active_q) && mem_ack;
	always @(posedge clk)
		if (rst) begin
			mmfm_commit_data_q <= 1'sb0;
			mmfm_commit_target_q <= 31'd0;
		end
		else begin
			mmfm_commit_data_q <= mem_rdata;
			mmfm_commit_target_q <= (mmfm_pop_accept ? mmfm_issue_target_q : 31'd0);
		end
	wire is_mv_store;
	wire is_mv_load;
	wire mv_postinc;
	wire mv_predec;
	wire mv_incdec;
	wire [31:0] mv_ptr;
	wire [31:0] mv_addr;
	wire [31:0] mv_ptr_new;
	wire mv_load_ptr_wr;
	assign is_mv_store = decoded[51-:7] == 7'd74;
	assign is_mv_load = decoded[51-:7] == 7'd75;
	assign mv_postinc = decoded[7-:2] == 2'b01;
	assign mv_predec = decoded[7-:2] == 2'b10;
	assign mv_incdec = mv_postinc || mv_predec;
	wire is_mv_off_ni_ptr = decoded[51-:7] == 7'd101;
	assign mv_ptr = ((is_mv_store || is_mv_off_ni_ptr) || is_mv_abs_ni ? rf_rs2_data : rf_rs1_data);
	assign mv_load_ptr_wr = (((state_q == 6'd6) && is_mv_load) && mv_incdec) && mem_ack;
	wire [4:0] mv_fs_raw;
	wire [5:0] mv_fs;
	wire mv_fe;
	wire [31:0] mv_fs_ext;
	wire [31:0] mv_fmask;
	reg [31:0] mv_load_data;
	localparam [31:0] tms34010_pkg_ST_FS0_HI = 4;
	localparam [31:0] tms34010_pkg_ST_FS0_LO = 0;
	localparam [31:0] tms34010_pkg_ST_FS1_HI = 10;
	localparam [31:0] tms34010_pkg_ST_FS1_LO = 6;
	assign mv_fs_raw = (instr_word_q[9] ? st_value[tms34010_pkg_ST_FS1_HI:tms34010_pkg_ST_FS1_LO] : st_value[tms34010_pkg_ST_FS0_HI:tms34010_pkg_ST_FS0_LO]);
	function automatic signed [5:0] sv2v_cast_13C0F_signed;
		input reg signed [5:0] inp;
		sv2v_cast_13C0F_signed = inp;
	endfunction
	function automatic [5:0] sv2v_cast_13C0F;
		input reg [5:0] inp;
		sv2v_cast_13C0F = inp;
	endfunction
	assign mv_fs = (decoded[5] ? sv2v_cast_13C0F_signed(8) : (decoded[4] ? io_psize[5:0] : (mv_fs_raw == 5'd0 ? sv2v_cast_13C0F(tms34010_pkg_DATA_WIDTH) : {1'b0, mv_fs_raw})));
	localparam [31:0] tms34010_pkg_ST_FE0_BIT = 5;
	localparam [31:0] tms34010_pkg_ST_FE1_BIT = 11;
	assign mv_fe = (decoded[5] ? 1'b1 : (decoded[4] ? 1'b0 : (instr_word_q[9] ? st_value[tms34010_pkg_ST_FE1_BIT] : st_value[tms34010_pkg_ST_FE0_BIT])));
	assign mv_fs_ext = sv2v_cast_DEBC9(mv_fs);
	assign mv_fmask = (mv_fs >= sv2v_cast_13C0F(tms34010_pkg_DATA_WIDTH) ? {32 {1'sb1}} : (32'd1 << mv_fs) - 32'd1);
	always @(*) begin
		if (_sv2v_0)
			;
		if (mv_fs >= sv2v_cast_13C0F(tms34010_pkg_DATA_WIDTH))
			mv_load_data = mem_rdata_eff;
		else if (mv_fe && mem_rdata_eff[mv_fs - 6'd1])
			mv_load_data = mem_rdata_eff | ~mv_fmask;
		else
			mv_load_data = mem_rdata_eff & mv_fmask;
	end
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst)
				mv_load_data_q <= 1'sb0;
			else if (((state_q == 6'd6) && mem_ack) && (((decoded[51-:7] == 7'd75) || (decoded[51-:7] == 7'd78)) || (decoded[51-:7] == 7'd80)))
				mv_load_data_q <= mv_load_data;
		end
	wire [31:0] pixt_pmask_field;
	wire [31:0] pixt_processed;
	wire pixt_transp;
	wire [31:0] pixt_merged;
	assign srt_pixt = decoded[4] && io_dpyctl_live[tms34010_pkg_DPYCTL_SRT_BIT];
	assign pixt_rmw = (decoded[4] && is_mv_store) && !srt_pixt;
	assign pixt_pmask_field = {{16 {1'b0}}, io_pmask} & mv_fmask;
	assign pixt_processed = ppop_apply(rf_rs1_data, pix_dest_q, io_control[tms34010_pkg_CTRL_PPOP_HI:tms34010_pkg_CTRL_PPOP_LO], mv_fmask);
	assign pixt_transp = io_control[tms34010_pkg_CTRL_T_BIT] && ((pixt_processed & mv_fmask) == {32 {1'sb0}});
	reg [31:0] pixt_wstart_q;
	reg [31:0] pixt_wend_q;
	wire pixt_in_window;
	wire pixt_clip_out;
	assign pixt_xy_win = (pixt_rmw && decoded[3]) && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] != 2'd0);
	assign pixt_in_window = (((mv_ptr[15:0] >= pixt_wstart_q[15:0]) && (mv_ptr[15:0] <= pixt_wend_q[15:0])) && (mv_ptr[31:16] >= pixt_wstart_q[31:16])) && (mv_ptr[31:16] <= pixt_wend_q[31:16]);
	assign pixt_clip_out = pixt_xy_win && ((io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd1) || !pixt_in_window);
	assign pixt_merged = (pixt_transp || pixt_clip_out ? pix_dest_q : (pixt_processed & ~pixt_pmask_field) | (pix_dest_q & pixt_pmask_field));
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				pixt_wstart_q <= 1'sb0;
				pixt_wend_q <= 1'sb0;
				pixt_inside_q <= 1'b0;
			end
			else begin
				if (state_q == 6'd37) begin
					pixt_wstart_q <= rf_rs1_data;
					pixt_wend_q <= rf_rs2_data;
				end
				if ((((state_q == 6'd6) && pixt_rmw) && (mem_op_step == 2'd1)) && mem_ack)
					pixt_inside_q <= pixt_in_window;
			end
		end
	wire [15:0] pix_xy_conv;
	wire [4:0] pix_xy_yshift;
	wire [31:0] pix_xy_linear;
	assign pix_xy_conv = (is_mv_store ? io_convdp : io_convsp);
	assign pix_xy_yshift = 5'd31 - pix_xy_conv[4:0];
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (io_psize[4:0])
			5'd1: pix_xy_xsh = 5'd0;
			5'd2: pix_xy_xsh = 5'd1;
			5'd4: pix_xy_xsh = 5'd2;
			5'd8: pix_xy_xsh = 5'd3;
			5'd16: pix_xy_xsh = 5'd4;
			default: pix_xy_xsh = 5'd0;
		endcase
	end
	assign pix_xy_linear = (({{16 {mv_ptr[31]}}, mv_ptr[31:16]} << pix_xy_yshift) | ({16'b0000000000000000, mv_ptr[15:0]} << pix_xy_xsh)) + rf_rs3_data;
	assign mv_addr = (decoded[3] ? pix_xy_linear : (mv_predec ? mv_ptr - mv_fs_ext : mv_ptr));
	assign mv_ptr_new = (mv_predec ? mv_ptr - mv_fs_ext : mv_ptr + mv_fs_ext);
	wire [4:0] pix_xy_dst_yshift;
	assign pix_xy_dst_yshift = 5'd31 - io_convdp[4:0];
	assign pix_xy_dst_linear = (({{16 {rf_rs2_data[31]}}, rf_rs2_data[31:16]} << pix_xy_dst_yshift) | ({16'b0000000000000000, rf_rs2_data[15:0]} << pix_xy_xsh)) + rf_rs3_data;
	wire is_mv_m2m;
	wire m2m_same_reg;
	wire m2m_src_wr;
	wire [31:0] m2m_src_addr;
	wire [31:0] m2m_dst_addr;
	wire [31:0] m2m_src_new;
	wire [31:0] m2m_dst_new;
	assign is_mv_m2m = decoded[51-:7] == 7'd76;
	assign m2m_same_reg = decoded[39-:4] == decoded[43-:4];
	assign m2m_src_addr = (decoded[3] ? pix_xy_linear : (mv_predec ? rf_rs1_data - mv_fs_ext : rf_rs1_data));
	assign m2m_dst_addr = (decoded[3] ? pix_xy_dst_linear : (mv_predec ? rf_rs2_data - mv_fs_ext : rf_rs2_data));
	assign m2m_src_new = (mv_predec ? rf_rs1_data - mv_fs_ext : rf_rs1_data + mv_fs_ext);
	assign m2m_dst_new = (mv_predec ? rf_rs2_data - mv_fs_ext : rf_rs2_data + mv_fs_ext);
	assign m2m_src_wr = ((((state_q == 6'd6) && is_mv_m2m) && mv_incdec) && (mem_op_step == 2'd0)) && mem_ack;
	wire fill_wb;
	wire pblt_wb_saddr;
	wire pblt_wb_daddr;
	wire graphics_wb;
	assign fill_wb = state_q == 6'd11;
	assign pblt_wb_saddr = state_q == 6'd14;
	assign pblt_wb_daddr = state_q == 6'd15;
	wire line_wb_d;
	wire line_wb_daddr;
	wire line_wb_count;
	wire line_wb;
	assign line_wb_d = state_q == 6'd33;
	assign line_wb_daddr = state_q == 6'd34;
	assign line_wb_count = state_q == 6'd35;
	assign line_wb = (line_wb_d || line_wb_daddr) || line_wb_count;
	assign graphics_wb = ((fill_wb || pblt_wb_saddr) || pblt_wb_daddr) || line_wb;
	wire int_sp_wb;
	assign int_sp_wb = (state_q == 6'd20) && int_push_q;
	assign rf_wr_en = ((((((((state_q == 6'd7) && decoded[14]) && dsj_precondition) && !(is_mv_m2m && m2m_same_reg)) && !(is_div && div_v)) || mv_load_ptr_wr) || m2m_src_wr) || graphics_wb) || int_sp_wb;
	assign rf_wr_file = (int_sp_wb ? 1'b0 : (graphics_wb ? 1'b1 : decoded[44]));
	assign rf_wr_idx = (int_sp_wb ? tms34010_pkg_REG_SP_IDX : (line_wb_count ? tms34010_pkg_B_COUNT_IDX : ((fill_wb || pblt_wb_daddr) || line_wb_daddr ? tms34010_pkg_B_DADDR_IDX : (pblt_wb_saddr || line_wb_d ? tms34010_pkg_B_SADDR_IDX : (mv_load_ptr_wr || m2m_src_wr ? decoded[39-:4] : ((is_mpy || is_div) && pair_wb_step ? decoded[43-:4] + 4'd1 : decoded[43-:4]))))));
	wire [4:0] exgf_cur_fs;
	wire exgf_cur_fe;
	wire [31:0] exgf_new_rd;
	reg [31:0] exgf_new_st;
	assign exgf_cur_fs = (instr_word_q[9] ? st_value[tms34010_pkg_ST_FS1_HI:tms34010_pkg_ST_FS1_LO] : st_value[tms34010_pkg_ST_FS0_HI:tms34010_pkg_ST_FS0_LO]);
	assign exgf_cur_fe = (instr_word_q[9] ? st_value[tms34010_pkg_ST_FE1_BIT] : st_value[tms34010_pkg_ST_FE0_BIT]);
	assign exgf_new_rd = {{26 {1'b0}}, exgf_cur_fe, exgf_cur_fs};
	always @(*) begin
		if (_sv2v_0)
			;
		exgf_new_st = st_value;
		if (instr_word_q[9]) begin
			exgf_new_st[tms34010_pkg_ST_FS1_HI:tms34010_pkg_ST_FS1_LO] = rf_rs2_data[4:0];
			exgf_new_st[tms34010_pkg_ST_FE1_BIT] = rf_rs2_data[5];
		end
		else begin
			exgf_new_st[tms34010_pkg_ST_FS0_HI:tms34010_pkg_ST_FS0_LO] = rf_rs2_data[4:0];
			exgf_new_st[tms34010_pkg_ST_FE0_BIT] = rf_rs2_data[5];
		end
	end
	wire [15:0] xy_rs_x;
	wire [15:0] xy_rs_y;
	wire [15:0] xy_rd_x;
	wire [15:0] xy_rd_y;
	wire [15:0] xy_x_add;
	wire [15:0] xy_y_add;
	wire [15:0] xy_x_sub;
	wire [15:0] xy_y_sub;
	wire [31:0] addxy_result;
	wire [31:0] subxy_result;
	wire [3:0] addxy_flags;
	wire [3:0] subxy_flags;
	assign xy_rs_x = rf_rs1_data[15:0];
	assign xy_rs_y = rf_rs1_data[31:16];
	assign xy_rd_x = rf_rs2_data[15:0];
	assign xy_rd_y = rf_rs2_data[31:16];
	assign xy_x_add = xy_rd_x + xy_rs_x;
	assign xy_y_add = xy_rd_y + xy_rs_y;
	assign xy_x_sub = xy_rd_x - xy_rs_x;
	assign xy_y_sub = xy_rd_y - xy_rs_y;
	assign addxy_result = {xy_y_add, xy_x_add};
	assign subxy_result = {xy_y_sub, xy_x_sub};
	assign addxy_flags = {xy_x_add == 16'd0, xy_y_add[15], xy_y_add == 16'd0, xy_x_add[15]};
	assign subxy_flags = {xy_x_sub == 16'd0, $signed(xy_rs_y) > $signed(xy_rd_y), xy_y_sub == 16'd0, $signed(xy_rs_x) > $signed(xy_rd_x)};
	wire [3:0] cmpxy_flags;
	assign cmpxy_flags = {xy_x_sub == 16'd0, xy_y_sub[15], xy_y_sub == 16'd0, xy_x_sub[15]};
	wire [15:0] cpw_pt_x;
	wire [15:0] cpw_pt_y;
	wire [15:0] cpw_ws_x;
	wire [15:0] cpw_ws_y;
	wire [15:0] cpw_we_x;
	wire [15:0] cpw_we_y;
	wire cpw_b5;
	wire cpw_b6;
	wire cpw_b7;
	wire cpw_b8;
	wire [31:0] cpw_result;
	wire [3:0] cpw_flags;
	assign cpw_pt_x = rf_rs1_data[15:0];
	assign cpw_pt_y = rf_rs1_data[31:16];
	assign cpw_ws_x = rf_rs2_data[15:0];
	assign cpw_ws_y = rf_rs2_data[31:16];
	assign cpw_we_x = rf_rs3_data[15:0];
	assign cpw_we_y = rf_rs3_data[31:16];
	assign cpw_b5 = $signed(cpw_ws_x) > $signed(cpw_pt_x);
	assign cpw_b6 = $signed(cpw_pt_x) > $signed(cpw_we_x);
	assign cpw_b7 = $signed(cpw_ws_y) > $signed(cpw_pt_y);
	assign cpw_b8 = $signed(cpw_pt_y) > $signed(cpw_we_y);
	assign cpw_result = {{23 {1'b0}}, cpw_b8, cpw_b7, cpw_b6, cpw_b5, 5'b00000};
	assign cpw_flags = {3'b000, ((cpw_b5 | cpw_b6) | cpw_b7) | cpw_b8};
	wire [4:0] cvxyl_ydp_shift;
	reg [4:0] cvxyl_xsh;
	wire [31:0] cvxyl_ypart;
	wire [31:0] cvxyl_xpart;
	wire [31:0] cvxyl_result;
	assign cvxyl_ydp_shift = 5'd31 - io_convdp[4:0];
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (io_psize[4:0])
			5'd1: cvxyl_xsh = 5'd0;
			5'd2: cvxyl_xsh = 5'd1;
			5'd4: cvxyl_xsh = 5'd2;
			5'd8: cvxyl_xsh = 5'd3;
			5'd16: cvxyl_xsh = 5'd4;
			default: cvxyl_xsh = 5'd0;
		endcase
	end
	assign cvxyl_ypart = {{16 {rf_rs1_data[31]}}, rf_rs1_data[31:16]} << cvxyl_ydp_shift;
	assign cvxyl_xpart = {16'b0000000000000000, rf_rs1_data[15:0]} << cvxyl_xsh;
	assign cvxyl_result = (cvxyl_ypart | cvxyl_xpart) + rf_rs3_data;
	wire signed [63:0] mpy_sprod;
	wire [63:0] mpy_uprod;
	wire [63:0] mpy_product;
	reg [63:0] mpy_product_q;
	assign is_mpy = (decoded[51-:7] == 7'd87) || (decoded[51-:7] == 7'd88);
	assign mpy_signed = decoded[51-:7] == 7'd87;
	assign mpy_rd_even = decoded[40] == 1'b0;
	wire [4:0] mpy_fs1;
	wire [31:0] mpy_fmask;
	reg [31:0] mpy_rs_field;
	assign mpy_fs1 = st_value[tms34010_pkg_ST_FS1_HI:tms34010_pkg_ST_FS1_LO];
	assign mpy_fmask = (32'd1 << mpy_fs1) - 32'd1;
	always @(*) begin
		if (_sv2v_0)
			;
		if (mpy_fs1 == 5'd0)
			mpy_rs_field = rf_rs1_data;
		else if (mpy_signed && rf_rs1_data[mpy_fs1 - 5'd1])
			mpy_rs_field = (rf_rs1_data & mpy_fmask) | ~mpy_fmask;
		else
			mpy_rs_field = rf_rs1_data & mpy_fmask;
	end
	assign mpy_sprod = $signed(rf_rs2_data) * $signed(mpy_rs_field);
	assign mpy_uprod = rf_rs2_data * mpy_rs_field;
	assign mpy_product = (mpy_signed ? $unsigned(mpy_sprod) : mpy_uprod);
	wire is_signed_div;
	wire is_div_mod;
	wire div_rd_even;
	wire div_use_pair;
	reg [63:0] div_dividend;
	wire [31:0] div_divisor;
	wire [31:0] div_quotient;
	wire [31:0] div_remainder;
	wire div_start;
	wire div_busy;
	wire div_done;
	wire div_overflow;
	assign is_divu = decoded[51-:7] == 7'd89;
	assign is_modu = decoded[51-:7] == 7'd90;
	assign is_divs = decoded[51-:7] == 7'd91;
	assign is_mods = decoded[51-:7] == 7'd92;
	assign is_div = ((is_divu || is_modu) || is_divs) || is_mods;
	assign is_signed_div = is_divs || is_mods;
	assign is_div_mod = is_modu || is_mods;
	assign div_rd_even = decoded[40] == 1'b0;
	assign div_use_pair = (is_divu || is_divs) && div_rd_even;
	wire div_dvd_sign;
	wire div_dvs_sign;
	wire div_result_neg;
	reg div_dvd_sign_q;
	reg div_dvs_sign_q;
	assign div_dvd_sign = is_signed_div && rf_rs2_data[31];
	assign div_dvs_sign = is_signed_div && rf_rs1_data[31];
	assign div_result_neg = div_dvd_sign_q ^ div_dvs_sign_q;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				div_dvd_sign_q <= 1'b0;
				div_dvs_sign_q <= 1'b0;
			end
			else if ((state_q == 6'd5) && is_div) begin
				div_dvd_sign_q <= div_dvd_sign;
				div_dvs_sign_q <= div_dvs_sign;
			end
		end
	wire [31:0] rd_abs;
	wire [63:0] raw64;
	wire [63:0] abs64;
	assign rd_abs = (rf_rs2_data[31] ? ~rf_rs2_data + 1'b1 : rf_rs2_data);
	assign raw64 = {rf_rs2_data, rf_rs3_data};
	assign abs64 = (rf_rs2_data[31] ? ~raw64 + 1'b1 : raw64);
	always @(*) begin
		if (_sv2v_0)
			;
		if (!is_signed_div)
			div_dividend = (div_use_pair ? raw64 : {{tms34010_pkg_DATA_WIDTH {1'b0}}, rf_rs2_data});
		else if (div_use_pair)
			div_dividend = abs64;
		else
			div_dividend = {{tms34010_pkg_DATA_WIDTH {1'b0}}, rd_abs};
	end
	assign div_divisor = (div_dvs_sign ? ~rf_rs1_data + 1'b1 : rf_rs1_data);
	assign div_start = (state_q == 6'd5) && is_div;
	tms34010_divider u_divider(
		.clk(clk),
		.ce_cpu(ce_cpu),
		.rst(rst),
		.start(div_start),
		.dividend(div_dividend),
		.divisor(div_divisor),
		.busy(div_busy),
		.done(div_done),
		.quotient(div_quotient),
		.remainder(div_remainder),
		.overflow(div_overflow)
	);
	wire [31:0] div_quot_out;
	wire [31:0] div_rem_out;
	wire [31:0] div_result_main;
	assign div_quot_out = (div_result_neg ? ~div_quotient + 1'b1 : div_quotient);
	assign div_rem_out = (div_dvd_sign_q ? ~div_remainder + 1'b1 : div_remainder);
	assign div_result_main = (is_div_mod ? div_rem_out : div_quot_out);
	assign div_signed_ovf = div_overflow || (is_signed_div && (div_result_neg ? div_quotient[31] && (div_quotient[30:0] != {31 {1'sb0}}) : div_quotient[31]));
	assign div_v = (is_signed_div ? div_signed_ovf : div_overflow);
	assign is_pair_wb = (is_mpy && mpy_rd_even) || (div_use_pair && !div_v);
	assign pair_second_pass = is_pair_wb && (pair_wb_step == 1'b0);
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				mpy_product_q <= 1'sb0;
				pair_wb_step <= 1'b0;
			end
			else begin
				if ((state_q == 6'd5) && is_mpy)
					mpy_product_q <= mpy_product;
				if (state_q == 6'd7)
					pair_wb_step <= (pair_second_pass ? 1'b1 : 1'b0);
				else
					pair_wb_step <= 1'b0;
			end
		end
	wire [4:0] fs_selected;
	reg [31:0] field_mask;
	reg field_msb;
	reg [31:0] sext_result;
	reg [31:0] zext_result;
	assign fs_selected = (instr_word_q[9] ? st_value[tms34010_pkg_ST_FS1_HI:tms34010_pkg_ST_FS1_LO] : st_value[tms34010_pkg_ST_FS0_HI:tms34010_pkg_ST_FS0_LO]);
	always @(*) begin
		if (_sv2v_0)
			;
		if (fs_selected == 5'd0) begin
			field_mask = 1'sb1;
			field_msb = rf_rs2_data[31];
			sext_result = rf_rs2_data;
			zext_result = rf_rs2_data;
		end
		else begin
			field_mask = (32'd1 << fs_selected) - 32'd1;
			field_msb = rf_rs2_data[fs_selected - 5'd1];
			sext_result = (field_msb ? (rf_rs2_data & field_mask) | ~field_mask : rf_rs2_data & field_mask);
			zext_result = rf_rs2_data & field_mask;
		end
	end
	reg [4:0] lmo_bit_pos;
	reg [31:0] lmo_result;
	function automatic signed [4:0] sv2v_cast_5_signed;
		input reg signed [4:0] inp;
		sv2v_cast_5_signed = inp;
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		lmo_bit_pos = 5'd0;
		begin : sv2v_autoblock_3
			reg signed [31:0] i;
			for (i = 0; i < tms34010_pkg_DATA_WIDTH; i = i + 1)
				if (rf_rs1_data[i])
					lmo_bit_pos = sv2v_cast_5_signed(i);
		end
		if (rf_rs1_data == {32 {1'sb0}})
			lmo_result = 1'sb0;
		else
			lmo_result = {{27 {1'b0}}, ~lmo_bit_pos};
	end
	localparam [31:0] tms34010_pkg_REV_VALUE = 32'h00000008;
	localparam [31:0] tms34010_pkg_WORD_BIT_SIZE_2 = sv2v_cast_DEBC9(64);
	always @(*) begin
		if (_sv2v_0)
			;
		if (int_sp_wb)
			rf_wr_data = rf_sp - tms34010_pkg_WORD_BIT_SIZE_2;
		else
			(* full_case, parallel_case *)
			case (decoded[51-:7])
				7'd81: rf_wr_data = {rf_rs2_data[31:16], rf_rs1_data[15:0]};
				7'd82: rf_wr_data = {rf_rs1_data[31:16], rf_rs2_data[15:0]};
				7'd83: rf_wr_data = addxy_result;
				7'd84: rf_wr_data = subxy_result;
				7'd97: rf_wr_data = drav_advance;
				7'd86: rf_wr_data = cpw_result;
				7'd87, 7'd88: rf_wr_data = (mpy_rd_even ? (pair_wb_step ? mpy_product_q[31:0] : mpy_product_q[63:32]) : mpy_product_q[31:0]);
				7'd89, 7'd91: rf_wr_data = (div_rd_even && pair_wb_step ? div_rem_out : div_quot_out);
				7'd90, 7'd92: rf_wr_data = div_rem_out;
				7'd47: rf_wr_data = st_value;
				7'd72: rf_wr_data = mm_rp_q;
				7'd73: rf_wr_data = mm_rp_q;
				7'd74: rf_wr_data = mv_ptr_new;
				7'd101: rf_wr_data = mv_ptr_new;
				7'd102: rf_wr_data = mv_ptr_new;
				7'd75: rf_wr_data = (mv_load_ptr_wr ? mv_ptr_new : mv_load_data_q);
				7'd76: rf_wr_data = (m2m_src_wr ? m2m_src_new : m2m_dst_new);
				7'd78, 7'd80: rf_wr_data = mv_load_data_q;
				7'd93: rf_wr_data = cvxyl_result;
				7'd94, 7'd95: rf_wr_data = fill_addr_q;
				7'd96: rf_wr_data = (pblt_wb_saddr ? pblt_src_addr_q : (decoded[1] ? {pblt_dst_xy_raw_q[31:16] + pblt_dy_q, pblt_dst_xy_raw_q[15:0]} : pblt_dst_addr_q));
				7'd98: rf_wr_data = (line_wb_d ? line_d_q : (line_wb_daddr ? line_daddr_q : line_count_q));
				7'd54, 7'd55: rf_wr_data = pc_value;
				7'd56: rf_wr_data = tms34010_pkg_REV_VALUE;
				7'd57: rf_wr_data = lmo_result;
				7'd59: rf_wr_data = sext_result;
				7'd60: rf_wr_data = zext_result;
				7'd61: rf_wr_data = exgf_new_rd;
				default: rf_wr_data = (decoded[24] ? shifter_result : alu_result);
			endcase
	end
	assign alu_op = decoded[31-:4];
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (decoded[51-:7])
			7'd5, 7'd33, 7'd7, 7'd10, 7'd12, 7'd13, 7'd14, 7'd15, 7'd41, 7'd16, 7'd17, 7'd18, 7'd24, 7'd25, 7'd26, 7'd27, 7'd28, 7'd29, 7'd36, 7'd37, 7'd38, 7'd40, 7'd43, 7'd44: alu_a = rf_rs2_data;
			7'd42: alu_a = 1'sb0;
			7'd64, 7'd65, 7'd66, 7'd68, 7'd69, 7'd67, 7'd70, 7'd71: alu_a = rf_rs2_data;
			default: alu_a = rf_rs1_data;
		endcase
	end
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (decoded[51-:7])
			7'd17, 7'd18, 7'd25, 7'd26: alu_b = ~imm32;
			7'd1, 7'd2, 7'd16, 7'd24, 7'd27, 7'd28, 7'd29: alu_b = imm32;
			7'd3, 7'd12, 7'd13: alu_b = (decoded[23-:5] == 5'd0 ? 32'd32 : {{27 {1'b0}}, decoded[23-:5]});
			7'd36, 7'd37, 7'd38, 7'd40: alu_b = {{27 {1'b0}}, decoded[23-:5]};
			7'd43: alu_b = 32'd1 << decoded[23-:5];
			7'd44: alu_b = 32'd1 << rf_rs1_data[4:0];
			7'd64, 7'd65, 7'd66, 7'd68, 7'd69: alu_b = tms34010_pkg_WORD_BIT_SIZE;
			7'd67: alu_b = tms34010_pkg_WORD_BIT_SIZE + ({{27 {1'b0}}, decoded[23-:5]} << 4);
			7'd70: alu_b = tms34010_pkg_WORD_BIT_SIZE_2;
			7'd71: alu_b = (trap_skip_push ? 32'd0 : tms34010_pkg_WORD_BIT_SIZE_2);
			7'd5, 7'd33, 7'd7, 7'd10: alu_b = rf_rs1_data;
			default: alu_b = rf_rs2_data;
		endcase
	end
	assign alu_cin = st_c;
	assign st_flag_update_en = ((state_q == 6'd7) && decoded[13]) || fill_win_flag_wb;
	reg [31:0] setf_new_st;
	always @(*) begin
		if (_sv2v_0)
			;
		setf_new_st = st_value;
		if (instr_word_q[9]) begin
			setf_new_st[tms34010_pkg_ST_FS1_HI:tms34010_pkg_ST_FS1_LO] = instr_word_q[4:0];
			setf_new_st[tms34010_pkg_ST_FE1_BIT] = instr_word_q[5];
		end
		else begin
			setf_new_st[tms34010_pkg_ST_FS0_HI:tms34010_pkg_ST_FS0_LO] = instr_word_q[4:0];
			setf_new_st[tms34010_pkg_ST_FE0_BIT] = instr_word_q[5];
		end
	end
	assign st_write_en = ((state_q == 6'd7) && ((((((((decoded[51-:7] == 7'd48) || (decoded[51-:7] == 7'd58)) || (decoded[51-:7] == 7'd61)) || (decoded[51-:7] == 7'd62)) || (decoded[51-:7] == 7'd63)) || (decoded[51-:7] == 7'd65)) || (decoded[51-:7] == 7'd70)) || (decoded[51-:7] == 7'd71))) || ((state_q == 6'd20) && int_push_q);
	localparam [31:0] tms34010_pkg_ST_IE_BIT = 21;
	localparam [31:0] tms34010_pkg_ST_RESET_VALUE = 32'h00000010;
	always @(*) begin
		if (_sv2v_0)
			;
		if (state_q == 6'd20)
			st_write_data = tms34010_pkg_ST_RESET_VALUE;
		else
			(* full_case, parallel_case *)
			case (decoded[51-:7])
				7'd48: st_write_data = rf_rs1_data;
				7'd58: st_write_data = setf_new_st;
				7'd61: st_write_data = exgf_new_st;
				7'd62: st_write_data = st_value & ~(32'd1 << tms34010_pkg_ST_IE_BIT);
				7'd63: st_write_data = st_value | (32'd1 << tms34010_pkg_ST_IE_BIT);
				7'd65: st_write_data = mem_rdata_eff;
				7'd70: st_write_data = popped_st_q;
				7'd71: st_write_data = tms34010_pkg_ST_RESET_VALUE;
				default: st_write_data = 1'sb0;
			endcase
	end
	reg branch_taken;
	localparam [3:0] tms34010_pkg_CC_C = 4'b1000;
	localparam [3:0] tms34010_pkg_CC_EQ = 4'b1010;
	localparam [3:0] tms34010_pkg_CC_GE = 4'b0101;
	localparam [3:0] tms34010_pkg_CC_GT = 4'b0111;
	localparam [3:0] tms34010_pkg_CC_HI = 4'b0011;
	localparam [3:0] tms34010_pkg_CC_HS = 4'b1001;
	localparam [3:0] tms34010_pkg_CC_LE = 4'b0110;
	localparam [3:0] tms34010_pkg_CC_LS = 4'b0010;
	localparam [3:0] tms34010_pkg_CC_LT = 4'b0100;
	localparam [3:0] tms34010_pkg_CC_N = 4'b1110;
	localparam [3:0] tms34010_pkg_CC_NE = 4'b1011;
	localparam [3:0] tms34010_pkg_CC_NN = 4'b1111;
	localparam [3:0] tms34010_pkg_CC_NV = 4'b1101;
	localparam [3:0] tms34010_pkg_CC_P = 4'b0001;
	localparam [3:0] tms34010_pkg_CC_UC = 4'b0000;
	localparam [3:0] tms34010_pkg_CC_V = 4'b1100;
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (decoded[18-:4])
			tms34010_pkg_CC_UC: branch_taken = 1'b1;
			tms34010_pkg_CC_P: branch_taken = !st_n & !st_z;
			tms34010_pkg_CC_LS: branch_taken = st_c | st_z;
			tms34010_pkg_CC_HI: branch_taken = !st_c & !st_z;
			tms34010_pkg_CC_LT: branch_taken = st_n ^ st_v;
			tms34010_pkg_CC_LE: branch_taken = (st_n ^ st_v) | st_z;
			tms34010_pkg_CC_GT: branch_taken = !(st_n ^ st_v) & !st_z;
			tms34010_pkg_CC_GE: branch_taken = !(st_n ^ st_v);
			tms34010_pkg_CC_EQ: branch_taken = st_z;
			tms34010_pkg_CC_NE: branch_taken = !st_z;
			tms34010_pkg_CC_HS: branch_taken = !st_c;
			tms34010_pkg_CC_C: branch_taken = st_c;
			tms34010_pkg_CC_V: branch_taken = st_v;
			tms34010_pkg_CC_NV: branch_taken = !st_v;
			tms34010_pkg_CC_N: branch_taken = st_n;
			tms34010_pkg_CC_NN: branch_taken = !st_n;
			default: branch_taken = 1'b0;
		endcase
	end
	always @(*) begin
		if (_sv2v_0)
			;
		pc_load_en = 1'b0;
		pc_load_value = 1'sb0;
		if (state_q == 6'd7)
			(* full_case, parallel_case *)
			case (decoded[51-:7])
				7'd11:
					if (branch_taken) begin
						pc_load_en = 1'b1;
						pc_load_value = branch_target_short;
					end
				7'd34:
					if (branch_taken) begin
						pc_load_en = 1'b1;
						pc_load_value = branch_target_long;
					end
				7'd35: begin
					pc_load_en = 1'b1;
					pc_load_value = {rf_rs1_data[31:4], 4'h0};
				end
				7'd55: begin
					pc_load_en = 1'b1;
					pc_load_value = {rf_rs2_data[31:4], 4'h0};
				end
				7'd36, 7'd37, 7'd38:
					if (dsj_precondition && dsj_rd_nonzero) begin
						pc_load_en = 1'b1;
						pc_load_value = branch_target_long;
					end
				7'd39:
					if (branch_taken) begin
						pc_load_en = 1'b1;
						pc_load_value = branch_target_jacc;
					end
				7'd40:
					if (dsj_rd_nonzero) begin
						pc_load_en = 1'b1;
						pc_load_value = branch_target_dsjs;
					end
				7'd66: begin
					pc_load_en = 1'b1;
					pc_load_value = {rf_rs1_data[31:4], 4'h0};
				end
				7'd68: begin
					pc_load_en = 1'b1;
					pc_load_value = branch_target_jacc;
				end
				7'd69: begin
					pc_load_en = 1'b1;
					pc_load_value = branch_target_long;
				end
				7'd67: begin
					pc_load_en = 1'b1;
					pc_load_value = mem_rdata_eff;
				end
				7'd70: begin
					pc_load_en = 1'b1;
					pc_load_value = popped_pc_q;
				end
				7'd71: begin
					pc_load_en = 1'b1;
					pc_load_value = popped_pc_q;
				end
				default:
					;
			endcase
		else if (state_q == 6'd20) begin
			pc_load_en = 1'b1;
			pc_load_value = popped_pc_q;
		end
		else if ((state_q == 6'd38) && mem_ack) begin
			pc_load_en = 1'b1;
			pc_load_value = mem_rdata_eff;
		end
	end
	tms34010_regfile u_regfile(
		.clk(clk),
		.ce_cpu(ce_cpu),
		.rst(rst),
		.rs1_file(rf_rs1_file),
		.rs1_idx(rf_rs1_idx),
		.rs1_data(rf_rs1_data),
		.rs2_file(rf_rs2_file),
		.rs2_idx(rf_rs2_idx),
		.rs2_data(rf_rs2_data),
		.rs3_file(rf_rs3_file),
		.rs3_idx(rf_rs3_idx),
		.rs3_data(rf_rs3_data),
		.wr_en(rf_wr_en),
		.wr_file(rf_wr_file),
		.wr_idx(rf_wr_idx),
		.wr_data(rf_wr_data),
		.aux_wr_target(mmfm_commit_target_q),
		.aux_wr_data(mmfm_commit_data_q),
		.sp_o(rf_sp)
	);
	wire io_is_io;
	wire [15:0] io_rdata16;
	wire [15:0] io_rdata_cpu16;
	wire [15:0] io_intenb;
	wire [15:0] io_intpend;
	wire [15:0] io_hstctlh;
	wire [15:0] io_intenb_live;
	wire [15:0] io_intpend_live;
	wire [15:0] io_hstctlh_live;
	wire nmi_clear;
	reg mem_we_int;
	wire io_wr_valid;
	wire [31:0] io_wr_addr;
	wire [31:0] io_wr_data;
	wire [5:0] io_wr_size;
	wire [4:0] io_wr_idx;
	wire [4:0] io_wr_idx_hi;
	wire io_wr_span2;
	wire [15:0] io_wr_low_mask;
	wire [15:0] io_wr_low_data;
	wire io_wr_status_guard;
	localparam [4:0] tms34010_pkg_IO_IDX_DPYADR = 5'h1e;
	localparam [4:0] tms34010_pkg_IO_IDX_DPYCTL = 5'h08;
	localparam [4:0] tms34010_pkg_IO_IDX_DPYSTRT = 5'h09;
	localparam [4:0] tms34010_pkg_IO_IDX_DPYTAP = 5'h1b;
	localparam [4:0] tms34010_pkg_IO_IDX_HEBLNK = 5'h01;
	localparam [4:0] tms34010_pkg_IO_IDX_HSBLNK = 5'h02;
	localparam [4:0] tms34010_pkg_IO_IDX_VEBLNK = 5'h05;
	localparam [4:0] tms34010_pkg_IO_IDX_VSBLNK = 5'h06;
	localparam [4:0] tms34010_pkg_IO_IDX_VTOTAL = 5'h07;
	wire display_wr_idx_match = ((((((((io_wr_idx == tms34010_pkg_IO_IDX_DPYCTL) || (io_wr_idx == tms34010_pkg_IO_IDX_DPYSTRT)) || (io_wr_idx == tms34010_pkg_IO_IDX_DPYTAP)) || (io_wr_idx == tms34010_pkg_IO_IDX_DPYADR)) || (io_wr_idx == tms34010_pkg_IO_IDX_HEBLNK)) || (io_wr_idx == tms34010_pkg_IO_IDX_HSBLNK)) || (io_wr_idx == tms34010_pkg_IO_IDX_VEBLNK)) || (io_wr_idx == tms34010_pkg_IO_IDX_VSBLNK)) || (io_wr_idx == tms34010_pkg_IO_IDX_VTOTAL);
	assign display_wr_valid_o = io_wr_valid && display_wr_idx_match;
	assign display_wr_idx_o = io_wr_idx;
	assign display_wr_data_o = io_wr_data[15:0];
	tms34010_io_write_boundary u_io_write_boundary(
		.clk(clk),
		.rst(rst),
		.ce_cpu(ce_cpu),
		.req(mem_req),
		.we(mem_we_int),
		.is_io(io_is_io),
		.ack(mem_ack),
		.addr(mem_addr),
		.wdata(mem_wdata),
		.size(mem_size),
		.wr_valid(io_wr_valid),
		.wr_addr(io_wr_addr),
		.wr_data(io_wr_data),
		.wr_size(io_wr_size),
		.wr_idx(io_wr_idx),
		.wr_idx_hi(io_wr_idx_hi),
		.wr_span2(io_wr_span2),
		.wr_low_mask(io_wr_low_mask),
		.wr_low_data(io_wr_low_data),
		.wr_status_guard(io_wr_status_guard)
	);
	tms34010_io_regs #(.PREDECODED_WRITE(1'b1)) u_io_regs(
		.clk(clk),
		.rst(rst),
		.ce_pix(ce_pix),
		.req(io_wr_valid),
		.we(1'b1),
		.addr(io_wr_addr),
		.wdata(io_wr_data),
		.size(io_wr_size),
		.write_idx(io_wr_idx),
		.write_idx_hi(io_wr_idx_hi),
		.write_span2(io_wr_span2),
		.low_write_mask(io_wr_low_mask),
		.low_write_data(io_wr_low_data),
		.status_guard(io_wr_status_guard),
		.raddr(mem_addr),
		.rdata(io_rdata16),
		.is_io(io_is_io),
		.psize_o(io_psize_live),
		.convdp_o(io_convdp_live),
		.convsp_o(io_convsp_live),
		.control_o(io_control_live),
		.pmask_o(io_pmask_live),
		.dpyctl_o(io_dpyctl_live),
		.intenb_o(io_intenb_live),
		.intpend_o(io_intpend_live),
		.hstctlh_o(io_hstctlh_live),
		.dpyadr_live_i(display_dpyadr_live_i),
		.dpyadr_live_valid_i(display_dpyadr_live_valid_i),
		.timing_start_o(timing_start_o),
		.line_wrap_o(display_line_wrap_o),
		.nmi_clear(nmi_clear),
		.wvp_set(wvp_set),
		.lint1_in(lint1_in)
	);
	tms34010_io_cpu_config u_io_cpu_config(
		.clk(clk),
		.rst(rst),
		.ce_cpu(ce_cpu),
		.req(mem_req),
		.we(mem_we_int),
		.is_io(io_is_io),
		.ack(mem_ack),
		.addr(mem_addr),
		.wdata(mem_wdata[15:0]),
		.size(mem_size),
		.live_psize(io_psize_live),
		.live_convdp(io_convdp_live),
		.live_convsp(io_convsp_live),
		.live_control(io_control_live),
		.live_pmask(io_pmask_live),
		.psize(io_psize),
		.convdp(io_convdp),
		.convsp(io_convsp),
		.control(io_control),
		.pmask(io_pmask)
	);
	tms34010_io_cpu_status u_io_cpu_status(
		.clk(clk),
		.rst(rst),
		.ce_cpu(ce_cpu),
		.req(mem_req),
		.we(mem_we_int),
		.is_io(io_is_io),
		.ack(mem_ack),
		.addr(mem_addr),
		.wdata(mem_wdata[15:0]),
		.size(mem_size),
		.live_intenb(io_intenb_live),
		.live_intpend(io_intpend_live),
		.live_hstctlh(io_hstctlh_live),
		.nmi_clear(nmi_clear),
		.intenb(io_intenb),
		.intpend(io_intpend),
		.hstctlh(io_hstctlh)
	);
	tms34010_io_cpu_read_mux u_io_cpu_read_mux(
		.is_io(io_is_io),
		.addr(mem_addr),
		.live_rdata(io_rdata16),
		.psize(io_psize),
		.convdp(io_convdp),
		.convsp(io_convsp),
		.control(io_control),
		.pmask(io_pmask),
		.intenb(io_intenb),
		.intpend(io_intpend),
		.hstctlh(io_hstctlh),
		.cpu_rdata(io_rdata_cpu16)
	);
	wire int_req;
	wire [31:0] int_vector;
	tms34010_int_ctrl u_int_ctrl(
		.intpend(io_intpend),
		.intenb(io_intenb),
		.ie(st_value[tms34010_pkg_ST_IE_BIT]),
		.int_req(int_req),
		.int_vector(int_vector)
	);
	wire nmi_req;
	wire nmi_nmim;
	localparam [31:0] tms34010_pkg_HSTCTL_NMI_BIT = 8;
	assign nmi_req = io_hstctlh[tms34010_pkg_HSTCTL_NMI_BIT];
	localparam [31:0] tms34010_pkg_HSTCTL_NMIM_BIT = 9;
	assign nmi_nmim = io_hstctlh[tms34010_pkg_HSTCTL_NMIM_BIT];
	wire int_take;
	assign int_take = nmi_req || int_req;
	reg fetch_inflight_q;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst)
				fetch_inflight_q <= 1'b0;
			else if (((state_q == 6'd1) && mem_req) && !mem_ack)
				fetch_inflight_q <= 1'b1;
			else if (mem_ack || (state_q != 6'd1))
				fetch_inflight_q <= 1'b0;
		end
	reg [31:0] int_vec_q;
	reg int_is_nmi_q;
	localparam [31:0] tms34010_pkg_INT_VEC_NMI = 32'hfffffee0;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				int_vec_q <= 1'sb0;
				int_is_nmi_q <= 1'b0;
				int_push_q <= 1'b0;
			end
			else if ((state_q == 6'd1) && int_take) begin
				int_vec_q <= (nmi_req ? tms34010_pkg_INT_VEC_NMI : int_vector);
				int_is_nmi_q <= nmi_req;
				int_push_q <= (nmi_req ? !nmi_nmim : 1'b1);
			end
		end
	assign nmi_clear = (state_q == 6'd20) && int_is_nmi_q;
	assign mem_we = mem_we_int && !io_is_io;
	wire srt_fill_write_live = state_q == 6'd42;
	wire srt_fill_write = srt_fill_write_live;
	assign shiftreg_req_o = (((state_q == 6'd6) && srt_pixt) && mem_req) || srt_fill_write;
	assign shiftreg_write_o = (srt_fill_write ? 1'b1 : mem_we);
	assign shiftreg_bit_addr_o = (srt_fill_write ? {11'd0, srt_fill_page_q, srt_fill_pair_q, 13'd0} : mem_addr);
	reg [15:0] io_rdata_q;
	reg io_is_io_q;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				io_rdata_q <= 1'sb0;
				io_is_io_q <= 1'b0;
			end
			else if (mem_req && mem_ack) begin
				io_rdata_q <= io_rdata_cpu16;
				io_is_io_q <= io_is_io;
			end
		end
	assign mem_rdata_eff = (mem_req ? (io_is_io ? {{16 {1'b0}}, io_rdata_cpu16} : mem_rdata) : (io_is_io_q ? {{16 {1'b0}}, io_rdata_q} : mem_rdata));
	tms34010_alu u_alu(
		.op(alu_op),
		.a(alu_a),
		.b(alu_b),
		.cin(alu_cin),
		.result(alu_result),
		.flags(alu_flags)
	);
	localparam [31:0] tms34010_pkg_SHIFT_AMOUNT_WIDTH = 5;
	reg [4:0] shifter_amount;
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (decoded[51-:7])
			7'd49, 7'd50, 7'd53: shifter_amount = rf_rs1_data[4:0];
			7'd51, 7'd52: shifter_amount = ~rf_rs1_data[4:0] + {{4 {1'b0}}, 1'b1};
			7'd21, 7'd22: shifter_amount = ~decoded[23-:5] + {{4 {1'b0}}, 1'b1};
			default: shifter_amount = decoded[23-:5];
		endcase
	end
	tms34010_shifter u_shifter(
		.op(decoded[27-:3]),
		.a(rf_rs2_data),
		.amount(shifter_amount),
		.result(shifter_result),
		.flags(shifter_flags)
	);
	reg [3:0] flag_input;
	always @(*) begin
		if (_sv2v_0)
			;
		if (fill_win_flag_wb)
			flag_input = {3'b000, fill_win_violation};
		else
			(* full_case, parallel_case *)
			case (decoded[51-:7])
				7'd46: flag_input = 4'b0100;
				7'd45: flag_input = 4'b0000;
				7'd57: flag_input = {2'b00, rf_rs1_data == 1'b0, 1'b0};
				7'd59: flag_input = {sext_result[31], 1'b0, sext_result == 1'b0, 1'b0};
				7'd60: flag_input = {2'b00, zext_result == 1'b0, 1'b0};
				7'd72: flag_input = {~rf_rs2_data[31], 3'b000};
				7'd75, 7'd78, 7'd80: flag_input = {mv_load_data_q[31], 1'b0, mv_load_data_q == 1'b0, decoded[4] && (mv_load_data_q != 1'b0)};
				7'd83: flag_input = addxy_flags;
				7'd84: flag_input = subxy_flags;
				7'd85: flag_input = cmpxy_flags;
				7'd86: flag_input = cpw_flags;
				7'd87, 7'd88: flag_input = {mpy_product_q[63], 1'b0, mpy_product_q == 64'd0, 1'b0};
				7'd89, 7'd91, 7'd90, 7'd92: flag_input = {(is_signed_div && !div_v) && div_result_main[31], 1'b0, !div_v && (div_result_main == 1'b0), div_v};
				default: flag_input = (decoded[24] ? shifter_flags : alu_flags);
			endcase
	end
	reg [3:0] effective_flag_mask;
	always @(*) begin
		if (_sv2v_0)
			;
		effective_flag_mask = decoded[12-:4];
		if (is_div_mod && div_v)
			effective_flag_mask[1] = 1'b0;
		if (fill_win_flag_wb)
			effective_flag_mask = 4'b0001;
	end
	tms34010_status_reg u_status_reg(
		.clk(clk),
		.ce_cpu(ce_cpu),
		.rst(rst),
		.flag_update_en(st_flag_update_en),
		.flags_in(flag_input),
		.flag_update_mask(effective_flag_mask),
		.st_write_en(st_write_en),
		.st_write_data(st_write_data),
		.st_o(st_value),
		.n_o(st_n),
		.c_o(st_c),
		.z_o(st_z),
		.v_o(st_v)
	);
	wire [31:0] unused_rf_sp;
	wire [31:0] unused_st_value;
	wire unused_st_nv;
	assign unused_rf_sp = rf_sp;
	assign unused_st_value = st_value;
	assign unused_st_nv = (st_n ^ st_v) ^ st_z;
	reg [4:0] cycle_reg_list_count;
	wire [15:0] cycle_budget;
	wire cycle_budget_valid;
	reg gfx_timing_start;
	wire gfx_timing_busy;
	wire gfx_timing_done;
	wire [31:0] gfx_timing_cycles;
	wire gfx_timing_overflow;
	reg [31:0] gfx_timing_saddr_raw_q;
	reg [31:0] gfx_timing_daddr_raw_q;
	reg [31:0] gfx_timing_offset_q;
	reg [31:0] gfx_timing_saddr;
	reg [31:0] gfx_timing_daddr;
	reg [31:0] gfx_timing_dydx;
	reg [31:0] gfx_timing_sptch;
	reg [31:0] gfx_timing_dptch;
	reg [31:0] gfx_timing_offset;
	reg [31:0] gfx_timing_wstart;
	reg [31:0] gfx_timing_wend;
	reg gfx_timing_is_fill;
	reg gfx_timing_is_binary;
	reg gfx_timing_src_xy;
	reg gfx_timing_dst_xy;
	reg gfx_timing_fits_16;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				gfx_timing_saddr_raw_q <= 32'd0;
				gfx_timing_daddr_raw_q <= 32'd0;
				gfx_timing_offset_q <= 32'd0;
			end
			else begin
				if ((state_q == 6'd5) && is_pblt) begin
					gfx_timing_saddr_raw_q <= rf_rs1_data;
					gfx_timing_daddr_raw_q <= rf_rs2_data;
				end
				else if ((state_q == 6'd5) && is_fill) begin
					gfx_timing_saddr_raw_q <= 32'd0;
					gfx_timing_daddr_raw_q <= rf_rs1_data;
				end
				if ((state_q == 6'd9) || (state_q == 6'd12))
					gfx_timing_offset_q <= rf_rs3_data;
			end
		end
	always @(*) begin
		if (_sv2v_0)
			;
		gfx_timing_start = ((((state_q == 6'd9) && (!fill_is_xy || (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd0))) || (state_q == 6'd21)) || ((state_q == 6'd12) && (!decoded[1] || (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd0)))) || (state_q == 6'd22);
		gfx_timing_is_fill = is_fill;
		gfx_timing_is_binary = is_pblt && decoded[0];
		gfx_timing_src_xy = is_pblt && decoded[2];
		gfx_timing_dst_xy = (is_fill ? fill_is_xy : is_pblt && decoded[1]);
		gfx_timing_saddr = gfx_timing_saddr_raw_q;
		gfx_timing_daddr = gfx_timing_daddr_raw_q;
		gfx_timing_dydx = (is_fill ? {fill_dy_q, fill_dx_q} : {pblt_dy_q, pblt_dx_q});
		if (state_q == 6'd9) begin
			gfx_timing_sptch = 32'd0;
			gfx_timing_dptch = rf_rs2_data;
			gfx_timing_offset = rf_rs3_data;
		end
		else if (state_q == 6'd12) begin
			gfx_timing_sptch = rf_rs1_data;
			gfx_timing_dptch = rf_rs2_data;
			gfx_timing_offset = rf_rs3_data;
		end
		else begin
			gfx_timing_sptch = pblt_sptch_q;
			gfx_timing_dptch = (is_fill ? fill_dptch_q : pblt_dptch_q);
			gfx_timing_offset = gfx_timing_offset_q;
		end
		gfx_timing_wstart = ((state_q == 6'd21) || (state_q == 6'd22) ? rf_rs1_data : 32'd0);
		gfx_timing_wend = ((state_q == 6'd21) || (state_q == 6'd22) ? rf_rs2_data : 32'd0);
		gfx_timing_fits_16 = (gfx_timing_done && !gfx_timing_overflow) && (gfx_timing_cycles[31:16] == 16'd0);
	end
	tms34010_gfx_cycle_counter u_gfx_cycle_counter(
		.clk(clk),
		.rst(rst),
		.ce(ce_cpu),
		.start(gfx_timing_start),
		.is_fill(gfx_timing_is_fill),
		.is_binary(gfx_timing_is_binary),
		.src_xy(gfx_timing_src_xy),
		.dst_xy(gfx_timing_dst_xy),
		.saddr(gfx_timing_saddr),
		.daddr(gfx_timing_daddr),
		.dydx(gfx_timing_dydx),
		.sptch(gfx_timing_sptch),
		.dptch(gfx_timing_dptch),
		.offset(gfx_timing_offset),
		.wstart(gfx_timing_wstart),
		.wend(gfx_timing_wend),
		.convsp(io_convsp),
		.convdp(io_convdp),
		.psize(io_psize),
		.control(io_control),
		.busy(gfx_timing_busy),
		.done(gfx_timing_done),
		.cycles(gfx_timing_cycles),
		.overflow(gfx_timing_overflow)
	);
	always @(*) begin
		if (_sv2v_0)
			;
		cycle_reg_list_count = (((((((((((((({4'd0, imm_lo_q[0]} + {4'd0, imm_lo_q[1]}) + {4'd0, imm_lo_q[2]}) + {4'd0, imm_lo_q[3]}) + {4'd0, imm_lo_q[4]}) + {4'd0, imm_lo_q[5]}) + {4'd0, imm_lo_q[6]}) + {4'd0, imm_lo_q[7]}) + {4'd0, imm_lo_q[8]}) + {4'd0, imm_lo_q[9]}) + {4'd0, imm_lo_q[10]}) + {4'd0, imm_lo_q[11]}) + {4'd0, imm_lo_q[12]}) + {4'd0, imm_lo_q[13]}) + {4'd0, imm_lo_q[14]}) + {4'd0, imm_lo_q[15]};
	end
	tms34010_cycle_budget u_cycle_budget(
		.iclass(decoded[51-:7]),
		.instr_word(instr_word_q),
		.branch_taken(branch_taken),
		.dsj_precondition(dsj_precondition),
		.dsj_rd_nonzero(dsj_rd_nonzero),
		.reg_list_count(cycle_reg_list_count),
		.move_mode(decoded[7-:2]),
		.force_byte(decoded[5]),
		.force_pixel(decoded[4]),
		.xy_addr(decoded[3]),
		.rd_odd(decoded[40]),
		.line_count(line_initial_count_q),
		.gfx_cycles(gfx_timing_cycles[15:0]),
		.gfx_cycles_valid(gfx_timing_fits_16),
		.cycles(cycle_budget),
		.valid(cycle_budget_valid)
	);
	assign instruction_cycles_o = (timing_interrupt_q ? 16'd16 : cycle_budget);
	assign instruction_cycles_valid_o = (timing_interrupt_q ? 1'b1 : cycle_budget_valid);
	localparam [5:0] tms34010_pkg_MEM_SIZE_32 = sv2v_cast_13C0F(tms34010_pkg_DATA_WIDTH);
	localparam [31:0] tms34010_pkg_TRAP_VECTOR_BASE = 32'hffffffe0;
	always @(*) begin
		if (_sv2v_0)
			;
		state_d = state_q;
		mem_req = 1'b0;
		mem_we_int = 1'b0;
		mem_addr = 1'sb0;
		mem_size = 1'sb0;
		mem_wdata = 1'sb0;
		pc_advance_en = 1'b0;
		(* full_case, parallel_case *)
		case (state_q)
			6'd0: state_d = 6'd38;
			6'd38: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = tms34010_pkg_TRAP_VECTOR_BASE;
				mem_size = tms34010_pkg_MEM_SIZE_32;
				if (mem_ack)
					state_d = 6'd1;
			end
			6'd1:
				if (int_take && !fetch_inflight_q)
					state_d = (nmi_req && nmi_nmim ? 6'd19 : 6'd18);
				else begin
					mem_req = 1'b1;
					mem_we_int = 1'b0;
					mem_addr = pc_value;
					mem_size = tms34010_pkg_INSTR_WORD_BITS;
					if (mem_ack) begin
						state_d = 6'd2;
						pc_advance_en = 1'b1;
					end
				end
			6'd18: begin
				mem_req = 1'b1;
				mem_we_int = 1'b1;
				mem_addr = rf_sp - tms34010_pkg_WORD_BIT_SIZE;
				mem_size = tms34010_pkg_MEM_SIZE_32;
				mem_wdata = pc_value;
				if (mem_ack)
					state_d = 6'd17;
			end
			6'd17: begin
				mem_req = 1'b1;
				mem_we_int = 1'b1;
				mem_addr = rf_sp - tms34010_pkg_WORD_BIT_SIZE_2;
				mem_size = tms34010_pkg_MEM_SIZE_32;
				mem_wdata = st_value;
				if (mem_ack)
					state_d = 6'd19;
			end
			6'd19: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = int_vec_q;
				mem_size = tms34010_pkg_MEM_SIZE_32;
				if (mem_ack)
					state_d = 6'd20;
			end
			6'd20: state_d = 6'd1;
			6'd2:
				if (decoded_live[33])
					state_d = 6'd3;
				else if (decoded_live[34])
					state_d = 6'd3;
				else
					state_d = 6'd5;
			6'd3: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = pc_value;
				mem_size = tms34010_pkg_INSTR_WORD_BITS;
				if (mem_ack) begin
					pc_advance_en = 1'b1;
					state_d = (decoded[33] ? 6'd4 : (is_mv_off_m2m ? 6'd39 : 6'd5));
				end
			end
			6'd4: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = pc_value;
				mem_size = tms34010_pkg_INSTR_WORD_BITS;
				if (mem_ack) begin
					pc_advance_en = 1'b1;
					state_d = (is_mv_abs_m2m ? 6'd39 : 6'd5);
				end
			end
			6'd39: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = pc_value;
				mem_size = tms34010_pkg_INSTR_WORD_BITS;
				if (mem_ack) begin
					pc_advance_en = 1'b1;
					state_d = (is_mv_off_m2m ? 6'd5 : 6'd40);
				end
			end
			6'd40: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = pc_value;
				mem_size = tms34010_pkg_INSTR_WORD_BITS;
				if (mem_ack) begin
					pc_advance_en = 1'b1;
					state_d = 6'd5;
				end
			end
			6'd5:
				if (is_div)
					state_d = 6'd8;
				else if (is_fill)
					state_d = 6'd9;
				else if (is_pblt)
					state_d = 6'd12;
				else if (is_drav)
					state_d = (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] != 2'd0 ? 6'd28 : 6'd27);
				else if (is_line)
					state_d = 6'd29;
				else if (pixt_xy_win)
					state_d = 6'd37;
				else
					state_d = (decoded[8] ? 6'd6 : 6'd7);
			6'd8: state_d = (div_done ? 6'd7 : 6'd8);
			6'd9: state_d = (((fill_dx_q[15] || fill_dy_q[15]) || (fill_dx_q == 16'd0)) || (fill_dy_q == 16'd0) ? 6'd41 : (srt_fill_exact_match ? 6'd42 : ((fill_win_en_q || fill_w2_q) || fill_w1_q ? 6'd21 : 6'd10)));
			6'd21: state_d = (fill_w1_q ? 6'd25 : (fill_w2_q && !fill_array_inside ? 6'd23 : 6'd10));
			6'd23: state_d = 6'd41;
			6'd25: state_d = 6'd41;
			6'd28: state_d = (((drav_w_q == 2'd2) || (drav_w_q == 2'd3)) && drav_in_window ? 6'd27 : 6'd7);
			6'd37: state_d = 6'd6;
			6'd27: begin
				mem_req = 1'b1;
				mem_addr = drav_linear_q;
				mem_size = io_psize[5:0];
				if (!drav_substep_q)
					mem_we_int = 1'b0;
				else begin
					mem_we_int = 1'b1;
					mem_wdata = drav_merged;
				end
				if (mem_ack && drav_substep_q)
					state_d = 6'd7;
				else
					state_d = 6'd27;
			end
			6'd29: state_d = 6'd30;
			6'd30: state_d = 6'd31;
			6'd31: state_d = (line_count_q == {32 {1'sb0}} ? 6'd33 : (line_win_en ? 6'd36 : 6'd32));
			6'd36: state_d = 6'd32;
			6'd32: begin
				mem_req = 1'b1;
				mem_addr = line_linear;
				mem_size = io_psize[5:0];
				if (!line_substep_q)
					mem_we_int = 1'b0;
				else begin
					mem_we_int = 1'b1;
					mem_wdata = line_merged;
				end
				if ((mem_ack && line_substep_q) && ((line_count_q == 32'd1) || line_abort))
					state_d = 6'd33;
				else
					state_d = 6'd32;
			end
			6'd33: state_d = 6'd34;
			6'd34: state_d = 6'd35;
			6'd35: state_d = 6'd1;
			6'd10: begin
				mem_req = 1'b1;
				mem_addr = fill_addr_q;
				mem_size = io_psize[5:0];
				if (!fill_substep_q)
					mem_we_int = 1'b0;
				else begin
					mem_we_int = 1'b1;
					mem_wdata = fill_merged;
				end
				if ((mem_ack && fill_substep_q) && fill_done)
					state_d = 6'd11;
				else
					state_d = 6'd10;
			end
			6'd42:
				if ((srt_fill_ack_i === 1'b1) && (srt_fill_pair_q == SRT_FILL_LAST_PAIR))
					state_d = 6'd11;
				else
					state_d = 6'd42;
			6'd11: state_d = 6'd41;
			6'd12: state_d = (((pblt_dx_q[15] || pblt_dy_q[15]) || (pblt_dx_q == 16'd0)) || (pblt_dy_q == 16'd0) ? 6'd41 : (decoded[0] ? 6'd16 : ((pblt_win_en_q || pblt_w2_q) || pblt_w1_q ? 6'd22 : 6'd13)));
			6'd16: state_d = ((pblt_win_en_q || pblt_w2_q) || pblt_w1_q ? 6'd22 : 6'd13);
			6'd22: state_d = (pblt_w1_q ? 6'd26 : (pblt_w2_q && !pblt_array_inside ? 6'd24 : 6'd13));
			6'd24: state_d = 6'd41;
			6'd26: state_d = 6'd41;
			6'd13: begin
				mem_req = 1'b1;
				mem_size = io_psize[5:0];
				(* full_case, parallel_case *)
				case (pblt_substep_q)
					2'd0: begin
						mem_we_int = 1'b0;
						mem_addr = pblt_src_addr_q;
						if (decoded[0])
							mem_size = sv2v_cast_13C0F_signed(1);
					end
					2'd1: begin
						mem_we_int = 1'b0;
						mem_addr = pblt_dst_addr_q;
					end
					default: begin
						mem_we_int = 1'b1;
						mem_addr = pblt_dst_addr_q;
						mem_wdata = pblt_merged;
					end
				endcase
				if ((mem_ack && (pblt_substep_q == 2'd2)) && pblt_done)
					state_d = 6'd14;
				else
					state_d = 6'd13;
			end
			6'd14: state_d = 6'd15;
			6'd15: state_d = 6'd41;
			6'd41: state_d = (gfx_timing_done ? 6'd1 : 6'd41);
			6'd6: begin
				(* full_case, parallel_case *)
				case (decoded[51-:7])
					7'd64: begin
						mem_req = 1'b1;
						mem_we_int = 1'b1;
						mem_addr = alu_result;
						mem_size = tms34010_pkg_MEM_SIZE_32;
						mem_wdata = st_value;
					end
					7'd65: begin
						mem_req = 1'b1;
						mem_we_int = 1'b0;
						mem_addr = rf_rs2_data;
						mem_size = tms34010_pkg_MEM_SIZE_32;
					end
					7'd66, 7'd68, 7'd69: begin
						mem_req = 1'b1;
						mem_we_int = 1'b1;
						mem_addr = alu_result;
						mem_size = tms34010_pkg_MEM_SIZE_32;
						mem_wdata = pc_value;
					end
					7'd67: begin
						mem_req = 1'b1;
						mem_we_int = 1'b0;
						mem_addr = rf_rs2_data;
						mem_size = tms34010_pkg_MEM_SIZE_32;
					end
					7'd70: begin
						mem_req = 1'b1;
						mem_we_int = 1'b0;
						mem_size = tms34010_pkg_MEM_SIZE_32;
						mem_addr = (mem_op_step == 2'd0 ? rf_rs2_data : rf_rs2_data + tms34010_pkg_WORD_BIT_SIZE);
					end
					7'd71: begin
						mem_req = 1'b1;
						mem_size = tms34010_pkg_MEM_SIZE_32;
						if (trap_skip_push) begin
							mem_we_int = 1'b0;
							mem_addr = tms34010_pkg_TRAP_VECTOR_BASE;
						end
						else
							(* full_case, parallel_case *)
							case (mem_op_step)
								2'd0: begin
									mem_we_int = 1'b1;
									mem_addr = rf_rs2_data - tms34010_pkg_WORD_BIT_SIZE;
									mem_wdata = pc_value;
								end
								2'd1: begin
									mem_we_int = 1'b1;
									mem_addr = rf_rs2_data - tms34010_pkg_WORD_BIT_SIZE_2;
									mem_wdata = st_value;
								end
								default: begin
									mem_we_int = 1'b0;
									mem_addr = tms34010_pkg_TRAP_VECTOR_BASE - ({{27 {1'b0}}, decoded[23-:5]} << 5);
								end
							endcase
					end
					7'd72: begin
						mem_req = 1'b1;
						mem_we_int = 1'b1;
						mem_addr = mm_rp_q;
						mem_size = tms34010_pkg_MEM_SIZE_32;
						mem_wdata = rf_rs1_data;
					end
					7'd73: begin
						mem_req = 1'b1;
						mem_we_int = 1'b0;
						mem_addr = mm_rp_q;
						mem_size = tms34010_pkg_MEM_SIZE_32;
					end
					7'd74: begin
						mem_req = 1'b1;
						mem_addr = mv_addr;
						mem_size = mv_fs;
						if (pixt_rmw && (mem_op_step == 2'd0))
							mem_we_int = 1'b0;
						else begin
							mem_we_int = 1'b1;
							mem_wdata = (pixt_rmw ? pixt_merged : rf_rs1_data);
						end
					end
					7'd75: begin
						mem_req = 1'b1;
						mem_we_int = 1'b0;
						mem_addr = mv_addr;
						mem_size = mv_fs;
					end
					7'd79: begin
						mem_req = 1'b1;
						mem_we_int = 1'b1;
						mem_addr = rf_rs2_data + imm32;
						mem_size = mv_fs;
						mem_wdata = rf_rs1_data;
					end
					7'd80: begin
						mem_req = 1'b1;
						mem_we_int = 1'b0;
						mem_addr = rf_rs1_data + imm32;
						mem_size = mv_fs;
					end
					7'd77: begin
						mem_req = 1'b1;
						mem_we_int = 1'b1;
						mem_addr = imm32;
						mem_size = mv_fs;
						mem_wdata = rf_rs1_data;
					end
					7'd78: begin
						mem_req = 1'b1;
						mem_we_int = 1'b0;
						mem_addr = imm32;
						mem_size = mv_fs;
					end
					7'd76: begin
						mem_req = 1'b1;
						mem_size = mv_fs;
						if (mem_op_step == 2'd0) begin
							mem_we_int = 1'b0;
							mem_addr = m2m_src_addr;
						end
						else begin
							mem_we_int = 1'b1;
							mem_addr = m2m_dst_addr;
							mem_wdata = move_data_q;
						end
					end
					7'd99: begin
						mem_req = 1'b1;
						mem_size = mv_fs;
						if (mem_op_step == 2'd0) begin
							mem_we_int = 1'b0;
							mem_addr = imm32;
						end
						else begin
							mem_we_int = 1'b1;
							mem_addr = imm2_32;
							mem_wdata = move_data_q;
						end
					end
					7'd100: begin
						mem_req = 1'b1;
						mem_size = mv_fs;
						if (mem_op_step == 2'd0) begin
							mem_we_int = 1'b0;
							mem_addr = rf_rs1_data + imm32;
						end
						else begin
							mem_we_int = 1'b1;
							mem_addr = rf_rs2_data + imm2_off_sext;
							mem_wdata = move_data_q;
						end
					end
					7'd101: begin
						mem_req = 1'b1;
						mem_size = mv_fs;
						if (mem_op_step == 2'd0) begin
							mem_we_int = 1'b0;
							mem_addr = rf_rs1_data + imm32;
						end
						else begin
							mem_we_int = 1'b1;
							mem_addr = rf_rs2_data;
							mem_wdata = move_data_q;
						end
					end
					7'd102: begin
						mem_req = 1'b1;
						mem_size = mv_fs;
						if (mem_op_step == 2'd0) begin
							mem_we_int = 1'b0;
							mem_addr = imm32;
						end
						else begin
							mem_we_int = 1'b1;
							mem_addr = rf_rs2_data;
							mem_wdata = move_data_q;
						end
					end
					default:
						;
				endcase
				if (mem_ack)
					(* full_case, parallel_case *)
					case (decoded[51-:7])
						7'd70:
							if (mem_op_step == 2'd1)
								state_d = 6'd7;
						7'd71:
							if (trap_skip_push || (mem_op_step == 2'd2))
								state_d = 6'd7;
						7'd72, 7'd73:
							if (mm_mask_will_be_empty)
								state_d = 6'd7;
						7'd76, 7'd99, 7'd100, 7'd101, 7'd102:
							if (mem_op_step == 2'd1)
								state_d = 6'd7;
						7'd74:
							if (!pixt_rmw || (mem_op_step == 2'd1))
								state_d = 6'd7;
						default: state_d = 6'd7;
					endcase
			end
			6'd7: state_d = (pair_second_pass ? 6'd7 : 6'd1);
			default: state_d = 6'd0;
		endcase
	end
	assign state_o = state_q;
	assign pc_o = pc_value;
	assign instr_word_o = instr_word_q;
	assign illegal_opcode_o = illegal_q;
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_cycle_budget (
	iclass,
	instr_word,
	branch_taken,
	dsj_precondition,
	dsj_rd_nonzero,
	reg_list_count,
	move_mode,
	force_byte,
	force_pixel,
	xy_addr,
	rd_odd,
	line_count,
	gfx_cycles,
	gfx_cycles_valid,
	cycles,
	valid
);
	reg _sv2v_0;
	input wire [6:0] iclass;
	input wire [15:0] instr_word;
	input wire branch_taken;
	input wire dsj_precondition;
	input wire dsj_rd_nonzero;
	input wire [4:0] reg_list_count;
	input wire [1:0] move_mode;
	input wire force_byte;
	input wire force_pixel;
	input wire xy_addr;
	input wire rd_odd;
	input wire [31:0] line_count;
	input wire [15:0] gfx_cycles;
	input wire gfx_cycles_valid;
	output reg [15:0] cycles;
	output reg valid;
	reg [15:0] line_cycles;
	always @(*) begin
		if (_sv2v_0)
			;
		if (|line_count[31:15])
			line_cycles = 16'hffff;
		else
			line_cycles = {line_count[14:0], 1'b0};
		cycles = 16'd1;
		valid = 1'b1;
		(* full_case, parallel_case *)
		case (iclass)
			7'd0: cycles = 16'd16;
			7'd1, 7'd16, 7'd17, 7'd18: cycles = 16'd2;
			7'd2, 7'd24, 7'd25, 7'd26, 7'd27, 7'd28, 7'd29: cycles = 16'd3;
			7'd11: cycles = (branch_taken ? 16'd2 : 16'd1);
			7'd34: cycles = (branch_taken ? 16'd3 : 16'd2);
			7'd39: cycles = (branch_taken ? 16'd3 : 16'd4);
			7'd35, 7'd55, 7'd44, 7'd64: cycles = 16'd2;
			7'd36, 7'd37, 7'd38: cycles = (dsj_precondition && dsj_rd_nonzero ? 16'd3 : 16'd2);
			7'd40: cycles = (dsj_rd_nonzero ? 16'd2 : 16'd3);
			7'd19, 7'd49, 7'd48, 7'd62, 7'd63, 7'd66, 7'd69, 7'd93: cycles = 16'd3;
			7'd58: cycles = (instr_word[9] ? 16'd2 : 16'd1);
			7'd59: cycles = 16'd3;
			7'd60: cycles = 16'd1;
			7'd65: cycles = 16'd8;
			7'd67: cycles = 16'd7;
			7'd68: cycles = 16'd4;
			7'd70: cycles = 16'd11;
			7'd71: cycles = 16'd16;
			7'd72: cycles = 16'd2 + ({11'd0, reg_list_count} << 2);
			7'd73: cycles = 16'd3 + ({11'd0, reg_list_count} << 2);
			7'd74:
				if (force_pixel)
					cycles = (xy_addr ? 16'd4 : 16'd2);
				else if (force_byte)
					cycles = 16'd1;
				else
					cycles = (move_mode == 2'b00 ? 16'd1 : 16'd2);
			7'd75:
				if (force_pixel)
					cycles = (xy_addr ? 16'd6 : 16'd4);
				else if (force_byte)
					cycles = 16'd3;
				else
					cycles = (move_mode == 2'b00 ? 16'd3 : 16'd4);
			7'd76:
				if (force_pixel)
					cycles = (xy_addr ? 16'd7 : 16'd4);
				else if (force_byte)
					cycles = 16'd3;
				else
					cycles = 16'd4;
			7'd77: cycles = (force_byte ? 16'd1 : 16'd3);
			7'd78: cycles = 16'd5;
			7'd79: cycles = 16'd3;
			7'd80: cycles = 16'd5;
			7'd99: cycles = 16'd7;
			7'd100: cycles = 16'd5;
			7'd101: cycles = 16'd5;
			7'd87: cycles = 16'd20;
			7'd88: cycles = 16'd21;
			7'd89: cycles = 16'd37;
			7'd90: cycles = 16'd35;
			7'd91: cycles = (rd_odd ? 16'd39 : 16'd40);
			7'd92: cycles = 16'd40;
			7'd94, 7'd95, 7'd96: begin
				cycles = gfx_cycles;
				valid = gfx_cycles_valid;
			end
			7'd97: cycles = 16'd4;
			7'd98: cycles = line_cycles;
			7'd3, 7'd4, 7'd5, 7'd6, 7'd7, 7'd8, 7'd9, 7'd10, 7'd12, 7'd13, 7'd14, 7'd15, 7'd20, 7'd21, 7'd22, 7'd23, 7'd30, 7'd31, 7'd32, 7'd33, 7'd41, 7'd42, 7'd43, 7'd45, 7'd46, 7'd47, 7'd50, 7'd51, 7'd52, 7'd53, 7'd54, 7'd56, 7'd57, 7'd61, 7'd81, 7'd82, 7'd83, 7'd84, 7'd85, 7'd86: cycles = 16'd1;
			default: begin
				cycles = 16'd1;
				valid = 1'b0;
			end
		endcase
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_cycle_scheduler (
	clk,
	rst,
	micro_tick,
	arch_step,
	instr_start,
	instr_retire,
	instr_cycles,
	ce_cpu,
	cadence_stall,
	cadence_overrun
);
	reg _sv2v_0;
	input wire clk;
	input wire rst;
	input wire micro_tick;
	input wire [5:0] arch_step;
	input wire instr_start;
	input wire instr_retire;
	input wire [15:0] instr_cycles;
	output reg ce_cpu;
	output reg cadence_stall;
	output reg cadence_overrun;
	localparam [9:0] PHASE_PER_CYCLE = 10'd384;
	localparam [17:0] PHASE_MOD_CYCLES = 18'd174762;
	localparam [9:0] PHASE_MOD_FRAC = 10'd256;
	reg active;
	reg waiting;
	(* preserve *) reg permit_q;
	reg [17:0] elapsed_cycles;
	reg [8:0] elapsed_fraction;
	reg [15:0] target_cycles;
	reg [15:0] budget_cycles;
	(* preserve *) reg retire_toggle_q;
	(* preserve *) reg [15:0] retire_cycles_q;
	reg retire_seen_q;
	reg retire_pending;
	reg [9:0] fraction_sum_one;
	reg [9:0] fraction_sum_two;
	reg [8:0] fraction_after_one;
	reg [17:0] cycles_after_one;
	reg [17:0] cycles_after_two;
	reg [17:0] target_cycles_ext;
	reg [15:0] target_cycles_effective;
	reg permit_next;
	function automatic [8:0] sv2v_cast_9;
		input reg [8:0] inp;
		sv2v_cast_9 = inp;
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		budget_cycles = (instr_cycles == 16'd0 ? 16'd1 : instr_cycles);
		retire_pending = retire_toggle_q ^ retire_seen_q;
		target_cycles_effective = (retire_pending ? retire_cycles_q : target_cycles);
		target_cycles_ext = {2'b00, target_cycles_effective};
		fraction_sum_one = {1'b0, elapsed_fraction} + {4'b0000, arch_step};
		cycles_after_one = elapsed_cycles;
		if ((elapsed_cycles == PHASE_MOD_CYCLES) && (fraction_sum_one >= PHASE_MOD_FRAC)) begin
			cycles_after_one = 18'd0;
			fraction_after_one = sv2v_cast_9(fraction_sum_one - PHASE_MOD_FRAC);
		end
		else if (fraction_sum_one >= PHASE_PER_CYCLE) begin
			cycles_after_one = elapsed_cycles + 18'd1;
			fraction_after_one = sv2v_cast_9(fraction_sum_one - PHASE_PER_CYCLE);
		end
		else
			fraction_after_one = fraction_sum_one[8:0];
		fraction_sum_two = {1'b0, elapsed_fraction} + {3'b000, arch_step, 1'b0};
		cycles_after_two = elapsed_cycles;
		if ((elapsed_cycles == PHASE_MOD_CYCLES) && (fraction_sum_two >= PHASE_MOD_FRAC))
			cycles_after_two = 18'd0;
		else if (fraction_sum_two >= PHASE_PER_CYCLE)
			cycles_after_two = elapsed_cycles + 18'd1;
		cadence_stall = waiting && (cycles_after_one < target_cycles_ext);
		permit_next = !waiting || (cycles_after_two >= target_cycles_ext);
		ce_cpu = micro_tick && permit_q;
	end
	always @(posedge clk)
		if (rst) begin
			active <= 1'b0;
			waiting <= 1'b0;
			permit_q <= 1'b1;
			elapsed_cycles <= 18'd0;
			elapsed_fraction <= 9'd0;
			target_cycles <= 16'd1;
			retire_toggle_q <= 1'b0;
			retire_cycles_q <= 16'd1;
			retire_seen_q <= 1'b0;
			cadence_overrun <= 1'b0;
		end
		else begin
			permit_q <= permit_next;
			if (active || waiting) begin
				elapsed_cycles <= cycles_after_one;
				elapsed_fraction <= fraction_after_one;
			end
			if (instr_retire) begin
				active <= 1'b0;
				waiting <= 1'b1;
				retire_toggle_q <= ~retire_toggle_q;
				retire_cycles_q <= budget_cycles;
			end
			if (retire_pending) begin
				target_cycles <= retire_cycles_q;
				retire_seen_q <= retire_toggle_q;
			end
			if (instr_start) begin
				active <= 1'b1;
				waiting <= 1'b0;
				if (waiting && (cycles_after_one >= target_cycles_ext)) begin
					if (cycles_after_one > target_cycles_ext) begin
						elapsed_cycles <= 18'd0;
						elapsed_fraction <= 9'd0;
						cadence_overrun <= 1'b1;
					end
					else begin
						elapsed_cycles <= 18'd0;
						elapsed_fraction <= fraction_after_one;
					end
				end
				else begin
					elapsed_cycles <= 18'd0;
					elapsed_fraction <= 9'd0;
				end
			end
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_decode (
	instr,
	decoded
);
	reg _sv2v_0;
	localparam [31:0] tms34010_pkg_INSTR_WORD_WIDTH = 16;
	input wire [15:0] instr;
	output reg [52:0] decoded;
	wire [9:0] top10;
	wire [6:0] top7;
	wire [5:0] top6;
	assign top10 = instr[15:6];
	assign top7 = instr[15:9];
	assign top6 = instr[15:10];
	localparam [9:0] MOVI_TOP10 = 10'b0000100111;
	localparam [5:0] MOVK_TOP6 = 6'b000110;
	localparam [5:0] ADDK_TOP6 = 6'b000100;
	localparam [5:0] SUBK_TOP6 = 6'b000101;
	localparam [8:0] UNARY_TOP9 = 9'b000000111;
	localparam [10:0] ADDI_IW_TOP11 = 11'b00001011000;
	localparam [10:0] SUBI_IW_TOP11 = 11'b00001011111;
	localparam [10:0] CMPI_IW_TOP11 = 11'b00001011010;
	localparam [5:0] SLA_K_TOP6 = 6'b001000;
	localparam [5:0] SLL_K_TOP6 = 6'b001001;
	localparam [5:0] SRA_K_TOP6 = 6'b001010;
	localparam [5:0] SRL_K_TOP6 = 6'b001011;
	localparam [5:0] RL_K_TOP6 = 6'b001100;
	localparam [10:0] ADDI_IL_TOP11 = 11'b00001011001;
	localparam [10:0] CMPI_IL_TOP11 = 11'b00001011011;
	localparam [10:0] ANDI_IL_TOP11 = 11'b00001011100;
	localparam [10:0] ORI_IL_TOP11 = 11'b00001011101;
	localparam [10:0] XORI_IL_TOP11 = 11'b00001011110;
	localparam [10:0] SUBI_IL_TOP11 = 11'b00001101000;
	localparam [5:0] MOVE_RR_TOP6 = 6'b010011;
	localparam [5:0] MOVE_STORE_TOP6 = 6'b100000;
	localparam [5:0] MOVE_LOAD_TOP6 = 6'b100001;
	localparam [5:0] MOVE_M2M_TOP6 = 6'b100010;
	localparam [5:0] MOVE_M2M_POSTINC_TOP6 = 6'b100110;
	localparam [5:0] MOVE_M2M_PREDEC_TOP6 = 6'b101010;
	localparam [5:0] MOVE_OFF_STORE_TOP6 = 6'b101100;
	localparam [5:0] MOVE_OFF_LOAD_TOP6 = 6'b101101;
	localparam [5:0] MOVE_OFF_M2M_TOP6 = 6'b101110;
	localparam [5:0] MOVE_OFF_NI_TOP6 = 6'b110100;
	localparam [5:0] MOVE_STORE_POSTINC_TOP6 = 6'b100100;
	localparam [5:0] MOVE_LOAD_POSTINC_TOP6 = 6'b100101;
	localparam [5:0] MOVE_STORE_PREDEC_TOP6 = 6'b101000;
	localparam [5:0] MOVE_LOAD_PREDEC_TOP6 = 6'b101001;
	localparam [6:0] MOVB_STORE_TOP7 = 7'b1000110;
	localparam [6:0] MOVB_LOAD_TOP7 = 7'b1000111;
	localparam [6:0] MOVB_M2M_TOP7 = 7'b1001110;
	localparam [6:0] MOVB_OFF_STORE_TOP7 = 7'b1010110;
	localparam [6:0] MOVB_OFF_LOAD_TOP7 = 7'b1010111;
	localparam [6:0] MOVB_OFF_M2M_TOP7 = 7'b1011110;
	localparam [6:0] PIXT_STORE_TOP7 = 7'b1111100;
	localparam [6:0] PIXT_LOAD_TOP7 = 7'b1111101;
	localparam [6:0] PIXT_M2M_TOP7 = 7'b1111110;
	localparam [6:0] PIXT_XY_STORE_TOP7 = 7'b1111000;
	localparam [6:0] PIXT_XY_LOAD_TOP7 = 7'b1111001;
	localparam [6:0] PIXT_XY_M2M_TOP7 = 7'b1111010;
	localparam [6:0] MOVX_TOP7 = 7'b1110110;
	localparam [6:0] MOVY_TOP7 = 7'b1110111;
	localparam [6:0] CVXYL_TOP7 = 7'b1110100;
	localparam [6:0] ADDXY_TOP7 = 7'b1110000;
	localparam [6:0] SUBXY_TOP7 = 7'b1110001;
	localparam [6:0] DRAV_TOP7 = 7'b1111011;
	localparam [6:0] CMPXY_TOP7 = 7'b1110010;
	localparam [6:0] CPW_TOP7 = 7'b1110011;
	localparam [6:0] MPYS_TOP7 = 7'b0101110;
	localparam [6:0] MPYU_TOP7 = 7'b0101111;
	localparam [6:0] DIVU_TOP7 = 7'b0101101;
	localparam [6:0] MODU_TOP7 = 7'b0110111;
	localparam [6:0] DIVS_TOP7 = 7'b0101100;
	localparam [6:0] MODS_TOP7 = 7'b0110110;
	localparam [6:0] ADD_RR_TOP7 = 7'b0100000;
	localparam [6:0] ADDC_RR_TOP7 = 7'b0100001;
	localparam [6:0] SUB_RR_TOP7 = 7'b0100010;
	localparam [6:0] SUBB_RR_TOP7 = 7'b0100011;
	localparam [6:0] AND_RR_TOP7 = 7'b0101000;
	localparam [6:0] ANDN_RR_TOP7 = 7'b0101001;
	localparam [6:0] OR_RR_TOP7 = 7'b0101010;
	localparam [6:0] XOR_RR_TOP7 = 7'b0101011;
	localparam [6:0] CMP_RR_TOP7 = 7'b0100100;
	localparam [15:0] PUSHST_OPCODE = 16'h01e0;
	localparam [15:0] POPST_OPCODE = 16'h01c0;
	localparam [10:0] CALL_RS_TOP11 = 11'b00001001001;
	localparam [15:0] RETI_OPCODE = 16'h0940;
	localparam [10:0] TRAP_TOP11 = 11'b00001001000;
	localparam [10:0] MMTM_TOP11 = 11'b00001001100;
	localparam [10:0] MMFM_TOP11 = 11'b00001001101;
	localparam [15:0] CALLA_OPCODE = 16'h0d5f;
	localparam [15:0] CALLR_OPCODE = 16'h0d3f;
	localparam [10:0] RETS_TOP11 = 11'b00001001011;
	localparam [15:0] DINT_OPCODE = 16'h0360;
	localparam [15:0] EINT_OPCODE = 16'h0d60;
	localparam [5:0] EXGF_TOP6 = 6'b110101;
	localparam [5:0] SETF_TOP6 = 6'b000001;
	localparam [6:0] LMO_RR_TOP7 = 7'b0110101;
	localparam [6:0] SLA_RR_TOP7 = 7'b0110000;
	localparam [6:0] SLL_RR_TOP7 = 7'b0110001;
	localparam [6:0] SRA_RR_TOP7 = 7'b0110010;
	localparam [6:0] SRL_RR_TOP7 = 7'b0110011;
	localparam [6:0] RL_RR_TOP7 = 7'b0110100;
	localparam [3:0] JRCC_TOP4 = 4'b1100;
	localparam [15:0] NOP_OPCODE = 16'h0300;
	localparam [10:0] JUMP_RS_TOP11 = 11'b00000001011;
	localparam [10:0] DSJ_TOP11 = 11'b00001101100;
	localparam [10:0] DSJEQ_TOP11 = 11'b00001101101;
	localparam [10:0] DSJNE_TOP11 = 11'b00001101110;
	localparam [15:0] CLRC_OPCODE = 16'h0320;
	localparam [15:0] SETC_OPCODE = 16'h0de0;
	localparam [10:0] GETST_TOP11 = 11'b00000001100;
	localparam [10:0] PUTST_TOP11 = 11'b00000001101;
	localparam [10:0] GETPC_TOP11 = 11'b00000001010;
	localparam [10:0] EXGPC_TOP11 = 11'b00000001001;
	localparam [10:0] REV_TOP11 = 11'b00000000001;
	localparam [5:0] BTST_K_TOP6 = 6'b000111;
	localparam [6:0] BTST_RR_TOP7 = 7'b0100101;
	localparam [4:0] DSJS_TOP5 = 5'b00111;
	wire [3:0] rs_idx_from_instr;
	assign rs_idx_from_instr = instr[8:5];
	wire [10:0] top11;
	assign top11 = instr[15:5];
	wire reg_file_from_instr;
	wire [3:0] reg_idx_from_instr;
	assign reg_file_from_instr = instr[4];
	assign reg_idx_from_instr = instr[3:0];
	localparam [3:0] tms34010_pkg_CC_C = 4'b1000;
	localparam [3:0] tms34010_pkg_CC_EQ = 4'b1010;
	localparam [3:0] tms34010_pkg_CC_GE = 4'b0101;
	localparam [3:0] tms34010_pkg_CC_GT = 4'b0111;
	localparam [3:0] tms34010_pkg_CC_HI = 4'b0011;
	localparam [3:0] tms34010_pkg_CC_HS = 4'b1001;
	localparam [3:0] tms34010_pkg_CC_LE = 4'b0110;
	localparam [3:0] tms34010_pkg_CC_LS = 4'b0010;
	localparam [3:0] tms34010_pkg_CC_LT = 4'b0100;
	localparam [3:0] tms34010_pkg_CC_N = 4'b1110;
	localparam [3:0] tms34010_pkg_CC_NE = 4'b1011;
	localparam [3:0] tms34010_pkg_CC_NN = 4'b1111;
	localparam [3:0] tms34010_pkg_CC_NV = 4'b1101;
	localparam [3:0] tms34010_pkg_CC_P = 4'b0001;
	localparam [3:0] tms34010_pkg_CC_UC = 4'b0000;
	localparam [3:0] tms34010_pkg_CC_V = 4'b1100;
	localparam [3:0] tms34010_pkg_REG_SP_IDX = 4'hf;
	always @(*) begin
		if (_sv2v_0)
			;
		decoded[52] = 1'b1;
		decoded[51-:7] = 7'd0;
		decoded[44] = 1'b0;
		decoded[43-:4] = 1'sb0;
		decoded[39-:4] = 1'sb0;
		decoded[34] = 1'b0;
		decoded[33] = 1'b0;
		decoded[32] = 1'b0;
		decoded[31-:4] = 4'd11;
		decoded[35] = reg_file_from_instr;
		decoded[7-:2] = 2'b00;
		decoded[5] = 1'b0;
		decoded[4] = 1'b0;
		decoded[3] = 1'b0;
		decoded[2] = 1'b0;
		decoded[1] = 1'b0;
		decoded[0] = 1'b0;
		decoded[27-:3] = 3'd0;
		decoded[24] = 1'b0;
		decoded[23-:5] = 1'sb0;
		decoded[18-:4] = 1'sb0;
		decoded[14] = 1'b0;
		decoded[13] = 1'b0;
		decoded[12-:4] = 4'b1111;
		decoded[8] = 1'b0;
		if ((top10 == MOVI_TOP10) && (instr[5] == 1'b0)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[33] = 1'b0;
			decoded[32] = 1'b1;
			decoded[31-:4] = 4'd12;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if ((top10 == MOVI_TOP10) && (instr[5] == 1'b1)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd2;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[34] = 1'b0;
			decoded[33] = 1'b1;
			decoded[32] = 1'b0;
			decoded[31-:4] = 4'd12;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (top6 == MOVK_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd3;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[34] = 1'b0;
			decoded[33] = 1'b0;
			decoded[32] = 1'b0;
			decoded[31-:4] = 4'd12;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top6 == ADDK_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd12;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top6 == SUBK_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd13;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top11 == ADDI_IW_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd16;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top11 == SUBI_IW_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd17;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top11 == CMPI_IW_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd18;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[31-:4] = 4'd4;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
		end
		if (top11 == ADDI_IL_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd24;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top11 == SUBI_IL_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd25;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top11 == CMPI_IL_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd26;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[31-:4] = 4'd4;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
		end
		if (top11 == ANDI_IL_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd27;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[31-:4] = 4'd6;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top11 == ORI_IL_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd28;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[31-:4] = 4'd7;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top11 == XORI_IL_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd29;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[31-:4] = 4'd8;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top6 == MOVE_RR_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd30;
			decoded[35] = reg_file_from_instr;
			decoded[44] = (instr[9] ? ~instr[4] : reg_file_from_instr);
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd11;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (top7 == MOVX_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd81;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top7 == MOVY_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd82;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top7 == CVXYL_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd93;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top7 == ADDXY_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd83;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == SUBXY_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd84;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == DRAV_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd97;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[8] = 1'b1;
		end
		if ((instr[15:8] == 8'hdf) && (instr[6:0] == 7'h1a)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd98;
			decoded[14] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top7 == CMPXY_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd85;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
		end
		if (top7 == MPYS_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd87;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1010;
		end
		if (top7 == MPYU_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd88;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top7 == DIVU_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd89;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0011;
		end
		if (top7 == MODU_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd90;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0011;
		end
		if (top7 == DIVS_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd91;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (top7 == MODS_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd92;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (top7 == CPW_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd86;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0001;
		end
		if (top6 == MOVE_STORE_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd74;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top6 == MOVE_LOAD_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd75;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
			decoded[8] = 1'b1;
		end
		if (top6 == MOVE_OFF_STORE_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd79;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (top6 == MOVE_OFF_LOAD_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd80;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (top6 == MOVE_OFF_M2M_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd100;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (top6 == MOVE_OFF_NI_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd101;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[7-:2] = 2'b01;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top6 == MOVE_M2M_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd76;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if ((top6 == MOVE_M2M_POSTINC_TOP6) || (top6 == MOVE_M2M_PREDEC_TOP6)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd76;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[7-:2] = (top6 == MOVE_M2M_PREDEC_TOP6 ? 2'b10 : 2'b01);
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if ((top6 == MOVE_STORE_POSTINC_TOP6) || (top6 == MOVE_STORE_PREDEC_TOP6)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd74;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[7-:2] = (top6 == MOVE_STORE_PREDEC_TOP6 ? 2'b10 : 2'b01);
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if ((top6 == MOVE_LOAD_POSTINC_TOP6) || (top6 == MOVE_LOAD_PREDEC_TOP6)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd75;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[7-:2] = (top6 == MOVE_LOAD_PREDEC_TOP6 ? 2'b10 : 2'b01);
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
			decoded[8] = 1'b1;
		end
		if (top6 == SLA_K_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd19;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[27-:3] = 3'd1;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top6 == SLL_K_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd20;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[27-:3] = 3'd0;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0110;
		end
		if (top6 == SRA_K_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd21;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[27-:3] = 3'd3;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1110;
		end
		if (top6 == SRL_K_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd22;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[27-:3] = 3'd2;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0110;
		end
		if (top6 == RL_K_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd23;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[27-:3] = 3'd4;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0110;
		end
		if (instr[15:7] == UNARY_TOP9)
			case (instr[6:5])
				2'b00: begin
					decoded[52] = 1'b0;
					decoded[51-:7] = 7'd41;
					decoded[44] = reg_file_from_instr;
					decoded[43-:4] = reg_idx_from_instr;
					decoded[31-:4] = 4'd13;
					decoded[14] = 1'b1;
					decoded[13] = 1'b1;
					decoded[12-:4] = 4'b1011;
				end
				2'b01: begin
					decoded[52] = 1'b0;
					decoded[51-:7] = 7'd14;
					decoded[44] = reg_file_from_instr;
					decoded[43-:4] = reg_idx_from_instr;
					decoded[31-:4] = 4'd10;
					decoded[14] = 1'b1;
					decoded[13] = 1'b1;
				end
				2'b10: begin
					decoded[52] = 1'b0;
					decoded[51-:7] = 7'd42;
					decoded[44] = reg_file_from_instr;
					decoded[43-:4] = reg_idx_from_instr;
					decoded[31-:4] = 4'd3;
					decoded[14] = 1'b1;
					decoded[13] = 1'b1;
				end
				2'b11: begin
					decoded[52] = 1'b0;
					decoded[51-:7] = 7'd15;
					decoded[44] = reg_file_from_instr;
					decoded[43-:4] = reg_idx_from_instr;
					decoded[31-:4] = 4'd9;
					decoded[14] = 1'b1;
					decoded[13] = 1'b1;
					decoded[12-:4] = 4'b0010;
				end
				default:
					;
			endcase
		if (top7 == SLA_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd49;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[27-:3] = 3'd1;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == SLL_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd50;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[27-:3] = 3'd0;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0110;
		end
		if (top7 == SRA_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd51;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[27-:3] = 3'd3;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1110;
		end
		if (top7 == SRL_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd52;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[27-:3] = 3'd2;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0110;
		end
		if (top7 == RL_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd53;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[27-:3] = 3'd4;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0110;
		end
		if (top7 == LMO_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd57;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (((instr[15:10] == SETF_TOP6) && instr[8]) && (instr[7:6] == 2'b01)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd58;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (((instr[15:10] == SETF_TOP6) && instr[8]) && (instr[7:5] == 3'b000)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd59;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1010;
		end
		if (((instr[15:10] == SETF_TOP6) && instr[8]) && (instr[7:5] == 3'b001)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd60;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (((instr[15:10] == SETF_TOP6) && instr[8]) && (instr[7:5] == 3'b100)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd77;
			decoded[44] = reg_file_from_instr;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (((instr[15:10] == SETF_TOP6) && instr[8]) && (instr[7:5] == 3'b101)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd78;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (((instr[15:10] == SETF_TOP6) && instr[8]) && (instr[7:5] == 3'b110)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd99;
			decoded[33] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if ((instr[15:10] == EXGF_TOP6) && (instr[8:5] == 4'b0000)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd102;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[8] = 1'b1;
			decoded[7-:2] = 2'b01;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top7 == MOVB_STORE_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd74;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top7 == MOVB_LOAD_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd75;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
			decoded[8] = 1'b1;
		end
		if (top7 == MOVB_M2M_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd76;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top7 == MOVB_OFF_STORE_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd79;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (top7 == MOVB_OFF_M2M_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd100;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (top7 == MOVB_OFF_LOAD_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd80;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if ((((instr[15:10] == SETF_TOP6) && !instr[9]) && instr[8]) && (instr[7:5] == 3'b111)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd77;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if ((((instr[15:10] == SETF_TOP6) && instr[9]) && instr[8]) && (instr[7:5] == 3'b111)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd78;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (top7 == PIXT_STORE_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd74;
			decoded[4] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top7 == PIXT_LOAD_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd75;
			decoded[4] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0001;
			decoded[8] = 1'b1;
		end
		if (top7 == PIXT_M2M_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd76;
			decoded[4] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top7 == PIXT_XY_STORE_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd74;
			decoded[4] = 1'b1;
			decoded[3] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top7 == PIXT_XY_LOAD_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd75;
			decoded[4] = 1'b1;
			decoded[3] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0001;
			decoded[8] = 1'b1;
		end
		if (top7 == PIXT_XY_M2M_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd76;
			decoded[4] = 1'b1;
			decoded[3] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (((instr[15:10] == EXGF_TOP6) && instr[8]) && (instr[7:5] == 3'b000)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd61;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (instr == DINT_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd62;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (instr == EINT_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd63;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (instr == PUSHST_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd64;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[39-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (instr == POPST_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd65;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[39-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top11 == CALL_RS_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd66;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top11 == RETS_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd67;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[39-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[23-:5] = instr[4:0];
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (instr == CALLA_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd68;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[31-:4] = 4'd2;
			decoded[33] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (instr == CALLR_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd69;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[31-:4] = 4'd2;
			decoded[34] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (instr == RETI_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd70;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[39-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top11 == TRAP_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd71;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[39-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[23-:5] = instr[4:0];
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top11 == MMTM_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd72;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[34] = 1'b1;
			decoded[8] = 1'b1;
		end
		if (top11 == MMFM_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd73;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[34] = 1'b1;
			decoded[8] = 1'b1;
		end
		if (top7 == ADD_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd4;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == ADDC_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd32;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == SUB_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd5;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == SUBB_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd33;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd3;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == AND_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd6;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd5;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top7 == ANDN_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd7;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd6;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top7 == OR_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd8;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd7;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top7 == XOR_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd9;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd8;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top7 == CMP_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd10;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd4;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
		end
		if ((((instr[15:12] == JRCC_TOP4) && (instr[7:0] != 8'h00)) && (instr[7:0] != 8'h80)) && ((((((((((((((((instr[11:8] == tms34010_pkg_CC_UC) || (instr[11:8] == tms34010_pkg_CC_P)) || (instr[11:8] == tms34010_pkg_CC_LS)) || (instr[11:8] == tms34010_pkg_CC_HI)) || (instr[11:8] == tms34010_pkg_CC_LT)) || (instr[11:8] == tms34010_pkg_CC_LE)) || (instr[11:8] == tms34010_pkg_CC_GT)) || (instr[11:8] == tms34010_pkg_CC_GE)) || (instr[11:8] == tms34010_pkg_CC_EQ)) || (instr[11:8] == tms34010_pkg_CC_NE)) || (instr[11:8] == tms34010_pkg_CC_HS)) || (instr[11:8] == tms34010_pkg_CC_C)) || (instr[11:8] == tms34010_pkg_CC_V)) || (instr[11:8] == tms34010_pkg_CC_NV)) || (instr[11:8] == tms34010_pkg_CC_N)) || (instr[11:8] == tms34010_pkg_CC_NN))) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd11;
			decoded[18-:4] = instr[11:8];
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (((instr[15:12] == JRCC_TOP4) && (instr[7:0] == 8'h00)) && ((((((((((((((((instr[11:8] == tms34010_pkg_CC_UC) || (instr[11:8] == tms34010_pkg_CC_P)) || (instr[11:8] == tms34010_pkg_CC_LS)) || (instr[11:8] == tms34010_pkg_CC_HI)) || (instr[11:8] == tms34010_pkg_CC_LT)) || (instr[11:8] == tms34010_pkg_CC_LE)) || (instr[11:8] == tms34010_pkg_CC_GT)) || (instr[11:8] == tms34010_pkg_CC_GE)) || (instr[11:8] == tms34010_pkg_CC_EQ)) || (instr[11:8] == tms34010_pkg_CC_NE)) || (instr[11:8] == tms34010_pkg_CC_HS)) || (instr[11:8] == tms34010_pkg_CC_C)) || (instr[11:8] == tms34010_pkg_CC_V)) || (instr[11:8] == tms34010_pkg_CC_NV)) || (instr[11:8] == tms34010_pkg_CC_N)) || (instr[11:8] == tms34010_pkg_CC_NN))) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd34;
			decoded[18-:4] = instr[11:8];
			decoded[34] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (instr == NOP_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd31;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (instr == 16'h0fc0) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd94;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0fe0) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd95;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0f00) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd96;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0f20) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd96;
			decoded[1] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0f40) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd96;
			decoded[2] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0f60) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd96;
			decoded[2] = 1'b1;
			decoded[1] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0f80) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd96;
			decoded[0] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0fa0) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd96;
			decoded[0] = 1'b1;
			decoded[1] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (top11 == JUMP_RS_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd35;
			decoded[44] = reg_file_from_instr;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (((top11 == DSJ_TOP11) || (top11 == DSJEQ_TOP11)) || (top11 == DSJNE_TOP11)) begin
			decoded[52] = 1'b0;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = 5'd1;
			decoded[31-:4] = 4'd2;
			decoded[34] = 1'b1;
			decoded[32] = 1'b0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			(* full_case, parallel_case *)
			case (top11)
				DSJ_TOP11: decoded[51-:7] = 7'd36;
				DSJEQ_TOP11: decoded[51-:7] = 7'd37;
				DSJNE_TOP11: decoded[51-:7] = 7'd38;
				default: decoded[51-:7] = 7'd0;
			endcase
		end
		if (((instr[15:12] == JRCC_TOP4) && (instr[7:0] == 8'h80)) && ((((((((((((((((instr[11:8] == tms34010_pkg_CC_UC) || (instr[11:8] == tms34010_pkg_CC_P)) || (instr[11:8] == tms34010_pkg_CC_LS)) || (instr[11:8] == tms34010_pkg_CC_HI)) || (instr[11:8] == tms34010_pkg_CC_LT)) || (instr[11:8] == tms34010_pkg_CC_LE)) || (instr[11:8] == tms34010_pkg_CC_GT)) || (instr[11:8] == tms34010_pkg_CC_GE)) || (instr[11:8] == tms34010_pkg_CC_EQ)) || (instr[11:8] == tms34010_pkg_CC_NE)) || (instr[11:8] == tms34010_pkg_CC_HS)) || (instr[11:8] == tms34010_pkg_CC_C)) || (instr[11:8] == tms34010_pkg_CC_V)) || (instr[11:8] == tms34010_pkg_CC_NV)) || (instr[11:8] == tms34010_pkg_CC_N)) || (instr[11:8] == tms34010_pkg_CC_NN))) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd39;
			decoded[18-:4] = instr[11:8];
			decoded[33] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (instr[15:11] == DSJS_TOP5) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd40;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = 5'd1;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top6 == BTST_K_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd43;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = ~instr[9:5];
			decoded[31-:4] = 4'd5;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (instr == CLRC_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd45;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0100;
		end
		if (instr == SETC_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd46;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0100;
		end
		if (top11 == GETST_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd47;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top11 == PUTST_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd48;
			decoded[44] = reg_file_from_instr;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (top11 == GETPC_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd54;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top11 == EXGPC_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd55;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top11 == REV_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd56;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top7 == BTST_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd44;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd5;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_divider (
	clk,
	ce_cpu,
	rst,
	start,
	dividend,
	divisor,
	busy,
	done,
	quotient,
	remainder,
	overflow
);
	input wire clk;
	input wire ce_cpu;
	input wire rst;
	input wire start;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	input wire [63:0] dividend;
	input wire [31:0] divisor;
	output wire busy;
	output wire done;
	output wire [31:0] quotient;
	output wire [31:0] remainder;
	output wire overflow;
	reg [1:0] st_q;
	reg [tms34010_pkg_DATA_WIDTH:0] rem_q;
	reg [31:0] quot_q;
	reg [31:0] dvd_lo_q;
	reg [31:0] divisor_q;
	reg ovf_q;
	localparam [31:0] tms34010_pkg_SHIFT_AMOUNT_WIDTH = 5;
	reg [tms34010_pkg_SHIFT_AMOUNT_WIDTH:0] iter_q;
	wire [tms34010_pkg_DATA_WIDTH:0] shifted;
	wire [tms34010_pkg_DATA_WIDTH:0] divisor_ext;
	assign divisor_ext = {1'b0, divisor_q};
	assign shifted = {rem_q[31:0], dvd_lo_q[31]};
	wire start_overflow;
	assign start_overflow = (divisor == {32 {1'sb0}}) || (dividend[63:tms34010_pkg_DATA_WIDTH] >= divisor);
	function automatic [5:0] sv2v_cast_287E4;
		input reg [5:0] inp;
		sv2v_cast_287E4 = inp;
	endfunction
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				st_q <= 2'd0;
				rem_q <= 1'sb0;
				quot_q <= 1'sb0;
				dvd_lo_q <= 1'sb0;
				divisor_q <= 1'sb0;
				ovf_q <= 1'b0;
				iter_q <= 1'sb0;
			end
			else
				(* full_case, parallel_case *)
				case (st_q)
					2'd0:
						if (start) begin
							divisor_q <= divisor;
							ovf_q <= start_overflow;
							rem_q <= {1'b0, dividend[63:tms34010_pkg_DATA_WIDTH]};
							dvd_lo_q <= dividend[31:0];
							quot_q <= 1'sb0;
							iter_q <= 1'sb0;
							st_q <= (start_overflow ? 2'd2 : 2'd1);
						end
					2'd1: begin
						if (shifted >= divisor_ext) begin
							rem_q <= shifted - divisor_ext;
							quot_q <= {quot_q[30:0], 1'b1};
						end
						else begin
							rem_q <= shifted;
							quot_q <= {quot_q[30:0], 1'b0};
						end
						dvd_lo_q <= {dvd_lo_q[30:0], 1'b0};
						iter_q <= iter_q + 1'b1;
						if (iter_q == sv2v_cast_287E4(31))
							st_q <= 2'd2;
					end
					2'd2: st_q <= 2'd0;
					default: st_q <= 2'd0;
				endcase
		end
	assign busy = st_q != 2'd0;
	assign done = st_q == 2'd2;
	assign quotient = quot_q;
	assign remainder = rem_q[31:0];
	assign overflow = ovf_q;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_gfx_cycle_counter (
	clk,
	rst,
	ce,
	start,
	is_fill,
	is_binary,
	src_xy,
	dst_xy,
	saddr,
	daddr,
	dydx,
	sptch,
	dptch,
	offset,
	wstart,
	wend,
	convsp,
	convdp,
	psize,
	control,
	busy,
	done,
	cycles,
	overflow
);
	reg _sv2v_0;
	input wire clk;
	input wire rst;
	input wire ce;
	input wire start;
	input wire is_fill;
	input wire is_binary;
	input wire src_xy;
	input wire dst_xy;
	input wire [31:0] saddr;
	input wire [31:0] daddr;
	input wire [31:0] dydx;
	input wire [31:0] sptch;
	input wire [31:0] dptch;
	input wire [31:0] offset;
	input wire [31:0] wstart;
	input wire [31:0] wend;
	input wire [15:0] convsp;
	input wire [15:0] convdp;
	input wire [15:0] psize;
	input wire [15:0] control;
	output reg busy;
	output reg done;
	output reg [31:0] cycles;
	output reg overflow;
	localparam [31:0] CTRL_T_BIT = 5;
	localparam [31:0] CTRL_W_LO = 6;
	localparam [31:0] CTRL_W_HI = 7;
	localparam [31:0] CTRL_PBH_BIT = 8;
	localparam [31:0] CTRL_PBV_BIT = 9;
	localparam [31:0] CTRL_ROP_LO = 10;
	localparam [31:0] CTRL_ROP_HI = 14;
	reg [1:0] state_q;
	reg [39:0] acc_q;
	reg [15:0] rows_left_q;
	reg [15:0] dx_q;
	reg [31:0] src_addr_q;
	reg [31:0] dst_addr_q;
	reg [31:0] sptch_q;
	reg [31:0] dptch_q;
	reg [4:0] bpp_shift_q;
	reg [3:0] op_timing_q;
	reg fill_q;
	reg binary_q;
	reg reverse_q;
	reg yreverse_q;
	reg needs_dest_q;
	function automatic [4:0] mame_bpp_shift;
		input reg [4:0] psize_low;
		if (psize_low[4])
			mame_bpp_shift = 5'd4;
		else if (psize_low[3])
			mame_bpp_shift = 5'd3;
		else if (psize_low[2])
			mame_bpp_shift = 5'd2;
		else if (psize_low[1])
			mame_bpp_shift = 5'd1;
		else
			mame_bpp_shift = 5'd0;
	endfunction
	function automatic [4:0] mame_pixel_shift;
		input reg [4:0] psize_low;
		(* full_case, parallel_case *)
		case (psize_low)
			5'd1: mame_pixel_shift = 5'd0;
			5'd2: mame_pixel_shift = 5'd1;
			5'd4: mame_pixel_shift = 5'd2;
			5'd8: mame_pixel_shift = 5'd3;
			5'd16: mame_pixel_shift = 5'd4;
			default: mame_pixel_shift = 5'd0;
		endcase
	endfunction
	function automatic [3:0] mame_rop_timing;
		input reg [4:0] rop;
		input reg transparency;
		reg [3:0] base;
		begin
			(* full_case, parallel_case *)
			case (rop)
				5'd0, 5'd22, 5'd23, 5'd24, 5'd25, 5'd26, 5'd27, 5'd28, 5'd29, 5'd30, 5'd31: base = 4'd2;
				5'd17, 5'd18, 5'd20, 5'd21: base = 4'd5;
				5'd19: base = 4'd6;
				default: base = 4'd4;
			endcase
			mame_rop_timing = base + (transparency ? 4'd2 : 4'd0);
		end
	endfunction
	function automatic [39:0] mul_small;
		input reg [39:0] value;
		input reg [3:0] factor;
		(* full_case, parallel_case *)
		case (factor)
			4'd0: mul_small = 40'd0;
			4'd1: mul_small = value;
			4'd2: mul_small = value << 1;
			4'd3: mul_small = (value << 1) + value;
			4'd4: mul_small = value << 2;
			4'd5: mul_small = (value << 2) + value;
			4'd6: mul_small = (value << 2) + (value << 1);
			4'd7: mul_small = ((value << 2) + (value << 1)) + value;
			4'd8: mul_small = value << 3;
			4'd9: mul_small = (value << 3) + value;
			4'd10: mul_small = (value << 3) + (value << 1);
			default: mul_small = 40'd0;
		endcase
	endfunction
	function automatic [31:0] xy_to_linear;
		input reg [31:0] xy;
		input reg [31:0] base_offset;
		input reg [15:0] conv;
		input reg [4:0] pixel_shift;
		reg signed [63:0] sx;
		reg signed [63:0] sy;
		reg signed [63:0] soff;
		reg signed [63:0] result;
		reg [4:0] conv_shift;
		begin
			sx = {{48 {xy[15]}}, xy[15:0]};
			sy = {{48 {xy[31]}}, xy[31:16]};
			soff = {{32 {base_offset[31]}}, base_offset};
			conv_shift = 5'd31 - conv[4:0];
			result = (soff + (sy <<< conv_shift)) + (sx <<< pixel_shift);
			xy_to_linear = result[31:0];
		end
	endfunction
	reg [4:0] calc_bpp_shift;
	reg [4:0] calc_pixel_shift;
	reg [4:0] calc_convsp_shift;
	reg [4:0] calc_convdp_shift;
	reg [4:0] calc_rop;
	reg [3:0] calc_op_timing;
	reg [1:0] calc_wmode;
	reg calc_transparency;
	reg calc_needs_dest;
	reg calc_any_xy;
	reg calc_active;
	reg signed [32:0] calc_dx_orig;
	reg signed [32:0] calc_dy_orig;
	reg signed [32:0] calc_sx_orig;
	reg signed [32:0] calc_sy_orig;
	reg signed [32:0] calc_ex;
	reg signed [32:0] calc_ey;
	reg signed [32:0] calc_sx;
	reg signed [32:0] calc_sy;
	reg signed [32:0] calc_dx;
	reg signed [32:0] calc_dy;
	reg signed [32:0] calc_wsx;
	reg signed [32:0] calc_wsy;
	reg signed [32:0] calc_wex;
	reg signed [32:0] calc_wey;
	reg signed [32:0] calc_diff;
	reg [31:0] calc_src_addr;
	reg [31:0] calc_dst_addr;
	reg [31:0] calc_dst_xy;
	reg [31:0] calc_bpp_mask;
	reg [63:0] calc_addr_delta;
	reg [39:0] calc_base_cycles;
	reg [15:0] calc_rows;
	reg [15:0] calc_dx_u;
	always @(*) begin
		if (_sv2v_0)
			;
		calc_bpp_shift = mame_bpp_shift(psize[4:0]);
		calc_pixel_shift = mame_pixel_shift(psize[4:0]);
		calc_convsp_shift = 5'd31 - convsp[4:0];
		calc_convdp_shift = 5'd31 - convdp[4:0];
		calc_rop = control[CTRL_ROP_HI:CTRL_ROP_LO];
		calc_wmode = control[CTRL_W_HI:CTRL_W_LO];
		calc_transparency = control[CTRL_T_BIT];
		calc_op_timing = mame_rop_timing(calc_rop, calc_transparency);
		calc_needs_dest = (calc_rop != 5'd0) || calc_transparency;
		calc_any_xy = src_xy || dst_xy;
		calc_dx_orig = {{17 {dydx[15]}}, dydx[15:0]};
		calc_dy_orig = {{17 {dydx[31]}}, dydx[31:16]};
		calc_sx_orig = {{17 {daddr[15]}}, daddr[15:0]};
		calc_sy_orig = {{17 {daddr[31]}}, daddr[31:16]};
		calc_wsx = {{17 {wstart[15]}}, wstart[15:0]};
		calc_wsy = {{17 {wstart[31]}}, wstart[31:16]};
		calc_wex = {{17 {wend[15]}}, wend[15:0]};
		calc_wey = {{17 {wend[31]}}, wend[31:16]};
		calc_sx = calc_sx_orig;
		calc_sy = calc_sy_orig;
		calc_ex = (calc_sx_orig + calc_dx_orig) - 33'sd1;
		calc_ey = (calc_sy_orig + calc_dy_orig) - 33'sd1;
		calc_dx = calc_dx_orig;
		calc_dy = calc_dy_orig;
		calc_diff = 33'sd0;
		calc_src_addr = (src_xy ? xy_to_linear(saddr, offset, convsp, calc_pixel_shift) : saddr);
		calc_dst_addr = daddr;
		calc_dst_xy = daddr;
		calc_addr_delta = 64'd0;
		if (!is_fill && !is_binary)
			calc_base_cycles = 40'd7 + (src_xy ? 40'd2 : 40'd0);
		else
			calc_base_cycles = 40'd4;
		if (dst_xy) begin
			if (!is_fill && !is_binary)
				calc_base_cycles = (calc_base_cycles + 40'd2) + (src_xy ? 40'd1 : 40'd0);
			else
				calc_base_cycles = calc_base_cycles + 40'd2;
			if (calc_wmode != 2'd0) begin
				calc_base_cycles = calc_base_cycles + 40'd3;
				calc_diff = calc_wsx - calc_sx;
				if (calc_diff > 33'sd0) begin
					if (!is_fill) begin
						calc_addr_delta = {{31 {1'b0}}, calc_diff} << (is_binary ? 5'd0 : calc_bpp_shift);
						calc_src_addr = calc_src_addr + calc_addr_delta[31:0];
					end
					calc_sx = calc_sx + calc_diff;
				end
				calc_diff = calc_ex - calc_wex;
				if (calc_diff > 33'sd0)
					calc_ex = calc_ex - calc_diff;
				calc_diff = calc_wsy - calc_sy;
				if (calc_diff > 33'sd0) begin
					if (!is_fill) begin
						calc_addr_delta = {{31 {1'b0}}, calc_diff} << calc_convsp_shift;
						calc_src_addr = calc_src_addr + calc_addr_delta[31:0];
					end
					calc_sy = calc_sy + calc_diff;
				end
				calc_diff = calc_ey - calc_wey;
				if (calc_diff > 33'sd0)
					calc_ey = calc_ey - calc_diff;
				calc_dx = (calc_ex - calc_sx) + 33'sd1;
				calc_dy = (calc_ey - calc_sy) + 33'sd1;
				if ((calc_dx_orig != calc_dx) || (calc_dy_orig != calc_dy)) begin
					if ((calc_sx_orig != calc_sx) || (calc_sy_orig != calc_sy))
						calc_base_cycles = calc_base_cycles + 40'd11;
					else
						calc_base_cycles = calc_base_cycles + 40'd3;
				end
				else if ((calc_sx_orig != calc_sx) || (calc_sy_orig != calc_sy))
					calc_base_cycles = calc_base_cycles + 40'd7;
			end
			calc_dst_xy = {calc_sy[15:0], calc_sx[15:0]};
			calc_dst_addr = xy_to_linear(calc_dst_xy, offset, convdp, calc_pixel_shift);
		end
		calc_bpp_mask = (32'd1 << calc_bpp_shift) - 32'd1;
		calc_dst_addr = calc_dst_addr & ~calc_bpp_mask;
		if ((!is_fill && !is_binary) && control[CTRL_PBH_BIT])
			calc_src_addr = calc_src_addr & ~calc_bpp_mask;
		calc_active = ((calc_dx > 33'sd0) && (calc_dy > 33'sd0)) && !(dst_xy && (calc_wmode == 2'd1));
		calc_rows = calc_dy[15:0];
		calc_dx_u = calc_dx[15:0];
		if ((((calc_active && !is_fill) && !is_binary) && control[CTRL_PBH_BIT]) && calc_any_xy) begin
			calc_addr_delta = {{31 {1'b0}}, calc_dx} << calc_bpp_shift;
			calc_src_addr = calc_src_addr + calc_addr_delta[31:0];
			calc_dst_addr = calc_dst_addr + calc_addr_delta[31:0];
		end
		if ((((calc_active && !is_fill) && !is_binary) && control[CTRL_PBV_BIT]) && calc_any_xy) begin
			calc_addr_delta = {{31 {1'b0}}, calc_dy - 33'sd1} << calc_convsp_shift;
			calc_src_addr = calc_src_addr + calc_addr_delta[31:0];
			calc_addr_delta = {{31 {1'b0}}, calc_dy - 33'sd1} << calc_convdp_shift;
			calc_dst_addr = calc_dst_addr + calc_addr_delta[31:0];
		end
		if (calc_active && is_fill)
			calc_base_cycles = calc_base_cycles + 40'd2;
		else if (calc_active && is_binary)
			calc_base_cycles = calc_base_cycles + 40'd2;
	end
	reg [31:0] row_total_bits;
	reg [31:0] row_dst_span;
	reg [31:0] row_src_span;
	reg [31:0] row_dst_words;
	reg [31:0] row_src_words;
	reg [31:0] row_dest_reads;
	reg [31:0] row_readwrites;
	reg [31:0] row_reverse_start;
	reg row_left_partial;
	reg row_right_partial;
	reg [3:0] row_extra_timing;
	reg [39:0] row_cycles;
	reg [39:0] row_sum;
	always @(*) begin
		if (_sv2v_0)
			;
		row_total_bits = {16'd0, dx_q} << bpp_shift_q;
		row_dst_span = {28'd0, dst_addr_q[3:0]} + row_total_bits;
		row_src_span = 32'd0;
		row_dst_words = (row_dst_span + 32'd15) >> 4;
		row_src_words = (row_dst_words << bpp_shift_q) >> 4;
		row_dest_reads = 32'd0;
		row_readwrites = 32'd0;
		row_reverse_start = dst_addr_q - row_total_bits;
		row_left_partial = 1'b0;
		row_right_partial = 1'b0;
		row_extra_timing = op_timing_q - 4'd2;
		row_cycles = 40'd0;
		if (fill_q)
			row_cycles = mul_small({8'd0, row_dst_words}, op_timing_q);
		else if (binary_q)
			row_cycles = mul_small({8'd0, row_dst_words}, op_timing_q) + ({8'd0, row_src_words} << 1);
		else if (reverse_q) begin
			row_dst_span = {28'd0, row_reverse_start[3:0]} + row_total_bits;
			row_dst_words = (row_dst_span + 32'd15) >> 4;
			row_cycles = mul_small({8'd0, row_dst_words}, op_timing_q + 4'd2) + 40'd2;
		end
		else begin
			row_dst_span = {28'd0, dst_addr_q[3:0]} + row_total_bits;
			row_src_span = {28'd0, src_addr_q[3:0]} + row_total_bits;
			row_dst_words = (row_dst_span + 32'd15) >> 4;
			row_src_words = (row_src_span + 32'd15) >> 4;
			row_left_partial = dst_addr_q[3:0] != 4'd0;
			row_right_partial = row_dst_span[3:0] != 4'd0;
			if (needs_dest_q)
				row_dest_reads = row_dst_words + (row_right_partial ? 32'd1 : 32'd0);
			else
				row_dest_reads = (row_left_partial ? 32'd1 : 32'd0) + (row_right_partial ? 32'd1 : 32'd0);
			row_readwrites = (row_src_words + row_dst_words) + row_dest_reads;
			row_cycles = ({8'd0, row_readwrites} << 1) + mul_small({24'd0, dx_q}, row_extra_timing);
		end
		row_sum = acc_q + row_cycles;
	end
	always @(posedge clk)
		if (rst) begin
			state_q <= 2'd0;
			acc_q <= 40'd0;
			rows_left_q <= 16'd0;
			dx_q <= 16'd0;
			src_addr_q <= 32'd0;
			dst_addr_q <= 32'd0;
			sptch_q <= 32'd0;
			dptch_q <= 32'd0;
			bpp_shift_q <= 5'd0;
			op_timing_q <= 4'd2;
			fill_q <= 1'b0;
			binary_q <= 1'b0;
			reverse_q <= 1'b0;
			yreverse_q <= 1'b0;
			needs_dest_q <= 1'b0;
			busy <= 1'b0;
			done <= 1'b0;
			cycles <= 32'd0;
			overflow <= 1'b0;
		end
		else if (ce !== 1'b0) begin
			if (start) begin
				acc_q <= calc_base_cycles;
				rows_left_q <= calc_rows;
				dx_q <= calc_dx_u;
				src_addr_q <= calc_src_addr;
				dst_addr_q <= calc_dst_addr;
				sptch_q <= sptch;
				dptch_q <= dptch;
				bpp_shift_q <= calc_bpp_shift;
				op_timing_q <= calc_op_timing;
				fill_q <= is_fill;
				binary_q <= is_binary;
				reverse_q <= (!is_fill && !is_binary) && control[CTRL_PBH_BIT];
				yreverse_q <= (!is_fill && !is_binary) && control[CTRL_PBV_BIT];
				needs_dest_q <= calc_needs_dest;
				done <= 1'b0;
				overflow <= 1'b0;
				if (calc_active) begin
					state_q <= 2'd1;
					busy <= 1'b1;
				end
				else begin
					state_q <= 2'd2;
					busy <= 1'b0;
					done <= 1'b1;
					overflow <= |calc_base_cycles[39:32];
					cycles <= (|calc_base_cycles[39:32] ? 32'hffffffff : calc_base_cycles[31:0]);
				end
			end
			else
				(* full_case, parallel_case *)
				case (state_q)
					2'd1: begin
						acc_q <= row_sum;
						if (rows_left_q == 16'd1) begin
							state_q <= 2'd2;
							busy <= 1'b0;
							done <= 1'b1;
							overflow <= |row_sum[39:32];
							cycles <= (|row_sum[39:32] ? 32'hffffffff : row_sum[31:0]);
						end
						else begin
							rows_left_q <= rows_left_q - 16'd1;
							if (!fill_q && !binary_q) begin
								if (yreverse_q) begin
									src_addr_q <= src_addr_q - sptch_q;
									dst_addr_q <= dst_addr_q - dptch_q;
								end
								else begin
									src_addr_q <= src_addr_q + sptch_q;
									dst_addr_q <= dst_addr_q + dptch_q;
								end
							end
						end
					end
					2'd0, 2'd2: busy <= 1'b0;
					default: begin
						state_q <= 2'd0;
						busy <= 1'b0;
						done <= 1'b0;
					end
				endcase
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_int_ctrl (
	intpend,
	intenb,
	ie,
	int_req,
	int_vector
);
	reg _sv2v_0;
	input wire [15:0] intpend;
	input wire [15:0] intenb;
	input wire ie;
	output wire int_req;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	output reg [31:0] int_vector;
	wire [15:0] active;
	assign active = intpend & intenb;
	localparam [31:0] tms34010_pkg_INT_DI_BIT = 10;
	localparam [31:0] tms34010_pkg_INT_HI_BIT = 9;
	localparam [31:0] tms34010_pkg_INT_WV_BIT = 11;
	localparam [31:0] tms34010_pkg_INT_X1_BIT = 1;
	localparam [31:0] tms34010_pkg_INT_X2_BIT = 2;
	assign int_req = ie && ((((active[tms34010_pkg_INT_HI_BIT] || active[tms34010_pkg_INT_DI_BIT]) || active[tms34010_pkg_INT_WV_BIT]) || active[tms34010_pkg_INT_X1_BIT]) || active[tms34010_pkg_INT_X2_BIT]);
	localparam [31:0] tms34010_pkg_INT_VEC_DI = 32'hfffffea0;
	localparam [31:0] tms34010_pkg_INT_VEC_HI = 32'hfffffec0;
	localparam [31:0] tms34010_pkg_INT_VEC_WV = 32'hfffffe80;
	localparam [31:0] tms34010_pkg_INT_VEC_X1 = 32'hffffffc0;
	localparam [31:0] tms34010_pkg_INT_VEC_X2 = 32'hffffffa0;
	always @(*) begin
		if (_sv2v_0)
			;
		if (active[tms34010_pkg_INT_HI_BIT])
			int_vector = tms34010_pkg_INT_VEC_HI;
		else if (active[tms34010_pkg_INT_DI_BIT])
			int_vector = tms34010_pkg_INT_VEC_DI;
		else if (active[tms34010_pkg_INT_WV_BIT])
			int_vector = tms34010_pkg_INT_VEC_WV;
		else if (active[tms34010_pkg_INT_X1_BIT])
			int_vector = tms34010_pkg_INT_VEC_X1;
		else if (active[tms34010_pkg_INT_X2_BIT])
			int_vector = tms34010_pkg_INT_VEC_X2;
		else
			int_vector = tms34010_pkg_INT_VEC_HI;
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_pc (
	clk,
	ce_cpu,
	rst,
	load_en,
	load_value,
	advance_en,
	advance_amount,
	pc_o
);
	reg _sv2v_0;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	localparam [31:0] tms34010_pkg_RESET_PC = 1'sb0;
	parameter [31:0] RESET_VALUE = tms34010_pkg_RESET_PC;
	input wire clk;
	input wire ce_cpu;
	input wire rst;
	input wire load_en;
	input wire [31:0] load_value;
	input wire advance_en;
	localparam [31:0] tms34010_pkg_PC_ADVANCE_WIDTH = 8;
	input wire [7:0] advance_amount;
	output wire [31:0] pc_o;
	reg [31:0] pc_q;
	reg [31:0] pc_d;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst)
				pc_q <= RESET_VALUE;
			else
				pc_q <= pc_d;
		end
	wire [31:0] advance_ext;
	assign advance_ext = {{tms34010_pkg_ADDR_WIDTH - tms34010_pkg_PC_ADVANCE_WIDTH {1'b0}}, advance_amount};
	always @(*) begin
		if (_sv2v_0)
			;
		pc_d = pc_q;
		if (load_en)
			pc_d = load_value;
		else if (advance_en)
			pc_d = pc_q + advance_ext;
	end
	assign pc_o = pc_q;
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_regfile (
	clk,
	ce_cpu,
	rst,
	rs1_file,
	rs1_idx,
	rs1_data,
	rs2_file,
	rs2_idx,
	rs2_data,
	rs3_file,
	rs3_idx,
	rs3_data,
	wr_en,
	wr_file,
	wr_idx,
	wr_data,
	aux_wr_target,
	aux_wr_data,
	sp_o
);
	reg _sv2v_0;
	input wire clk;
	input wire ce_cpu;
	input wire rst;
	input wire rs1_file;
	input wire [3:0] rs1_idx;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	output reg [31:0] rs1_data;
	input wire rs2_file;
	input wire [3:0] rs2_idx;
	output reg [31:0] rs2_data;
	input wire rs3_file;
	input wire [3:0] rs3_idx;
	output reg [31:0] rs3_data;
	input wire wr_en;
	input wire wr_file;
	input wire [3:0] wr_idx;
	input wire [31:0] wr_data;
	input wire [30:0] aux_wr_target;
	input wire [31:0] aux_wr_data;
	output wire [31:0] sp_o;
	reg [31:0] a_regs [0:14];
	reg [31:0] b_regs [0:14];
	reg [31:0] sp_q;
	localparam [3:0] tms34010_pkg_REG_SP_IDX = 4'hf;
	always @(*) begin
		if (_sv2v_0)
			;
		if (rs1_idx == tms34010_pkg_REG_SP_IDX)
			rs1_data = sp_q;
		else if (rs1_file == 1'b1)
			rs1_data = b_regs[rs1_idx];
		else
			rs1_data = a_regs[rs1_idx];
	end
	always @(*) begin
		if (_sv2v_0)
			;
		if (rs2_idx == tms34010_pkg_REG_SP_IDX)
			rs2_data = sp_q;
		else if (rs2_file == 1'b1)
			rs2_data = b_regs[rs2_idx];
		else
			rs2_data = a_regs[rs2_idx];
	end
	always @(*) begin
		if (_sv2v_0)
			;
		if (rs3_idx == tms34010_pkg_REG_SP_IDX)
			rs3_data = sp_q;
		else if (rs3_file == 1'b1)
			rs3_data = b_regs[rs3_idx];
		else
			rs3_data = a_regs[rs3_idx];
	end
	always @(posedge clk)
		if (rst) begin
			begin : sv2v_autoblock_1
				reg [31:0] i;
				for (i = 0; i < 15; i = i + 1)
					a_regs[i] <= 1'sb0;
			end
			begin : sv2v_autoblock_2
				reg [31:0] i;
				for (i = 0; i < 15; i = i + 1)
					b_regs[i] <= 1'sb0;
			end
			sp_q <= 1'sb0;
		end
		else begin
			begin : sv2v_autoblock_3
				reg [31:0] i;
				for (i = 0; i < 15; i = i + 1)
					begin
						if (aux_wr_target[i])
							a_regs[i] <= aux_wr_data;
						if (aux_wr_target[15 + i])
							b_regs[i] <= aux_wr_data;
					end
			end
			if (aux_wr_target[30])
				sp_q <= aux_wr_data;
			if ((ce_cpu !== 1'b0) && wr_en) begin
				if (wr_idx == tms34010_pkg_REG_SP_IDX)
					sp_q <= wr_data;
				else if (wr_file == 1'b1)
					b_regs[wr_idx] <= wr_data;
				else
					a_regs[wr_idx] <= wr_data;
			end
		end
	assign sp_o = sp_q;
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_shifter (
	op,
	a,
	amount,
	result,
	flags
);
	reg _sv2v_0;
	input wire [2:0] op;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	input wire [31:0] a;
	localparam [31:0] tms34010_pkg_SHIFT_AMOUNT_WIDTH = 5;
	input wire [4:0] amount;
	output reg [31:0] result;
	output reg [3:0] flags;
	wire [tms34010_pkg_SHIFT_AMOUNT_WIDTH:0] amount_w6;
	wire [tms34010_pkg_SHIFT_AMOUNT_WIDTH:0] complement_w6;
	assign amount_w6 = {1'b0, amount};
	assign complement_w6 = 6'd32 - amount_w6;
	wire [4:0] left_carry_idx;
	wire [4:0] right_carry_idx;
	assign left_carry_idx = complement_w6[4:0];
	assign right_carry_idx = amount - 5'd1;
	wire [31:0] left;
	wire [31:0] right_l;
	wire signed [31:0] right_a;
	wire [31:0] right_comp;
	wire [31:0] left_comp;
	assign left = a << amount;
	assign right_l = a >> amount;
	assign right_a = $signed(a) >>> amount;
	assign right_comp = a >> complement_w6;
	assign left_comp = a << complement_w6;
	wire [31:0] sla_v_mask;
	wire [31:0] sla_v_res2;
	assign sla_v_mask = (32'hffffffff << (6'd31 - amount_w6)) & 32'h7fffffff;
	assign sla_v_res2 = (a[31] ? a ^ sla_v_mask : a);
	always @(*) begin
		if (_sv2v_0)
			;
		result = a;
		flags[3] = a[31];
		flags[2] = 1'b0;
		flags[1] = a == {32 {1'sb0}};
		flags[0] = 1'b0;
		if (amount != {5 {1'sb0}}) begin
			(* full_case, parallel_case *)
			case (op)
				3'd0: begin
					result = left;
					flags[2] = a[left_carry_idx];
				end
				3'd1: begin
					result = left;
					flags[2] = a[left_carry_idx];
					flags[0] = |(sla_v_res2 & sla_v_mask);
				end
				3'd2: begin
					result = right_l;
					flags[2] = a[right_carry_idx];
				end
				3'd3: begin
					result = right_a;
					flags[2] = a[right_carry_idx];
				end
				3'd4: begin
					result = left | right_comp;
					flags[2] = a[left_carry_idx];
				end
				3'd5: begin
					result = right_l | left_comp;
					flags[2] = a[right_carry_idx];
				end
				default:
					;
			endcase
			flags[3] = result[31];
			flags[1] = result == {32 {1'sb0}};
		end
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_status_reg (
	clk,
	ce_cpu,
	rst,
	flag_update_en,
	flags_in,
	flag_update_mask,
	st_write_en,
	st_write_data,
	st_o,
	n_o,
	c_o,
	z_o,
	v_o
);
	input wire clk;
	input wire ce_cpu;
	input wire rst;
	input wire flag_update_en;
	input wire [3:0] flags_in;
	input wire [3:0] flag_update_mask;
	input wire st_write_en;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	input wire [31:0] st_write_data;
	output wire [31:0] st_o;
	output wire n_o;
	output wire c_o;
	output wire z_o;
	output wire v_o;
	reg [31:0] st_q;
	localparam [31:0] tms34010_pkg_ST_C_BIT = 30;
	localparam [31:0] tms34010_pkg_ST_N_BIT = 31;
	localparam [31:0] tms34010_pkg_ST_RESET_VALUE = 32'h00000010;
	localparam [31:0] tms34010_pkg_ST_V_BIT = 28;
	localparam [31:0] tms34010_pkg_ST_Z_BIT = 29;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst)
				st_q <= tms34010_pkg_ST_RESET_VALUE;
			else if (st_write_en)
				st_q <= st_write_data;
			else if (flag_update_en) begin
				if (flag_update_mask[3])
					st_q[tms34010_pkg_ST_N_BIT] <= flags_in[3];
				if (flag_update_mask[2])
					st_q[tms34010_pkg_ST_C_BIT] <= flags_in[2];
				if (flag_update_mask[1])
					st_q[tms34010_pkg_ST_Z_BIT] <= flags_in[1];
				if (flag_update_mask[0])
					st_q[tms34010_pkg_ST_V_BIT] <= flags_in[0];
			end
		end
	assign st_o = st_q;
	assign n_o = st_q[tms34010_pkg_ST_N_BIT];
	assign c_o = st_q[tms34010_pkg_ST_C_BIT];
	assign z_o = st_q[tms34010_pkg_ST_Z_BIT];
	assign v_o = st_q[tms34010_pkg_ST_V_BIT];
endmodule
`default_nettype wire
`default_nettype none
module tms34010_io_cpu_config (
	clk,
	rst,
	ce_cpu,
	req,
	we,
	is_io,
	ack,
	addr,
	wdata,
	size,
	live_psize,
	live_convdp,
	live_convsp,
	live_control,
	live_pmask,
	psize,
	convdp,
	convsp,
	control,
	pmask
);
	input wire clk;
	input wire rst;
	input wire ce_cpu;
	input wire req;
	input wire we;
	input wire is_io;
	input wire ack;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	input wire [31:0] addr;
	input wire [15:0] wdata;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	input wire [5:0] size;
	input wire [15:0] live_psize;
	input wire [15:0] live_convdp;
	input wire [15:0] live_convsp;
	input wire [15:0] live_control;
	input wire [15:0] live_pmask;
	output reg [15:0] psize;
	output reg [15:0] convdp;
	output reg [15:0] convsp;
	output reg [15:0] control;
	output reg [15:0] pmask;
	localparam [31:0] tms34010_pkg_IO_REG_IDX_W = 5;
	wire [4:0] wr_idx = addr[8:4];
	wire config_write = ((((ce_cpu !== 1'b0) && req) && we) && is_io) && ack;
	function automatic signed [5:0] sv2v_cast_13C0F_signed;
		input reg signed [5:0] inp;
		sv2v_cast_13C0F_signed = inp;
	endfunction
	function automatic [15:0] sv2v_cast_16;
		input reg [15:0] inp;
		sv2v_cast_16 = inp;
	endfunction
	function automatic [15:0] tms34010_pkg_io_field_mask;
		input reg [3:0] bit_off;
		input reg [5:0] fsize;
		reg [31:0] base;
		begin
			base = (fsize >= sv2v_cast_13C0F_signed(16) ? 32'h0000ffff : (32'd1 << fsize) - 32'd1);
			tms34010_pkg_io_field_mask = sv2v_cast_16((base << bit_off) & 32'h0000ffff);
		end
	endfunction
	function automatic [15:0] tms34010_pkg_io_field_merge;
		input reg [15:0] current;
		input reg [15:0] wdata;
		input reg [3:0] bit_off;
		input reg [5:0] fsize;
		reg [15:0] m;
		begin
			m = tms34010_pkg_io_field_mask(bit_off, fsize);
			tms34010_pkg_io_field_merge = (current & ~m) | ((wdata << bit_off) & m);
		end
	endfunction
	wire [15:0] psize_merged = tms34010_pkg_io_field_merge(psize, wdata, addr[3:0], size);
	wire [15:0] convdp_merged = tms34010_pkg_io_field_merge(convdp, wdata, addr[3:0], size);
	wire [15:0] convsp_merged = tms34010_pkg_io_field_merge(convsp, wdata, addr[3:0], size);
	wire [15:0] control_merged = tms34010_pkg_io_field_merge(control, wdata, addr[3:0], size);
	wire [15:0] pmask_merged = tms34010_pkg_io_field_merge(pmask, wdata, addr[3:0], size);
	localparam [4:0] tms34010_pkg_IO_IDX_CONTROL = 5'h0b;
	localparam [4:0] tms34010_pkg_IO_IDX_CONVDP = 5'h14;
	localparam [4:0] tms34010_pkg_IO_IDX_CONVSP = 5'h13;
	localparam [4:0] tms34010_pkg_IO_IDX_PMASK = 5'h16;
	localparam [4:0] tms34010_pkg_IO_IDX_PSIZE = 5'h15;
	always @(posedge clk)
		if (rst) begin
			psize <= 16'h0000;
			convdp <= 16'h0000;
			convsp <= 16'h0000;
			control <= 16'h0000;
			pmask <= 16'h0000;
		end
		else if (config_write)
			(* full_case, parallel_case *)
			case (wr_idx)
				tms34010_pkg_IO_IDX_PSIZE: psize <= psize_merged;
				tms34010_pkg_IO_IDX_CONVDP: convdp <= convdp_merged;
				tms34010_pkg_IO_IDX_CONVSP: convsp <= convsp_merged;
				tms34010_pkg_IO_IDX_CONTROL: control <= control_merged;
				tms34010_pkg_IO_IDX_PMASK: pmask <= pmask_merged;
				default:
					;
			endcase
endmodule
`default_nettype wire
`default_nettype none
module tms34010_io_cpu_read_mux (
	is_io,
	addr,
	live_rdata,
	psize,
	convdp,
	convsp,
	control,
	pmask,
	intenb,
	intpend,
	hstctlh,
	cpu_rdata
);
	reg _sv2v_0;
	input wire is_io;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	input wire [31:0] addr;
	input wire [15:0] live_rdata;
	input wire [15:0] psize;
	input wire [15:0] convdp;
	input wire [15:0] convsp;
	input wire [15:0] control;
	input wire [15:0] pmask;
	input wire [15:0] intenb;
	input wire [15:0] intpend;
	input wire [15:0] hstctlh;
	output reg [15:0] cpu_rdata;
	localparam [31:0] tms34010_pkg_IO_REG_IDX_W = 5;
	wire [4:0] rd_idx = addr[8:4];
	localparam [4:0] tms34010_pkg_IO_IDX_CONTROL = 5'h0b;
	localparam [4:0] tms34010_pkg_IO_IDX_CONVDP = 5'h14;
	localparam [4:0] tms34010_pkg_IO_IDX_CONVSP = 5'h13;
	localparam [4:0] tms34010_pkg_IO_IDX_HSTCTLH = 5'h10;
	localparam [4:0] tms34010_pkg_IO_IDX_INTENB = 5'h11;
	localparam [4:0] tms34010_pkg_IO_IDX_INTPEND = 5'h12;
	localparam [4:0] tms34010_pkg_IO_IDX_PMASK = 5'h16;
	localparam [4:0] tms34010_pkg_IO_IDX_PSIZE = 5'h15;
	always @(*) begin
		if (_sv2v_0)
			;
		cpu_rdata = live_rdata;
		if (is_io)
			case (rd_idx)
				tms34010_pkg_IO_IDX_PSIZE: cpu_rdata = psize;
				tms34010_pkg_IO_IDX_CONVDP: cpu_rdata = convdp;
				tms34010_pkg_IO_IDX_CONVSP: cpu_rdata = convsp;
				tms34010_pkg_IO_IDX_CONTROL: cpu_rdata = control;
				tms34010_pkg_IO_IDX_PMASK: cpu_rdata = pmask;
				tms34010_pkg_IO_IDX_INTENB: cpu_rdata = intenb;
				tms34010_pkg_IO_IDX_INTPEND: cpu_rdata = intpend;
				tms34010_pkg_IO_IDX_HSTCTLH: cpu_rdata = hstctlh;
				default:
					;
			endcase
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_io_cpu_status (
	clk,
	rst,
	ce_cpu,
	req,
	we,
	is_io,
	ack,
	addr,
	wdata,
	size,
	live_intenb,
	live_intpend,
	live_hstctlh,
	nmi_clear,
	intenb,
	intpend,
	hstctlh
);
	input wire clk;
	input wire rst;
	input wire ce_cpu;
	input wire req;
	input wire we;
	input wire is_io;
	input wire ack;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	input wire [31:0] addr;
	input wire [15:0] wdata;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	input wire [5:0] size;
	input wire [15:0] live_intenb;
	input wire [15:0] live_intpend;
	input wire [15:0] live_hstctlh;
	input wire nmi_clear;
	output reg [15:0] intenb;
	output reg [15:0] intpend;
	output reg [15:0] hstctlh;
	reg intenb_write_bridge;
	reg intpend_write_bridge;
	reg hstctlh_write_bridge;
	localparam [31:0] tms34010_pkg_IO_REG_IDX_W = 5;
	wire [4:0] wr_idx = addr[8:4];
	wire status_write = ((((ce_cpu !== 1'b0) && req) && we) && is_io) && ack;
	function automatic signed [5:0] sv2v_cast_13C0F_signed;
		input reg signed [5:0] inp;
		sv2v_cast_13C0F_signed = inp;
	endfunction
	function automatic [15:0] sv2v_cast_16;
		input reg [15:0] inp;
		sv2v_cast_16 = inp;
	endfunction
	function automatic [15:0] tms34010_pkg_io_field_mask;
		input reg [3:0] bit_off;
		input reg [5:0] fsize;
		reg [31:0] base;
		begin
			base = (fsize >= sv2v_cast_13C0F_signed(16) ? 32'h0000ffff : (32'd1 << fsize) - 32'd1);
			tms34010_pkg_io_field_mask = sv2v_cast_16((base << bit_off) & 32'h0000ffff);
		end
	endfunction
	function automatic [15:0] tms34010_pkg_io_field_merge;
		input reg [15:0] current;
		input reg [15:0] wdata;
		input reg [3:0] bit_off;
		input reg [5:0] fsize;
		reg [15:0] m;
		begin
			m = tms34010_pkg_io_field_mask(bit_off, fsize);
			tms34010_pkg_io_field_merge = (current & ~m) | ((wdata << bit_off) & m);
		end
	endfunction
	wire [15:0] intenb_merged = tms34010_pkg_io_field_merge(intenb, wdata, addr[3:0], size);
	wire [15:0] intpend_merged = tms34010_pkg_io_field_merge(intpend, wdata, addr[3:0], size);
	wire [15:0] hstctlh_merged = tms34010_pkg_io_field_merge(hstctlh, wdata, addr[3:0], size);
	localparam [31:0] tms34010_pkg_HSTCTL_NMI_BIT = 8;
	localparam [4:0] tms34010_pkg_IO_IDX_HSTCTLH = 5'h10;
	localparam [4:0] tms34010_pkg_IO_IDX_INTENB = 5'h11;
	localparam [4:0] tms34010_pkg_IO_IDX_INTPEND = 5'h12;
	localparam [31:0] tms34010_pkg_INT_DI_BIT = 10;
	localparam [31:0] tms34010_pkg_INT_WV_BIT = 11;
	localparam [15:0] tms34010_pkg_INTPEND_W0C_MASK = (16'h0001 << tms34010_pkg_INT_DI_BIT) | (16'h0001 << tms34010_pkg_INT_WV_BIT);
	function automatic [15:0] tms34010_pkg_intpend_apply_cpu_write;
		input reg [15:0] current;
		input reg [15:0] wdata;
		tms34010_pkg_intpend_apply_cpu_write = current & (wdata | ~tms34010_pkg_INTPEND_W0C_MASK);
	endfunction
	always @(posedge clk)
		if (rst) begin
			intenb <= 16'h0000;
			intpend <= 16'h0000;
			hstctlh <= 16'h0000;
			intenb_write_bridge <= 1'b0;
			intpend_write_bridge <= 1'b0;
			hstctlh_write_bridge <= 1'b0;
		end
		else if (ce_cpu !== 1'b0) begin
			if (status_write && (wr_idx == tms34010_pkg_IO_IDX_INTENB)) begin
				intenb <= intenb_merged;
				intenb_write_bridge <= 1'b1;
			end
			else if (intenb_write_bridge)
				intenb_write_bridge <= 1'b0;
			else begin
				intenb <= live_intenb;
				intenb_write_bridge <= 1'b0;
			end
			if (status_write && (wr_idx == tms34010_pkg_IO_IDX_INTPEND)) begin
				intpend <= tms34010_pkg_intpend_apply_cpu_write(intpend, intpend_merged);
				intpend_write_bridge <= 1'b1;
			end
			else if (intpend_write_bridge)
				intpend_write_bridge <= 1'b0;
			else begin
				intpend <= live_intpend;
				intpend_write_bridge <= 1'b0;
			end
			if (status_write && (wr_idx == tms34010_pkg_IO_IDX_HSTCTLH)) begin
				hstctlh <= hstctlh_merged;
				hstctlh_write_bridge <= 1'b1;
			end
			else if (hstctlh_write_bridge)
				hstctlh_write_bridge <= 1'b0;
			else begin
				hstctlh <= live_hstctlh;
				hstctlh_write_bridge <= 1'b0;
			end
			if (nmi_clear)
				hstctlh[tms34010_pkg_HSTCTL_NMI_BIT] <= 1'b0;
		end
endmodule
`default_nettype wire
`default_nettype none
module tms34010_io_regs (
	clk,
	rst,
	req,
	we,
	addr,
	wdata,
	size,
	write_idx,
	write_idx_hi,
	write_span2,
	low_write_mask,
	low_write_data,
	status_guard,
	raddr,
	ce_pix,
	rdata,
	is_io,
	psize_o,
	convdp_o,
	convsp_o,
	control_o,
	pmask_o,
	dpyctl_o,
	intenb_o,
	intpend_o,
	hstctlh_o,
	dpyadr_live_i,
	dpyadr_live_valid_i,
	timing_start_o,
	line_wrap_o,
	nmi_clear,
	wvp_set,
	lint1_in
);
	parameter [0:0] PREDECODED_WRITE = 1'b0;
	input wire clk;
	input wire rst;
	input wire req;
	input wire we;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	input wire [31:0] addr;
	input wire [31:0] wdata;
	input wire [5:0] size;
	localparam [31:0] tms34010_pkg_IO_REG_IDX_W = 5;
	input wire [4:0] write_idx;
	input wire [4:0] write_idx_hi;
	input wire write_span2;
	input wire [15:0] low_write_mask;
	input wire [15:0] low_write_data;
	input wire status_guard;
	input wire [31:0] raddr;
	input wire ce_pix;
	output wire [15:0] rdata;
	output wire is_io;
	output wire [15:0] psize_o;
	output wire [15:0] convdp_o;
	output wire [15:0] convsp_o;
	output wire [15:0] control_o;
	output wire [15:0] pmask_o;
	output wire [15:0] dpyctl_o;
	output wire [15:0] intenb_o;
	output wire [15:0] intpend_o;
	output wire [15:0] hstctlh_o;
	input wire [15:0] dpyadr_live_i;
	input wire dpyadr_live_valid_i;
	output reg timing_start_o;
	output wire line_wrap_o;
	input wire nmi_clear;
	input wire wvp_set;
	input wire lint1_in;
	wire [4:0] rd_idx;
	wire [4:0] wr_idx;
	wire wr_is_io;
	assign is_io = (raddr[31:30] == 2'b11) && (raddr[29:9] == {21 {1'sb0}});
	assign rd_idx = raddr[8:4];
	assign wr_is_io = (PREDECODED_WRITE ? 1'b1 : (addr[31:30] == 2'b11) && (addr[29:9] == {21 {1'sb0}}));
	assign wr_idx = (PREDECODED_WRITE ? write_idx : addr[8:4]);
	wire wr_span2 = (PREDECODED_WRITE ? write_span2 : size > 6'd16);
	wire [4:0] wr_idx_hi = (PREDECODED_WRITE ? write_idx_hi : wr_idx + 1'b1);
	localparam [31:0] tms34010_pkg_IO_REG_COUNT = 32;
	reg [15:0] io_reg [0:31];
	wire [15:0] wr_merged;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	function automatic signed [5:0] sv2v_cast_13C0F_signed;
		input reg signed [5:0] inp;
		sv2v_cast_13C0F_signed = inp;
	endfunction
	function automatic [15:0] sv2v_cast_16;
		input reg [15:0] inp;
		sv2v_cast_16 = inp;
	endfunction
	function automatic [15:0] tms34010_pkg_io_field_mask;
		input reg [3:0] bit_off;
		input reg [5:0] fsize;
		reg [31:0] base;
		begin
			base = (fsize >= sv2v_cast_13C0F_signed(16) ? 32'h0000ffff : (32'd1 << fsize) - 32'd1);
			tms34010_pkg_io_field_mask = sv2v_cast_16((base << bit_off) & 32'h0000ffff);
		end
	endfunction
	function automatic [15:0] tms34010_pkg_io_field_merge;
		input reg [15:0] current;
		input reg [15:0] wdata;
		input reg [3:0] bit_off;
		input reg [5:0] fsize;
		reg [15:0] m;
		begin
			m = tms34010_pkg_io_field_mask(bit_off, fsize);
			tms34010_pkg_io_field_merge = (current & ~m) | ((wdata << bit_off) & m);
		end
	endfunction
	assign wr_merged = (PREDECODED_WRITE ? (io_reg[wr_idx] & ~low_write_mask) | low_write_data : tms34010_pkg_io_field_merge(io_reg[wr_idx], wdata[15:0], addr[3:0], size));
	wire timing_start_req;
	localparam [4:0] tms34010_pkg_IO_IDX_HTOTAL = 5'h03;
	assign timing_start_req = (((((!rst && req) && we) && wr_is_io) && (wr_idx == tms34010_pkg_IO_IDX_HTOTAL)) && (io_reg[tms34010_pkg_IO_IDX_HTOTAL] == 16'd0)) && (wr_merged != 16'd0);
	always @(posedge clk)
		if (rst)
			timing_start_o <= 1'b0;
		else
			timing_start_o <= timing_start_req;
	wire dpyint_pulse;
	wire dpyint_event;
	(* preserve *) reg dpyint_event_q;
	(* preserve *) reg wvp_set_q;
	(* preserve *) reg nmi_clear_q;
	wire [15:0] vid_hcount;
	wire [15:0] vid_vcount;
	wire vid_hs_unused;
	wire vid_vs_unused;
	wire vid_hb_unused;
	wire vid_vb_unused;
	wire vid_bl_unused;
	localparam [4:0] tms34010_pkg_IO_IDX_DPYINT = 5'h0a;
	localparam [4:0] tms34010_pkg_IO_IDX_HEBLNK = 5'h01;
	localparam [4:0] tms34010_pkg_IO_IDX_HESYNC = 5'h00;
	localparam [4:0] tms34010_pkg_IO_IDX_HSBLNK = 5'h02;
	localparam [4:0] tms34010_pkg_IO_IDX_VEBLNK = 5'h05;
	localparam [4:0] tms34010_pkg_IO_IDX_VESYNC = 5'h04;
	localparam [4:0] tms34010_pkg_IO_IDX_VSBLNK = 5'h06;
	localparam [4:0] tms34010_pkg_IO_IDX_VTOTAL = 5'h07;
	tms34010_video u_video(
		.clk(clk),
		.rst(rst),
		.timing_start(timing_start_o),
		.ce(ce_pix),
		.hesync(io_reg[tms34010_pkg_IO_IDX_HESYNC]),
		.heblnk(io_reg[tms34010_pkg_IO_IDX_HEBLNK]),
		.hsblnk(io_reg[tms34010_pkg_IO_IDX_HSBLNK]),
		.htotal(io_reg[tms34010_pkg_IO_IDX_HTOTAL]),
		.vesync(io_reg[tms34010_pkg_IO_IDX_VESYNC]),
		.veblnk(io_reg[tms34010_pkg_IO_IDX_VEBLNK]),
		.vsblnk(io_reg[tms34010_pkg_IO_IDX_VSBLNK]),
		.vtotal(io_reg[tms34010_pkg_IO_IDX_VTOTAL]),
		.dpyint(io_reg[tms34010_pkg_IO_IDX_DPYINT]),
		.hcount(vid_hcount),
		.vcount(vid_vcount),
		.hsync(vid_hs_unused),
		.vsync(vid_vs_unused),
		.hblank(vid_hb_unused),
		.vblank(vid_vb_unused),
		.blank(vid_bl_unused),
		.dpyint_pulse(dpyint_pulse),
		.line_wrap_o(line_wrap_o)
	);
	localparam [4:0] tms34010_pkg_IO_IDX_DPYCTL = 5'h08;
	assign dpyint_event = (dpyint_pulse && (io_reg[tms34010_pkg_IO_IDX_VTOTAL] != 16'h0000)) && io_reg[tms34010_pkg_IO_IDX_DPYCTL][15];
	wire lint1_lvl;
	assign lint1_lvl = lint1_in === 1'b1;
	wire dpyadr_live_valid;
	assign dpyadr_live_valid = dpyadr_live_valid_i === 1'b1;
	localparam [31:0] tms34010_pkg_INT_X1_BIT = 1;
	localparam [4:0] tms34010_pkg_IO_IDX_DPYADR = 5'h1e;
	localparam [4:0] tms34010_pkg_IO_IDX_HCOUNT = 5'h1c;
	localparam [4:0] tms34010_pkg_IO_IDX_INTPEND = 5'h12;
	localparam [4:0] tms34010_pkg_IO_IDX_VCOUNT = 5'h1d;
	function automatic [4:0] sv2v_cast_7548C;
		input reg [4:0] inp;
		sv2v_cast_7548C = inp;
	endfunction
	assign rdata = (!is_io ? 16'h0000 : (rd_idx == sv2v_cast_7548C(5'h1d) ? vid_vcount : (rd_idx == sv2v_cast_7548C(5'h1c) ? vid_hcount : ((rd_idx == sv2v_cast_7548C(5'h1e)) && dpyadr_live_valid ? dpyadr_live_i : (rd_idx == sv2v_cast_7548C(5'h12) ? io_reg[rd_idx] | (sv2v_cast_16(lint1_lvl) << tms34010_pkg_INT_X1_BIT) : io_reg[rd_idx])))));
	localparam [4:0] tms34010_pkg_IO_IDX_PSIZE = 5'h15;
	assign psize_o = io_reg[tms34010_pkg_IO_IDX_PSIZE];
	localparam [4:0] tms34010_pkg_IO_IDX_CONVDP = 5'h14;
	assign convdp_o = io_reg[tms34010_pkg_IO_IDX_CONVDP];
	localparam [4:0] tms34010_pkg_IO_IDX_CONVSP = 5'h13;
	assign convsp_o = io_reg[tms34010_pkg_IO_IDX_CONVSP];
	localparam [4:0] tms34010_pkg_IO_IDX_CONTROL = 5'h0b;
	assign control_o = io_reg[tms34010_pkg_IO_IDX_CONTROL];
	localparam [4:0] tms34010_pkg_IO_IDX_PMASK = 5'h16;
	assign pmask_o = io_reg[tms34010_pkg_IO_IDX_PMASK];
	assign dpyctl_o = io_reg[tms34010_pkg_IO_IDX_DPYCTL];
	localparam [4:0] tms34010_pkg_IO_IDX_INTENB = 5'h11;
	assign intenb_o = io_reg[tms34010_pkg_IO_IDX_INTENB];
	assign intpend_o = io_reg[tms34010_pkg_IO_IDX_INTPEND] | (sv2v_cast_16(lint1_lvl) << tms34010_pkg_INT_X1_BIT);
	localparam [4:0] tms34010_pkg_IO_IDX_HSTCTLH = 5'h10;
	assign hstctlh_o = io_reg[tms34010_pkg_IO_IDX_HSTCTLH];
	localparam [31:0] tms34010_pkg_HSTCTL_NMI_BIT = 8;
	localparam [31:0] tms34010_pkg_INT_DI_BIT = 10;
	localparam [31:0] tms34010_pkg_INT_WV_BIT = 11;
	localparam [15:0] tms34010_pkg_INTPEND_W0C_MASK = (16'h0001 << tms34010_pkg_INT_DI_BIT) | (16'h0001 << tms34010_pkg_INT_WV_BIT);
	function automatic [15:0] tms34010_pkg_intpend_apply_cpu_write;
		input reg [15:0] current;
		input reg [15:0] wdata;
		tms34010_pkg_intpend_apply_cpu_write = current & (wdata | ~tms34010_pkg_INTPEND_W0C_MASK);
	endfunction
	always @(posedge clk)
		if (rst) begin
			begin : sv2v_autoblock_1
				reg signed [31:0] i;
				for (i = 0; i < tms34010_pkg_IO_REG_COUNT; i = i + 1)
					io_reg[i] <= 16'h0000;
			end
			dpyint_event_q <= 1'b0;
			wvp_set_q <= 1'b0;
			nmi_clear_q <= 1'b0;
		end
		else begin
			dpyint_event_q <= dpyint_event;
			wvp_set_q <= wvp_set === 1'b1;
			nmi_clear_q <= nmi_clear === 1'b1;
			if ((req && we) && wr_is_io) begin
				if (wr_idx == tms34010_pkg_IO_IDX_INTPEND)
					io_reg[wr_idx] <= tms34010_pkg_intpend_apply_cpu_write(io_reg[wr_idx], wr_merged);
				else
					io_reg[wr_idx] <= wr_merged;
				if (wr_span2) begin
					if (wr_idx_hi == tms34010_pkg_IO_IDX_INTPEND)
						io_reg[wr_idx_hi] <= tms34010_pkg_intpend_apply_cpu_write(io_reg[wr_idx_hi], wdata[31:16]);
					else
						io_reg[wr_idx_hi] <= wdata[31:16];
				end
			end
			if (((req && we) && wr_is_io) && (status_guard === 1'b1)) begin
				if (wr_idx == tms34010_pkg_IO_IDX_INTPEND) begin
					if (wvp_set_q)
						io_reg[tms34010_pkg_IO_IDX_INTPEND][tms34010_pkg_INT_WV_BIT] <= 1'b1;
					if (dpyint_event_q)
						io_reg[tms34010_pkg_IO_IDX_INTPEND][tms34010_pkg_INT_DI_BIT] <= 1'b1;
				end
				if ((wr_idx == tms34010_pkg_IO_IDX_HSTCTLH) && nmi_clear_q)
					io_reg[tms34010_pkg_IO_IDX_HSTCTLH][tms34010_pkg_HSTCTL_NMI_BIT] <= 1'b0;
			end
			if (nmi_clear === 1'b1)
				io_reg[tms34010_pkg_IO_IDX_HSTCTLH][tms34010_pkg_HSTCTL_NMI_BIT] <= 1'b0;
			if (wvp_set === 1'b1)
				io_reg[tms34010_pkg_IO_IDX_INTPEND][tms34010_pkg_INT_WV_BIT] <= 1'b1;
			if (dpyint_event)
				io_reg[tms34010_pkg_IO_IDX_INTPEND][tms34010_pkg_INT_DI_BIT] <= 1'b1;
		end
endmodule
`default_nettype wire
`default_nettype none
module tms34010_io_write_boundary (
	clk,
	rst,
	ce_cpu,
	req,
	we,
	is_io,
	ack,
	addr,
	wdata,
	size,
	wr_valid,
	wr_addr,
	wr_data,
	wr_size,
	wr_idx,
	wr_idx_hi,
	wr_span2,
	wr_low_mask,
	wr_low_data,
	wr_status_guard
);
	input wire clk;
	input wire rst;
	input wire ce_cpu;
	input wire req;
	input wire we;
	input wire is_io;
	input wire ack;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	input wire [31:0] addr;
	input wire [31:0] wdata;
	input wire [5:0] size;
	output reg wr_valid;
	output reg [31:0] wr_addr;
	output reg [31:0] wr_data;
	output reg [5:0] wr_size;
	localparam [31:0] tms34010_pkg_IO_REG_IDX_W = 5;
	(* preserve *) output reg [4:0] wr_idx;
	(* preserve *) output reg [4:0] wr_idx_hi;
	(* preserve *) output reg wr_span2;
	(* preserve *) output reg [15:0] wr_low_mask;
	(* preserve *) output reg [15:0] wr_low_data;
	(* preserve *) output reg wr_status_guard;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	function automatic signed [5:0] sv2v_cast_13C0F_signed;
		input reg signed [5:0] inp;
		sv2v_cast_13C0F_signed = inp;
	endfunction
	function automatic [15:0] sv2v_cast_16;
		input reg [15:0] inp;
		sv2v_cast_16 = inp;
	endfunction
	function automatic [15:0] tms34010_pkg_io_field_mask;
		input reg [3:0] bit_off;
		input reg [5:0] fsize;
		reg [31:0] base;
		begin
			base = (fsize >= sv2v_cast_13C0F_signed(16) ? 32'h0000ffff : (32'd1 << fsize) - 32'd1);
			tms34010_pkg_io_field_mask = sv2v_cast_16((base << bit_off) & 32'h0000ffff);
		end
	endfunction
	wire [15:0] low_mask = tms34010_pkg_io_field_mask(addr[3:0], size);
	wire [15:0] low_data = (wdata[15:0] << addr[3:0]) & low_mask;
	wire span2 = size > sv2v_cast_13C0F_signed(16);
	always @(posedge clk)
		if (rst) begin
			wr_valid <= 1'b0;
			wr_addr <= 1'sb0;
			wr_data <= 1'sb0;
			wr_size <= 1'sb0;
			wr_idx <= 1'sb0;
			wr_idx_hi <= 1'sb0;
			wr_span2 <= 1'b0;
			wr_low_mask <= 1'sb0;
			wr_low_data <= 1'sb0;
			wr_status_guard <= 1'b0;
		end
		else begin
			wr_valid <= 1'b0;
			wr_status_guard <= 1'b0;
			if (((((ce_cpu !== 1'b0) && req) && we) && is_io) && ack) begin
				wr_valid <= 1'b1;
				wr_addr <= addr;
				wr_data <= wdata;
				wr_size <= size;
				wr_idx <= addr[8:4];
				wr_idx_hi <= addr[8:4] + 1'b1;
				wr_span2 <= span2;
				wr_low_mask <= low_mask;
				wr_low_data <= low_data;
				wr_status_guard <= 1'b1;
			end
		end
endmodule
`default_nettype wire
`default_nettype none
module tms34010_refresh (
	clk,
	rst,
	rr,
	refresh_row,
	refresh_req
);
	input wire clk;
	input wire rst;
	input wire [1:0] rr;
	output wire [7:0] refresh_row;
	output wire refresh_req;
	wire enabled;
	wire [6:0] interval;
	assign enabled = (rr == 2'b00) || (rr == 2'b01);
	assign interval = (rr == 2'b01 ? 7'd63 : 7'd31);
	reg [6:0] presc_q;
	reg [7:0] refresh_row_q;
	assign refresh_req = enabled && (presc_q == interval);
	assign refresh_row = refresh_row_q;
	always @(posedge clk)
		if (rst) begin
			presc_q <= 7'd0;
			refresh_row_q <= 8'd0;
		end
		else if (enabled) begin
			if (presc_q == interval) begin
				presc_q <= 7'd0;
				refresh_row_q <= refresh_row_q + 8'd1;
			end
			else
				presc_q <= presc_q + 7'd1;
		end
endmodule
`default_nettype wire
`default_nettype none
module tms34010_video (
	clk,
	rst,
	timing_start,
	ce,
	hesync,
	heblnk,
	hsblnk,
	htotal,
	vesync,
	veblnk,
	vsblnk,
	vtotal,
	dpyint,
	hcount,
	vcount,
	hsync,
	vsync,
	hblank,
	vblank,
	blank,
	dpyint_pulse,
	line_wrap_o
);
	input wire clk;
	input wire rst;
	input wire timing_start;
	input wire ce;
	input wire [15:0] hesync;
	input wire [15:0] heblnk;
	input wire [15:0] hsblnk;
	input wire [15:0] htotal;
	input wire [15:0] vesync;
	input wire [15:0] veblnk;
	input wire [15:0] vsblnk;
	input wire [15:0] vtotal;
	input wire [15:0] dpyint;
	output reg [15:0] hcount;
	output reg [15:0] vcount;
	output wire hsync;
	output wire vsync;
	output wire hblank;
	output wire vblank;
	output wire blank;
	output wire dpyint_pulse;
	output wire line_wrap_o;
	wire hwrap;
	assign hwrap = hcount == htotal;
	wire ce_eff;
	assign ce_eff = (ce === 1'b0 ? 1'b0 : 1'b1);
	wire timing_start_eff;
	assign timing_start_eff = timing_start === 1'b1;
	assign line_wrap_o = (((!rst && !timing_start_eff) && (htotal != 16'd0)) && ce_eff) && hwrap;
	always @(posedge clk)
		if (rst || timing_start_eff) begin
			hcount <= 16'd0;
			vcount <= 16'd0;
		end
		else if (ce_eff) begin
			if (hwrap) begin
				hcount <= 16'd0;
				if (vcount == vtotal)
					vcount <= 16'd0;
				else
					vcount <= vcount + 16'd1;
			end
			else
				hcount <= hcount + 16'd1;
		end
	assign hsync = hcount <= hesync;
	assign vsync = vcount <= vesync;
	assign hblank = (hcount < heblnk) || (hcount >= hsblnk);
	assign vblank = (vcount < veblnk) || (vcount >= vsblnk);
	assign blank = hblank || vblank;
	wire dpyint_arrival;
	wire [15:0] dpyint_arrival_vcount;
	assign dpyint_arrival = (hsblnk == 16'd0 ? hwrap : hcount == (hsblnk - 16'd1));
	assign dpyint_arrival_vcount = ((hsblnk == 16'd0) && hwrap ? (vcount == vtotal ? 16'd0 : vcount + 16'd1) : vcount);
	assign dpyint_pulse = (ce_eff && dpyint_arrival) && (dpyint_arrival_vcount == dpyint);
endmodule
`default_nettype wire
`default_nettype none
module yunit_protection (
	clk,
	rst,
	game_id,
	wr,
	wdata,
	strike_word,
	result
);
	input wire clk;
	input wire rst;
	input wire [3:0] game_id;
	input wire wr;
	input wire [15:0] wdata;
	input wire [15:0] strike_word;
	output reg [15:0] result;
	reg [15:0] seq0;
	reg [15:0] seq1;
	reg [15:0] seq2;
	reg [4:0] index;
	localparam [3:0] yunit_pkg_YG_HIIMPACT = 4'd2;
	localparam [3:0] yunit_pkg_YG_MK = 4'd5;
	localparam [3:0] yunit_pkg_YG_SAURNFRNT = 4'd9;
	localparam [3:0] yunit_pkg_YG_SHIMPACT = 4'd3;
	localparam [3:0] yunit_pkg_YG_STRKFORC = 4'd4;
	localparam [3:0] yunit_pkg_YG_TERM2 = 4'd6;
	localparam [3:0] yunit_pkg_YG_TOTCARN = 4'd7;
	localparam [3:0] yunit_pkg_YG_TROG = 4'd1;
	localparam [3:0] yunit_pkg_YG_YUNITTST = 4'd8;
	function automatic [15:0] reset_word;
		input reg [3:0] game;
		input reg [1:0] n;
		begin
			reset_word = 16'h0000;
			case (game)
				yunit_pkg_YG_TROG: reset_word = 16'h0f00;
				yunit_pkg_YG_HIIMPACT: reset_word = 16'h0b00;
				yunit_pkg_YG_SHIMPACT, yunit_pkg_YG_YUNITTST:
					case (n)
						0: reset_word = 16'h0f00;
						1: reset_word = 16'h0e00;
						default: reset_word = 16'h0d00;
					endcase
				yunit_pkg_YG_STRKFORC, yunit_pkg_YG_SAURNFRNT: reset_word = (n == 0 ? 16'h1234 : 16'h0000);
				yunit_pkg_YG_MK:
					case (n)
						0: reset_word = 16'h0d00;
						1: reset_word = 16'h0c00;
						default: reset_word = 16'h0900;
					endcase
				yunit_pkg_YG_TERM2, yunit_pkg_YG_TOTCARN: reset_word = 16'h0f00;
				default: reset_word = 16'h0000;
			endcase
		end
	endfunction
	function automatic [15:0] data_word;
		input reg [3:0] game;
		input reg [4:0] n;
		begin
			data_word = 16'h0000;
			case (game)
				yunit_pkg_YG_TROG:
					case (n)
						0: data_word = 16'h3000;
						1: data_word = 16'h1000;
						2: data_word = 16'h2000;
						3: data_word = 16'h0000;
						4: data_word = 16'h2000;
						5: data_word = 16'h3000;
						6: data_word = 16'h3000;
						7: data_word = 16'h1000;
						8: data_word = 16'h0000;
						9: data_word = 16'h0000;
						10: data_word = 16'h2000;
						11: data_word = 16'h3000;
						12: data_word = 16'h1000;
						13: data_word = 16'h1000;
						default: data_word = 16'h2000;
					endcase
				yunit_pkg_YG_HIIMPACT:
					case (n)
						0: data_word = 16'h2000;
						1: data_word = 16'h4000;
						2: data_word = 16'h4000;
						3: data_word = 16'h0000;
						4: data_word = 16'h6000;
						5: data_word = 16'h6000;
						6: data_word = 16'h2000;
						7: data_word = 16'h4000;
						8: data_word = 16'h2000;
						9: data_word = 16'h4000;
						10: data_word = 16'h2000;
						11: data_word = 16'h0000;
						12: data_word = 16'h4000;
						13: data_word = 16'h6000;
						default: data_word = 16'h2000;
					endcase
				yunit_pkg_YG_SHIMPACT, yunit_pkg_YG_YUNITTST:
					case (n)
						0: data_word = 16'h0000;
						1: data_word = 16'h4000;
						2: data_word = 16'h2000;
						3: data_word = 16'h5000;
						4: data_word = 16'h2000;
						5: data_word = 16'h1000;
						6: data_word = 16'h4000;
						7: data_word = 16'h6000;
						8: data_word = 16'h3000;
						9: data_word = 16'h0000;
						10: data_word = 16'h2000;
						11: data_word = 16'h5000;
						12: data_word = 16'h5000;
						13: data_word = 16'h5000;
						default: data_word = 16'h2000;
					endcase
				yunit_pkg_YG_MK:
					case (n)
						0: data_word = 16'h4600;
						1: data_word = 16'hf600;
						2: data_word = 16'ha600;
						3: data_word = 16'h0600;
						4: data_word = 16'h2600;
						5: data_word = 16'h9600;
						6: data_word = 16'hc600;
						7: data_word = 16'he600;
						8: data_word = 16'h8600;
						9: data_word = 16'h7600;
						10: data_word = 16'h8600;
						11: data_word = 16'h8600;
						12: data_word = 16'h9600;
						13: data_word = 16'hd600;
						14: data_word = 16'h6600;
						15: data_word = 16'hb600;
						16: data_word = 16'hd600;
						17: data_word = 16'he600;
						18: data_word = 16'hf600;
						19: data_word = 16'h7600;
						20: data_word = 16'hb600;
						21: data_word = 16'ha600;
						default: data_word = 16'h3600;
					endcase
				yunit_pkg_YG_TERM2:
					case (n)
						0: data_word = 16'h4000;
						1: data_word = 16'hf000;
						default: data_word = 16'ha000;
					endcase
				yunit_pkg_YG_TOTCARN:
					case (n)
						0: data_word = 16'h4a00;
						1: data_word = 16'h6a00;
						2: data_word = 16'hda00;
						3: data_word = 16'h6a00;
						4: data_word = 16'h9a00;
						5: data_word = 16'h4a00;
						6: data_word = 16'h2a00;
						7: data_word = 16'h9a00;
						8: data_word = 16'h1a00;
						9: data_word = 16'h8a00;
						default: data_word = 16'haa00;
					endcase
				default: data_word = 16'h0000;
			endcase
		end
	endfunction
	wire [15:0] masked = wdata & 16'h0f00;
	wire reset_match = ((seq1 == reset_word(game_id, 0)) && (seq2 == reset_word(game_id, 1))) && (masked == reset_word(game_id, 2));
	wire clock_edge = seq2[11] && !masked[11];
	function automatic yunit_pkg_yunit_has_protection;
		input reg [3:0] game;
		case (game)
			yunit_pkg_YG_TROG, yunit_pkg_YG_HIIMPACT, yunit_pkg_YG_SHIMPACT, yunit_pkg_YG_STRKFORC, yunit_pkg_YG_MK, yunit_pkg_YG_TERM2, yunit_pkg_YG_TOTCARN, yunit_pkg_YG_YUNITTST, yunit_pkg_YG_SAURNFRNT: yunit_pkg_yunit_has_protection = 1'b1;
			default: yunit_pkg_yunit_has_protection = 1'b0;
		endcase
	endfunction
	always @(posedge clk)
		if (rst) begin
			seq0 <= 16'h0000;
			seq1 <= 16'h0000;
			seq2 <= 16'h0000;
			index <= 5'd0;
			result <= 16'h0000;
		end
		else if (wr && yunit_pkg_yunit_has_protection(game_id)) begin
			seq0 <= seq1;
			seq1 <= seq2;
			seq2 <= masked;
			if ((game_id == yunit_pkg_YG_STRKFORC) || (game_id == yunit_pkg_YG_SAURNFRNT)) begin
				if (masked == 16'h0500)
					result <= strike_word << 4;
			end
			else begin
				if (reset_match)
					index <= 5'd0;
				if (clock_edge) begin
					result <= data_word(game_id, (reset_match ? 5'd0 : index));
					index <= (reset_match ? 5'd0 : index) + 5'd1;
				end
			end
		end
endmodule
`default_nettype wire
`default_nettype none
module yunit_nvram_bridge (
	clk,
	rst_pon,
	ioctl_download,
	ioctl_upload,
	ioctl_wr,
	ioctl_index,
	ioctl_addr,
	ioctl_dout,
	ioctl_din,
	ioctl_upload_req,
	autosave,
	manual_save,
	clear_nvram,
	osd_status,
	cpu_write_pulse,
	cmos_cpu_busy,
	cmos_quiesce,
	nvram_ext_en,
	nvram_ext_wr,
	nvram_ext_addr,
	nvram_ext_wdata,
	nvram_ext_rdata,
	nvram_loading,
	nvram_dirty
);
	parameter integer NVRAM_BYTES = 32768;
	input wire clk;
	input wire rst_pon;
	input wire ioctl_download;
	input wire ioctl_upload;
	input wire ioctl_wr;
	input wire [7:0] ioctl_index;
	input wire [24:0] ioctl_addr;
	input wire [7:0] ioctl_dout;
	output wire [7:0] ioctl_din;
	output wire ioctl_upload_req;
	input wire autosave;
	input wire manual_save;
	input wire clear_nvram;
	input wire osd_status;
	input wire cpu_write_pulse;
	input wire cmos_cpu_busy;
	output wire cmos_quiesce;
	output wire nvram_ext_en;
	output wire nvram_ext_wr;
	output wire [14:0] nvram_ext_addr;
	output wire [7:0] nvram_ext_wdata;
	input wire [7:0] nvram_ext_rdata;
	output wire nvram_loading;
	output reg nvram_dirty;
	reg clearing;
	reg [14:0] clear_addr;
	reg old_clear;
	reg old_manual;
	reg old_osd;
	reg save_pending;
	localparam signed [31:0] SAVE_WATCHDOG_W = 25;
	localparam [24:0] SAVE_WATCHDOG_MAX = 1'sb1;
	reg [24:0] save_watchdog;
	wire nvram_download = ioctl_download && (ioctl_index == 8'd4);
	wire nvram_upload = ioctl_upload && (ioctl_index == 8'd4);
	wire nvram_addr_valid = ioctl_addr < NVRAM_BYTES;
	assign nvram_loading = nvram_download || clearing;
	assign cmos_quiesce = (save_pending || nvram_upload) || nvram_loading;
	assign ioctl_upload_req = (save_pending && !cmos_cpu_busy) && !nvram_loading;
	assign nvram_ext_en = nvram_loading || nvram_upload;
	assign nvram_ext_wr = clearing || ((nvram_download && ioctl_wr) && nvram_addr_valid);
	assign nvram_ext_addr = (clearing ? clear_addr : ioctl_addr[14:0]);
	assign nvram_ext_wdata = (clearing ? 8'h00 : ioctl_dout);
	assign ioctl_din = ((ioctl_index == 8'd4) && nvram_addr_valid ? nvram_ext_rdata : 8'h00);
	always @(posedge clk)
		if (rst_pon) begin
			clearing <= 1'b0;
			clear_addr <= 15'd0;
			old_clear <= 1'b0;
			old_manual <= 1'b0;
			old_osd <= 1'b0;
			save_pending <= 1'b0;
			save_watchdog <= 1'sb0;
			nvram_dirty <= 1'b0;
		end
		else begin
			old_clear <= clear_nvram;
			old_manual <= manual_save;
			old_osd <= osd_status;
			if (cpu_write_pulse)
				nvram_dirty <= 1'b1;
			if ((((clear_nvram && !old_clear) && !clearing) && !nvram_download) && !nvram_upload) begin
				clearing <= 1'b1;
				clear_addr <= 15'd0;
			end
			else if (clearing) begin
				if (clear_addr == (NVRAM_BYTES - 1)) begin
					clearing <= 1'b0;
					nvram_dirty <= 1'b1;
					save_pending <= 1'b1;
					save_watchdog <= 1'sb0;
				end
				else
					clear_addr <= clear_addr + 1'b1;
			end
			if ((manual_save && !old_manual) || (((autosave && nvram_dirty) && osd_status) && !old_osd)) begin
				save_pending <= 1'b1;
				save_watchdog <= 1'sb0;
			end
			if ((save_pending && !nvram_upload) && !nvram_loading) begin
				if (save_watchdog == SAVE_WATCHDOG_MAX)
					save_pending <= 1'b0;
				else
					save_watchdog <= save_watchdog + 1'b1;
			end
			if (nvram_upload) begin
				save_pending <= 1'b0;
				nvram_dirty <= 1'b0;
			end
			if ((nvram_download && ioctl_wr) && nvram_addr_valid) begin
				save_pending <= 1'b0;
				nvram_dirty <= 1'b0;
			end
		end
endmodule
`default_nettype wire
`default_nettype none
module yunit_mem (
	clk,
	rst,
	mem_req,
	mem_we,
	mem_addr,
	mem_size,
	mem_wdata,
	mem_rdata,
	mem_ack,
	fb_we,
	fb_addr,
	fb_wdata,
	dma_palette,
	inputs,
	game_id,
	game_gfx_bytes,
	term2_adc,
	term2_adc_sel,
	snd_select,
	snd_trig,
	snd_reset,
	dbg_p1ctrl,
	dbg_bdir,
	cmos_quiesce,
	nvram_ext_en,
	nvram_ext_wr,
	nvram_ext_addr,
	nvram_ext_wdata,
	nvram_ext_rdata,
	cmos_cpu_busy,
	cmos_cpu_write_pulse,
	autoerase_enable,
	erase_start,
	erase_row0,
	erase_lines,
	erase_busy,
	erase_line_valid,
	erase_line_row,
	gfx_rd,
	gfx_raddr,
	gfx_rdata,
	gfx_rack,
	fb_ack,
	fb_busy,
	fb_flush,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	sdram_por,
	ddram_addr,
	ddram_burstcnt,
	ddram_rd,
	ddram_we,
	ddram_din,
	ddram_be,
	ddram_busy,
	ddram_dout,
	ddram_dout_ready,
	palv_we_a,
	palv_aa,
	palv_awd,
	palv_we_b,
	palv_ba,
	palv_bwd
);
	reg _sv2v_0;
	parameter signed [31:0] ROM_WORDS = 32'h00020000;
	parameter signed [31:0] RAM_WORDS = 32'h00010000;
	parameter signed [31:0] VRAM_WORDS = 32'h00040000;
	parameter signed [31:0] PAL_WORDS = 32'h00002000;
	parameter signed [31:0] CMOS_WORDS = 32'h00004000;
	parameter signed [31:0] GFX_PIXELS = 32'h00180000;
	parameter signed [31:0] ROM_WORD_OFFSET = 32'h00060000;
	parameter ROM_HEX = "smashtv_maindata.hex";
	parameter GFX_HEX = "build/smashtv_gfx.hex";
	input wire clk;
	input wire rst;
	input wire mem_req;
	input wire mem_we;
	input wire [31:0] mem_addr;
	input wire [5:0] mem_size;
	input wire [31:0] mem_wdata;
	output reg [31:0] mem_rdata;
	output reg mem_ack;
	input wire fb_we;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	input wire [17:0] fb_addr;
	input wire [15:0] fb_wdata;
	input wire [15:0] dma_palette;
	input wire [63:0] inputs;
	input wire [3:0] game_id;
	input wire [23:0] game_gfx_bytes;
	input wire [7:0] term2_adc;
	output reg [1:0] term2_adc_sel;
	output reg [7:0] snd_select;
	output reg snd_trig;
	output reg snd_reset;
	output reg [31:0] dbg_p1ctrl;
	output reg [31:0] dbg_bdir;
	input wire cmos_quiesce;
	input wire nvram_ext_en;
	input wire nvram_ext_wr;
	input wire [14:0] nvram_ext_addr;
	input wire [7:0] nvram_ext_wdata;
	output wire [7:0] nvram_ext_rdata;
	output wire cmos_cpu_busy;
	output reg cmos_cpu_write_pulse;
	output wire autoerase_enable;
	input wire erase_start;
	input wire [8:0] erase_row0;
	input wire [9:0] erase_lines;
	output wire erase_busy;
	input wire erase_line_valid;
	input wire [8:0] erase_line_row;
	output reg gfx_rd;
	output wire [23:0] gfx_raddr;
	input wire [15:0] gfx_rdata;
	input wire gfx_rack;
	output wire fb_ack;
	output wire fb_busy;
	input wire fb_flush;
	input wire scan_req;
	input wire [17:0] scan_addr;
	output wire [15:0] scan_data;
	output wire scan_ack;
	input wire sdram_por;
	output wire [28:0] ddram_addr;
	output wire [7:0] ddram_burstcnt;
	output wire ddram_rd;
	output wire ddram_we;
	output wire [63:0] ddram_din;
	output wire [7:0] ddram_be;
	input wire ddram_busy;
	input wire [63:0] ddram_dout;
	input wire ddram_dout_ready;
	output reg palv_we_a;
	output reg [12:0] palv_aa;
	output reg [15:0] palv_awd;
	output reg palv_we_b;
	output reg [12:0] palv_ba;
	output reg [15:0] palv_bwd;
	localparam [3:0] R_NONE = 4'd0;
	localparam [3:0] R_VRAM = 4'd1;
	localparam [3:0] R_RAM = 4'd2;
	localparam [3:0] R_CMOS = 4'd3;
	localparam [3:0] R_PAL = 4'd4;
	localparam [3:0] R_DMA = 4'd5;
	localparam [3:0] R_INPUT = 4'd6;
	localparam [3:0] R_PROT = 4'd7;
	localparam [3:0] R_SOUND = 4'd8;
	localparam [3:0] R_CTRL = 4'd9;
	localparam [3:0] R_GFX = 4'd10;
	localparam [3:0] R_ROM = 4'd11;
	localparam [31:0] yunit_pkg_YMAP_RAM_BASE = 32'h01000000;
	function automatic [27:0] sv2v_cast_28;
		input reg [27:0] inp;
		sv2v_cast_28 = inp;
	endfunction
	localparam [27:0] WB_RAM = sv2v_cast_28(yunit_pkg_YMAP_RAM_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_MAINDATA_BASE = 32'hff800000;
	localparam [27:0] WB_ROM = sv2v_cast_28(yunit_pkg_YMAP_MAINDATA_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_VRAM_BASE = 32'h00000000;
	localparam [27:0] WB_VRAM = sv2v_cast_28(yunit_pkg_YMAP_VRAM_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_PAL_BASE = 32'h01800000;
	localparam [27:0] WB_PAL = sv2v_cast_28(yunit_pkg_YMAP_PAL_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_CMOS_BASE = 32'h01400000;
	localparam [27:0] WB_CMOS = sv2v_cast_28(yunit_pkg_YMAP_CMOS_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_INPUT_BASE = 32'h01c00000;
	localparam [27:0] WB_INPUT = sv2v_cast_28(yunit_pkg_YMAP_INPUT_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_GFX_BASE = 32'h02000000;
	localparam [27:0] WB_GFX = sv2v_cast_28(yunit_pkg_YMAP_GFX_BASE >> 4);
	localparam [27:0] ROM_PROG_OFF = ROM_WORD_OFFSET[27:0];
	localparam [3:0] yunit_pkg_YG_SMASHTV = 4'd0;
	wire [3:0] game = (^game_id === 1'bx ? yunit_pkg_YG_SMASHTV : game_id);
	localparam [3:0] yunit_pkg_YG_SAURNFRNT = 4'd9;
	localparam [3:0] yunit_pkg_YG_STRKFORC = 4'd4;
	localparam [3:0] yunit_pkg_YG_TROG = 4'd1;
	function automatic yunit_pkg_yunit_is_4bpp;
		input reg [3:0] game;
		yunit_pkg_yunit_is_4bpp = ((game == yunit_pkg_YG_TROG) || (game == yunit_pkg_YG_STRKFORC)) || (game == yunit_pkg_YG_SAURNFRNT);
	endfunction
	wire game_bpp4 = yunit_pkg_yunit_is_4bpp(game);
	function automatic signed [23:0] sv2v_cast_24_signed;
		input reg signed [23:0] inp;
		sv2v_cast_24_signed = inp;
	endfunction
	wire [23:0] gfx_valid_bytes = (^game_gfx_bytes === 1'bx ? sv2v_cast_24_signed(GFX_PIXELS) : game_gfx_bytes);
	(* ramstyle = "no_rw_check" *) reg [15:0] ram [0:RAM_WORDS - 1];
	(* ramstyle = "no_rw_check" *) reg [15:0] pal [0:PAL_WORDS - 1];
	reg videobank = 1'b0;
	reg [1:0] cmos_page = 2'd0;
	reg autoerase = 1'b0;
	assign autoerase_enable = autoerase;
	reg [15:0] strike_shadow;
	wire [15:0] prot_result;
	reg er_run = 1'b0;
	wire [8:0] er_row;
	wire [8:0] er_x;
	wire [9:0] er_left;
	(* ramstyle = "no_rw_check" *) reg [15:0] nvram [0:CMOS_WORDS - 1];
	localparam [3:0] M_IDLE = 4'd0;
	localparam [3:0] M_ACK = 4'd1;
	localparam [3:0] M_GFX = 4'd2;
	localparam [3:0] M_HR1 = 4'd3;
	localparam [3:0] M_HR2 = 4'd4;
	localparam [3:0] M_HFIN = 4'd5;
	localparam [3:0] M_HW2 = 4'd6;
	localparam [3:0] M_VRD = 4'd7;
	localparam [3:0] M_VWR0 = 4'd8;
	localparam [3:0] M_VWR1 = 4'd9;
	localparam [3:0] M_VWW0 = 4'd10;
	localparam [3:0] M_VWW1 = 4'd11;
	localparam [3:0] M_VSD = 4'd12;
	localparam [3:0] M_HFIN2 = 4'd13;
	localparam [3:0] M_RDLY = 4'd14;
	localparam [3:0] M_SBH = 4'd15;
	localparam [4:0] M_EXD = 5'd16;
	localparam [4:0] M_CR0 = 5'd17;
	localparam [4:0] M_CR1 = 5'd18;
	localparam [4:0] M_CR2 = 5'd19;
	localparam [4:0] M_CR3 = 5'd20;
	localparam [4:0] M_CFIN = 5'd21;
	localparam [4:0] M_CW1 = 5'd22;
	localparam [4:0] M_CW2 = 5'd23;
	reg [4:0] state;
	wire cmos_quiesce_on = cmos_quiesce === 1'b1;
	wire nvram_ext_en_on = nvram_ext_en === 1'b1;
	wire nvram_ext_wr_on = nvram_ext_en_on && (nvram_ext_wr === 1'b1);
	wire cmos_req_now = (mem_addr[31:20] == 12'h014) && (mem_addr[19:16] == 4'h0);
	localparam [23:0] SDRAM_ROMB = sv2v_cast_24_signed(GFX_PIXELS);
	reg [23:0] gfx_base;
	reg [1:0] gfx_cnt;
	reg [1:0] gfx_need;
	reg gfx_isrom;
	reg [15:0] gw0;
	reg [15:0] gw1;
	reg [23:0] gfx_raddr_q;
	reg [3:0] boff_r;
	reg [47:0] rmask_r;
	localparam signed [31:0] SB_N = 8;
	reg [15:0] sb_q [0:7];
	reg [22:0] sb_base;
	reg [3:0] sb_fill;
	reg sb_vld;
	reg pf_run;
	reg pf_busy;
	reg [31:0] a_q;
	reg we_q;
	reg [31:0] wd_q;
	reg [5:0] sz_q;
	wire cmos_req_q = (a_q[31:20] == 12'h014) && (a_q[19:16] == 4'h0);
	assign cmos_cpu_busy = (!rst && (state != M_IDLE)) && cmos_req_q;
	wire [27:0] widx = a_q[31:4];
	wire [3:0] boff = a_q[3:0];
	wire [5:0] sz = sz_q;
	reg [3:0] region;
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		casez (a_q[31:20])
			12'h000, 12'h001: region = R_VRAM;
			12'h010: region = R_RAM;
			12'h014: region = (a_q[19:16] == 4'h0 ? R_CMOS : R_NONE);
			12'h018: region = R_PAL;
			12'h01a: region = ((a_q[18:8] == 11'h000) && (a_q[7:4] <= 4'd9) ? R_DMA : R_NONE);
			12'h01c: region = (a_q[7:4] >= 4'd6 ? R_PROT : R_INPUT);
			12'h01e: region = R_SOUND;
			12'h01f: region = R_CTRL;
			12'h020, 12'h021, 12'h022, 12'h023, 12'h024, 12'h025, 12'h026, 12'h027, 12'h028, 12'h029, 12'h02a, 12'h02b, 12'h02c, 12'h02d, 12'h02e, 12'h02f, 12'h030, 12'h031, 12'h032, 12'h033, 12'h034, 12'h035, 12'h036, 12'h037, 12'h038, 12'h039, 12'h03a, 12'h03b, 12'h03c, 12'h03d, 12'h03e, 12'h03f, 12'h040, 12'h041, 12'h042, 12'h043, 12'h044, 12'h045, 12'h046, 12'h047, 12'h048, 12'h049, 12'h04a, 12'h04b, 12'h04c, 12'h04d, 12'h04e, 12'h04f, 12'h050, 12'h051, 12'h052, 12'h053, 12'h054, 12'h055, 12'h056, 12'h057, 12'h058, 12'h059, 12'h05a, 12'h05b, 12'h05c, 12'h05d, 12'h05e, 12'h05f: region = R_GFX;
			12'hff8, 12'hff9, 12'hffa, 12'hffb, 12'hffc, 12'hffd, 12'hffe, 12'hfff: region = R_ROM;
			default: region = R_NONE;
		endcase
	end
	wire is_hwvram = region == R_VRAM;
	localparam [27:0] ROMW = ROM_WORDS[27:0];
	localparam [27:0] RAMW = RAM_WORDS[27:0];
	localparam [27:0] VRAMW = VRAM_WORDS[27:0];
	localparam [27:0] PALW = PAL_WORDS[27:0];
	localparam [27:0] CMOS_PAGEW = 28'h0001000;
	localparam [27:0] GFXPIXW = GFX_PIXELS[27:0];
	localparam [3:0] yunit_pkg_YG_TERM2 = 4'd6;
	function automatic [15:0] read_word;
		input reg [3:0] rgn;
		input reg [27:0] gw;
		reg [27:0] rel;
		begin
			read_word = 16'h0000;
			if (rgn == R_ROM)
				;
			else if (rgn == R_RAM)
				;
			else if (rgn == R_VRAM)
				;
			else if (rgn == R_PAL)
				;
			else if (rgn == R_CMOS)
				;
			else if (rgn == R_INPUT) begin
				rel = gw - WB_INPUT;
				case (rel[1:0])
					2'd0: read_word = inputs[15:0];
					2'd1: read_word = inputs[31:16];
					2'd2: read_word = (game == yunit_pkg_YG_TERM2 ? {8'hff, term2_adc} : inputs[47:32]);
					2'd3: read_word = inputs[63:48];
					default: read_word = 16'hffff;
				endcase
				if (rel > 28'd3)
					read_word = 16'hffff;
			end
			else if (rgn == R_PROT)
				read_word = prot_result;
			else if (rgn == R_GFX)
				rel = gw - WB_GFX;
		end
	endfunction
	function automatic [47:0] dup4_window;
		input reg [47:0] w;
		integer n;
		for (n = 0; n < 6; n = n + 1)
			dup4_window[n * 8+:8] = {2 {w[n * 8+:4]}};
	endfunction
	wire [47:0] rmask = (48'd1 << sz) - 48'd1;
	wire [47:0] smask = rmask << boff;
	wire [5:0] lastb = (boff + sz) - 6'd1;
	assign gfx_raddr = gfx_raddr_q;
	always @(posedge clk) begin
		boff_r <= boff;
		rmask_r <= rmask;
	end
	reg ext_fetch;
	reg ext_isrom;
	reg [23:0] ext_base;
	reg [27:0] rom_rel;
	function automatic [23:0] sv2v_cast_24;
		input reg [23:0] inp;
		sv2v_cast_24 = inp;
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		ext_fetch = 1'b0;
		ext_isrom = 1'b0;
		ext_base = 24'd0;
		rom_rel = widx - WB_ROM;
		if (((region == R_GFX) && !we_q) && (sv2v_cast_24((widx - WB_GFX) << 1) < gfx_valid_bytes)) begin
			ext_fetch = 1'b1;
			ext_base = sv2v_cast_24((widx - WB_GFX) << 1);
		end
		if ((((region == R_ROM) && !we_q) && (rom_rel >= ROM_PROG_OFF)) && ((rom_rel - ROM_PROG_OFF) < ROMW)) begin
			ext_fetch = 1'b1;
			ext_isrom = 1'b1;
			ext_base = SDRAM_ROMB + sv2v_cast_24((rom_rel - ROM_PROG_OFF) << 1);
		end
	end
	wire [1:0] extnw = 2'd1 + lastb[5:4];
	wire [22:0] ext_waddr = ext_base[23:1];
	reg [23:0] exd_base;
	reg [22:0] exd_waddr;
	reg exd_isrom;
	reg [1:0] exd_need;
	reg win_isgfx_q;
	wire [22:0] exd_off = exd_waddr - sb_base;
	wire exd_hit = ((sb_vld && exd_isrom) && (exd_off < 23'd8)) && (({1'b0, exd_off[2:0]} + {2'b00, exd_need}) <= sb_fill);
	wire [15:0] exd_w0 = sb_q[exd_off[2:0]];
	wire [15:0] exd_w1 = sb_q[exd_off[2:0] + 3'd1];
	wire [15:0] exd_w2 = sb_q[exd_off[2:0] + 3'd2];
	function automatic [22:0] sv2v_cast_23;
		input reg [22:0] inp;
		sv2v_cast_23 = inp;
	endfunction
	localparam [22:0] SB_ROM_WEND = sv2v_cast_23((SDRAM_ROMB >> 1) + ROM_WORDS);
	wire pf_inrange = (sb_base + {19'd0, sb_fill}) < SB_ROM_WEND;
	reg is_hwram;
	reg [1:0] hsel;
	reg [17:0] hidx [0:2];
	reg hval [0:2];
	reg [27:0] hr;
	always @(*) begin
		if (_sv2v_0)
			;
		is_hwram = 1'b0;
		hsel = 2'd0;
		hr = 28'd0;
		begin : sv2v_autoblock_1
			reg signed [31:0] j;
			for (j = 0; j < 3; j = j + 1)
				begin
					hidx[j] = 18'd0;
					hval[j] = 1'b0;
				end
		end
		if (region == R_RAM) begin
			is_hwram = 1'b1;
			hsel = 2'd0;
			begin : sv2v_autoblock_2
				reg signed [31:0] j;
				for (j = 0; j < 3; j = j + 1)
					begin
						hr = (widx + j[27:0]) - WB_RAM;
						hidx[j] = hr[17:0];
						hval[j] = hr < RAMW;
					end
			end
		end
		else if (region == R_PAL) begin
			is_hwram = 1'b1;
			hsel = 2'd1;
			begin : sv2v_autoblock_3
				reg signed [31:0] j;
				for (j = 0; j < 3; j = j + 1)
					begin
						hr = (widx + j[27:0]) - WB_PAL;
						hidx[j] = hr[17:0];
						hval[j] = hr < PALW;
					end
			end
		end
		else if (region == R_CMOS) begin
			is_hwram = 1'b1;
			hsel = 2'd2;
			begin : sv2v_autoblock_4
				reg signed [31:0] j;
				for (j = 0; j < 3; j = j + 1)
					begin
						hr = (widx + j[27:0]) - WB_CMOS;
						hidx[j] = {4'd0, cmos_page, hr[11:0]};
						hval[j] = hr < CMOS_PAGEW;
					end
			end
		end
	end
	reg [15:0] rd0;
	reg [15:0] rd1;
	reg [15:0] rd2;
	wire [47:0] hwin = {(hval[2] ? rd2 : 16'h0000), (hval[1] ? rd1 : 16'h0000), (hval[0] ? rd0 : 16'h0000)};
	wire [47:0] hmerged = (hwin & ~smask) | (({16'h0000, wd_q} << boff) & smask);
	reg [47:0] smask_q;
	reg [47:0] rmask_q;
	reg [47:0] wsh_q;
	reg [47:0] hwin_q;
	reg [3:0] boff_q;
	reg [2:0] cval_q;
	always @(posedge clk) begin
		smask_q <= smask;
		rmask_q <= rmask;
		boff_q <= boff;
		wsh_q <= {16'h0000, wd_q} << boff;
		hwin_q <= hwin;
		if ((state == M_ACK) && (hsel == 2'd2))
			cval_q <= {hval[2], hval[1], hval[0]};
	end
	wire [47:0] hmerged2 = (hwin_q & ~smask_q) | (wsh_q & smask_q);
	reg [17:0] eng_aa;
	reg [17:0] eng_ba;
	reg eng_awe;
	reg eng_bwe;
	reg [15:0] eng_awd;
	reg [15:0] eng_bwd;
	reg [15:0] eng_aq;
	reg [15:0] eng_bq;
	always @(*) begin
		if (_sv2v_0)
			;
		eng_aa = hidx[0];
		eng_ba = hidx[1];
		eng_awe = 1'b0;
		eng_bwe = 1'b0;
		eng_awd = hmerged2[15:0];
		eng_bwd = hmerged2[31:16];
		case (state)
			M_HR1: eng_aa = hidx[2];
			M_HFIN2:
				if (we_q) begin
					eng_aa = hidx[0];
					eng_awe = hval[0];
					eng_ba = hidx[1];
					eng_bwe = (lastb >= 6'd16) & hval[1];
				end
			M_HW2: begin
				eng_aa = hidx[2];
				eng_awe = (lastb >= 6'd32) & hval[2];
				eng_awd = hmerged2[47:32];
			end
			default:
				;
		endcase
	end
	reg [16:0] ram_aa;
	reg [16:0] ram_ba;
	reg ram_awe;
	reg ram_bwe;
	reg [15:0] ram_awd;
	reg [15:0] ram_bwd;
	reg [15:0] ram_aq;
	reg [15:0] ram_bq;
	reg [12:0] pal_aa;
	reg [12:0] pal_ba;
	reg pal_awe;
	reg pal_bwe;
	reg [15:0] pal_awd;
	reg [15:0] pal_bwd;
	reg [15:0] pal_aq;
	reg [15:0] pal_bq;
	always @(*) begin
		if (_sv2v_0)
			;
		ram_aa = eng_aa[16:0];
		ram_ba = eng_ba[16:0];
		ram_awd = eng_awd;
		ram_bwd = eng_bwd;
		pal_aa = eng_aa[12:0];
		pal_ba = eng_ba[12:0];
		pal_awd = eng_awd;
		pal_bwd = eng_bwd;
		ram_awe = (hsel == 2'd0) & eng_awe;
		ram_bwe = (hsel == 2'd0) & eng_bwe;
		pal_awe = (hsel == 2'd1) & eng_awe;
		pal_bwe = (hsel == 2'd1) & eng_bwe;
		eng_aq = (hsel == 2'd0 ? ram_aq : (hsel == 2'd1 ? pal_aq : 16'd0));
		eng_bq = (hsel == 2'd0 ? ram_bq : (hsel == 2'd1 ? pal_bq : 16'd0));
	end
	always @(posedge clk) begin
		if (ram_awe)
			ram[ram_aa] <= ram_awd;
		ram_aq <= ram[ram_aa];
	end
	always @(posedge clk) begin
		if (ram_bwe)
			ram[ram_ba] <= ram_bwd;
		ram_bq <= ram[ram_ba];
	end
	always @(posedge clk)
		if (rst) begin
			dbg_p1ctrl <= 32'd0;
			dbg_bdir <= 32'd0;
		end
		else begin
			if (ram_awe && (ram_aa == 'h865b))
				dbg_p1ctrl <= {ram_awd, dbg_p1ctrl[15:0] + 16'd1};
			if (ram_bwe && (ram_ba == 'h865b))
				dbg_p1ctrl <= {ram_bwd, dbg_p1ctrl[15:0] + 16'd1};
			if (ram_awe && (ram_aa == 'hde48))
				dbg_bdir <= {ram_awd, dbg_bdir[15:0] + 16'd1};
			if (ram_bwe && (ram_ba == 'hde48))
				dbg_bdir <= {ram_bwd, dbg_bdir[15:0] + 16'd1};
		end
	always @(posedge clk) begin
		if (pal_awe)
			pal[pal_aa] <= pal_awd;
		pal_aq <= pal[pal_aa];
	end
	always @(posedge clk) begin
		if (pal_bwe)
			pal[pal_ba] <= pal_bwd;
		pal_bq <= pal[pal_ba];
	end
	reg [13:0] nv_ext_word_addr;
	reg [15:0] nv_ext_q;
	reg nv_ext_lane_q;
	reg [13:0] nv_cpu_addr;
	reg [15:0] nv_cpu_wdata;
	reg [15:0] nv_cpu_q;
	reg nv_cpu_we;
	reg [15:0] c_rd0;
	reg [15:0] c_rd1;
	reg [15:0] c_rd2;
	reg [31:0] cmos_rdata_q;
	wire [47:0] cwin = {(cval_q[2] ? c_rd2 : 16'd0), (cval_q[1] ? c_rd1 : 16'd0), (cval_q[0] ? c_rd0 : 16'd0)};
	wire [47:0] cwin_last = {(cval_q[2] ? nv_cpu_q : 16'd0), (cval_q[1] ? c_rd1 : 16'd0), (cval_q[0] ? c_rd0 : 16'd0)};
	function automatic [31:0] sv2v_cast_32;
		input reg [31:0] inp;
		sv2v_cast_32 = inp;
	endfunction
	wire [31:0] cmos_rdata_next = sv2v_cast_32((cwin_last >> boff_q) & rmask_q);
	wire [47:0] cmerged = (cwin & ~smask_q) | (wsh_q & smask_q);
	always @(*) begin
		if (_sv2v_0)
			;
		nv_ext_word_addr = (nvram_ext_en_on ? nvram_ext_addr[14:1] : 14'd0);
		nv_cpu_addr = hidx[0][13:0];
		nv_cpu_wdata = cmerged[15:0];
		nv_cpu_we = 1'b0;
		case (state)
			M_CR1: nv_cpu_addr = hidx[1][13:0];
			M_CR2: nv_cpu_addr = hidx[2][13:0];
			M_CFIN: begin
				nv_cpu_addr = hidx[0][13:0];
				nv_cpu_wdata = cmerged[15:0];
				nv_cpu_we = ((we_q && hval[0]) && !nvram_ext_en_on) && !rst;
			end
			M_CW1: begin
				nv_cpu_addr = hidx[1][13:0];
				nv_cpu_wdata = cmerged[31:16];
				nv_cpu_we = (hval[1] && !nvram_ext_en_on) && !rst;
			end
			M_CW2: begin
				nv_cpu_addr = hidx[2][13:0];
				nv_cpu_wdata = cmerged[47:32];
				nv_cpu_we = (hval[2] && !nvram_ext_en_on) && !rst;
			end
			default:
				;
		endcase
	end
	reg [13:0] nv_ext_fwd_addr;
	reg [15:0] nv_ext_fwd_word;
	reg nv_ext_fwd_v;
	wire [15:0] nv_ext_base = (nv_ext_fwd_v && (nv_ext_fwd_addr == nv_ext_word_addr) ? nv_ext_fwd_word : nv_ext_q);
	wire [15:0] nv_ext_merged = (nvram_ext_addr[0] ? {nvram_ext_wdata, nv_ext_base[7:0]} : {nv_ext_base[15:8], nvram_ext_wdata});
	always @(posedge clk) begin
		if (nv_cpu_we)
			nvram[nv_cpu_addr] <= nv_cpu_wdata;
		nv_cpu_q <= nvram[nv_cpu_addr];
	end
	always @(posedge clk) begin
		if (nvram_ext_wr_on)
			nvram[nv_ext_word_addr] <= nv_ext_merged;
		nv_ext_q <= nvram[nv_ext_word_addr];
		nv_ext_lane_q <= (nvram_ext_en_on ? nvram_ext_addr[0] : 1'b0);
	end
	always @(posedge clk)
		if (nvram_ext_wr_on) begin
			nv_ext_fwd_addr <= nv_ext_word_addr;
			nv_ext_fwd_word <= nv_ext_merged;
			nv_ext_fwd_v <= 1'b1;
		end
		else if (rst && !nvram_ext_en_on)
			nv_ext_fwd_v <= 1'b0;
	assign nvram_ext_rdata = (nvram_ext_en_on ? (nv_ext_lane_q ? nv_ext_q[15:8] : nv_ext_q[7:0]) : 8'h00);
	always @(posedge clk) begin
		palv_we_a <= pal_awe;
		palv_aa <= (game_bpp4 ? {5'b00000, pal_aa[7:0]} : {1'b0, pal_aa[11:0]});
		palv_awd <= pal_awd;
		palv_we_b <= pal_bwe;
		palv_ba <= (game_bpp4 ? {5'b00000, pal_ba[7:0]} : {1'b0, pal_ba[11:0]});
		palv_bwd <= pal_bwd;
	end
	reg vsd_req;
	wire vsd_done;
	wire [31:0] vsd_rdata;
	stv_vram_ddr_top #(
		.VRAMW(VRAM_WORDS),
		.VRAM_DDR_BASE(29'h06400000)
	) u_vram_sdram(
		.clk(clk),
		.rst(rst),
		.sdram_por(sdram_por),
		.req(vsd_req),
		.we(we_q),
		.widx(widx),
		.boff(boff),
		.sz(sz_q),
		.wd(wd_q),
		.videobank(videobank),
		.dma_palette(dma_palette),
		.rdata(vsd_rdata),
		.done(vsd_done),
		.fb_we(fb_we),
		.fb_addr(fb_addr),
		.fb_wdata(fb_wdata),
		.fb_ack(fb_ack),
		.fb_busy(fb_busy),
		.fb_flush(fb_flush),
		.erase_en(autoerase),
		.erase_busy(erase_busy),
		.erase_line_valid(erase_line_valid),
		.erase_line_row(erase_line_row),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack),
		.ddram_addr(ddram_addr),
		.ddram_burstcnt(ddram_burstcnt),
		.ddram_rd(ddram_rd),
		.ddram_we(ddram_we),
		.ddram_din(ddram_din),
		.ddram_be(ddram_be),
		.ddram_busy(ddram_busy),
		.ddram_dout(ddram_dout),
		.ddram_dout_ready(ddram_dout_ready)
	);
	reg [47:0] win_s;
	reg [47:0] merged_s;
	reg [47:0] win_s_q;
	wire [27:0] wrel;
	wire prot_wr = ((state == M_ACK) && we_q) && (region == R_PROT);
	yunit_protection u_protection(
		.clk(clk),
		.rst(rst),
		.game_id(game),
		.wr(prot_wr),
		.wdata(wd_q[15:0]),
		.strike_word(strike_shadow),
		.result(prot_result)
	);
	always @(posedge clk)
		if (rst) begin
			state <= M_IDLE;
			mem_ack <= 1'b0;
			mem_rdata <= 32'h00000000;
			snd_select <= 8'h00;
			snd_trig <= 1'b0;
			snd_reset <= 1'b1;
			cmos_cpu_write_pulse <= 1'b0;
			term2_adc_sel <= 2'd0;
			strike_shadow <= 16'h0000;
			er_run <= 1'b0;
			gfx_rd <= 1'b0;
			sb_vld <= 1'b0;
			sb_fill <= 4'd0;
			sb_base <= 23'd0;
			pf_run <= 1'b0;
			pf_busy <= 1'b0;
			vsd_req <= 1'b0;
		end
		else begin
			cmos_cpu_write_pulse <= 1'b0;
			if (pf_busy && gfx_rack) begin
				pf_busy <= 1'b0;
				gfx_rd <= 1'b0;
				if ((pf_run && sb_vld) && (sb_fill < SB_N)) begin
					sb_q[sb_fill[2:0]] <= gfx_rdata;
					sb_fill <= sb_fill + 4'd1;
				end
			end
			else if (((((((((pf_run && sb_vld) && !pf_busy) && !gfx_rd) && (sb_fill < SB_N)) && pf_inrange) && (state != M_GFX)) && (state != M_SBH)) && (state != M_EXD)) && !((state == M_ACK) && ext_fetch)) begin
				gfx_raddr_q <= {sb_base + {19'd0, sb_fill}, 1'b0};
				gfx_rd <= 1'b1;
				pf_busy <= 1'b1;
			end
			(* full_case, parallel_case *)
			case (state)
				M_IDLE: begin
					mem_ack <= 1'b0;
					if ((mem_req && !mem_ack) && !(cmos_req_now && (cmos_quiesce_on || nvram_ext_en_on))) begin
						a_q <= mem_addr;
						we_q <= mem_we;
						wd_q <= mem_wdata;
						sz_q <= mem_size;
						if (mem_we && (mem_addr[31:4] == (WB_RAM + 28'h000a439)))
							strike_shadow <= mem_wdata[15:0];
						if (mem_we && &mem_addr[31:23]) begin
							sb_vld <= 1'b0;
							pf_run <= 1'b0;
						end
						state <= M_ACK;
					end
				end
				M_ACK:
					if (ext_fetch) begin
						mem_ack <= 1'b0;
						exd_base <= ext_base;
						exd_waddr <= ext_waddr;
						exd_isrom <= ext_isrom;
						exd_need <= extnw;
						state <= M_EXD;
					end
					else if (is_hwram) begin
						mem_ack <= 1'b0;
						state <= (hsel == 2'd2 ? M_CR0 : M_HR1);
					end
					else if (is_hwvram) begin
						mem_ack <= 1'b0;
						vsd_req <= 1'b1;
						state <= M_VSD;
					end
					else begin
						win_s = {read_word(region, widx + 28'd2), read_word(region, widx + 28'd1), read_word(region, widx)};
						merged_s = (win_s & ~smask) | (({16'h0000, wd_q} << boff) & smask);
						if (we_q) begin
							(* full_case, parallel_case *)
							case (region)
								default:
									;
							endcase
							if (region == R_CTRL) begin
								videobank <= wd_q[5];
								cmos_page <= wd_q[7:6];
								autoerase <= ~wd_q[4];
							end
							if (region == R_SOUND) begin
								snd_select <= wd_q[7:0];
								snd_trig <= wd_q[9];
								snd_reset <= ~wd_q[8];
								if (game == yunit_pkg_YG_TERM2)
									term2_adc_sel <= wd_q[13:12];
							end
							mem_ack <= 1'b1;
							state <= M_IDLE;
						end
						else begin
							win_s_q <= win_s;
							mem_ack <= 1'b0;
							state <= M_RDLY;
						end
					end
				M_EXD:
					if (exd_hit) begin
						win_s_q <= {exd_w2, exd_w1, exd_w0};
						win_isgfx_q <= 1'b0;
						state <= M_SBH;
					end
					else if (pf_busy)
						;
					else begin
						gfx_base <= exd_base;
						gfx_cnt <= 2'd0;
						gfx_need <= exd_need;
						gfx_isrom <= exd_isrom;
						if (exd_isrom) begin
							sb_vld <= 1'b0;
							sb_base <= exd_waddr;
							sb_fill <= 4'd0;
							pf_run <= 1'b0;
						end
						gfx_raddr_q <= exd_base;
						gfx_rd <= 1'b1;
						state <= M_GFX;
					end
				M_GFX:
					if (gfx_rack) begin
						gfx_rd <= 1'b0;
						if (gfx_isrom)
							sb_q[{1'b0, gfx_cnt}] <= gfx_rdata;
						if (gfx_cnt == 2'd0)
							gw0 <= gfx_rdata;
						if (gfx_cnt == 2'd1)
							gw1 <= gfx_rdata;
						if (({1'b0, gfx_cnt} + 3'd1) >= {1'b0, gfx_need}) begin
							win_s_q <= (gfx_need == 2'd1 ? {32'h00000000, gfx_rdata} : (gfx_need == 2'd2 ? {16'h0000, gfx_rdata, gw0} : {gfx_rdata, gw1, gw0}));
							win_isgfx_q <= !gfx_isrom;
							if (gfx_isrom) begin
								sb_fill <= {2'b00, gfx_cnt} + 4'd1;
								sb_vld <= 1'b1;
								pf_run <= 1'b1;
							end
							state <= M_SBH;
						end
						else
							gfx_cnt <= gfx_cnt + 2'd1;
					end
					else if (!gfx_rd) begin
						gfx_raddr_q <= gfx_base + {21'd0, gfx_cnt, 1'b0};
						gfx_rd <= 1'b1;
					end
				M_SBH: begin
					mem_rdata <= sv2v_cast_32(((game_bpp4 && win_isgfx_q ? dup4_window(win_s_q) : win_s_q) >> boff_r) & rmask_r);
					mem_ack <= 1'b1;
					state <= M_IDLE;
				end
				M_HR1: begin
					rd0 <= eng_aq;
					rd1 <= eng_bq;
					state <= M_HR2;
				end
				M_HR2: begin
					rd2 <= eng_aq;
					state <= M_HFIN;
				end
				M_HFIN: state <= M_HFIN2;
				M_HFIN2:
					if (we_q) begin
						if ((lastb >= 6'd32) && hval[2])
							state <= M_HW2;
						else begin
							mem_ack <= 1'b1;
							state <= M_IDLE;
						end
					end
					else begin
						mem_rdata <= sv2v_cast_32((hwin_q >> boff_q) & rmask_q);
						mem_ack <= 1'b1;
						state <= M_IDLE;
					end
				M_HW2: begin
					mem_ack <= 1'b1;
					state <= M_IDLE;
				end
				M_CR0: begin
					mem_ack <= 1'b0;
					state <= (nvram_ext_en_on ? M_CR0 : M_CR1);
				end
				M_CR1: begin
					mem_ack <= 1'b0;
					if (nvram_ext_en_on)
						state <= M_CR0;
					else begin
						c_rd0 <= nv_cpu_q;
						state <= M_CR2;
					end
				end
				M_CR2: begin
					mem_ack <= 1'b0;
					if (nvram_ext_en_on)
						state <= M_CR0;
					else begin
						c_rd1 <= nv_cpu_q;
						state <= M_CR3;
					end
				end
				M_CR3: begin
					mem_ack <= 1'b0;
					if (nvram_ext_en_on)
						state <= M_CR0;
					else begin
						c_rd2 <= nv_cpu_q;
						if (!we_q)
							cmos_rdata_q <= cmos_rdata_next;
						state <= M_CFIN;
					end
				end
				M_CFIN: begin
					mem_ack <= 1'b0;
					if (nvram_ext_en_on)
						state <= M_CR0;
					else if (we_q) begin
						if ((lastb >= 6'd16) && hval[1])
							state <= M_CW1;
						else begin
							cmos_cpu_write_pulse <= 1'b1;
							mem_ack <= 1'b1;
							state <= M_IDLE;
						end
					end
					else begin
						mem_rdata <= cmos_rdata_q;
						mem_ack <= 1'b1;
						state <= M_IDLE;
					end
				end
				M_CW1: begin
					mem_ack <= 1'b0;
					if (nvram_ext_en_on)
						state <= M_CR0;
					else if ((lastb >= 6'd32) && hval[2])
						state <= M_CW2;
					else begin
						cmos_cpu_write_pulse <= 1'b1;
						mem_ack <= 1'b1;
						state <= M_IDLE;
					end
				end
				M_CW2: begin
					mem_ack <= 1'b0;
					if (nvram_ext_en_on)
						state <= M_CR0;
					else begin
						cmos_cpu_write_pulse <= 1'b1;
						mem_ack <= 1'b1;
						state <= M_IDLE;
					end
				end
				M_RDLY: begin
					mem_rdata <= sv2v_cast_32((win_s_q >> boff_q) & rmask_q);
					mem_ack <= 1'b1;
					state <= M_IDLE;
				end
				M_VSD: begin
					vsd_req <= 1'b0;
					if (vsd_done) begin
						mem_rdata <= vsd_rdata;
						mem_ack <= 1'b1;
						state <= M_IDLE;
					end
				end
				default: begin
					state <= M_IDLE;
					mem_ack <= 1'b0;
				end
			endcase
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_dma (
	clk,
	rst,
	reg_we,
	reg_addr,
	reg_wdata,
	reg_rdata,
	src_req,
	src_addr,
	src_data,
	src_ack,
	fb_we,
	fb_addr,
	fb_wdata,
	fb_ack,
	fb_busy,
	fb_flush,
	busy,
	trigger_blocked,
	blit_irq,
	dma_palette
);
	reg _sv2v_0;
	parameter [0:0] RENDER_ONLY = 1'b0;
	input wire clk;
	input wire rst;
	input wire reg_we;
	input wire [3:0] reg_addr;
	input wire [15:0] reg_wdata;
	output wire [15:0] reg_rdata;
	output wire src_req;
	output wire [23:0] src_addr;
	input wire [7:0] src_data;
	input wire src_ack;
	output reg fb_we;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	output reg [17:0] fb_addr;
	output reg [15:0] fb_wdata;
	input wire fb_ack;
	input wire fb_busy;
	output wire fb_flush;
	output wire busy;
	output wire trigger_blocked;
	output reg blit_irq;
	output wire [15:0] dma_palette;
	localparam signed [31:0] yunit_pkg_DMA_NREGS = 16;
	reg [15:0] regf [0:15];
	reg [15:0] launchf [0:15];
	reg [15:0] pendf [0:15];
	reg busy_r;
	reg abort_r;
	reg pend_trig;
	reg [25:0] pace_cnt;
	reg pace_arm;
	localparam [3:0] yunit_pkg_DMA_COMMAND = 4'd0;
	wire [15:0] cmd_reg = regf[yunit_pkg_DMA_COMMAND];
	wire [15:0] launch_cmd = launchf[yunit_pkg_DMA_COMMAND];
	localparam signed [31:0] yunit_pkg_DMA_CMD_FLIPX_BIT = 4;
	wire flipx_w = launch_cmd[yunit_pkg_DMA_CMD_FLIPX_BIT];
	wire [3:0] mode_w = launch_cmd[3:0];
	localparam [3:0] yunit_pkg_DMA_PALETTE = 4'd8;
	wire [7:0] pal_lo = launchf[yunit_pkg_DMA_PALETTE][7:0];
	localparam [3:0] yunit_pkg_DMA_COLOR = 4'd9;
	wire [7:0] col_lo = launchf[yunit_pkg_DMA_COLOR][7:0];
	localparam signed [31:0] yunit_pkg_DMA_CMD_TRIG_BIT = 15;
	wire wdata_trig = reg_wdata[yunit_pkg_DMA_CMD_TRIG_BIT];
	assign busy = busy_r;
	assign dma_palette = regf[yunit_pkg_DMA_PALETTE];
	assign reg_rdata = (reg_addr == yunit_pkg_DMA_COMMAND ? {busy_r, cmd_reg[14:0]} : regf[reg_addr]);
	reg [2:0] state;
	reg [2:0] state_n;
	wire trigger_write = (reg_we && (reg_addr == yunit_pkg_DMA_COMMAND)) && wdata_trig;
	wire direct_accept = (trigger_write && (state == 3'd0)) && (RENDER_ONLY || !pend_trig);
	wire pending_accept = ((!RENDER_ONLY && trigger_write) && (state != 3'd0)) && !pend_trig;
	assign trigger_blocked = (RENDER_ONLY ? 1'b0 : pend_trig);
	reg [3:0] mode_c;
	reg flipx_c;
	reg readmode_c;
	reg signed [11:0] width_c;
	reg signed [11:0] height_c;
	reg signed [11:0] xpos_c;
	reg signed [11:0] ypos_c;
	reg signed [31:0] rowbytes_c;
	reg [15:0] pal16_c;
	reg [15:0] color16_c;
	reg signed [11:0] row_i;
	reg signed [11:0] col_i;
	reg signed [11:0] tx;
	reg [8:0] ty;
	reg signed [31:0] cur_off;
	reg signed [31:0] o_ptr;
	reg [7:0] px;
	reg signed [31:0] rb_in;
	reg signed [31:0] xs_in;
	reg signed [31:0] ys_in;
	reg [15:0] w_in;
	reg [15:0] h_in;
	reg [31:0] gfxoff0;
	reg [31:0] gfxoff1;
	reg [31:0] gfxoff2;
	reg signed [31:0] rb_adj;
	reg signed [31:0] xpos0;
	reg signed [31:0] ypos1;
	reg signed [31:0] height1a;
	reg signed [31:0] height1;
	reg signed [31:0] xpos_f;
	reg signed [31:0] width_f;
	reg signed [31:0] offbytes_c;
	localparam [3:0] yunit_pkg_DMA_HEIGHT = 4'd7;
	localparam [3:0] yunit_pkg_DMA_OFFSETHI = 4'd3;
	localparam [3:0] yunit_pkg_DMA_OFFSETLO = 4'd2;
	localparam [3:0] yunit_pkg_DMA_ROWBYTES = 4'd1;
	localparam [3:0] yunit_pkg_DMA_WIDTH = 4'd6;
	localparam [3:0] yunit_pkg_DMA_XSTART = 4'd4;
	localparam [3:0] yunit_pkg_DMA_YSTART = 4'd5;
	always @(*) begin
		if (_sv2v_0)
			;
		rb_in = $signed(launchf[yunit_pkg_DMA_ROWBYTES]);
		xs_in = $signed(launchf[yunit_pkg_DMA_XSTART]);
		ys_in = $signed(launchf[yunit_pkg_DMA_YSTART]);
		w_in = launchf[yunit_pkg_DMA_WIDTH];
		h_in = launchf[yunit_pkg_DMA_HEIGHT];
		gfxoff0 = {launchf[yunit_pkg_DMA_OFFSETHI], launchf[yunit_pkg_DMA_OFFSETLO]};
		rb_adj = (flipx_w ? ((rb_in - $signed({16'd0, w_in})) + 32'sd3) & ~32'sd3 : ((rb_in + $signed({16'd0, w_in})) + 32'sd3) & ~32'sd3);
		xpos0 = (flipx_w ? (xs_in + $signed({16'd0, w_in})) - 32'sd1 : xs_in);
		gfxoff1 = (flipx_w ? gfxoff0 - (({16'd0, w_in} - 32'd1) << 3) : gfxoff0);
		ypos1 = (ys_in < 0 ? 32'sd0 : ys_in);
		height1a = (ys_in < 0 ? $signed({16'd0, h_in}) + ys_in : $signed({16'd0, h_in}));
		height1 = ((ypos1 + height1a) > 32'sd512 ? 32'sd512 - ypos1 : height1a);
		if (!flipx_w) begin
			if (xpos0 < 0) begin
				width_f = $signed({16'd0, w_in}) + xpos0;
				xpos_f = 32'sd0;
			end
			else begin
				width_f = $signed({16'd0, w_in});
				xpos_f = xpos0;
			end
			if ((xpos_f + width_f) > 32'sd512)
				width_f = 32'sd512 - xpos_f;
		end
		else begin
			if (xpos0 >= 32'sd512) begin
				width_f = $signed({16'd0, w_in}) - (xpos0 - 32'sd511);
				xpos_f = 32'sd511;
			end
			else begin
				width_f = $signed({16'd0, w_in});
				xpos_f = xpos0;
			end
			if ((xpos_f - width_f) < 0)
				width_f = xpos_f;
		end
		gfxoff2 = (gfxoff1 < 32'h02000000 ? gfxoff1 + 32'h02000000 : gfxoff1);
		offbytes_c = ($signed(gfxoff2) - 32'sh02000000) >>> 3;
	end
	wire [11:0] width12 = width_f[11:0];
	wire [11:0] height12 = height1[11:0];
	wire [11:0] xpos12 = xpos_f[11:0];
	wire [11:0] ypos12 = ypos1[11:0];
	wire readmode_w = (mode_w >= 4'h1) && (mode_w <= 4'hb);
	reg pix_we;
	reg [15:0] pix_data;
	always @(*) begin
		if (_sv2v_0)
			;
		pix_we = 1'b0;
		pix_data = 16'h0000;
		(* full_case, parallel_case *)
		case (mode_c)
			4'h0:
				;
			4'h1: begin
				pix_we = px == 8'd0;
				pix_data = pal16_c;
			end
			4'h2: begin
				pix_we = px != 8'd0;
				pix_data = pal16_c | {8'd0, px};
			end
			4'h3: begin
				pix_we = 1'b1;
				pix_data = pal16_c | {8'd0, px};
			end
			4'h4, 4'h5: begin
				pix_we = px == 8'd0;
				pix_data = color16_c;
			end
			4'h6, 4'h7: begin
				pix_we = 1'b1;
				pix_data = (px == 8'd0 ? color16_c : pal16_c | {8'd0, px});
			end
			4'h8, 4'ha: begin
				pix_we = px != 8'd0;
				pix_data = color16_c;
			end
			4'h9, 4'hb: begin
				pix_we = 1'b1;
				pix_data = (px != 8'd0 ? color16_c : pal16_c | {8'd0, px});
			end
			default: begin
				pix_we = 1'b1;
				pix_data = color16_c;
			end
		endcase
	end
	wire row_overrun = ($unsigned(cur_off) >= 32'h06000000) && (mode_c < 4'hc);
	wire [8:0] tx9 = tx[8:0];
	wire [8:0] ty_next = ypos_c[8:0] + row_i[8:0];
	wire dma_done_ok = (RENDER_ONLY ? 1'b1 : pace_cnt == 26'd0);
	always @(*) begin
		if (_sv2v_0)
			;
		state_n = state;
		(* full_case, parallel_case *)
		case (state)
			3'd0:
				if (pend_trig)
					state_n = 3'd1;
				else if (direct_accept)
					state_n = 3'd1;
			3'd1: state_n = 3'd2;
			3'd2:
				if ((height1 <= 0) || (width_f <= 0))
					state_n = 3'd6;
				else
					state_n = 3'd3;
			3'd3:
				if (row_i >= height_c)
					state_n = 3'd6;
				else if (row_overrun)
					state_n = 3'd3;
				else
					state_n = 3'd4;
			3'd4:
				if (!readmode_c)
					state_n = 3'd5;
				else if (src_ack)
					state_n = 3'd5;
			3'd5:
				if (pix_we && !fb_ack)
					state_n = 3'd5;
				else if (col_i >= (width_c - 12'sd1))
					state_n = 3'd3;
				else
					state_n = 3'd4;
			3'd6:
				if (dma_done_ok)
					state_n = 3'd0;
			default: state_n = 3'd0;
		endcase
	end
	assign src_req = (state == 3'd4) && readmode_c;
	assign src_addr = o_ptr[23:0];
	assign fb_flush = state == 3'd6;
	integer i;
	always @(posedge clk)
		if (rst) begin
			state <= 3'd0;
			fb_we <= 1'b0;
			blit_irq <= 1'b0;
			busy_r <= 1'b0;
			pace_cnt <= 26'd0;
			pace_arm <= 1'b0;
			abort_r <= 1'b0;
			pend_trig <= 1'b0;
			for (i = 0; i < yunit_pkg_DMA_NREGS; i = i + 1)
				begin
					regf[i] <= 16'h0000;
					launchf[i] <= 16'h0000;
					pendf[i] <= 16'h0000;
				end
		end
		else begin
			state <= state_n;
			fb_we <= 1'b0;
			if (reg_we) begin
				regf[reg_addr] <= reg_wdata;
				if (reg_addr == yunit_pkg_DMA_COMMAND) begin
					blit_irq <= 1'b0;
					if (wdata_trig) begin
						if (direct_accept) begin
							for (i = 0; i < 10; i = i + 1)
								launchf[i] <= (i == yunit_pkg_DMA_COMMAND ? reg_wdata : regf[i]);
							busy_r <= 1'b1;
						end
						else if (pending_accept) begin
							for (i = 0; i < 10; i = i + 1)
								pendf[i] <= (i == yunit_pkg_DMA_COMMAND ? reg_wdata : regf[i]);
							pend_trig <= 1'b1;
							busy_r <= 1'b1;
						end
					end
					else if (!RENDER_ONLY) begin
						if (state == 3'd0)
							busy_r <= 1'b0;
						else begin
							busy_r <= 1'b0;
							if (state_n != 3'd0)
								abort_r <= 1'b1;
						end
					end
				end
			end
			if (abort_r && (state_n == 3'd0))
				abort_r <= 1'b0;
			if ((!RENDER_ONLY && (state == 3'd0)) && pend_trig) begin
				for (i = 0; i < 10; i = i + 1)
					launchf[i] <= pendf[i];
				pend_trig <= 1'b0;
			end
			if (RENDER_ONLY) begin
				pace_arm <= 1'b0;
				pace_cnt <= 26'd0;
			end
			else begin
				pace_arm <= state == 3'd2;
				if (pace_arm)
					pace_cnt <= ({14'd0, width_c[11:0]} * {14'd0, height_c[11:0]}) << 2;
				else if (pace_cnt != 26'd0)
					pace_cnt <= pace_cnt - 26'd1;
			end
			(* full_case, parallel_case *)
			case (state)
				3'd2: begin
					mode_c <= mode_w;
					flipx_c <= flipx_w;
					readmode_c <= readmode_w;
					width_c <= (width_f <= 32'sd0 ? 12'sd0 : $signed(width12));
					height_c <= (height1 <= 32'sd0 ? 12'sd0 : $signed(height12));
					xpos_c <= $signed(xpos12);
					ypos_c <= $signed(ypos12);
					rowbytes_c <= rb_adj;
					pal16_c <= {pal_lo, 8'h00};
					color16_c <= {pal_lo, col_lo};
					row_i <= 12'sd0;
					cur_off <= offbytes_c;
				end
				3'd3: begin
					ty <= ty_next;
					tx <= xpos_c;
					col_i <= 12'sd0;
					o_ptr <= cur_off;
					if (row_i < height_c) begin
						cur_off <= cur_off + rowbytes_c;
						row_i <= row_i + 12'sd1;
					end
				end
				3'd4:
					if (readmode_c && src_ack)
						px <= src_data;
				3'd5: begin
					if (pix_we) begin
						fb_we <= 1'b1;
						fb_addr <= {ty, tx9};
						fb_wdata <= pix_data;
					end
					if (!pix_we || fb_ack) begin
						tx <= tx + (flipx_c ? -12'sd1 : 12'sd1);
						col_i <= col_i + 12'sd1;
						if (readmode_c)
							o_ptr <= o_ptr + 32'sd1;
					end
				end
				3'd6:
					if (dma_done_ok) begin
						if (pend_trig || pending_accept)
							blit_irq <= 1'b0;
						else begin
							busy_r <= 1'b0;
							blit_irq <= 1'b1;
						end
					end
				default:
					;
			endcase
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_dma_logical_timer (
	clk,
	rst,
	command_we,
	command_start,
	clipped_pixels,
	completion_ready,
	busy,
	blit_irq,
	completion_pulse,
	timer_pending
);
	input wire clk;
	input wire rst;
	input wire command_we;
	input wire command_start;
	input wire [18:0] clipped_pixels;
	input wire completion_ready;
	output reg busy;
	output reg blit_irq;
	output reg completion_pulse;
	output wire timer_pending;
	localparam [30:0] MILLI_PER_PIXEL = 31'd3936;
	localparam [30:0] MILLI_PER_CLOCK = 31'd1000;
	reg [18:0] pixels_q;
	reg calc_valid;
	wire [30:0] duration_milli = {{12 {1'b0}}, pixels_q} * MILLI_PER_PIXEL;
	reg [30:0] remaining_milli;
	reg count_valid;
	reg due_deferred;
	wire calc_due = calc_valid && (duration_milli <= MILLI_PER_CLOCK);
	wire count_due = count_valid && (remaining_milli <= MILLI_PER_CLOCK);
	wire due_raw = (due_deferred || calc_due) || count_due;
	wire due_now = completion_ready && due_raw;
	assign timer_pending = (calc_valid || count_valid) || due_deferred;
	always @(posedge clk)
		if (rst) begin
			pixels_q <= 19'd0;
			calc_valid <= 1'b0;
			remaining_milli <= 31'd0;
			count_valid <= 1'b0;
			due_deferred <= 1'b0;
			busy <= 1'b0;
			blit_irq <= 1'b0;
			completion_pulse <= 1'b0;
		end
		else begin
			completion_pulse <= 1'b0;
			if (command_we && command_start) begin
				pixels_q <= clipped_pixels;
				calc_valid <= 1'b1;
				remaining_milli <= 31'd0;
				count_valid <= 1'b0;
				due_deferred <= 1'b0;
			end
			else if (due_deferred) begin
				if (!command_we && completion_ready)
					due_deferred <= 1'b0;
			end
			else if (calc_valid) begin
				calc_valid <= 1'b0;
				if (calc_due) begin
					if (command_we || !completion_ready)
						due_deferred <= 1'b1;
				end
				else begin
					remaining_milli <= duration_milli - MILLI_PER_CLOCK;
					count_valid <= 1'b1;
				end
			end
			else if (count_valid) begin
				if (count_due) begin
					count_valid <= 1'b0;
					if (command_we || !completion_ready)
						due_deferred <= 1'b1;
				end
				else
					remaining_milli <= remaining_milli - MILLI_PER_CLOCK;
			end
			if (command_we) begin
				busy <= command_start;
				blit_irq <= 1'b0;
			end
			else if (due_now) begin
				busy <= 1'b0;
				blit_irq <= 1'b1;
				completion_pulse <= 1'b1;
			end
		end
endmodule
`default_nettype wire
`default_nettype none
module yunit_dma_descriptor_fifo (
	clk,
	rst,
	push,
	push_data,
	push_ready,
	pop,
	pop_data,
	empty,
	full,
	count,
	high_water,
	overflow_sticky
);
	parameter signed [31:0] WIDTH = 160;
	parameter signed [31:0] DEPTH = 512;
	parameter signed [31:0] AW = $clog2(DEPTH);
	input wire clk;
	input wire rst;
	input wire push;
	input wire [WIDTH - 1:0] push_data;
	output wire push_ready;
	input wire pop;
	output wire [WIDTH - 1:0] pop_data;
	output wire empty;
	output wire full;
	output reg [AW:0] count;
	output reg [AW:0] high_water;
	output reg overflow_sticky;
	reg [WIDTH - 1:0] mem [0:DEPTH - 1];
	reg [AW - 1:0] wr_ptr;
	reg [AW - 1:0] rd_ptr;
	wire pop_accept = pop && !empty;
	wire push_accept = push && push_ready;
	assign empty = count == 0;
	assign full = count == DEPTH;
	assign push_ready = !full || pop_accept;
	assign pop_data = mem[rd_ptr];
	always @(posedge clk)
		if (rst) begin
			wr_ptr <= 1'sb0;
			rd_ptr <= 1'sb0;
			count <= 1'sb0;
			high_water <= 1'sb0;
			overflow_sticky <= 1'b0;
		end
		else begin
			if (push && !push_ready)
				overflow_sticky <= 1'b1;
			if (push_accept) begin
				mem[wr_ptr] <= push_data;
				if (wr_ptr == (DEPTH - 1))
					wr_ptr <= 1'sb0;
				else
					wr_ptr <= wr_ptr + 1'b1;
			end
			if (pop_accept) begin
				if (rd_ptr == (DEPTH - 1))
					rd_ptr <= 1'sb0;
				else
					rd_ptr <= rd_ptr + 1'b1;
			end
			(* full_case, parallel_case *)
			case ({push_accept, pop_accept})
				2'b10: count <= count + 1'b1;
				2'b01: count <= count - 1'b1;
				default:
					;
			endcase
			if ((push_accept && !pop_accept) && ((count + 1'b1) > high_water))
				high_water <= count + 1'b1;
		end
endmodule
`default_nettype wire
`default_nettype none
module vram_sdram (
	clk,
	rst,
	req,
	we,
	widx,
	boff,
	sz,
	wd,
	videobank,
	dma_palette,
	rdata,
	done,
	active,
	sd_addr,
	sd_din,
	sd_be,
	sd_rd,
	sd_wr,
	sd_dout,
	sd_ack
);
	reg _sv2v_0;
	parameter signed [31:0] VRAMW = 32'h00040000;
	parameter signed [31:0] SD_AW = 21;
	parameter [SD_AW - 1:0] VRAM_BASE = 1'sb0;
	parameter [0:0] BE_WRITE = 1'b0;
	input wire clk;
	input wire rst;
	input wire req;
	input wire we;
	input wire [27:0] widx;
	input wire [3:0] boff;
	input wire [5:0] sz;
	input wire [31:0] wd;
	input wire videobank;
	input wire [15:0] dma_palette;
	output reg [31:0] rdata;
	output reg done;
	output wire active;
	output reg [SD_AW - 1:0] sd_addr;
	output reg [15:0] sd_din;
	output reg [1:0] sd_be;
	output reg sd_rd;
	output reg sd_wr;
	input wire [15:0] sd_dout;
	input wire sd_ack;
	reg we_l;
	reg vb_l;
	reg [27:0] wi;
	reg [3:0] bo;
	reg [5:0] szl;
	reg [31:0] wd_l;
	reg [15:0] pal_l;
	wire [17:0] ea = (wi << 1) + {17'd0, bo[3]};
	wire vea_v = ((wi << 1) + {27'd0, bo[3]}) < VRAMW;
	function automatic [17:0] went;
		input [2:0] i;
		went = ((wi + {26'd0, i[2:1]}) << 1) + {17'd0, i[0]};
	endfunction
	function automatic wentv;
		input [2:0] i;
		wentv = (((wi + {26'd0, i[2:1]}) << 1) + {17'd0, i[0]}) < VRAMW;
	endfunction
	reg [15:0] o0;
	reg [15:0] o1;
	reg [15:0] o2;
	reg [15:0] o3;
	reg [15:0] o4;
	reg [15:0] o5;
	wire [7:0] oea = (bo[3] ? o1[7:0] : o0[7:0]);
	wire [15:0] pw0 = (vb_l ? {o1[7:0], o0[7:0]} : {o1[15:8], o0[15:8]});
	wire [15:0] pw1 = (vb_l ? {o3[7:0], o2[7:0]} : {o3[15:8], o2[15:8]});
	wire [15:0] pw2 = (vb_l ? {o5[7:0], o4[7:0]} : {o5[15:8], o4[15:8]});
	wire [47:0] win48 = {pw2, pw1, pw0};
	wire [47:0] rmask = (48'd1 << szl) - 48'd1;
	wire [47:0] merged48 = (win48 & ~(rmask << bo)) | (({16'h0000, wd_l} & rmask) << bo);
	function automatic [15:0] nent;
		input [2:0] i;
		reg [7:0] nb;
		reg [7:0] ob;
		begin
			nb = merged48[{2'd0, i} * 8+:8];
			case (i)
				3'd0: ob = o0[7:0];
				3'd1: ob = o1[7:0];
				3'd2: ob = o2[7:0];
				3'd3: ob = o3[7:0];
				3'd4: ob = o4[7:0];
				default: ob = o5[7:0];
			endcase
			if (vb_l)
				nent = {(i[0] ? pal_l[15:8] : pal_l[7:0]), nb};
			else
				nent = {nb, ob};
		end
	endfunction
	wire [15:0] vnewea = (vb_l ? {(bo[3] ? pal_l[15:8] : pal_l[7:0]), wd_l[7:0]} : {wd_l[7:0], oea});
	wire [5:0] lastbit = ({2'd0, bo} + szl) - 6'd1;
	wire [2:0] nwords = 3'd1 + {1'b0, lastbit[5:4]};
	wire [2:0] nents = {nwords[1:0], 1'b0};
	wire is8 = we_l & (szl <= 6'd8);
	wire [2:0] nread = (is8 ? 3'd1 : nents);
	wire [2:0] nwrite = (we_l ? (is8 ? 3'd1 : nents) : 3'd0);
	function automatic [17:0] raddr;
		input [2:0] i;
		if (is8)
			raddr = ea;
		else
			raddr = went(i);
	endfunction
	function automatic rvalid;
		input [2:0] i;
		if (is8)
			rvalid = vea_v;
		else
			rvalid = wentv(i);
	endfunction
	function automatic [17:0] waddr;
		input [2:0] i;
		if (is8)
			waddr = ea;
		else
			waddr = went(i);
	endfunction
	function automatic [15:0] wdata;
		input [2:0] i;
		if (is8)
			wdata = vnewea;
		else
			wdata = nent(i);
	endfunction
	function automatic wvalid;
		input [2:0] i;
		if (is8)
			wvalid = vea_v;
		else
			wvalid = wentv(i);
	endfunction
	function automatic wr_read;
		input [2:0] i;
		reg [7:0] blo;
		reg [7:0] bhi;
		reg [7:0] flo;
		reg [7:0] fhi;
		begin
			blo = {5'd0, i} << 3;
			bhi = blo + 8'd8;
			flo = {4'd0, bo};
			fhi = flo + {2'd0, szl};
			wr_read = !((flo <= blo) && (fhi >= bhi));
		end
	endfunction
	wire [1:0] be_wr = (BE_WRITE && !is8 ? (vb_l ? 2'b11 : 2'b10) : 2'b11);
	reg [1:0] st;
	reg [2:0] idx;
	assign active = st != 2'd0;
	function automatic [31:0] sv2v_cast_32;
		input reg [31:0] inp;
		sv2v_cast_32 = inp;
	endfunction
	always @(posedge clk)
		if (rst) begin
			st <= 2'd0;
			done <= 1'b0;
			sd_rd <= 1'b0;
			sd_wr <= 1'b0;
			idx <= 3'd0;
		end
		else begin
			done <= 1'b0;
			case (st)
				2'd0: begin
					sd_rd <= 1'b0;
					sd_wr <= 1'b0;
					if (req) begin
						we_l <= we;
						wi <= widx;
						bo <= boff;
						szl <= sz;
						wd_l <= wd;
						vb_l <= videobank;
						pal_l <= dma_palette;
						idx <= 3'd0;
						st <= 2'd1;
					end
				end
				2'd1:
					if (idx >= nread) begin
						sd_rd <= 1'b0;
						if (we_l) begin
							idx <= 3'd0;
							st <= 2'd2;
						end
						else
							st <= 2'd3;
					end
					else if (!rvalid(idx) || (((BE_WRITE && we_l) && !is8) && !wr_read(idx))) begin
						case (idx)
							3'd0: o0 <= 16'h0000;
							3'd1: o1 <= 16'h0000;
							3'd2: o2 <= 16'h0000;
							3'd3: o3 <= 16'h0000;
							3'd4: o4 <= 16'h0000;
							default: o5 <= 16'h0000;
						endcase
						idx <= idx + 3'd1;
					end
					else if (sd_ack) begin
						case (idx)
							3'd0: o0 <= sd_dout;
							3'd1: o1 <= sd_dout;
							3'd2: o2 <= sd_dout;
							3'd3: o3 <= sd_dout;
							3'd4: o4 <= sd_dout;
							default: o5 <= sd_dout;
						endcase
						sd_rd <= 1'b0;
						idx <= idx + 3'd1;
					end
					else begin
						sd_addr <= VRAM_BASE + raddr(idx);
						sd_be <= 2'b00;
						sd_rd <= 1'b1;
					end
				2'd2:
					if (idx >= nwrite) begin
						sd_wr <= 1'b0;
						st <= 2'd3;
					end
					else if (!wvalid(idx))
						idx <= idx + 3'd1;
					else if (sd_ack) begin
						sd_wr <= 1'b0;
						idx <= idx + 3'd1;
					end
					else begin
						sd_addr <= VRAM_BASE + waddr(idx);
						sd_din <= wdata(idx);
						sd_be <= be_wr;
						sd_wr <= 1'b1;
					end
				2'd3: begin
					rdata <= sv2v_cast_32((win48 >> bo) & rmask);
					done <= 1'b1;
					st <= 2'd0;
				end
				default: st <= 2'd0;
			endcase
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module vram_sdram_top (
	clk,
	rst,
	req,
	we,
	widx,
	boff,
	sz,
	wd,
	videobank,
	dma_palette,
	rdata,
	done,
	fb_we,
	fb_addr,
	fb_wdata,
	fb_ack,
	erase_start,
	erase_row0,
	erase_lines,
	erase_busy,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	sd_addr,
	sd_din,
	sd_be,
	sd_rd,
	sd_wr,
	sd_dout,
	sd_ack
);
	reg _sv2v_0;
	parameter signed [31:0] VRAMW = 32'h00040000;
	parameter signed [31:0] SD_AW = 21;
	parameter [SD_AW - 1:0] VRAM_BASE = 1'sb0;
	parameter [0:0] BE_WRITE = 1'b0;
	parameter [0:0] BULK_ERASE = 1'b1;
	input wire clk;
	input wire rst;
	input wire req;
	input wire we;
	input wire [27:0] widx;
	input wire [3:0] boff;
	input wire [5:0] sz;
	input wire [31:0] wd;
	input wire videobank;
	input wire [15:0] dma_palette;
	output wire [31:0] rdata;
	output wire done;
	input wire fb_we;
	input wire [17:0] fb_addr;
	input wire [15:0] fb_wdata;
	output reg fb_ack;
	input wire erase_start;
	input wire [8:0] erase_row0;
	input wire [9:0] erase_lines;
	output wire erase_busy;
	input wire scan_req;
	input wire [17:0] scan_addr;
	output wire [15:0] scan_data;
	output reg scan_ack;
	output reg [SD_AW - 1:0] sd_addr;
	output reg [15:0] sd_din;
	output reg [1:0] sd_be;
	output reg sd_rd;
	output reg sd_wr;
	input wire [15:0] sd_dout;
	input wire sd_ack;
	reg c_ack_i;
	reg f_ack_i;
	reg ae_ack_i;
	wire [SD_AW - 1:0] c_addr;
	wire [15:0] c_din;
	wire [1:0] c_be;
	wire c_rd;
	wire c_wr;
	wire c_active;
	vram_sdram #(
		.VRAMW(VRAMW),
		.SD_AW(SD_AW),
		.VRAM_BASE(VRAM_BASE),
		.BE_WRITE(BE_WRITE)
	) u_cpu(
		.clk(clk),
		.rst(rst),
		.req(req),
		.we(we),
		.widx(widx),
		.boff(boff),
		.sz(sz),
		.wd(wd),
		.videobank(videobank),
		.dma_palette(dma_palette),
		.rdata(rdata),
		.done(done),
		.active(c_active),
		.sd_addr(c_addr),
		.sd_din(c_din),
		.sd_be(c_be),
		.sd_rd(c_rd),
		.sd_wr(c_wr),
		.sd_dout(sd_dout),
		.sd_ack(c_ack_i)
	);
	reg [17:0] f_a;
	reg [15:0] f_d;
	reg f_pending;
	reg fb_we_d;
	always @(posedge clk)
		if (rst) begin
			f_pending <= 1'b0;
			fb_ack <= 1'b0;
			fb_we_d <= 1'b0;
		end
		else begin
			fb_ack <= 1'b0;
			fb_we_d <= fb_we;
			if (!f_pending) begin
				if (fb_we & ~fb_we_d) begin
					f_a <= fb_addr;
					f_d <= fb_wdata;
					f_pending <= 1'b1;
				end
			end
			else if (f_ack_i) begin
				f_pending <= 1'b0;
				fb_ack <= 1'b1;
			end
		end
	localparam [1:0] AE_IDLE = 2'd0;
	localparam [1:0] AE_RD = 2'd1;
	localparam [1:0] AE_WR = 2'd2;
	localparam [1:0] AE_ADV = 2'd3;
	reg [1:0] ae;
	reg er_run;
	reg [8:0] er_row;
	reg [8:0] er_x;
	reg [9:0] er_left;
	reg [15:0] er_data;
	wire [17:0] ae_src = {8'hff, er_row[0], er_x};
	wire [17:0] ae_dst = {er_row, er_x};
	wire ae_skip = (er_row == 9'd510) || (er_row == 9'd511);
	wire ae_rd_req = (BULK_ERASE && (ae == AE_RD)) && !ae_skip;
	wire ae_wr_req = BULK_ERASE && (ae == AE_WR);
	assign erase_busy = BULK_ERASE && er_run;
	always @(posedge clk)
		if (rst) begin
			ae <= AE_IDLE;
			er_run <= 1'b0;
		end
		else
			case (ae)
				AE_IDLE:
					if (erase_start && (erase_lines != 10'd0)) begin
						er_run <= 1'b1;
						er_row <= erase_row0 - 9'd1;
						er_x <= 9'd0;
						er_left <= erase_lines + 10'd1;
						ae <= AE_RD;
					end
				AE_RD:
					if (ae_skip)
						ae <= AE_ADV;
					else if (ae_ack_i) begin
						er_data <= sd_dout;
						ae <= AE_WR;
					end
				AE_WR:
					if (ae_ack_i)
						ae <= AE_ADV;
				AE_ADV:
					if (er_x == 9'd511) begin
						er_x <= 9'd0;
						er_row <= er_row + 9'd1;
						er_left <= er_left - 10'd1;
						if (er_left <= 10'd1) begin
							er_run <= 1'b0;
							ae <= AE_IDLE;
						end
						else
							ae <= AE_RD;
					end
					else begin
						er_x <= er_x + 9'd1;
						ae <= AE_RD;
					end
				default: ae <= AE_IDLE;
			endcase
	wire cpu_req = c_rd | c_wr;
	wire fb_req = f_pending;
	wire ae_req = ae_rd_req | ae_wr_req;
	reg [2:0] gnt;
	reg gnt_held;
	reg [2:0] gnt_r;
	reg bubble;
	always @(*) begin
		if (_sv2v_0)
			;
		if (gnt_held)
			gnt = gnt_r;
		else if (bubble)
			gnt = 3'd0;
		else if (scan_req)
			gnt = 3'd1;
		else if (cpu_req)
			gnt = 3'd2;
		else if (fb_req)
			gnt = 3'd3;
		else if (ae_req)
			gnt = 3'd4;
		else
			gnt = 3'd0;
	end
	always @(posedge clk)
		if (rst) begin
			gnt_held <= 1'b0;
			gnt_r <= 3'd0;
			bubble <= 1'b0;
		end
		else begin
			bubble <= 1'b0;
			if (!gnt_held) begin
				if (!bubble && (gnt != 3'd0)) begin
					gnt_held <= 1'b1;
					gnt_r <= gnt;
				end
			end
			else if (sd_ack) begin
				gnt_held <= 1'b0;
				bubble <= 1'b1;
			end
		end
	always @(*) begin
		if (_sv2v_0)
			;
		sd_addr = 1'sb0;
		sd_din = 16'h0000;
		sd_be = 2'b00;
		sd_rd = 1'b0;
		sd_wr = 1'b0;
		c_ack_i = 1'b0;
		f_ack_i = 1'b0;
		ae_ack_i = 1'b0;
		scan_ack = 1'b0;
		case (gnt)
			3'd1: begin
				sd_addr = VRAM_BASE + {{SD_AW - 18 {1'b0}}, scan_addr};
				sd_be = 2'b00;
				sd_rd = scan_req;
				scan_ack = sd_ack;
			end
			3'd2: begin
				sd_addr = c_addr;
				sd_din = c_din;
				sd_be = c_be;
				sd_rd = c_rd;
				sd_wr = c_wr;
				c_ack_i = sd_ack;
			end
			3'd3: begin
				sd_addr = VRAM_BASE + {{SD_AW - 18 {1'b0}}, f_a};
				sd_din = f_d;
				sd_be = 2'b11;
				sd_wr = f_pending;
				f_ack_i = sd_ack;
			end
			3'd4: begin
				if (ae_rd_req) begin
					sd_addr = VRAM_BASE + {{SD_AW - 18 {1'b0}}, ae_src};
					sd_be = 2'b00;
					sd_rd = 1'b1;
				end
				else begin
					sd_addr = VRAM_BASE + {{SD_AW - 18 {1'b0}}, ae_dst};
					sd_din = er_data;
					sd_be = 2'b11;
					sd_wr = 1'b1;
				end
				ae_ack_i = sd_ack;
			end
			default:
				;
		endcase
	end
	assign scan_data = sd_dout;
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module vram_sdram_scanout (
	clk,
	rst,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	invalidate_valid,
	invalidate_row,
	brd_req,
	brd_addr,
	brd_len,
	brd_dout,
	brd_dvalid,
	brd_done
);
	parameter [24:0] VRAM_WBASE = 25'h00e0000;
	input wire clk;
	input wire rst;
	input wire scan_req;
	input wire [17:0] scan_addr;
	output reg [15:0] scan_data;
	output reg scan_ack;
	input wire invalidate_valid;
	input wire [8:0] invalidate_row;
	output reg brd_req;
	output reg [24:0] brd_addr;
	output reg [9:0] brd_len;
	input wire [15:0] brd_dout;
	input wire brd_dvalid;
	input wire brd_done;
	localparam integer ROWLEN = 512;
	(* ramstyle = "no_rw_check" *) reg [15:0] rc [0:ROWLEN - 1];
	reg [8:0] rc_row;
	reg rc_valid;
	wire [8:0] req_row = scan_addr[17:9];
	wire [8:0] req_col = scan_addr[8:0];
	wire [8:0] rc_raddr = req_col;
	reg [15:0] rc_q;
	always @(posedge clk) rc_q <= rc[rc_raddr];
	reg [9:0] fill_i;
	reg [1:0] ss;
	always @(posedge clk)
		if (rst) begin
			ss <= 2'd0;
			rc_valid <= 1'b0;
			rc_row <= 9'd0;
			brd_req <= 1'b0;
			brd_len <= 10'd0;
			scan_ack <= 1'b0;
			scan_data <= 16'd0;
			fill_i <= 10'd0;
		end
		else begin
			scan_ack <= 1'b0;
			if ((invalidate_valid && rc_valid) && (rc_row == invalidate_row))
				rc_valid <= 1'b0;
			case (ss)
				2'd0:
					if (scan_req) begin
						if (rc_valid && (rc_row == req_row))
							ss <= 2'd2;
						else begin
							brd_addr <= (VRAM_WBASE + {req_row, 9'd0}) << 1;
							brd_len <= ROWLEN[9:0];
							brd_req <= 1'b1;
							fill_i <= 10'd0;
							ss <= 2'd1;
						end
					end
				2'd1: begin
					if (brd_dvalid && (fill_i < ROWLEN)) begin
						rc[fill_i[8:0]] <= brd_dout;
						fill_i <= fill_i + 10'd1;
					end
					if (brd_done) begin
						brd_req <= 1'b0;
						rc_valid <= !(invalidate_valid && (invalidate_row == req_row));
						rc_row <= req_row;
						ss <= 2'd0;
					end
				end
				2'd2: begin
					scan_data <= rc_q;
					scan_ack <= 1'b1;
					ss <= 2'd3;
				end
				2'd3:
					if (!scan_req)
						ss <= 2'd0;
				default: ss <= 2'd0;
			endcase
		end
endmodule
`default_nettype wire
`default_nettype none
module stv_vram_ddr_agent (
	clk,
	sdram_por,
	tst_wr_req,
	tst_rd_req,
	tst_addr,
	tst_wdata,
	tst_be,
	tst_burstcnt,
	tst_rdata,
	tst_rd_valid,
	tst_busy,
	tst_wnext,
	tst_wr_done,
	tst_wr_base,
	tst_wr_count,
	tst_wr_last_data,
	ddram_addr,
	ddram_burstcnt,
	ddram_rd,
	ddram_we,
	ddram_din,
	ddram_be,
	ddram_busy,
	ddram_dout,
	ddram_dout_ready
);
	parameter [28:0] VRAM_DDR_BASE = 29'h06400000;
	input clk;
	input sdram_por;
	input tst_wr_req;
	input tst_rd_req;
	input [25:0] tst_addr;
	input [63:0] tst_wdata;
	input [7:0] tst_be;
	input [7:0] tst_burstcnt;
	output reg [63:0] tst_rdata;
	output reg tst_rd_valid;
	output reg tst_busy;
	output wire tst_wnext;
	output reg tst_wr_done;
	output reg [25:0] tst_wr_base;
	output reg [7:0] tst_wr_count;
	output reg [63:0] tst_wr_last_data;
	output reg [28:0] ddram_addr;
	output reg [7:0] ddram_burstcnt;
	output reg ddram_rd;
	output reg ddram_we;
	output wire [63:0] ddram_din;
	output reg [7:0] ddram_be;
	input ddram_busy;
	input [63:0] ddram_dout;
	input ddram_dout_ready;
	localparam ST_IDLE = 3'd0;
	localparam ST_WR = 3'd1;
	localparam ST_RD_REQ = 3'd2;
	localparam ST_RD_RCV = 3'd3;
	localparam ST_WRB = 3'd4;
	reg [2:0] state;
	reg [63:0] ddram_din_r;
	reg [7:0] beat;
	reg [7:0] bcnt;
	assign ddram_din = (state == ST_WRB ? tst_wdata : ddram_din_r);
	assign tst_wnext = (((state == ST_WRB) && ddram_we) && !ddram_busy) && (beat != (bcnt - 8'd1));
	always @(posedge clk)
		if (sdram_por) begin
			state <= ST_IDLE;
			beat <= 8'd0;
			bcnt <= 8'd1;
			ddram_addr <= 29'd0;
			ddram_burstcnt <= 8'd1;
			ddram_rd <= 1'b0;
			ddram_we <= 1'b0;
			ddram_din_r <= 64'd0;
			ddram_be <= 8'hff;
			tst_rdata <= 64'd0;
			tst_rd_valid <= 1'b0;
			tst_busy <= 1'b0;
			tst_wr_done <= 1'b0;
			tst_wr_base <= 26'd0;
			tst_wr_count <= 8'd0;
			tst_wr_last_data <= 64'd0;
		end
		else begin
			ddram_rd <= 1'b0;
			ddram_we <= 1'b0;
			tst_rd_valid <= 1'b0;
			tst_wr_done <= 1'b0;
			case (state)
				ST_IDLE:
					if (tst_wr_req) begin
						ddram_addr <= VRAM_DDR_BASE + {3'd0, tst_addr};
						ddram_be <= tst_be;
						tst_busy <= 1'b1;
						tst_wr_base <= tst_addr;
						tst_wr_count <= (tst_burstcnt == 8'd0 ? 8'd1 : tst_burstcnt);
						if (tst_burstcnt <= 8'd1) begin
							ddram_din_r <= tst_wdata;
							ddram_burstcnt <= 8'd1;
							state <= ST_WR;
						end
						else begin
							ddram_burstcnt <= tst_burstcnt;
							bcnt <= tst_burstcnt;
							beat <= 8'd0;
							state <= ST_WRB;
						end
					end
					else if (tst_rd_req) begin
						ddram_addr <= VRAM_DDR_BASE + {3'd0, tst_addr};
						ddram_burstcnt <= (tst_burstcnt == 8'd0 ? 8'd1 : tst_burstcnt);
						bcnt <= (tst_burstcnt == 8'd0 ? 8'd1 : tst_burstcnt);
						beat <= 8'd0;
						ddram_rd <= 1'b1;
						tst_busy <= 1'b1;
						state <= ST_RD_REQ;
					end
				ST_WR: begin
					ddram_we <= 1'b1;
					if (ddram_we && !ddram_busy) begin
						ddram_we <= 1'b0;
						tst_busy <= 1'b0;
						state <= ST_IDLE;
						tst_wr_done <= 1'b1;
						tst_wr_last_data <= ddram_din_r;
					end
				end
				ST_WRB: begin
					ddram_we <= 1'b1;
					if (ddram_we && !ddram_busy) begin
						if (beat == (bcnt - 8'd1)) begin
							ddram_we <= 1'b0;
							tst_busy <= 1'b0;
							state <= ST_IDLE;
							tst_wr_done <= 1'b1;
							tst_wr_last_data <= tst_wdata;
						end
						beat <= beat + 8'd1;
					end
				end
				ST_RD_REQ:
					if (ddram_busy)
						ddram_rd <= 1'b1;
					else
						state <= ST_RD_RCV;
				ST_RD_RCV:
					if (ddram_dout_ready) begin
						tst_rdata <= ddram_dout;
						tst_rd_valid <= 1'b1;
						if (beat == (bcnt - 8'd1)) begin
							tst_busy <= 1'b0;
							state <= ST_IDLE;
						end
						beat <= beat + 8'd1;
					end
				default: state <= ST_IDLE;
			endcase
		end
endmodule
`default_nettype wire
`default_nettype none
module stv_vram_ddr_top (
	clk,
	rst,
	sdram_por,
	req,
	we,
	widx,
	boff,
	sz,
	wd,
	videobank,
	dma_palette,
	rdata,
	done,
	fb_we,
	fb_addr,
	fb_wdata,
	fb_ack,
	fb_flush,
	fb_busy,
	erase_en,
	erase_frame_start,
	erase_line_valid,
	erase_line_first,
	erase_line_row,
	erase_busy,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	shift_req,
	shift_write,
	shift_entry,
	shift_rdata,
	shift_ready,
	shift_done,
	shift_invalidate_valid,
	shift_invalidate_row,
	ddram_addr,
	ddram_burstcnt,
	ddram_rd,
	ddram_we,
	ddram_din,
	ddram_be,
	ddram_busy,
	ddram_dout,
	ddram_dout_ready
);
	reg _sv2v_0;
	parameter signed [31:0] VRAMW = 32'h00040000;
	parameter [28:0] VRAM_DDR_BASE = 29'h06400000;
	input wire clk;
	input wire rst;
	input wire sdram_por;
	input wire req;
	input wire we;
	input wire [27:0] widx;
	input wire [3:0] boff;
	input wire [5:0] sz;
	input wire [31:0] wd;
	input wire videobank;
	input wire [15:0] dma_palette;
	output wire [31:0] rdata;
	output wire done;
	input wire fb_we;
	input wire [17:0] fb_addr;
	input wire [15:0] fb_wdata;
	output reg fb_ack;
	input wire fb_flush;
	output wire fb_busy;
	input wire erase_en;
	input wire erase_frame_start;
	input wire erase_line_valid;
	input wire erase_line_first;
	input wire [8:0] erase_line_row;
	output wire erase_busy;
	input wire scan_req;
	input wire [17:0] scan_addr;
	output reg [15:0] scan_data;
	output reg scan_ack;
	input wire shift_req;
	input wire shift_write;
	input wire [17:0] shift_entry;
	output reg [15:0] shift_rdata;
	output wire shift_ready;
	output reg shift_done;
	output wire shift_invalidate_valid;
	output wire [8:0] shift_invalidate_row;
	output wire [28:0] ddram_addr;
	output wire [7:0] ddram_burstcnt;
	output wire ddram_rd;
	output wire ddram_we;
	output wire [63:0] ddram_din;
	output wire [7:0] ddram_be;
	input wire ddram_busy;
	input wire [63:0] ddram_dout;
	input wire ddram_dout_ready;
	function automatic [7:0] lane_be;
		input [1:0] l;
		case (l)
			2'd0: lane_be = 8'h03;
			2'd1: lane_be = 8'h0c;
			2'd2: lane_be = 8'h30;
			default: lane_be = 8'hc0;
		endcase
	endfunction
	reg [8:0] rc_row;
	reg rc_valid;
	reg rc_fbsel;
	reg fb_sel;
	localparam [0:0] DBL_EN = 1'b0;
	reg dbl_arm;
	wire dbl_on = DBL_EN & dbl_arm;
	localparam [0:0] BSNOOP = 1'b1;
	localparam [0:0] B_SCAN_PROOF = 1'b1;
	reg [63:0] bfill_merged;
	reg c_start;
	reg c_wr;
	reg [25:0] c_addr;
	reg d_start;
	reg d_wr;
	reg [25:0] d_addr;
	(* preserve, dont_merge *) reg [15:0] bsn_d_addr_q;
	reg d_is_burst;
	wire d_busy;
	wire b_fill_lock;
	wire b_bus_lock;
	reg [1:0] ls;
	wire tst_busy;
	reg d_add;
	reg [15:0] d_add_beat;
	reg e_start;
	reg e_wr;
	reg [25:0] e_addr;
	wire e_block;
	wire e_write_invalidate;
	wire [8:0] e_invalidate_row;
	reg [17:0] e_base_entry;
	reg [16:0] e_base_beat;
	reg e_op_we;
	reg e_fbsel;
	reg [8:0] e_fill;
	reg [7:0] e_blen;
	wire e_rd_valid;
	wire [63:0] e_rdata;
	wire e_done;
	wire e_burst_next;
	localparam [3:0] E_IDLE = 4'd0;
	localparam [3:0] E_DRAIN = 4'd1;
	localparam [3:0] E_RREQ = 4'd2;
	localparam [3:0] E_RFILL = 4'd3;
	localparam [3:0] E_WREQ = 4'd4;
	localparam [3:0] E_WSTREAM = 4'd5;
	localparam [3:0] E_INV0 = 4'd6;
	localparam [3:0] E_INV1 = 4'd7;
	localparam [3:0] E_FIN = 4'd8;
	reg [3:0] est;
	reg srt_snapshot_hold;
	wire [20:0] sd_addr;
	wire [15:0] sd_din;
	wire [1:0] sd_be;
	wire sd_rd;
	wire sd_wr;
	reg [15:0] sd_dout;
	reg sd_ack;
	vram_sdram_top #(
		.VRAMW(VRAMW),
		.SD_AW(21),
		.VRAM_BASE(21'd0),
		.BULK_ERASE(1'b0)
	) u_acc(
		.clk(clk),
		.rst(rst),
		.req(req),
		.we(we),
		.widx(widx),
		.boff(boff),
		.sz(sz),
		.wd(wd),
		.videobank(videobank),
		.dma_palette(dma_palette),
		.rdata(rdata),
		.done(done),
		.fb_we(1'b0),
		.fb_addr(18'd0),
		.fb_wdata(16'd0),
		.fb_ack(),
		.erase_start(1'b0),
		.erase_row0(9'd0),
		.erase_lines(10'd0),
		.erase_busy(),
		.scan_req(1'b0),
		.scan_addr(18'd0),
		.scan_data(),
		.scan_ack(),
		.sd_addr(sd_addr),
		.sd_din(sd_din),
		.sd_be(sd_be),
		.sd_rd(sd_rd),
		.sd_wr(sd_wr),
		.sd_dout(sd_dout),
		.sd_ack(sd_ack)
	);
	reg a_start;
	reg a_wr;
	reg [25:0] a_addr;
	reg [63:0] a_wdata;
	reg [7:0] a_be;
	reg a_done;
	wire a_rd_valid;
	wire [63:0] a_rdata;
	reg [1:0] a_lane;
	reg [15:0] rmw_din;
	(* ramstyle = "M10K" *) reg [69:0] shw_mem [0:2047];
	reg [69:0] shw_q;
	reg [15:0] shw_cand_q;
	reg [63:0] shw_base;
	reg shw_base_hit;
	reg [2047:0] shw_valid;
	(* preserve, dont_merge *) reg [15:0] shw_v_bank_q;
	(* preserve, dont_merge *) reg [3:0] shw_v_bank_sel_q;
	wire shw_v_q;
	function automatic [10:0] shw_index;
		input reg [15:0] beat_addr;
		shw_index = {beat_addr[10:7], beat_addr[6:0] ^ {beat_addr[11], beat_addr[12], beat_addr[13], beat_addr[14], beat_addr[15], 2'b00}};
	endfunction
	wire shw_en = 1'b1;
	reg [63:0] rmw_beat;
	wire [63:0] rmw_merged = (a_lane == 2'd0 ? {rmw_beat[63:16], rmw_din} : (a_lane == 2'd1 ? {rmw_beat[63:32], rmw_din, rmw_beat[15:0]} : (a_lane == 2'd2 ? {rmw_beat[63:48], rmw_din, rmw_beat[31:0]} : {rmw_din, rmw_beat[47:0]})));
	reg [63:0] bc_beat0;
	reg [63:0] bc_beat1;
	reg [25:0] bc_addr0;
	reg [25:0] bc_addr1;
	reg bc_v0;
	reg bc_v1;
	reg bc_lru;
	reg bc_lastwr;
	reg bc_lastwr_v;
	reg bc_alloc;
	wire bc_hit0 = (!dbl_on && bc_v0) && (bc_addr0 == a_addr);
	wire bc_hit1 = (!dbl_on && bc_v1) && (bc_addr1 == a_addr);
	wire hit_idx = bc_hit1;
	wire [63:0] fwd_beat = (bc_hit1 ? bc_beat1 : bc_beat0);
	wire wr_alloc = (!bc_v0 ? 1'b0 : (!bc_v1 ? 1'b1 : bc_lru));
	wire rd_alloc = (!bc_v0 ? 1'b0 : (!bc_v1 ? 1'b1 : (bc_lastwr_v && (bc_lru == bc_lastwr) ? ~bc_lru : bc_lru)));
	reg a_is_wr;
	reg wb_v;
	reg [25:0] wb_addr;
	reg [63:0] wb_data;
	reg [25:0] a_addr_save;
	reg flush_pend;
	reg [4:0] wb_idle;
	localparam [4:0] WB_FLUSH_IDLE = 5'd16;
	reg awt_req;
	reg [6:0] awt_col;
	reg [63:0] awt_data;
	reg dwt_req;
	reg [6:0] dwt_col;
	reg [63:0] dwt_data;
	reg asrcwt_req;
	reg [7:0] asrcwt_idx;
	reg [63:0] asrcwt_data;
	reg dsrcwt_req;
	reg [7:0] dsrcwt_idx;
	reg [63:0] dsrcwt_data;
	wire wt_req = !dbl_on && (awt_req | dwt_req);
	wire [6:0] wt_col = (awt_req ? awt_col : dwt_col);
	wire [63:0] wt_data = (awt_req ? awt_data : dwt_data);
	wire srcwt_req = asrcwt_req | dsrcwt_req;
	wire [7:0] srcwt_idx = (asrcwt_req ? asrcwt_idx : dsrcwt_idx);
	wire [63:0] srcwt_data = (asrcwt_req ? asrcwt_data : dsrcwt_data);
	wire fwd_hit = bc_hit0 | bc_hit1;
	localparam [2:0] A_IDLE = 3'd0;
	localparam [2:0] A_DEC = 3'd1;
	localparam [2:0] A_WAIT = 3'd2;
	localparam [2:0] A_ACK = 3'd3;
	localparam [2:0] A_RMW_RD = 3'd4;
	localparam [2:0] A_RMW_MRG = 3'd5;
	localparam [2:0] A_FLUSH = 3'd6;
	reg [2:0] ats;
	wire a_req_pending = sd_rd || sd_wr;
	wire a_flush_due = wb_v && (wb_idle >= WB_FLUSH_IDLE);
	wire a_claim = (((ats != A_IDLE) || a_start) || a_req_pending) || a_flush_due;
	always @(posedge clk)
		if (rst) begin
			ats <= A_IDLE;
			a_start <= 1'b0;
			a_wr <= 1'b0;
			a_addr <= 26'd0;
			a_wdata <= 64'd0;
			a_be <= 8'd0;
			a_lane <= 2'd0;
			rmw_din <= 16'd0;
			rmw_beat <= 64'd0;
			sd_ack <= 1'b0;
			sd_dout <= 16'd0;
			wb_v <= 1'b0;
			wb_addr <= 26'd0;
			wb_data <= 64'd0;
			a_addr_save <= 26'd0;
			flush_pend <= 1'b0;
			wb_idle <= 5'd0;
			bc_beat0 <= 64'd0;
			bc_beat1 <= 64'd0;
			bc_addr0 <= 26'd0;
			bc_addr1 <= 26'd0;
			bc_v0 <= 1'b0;
			bc_v1 <= 1'b0;
			bc_lru <= 1'b0;
			bc_lastwr <= 1'b0;
			bc_lastwr_v <= 1'b0;
			bc_alloc <= 1'b0;
			a_is_wr <= 1'b0;
			awt_req <= 1'b0;
			asrcwt_req <= 1'b0;
			asrcwt_idx <= 8'd0;
			asrcwt_data <= 64'd0;
		end
		else begin
			sd_ack <= 1'b0;
			awt_req <= 1'b0;
			asrcwt_req <= 1'b0;
			case (ats)
				A_IDLE:
					if (!d_busy) begin
						if (b_fill_lock && wb_v) begin
							flush_pend <= 1'b0;
							a_addr <= wb_addr;
							a_wdata <= wb_data;
							a_be <= 8'hff;
							a_wr <= 1'b1;
							a_start <= 1'b1;
							ats <= A_FLUSH;
						end
						else if ((!b_fill_lock && !e_block) && sd_rd) begin
							a_lane <= sd_addr[1:0];
							a_addr <= {10'd0, sd_addr[17:2]};
							a_addr_save <= {10'd0, sd_addr[17:2]};
							a_is_wr <= 1'b0;
							if (wb_v && (wb_addr != {10'd0, sd_addr[17:2]})) begin
								flush_pend <= 1'b1;
								a_addr <= wb_addr;
								a_wdata <= wb_data;
								a_be <= 8'hff;
								a_wr <= 1'b1;
								a_start <= 1'b1;
								ats <= A_FLUSH;
							end
							else
								ats <= A_DEC;
						end
						else if ((!b_fill_lock && !e_block) && sd_wr) begin
							a_lane <= sd_addr[1:0];
							a_addr <= {10'd0, sd_addr[17:2]};
							a_addr_save <= {10'd0, sd_addr[17:2]};
							rmw_din <= sd_din;
							a_is_wr <= 1'b1;
							if (wb_v && (wb_addr != {10'd0, sd_addr[17:2]})) begin
								flush_pend <= 1'b1;
								a_addr <= wb_addr;
								a_wdata <= wb_data;
								a_be <= 8'hff;
								a_wr <= 1'b1;
								a_start <= 1'b1;
								ats <= A_FLUSH;
							end
							else
								ats <= A_DEC;
						end
						else if (!b_fill_lock && wb_v) begin
							if (wb_idle >= WB_FLUSH_IDLE) begin
								flush_pend <= 1'b0;
								a_addr <= wb_addr;
								a_wdata <= wb_data;
								a_be <= 8'hff;
								a_wr <= 1'b1;
								a_start <= 1'b1;
								ats <= A_FLUSH;
							end
							else
								wb_idle <= wb_idle + 5'd1;
						end
					end
				A_DEC:
					if (fwd_hit) begin
						if (a_is_wr) begin
							rmw_beat <= fwd_beat;
							ats <= A_RMW_MRG;
						end
						else begin
							case (a_lane)
								2'd0: sd_dout <= fwd_beat[15:0];
								2'd1: sd_dout <= fwd_beat[31:16];
								2'd2: sd_dout <= fwd_beat[47:32];
								default: sd_dout <= fwd_beat[63:48];
							endcase
							sd_ack <= 1'b1;
							ats <= A_ACK;
						end
						bc_lru <= ~hit_idx;
						bc_alloc <= hit_idx;
					end
					else begin
						a_wr <= 1'b0;
						a_start <= 1'b1;
						ats <= (a_is_wr ? A_RMW_RD : A_WAIT);
						bc_alloc <= (a_is_wr ? wr_alloc : rd_alloc);
					end
				A_WAIT: begin
					if (a_rd_valid) begin
						case (a_lane)
							2'd0: sd_dout <= a_rdata[15:0];
							2'd1: sd_dout <= a_rdata[31:16];
							2'd2: sd_dout <= a_rdata[47:32];
							default: sd_dout <= a_rdata[63:48];
						endcase
						if (!a_is_wr) begin
							if (bc_alloc) begin
								bc_beat1 <= a_rdata;
								bc_addr1 <= a_addr;
								bc_v1 <= 1'b1;
							end
							else begin
								bc_beat0 <= a_rdata;
								bc_addr0 <= a_addr;
								bc_v0 <= 1'b1;
							end
							bc_lru <= ~bc_alloc;
						end
					end
					if (a_done) begin
						a_start <= 1'b0;
						sd_ack <= 1'b1;
						ats <= A_ACK;
					end
				end
				A_RMW_RD: begin
					if (a_rd_valid)
						rmw_beat <= (shw_en && shw_base_hit ? shw_base : a_rdata);
					if (a_done) begin
						a_start <= 1'b0;
						ats <= A_RMW_MRG;
					end
				end
				A_RMW_MRG: begin
					wb_v <= 1'b1;
					wb_addr <= a_addr;
					wb_data <= rmw_merged;
					wb_idle <= 5'd0;
					sd_ack <= 1'b1;
					ats <= A_ACK;
					if (bc_alloc) begin
						bc_beat1 <= rmw_merged;
						bc_addr1 <= a_addr;
						bc_v1 <= 1'b1;
					end
					else begin
						bc_beat0 <= rmw_merged;
						bc_addr0 <= a_addr;
						bc_v0 <= 1'b1;
					end
					bc_lru <= ~bc_alloc;
					bc_lastwr <= bc_alloc;
					bc_lastwr_v <= 1'b1;
					awt_req <= rc_valid && (a_addr[15:7] == rc_row);
					awt_col <= a_addr[6:0];
					awt_data <= rmw_merged;
					asrcwt_req <= (a_addr[15:7] == 9'd510) || (a_addr[15:7] == 9'd511);
					asrcwt_idx <= {a_addr[15:7] == 9'd511, a_addr[6:0]};
					asrcwt_data <= rmw_merged;
				end
				A_ACK: ats <= A_IDLE;
				A_FLUSH:
					if (a_done) begin
						a_start <= 1'b0;
						a_wr <= 1'b0;
						wb_v <= 1'b0;
						if (flush_pend) begin
							a_addr <= a_addr_save;
							ats <= A_DEC;
						end
						else
							ats <= A_IDLE;
					end
				default: ats <= A_IDLE;
			endcase
			if (c_start && c_wr) begin
				if (bc_v0 && (bc_addr0 == c_addr))
					bc_v0 <= 1'b0;
				if (bc_v1 && (bc_addr1 == c_addr))
					bc_v1 <= 1'b0;
			end
			if (d_add) begin
				if (bc_v0 && (bc_addr0 == {10'd0, d_add_beat}))
					bc_v0 <= 1'b0;
				if (bc_v1 && (bc_addr1 == {10'd0, d_add_beat}))
					bc_v1 <= 1'b0;
			end
			if ((d_start && d_wr) && !d_is_burst) begin
				if (bc_v0 && (bc_addr0 == d_addr))
					bc_v0 <= 1'b0;
				if (bc_v1 && (bc_addr1 == d_addr))
					bc_v1 <= 1'b0;
			end
			if (e_write_invalidate) begin
				bc_v0 <= 1'b0;
				bc_v1 <= 1'b0;
				bc_lastwr_v <= 1'b0;
			end
			if (((c_start && c_wr) && wb_v) && (wb_addr == c_addr))
				wb_v <= 1'b0;
			if ((d_add && wb_v) && (wb_addr == {10'd0, d_add_beat}))
				wb_v <= 1'b0;
			if ((((d_start && d_wr) && !d_is_burst) && wb_v) && (wb_addr == d_addr))
				wb_v <= 1'b0;
		end
	(* ramstyle = "no_rw_check" *) reg [63:0] rc [0:127];
	(* preserve, dont_merge *) reg bsn_commit_v;
	(* preserve, dont_merge *) reg [6:0] bsn_commit_addr;
	(* preserve, dont_merge *) reg [63:0] bsn_commit_data;
	reg bsn_commit_done_q;
	reg wtp_v;
	reg [6:0] wtp_col;
	reg [63:0] wtp_data;
	reg [8:0] wtp_row;
	wire [8:0] req_row = scan_addr[17:9];
	wire [8:0] req_col = scan_addr[8:0];
	reg [63:0] rc_q;
	wire [6:0] rc_raddr = req_col[8:2];
	reg [1:0] rc_rlane;
	always @(posedge clk) rc_q <= rc[rc_raddr];
	reg b_start;
	reg [25:0] b_addr;
	reg [7:0] b_burstlen;
	reg b_done;
	wire b_rd_valid;
	wire [63:0] b_rdata;
	reg [7:0] fillbeat;
	reg [8:0] fill_row;
	(* preserve, dont_merge *) reg [8:0] bsn_fill_row_q;
	(* preserve, dont_merge *) reg [6:0] bsn_fillbeat_q;
	(* dont_merge *) reg [8:0] park_row;
	localparam [7:0] BMAX = 8'd32;
	localparam [2:0] B_IDLE = 3'd0;
	localparam [2:0] B_REQ = 3'd1;
	localparam [2:0] B_FILL = 3'd2;
	localparam [2:0] B_HIT = 3'd3;
	localparam [2:0] B_WAIT = 3'd4;
	localparam [2:0] B_DRAIN = 3'd5;
	localparam [2:0] B_COMMIT = 3'd6;
	reg [2:0] bts;
	assign b_fill_lock = (((bts == B_DRAIN) || (bts == B_REQ)) || (bts == B_FILL)) || (bts == B_COMMIT);
	assign b_bus_lock = (bts == B_REQ) || (bts == B_FILL);
	always @(posedge clk)
		if (rst) begin
			bts <= B_IDLE;
			b_start <= 1'b0;
			b_addr <= 26'd0;
			b_burstlen <= 8'd0;
			rc_valid <= 1'b0;
			rc_row <= 9'd0;
			fillbeat <= 8'd0;
			bsn_fillbeat_q <= 7'd0;
			fill_row <= 9'd0;
			bsn_fill_row_q <= 9'd0;
			park_row <= 9'd0;
			rc_rlane <= 2'd0;
			scan_ack <= 1'b0;
			scan_data <= 16'd0;
			wtp_v <= 1'b0;
			wtp_col <= 7'd0;
			wtp_data <= 64'd0;
			wtp_row <= 9'd0;
			bsn_commit_v <= 1'b0;
			bsn_commit_addr <= 7'd0;
			bsn_commit_data <= 64'd0;
			bsn_commit_done_q <= 1'b0;
		end
		else begin
			scan_ack <= 1'b0;
			bsn_commit_v <= (bts == B_FILL) && b_rd_valid;
			if ((bts == B_FILL) && b_rd_valid) begin
				bsn_commit_addr <= bsn_fillbeat_q;
				bsn_commit_data <= bfill_merged;
			end
			case (bts)
				B_IDLE:
					if (scan_req) begin
						if ((rc_valid && (rc_row == req_row)) && (!dbl_on || (rc_fbsel == fb_sel))) begin
							rc_rlane <= req_col[1:0];
							bts <= B_HIT;
						end
						else begin
							fillbeat <= 8'd0;
							bsn_fillbeat_q <= 7'd0;
							bsn_commit_done_q <= 1'b0;
							fill_row <= req_row;
							bsn_fill_row_q <= req_row;
							park_row <= req_row;
							rc_valid <= 1'b0;
							wtp_v <= 1'b0;
							bts <= B_REQ;
						end
					end
				B_DRAIN:
					if ((((((((ats == A_IDLE) && !a_start) && !wb_v) && !d_busy) && !d_start) && !c_start) && (ls == 2'd0)) && !tst_busy)
						bts <= B_REQ;
				B_REQ: begin
					b_addr <= {10'd0, fill_row, 7'd0} + {18'd0, fillbeat};
					b_burstlen <= ((8'd128 - fillbeat) > BMAX ? BMAX : 8'd128 - fillbeat);
					b_start <= 1'b1;
					bts <= B_FILL;
				end
				B_FILL: begin
					if (b_rd_valid) begin
						fillbeat <= fillbeat + 8'd1;
						bsn_fillbeat_q <= fillbeat[6:0] + 7'd1;
					end
					if (b_done) begin
						b_start <= 1'b0;
						if (fillbeat >= 8'd128) begin
							if (bsn_commit_done_q || (bsn_commit_v && (bsn_commit_addr == 7'd127))) begin
								rc_valid <= 1'b1;
								rc_fbsel <= fb_sel;
								rc_row <= fill_row;
								bts <= B_IDLE;
							end
							else
								bts <= B_COMMIT;
						end
						else
							bts <= B_REQ;
					end
				end
				B_COMMIT:
					if (bsn_commit_done_q || (bsn_commit_v && (bsn_commit_addr == 7'd127))) begin
						rc_valid <= 1'b1;
						rc_fbsel <= fb_sel;
						rc_row <= fill_row;
						bts <= B_IDLE;
					end
				B_HIT: begin
					case (rc_rlane)
						2'd0: scan_data <= rc_q[15:0];
						2'd1: scan_data <= rc_q[31:16];
						2'd2: scan_data <= rc_q[47:32];
						default: scan_data <= rc_q[63:48];
					endcase
					scan_ack <= 1'b1;
					bts <= B_WAIT;
				end
				B_WAIT:
					if (!scan_req)
						bts <= B_IDLE;
				default: bts <= B_IDLE;
			endcase
			if (bsn_commit_v) begin
				rc[bsn_commit_addr] <= bsn_commit_data;
				if (bsn_commit_addr == 7'd127)
					bsn_commit_done_q <= 1'b1;
				if (wt_req) begin
					wtp_v <= 1'b1;
					wtp_col <= wt_col;
					wtp_data <= wt_data;
					wtp_row <= rc_row;
				end
			end
			else if (wtp_v) begin
				if (rc_valid && (rc_row == wtp_row))
					rc[wtp_col] <= wtp_data;
				wtp_v <= 1'b0;
				if (wt_req) begin
					wtp_v <= 1'b1;
					wtp_col <= wt_col;
					wtp_data <= wt_data;
					wtp_row <= rc_row;
				end
			end
			else if (wt_req)
				rc[wt_col] <= wt_data;
			if (e_write_invalidate && (rc_row == e_invalidate_row)) begin
				rc_valid <= 1'b0;
				wtp_v <= 1'b0;
			end
		end
	(* ramstyle = "no_rw_check" *) reg [63:0] src_cache [0:255];
	reg src510_valid;
	reg src511_valid;
	reg [63:0] src_q;
	reg [7:0] src_raddr;
	wire srt_stream = (est == E_WREQ) || (est == E_WSTREAM);
	wire [7:0] src_cache_raddr = (srt_stream ? e_fill[7:0] + {7'd0, e_burst_next} : src_raddr);
	always @(posedge clk) src_q <= src_cache[src_cache_raddr];
	reg [8:0] req_row_d;
	always @(posedge clk) req_row_d <= req_row;
	wire row_changed = req_row != req_row_d;
	wire trig_wrap = req_row < req_row_d;
	wire [8:0] trig_nr = req_row - 9'd1;
	wire trig_row_ok = (trig_nr != 9'd510) && (trig_nr != 9'd511);
	wire ev_row_ok = erase_line_row < 9'd510;
	always @(posedge clk)
		if (rst) begin
			fb_sel <= 1'b0;
			dbl_arm <= 1'b0;
		end
		else begin
			if (fb_we)
				dbl_arm <= 1'b1;
			if (dbl_on && trig_wrap)
				fb_sel <= ~fb_sel;
		end
	wire sel_back = dbl_on & fb_sel;
	wire sel_front = dbl_on & ~fb_sel;
	reg [8:0] er_goal;
	reg er_goal_v;
	reg er_snap;
	reg er_stale;
	localparam [8:0] ER_MAX_LAG = 9'd8;
	reg [8:0] er_next;
	reg er_resync_pending;
	reg [8:0] er_resync_row;
	wire erase_first_resync = (erase_line_valid && ev_row_ok) && (erase_line_first === 1'b1);
	wire [8:0] er_lag = er_goal - er_next;
	wire er_pending = (er_goal_v && erase_en) && (er_lag < 9'd256);
	reg [63:0] c_wdata;
	reg [7:0] c_burstlen;
	reg c_done;
	wire c_rd_valid;
	wire [63:0] c_rdata;
	wire [8:0] e_fill_rd_n = e_fill + (e_rd_valid ? 9'd1 : 9'd0);
	wire srt_load_complete = ((est == E_RFILL) && e_done) && (e_fill_rd_n >= 9'd256);
	wire srt_snapshot_release = ((est == E_FIN) && e_op_we) && ((e_base_entry == 18'h1f800) || (e_base_entry == 18'h3f800));
	wire srcwt_cache_allow = !srt_snapshot_hold;
	localparam [7:0] CB_MAX = 8'd16;
	reg [63:0] cb_data [0:15];
	reg [4:0] c_stg;
	localparam [4:0] C_STG_READY = 5'd17;
	wire c_is_burst = c_wr && (c_burstlen > 8'd1);
	reg [8:0] erase_row;
	reg [6:0] c_beat;
	reg [7:0] c_fill;
	reg c_fill_which;
	wire erase_par = erase_row[0];
	wire next_par = er_next[0];
	wire next_srcv = (next_par ? src511_valid : src510_valid);
	localparam [2:0] C_IDLE = 3'd0;
	localparam [2:0] C_FILL_REQ = 3'd1;
	localparam [2:0] C_FILL_RCV = 3'd2;
	localparam [2:0] C_STAGE = 3'd3;
	localparam [2:0] C_BWR = 3'd4;
	reg [2:0] cts;
	assign erase_busy = cts != C_IDLE;
	reg swp_v;
	reg [7:0] swp_idx;
	reg [63:0] swp_data;
	always @(posedge clk)
		if (rst) begin
			cts <= C_IDLE;
			c_start <= 1'b0;
			c_wr <= 1'b0;
			c_addr <= 26'd0;
			c_wdata <= 64'd0;
			c_burstlen <= 8'd1;
			c_beat <= 7'd0;
			c_stg <= 5'd0;
			c_fill <= 8'd0;
			c_fill_which <= 1'b0;
			erase_row <= 9'd0;
			src_raddr <= 8'd0;
			src510_valid <= 1'b0;
			src511_valid <= 1'b0;
			swp_v <= 1'b0;
			swp_idx <= 8'd0;
			swp_data <= 64'd0;
			srt_snapshot_hold <= 1'b0;
			er_goal <= 9'd0;
			er_goal_v <= 1'b0;
			er_next <= 9'd0;
			er_resync_pending <= 1'b0;
			er_resync_row <= 9'd0;
		end
		else begin
			if (srcwt_req && srcwt_cache_allow) begin
				if (srcwt_idx[7])
					src511_valid <= 1'b1;
				else
					src510_valid <= 1'b1;
			end
			if (srt_load_complete) begin
				src510_valid <= 1'b1;
				src511_valid <= 1'b1;
				srt_snapshot_hold <= 1'b1;
			end
			if (srt_snapshot_release) begin
				srt_snapshot_hold <= 1'b0;
				src510_valid <= 1'b0;
				src511_valid <= 1'b0;
			end
			if (erase_line_valid && ev_row_ok) begin
				er_goal <= erase_line_row;
				er_goal_v <= 1'b1;
			end
			if (!erase_en)
				er_next <= er_goal + 9'd1;
			er_snap = erase_first_resync;
			er_stale = ((((er_goal_v && erase_en) && !er_snap) && !er_resync_pending) && ((er_goal - er_next) < 9'd256)) && ((er_goal - er_next) > ER_MAX_LAG);
			case (cts)
				C_IDLE:
					if (((!er_snap && !er_resync_pending) && er_pending) && ((er_next == 9'd510) || (er_next == 9'd511)))
						er_next <= er_next + 9'd1;
					else if (((((er_pending && !er_snap) && !er_resync_pending) && !er_stale) && !e_block) && !srt_snapshot_hold) begin
						erase_row <= er_next;
						src_raddr <= {next_par, 7'd0};
						c_beat <= 7'd0;
						if (!next_srcv) begin
							c_fill <= 8'd0;
							c_fill_which <= next_par;
							cts <= C_FILL_REQ;
						end
						else begin
							c_stg <= 5'd0;
							cts <= C_STAGE;
						end
					end
				C_FILL_REQ:
					if (!b_fill_lock) begin
						c_addr <= {10'd0, (c_fill_which ? 9'd511 : 9'd510), 7'd0} + {18'd0, c_fill};
						c_burstlen <= ((8'd128 - c_fill) > BMAX ? BMAX : 8'd128 - c_fill);
						c_wr <= 1'b0;
						c_start <= 1'b1;
						cts <= C_FILL_RCV;
					end
				C_FILL_RCV: begin
					if (c_rd_valid)
						c_fill <= c_fill + 8'd1;
					if (c_done) begin
						c_start <= 1'b0;
						if (c_fill >= 8'd128) begin
							if (c_fill_which)
								src511_valid <= 1'b1;
							else
								src510_valid <= 1'b1;
							src_raddr <= {c_fill_which, 7'd0};
							c_stg <= 5'd0;
							cts <= C_STAGE;
						end
						else
							cts <= C_FILL_REQ;
					end
				end
				C_STAGE:
					if (c_stg == 5'd0) begin
						src_raddr <= {erase_par, c_beat + 7'd1};
						c_stg <= 5'd1;
					end
					else if (c_stg == C_STG_READY) begin
						if (!b_fill_lock) begin
							c_addr <= {10'd0, erase_row, c_beat};
							c_burstlen <= CB_MAX;
							c_wr <= 1'b1;
							c_start <= 1'b1;
							cts <= C_BWR;
						end
					end
					else begin
						cb_data[c_stg[3:0] - 4'd1] <= src_q;
						if (c_stg == CB_MAX[4:0]) begin
							if (!b_fill_lock) begin
								c_addr <= {10'd0, erase_row, c_beat};
								c_burstlen <= CB_MAX;
								c_wr <= 1'b1;
								c_start <= 1'b1;
								cts <= C_BWR;
							end
							else
								c_stg <= C_STG_READY;
						end
						else begin
							src_raddr <= {erase_par, (c_beat + {2'b00, c_stg}) + 7'd1};
							c_stg <= c_stg + 5'd1;
						end
					end
				C_BWR:
					if (c_done) begin
						c_start <= 1'b0;
						if ((c_beat + CB_MAX[6:0]) == 7'd0) begin
							if (!er_snap && !er_resync_pending)
								er_next <= er_next + 9'd1;
							if (((!er_snap && !er_resync_pending) && (erase_row == er_goal)) && !(erase_line_valid && ev_row_ok))
								er_goal_v <= 1'b0;
							cts <= C_IDLE;
						end
						else begin
							c_beat <= c_beat + CB_MAX[6:0];
							src_raddr <= {erase_par, c_beat + CB_MAX[6:0]};
							c_stg <= 5'd0;
							cts <= C_STAGE;
						end
					end
				default: cts <= C_IDLE;
			endcase
			if (erase_first_resync) begin
				er_resync_pending <= 1'b1;
				er_resync_row <= erase_line_row;
			end
			if ((er_resync_pending && (cts == C_IDLE)) && !erase_first_resync) begin
				er_next <= er_resync_row;
				er_resync_pending <= 1'b0;
			end
			if (er_snap && !erase_first_resync)
				er_next <= trig_nr;
			else if (er_stale)
				er_next <= er_goal - ER_MAX_LAG;
			if (((est == E_RFILL) && e_rd_valid) && !e_op_we)
				src_cache[e_fill[7:0]] <= e_rdata;
			else if ((cts == C_FILL_RCV) && c_rd_valid) begin
				src_cache[{c_fill_which, c_fill[6:0]}] <= c_rdata;
				if (srcwt_req) begin
					swp_v <= 1'b1;
					swp_idx <= srcwt_idx;
					swp_data <= srcwt_data;
				end
			end
			else if (srcwt_req && srcwt_cache_allow) begin
				src_cache[srcwt_idx] <= srcwt_data;
				if (swp_v && (swp_idx == srcwt_idx))
					swp_v <= 1'b0;
			end
			else if (swp_v && srcwt_cache_allow) begin
				src_cache[swp_idx] <= swp_data;
				swp_v <= 1'b0;
			end
		end
	localparam FBCOMB = 1'b1;
	reg [15:0] wc_beat;
	(* preserve, dont_merge *) reg [15:0] ack_wc_beat_q;
	(* preserve, dont_merge *) reg [15:0] bsn_wc_beat_q;
	reg [3:0] wc_mask;
	reg [63:0] wc_data;
	reg [7:0] wc_idle;
	localparam [7:0] FB_WFLUSH_IDLE = 8'd64;
	reg cmb_fb_we_d;
	reg fb_pend;
	wire [15:0] fb_beat = fb_addr[17:2];
	wire fb_same = (FBCOMB && (wc_mask != 4'd0)) && (fb_beat == ack_wc_beat_q);
	wire fb_new = fb_we & ~cmb_fb_we_d;
	wire fb_req = fb_new | fb_pend;
	wire fb_fill_park = (b_fill_lock && fb_req) && (fb_beat[15:7] == park_row);
	wire d_flush_req = (wc_mask != 4'd0) && (((((((fb_req && !fb_same) || (wc_idle >= FB_WFLUSH_IDLE)) || a_start) || a_req_pending) || fb_fill_park) || fb_flush) || e_block);
	reg [63:0] d_wdata;
	reg [7:0] d_be;
	reg d_done;
	wire d_rd_valid;
	wire [63:0] d_rdata;
	reg [63:0] d_fwd;
	reg [15:0] d_fwd_beat;
	reg d_fwd_v;
	reg [3:0] df_mask;
	reg [63:0] df_data;
	reg [15:0] df_beat;
	localparam [2:0] D_IDLE = 3'd0;
	localparam [2:0] D_RD = 3'd1;
	localparam [2:0] D_MRG = 3'd2;
	localparam [2:0] D_WR = 3'd3;
	localparam [2:0] D_WRB = 3'd4;
	reg [2:0] dst;
	localparam [3:0] RB_MAX = 4'd8;
	reg [63:0] rb_data [0:7];
	reg [15:0] rb_base;
	reg [3:0] rb_cnt;
	reg [7:0] rb_idle;
	reg [7:0] d_blen;
	(* preserve, dont_merge *) reg [3:0] bsn_d_blen_q;
	reg [3:0] wstream_idx;
	assign d_busy = ((dst != D_IDLE) || (wc_mask != 4'd0)) || (rb_cnt != 4'd0);
	assign fb_busy = d_busy;
	function automatic [63:0] d_lane_merge;
		input [63:0] base;
		input [63:0] neu;
		input [3:0] m;
		d_lane_merge = {(m[3] ? neu[63:48] : base[63:48]), (m[2] ? neu[47:32] : base[47:32]), (m[1] ? neu[31:16] : base[31:16]), (m[0] ? neu[15:0] : base[15:0])};
	endfunction
	wire [63:0] d_ownmerge = d_lane_merge(d_fwd, wc_data, wc_mask);
	wire [63:0] d_wbmerge = d_lane_merge(wb_data, wc_data, wc_mask);
	wire fbeat_full = wc_mask == 4'hf;
	wire rb_ext = ((rb_cnt != 4'd0) && (rb_cnt < RB_MAX)) && (wc_beat == (rb_base + {12'd0, rb_cnt}));
	wire d_want_fire = ((rb_cnt != 4'd0) && d_flush_req) && (fbeat_full ? !rb_ext : 1'b1);
	wire flush_now = (dst == D_IDLE) && d_flush_req;
	wire accept = ((((fb_req && !a_claim) && !fb_fill_park) && !e_block) && ((wc_mask == 4'd0) || fb_same)) && !flush_now;
	always @(*) begin
		if (_sv2v_0)
			;
		fb_ack = accept;
	end
	always @(posedge clk)
		if (rst) begin
			wc_beat <= 16'd0;
			ack_wc_beat_q <= 16'd0;
			bsn_wc_beat_q <= 16'd0;
			wc_mask <= 4'd0;
			wc_data <= 64'd0;
			wc_idle <= 8'd0;
			cmb_fb_we_d <= 1'b0;
			fb_pend <= 1'b0;
			d_start <= 1'b0;
			d_wr <= 1'b0;
			d_addr <= 26'd0;
			bsn_d_addr_q <= 16'd0;
			d_wdata <= 64'd0;
			d_be <= 8'd0;
			d_fwd <= 64'd0;
			d_fwd_beat <= 16'd0;
			d_fwd_v <= 1'b0;
			df_mask <= 4'd0;
			df_data <= 64'd0;
			df_beat <= 16'd0;
			dst <= D_IDLE;
			dwt_req <= 1'b0;
			dwt_col <= 7'd0;
			dwt_data <= 64'd0;
			dsrcwt_req <= 1'b0;
			dsrcwt_idx <= 8'd0;
			dsrcwt_data <= 64'd0;
			rb_base <= 16'd0;
			rb_cnt <= 4'd0;
			rb_idle <= 8'd0;
			d_blen <= 8'd0;
			bsn_d_blen_q <= 4'd0;
			d_is_burst <= 1'b0;
			d_add <= 1'b0;
			d_add_beat <= 16'd0;
		end
		else begin
			cmb_fb_we_d <= fb_we;
			dwt_req <= 1'b0;
			dsrcwt_req <= 1'b0;
			d_add <= 1'b0;
			if (((c_start && c_wr) && d_fwd_v) && (d_fwd_beat[15:7] == c_addr[15:7]))
				d_fwd_v <= 1'b0;
			if ((e_write_invalidate && d_fwd_v) && (d_fwd_beat[15:7] == e_invalidate_row))
				d_fwd_v <= 1'b0;
			if ((wc_mask != 4'd0) && (wc_idle != 8'hff))
				wc_idle <= wc_idle + 8'd1;
			if ((rb_cnt != 4'd0) && (rb_idle != 8'hff))
				rb_idle <= rb_idle + 8'd1;
			if (accept) begin
				fb_pend <= 1'b0;
				wc_beat <= fb_beat;
				ack_wc_beat_q <= fb_beat;
				bsn_wc_beat_q <= fb_beat;
				wc_mask[fb_addr[1:0]] <= 1'b1;
				wc_data[fb_addr[1:0] * 16+:16] <= fb_wdata;
				wc_idle <= 8'd0;
			end
			else if (fb_new)
				fb_pend <= 1'b1;
			if (dst == D_IDLE) begin
				if ((rb_cnt != 4'd0) && (((((((a_start || a_req_pending) || fb_fill_park) || (rb_cnt == RB_MAX)) || (rb_idle >= FB_WFLUSH_IDLE)) || d_want_fire) || fb_flush) || e_block)) begin
					d_addr <= {10'd0, rb_base};
					bsn_d_addr_q <= rb_base;
					d_blen <= {4'd0, rb_cnt};
					bsn_d_blen_q <= rb_cnt;
					d_wr <= 1'b1;
					d_start <= 1'b1;
					d_is_burst <= 1'b1;
					dst <= D_WRB;
					rb_cnt <= 4'd0;
					rb_idle <= 8'd0;
					d_fwd_v <= 1'b0;
				end
				else if (d_flush_req) begin
					if (fbeat_full) begin
						if (rb_cnt == 4'd0)
							rb_base <= wc_beat;
						rb_data[rb_cnt] <= wc_data;
						rb_cnt <= rb_cnt + 4'd1;
						rb_idle <= 8'd0;
						wc_mask <= 4'd0;
						d_add <= 1'b1;
						d_add_beat <= wc_beat;
						dwt_req <= rc_valid && (wc_beat[15:7] == rc_row);
						dwt_col <= wc_beat[6:0];
						dwt_data <= wc_data;
						dsrcwt_req <= (wc_beat[15:7] == 9'd510) || (wc_beat[15:7] == 9'd511);
						dsrcwt_idx <= {wc_beat[15:7] == 9'd511, wc_beat[6:0]};
						dsrcwt_data <= wc_data;
						d_fwd_v <= 1'b0;
					end
					else if (wb_v && (wb_addr == {10'd0, wc_beat})) begin
						df_mask <= wc_mask;
						df_data <= wc_data;
						df_beat <= wc_beat;
						wc_mask <= 4'd0;
						d_wdata <= d_wbmerge;
						d_addr <= {10'd0, wc_beat};
						bsn_d_addr_q <= wc_beat;
						d_be <= 8'hff;
						d_wr <= 1'b1;
						d_start <= 1'b1;
						d_is_burst <= 1'b0;
						dst <= D_WR;
						d_fwd <= d_wbmerge;
						d_fwd_beat <= wc_beat;
						d_fwd_v <= 1'b1;
						dwt_req <= rc_valid && (wc_beat[15:7] == rc_row);
						dwt_col <= wc_beat[6:0];
						dwt_data <= d_wbmerge;
						dsrcwt_req <= (wc_beat[15:7] == 9'd510) || (wc_beat[15:7] == 9'd511);
						dsrcwt_idx <= {wc_beat[15:7] == 9'd511, wc_beat[6:0]};
						dsrcwt_data <= d_wbmerge;
					end
					else if (d_fwd_v && (d_fwd_beat == wc_beat)) begin
						df_mask <= wc_mask;
						df_data <= wc_data;
						df_beat <= wc_beat;
						wc_mask <= 4'd0;
						d_wdata <= d_ownmerge;
						d_addr <= {10'd0, wc_beat};
						bsn_d_addr_q <= wc_beat;
						d_be <= 8'hff;
						d_wr <= 1'b1;
						d_start <= 1'b1;
						d_is_burst <= 1'b0;
						dst <= D_WR;
						d_fwd <= d_ownmerge;
						d_fwd_beat <= wc_beat;
						dwt_req <= rc_valid && (wc_beat[15:7] == rc_row);
						dwt_col <= wc_beat[6:0];
						dwt_data <= d_ownmerge;
						dsrcwt_req <= (wc_beat[15:7] == 9'd510) || (wc_beat[15:7] == 9'd511);
						dsrcwt_idx <= {wc_beat[15:7] == 9'd511, wc_beat[6:0]};
						dsrcwt_data <= d_ownmerge;
					end
					else begin
						df_mask <= wc_mask;
						df_data <= wc_data;
						df_beat <= wc_beat;
						wc_mask <= 4'd0;
						d_addr <= {10'd0, wc_beat};
						bsn_d_addr_q <= wc_beat;
						d_wr <= 1'b0;
						d_start <= 1'b1;
						d_is_burst <= 1'b0;
						dst <= D_RD;
					end
				end
			end
			case (dst)
				D_RD: begin
					if (d_rd_valid)
						d_wdata <= d_lane_merge((shw_en && shw_base_hit ? shw_base : d_rdata), df_data, df_mask);
					if (d_done) begin
						d_start <= 1'b0;
						dst <= D_MRG;
					end
				end
				D_MRG: begin
					d_addr <= {10'd0, df_beat};
					bsn_d_addr_q <= df_beat;
					d_be <= 8'hff;
					d_wr <= 1'b1;
					d_start <= 1'b1;
					d_fwd <= d_wdata;
					d_fwd_beat <= df_beat;
					d_fwd_v <= 1'b1;
					dwt_req <= rc_valid && (df_beat[15:7] == rc_row);
					dwt_col <= df_beat[6:0];
					dwt_data <= d_wdata;
					dsrcwt_req <= (df_beat[15:7] == 9'd510) || (df_beat[15:7] == 9'd511);
					dsrcwt_idx <= {df_beat[15:7] == 9'd511, df_beat[6:0]};
					dsrcwt_data <= d_wdata;
					dst <= D_WR;
				end
				D_WR:
					if (d_done) begin
						d_start <= 1'b0;
						d_wr <= 1'b0;
						d_is_burst <= 1'b0;
						dst <= D_IDLE;
					end
				D_WRB:
					if (d_done) begin
						d_start <= 1'b0;
						d_wr <= 1'b0;
						d_is_burst <= 1'b0;
						dst <= D_IDLE;
					end
				default:
					;
			endcase
		end
	assign e_block = est != E_IDLE;
	assign shift_ready = est == E_IDLE;
	assign e_write_invalidate = e_op_we && ((est == E_INV0) || (est == E_INV1));
	assign e_invalidate_row = e_base_entry[17:9] + (est == E_INV1 ? 9'd1 : 9'd0);
	assign shift_invalidate_valid = e_write_invalidate;
	assign shift_invalidate_row = e_invalidate_row;
	wire [15:0] bfill_bt = {bsn_fill_row_q, bsn_fillbeat_q};
	wire [15:0] bsn_bstoff = bfill_bt - bsn_d_addr_q;
	wire bsn_burst = ((d_start && d_wr) && d_is_burst) && ({8'd0, bsn_bstoff} < {20'd0, bsn_d_blen_q});
	wire bsn_single = ((d_start && d_wr) && !d_is_burst) && (bsn_d_addr_q == bfill_bt);
	wire bsn_rmwjob = ((dst == D_RD) || (dst == D_MRG)) && (df_beat == bfill_bt);
	wire [15:0] bsn_rboff = bfill_bt - rb_base;
	wire bsn_rbacc = ((rb_cnt != 4'd0) && ({12'd0, bsn_rboff[3:0]} < {12'd0, rb_cnt})) && (bsn_rboff[15:4] == 12'd0);
	always @(*) begin
		if (_sv2v_0)
			;
		bfill_merged = b_rdata;
		if (((((shw_en && !dbl_on) && shw_v_q) && shw_q[69]) && (shw_q[68:64] == bfill_bt[15:11])) && (shw_cand_q == bfill_bt))
			bfill_merged = shw_q[63:0];
		if (d_fwd_v && (d_fwd_beat == bfill_bt))
			bfill_merged = d_fwd;
		if (wb_v && (wb_addr[15:0] == bfill_bt))
			bfill_merged = wb_data;
		if (bsn_burst)
			bfill_merged = rb_data[bsn_bstoff[2:0]];
		if (bsn_rbacc)
			bfill_merged = rb_data[bsn_rboff[2:0]];
		if (bsn_single)
			bfill_merged = d_wdata;
		if (bsn_rmwjob)
			bfill_merged = d_lane_merge(bfill_merged, df_data, df_mask);
		if ((wc_mask != 4'd0) && (bsn_wc_beat_q == bfill_bt))
			bfill_merged = d_lane_merge(bfill_merged, wc_data, wc_mask);
	end
	reg tst_wr_req;
	reg tst_rd_req;
	reg [25:0] tst_addr;
	reg [63:0] tst_wdata_lat;
	wire [63:0] tst_rdata;
	wire [63:0] tst_wdata;
	wire tst_wnext;
	wire d_burst_next;
	reg [7:0] tst_be;
	reg [7:0] tst_burstcnt;
	wire tst_rd_valid;
	reg [1:0] l_gnt;
	(* dont_merge *) reg shw_b_gnt;
	localparam [1:0] L_IDLE = 2'd0;
	localparam [1:0] L_ACCEPT = 2'd1;
	localparam [1:0] L_RUN = 2'd2;
	localparam [1:0] L_DONE = 2'd3;
	reg [3:0] pub_dirty;
	reg [15:0] pub_addr [0:3];
	reg [63:0] pub_expect [0:3];
	reg [1:0] pub_page;
	reg l_proof;
	wire tst_wr_done;
	wire [25:0] tst_wr_base;
	wire [7:0] tst_wr_count;
	wire [63:0] tst_wr_last_data;
	wire [15:0] pub_ret_base = tst_wr_base[15:0];
	wire [15:0] pub_ret_last = (tst_wr_base[15:0] + {8'd0, tst_wr_count}) - 16'd1;
	wire [3:0] pub_ret_mask = (4'b0001 << pub_ret_base[15:14]) | (4'b0001 << pub_ret_last[15:14]);
	wire pub_hold = tst_wr_done;
	wire pub_match_evt;
	localparam signed [31:0] PG_WINDOW = 2047;
	reg [15:0] pg_base [0:3];
	reg [15:0] pg_last [0:3];
	reg [10:0] pg_age [0:3];
	reg [1:0] pg_wr;
	integer pge;
	function automatic signed [10:0] sv2v_cast_11_signed;
		input reg signed [10:0] inp;
		sv2v_cast_11_signed = inp;
	endfunction
	always @(posedge clk)
		if (sdram_por) begin
			for (pge = 0; pge < 4; pge = pge + 1)
				begin
					pg_base[pge] <= 16'd0;
					pg_last[pge] <= 16'd0;
					pg_age[pge] <= 11'd0;
				end
			pg_wr <= 2'd0;
		end
		else begin
			for (pge = 0; pge < 4; pge = pge + 1)
				if (pg_age[pge] != 11'd0)
					pg_age[pge] <= pg_age[pge] - 11'd1;
			if (tst_wr_done) begin
				pg_base[pg_wr] <= pub_ret_base;
				pg_last[pg_wr] <= pub_ret_last;
				pg_age[pg_wr] <= sv2v_cast_11_signed(PG_WINDOW);
				pg_wr <= pg_wr + 2'd1;
			end
		end
	reg [7:0] shw_cnt;
	wire [15:0] shw_wa = tst_addr[15:0] + {8'd0, shw_cnt};
	always @(posedge clk)
		if (sdram_por) begin
			shw_cnt <= 8'd0;
			shw_valid <= 1'sb0;
		end
		else begin
			if (tst_wr_req)
				shw_cnt <= 8'd0;
			if (tst_wnext)
				shw_cnt <= shw_cnt + 8'd1;
			if (tst_wr_done) begin
				shw_mem[shw_index(pub_ret_last)] <= {1'b1, pub_ret_last[15:11], tst_wr_last_data};
				shw_valid[shw_index(pub_ret_last)] <= 1'b1;
			end
			else if (tst_wnext) begin
				shw_mem[shw_index(shw_wa)] <= {1'b1, shw_wa[15:11], tst_wdata};
				shw_valid[shw_index(shw_wa)] <= 1'b1;
			end
		end
	wire shw_b_rd_valid = ((shw_b_gnt && (ls == L_RUN)) && tst_rd_valid) && !l_proof;
	wire [15:0] shw_b_cand = bfill_bt + ((bts == B_FILL) && shw_b_rd_valid ? 16'd1 : 16'd0);
	wire [15:0] shw_cand = (bts == B_FILL ? shw_b_cand : (a_start && !a_wr ? a_addr[15:0] : d_addr[15:0]));
	wire [10:0] shw_cand_idx = shw_index(shw_cand);
	wire [15:0] shw_v_bank_d;
	assign shw_v_bank_d[0] = shw_valid[{shw_cand_idx[10:4], 4'h0}];
	assign shw_v_bank_d[1] = shw_valid[{shw_cand_idx[10:4], 4'h1}];
	assign shw_v_bank_d[2] = shw_valid[{shw_cand_idx[10:4], 4'h2}];
	assign shw_v_bank_d[3] = shw_valid[{shw_cand_idx[10:4], 4'h3}];
	assign shw_v_bank_d[4] = shw_valid[{shw_cand_idx[10:4], 4'h4}];
	assign shw_v_bank_d[5] = shw_valid[{shw_cand_idx[10:4], 4'h5}];
	assign shw_v_bank_d[6] = shw_valid[{shw_cand_idx[10:4], 4'h6}];
	assign shw_v_bank_d[7] = shw_valid[{shw_cand_idx[10:4], 4'h7}];
	assign shw_v_bank_d[8] = shw_valid[{shw_cand_idx[10:4], 4'h8}];
	assign shw_v_bank_d[9] = shw_valid[{shw_cand_idx[10:4], 4'h9}];
	assign shw_v_bank_d[10] = shw_valid[{shw_cand_idx[10:4], 4'ha}];
	assign shw_v_bank_d[11] = shw_valid[{shw_cand_idx[10:4], 4'hb}];
	assign shw_v_bank_d[12] = shw_valid[{shw_cand_idx[10:4], 4'hc}];
	assign shw_v_bank_d[13] = shw_valid[{shw_cand_idx[10:4], 4'hd}];
	assign shw_v_bank_d[14] = shw_valid[{shw_cand_idx[10:4], 4'he}];
	assign shw_v_bank_d[15] = shw_valid[{shw_cand_idx[10:4], 4'hf}];
	assign shw_v_q = shw_v_bank_q[shw_v_bank_sel_q];
	always @(posedge clk) begin
		shw_q <= shw_mem[shw_cand_idx];
		shw_v_bank_q <= shw_v_bank_d;
		shw_v_bank_sel_q <= shw_cand_idx[3:0];
		shw_cand_q <= shw_cand;
	end
	wire shw_q_hit = ((!dbl_on && shw_v_q) && shw_q[69]) && (shw_q[68:64] == shw_cand_q[15:11]);
	function automatic pg_overlap;
		input reg [15:0] lo;
		input reg [15:0] hi;
		pg_overlap = ((((pg_age[0] != 11'd0) && !((hi < pg_base[0]) || (lo > pg_last[0]))) || ((pg_age[1] != 11'd0) && !((hi < pg_base[1]) || (lo > pg_last[1])))) || ((pg_age[2] != 11'd0) && !((hi < pg_base[2]) || (lo > pg_last[2])))) || ((pg_age[3] != 11'd0) && !((hi < pg_base[3]) || (lo > pg_last[3])));
	endfunction
	wire a_shw_hit = shw_q_hit && (shw_cand_q == a_addr[15:0]);
	wire d_shw_hit = shw_q_hit && (shw_cand_q == d_addr[15:0]);
	wire a_lkp_cur = shw_cand_q == a_addr[15:0];
	wire d_lkp_cur = shw_cand_q == d_addr[15:0];
	wire pub_fence_en = !dbl_on;
	wire a_pub_hazard = ((pg_overlap(a_addr[15:0], a_addr[15:0]) && !a_shw_hit) || tst_wr_done) || !a_lkp_cur;
	wire d_pub_hazard = ((pg_overlap(d_addr[15:0], d_addr[15:0]) && !d_shw_hit) || tst_wr_done) || !d_lkp_cur;
	wire c_pub_hazard = pg_overlap(c_addr[15:0], (c_addr[15:0] + {8'd0, c_burstlen}) - 16'd1) || tst_wr_done;
	wire e_pub_hazard = pg_overlap(e_base_beat[15:0], e_base_beat[15:0] + 16'd255) || tst_wr_done;
	integer pgi;
	always @(posedge clk)
		if (sdram_por) begin
			pub_dirty <= 4'b0000;
			for (pgi = 0; pgi < 4; pgi = pgi + 1)
				begin
					pub_addr[pgi] <= 16'd0;
					pub_expect[pgi] <= 64'd0;
				end
		end
		else begin
			if (pub_match_evt)
				pub_dirty[pub_page] <= 1'b0;
			if (tst_wr_done) begin
				for (pgi = 0; pgi < 4; pgi = pgi + 1)
					if (pub_dirty[pgi] || pub_ret_mask[pgi]) begin
						pub_dirty[pgi] <= 1'b1;
						pub_addr[pgi] <= pub_ret_last;
						pub_expect[pgi] <= tst_wr_last_data;
					end
			end
		end
	assign tst_wdata = ((l_gnt == 2'd2) && e_start ? src_q : ((l_gnt == 2'd3) && d_is_burst ? rb_data[wstream_idx] : ((l_gnt == 2'd2) && c_is_burst ? cb_data[wstream_idx] : tst_wdata_lat)));
	assign d_burst_next = ((((l_gnt == 2'd3) && d_is_burst) || (((l_gnt == 2'd2) && c_is_burst) && !e_start)) && (ls == L_RUN)) && tst_wnext;
	assign e_burst_next = (((l_gnt == 2'd2) && e_start) && (ls == L_RUN)) && tst_wnext;
	always @(posedge clk)
		if (rst) begin
			ls <= L_IDLE;
			l_gnt <= 2'd0;
			shw_b_gnt <= 1'b0;
			tst_rd_req <= 1'b0;
			tst_wr_req <= 1'b0;
			tst_addr <= 26'd0;
			tst_wdata_lat <= 64'd0;
			tst_be <= 8'd0;
			tst_burstcnt <= 8'd1;
			a_done <= 1'b0;
			b_done <= 1'b0;
			c_done <= 1'b0;
			d_done <= 1'b0;
			wstream_idx <= 4'd0;
			l_proof <= 1'b0;
			pub_page <= 2'd0;
		end
		else begin
			tst_rd_req <= 1'b0;
			tst_wr_req <= 1'b0;
			a_done <= 1'b0;
			b_done <= 1'b0;
			c_done <= 1'b0;
			d_done <= 1'b0;
			if (d_burst_next)
				wstream_idx <= wstream_idx + 4'd1;
			case (ls)
				L_IDLE:
					if (!tst_busy) begin
						if (b_start) begin
							if ((B_SCAN_PROOF && pub_fence_en) && pub_hold)
								;
							else if ((B_SCAN_PROOF && pub_fence_en) && pub_dirty[b_addr[15:14]]) begin
								l_gnt <= 2'd1;
								shw_b_gnt <= 1'b1;
								l_proof <= 1'b1;
								pub_page <= b_addr[15:14];
								tst_addr <= {9'd0, sel_front, pub_addr[b_addr[15:14]]};
								tst_burstcnt <= 8'd1;
								tst_rd_req <= 1'b1;
								ls <= L_ACCEPT;
							end
							else begin
								l_gnt <= 2'd1;
								shw_b_gnt <= 1'b1;
								tst_addr <= {9'd0, sel_front, b_addr[15:0]};
								tst_burstcnt <= b_burstlen;
								tst_rd_req <= 1'b1;
								ls <= L_ACCEPT;
							end
						end
						else if (b_bus_lock)
							;
						else if (e_start) begin
							l_gnt <= 2'd2;
							shw_b_gnt <= 1'b0;
							tst_addr <= {9'd0, e_fbsel, e_addr[15:0]};
							tst_burstcnt <= e_blen;
							tst_be <= 8'hff;
							if (e_wr)
								tst_wr_req <= 1'b1;
							else
								tst_rd_req <= 1'b1;
							ls <= L_ACCEPT;
						end
						else if (a_start && !d_busy) begin
							if (!a_wr && a_pub_hazard)
								;
							else begin
								l_gnt <= 2'd0;
								shw_b_gnt <= 1'b0;
								tst_addr <= {9'd0, sel_back, a_addr[15:0]};
								tst_burstcnt <= 8'd1;
								if (a_wr) begin
									tst_wdata_lat <= a_wdata;
									tst_be <= a_be;
									tst_wr_req <= 1'b1;
								end
								else begin
									tst_rd_req <= 1'b1;
									shw_base <= shw_q[63:0];
									shw_base_hit <= a_shw_hit === 1'b1;
								end
								ls <= L_ACCEPT;
							end
						end
						else if (d_start) begin
							if ((!d_wr && !d_is_burst) && d_pub_hazard)
								;
							else begin
								l_gnt <= 2'd3;
								shw_b_gnt <= 1'b0;
								if (d_is_burst) begin
									tst_addr <= {9'd0, sel_back, d_addr[15:0]};
									tst_burstcnt <= d_blen;
									tst_be <= 8'hff;
									tst_wr_req <= 1'b1;
									wstream_idx <= 4'd0;
								end
								else begin
									tst_addr <= {9'd0, sel_back, d_addr[15:0]};
									tst_burstcnt <= 8'd1;
									if (d_wr) begin
										tst_wdata_lat <= d_wdata;
										tst_be <= d_be;
										tst_wr_req <= 1'b1;
									end
									else begin
										tst_rd_req <= 1'b1;
										shw_base <= shw_q[63:0];
										shw_base_hit <= d_shw_hit === 1'b1;
									end
								end
								ls <= L_ACCEPT;
							end
						end
						else if (c_start) begin
							if (!c_wr && c_pub_hazard)
								;
							else begin
								l_gnt <= 2'd2;
								shw_b_gnt <= 1'b0;
								tst_addr <= {9'd0, sel_back, c_addr[15:0]};
								tst_burstcnt <= c_burstlen;
								if (c_wr) begin
									tst_be <= 8'hff;
									tst_wr_req <= 1'b1;
									wstream_idx <= 4'd0;
								end
								else
									tst_rd_req <= 1'b1;
								ls <= L_ACCEPT;
							end
						end
					end
				L_ACCEPT:
					if (tst_busy)
						ls <= L_RUN;
				L_RUN:
					if (!tst_busy) begin
						if (!l_proof)
							case (l_gnt)
								2'd1: b_done <= 1'b1;
								2'd2: c_done <= 1'b1;
								2'd3: d_done <= 1'b1;
								default: a_done <= 1'b1;
							endcase
						l_proof <= 1'b0;
						ls <= L_DONE;
					end
				L_DONE: ls <= L_IDLE;
				default: ls <= L_IDLE;
			endcase
		end
	assign a_rd_valid = (((l_gnt == 2'd0) && (ls == L_RUN)) && tst_rd_valid) && !l_proof;
	assign b_rd_valid = (((l_gnt == 2'd1) && (ls == L_RUN)) && tst_rd_valid) && !l_proof;
	assign c_rd_valid = (((l_gnt == 2'd2) && (ls == L_RUN)) && tst_rd_valid) && !l_proof;
	assign d_rd_valid = (((l_gnt == 2'd3) && (ls == L_RUN)) && tst_rd_valid) && !l_proof;
	assign e_rd_valid = c_rd_valid && e_start;
	assign pub_match_evt = ((l_proof && (ls == L_RUN)) && tst_rd_valid) && (tst_rdata == pub_expect[pub_page]);
	assign a_rdata = tst_rdata;
	assign b_rdata = tst_rdata;
	assign c_rdata = tst_rdata;
	assign d_rdata = tst_rdata;
	assign e_rdata = tst_rdata;
	assign e_done = c_done;
	function automatic [7:0] sv2v_cast_8;
		input reg [7:0] inp;
		sv2v_cast_8 = inp;
	endfunction
	always @(posedge clk)
		if (rst) begin
			est <= E_IDLE;
			e_start <= 1'b0;
			e_wr <= 1'b0;
			e_addr <= 26'd0;
			e_blen <= 8'd1;
			e_fill <= 9'd0;
			e_base_entry <= 18'd0;
			e_base_beat <= 17'd0;
			e_op_we <= 1'b0;
			e_fbsel <= 1'b0;
			shift_done <= 1'b0;
			shift_rdata <= 16'd0;
		end
		else begin
			shift_done <= 1'b0;
			case (est)
				E_IDLE:
					if (shift_req && shift_ready) begin
						e_base_entry <= shift_entry;
						e_base_beat <= shift_entry[17:2];
						e_op_we <= shift_write;
						e_fbsel <= sel_back;
						e_fill <= 9'd0;
						est <= E_DRAIN;
					end
				E_DRAIN:
					if ((((((((((ats == A_IDLE) && !a_start) && !wb_v) && !d_busy) && !d_start) && (cts == C_IDLE)) && !swp_v) && (ls == L_IDLE)) && !tst_busy) && (e_op_we || !e_pub_hazard))
						est <= (e_op_we ? E_WREQ : E_RREQ);
				E_RREQ: begin
					e_addr <= {9'd0, e_base_beat} + {17'd0, e_fill};
					e_blen <= ((9'd256 - e_fill) > 9'h020 ? BMAX : sv2v_cast_8(9'd256 - e_fill));
					e_wr <= 1'b0;
					e_start <= 1'b1;
					est <= E_RFILL;
				end
				E_RFILL: begin
					if (e_rd_valid) begin
						if (e_fill == 9'd0)
							shift_rdata <= e_rdata[15:0];
						e_fill <= e_fill_rd_n;
					end
					if (e_done) begin
						e_start <= 1'b0;
						est <= (e_fill_rd_n >= 9'd256 ? E_FIN : E_RREQ);
					end
				end
				E_WREQ: begin
					e_addr <= {9'd0, e_base_beat} + {17'd0, e_fill};
					e_blen <= ((9'd256 - e_fill) > 9'h020 ? BMAX : sv2v_cast_8(9'd256 - e_fill));
					e_wr <= 1'b1;
					e_start <= 1'b1;
					est <= E_WSTREAM;
				end
				E_WSTREAM: begin
					if (e_burst_next)
						e_fill <= e_fill + 9'd1;
					if (e_done) begin
						e_start <= 1'b0;
						e_wr <= 1'b0;
						e_fill <= e_fill + 9'd1;
						est <= ((e_fill + 9'd1) >= 9'd256 ? E_INV0 : E_WREQ);
					end
				end
				E_INV0: est <= E_INV1;
				E_INV1: est <= E_FIN;
				E_FIN: begin
					shift_done <= 1'b1;
					est <= E_IDLE;
				end
				default: est <= E_IDLE;
			endcase
		end
	stv_vram_ddr_agent #(.VRAM_DDR_BASE(VRAM_DDR_BASE)) u_agent(
		.clk(clk),
		.sdram_por(sdram_por),
		.tst_wr_req(tst_wr_req),
		.tst_rd_req(tst_rd_req),
		.tst_addr(tst_addr),
		.tst_wdata(tst_wdata),
		.tst_be(tst_be),
		.tst_burstcnt(tst_burstcnt),
		.tst_rdata(tst_rdata),
		.tst_rd_valid(tst_rd_valid),
		.tst_busy(tst_busy),
		.tst_wnext(tst_wnext),
		.tst_wr_done(tst_wr_done),
		.tst_wr_base(tst_wr_base),
		.tst_wr_count(tst_wr_count),
		.tst_wr_last_data(tst_wr_last_data),
		.ddram_addr(ddram_addr),
		.ddram_burstcnt(ddram_burstcnt),
		.ddram_rd(ddram_rd),
		.ddram_we(ddram_we),
		.ddram_din(ddram_din),
		.ddram_be(ddram_be),
		.ddram_busy(ddram_busy),
		.ddram_dout(ddram_dout),
		.ddram_dout_ready(ddram_dout_ready)
	);
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_memsys (
	clk,
	rst,
	mem_req,
	mem_we,
	mem_addr,
	mem_size,
	mem_wdata,
	mem_rdata,
	mem_ack,
	src_req,
	src_addr,
	src_data,
	src_ack,
	inputs,
	game_id,
	game_gfx_bytes,
	term2_adc,
	term2_adc_sel,
	int1,
	snd_select,
	snd_trig,
	snd_reset,
	dbg_p1ctrl,
	dbg_bdir,
	cmos_quiesce,
	nvram_ext_en,
	nvram_ext_wr,
	nvram_ext_addr,
	nvram_ext_wdata,
	nvram_ext_rdata,
	cmos_cpu_busy,
	cmos_cpu_write_pulse,
	autoerase_enable,
	erase_start,
	erase_row0,
	erase_lines,
	erase_busy,
	erase_line_valid,
	erase_line_row,
	blit_busy,
	dma_render_overflow,
	dma_render_level,
	dma_vram_order_stall,
	fb_busy,
	fb_snoop_we,
	fb_snoop_addr,
	fb_snoop_data,
	dbg_dma_we,
	dbg_dma_addr,
	dbg_dma_wdata,
	cpu_gfx_rd,
	cpu_gfx_raddr,
	cpu_gfx_rdata,
	cpu_gfx_rack,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	sdram_por,
	ddram_addr,
	ddram_burstcnt,
	ddram_rd,
	ddram_we,
	ddram_din,
	ddram_be,
	ddram_busy,
	ddram_dout,
	ddram_dout_ready,
	palv_we_a,
	palv_aa,
	palv_awd,
	palv_we_b,
	palv_ba,
	palv_bwd
);
	reg _sv2v_0;
	parameter ROM_HEX = "smashtv_maindata.hex";
	parameter signed [31:0] ROM_WORDS = 32'h00020000;
	parameter signed [31:0] ROM_WORD_OFFSET = 32'h00060000;
	parameter signed [31:0] GFX_PIXELS = 32'h00180000;
	parameter signed [31:0] DMA_DESC_DEPTH = 512;
	input wire clk;
	input wire rst;
	input wire mem_req;
	input wire mem_we;
	input wire [31:0] mem_addr;
	input wire [5:0] mem_size;
	input wire [31:0] mem_wdata;
	output wire [31:0] mem_rdata;
	output wire mem_ack;
	output wire src_req;
	output wire [23:0] src_addr;
	input wire [7:0] src_data;
	input wire src_ack;
	input wire [63:0] inputs;
	input wire [3:0] game_id;
	input wire [23:0] game_gfx_bytes;
	input wire [7:0] term2_adc;
	output wire [1:0] term2_adc_sel;
	output wire int1;
	output wire [7:0] snd_select;
	output wire snd_trig;
	output wire snd_reset;
	output wire [31:0] dbg_p1ctrl;
	output wire [31:0] dbg_bdir;
	input wire cmos_quiesce;
	input wire nvram_ext_en;
	input wire nvram_ext_wr;
	input wire [14:0] nvram_ext_addr;
	input wire [7:0] nvram_ext_wdata;
	output wire [7:0] nvram_ext_rdata;
	output wire cmos_cpu_busy;
	output wire cmos_cpu_write_pulse;
	output wire autoerase_enable;
	input wire erase_start;
	input wire [8:0] erase_row0;
	input wire [9:0] erase_lines;
	output wire erase_busy;
	input wire erase_line_valid;
	input wire [8:0] erase_line_row;
	output wire blit_busy;
	output wire dma_render_overflow;
	output wire [9:0] dma_render_level;
	output wire dma_vram_order_stall;
	output wire fb_busy;
	output wire fb_snoop_we;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	output wire [17:0] fb_snoop_addr;
	output wire [15:0] fb_snoop_data;
	output wire dbg_dma_we;
	output wire [3:0] dbg_dma_addr;
	output wire [15:0] dbg_dma_wdata;
	output wire cpu_gfx_rd;
	output wire [23:0] cpu_gfx_raddr;
	input wire [15:0] cpu_gfx_rdata;
	input wire cpu_gfx_rack;
	input wire scan_req;
	input wire [17:0] scan_addr;
	output wire [15:0] scan_data;
	output wire scan_ack;
	input wire sdram_por;
	output wire [28:0] ddram_addr;
	output wire [7:0] ddram_burstcnt;
	output wire ddram_rd;
	output wire ddram_we;
	output wire [63:0] ddram_din;
	output wire [7:0] ddram_be;
	input wire ddram_busy;
	input wire [63:0] ddram_dout;
	input wire ddram_dout_ready;
	output wire palv_we_a;
	output wire [12:0] palv_aa;
	output wire [15:0] palv_awd;
	output wire palv_we_b;
	output wire [12:0] palv_ba;
	output wire [15:0] palv_bwd;
	wire is_dma_now = mem_addr[31:20] == 12'h01a;
	wire mem_req_m;
	wire [31:0] mem_rdata_m;
	wire mem_ack_m;
	localparam signed [31:0] yunit_pkg_DMA_NREGS = 16;
	reg [15:0] dma_regf [0:15];
	wire dma_cpu_reg_we;
	wire [3:0] dma_cpu_reg_addr;
	wire [15:0] dma_cpu_reg_wdata;
	wire [15:0] dma_cpu_reg_rdata;
	wire phys_reg_we;
	wire [3:0] phys_reg_addr;
	wire [15:0] phys_reg_wdata;
	wire [15:0] phys_reg_rdata;
	wire dma_fb_we;
	wire [17:0] dma_fb_addr;
	wire [15:0] dma_fb_wdata;
	wire [15:0] phys_dma_palette;
	wire phys_busy;
	wire phys_irq;
	localparam [3:0] yunit_pkg_DMA_PALETTE = 4'd8;
	wire [15:0] dma_palette_live = dma_regf[yunit_pkg_DMA_PALETTE];
	wire mem_fb_ack;
	wire dma_fb_ack = mem_fb_ack;
	wire mem_fb_busy;
	wire dma_fb_busy = mem_fb_busy;
	wire dma_fb_flush;
	assign fb_snoop_we = dma_fb_we && dma_fb_ack;
	assign fb_snoop_addr = dma_fb_addr;
	assign fb_snoop_data = dma_fb_wdata;
	assign fb_busy = dma_fb_busy;
	yunit_mem #(
		.ROM_HEX(ROM_HEX),
		.ROM_WORDS(ROM_WORDS),
		.ROM_WORD_OFFSET(ROM_WORD_OFFSET),
		.GFX_PIXELS(GFX_PIXELS)
	) u_mem(
		.clk(clk),
		.rst(rst),
		.mem_req(mem_req_m),
		.mem_we(mem_we),
		.mem_addr(mem_addr),
		.mem_size(mem_size),
		.mem_wdata(mem_wdata),
		.mem_rdata(mem_rdata_m),
		.mem_ack(mem_ack_m),
		.fb_we(dma_fb_we),
		.fb_addr(dma_fb_addr),
		.fb_wdata(dma_fb_wdata),
		.dma_palette(dma_palette_live),
		.inputs(inputs),
		.game_id(game_id),
		.game_gfx_bytes(game_gfx_bytes),
		.term2_adc(term2_adc),
		.term2_adc_sel(term2_adc_sel),
		.snd_select(snd_select),
		.snd_trig(snd_trig),
		.snd_reset(snd_reset),
		.dbg_p1ctrl(dbg_p1ctrl),
		.dbg_bdir(dbg_bdir),
		.cmos_quiesce(cmos_quiesce),
		.nvram_ext_en(nvram_ext_en),
		.nvram_ext_wr(nvram_ext_wr),
		.nvram_ext_addr(nvram_ext_addr),
		.nvram_ext_wdata(nvram_ext_wdata),
		.nvram_ext_rdata(nvram_ext_rdata),
		.cmos_cpu_busy(cmos_cpu_busy),
		.cmos_cpu_write_pulse(cmos_cpu_write_pulse),
		.autoerase_enable(autoerase_enable),
		.erase_start(erase_start),
		.erase_row0(erase_row0),
		.erase_lines(erase_lines),
		.erase_busy(erase_busy),
		.erase_line_valid(erase_line_valid),
		.erase_line_row(erase_line_row),
		.gfx_rd(cpu_gfx_rd),
		.gfx_raddr(cpu_gfx_raddr),
		.gfx_rdata(cpu_gfx_rdata),
		.gfx_rack(cpu_gfx_rack),
		.fb_ack(mem_fb_ack),
		.fb_busy(mem_fb_busy),
		.fb_flush(dma_fb_flush),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack),
		.sdram_por(sdram_por),
		.ddram_addr(ddram_addr),
		.ddram_burstcnt(ddram_burstcnt),
		.ddram_rd(ddram_rd),
		.ddram_we(ddram_we),
		.ddram_din(ddram_din),
		.ddram_be(ddram_be),
		.ddram_busy(ddram_busy),
		.ddram_dout(ddram_dout),
		.ddram_dout_ready(ddram_dout_ready),
		.palv_we_a(palv_we_a),
		.palv_aa(palv_aa),
		.palv_awd(palv_awd),
		.palv_we_b(palv_we_b),
		.palv_ba(palv_ba),
		.palv_bwd(palv_bwd)
	);
	localparam [3:0] yunit_pkg_DMA_COMMAND = 4'd0;
	wire timer_command_we = dma_cpu_reg_we && (dma_cpu_reg_addr == yunit_pkg_DMA_COMMAND);
	localparam signed [31:0] yunit_pkg_DMA_CMD_TRIG_BIT = 15;
	wire timer_command_start = dma_cpu_reg_wdata[yunit_pkg_DMA_CMD_TRIG_BIT];
	reg signed [17:0] timer_nf_x_s1;
	reg signed [17:0] timer_nf_width_s1;
	reg signed [17:0] timer_flip_x_s1;
	reg signed [17:0] timer_flip_width_s1;
	reg signed [17:0] timer_y_s1;
	reg signed [17:0] timer_height_s1;
	(* preserve *) reg signed [17:0] timer_nf_x_s1_q;
	(* preserve *) reg signed [17:0] timer_nf_width_s1_q;
	(* preserve *) reg signed [17:0] timer_flip_x_s1_q;
	(* preserve *) reg signed [17:0] timer_flip_width_s1_q;
	(* preserve *) reg signed [17:0] timer_y_s1_q;
	(* preserve *) reg signed [17:0] timer_height_s1_q;
	reg signed [17:0] timer_nf_width_s2;
	reg signed [17:0] timer_flip_width_s2;
	reg signed [17:0] timer_height_s2;
	(* preserve *) reg [9:0] timer_nf_clipped_width_q;
	(* preserve *) reg [9:0] timer_nf_clipped_height_q;
	(* preserve *) reg [9:0] timer_flip_clipped_width_q;
	(* preserve *) reg [9:0] timer_flip_clipped_height_q;
	(* preserve *) reg [9:0] timer_clipped_width_q;
	(* preserve *) reg [9:0] timer_clipped_height_q;
	wire [18:0] timer_clipped_pixels;
	localparam signed [31:0] yunit_pkg_DMA_CMD_FLIPX_BIT = 4;
	wire timer_prepare_flip = (mem_addr[7:4] == 4'hf ? mem_wdata[20] : mem_wdata[yunit_pkg_DMA_CMD_FLIPX_BIT]);
	localparam [3:0] yunit_pkg_DMA_HEIGHT = 4'd7;
	localparam [3:0] yunit_pkg_DMA_WIDTH = 4'd6;
	localparam [3:0] yunit_pkg_DMA_XSTART = 4'd4;
	localparam [3:0] yunit_pkg_DMA_YSTART = 4'd5;
	always @(*) begin
		if (_sv2v_0)
			;
		timer_nf_x_s1 = $signed({{2 {dma_regf[yunit_pkg_DMA_XSTART][15]}}, dma_regf[yunit_pkg_DMA_XSTART]});
		timer_nf_width_s1 = $signed({2'b00, dma_regf[yunit_pkg_DMA_WIDTH]});
		timer_flip_x_s1 = (timer_nf_x_s1 + timer_nf_width_s1) - 18'sd1;
		timer_flip_width_s1 = timer_nf_width_s1;
		timer_y_s1 = $signed({{2 {dma_regf[yunit_pkg_DMA_YSTART][15]}}, dma_regf[yunit_pkg_DMA_YSTART]});
		timer_height_s1 = $signed({2'b00, dma_regf[yunit_pkg_DMA_HEIGHT]});
		if (timer_y_s1 < 0) begin
			timer_height_s1 = timer_height_s1 + timer_y_s1;
			timer_y_s1 = 0;
		end
		if (timer_flip_x_s1 >= 18'sd512) begin
			timer_flip_width_s1 = 18'sd512 - timer_nf_x_s1;
			timer_flip_x_s1 = 18'sd511;
		end
		if (timer_nf_x_s1 < 0) begin
			timer_nf_width_s1 = timer_nf_width_s1 + timer_nf_x_s1;
			timer_nf_x_s1 = 0;
		end
	end
	always @(posedge clk)
		if (rst) begin
			timer_nf_x_s1_q <= 18'sd0;
			timer_nf_width_s1_q <= 18'sd0;
			timer_flip_x_s1_q <= 18'sd0;
			timer_flip_width_s1_q <= 18'sd0;
			timer_y_s1_q <= 18'sd0;
			timer_height_s1_q <= 18'sd0;
		end
		else begin
			timer_nf_x_s1_q <= timer_nf_x_s1;
			timer_nf_width_s1_q <= timer_nf_width_s1;
			timer_flip_x_s1_q <= timer_flip_x_s1;
			timer_flip_width_s1_q <= timer_flip_width_s1;
			timer_y_s1_q <= timer_y_s1;
			timer_height_s1_q <= timer_height_s1;
		end
	always @(*) begin
		if (_sv2v_0)
			;
		timer_nf_width_s2 = timer_nf_width_s1_q;
		timer_flip_width_s2 = timer_flip_width_s1_q;
		timer_height_s2 = timer_height_s1_q;
		if ((timer_y_s1_q + timer_height_s1_q) > 18'sd512)
			timer_height_s2 = 18'sd512 - timer_y_s1_q;
		if ((timer_nf_x_s1_q + timer_nf_width_s1_q) > 18'sd512)
			timer_nf_width_s2 = 18'sd512 - timer_nf_x_s1_q;
		if ((timer_flip_x_s1_q - timer_flip_width_s1_q) < 0)
			timer_flip_width_s2 = timer_flip_x_s1_q;
	end
	always @(posedge clk)
		if (rst) begin
			timer_nf_clipped_width_q <= 10'd0;
			timer_nf_clipped_height_q <= 10'd0;
			timer_flip_clipped_width_q <= 10'd0;
			timer_flip_clipped_height_q <= 10'd0;
		end
		else begin
			if ((timer_nf_width_s2 <= 0) || (timer_height_s2 <= 0)) begin
				timer_nf_clipped_width_q <= 10'd0;
				timer_nf_clipped_height_q <= 10'd0;
			end
			else begin
				timer_nf_clipped_width_q <= timer_nf_width_s2[9:0];
				timer_nf_clipped_height_q <= timer_height_s2[9:0];
			end
			if ((timer_flip_width_s2 <= 0) || (timer_height_s2 <= 0)) begin
				timer_flip_clipped_width_q <= 10'd0;
				timer_flip_clipped_height_q <= 10'd0;
			end
			else begin
				timer_flip_clipped_width_q <= timer_flip_width_s2[9:0];
				timer_flip_clipped_height_q <= timer_height_s2[9:0];
			end
		end
	assign timer_clipped_pixels = {9'd0, timer_clipped_width_q} * {9'd0, timer_clipped_height_q};
	wire logical_completion_pulse;
	wire logical_timer_pending;
	wire physical_completion_ready;
	yunit_dma_logical_timer u_dma_logical_timer(
		.clk(clk),
		.rst(rst),
		.command_we(timer_command_we),
		.command_start(timer_command_start),
		.clipped_pixels(timer_clipped_pixels),
		.completion_ready(physical_completion_ready),
		.busy(blit_busy),
		.blit_irq(int1),
		.completion_pulse(logical_completion_pulse),
		.timer_pending(logical_timer_pending)
	);
	assign dma_cpu_reg_rdata = (dma_cpu_reg_addr == yunit_pkg_DMA_COMMAND ? {blit_busy, dma_regf[yunit_pkg_DMA_COMMAND][14:0]} : dma_regf[dma_cpu_reg_addr]);
	localparam signed [31:0] DMA_DESC_REGS = 10;
	localparam signed [31:0] DMA_DESC_W = 160;
	localparam signed [31:0] DMA_DESC_AW = $clog2(DMA_DESC_DEPTH);
	reg [159:0] desc_push_data;
	wire [159:0] desc_pop_data;
	wire desc_push;
	wire desc_pop;
	wire desc_push_ready;
	wire desc_empty;
	wire desc_full;
	wire [DMA_DESC_AW:0] desc_count;
	wire [DMA_DESC_AW:0] desc_high_water;
	integer desc_i;
	always @(*) begin
		if (_sv2v_0)
			;
		for (desc_i = 0; desc_i < DMA_DESC_REGS; desc_i = desc_i + 1)
			desc_push_data[desc_i * 16+:16] = (desc_i == yunit_pkg_DMA_COMMAND ? dma_cpu_reg_wdata : dma_regf[desc_i]);
	end
	assign desc_push = timer_command_we && timer_command_start;
	assign dma_render_level = desc_count;
	yunit_dma_descriptor_fifo #(
		.WIDTH(DMA_DESC_W),
		.DEPTH(DMA_DESC_DEPTH),
		.AW(DMA_DESC_AW)
	) u_dma_desc_fifo(
		.clk(clk),
		.rst(rst),
		.push(desc_push),
		.push_data(desc_push_data),
		.push_ready(desc_push_ready),
		.pop(desc_pop),
		.pop_data(desc_pop_data),
		.empty(desc_empty),
		.full(desc_full),
		.count(desc_count),
		.high_water(desc_high_water),
		.overflow_sticky(dma_render_overflow)
	);
	reg [1:0] pstate;
	reg [3:0] phys_reg_index;
	reg [159:0] phys_desc;
	assign desc_pop = ((pstate == 2'd0) && !desc_empty) && !phys_busy;
	assign phys_reg_we = (pstate == 2'd1) || (pstate == 2'd2);
	assign phys_reg_addr = (pstate == 2'd2 ? yunit_pkg_DMA_COMMAND[3:0] : phys_reg_index);
	assign phys_reg_wdata = phys_desc[phys_reg_addr * 16+:16];
	always @(posedge clk)
		if (rst) begin
			pstate <= 2'd0;
			phys_reg_index <= 4'd1;
			phys_desc <= 1'sb0;
		end
		else
			(* full_case, parallel_case *)
			case (pstate)
				2'd0:
					if (desc_pop) begin
						phys_desc <= desc_pop_data;
						phys_reg_index <= 4'd1;
						pstate <= 2'd1;
					end
				2'd1:
					if (phys_reg_index == 4'd9)
						pstate <= 2'd2;
					else
						phys_reg_index <= phys_reg_index + 4'd1;
				2'd2: pstate <= 2'd3;
				2'd3:
					if (!phys_busy)
						pstate <= 2'd0;
				default: pstate <= 2'd0;
			endcase
	yunit_dma #(.RENDER_ONLY(1'b1)) u_dma(
		.clk(clk),
		.rst(rst),
		.reg_we(phys_reg_we),
		.reg_addr(phys_reg_addr),
		.reg_wdata(phys_reg_wdata),
		.reg_rdata(phys_reg_rdata),
		.src_req(src_req),
		.src_addr(src_addr),
		.src_data(src_data),
		.src_ack(src_ack),
		.fb_we(dma_fb_we),
		.fb_addr(dma_fb_addr),
		.fb_wdata(dma_fb_wdata),
		.fb_ack(dma_fb_ack),
		.fb_busy(dma_fb_busy),
		.fb_flush(dma_fb_flush),
		.busy(phys_busy),
		.trigger_blocked(),
		.blit_irq(phys_irq),
		.dma_palette(phys_dma_palette)
	);
	reg [1:0] dstate;
	reg [31:0] d_addr_q;
	reg d_we_q;
	reg [31:0] d_wd_q;
	reg [5:0] d_sz_q;
	reg dma_ack;
	wire d_second = dstate == 2'd2;
	assign dma_cpu_reg_addr = (d_second ? d_addr_q[7:4] + 4'd1 : d_addr_q[7:4]);
	assign dma_cpu_reg_wdata = (d_second ? d_wd_q[31:16] : d_wd_q[15:0]);
	assign dbg_dma_we = dma_cpu_reg_we;
	assign dbg_dma_addr = dma_cpu_reg_addr;
	assign dbg_dma_wdata = dma_cpu_reg_wdata;
	assign dma_cpu_reg_we = (dstate == 2'd1) || (dstate == 2'd2);
	integer dma_reg_i;
	always @(posedge clk)
		if (rst)
			for (dma_reg_i = 0; dma_reg_i < yunit_pkg_DMA_NREGS; dma_reg_i = dma_reg_i + 1)
				dma_regf[dma_reg_i] <= 16'h0000;
		else if (dma_cpu_reg_we)
			dma_regf[dma_cpu_reg_addr] <= dma_cpu_reg_wdata;
		else if (logical_completion_pulse)
			dma_regf[yunit_pkg_DMA_COMMAND][yunit_pkg_DMA_CMD_TRIG_BIT] <= 1'b0;
	wire request_triggers_lo = (mem_we && (mem_addr[7:4] == yunit_pkg_DMA_COMMAND)) && mem_wdata[yunit_pkg_DMA_CMD_TRIG_BIT];
	wire request_triggers_hi = ((mem_we && (mem_size > 6'd16)) && (mem_addr[7:4] == 4'hf)) && mem_wdata[31];
	wire request_needs_descriptor = request_triggers_lo || request_triggers_hi;
	wire timer_prepare_accept = (((((dstate == 2'd0) && mem_req) && is_dma_now) && !mem_ack) && request_needs_descriptor) && desc_push_ready;
	always @(posedge clk)
		if (rst) begin
			timer_clipped_width_q <= 10'd0;
			timer_clipped_height_q <= 10'd0;
		end
		else if (timer_prepare_accept) begin
			timer_clipped_width_q <= (timer_prepare_flip ? timer_flip_clipped_width_q : timer_nf_clipped_width_q);
			timer_clipped_height_q <= (timer_prepare_flip ? timer_flip_clipped_height_q : timer_nf_clipped_height_q);
		end
	always @(posedge clk)
		if (rst) begin
			dstate <= 2'd0;
			dma_ack <= 1'b0;
		end
		else
			(* full_case, parallel_case *)
			case (dstate)
				2'd0: begin
					dma_ack <= 1'b0;
					if ((mem_req && is_dma_now) && !mem_ack) begin
						if (request_needs_descriptor && !desc_push_ready)
							;
						else begin
							d_addr_q <= mem_addr;
							d_we_q <= mem_we;
							d_wd_q <= mem_wdata;
							d_sz_q <= mem_size;
							dstate <= (mem_we ? 2'd1 : 2'd3);
						end
					end
				end
				2'd1: dstate <= (d_sz_q > 6'd16 ? 2'd2 : 2'd3);
				2'd2: dstate <= 2'd3;
				2'd3: begin
					dma_ack <= 1'b1;
					dstate <= 2'd0;
				end
				default: dstate <= 2'd0;
			endcase
	wire is_vram_now = mem_addr[31:21] == 11'd0;
	wire dma_descriptor_active = (!desc_empty || (pstate != 2'd0)) || phys_busy;
	wire dma_render_active = dma_descriptor_active || dma_fb_busy;
	assign physical_completion_ready = !dma_descriptor_active;
	assign dma_vram_order_stall = ((mem_req && !is_dma_now) && is_vram_now) && dma_render_active;
	assign mem_req_m = (mem_req && !is_dma_now) && !dma_vram_order_stall;
	assign mem_ack = (is_dma_now ? dma_ack : mem_ack_m);
	assign mem_rdata = (is_dma_now ? {16'h0000, dma_cpu_reg_rdata} : mem_rdata_m);
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_display_address_sequencer (
	clk,
	rst,
	line_tick,
	dpyctl_we,
	dpyctl_wdata,
	dpystart_we,
	dpystart_wdata,
	dpytap_we,
	dpytap_wdata,
	dpyadr_we,
	dpyadr_wdata,
	veblnk_we,
	veblnk_wdata,
	vsblnk_we,
	vsblnk_wdata,
	vtotal_we,
	vtotal_wdata,
	flip_hold,
	vcount_live,
	dpyadr_live,
	line_event,
	scanout_valid,
	scanout_vcount,
	scanout_row_raw,
	scanout_row_phys,
	scanout_base_word,
	scanout_coladdr,
	scanout_col_word,
	scanout_yoffset,
	prefetch_valid,
	prefetch_vcount,
	prefetch_row_raw,
	prefetch_row_phys,
	prefetch_base_word,
	prefetch_coladdr,
	prefetch_col_word,
	prefetch_yoffset,
	frame_start_o,
	line_consumed_valid,
	line_consumed_first,
	line_consumed_row_raw,
	line_consumed_row_phys,
	line_consumed_base_word,
	contract_valid,
	unsupported_mode,
	config_invalid,
	timing_conflict_pulse,
	timing_conflict_sticky,
	line_deferred_pulse,
	line_deferred_sticky,
	sequence_error_pulse,
	sequence_error_sticky
);
	reg _sv2v_0;
	input wire clk;
	input wire rst;
	input wire line_tick;
	input wire dpyctl_we;
	input wire [15:0] dpyctl_wdata;
	input wire dpystart_we;
	input wire [15:0] dpystart_wdata;
	input wire dpytap_we;
	input wire [15:0] dpytap_wdata;
	input wire dpyadr_we;
	input wire [15:0] dpyadr_wdata;
	input wire veblnk_we;
	input wire [15:0] veblnk_wdata;
	input wire vsblnk_we;
	input wire [15:0] vsblnk_wdata;
	input wire vtotal_we;
	input wire [15:0] vtotal_wdata;
	input wire flip_hold;
	output wire [15:0] vcount_live;
	output wire [15:0] dpyadr_live;
	output reg line_event;
	output reg scanout_valid;
	output reg [15:0] scanout_vcount;
	output reg [11:0] scanout_row_raw;
	output reg [8:0] scanout_row_phys;
	output reg [17:0] scanout_base_word;
	output reg [13:0] scanout_coladdr;
	output reg [8:0] scanout_col_word;
	output reg [1:0] scanout_yoffset;
	output reg prefetch_valid;
	output reg [15:0] prefetch_vcount;
	output reg [11:0] prefetch_row_raw;
	output reg [8:0] prefetch_row_phys;
	output reg [17:0] prefetch_base_word;
	output reg [13:0] prefetch_coladdr;
	output reg [8:0] prefetch_col_word;
	output reg [1:0] prefetch_yoffset;
	output wire frame_start_o;
	output reg line_consumed_valid;
	output reg line_consumed_first;
	output reg [11:0] line_consumed_row_raw;
	output reg [8:0] line_consumed_row_phys;
	output reg [17:0] line_consumed_base_word;
	output wire contract_valid;
	output wire unsupported_mode;
	output wire config_invalid;
	output reg timing_conflict_pulse;
	output reg timing_conflict_sticky;
	output reg line_deferred_pulse;
	output reg line_deferred_sticky;
	output reg sequence_error_pulse;
	output reg sequence_error_sticky;
	reg [15:0] dpyctl;
	reg [15:0] dpystart;
	reg [15:0] dpytap;
	reg [15:0] dpyadr;
	reg [15:0] veblnk;
	reg [15:0] vsblnk;
	reg [15:0] vtotal;
	reg [15:0] vcount;
	reg first_consumed_pending;
	reg final_pending;
	reg [11:0] final_pending_row_raw;
	reg line_pending;
	reg [15:0] dpystart_committed;
	localparam [1:0] FLIP_DEFER_MAX = 2'd2;
	reg [1:0] flip_defer_cnt;
	wire any_reg_write = (((((dpyctl_we || dpystart_we) || dpytap_we) || dpyadr_we) || veblnk_we) || vsblnk_we) || vtotal_we;
	wire mode_supported = dpyctl[13] && dpyctl[14];
	wire timing_config_valid = ((vtotal != 16'd0) && (veblnk < vsblnk)) && (vsblnk <= vtotal);
	wire visible_line = (vcount >= veblnk) && (vcount < vsblnk);
	wire display_line = visible_line && dpyctl[15];
	wire line_collision = line_tick && any_reg_write;
	wire line_overrun = line_tick && line_pending;
	wire tick_event = line_pending || (line_tick && !any_reg_write);
	wire safe_tick = (tick_event && contract_valid) && !line_overrun;
	wire pending_sequence_bad = (safe_tick && final_pending) && (vcount != vsblnk);
	wire flip_reload_edge = (tick_event && !dpyadr_we) && (vcount == vsblnk);
	assign frame_start_o = flip_reload_edge;
	wire flip_change_pending = dpystart != dpystart_committed;
	wire flip_wdog_force = flip_defer_cnt >= FLIP_DEFER_MAX;
	wire flip_adopt = (!flip_hold || flip_wdog_force) || !flip_change_pending;
	wire [15:0] dpystart_eff = (flip_adopt ? dpystart : dpystart_committed);
	reg [15:0] display_dpyadr;
	reg [15:0] next_visible_dpyadr;
	reg [11:0] current_row_raw;
	reg [13:0] current_coladdr;
	reg [1:0] current_yoffset;
	reg prefetch_candidate_valid;
	reg [15:0] prefetch_candidate_vcount;
	reg [15:0] prefetch_candidate_dpyadr;
	reg [15:0] prefetch_display_dpyadr;
	reg [11:0] prefetch_candidate_row_raw;
	reg [13:0] prefetch_candidate_coladdr;
	reg [1:0] prefetch_candidate_yoffset;
	wire [11:0] previous_row_raw = current_row_raw - 12'd1;
	always @(*) begin
		if (_sv2v_0)
			;
		if (dpyctl[10])
			display_dpyadr = dpyadr;
		else
			display_dpyadr = dpyadr ^ 16'hfffc;
		current_row_raw = display_dpyadr[15:4];
		current_coladdr = ((display_dpyadr & 16'h007c) << 4) | (dpytap & 16'h3fff);
		current_yoffset = (dpystart - dpyadr) & 16'h0003;
		if (dpyadr[1:0] == 2'b00)
			next_visible_dpyadr = ((dpyadr & 16'hfffc) - (dpyctl & 16'h03fc)) | (dpystart & 16'h0003);
		else
			next_visible_dpyadr = (dpyadr & 16'hfffc) | ((dpyadr - 16'd1) & 16'h0003);
		prefetch_candidate_valid = 1'b0;
		prefetch_candidate_vcount = 16'd0;
		prefetch_candidate_dpyadr = dpyadr;
		if (display_line && ((vcount + 16'd1) < vsblnk)) begin
			prefetch_candidate_valid = 1'b1;
			prefetch_candidate_vcount = vcount + 16'd1;
			prefetch_candidate_dpyadr = next_visible_dpyadr;
		end
		else if (!visible_line && dpyctl[15]) begin
			prefetch_candidate_valid = 1'b1;
			prefetch_candidate_vcount = veblnk;
			prefetch_candidate_dpyadr = (vcount == vsblnk ? dpystart : dpyadr);
		end
		if (dpyctl[10])
			prefetch_display_dpyadr = prefetch_candidate_dpyadr;
		else
			prefetch_display_dpyadr = prefetch_candidate_dpyadr ^ 16'hfffc;
		prefetch_candidate_row_raw = prefetch_display_dpyadr[15:4];
		prefetch_candidate_coladdr = ((prefetch_display_dpyadr & 16'h007c) << 4) | (dpytap & 16'h3fff);
		prefetch_candidate_yoffset = (dpystart - prefetch_candidate_dpyadr) & 16'h0003;
	end
	assign vcount_live = vcount;
	assign dpyadr_live = dpyadr;
	assign unsupported_mode = !mode_supported;
	assign config_invalid = !timing_config_valid;
	assign contract_valid = (mode_supported && timing_config_valid) && !sequence_error_sticky;
	always @(posedge clk)
		if (rst) begin
			dpyctl <= 16'd0;
			dpystart <= 16'd0;
			dpytap <= 16'd0;
			veblnk <= 16'd0;
			vsblnk <= 16'd0;
			vtotal <= 16'd0;
		end
		else begin
			if (dpyctl_we)
				dpyctl <= dpyctl_wdata;
			if (dpystart_we)
				dpystart <= dpystart_wdata;
			if (dpytap_we)
				dpytap <= dpytap_wdata;
			if (veblnk_we)
				veblnk <= veblnk_wdata;
			if (vsblnk_we)
				vsblnk <= vsblnk_wdata;
			if (vtotal_we)
				vtotal <= vtotal_wdata;
		end
	always @(posedge clk)
		if (rst)
			dpyadr <= 16'd0;
		else if (dpyadr_we)
			dpyadr <= dpyadr_wdata;
		else if (tick_event) begin
			if (vcount == vsblnk)
				dpyadr <= dpystart_eff;
			else if (visible_line)
				dpyadr <= next_visible_dpyadr;
		end
	always @(posedge clk)
		if (rst) begin
			dpystart_committed <= 16'd0;
			flip_defer_cnt <= 2'd0;
		end
		else if (flip_reload_edge) begin
			dpystart_committed <= dpystart_eff;
			if (flip_change_pending && !flip_adopt)
				flip_defer_cnt <= flip_defer_cnt + 2'd1;
			else
				flip_defer_cnt <= 2'd0;
		end
	always @(posedge clk)
		if (rst)
			vcount <= 16'd0;
		else if (tick_event) begin
			if (vtotal == 16'd0)
				vcount <= 16'd1;
			else if (vcount >= vtotal)
				vcount <= 16'd0;
			else
				vcount <= vcount + 16'd1;
		end
	always @(posedge clk)
		if (rst)
			line_pending <= 1'b0;
		else if (line_overrun)
			line_pending <= 1'b0;
		else if (line_collision)
			line_pending <= 1'b1;
		else
			line_pending <= 1'b0;
	always @(posedge clk)
		if (rst) begin
			timing_conflict_pulse <= 1'b0;
			timing_conflict_sticky <= 1'b0;
			line_deferred_pulse <= 1'b0;
			line_deferred_sticky <= 1'b0;
			sequence_error_pulse <= 1'b0;
			sequence_error_sticky <= 1'b0;
		end
		else begin
			timing_conflict_pulse <= line_collision;
			line_deferred_pulse <= line_collision && !line_overrun;
			sequence_error_pulse <= pending_sequence_bad || line_overrun;
			if (line_collision)
				timing_conflict_sticky <= 1'b1;
			if (line_collision && !line_overrun)
				line_deferred_sticky <= 1'b1;
			if (pending_sequence_bad || line_overrun)
				sequence_error_sticky <= 1'b1;
		end
	always @(posedge clk)
		if (rst) begin
			final_pending <= 1'b0;
			final_pending_row_raw <= 12'd0;
		end
		else if (tick_event) begin
			if (!safe_tick || pending_sequence_bad)
				final_pending <= 1'b0;
			else begin
				if (final_pending)
					final_pending <= 1'b0;
				if (display_line && (vcount == (vsblnk - 16'd1))) begin
					final_pending <= 1'b1;
					final_pending_row_raw <= current_row_raw;
				end
			end
		end
	always @(posedge clk)
		if (rst) begin
			scanout_valid <= 1'b0;
			line_event <= 1'b0;
			scanout_vcount <= 16'd0;
			scanout_row_raw <= 12'd0;
			scanout_row_phys <= 9'd0;
			scanout_base_word <= 18'd0;
			scanout_coladdr <= 14'd0;
			scanout_col_word <= 9'd0;
			scanout_yoffset <= 2'd0;
			prefetch_valid <= 1'b0;
			prefetch_vcount <= 16'd0;
			prefetch_row_raw <= 12'd0;
			prefetch_row_phys <= 9'd0;
			prefetch_base_word <= 18'd0;
			prefetch_coladdr <= 14'd0;
			prefetch_col_word <= 9'd0;
			prefetch_yoffset <= 2'd0;
			line_consumed_valid <= 1'b0;
			line_consumed_first <= 1'b0;
			first_consumed_pending <= 1'b1;
			line_consumed_row_raw <= 12'd0;
			line_consumed_row_phys <= 9'd0;
			line_consumed_base_word <= 18'd0;
		end
		else begin
			line_event <= 1'b0;
			scanout_valid <= 1'b0;
			prefetch_valid <= 1'b0;
			line_consumed_valid <= 1'b0;
			line_consumed_first <= 1'b0;
			if (safe_tick && !pending_sequence_bad) begin
				line_event <= 1'b1;
				if (vcount == veblnk)
					first_consumed_pending <= 1'b1;
				if (display_line) begin
					scanout_valid <= 1'b1;
					scanout_vcount <= vcount;
					scanout_row_raw <= current_row_raw;
					scanout_row_phys <= current_row_raw[8:0];
					scanout_base_word <= {current_row_raw[8:0], 9'd0};
					scanout_coladdr <= current_coladdr;
					scanout_col_word <= {current_coladdr[7:0], 1'b0};
					scanout_yoffset <= current_yoffset;
				end
				if (prefetch_candidate_valid) begin
					prefetch_valid <= 1'b1;
					prefetch_vcount <= prefetch_candidate_vcount;
					prefetch_row_raw <= prefetch_candidate_row_raw;
					prefetch_row_phys <= prefetch_candidate_row_raw[8:0];
					prefetch_base_word <= {prefetch_candidate_row_raw[8:0], 9'd0};
					prefetch_coladdr <= prefetch_candidate_coladdr;
					prefetch_col_word <= {prefetch_candidate_coladdr[7:0], 1'b0};
					prefetch_yoffset <= prefetch_candidate_yoffset;
				end
				if (final_pending) begin
					if ((final_pending_row_raw[8:0] != 9'd510) && (final_pending_row_raw[8:0] != 9'd511)) begin
						line_consumed_valid <= 1'b1;
						line_consumed_first <= first_consumed_pending;
						first_consumed_pending <= 1'b0;
						line_consumed_row_raw <= final_pending_row_raw;
						line_consumed_row_phys <= final_pending_row_raw[8:0];
						line_consumed_base_word <= {final_pending_row_raw[8:0], 9'd0};
					end
				end
				else if ((display_line && (current_row_raw[8:0] != 9'd511)) && (current_row_raw[8:0] != 9'd0)) begin
					line_consumed_valid <= 1'b1;
					line_consumed_first <= first_consumed_pending || (vcount == veblnk);
					first_consumed_pending <= 1'b0;
					line_consumed_row_raw <= previous_row_raw;
					line_consumed_row_phys <= previous_row_raw[8:0];
					line_consumed_base_word <= {previous_row_raw[8:0], 9'd0};
				end
			end
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_autoerase_scheduler (
	clk,
	rst,
	line_consumed_valid,
	line_phys_row,
	autoerase_enable,
	job_valid,
	job_ready,
	job_src_row,
	job_dst_row,
	job_done,
	job_inflight,
	pending_count,
	overflow_pulse,
	overflow_sticky
);
	input wire clk;
	input wire rst;
	input wire line_consumed_valid;
	input wire [8:0] line_phys_row;
	input wire autoerase_enable;
	output wire job_valid;
	input wire job_ready;
	output wire [8:0] job_src_row;
	output wire [8:0] job_dst_row;
	input wire job_done;
	output reg job_inflight;
	output wire [1:0] pending_count;
	output reg overflow_pulse;
	output reg overflow_sticky;
	localparam [1:0] FIFO_DEPTH = 2'd2;
	reg [8:0] src_fifo [0:1];
	reg [8:0] dst_fifo [0:1];
	reg rd_ptr;
	reg wr_ptr;
	reg [1:0] fifo_count;
	wire event_eligible = (line_consumed_valid && autoerase_enable) && (line_phys_row < 9'd510);
	wire launch_job = job_valid && job_ready;
	wire fifo_has_room = (fifo_count < FIFO_DEPTH) || launch_job;
	wire enqueue_event = event_eligible && fifo_has_room;
	wire drop_event = event_eligible && !fifo_has_room;
	assign pending_count = fifo_count;
	assign job_valid = !job_inflight && (fifo_count != 2'd0);
	assign job_src_row = (job_valid ? src_fifo[rd_ptr] : 9'd0);
	assign job_dst_row = (job_valid ? dst_fifo[rd_ptr] : 9'd0);
	always @(posedge clk)
		if (rst) begin
			rd_ptr <= 1'b0;
			wr_ptr <= 1'b0;
			fifo_count <= 2'd0;
			job_inflight <= 1'b0;
			overflow_pulse <= 1'b0;
			overflow_sticky <= 1'b0;
		end
		else begin
			overflow_pulse <= drop_event;
			if (drop_event)
				overflow_sticky <= 1'b1;
			if (enqueue_event) begin
				src_fifo[wr_ptr] <= (line_phys_row[0] ? 9'd511 : 9'd510);
				dst_fifo[wr_ptr] <= line_phys_row;
				wr_ptr <= ~wr_ptr;
			end
			if (launch_job)
				rd_ptr <= ~rd_ptr;
			case ({enqueue_event, launch_job})
				2'b10: fifo_count <= fifo_count + 2'd1;
				2'b01: fifo_count <= fifo_count - 2'd1;
				default: fifo_count <= fifo_count;
			endcase
			if (job_inflight) begin
				if (job_done)
					job_inflight <= 1'b0;
			end
			else if (launch_job)
				job_inflight <= 1'b1;
		end
endmodule
`default_nettype wire
`default_nettype none
module yunit_autoerase_sdram_backend (
	clk,
	rst,
	job_valid,
	job_ready,
	job_src_row,
	job_dst_row,
	job_done,
	protocol_error,
	brd_req,
	brd_addr,
	brd_len,
	brd_dout,
	brd_dvalid,
	brd_done,
	bwr_req,
	bwr_addr,
	bwr_len,
	bwr_din,
	bwr_wtbt,
	bwr_valid,
	bwr_ready,
	bwr_done
);
	parameter [24:0] VRAM_WORD_BASE = 25'h00e0000;
	input wire clk;
	input wire rst;
	input wire job_valid;
	output wire job_ready;
	input wire [8:0] job_src_row;
	input wire [8:0] job_dst_row;
	output reg job_done;
	output reg protocol_error;
	output reg brd_req;
	output reg [24:0] brd_addr;
	output wire [9:0] brd_len;
	input wire [15:0] brd_dout;
	input wire brd_dvalid;
	input wire brd_done;
	output reg bwr_req;
	output reg [24:0] bwr_addr;
	output wire [9:0] bwr_len;
	output wire [15:0] bwr_din;
	output wire [1:0] bwr_wtbt;
	output wire bwr_valid;
	input wire bwr_ready;
	input wire bwr_done;
	localparam [9:0] ROW_WORDS = 10'd512;
	reg [15:0] row_buffer [0:511];
	reg [9:0] read_count;
	reg [9:0] write_count;
	reg [15:0] write_data_q;
	reg [1:0] state;
	wire [24:0] src_word_addr = VRAM_WORD_BASE + {{7 {1'b0}}, job_src_row, 9'd0};
	wire [24:0] dst_word_addr = VRAM_WORD_BASE + {{7 {1'b0}}, job_dst_row, 9'd0};
	wire write_beat = bwr_valid && bwr_ready;
	wire rb_we = ((state == 2'd1) && brd_dvalid) && (read_count < ROW_WORDS);
	wire [8:0] rb_waddr = read_count[8:0];
	wire rb_re = ((state == 2'd1) && brd_done) || (((state == 2'd2) && write_beat) && (write_count < (ROW_WORDS - 10'd1)));
	wire [8:0] rb_raddr = (state == 2'd1 ? 9'd0 : write_count[8:0] + 9'd1);
	always @(posedge clk) begin
		if (rb_we)
			row_buffer[rb_waddr] <= brd_dout;
		if (rb_re)
			write_data_q <= row_buffer[rb_raddr];
	end
	assign job_ready = state == 2'd0;
	assign brd_len = ROW_WORDS;
	assign bwr_len = ROW_WORDS;
	assign bwr_wtbt = 2'b11;
	assign bwr_din = write_data_q;
	assign bwr_valid = (state == 2'd2) && (write_count < ROW_WORDS);
	always @(posedge clk)
		if (rst) begin
			state <= 2'd0;
			job_done <= 1'b0;
			protocol_error <= 1'b0;
			brd_req <= 1'b0;
			brd_addr <= 25'd0;
			bwr_req <= 1'b0;
			bwr_addr <= 25'd0;
			read_count <= 10'd0;
			write_count <= 10'd0;
		end
		else begin
			job_done <= 1'b0;
			(* full_case, parallel_case *)
			case (state)
				2'd0: begin
					brd_req <= 1'b0;
					bwr_req <= 1'b0;
					if (job_valid) begin
						brd_addr <= src_word_addr << 1;
						bwr_addr <= dst_word_addr << 1;
						read_count <= 10'd0;
						brd_req <= 1'b1;
						bwr_req <= 1'b1;
						state <= 2'd1;
					end
				end
				2'd1: begin
					if (brd_dvalid) begin
						if (read_count < ROW_WORDS)
							read_count <= read_count + 10'd1;
						else
							protocol_error <= 1'b1;
					end
					if (brd_done) begin
						brd_req <= 1'b0;
						if (read_count != ROW_WORDS)
							protocol_error <= 1'b1;
						write_count <= 10'd0;
						state <= 2'd2;
					end
				end
				2'd2: begin
					if (write_beat)
						write_count <= write_count + 10'd1;
					if (bwr_done) begin
						bwr_req <= 1'b0;
						if (write_count != ROW_WORDS)
							protocol_error <= 1'b1;
						job_done <= 1'b1;
						state <= 2'd0;
					end
				end
				default: state <= 2'd0;
			endcase
		end
endmodule
`default_nettype wire
`default_nettype none
module yunit_shiftreg_engine (
	clk,
	rst,
	req_valid,
	req_ready,
	req_write,
	req_bit_addr,
	read_data,
	busy,
	done,
	error,
	mem_valid,
	mem_ready,
	mem_write,
	mem_addr,
	mem_wdata,
	mem_rdata,
	mem_error
);
	reg _sv2v_0;
	input wire clk;
	input wire rst;
	input wire req_valid;
	output reg req_ready;
	input wire req_write;
	input wire [31:0] req_bit_addr;
	output reg [15:0] read_data;
	output reg busy;
	output reg done;
	output reg error;
	output reg mem_valid;
	input wire mem_ready;
	output reg mem_write;
	output reg [17:0] mem_addr;
	output reg [15:0] mem_wdata;
	input wire [15:0] mem_rdata;
	input wire mem_error;
	localparam [9:0] SHIFT_LAST = 10'd1023;
	reg [2:0] state;
	reg [2:0] state_next;
	reg [15:0] shift_ram [0:1023];
	reg [15:0] ram_q;
	reg [9:0] ram_addr;
	reg [15:0] ram_wdata;
	reg ram_we;
	reg [17:0] base_word;
	reg [9:0] word_index;
	wire accept_req = req_valid && req_ready;
	wire mem_accept = mem_valid && mem_ready;
	wire last_word = word_index == SHIFT_LAST;
	wire [17:0] request_base_word = req_bit_addr[20:3];
	wire [17:0] indexed_word = base_word + {{8 {1'b0}}, word_index};
	always @(posedge clk)
		if (rst)
			state <= 3'd0;
		else
			state <= state_next;
	always @(*) begin
		if (_sv2v_0)
			;
		state_next = state;
		case (state)
			3'd0:
				if (last_word)
					state_next = 3'd1;
			3'd1:
				if (accept_req) begin
					if (req_write)
						state_next = 3'd3;
					else
						state_next = 3'd2;
				end
			3'd2:
				if (mem_accept && (mem_error || last_word))
					state_next = 3'd5;
			3'd3: state_next = 3'd4;
			3'd4:
				if (mem_accept) begin
					if (mem_error || last_word)
						state_next = 3'd5;
					else
						state_next = 3'd3;
				end
			3'd5: state_next = 3'd1;
			default: state_next = 3'd0;
		endcase
	end
	always @(*) begin
		if (_sv2v_0)
			;
		req_ready = 1'b0;
		busy = 1'b1;
		done = 1'b0;
		mem_valid = 1'b0;
		mem_write = 1'b0;
		mem_addr = indexed_word;
		mem_wdata = 16'd0;
		case (state)
			3'd0:
				;
			3'd1: begin
				req_ready = 1'b1;
				busy = 1'b0;
			end
			3'd2: mem_valid = 1'b1;
			3'd3:
				;
			3'd4: begin
				mem_valid = 1'b1;
				mem_write = 1'b1;
				mem_wdata = ram_q;
			end
			3'd5: done = 1'b1;
			default:
				;
		endcase
	end
	always @(*) begin
		if (_sv2v_0)
			;
		ram_addr = word_index;
		ram_wdata = 16'd0;
		ram_we = 1'b0;
		case (state)
			3'd0: ram_we = 1'b1;
			3'd2:
				if (mem_accept && !mem_error) begin
					ram_wdata = mem_rdata;
					ram_we = 1'b1;
				end
			3'd1, 3'd3, 3'd4, 3'd5:
				;
			default:
				;
		endcase
	end
	always @(posedge clk)
		if (!rst) begin
			if (ram_we)
				shift_ram[ram_addr] <= ram_wdata;
			ram_q <= shift_ram[ram_addr];
		end
	always @(posedge clk)
		if (rst)
			word_index <= 10'd0;
		else
			case (state)
				3'd0:
					if (last_word)
						word_index <= 10'd0;
					else
						word_index <= word_index + 10'd1;
				3'd1:
					if (accept_req)
						word_index <= 10'd0;
				3'd2, 3'd4:
					if (mem_accept && !mem_error) begin
						if (last_word)
							word_index <= 10'd0;
						else
							word_index <= word_index + 10'd1;
					end
				3'd3, 3'd5:
					;
				default: word_index <= 10'd0;
			endcase
	always @(posedge clk)
		if (rst)
			base_word <= 18'd0;
		else if (accept_req)
			base_word <= request_base_word;
	always @(posedge clk)
		if (rst)
			read_data <= 16'd0;
		else if ((((state == 3'd2) && mem_accept) && !mem_error) && (word_index == 10'd0))
			read_data <= mem_rdata;
	always @(posedge clk)
		if (rst)
			error <= 1'b0;
		else if (accept_req)
			error <= 1'b0;
		else if (mem_accept && mem_error)
			error <= 1'b1;
	initial _sv2v_0 = 0;
endmodule
module yunit_shiftreg_command_bridge (
	clk,
	rst,
	cpu_ce,
	cpu_req,
	cpu_write,
	cpu_bit_addr,
	engine_req_valid,
	engine_req_ready,
	engine_req_write,
	engine_req_bit_addr,
	engine_done,
	engine_error,
	core_ack,
	error_sticky
);
	reg _sv2v_0;
	parameter integer AW = 32;
	input wire clk;
	input wire rst;
	input wire cpu_ce;
	input wire cpu_req;
	input wire cpu_write;
	input wire [AW - 1:0] cpu_bit_addr;
	output reg engine_req_valid;
	input wire engine_req_ready;
	output reg engine_req_write;
	output reg [AW - 1:0] engine_req_bit_addr;
	input wire engine_done;
	input wire engine_error;
	output wire core_ack;
	output reg error_sticky;
	(* preserve *) reg cmd_valid_q;
	(* preserve *) reg cmd_write_q;
	(* preserve *) reg [AW - 1:0] cmd_bit_addr_q;
	(* preserve, dont_merge, altera_attribute = "-name ADV_NETLIST_OPT_ALLOWED NEVER_ALLOW; -name DONT_MERGE_REGISTER ON; -name PRESERVE_REGISTER ON" *) reg command_issued_q;
	(* preserve, dont_merge, altera_attribute = "-name ADV_NETLIST_OPT_ALLOWED NEVER_ALLOW; -name DONT_MERGE_REGISTER ON; -name PRESERVE_REGISTER ON" *) reg ack_pending_q;
	(* preserve, dont_merge, altera_attribute = "-name ADV_NETLIST_OPT_ALLOWED NEVER_ALLOW; -name DONT_MERGE_REGISTER ON; -name PRESERVE_REGISTER ON" *) reg core_ack_q;
	wire capture_command = ((cpu_ce && cpu_req) && !cmd_valid_q) && !command_issued_q;
	wire engine_accept = engine_req_valid && engine_req_ready;
	wire core_consume = cpu_ce && core_ack_q;
	always @(*) begin
		if (_sv2v_0)
			;
		engine_req_valid = cmd_valid_q;
		engine_req_write = cmd_write_q;
		engine_req_bit_addr = cmd_bit_addr_q;
	end
	assign core_ack = core_ack_q;
	always @(posedge clk)
		if (rst) begin
			cmd_valid_q <= 1'b0;
			cmd_write_q <= 1'b0;
			cmd_bit_addr_q <= 1'sb0;
			command_issued_q <= 1'b0;
			ack_pending_q <= 1'b0;
			core_ack_q <= 1'b0;
			error_sticky <= 1'b0;
		end
		else begin
			if (capture_command) begin
				cmd_valid_q <= 1'b1;
				cmd_write_q <= cpu_write;
				cmd_bit_addr_q <= cpu_bit_addr;
			end
			if (engine_accept) begin
				cmd_valid_q <= 1'b0;
				command_issued_q <= 1'b1;
			end
			if (engine_done)
				ack_pending_q <= 1'b1;
			if (engine_error)
				error_sticky <= 1'b1;
			if (cpu_ce) begin
				if (core_ack_q)
					core_ack_q <= 1'b0;
				else if (ack_pending_q || engine_done)
					core_ack_q <= 1'b1;
			end
			if (core_consume) begin
				command_issued_q <= 1'b0;
				ack_pending_q <= 1'b0;
			end
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_vram_word_arb (
	clk,
	rst,
	normal_addr,
	normal_din,
	normal_be,
	normal_rd,
	normal_wr,
	normal_dout,
	normal_ack,
	shift_valid,
	shift_write,
	shift_addr,
	shift_wdata,
	shift_rdata,
	shift_ready,
	shared_addr,
	shared_din,
	shared_be,
	shared_rd,
	shared_wr,
	shared_dout,
	shared_ack,
	shift_owned,
	protocol_error
);
	parameter signed [31:0] ADDR_WIDTH = 25;
	input wire clk;
	input wire rst;
	input wire [ADDR_WIDTH - 1:0] normal_addr;
	input wire [15:0] normal_din;
	input wire [1:0] normal_be;
	input wire normal_rd;
	input wire normal_wr;
	output wire [15:0] normal_dout;
	output wire normal_ack;
	input wire shift_valid;
	input wire shift_write;
	input wire [17:0] shift_addr;
	input wire [15:0] shift_wdata;
	output wire [15:0] shift_rdata;
	output wire shift_ready;
	output wire [ADDR_WIDTH - 1:0] shared_addr;
	output wire [15:0] shared_din;
	output wire [1:0] shared_be;
	output wire shared_rd;
	output wire shared_wr;
	input wire [15:0] shared_dout;
	input wire shared_ack;
	output wire shift_owned;
	output reg protocol_error;
	reg [1:0] owner;
	reg [ADDR_WIDTH - 1:0] addr_q;
	reg [15:0] din_q;
	reg [1:0] be_q;
	reg write_q;
	wire normal_request = normal_rd || normal_wr;
	assign shared_addr = addr_q;
	assign shared_din = din_q;
	assign shared_be = be_q;
	assign shared_rd = (owner != 2'd0) && !write_q;
	assign shared_wr = (owner != 2'd0) && write_q;
	assign normal_dout = shared_dout;
	assign normal_ack = (owner == 2'd1) && shared_ack;
	assign shift_rdata = shared_dout;
	assign shift_ready = (owner == 2'd2) && shared_ack;
	assign shift_owned = owner == 2'd2;
	always @(posedge clk)
		if (rst) begin
			owner <= 2'd0;
			addr_q <= 1'sb0;
			din_q <= 16'd0;
			be_q <= 2'd0;
			write_q <= 1'b0;
			protocol_error <= 1'b0;
		end
		else begin
			if (normal_rd && normal_wr)
				protocol_error <= 1'b1;
			(* full_case, parallel_case *)
			case (owner)
				2'd0:
					if (shift_valid) begin
						addr_q <= {{ADDR_WIDTH - 18 {1'b0}}, shift_addr};
						din_q <= shift_wdata;
						be_q <= 2'b11;
						write_q <= shift_write;
						owner <= 2'd2;
					end
					else if (normal_request) begin
						addr_q <= normal_addr;
						din_q <= normal_din;
						be_q <= normal_be;
						write_q <= normal_wr;
						owner <= 2'd1;
					end
				2'd1, 2'd2:
					if (shared_ack)
						owner <= 2'd0;
				default: owner <= 2'd0;
			endcase
		end
endmodule
`default_nettype wire
`default_nettype none
module yunit_video (
	clk,
	rst,
	ce_pix,
	bpp4,
	use_dynamic_display,
	display_contract_valid,
	line_event,
	line_desc_valid,
	line_desc_row_phys,
	line_desc_col_word,
	line_cache_ready,
	visible_px,
	flip_x,
	vram_raddr,
	vram_rdata,
	pal_raddr,
	pal_rdata,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de,
	vblank_raw,
	vblank_irq
);
	reg _sv2v_0;
	parameter signed [31:0] H_ACT = 410;
	parameter signed [31:0] H_FP = 6;
	parameter signed [31:0] H_SYNC = 44;
	parameter signed [31:0] H_BP = 46;
	parameter signed [31:0] V_ACT = 256;
	parameter signed [31:0] V_FP = 13;
	parameter signed [31:0] V_SYNC = 4;
	parameter signed [31:0] V_BP = 16;
	parameter signed [31:0] DISP_ROW0 = 0;
	input wire clk;
	input wire rst;
	input wire ce_pix;
	input wire bpp4;
	input wire use_dynamic_display;
	input wire display_contract_valid;
	input wire line_event;
	input wire line_desc_valid;
	input wire [8:0] line_desc_row_phys;
	input wire [8:0] line_desc_col_word;
	input wire line_cache_ready;
	input wire [11:0] visible_px;
	input wire flip_x;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	output reg [17:0] vram_raddr;
	input wire [15:0] vram_rdata;
	output wire [11:0] pal_raddr;
	input wire [15:0] pal_rdata;
	output reg [7:0] vid_r;
	output reg [7:0] vid_g;
	output reg [7:0] vid_b;
	output reg hsync;
	output reg vsync;
	output reg hblank;
	output reg vblank;
	output reg de;
	output wire vblank_raw;
	output reg vblank_irq;
	localparam signed [31:0] H_TOTAL = ((H_ACT + H_FP) + H_SYNC) + H_BP;
	localparam signed [31:0] V_TOTAL = ((V_ACT + V_FP) + V_SYNC) + V_BP;
	reg [11:0] hc;
	reg [11:0] vc;
	reg s0_de;
	reg s0_hs;
	reg s0_vs;
	reg s0_hb;
	reg s0_vb;
	reg [11:0] s0_x;
	reg [11:0] s0_y;
	reg [8:0] display_row;
	reg [8:0] display_col;
	reg display_line_valid;
	wire dynamic_display = use_dynamic_display === 1'b1;
	wire dynamic_contract_ok = display_contract_valid === 1'b1;
	wire dynamic_cache_ok = line_cache_ready === 1'b1;
	function automatic signed [8:0] sv2v_cast_9_signed;
		input reg signed [8:0] inp;
		sv2v_cast_9_signed = inp;
	endfunction
	always @(posedge clk)
		if (rst) begin
			display_row <= sv2v_cast_9_signed(DISP_ROW0);
			display_col <= 9'd0;
			display_line_valid <= 1'b0;
		end
		else if (dynamic_display && (line_event === 1'b1)) begin
			display_line_valid <= line_desc_valid === 1'b1;
			if (line_desc_valid === 1'b1) begin
				display_row <= line_desc_row_phys;
				display_col <= line_desc_col_word;
			end
		end
	function automatic signed [11:0] sv2v_cast_12_signed;
		input reg signed [11:0] inp;
		sv2v_cast_12_signed = inp;
	endfunction
	always @(posedge clk)
		if (rst) begin
			hc <= sv2v_cast_12_signed(H_ACT + H_FP);
			vc <= sv2v_cast_12_signed((V_ACT + V_FP) - 1);
			vblank_irq <= 1'b0;
		end
		else if (ce_pix) begin
			vblank_irq <= 1'b0;
			if (hc == (H_TOTAL - 1)) begin
				hc <= 1'sb0;
				if (vc == (V_TOTAL - 1))
					vc <= 1'sb0;
				else begin
					vc <= vc + 12'd1;
					if (vc == (V_ACT - 1))
						vblank_irq <= 1'b1;
				end
			end
			else
				hc <= hc + 12'd1;
		end
	always @(*) begin
		if (_sv2v_0)
			;
		s0_x = hc;
		s0_y = vc;
		s0_de = ((hc < H_ACT) && (vc < V_ACT)) && (!dynamic_display || ((display_line_valid && dynamic_contract_ok) && dynamic_cache_ok));
		s0_hb = hc >= H_ACT;
		s0_vb = vc >= V_ACT;
		s0_hs = (hc >= (H_ACT + H_FP)) && (hc < ((H_ACT + H_FP) + H_SYNC));
		s0_vs = (vc >= (V_ACT + V_FP)) && (vc < ((V_ACT + V_FP) + V_SYNC));
	end
	wire [11:0] vis_w_c = (^visible_px === 1'bx ? sv2v_cast_12_signed(H_ACT) : visible_px);
	reg [11:0] vis_w;
	reg [11:0] vis_last_q;
	always @(posedge clk) begin
		vis_w <= vis_w_c;
		vis_last_q <= vis_w_c - 12'd1;
	end
	reg [11:0] x_mirror;
	(* preserve, dont_merge *) reg [11:0] scan_x_mirror_q;
	always @(posedge clk)
		if (rst) begin
			x_mirror <= 12'd0;
			scan_x_mirror_q <= 12'd0;
		end
		else if (ce_pix) begin
			if (hc == (H_TOTAL - 1)) begin
				x_mirror <= vis_last_q;
				scan_x_mirror_q <= vis_last_q;
			end
			else begin
				x_mirror <= x_mirror - 12'd1;
				scan_x_mirror_q <= x_mirror - 12'd1;
			end
		end
	wire [11:0] x_eff = (flip_x === 1'b1 ? scan_x_mirror_q : s0_x);
	localparam signed [31:0] yunit_pkg_FB_ROWSHIFT = 9;
	function automatic [17:0] sv2v_cast_18;
		input reg [17:0] inp;
		sv2v_cast_18 = inp;
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		if (dynamic_display)
			vram_raddr = {display_row, display_col + x_eff[8:0]};
		else
			vram_raddr = sv2v_cast_18(((DISP_ROW0 + s0_y) << yunit_pkg_FB_ROWSHIFT) + (x_eff & 12'h1ff));
	end
	assign vblank_raw = s0_vb;
	reg s1_de;
	reg s1_hs;
	reg s1_vs;
	reg s1_hb;
	reg s1_vb;
	reg s2_de;
	reg s2_hs;
	reg s2_vs;
	reg s2_hb;
	reg s2_vb;
	always @(posedge clk)
		if (rst) begin
			s1_de <= 0;
			s1_hs <= 0;
			s1_vs <= 0;
			s1_hb <= 0;
			s1_vb <= 0;
			s2_de <= 0;
			s2_hs <= 0;
			s2_vs <= 0;
			s2_hb <= 0;
			s2_vb <= 0;
		end
		else if (ce_pix) begin
			s1_de <= s0_de;
			s1_hs <= s0_hs;
			s1_vs <= s0_vs;
			s1_hb <= s0_hb;
			s1_vb <= s0_vb;
			s2_de <= s1_de;
			s2_hs <= s1_hs;
			s2_vs <= s1_vs;
			s2_hb <= s1_hb;
			s2_vb <= s1_vb;
		end
	function automatic [11:0] yunit_pkg_pen_map4;
		input reg [15:0] w;
		yunit_pkg_pen_map4 = {4'b0000, w[15:12], w[3:0]};
	endfunction
	function automatic [11:0] yunit_pkg_pen_map6;
		input reg [15:0] w;
		yunit_pkg_pen_map6 = {w[11:8], w[15:14], w[5:0]};
	endfunction
	assign pal_raddr = (bpp4 === 1'b1 ? yunit_pkg_pen_map4(vram_rdata) : yunit_pkg_pen_map6(vram_rdata));
	wire [23:0] rgb;
	function automatic [23:0] yunit_pkg_rgb555_to_888;
		input reg [15:0] c;
		reg [4:0] r5;
		reg [4:0] g5;
		reg [4:0] b5;
		begin
			r5 = c[14:10];
			g5 = c[9:5];
			b5 = c[4:0];
			yunit_pkg_rgb555_to_888 = {r5, r5[4:2], g5, g5[4:2], b5, b5[4:2]};
		end
	endfunction
	assign rgb = yunit_pkg_rgb555_to_888(pal_rdata);
	wire s0_vis = s0_x < vis_w;
	reg s1_vis;
	reg s2_vis;
	always @(posedge clk)
		if (rst) begin
			s1_vis <= 1'b1;
			s2_vis <= 1'b1;
		end
		else if (ce_pix) begin
			s1_vis <= s0_vis;
			s2_vis <= s1_vis;
		end
	wire pix_on = s2_de && s2_vis;
	always @(posedge clk)
		if (rst) begin
			de <= 0;
			hsync <= 0;
			vsync <= 0;
			hblank <= 0;
			vblank <= 0;
			vid_r <= 0;
			vid_g <= 0;
			vid_b <= 0;
		end
		else if (ce_pix) begin
			de <= s2_de;
			hsync <= s2_hs;
			vsync <= s2_vs;
			hblank <= s2_hb;
			vblank <= s2_vb;
			vid_r <= (pix_on ? rgb[23:16] : 8'h00);
			vid_g <= (pix_on ? rgb[15:8] : 8'h00);
			vid_b <= (pix_on ? rgb[7:0] : 8'h00);
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_scanline (
	clk,
	rst,
	ce_pix,
	vblank,
	use_dynamic_display,
	line_event,
	current_line_valid,
	current_line_row,
	current_line_col,
	prefetch_valid,
	prefetch_row,
	prefetch_col,
	current_row_ready,
	vram_raddr,
	vram_rdata,
	snoop_we,
	snoop_addr,
	snoop_data,
	invalidate_valid,
	invalidate_row,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack
);
	reg _sv2v_0;
	parameter signed [31:0] FB_ADDR_W = 18;
	parameter signed [31:0] NCOL = 512;
	parameter signed [31:0] FIRST_ROW = 0;
	input wire clk;
	input wire rst;
	input wire ce_pix;
	input wire vblank;
	input wire use_dynamic_display;
	input wire line_event;
	input wire current_line_valid;
	input wire [8:0] current_line_row;
	input wire [8:0] current_line_col;
	input wire prefetch_valid;
	input wire [8:0] prefetch_row;
	input wire [8:0] prefetch_col;
	output reg current_row_ready;
	input wire [FB_ADDR_W - 1:0] vram_raddr;
	output wire [15:0] vram_rdata;
	input wire snoop_we;
	input wire [FB_ADDR_W - 1:0] snoop_addr;
	input wire [15:0] snoop_data;
	input wire invalidate_valid;
	input wire [8:0] invalidate_row;
	output reg scan_req;
	output wire [17:0] scan_addr;
	input wire [15:0] scan_data;
	input wire scan_ack;
	localparam signed [31:0] ROWW = FB_ADDR_W - 9;
	localparam signed [31:0] REFILL_WORDS = NCOL;
	wire [ROWW - 1:0] req_row = vram_raddr[FB_ADDR_W - 1:9];
	wire [8:0] req_col = vram_raddr[8:0];
	(* ramstyle = "no_rw_check" *) reg [15:0] lb0 [0:511];
	(* ramstyle = "no_rw_check" *) reg [15:0] lb1 [0:511];
	(* ramstyle = "no_rw_check" *) reg [15:0] ov0 [0:511];
	(* ramstyle = "no_rw_check" *) reg [15:0] ov1 [0:511];
	reg [511:0] ov0_valid;
	reg [511:0] ov1_valid;
	reg disp_sel;
	reg [ROWW - 1:0] disp_row;
	reg [8:0] disp_col;
	reg [ROWW - 1:0] buf_row [0:1];
	reg buf_valid [0:1];
	reg [8:0] buf_col [0:1];
	reg [ROWW - 1:0] next_row_q;
	reg [8:0] next_col_q;
	reg next_valid_q;
	wire dynamic_display = use_dynamic_display === 1'b1;
	wire line_event_on = line_event === 1'b1;
	wire current_line_valid_on = current_line_valid === 1'b1;
	wire prefetch_valid_on = prefetch_valid === 1'b1;
	wire invalidate_on = invalidate_valid === 1'b1;
	wire [ROWW - 1:0] next_row = (dynamic_display ? next_row_q : disp_row + 1'b1);
	wire [8:0] next_col = (dynamic_display ? next_col_q : 9'd0);
	wire next_valid = (dynamic_display ? next_valid_q : 1'b1);
	function automatic col_in_window;
		input reg [8:0] col;
		input reg [8:0] first_col;
		reg [8:0] delta;
		begin
			delta = col - first_col;
			if (REFILL_WORDS >= 512)
				col_in_window = 1'b1;
			else
				col_in_window = delta < REFILL_WORDS;
		end
	endfunction
	wire ready0 = (buf_valid[0] && (buf_row[0] == disp_row)) && (!dynamic_display || (buf_col[0] == disp_col));
	wire ready1 = (buf_valid[1] && (buf_row[1] == disp_row)) && (!dynamic_display || (buf_col[1] == disp_col));
	wire hit0 = ((buf_valid[0] && (buf_row[0] == req_row)) && (!dynamic_display || (buf_col[0] == disp_col))) && col_in_window(req_col, buf_col[0]);
	wire hit1 = ((buf_valid[1] && (buf_row[1] == req_row)) && (!dynamic_display || (buf_col[1] == disp_col))) && col_in_window(req_col, buf_col[1]);
	wire sel_now = (hit0 ? 1'b0 : (hit1 ? 1'b1 : disp_sel));
	always @(*) begin
		if (_sv2v_0)
			;
		current_row_ready = ready0 || ready1;
	end
	function automatic signed [ROWW - 1:0] sv2v_cast_AD1AC_signed;
		input reg signed [ROWW - 1:0] inp;
		sv2v_cast_AD1AC_signed = inp;
	endfunction
	wire [ROWW - 1:0] planned_row0 = (!dynamic_display ? (vblank ? sv2v_cast_AD1AC_signed(FIRST_ROW) : (sel_now ? req_row + 1'b1 : req_row)) : (disp_sel ? (next_valid ? next_row : disp_row) : disp_row));
	wire [ROWW - 1:0] planned_row1 = (!dynamic_display ? (vblank ? sv2v_cast_AD1AC_signed(FIRST_ROW + 1) : (sel_now ? req_row : req_row + 1'b1)) : (disp_sel ? disp_row : (next_valid ? next_row : disp_row)));
	wire [8:0] planned_col0 = (!dynamic_display ? 9'd0 : (disp_sel ? (next_valid ? next_col : disp_col) : disp_col));
	wire [8:0] planned_col1 = (!dynamic_display ? 9'd0 : (disp_sel ? disp_col : (next_valid ? next_col : disp_col)));
	reg [15:0] lb0_q;
	reg [15:0] lb1_q;
	reg [15:0] ov0_q;
	reg [15:0] ov1_q;
	reg ovv0_q;
	reg ovv1_q;
	reg sel_q;
	reg hit_q;
	always @(posedge clk)
		if (ce_pix) begin
			lb0_q <= lb0[req_col];
			lb1_q <= lb1[req_col];
			ov0_q <= ov0[req_col];
			ov1_q <= ov1[req_col];
			ovv0_q <= ov0_valid[req_col];
			ovv1_q <= ov1_valid[req_col];
			sel_q <= sel_now;
			hit_q <= hit0 || hit1;
		end
	assign vram_rdata = (!hit_q ? 16'd0 : (sel_q ? (ovv1_q ? ov1_q : lb1_q) : (ovv0_q ? ov0_q : lb0_q)));
	wire [ROWW - 1:0] snoop_row = snoop_addr[FB_ADDR_W - 1:9];
	wire [8:0] snoop_col = snoop_addr[8:0];
	reg loading;
	reg tgt_sel;
	reg [ROWW - 1:0] tgt_row;
	reg [8:0] tgt_col;
	reg [8:0] li;
	reg vbl_q;
	wire frame_start = !vbl_q && vblank;
	wire row_advance = !vblank && (req_row != disp_row);
	wire descriptor_advance = ((dynamic_display && line_event_on) && current_line_valid_on) && ((current_line_row[ROWW - 1:0] != disp_row) || (current_line_col != disp_col));
	wire blank_retarget = ((((dynamic_display && line_event_on) && !current_line_valid_on) && vblank) && prefetch_valid_on) && ((prefetch_row[ROWW - 1:0] != disp_row) || (prefetch_col != disp_col));
	wire descriptor_hit0 = (buf_valid[0] && (buf_row[0] == current_line_row[ROWW - 1:0])) && (buf_col[0] == current_line_col);
	wire descriptor_hit1 = (buf_valid[1] && (buf_row[1] == current_line_row[ROWW - 1:0])) && (buf_col[1] == current_line_col);
	wire descriptor_sel = (descriptor_hit0 ? 1'b0 : (descriptor_hit1 ? 1'b1 : (descriptor_advance ? ~disp_sel : disp_sel)));
	wire promote_future_overlay = (((descriptor_advance && next_valid) && (next_row == current_line_row[ROWW - 1:0])) && (next_col == current_line_col)) && (descriptor_sel != disp_sel);
	wire prefetch_retarget = ((dynamic_display && line_event_on) && prefetch_valid_on) && ((!next_valid_q || (prefetch_row[ROWW - 1:0] != next_row_q)) || (prefetch_col != next_col_q));
	wire snoop_to0 = ((snoop_we && col_in_window(snoop_col, planned_col0)) && (snoop_row == planned_row0)) && (vblank || sel_now);
	wire snoop_to1 = ((snoop_we && col_in_window(snoop_col, planned_col1)) && (snoop_row == planned_row1)) && (vblank || !sel_now);
	wire disp_stale = (!buf_valid[disp_sel] || (buf_row[disp_sel] != disp_row)) || (dynamic_display && (buf_col[disp_sel] != disp_col));
	wire load_stale = (next_valid && ((next_row != disp_row) || (dynamic_display && (next_col != disp_col)))) && ((!buf_valid[~disp_sel] || (buf_row[~disp_sel] != next_row)) || (dynamic_display && (buf_col[~disp_sel] != next_col)));
	wire loader_start_ok = (!loading && !frame_start) && !(dynamic_display && line_event_on);
	wire start_disp_load = loader_start_ok && disp_stale;
	wire start_next_load = (loader_start_ok && !disp_stale) && load_stale;
	reg [511:0] ov0_valid_next;
	reg [511:0] ov1_valid_next;
	always @(*) begin
		if (_sv2v_0)
			;
		ov0_valid_next = ov0_valid;
		ov1_valid_next = ov1_valid;
		if (frame_start) begin
			ov0_valid_next = 1'sb0;
			ov1_valid_next = 1'sb0;
		end
		else if (row_advance || descriptor_advance) begin
			if (disp_sel)
				ov1_valid_next = 1'sb0;
			else
				ov0_valid_next = 1'sb0;
		end
		if (blank_retarget) begin
			if ((buf_valid[0] && (buf_row[0] == prefetch_row[ROWW - 1:0])) && (buf_col[0] == prefetch_col))
				;
			else if ((buf_valid[1] && (buf_row[1] == prefetch_row[ROWW - 1:0])) && (buf_col[1] == prefetch_col))
				;
			else if (disp_sel)
				ov1_valid_next = 1'sb0;
			else
				ov0_valid_next = 1'sb0;
		end
		if (((prefetch_retarget && !promote_future_overlay) && ((prefetch_row[ROWW - 1:0] != disp_row) || (prefetch_col != disp_col))) && ((!buf_valid[~disp_sel] || (buf_row[~disp_sel] != prefetch_row[ROWW - 1:0])) || (buf_col[~disp_sel] != prefetch_col))) begin
			if (~disp_sel)
				ov1_valid_next = 1'sb0;
			else
				ov0_valid_next = 1'sb0;
		end
		if (invalidate_on) begin
			if (((planned_row0 == invalidate_row[ROWW - 1:0]) || (buf_valid[0] && (buf_row[0] == invalidate_row[ROWW - 1:0]))) || ((loading && !tgt_sel) && (tgt_row == invalidate_row[ROWW - 1:0])))
				ov0_valid_next = 1'sb0;
			if (((planned_row1 == invalidate_row[ROWW - 1:0]) || (buf_valid[1] && (buf_row[1] == invalidate_row[ROWW - 1:0]))) || ((loading && tgt_sel) && (tgt_row == invalidate_row[ROWW - 1:0])))
				ov1_valid_next = 1'sb0;
		end
		if (snoop_to0)
			ov0_valid_next[snoop_col] = 1'b1;
		if (snoop_to1)
			ov1_valid_next[snoop_col] = 1'b1;
	end
	always @(posedge clk)
		if (rst) begin
			loading <= 1'b0;
			scan_req <= 1'b0;
			disp_sel <= 1'b0;
			disp_row <= 1'sb0;
			disp_col <= 9'd0;
			buf_valid[0] <= 1'b0;
			buf_valid[1] <= 1'b0;
			buf_col[0] <= 9'd0;
			buf_col[1] <= 9'd0;
			ov0_valid <= 1'sb0;
			ov1_valid <= 1'sb0;
			next_row_q <= sv2v_cast_AD1AC_signed(FIRST_ROW + 1);
			next_col_q <= 9'd0;
			next_valid_q <= 1'b0;
			vbl_q <= 1'b0;
		end
		else begin
			vbl_q <= vblank;
			ov0_valid <= ov0_valid_next;
			ov1_valid <= ov1_valid_next;
			if (frame_start) begin
				disp_sel <= 1'b0;
				disp_row <= (dynamic_display && next_valid_q ? next_row_q : sv2v_cast_AD1AC_signed(FIRST_ROW));
				disp_col <= (dynamic_display && next_valid_q ? next_col_q : 9'd0);
				buf_valid[0] <= 1'b0;
				buf_valid[1] <= 1'b0;
				loading <= 1'b0;
				scan_req <= 1'b0;
			end
			else begin
				if (dynamic_display && line_event_on) begin
					next_valid_q <= prefetch_valid_on;
					if (prefetch_valid_on) begin
						next_row_q <= prefetch_row[ROWW - 1:0];
						next_col_q <= prefetch_col;
					end
					if (current_line_valid_on) begin
						disp_row <= current_line_row[ROWW - 1:0];
						disp_col <= current_line_col;
						disp_sel <= descriptor_sel;
					end
					else if ((vblank && prefetch_valid_on) && ((prefetch_row[ROWW - 1:0] != disp_row) || (prefetch_col != disp_col))) begin
						disp_row <= prefetch_row[ROWW - 1:0];
						disp_col <= prefetch_col;
						if ((buf_valid[0] && (buf_row[0] == prefetch_row[ROWW - 1:0])) && (buf_col[0] == prefetch_col))
							disp_sel <= 1'b0;
						else if ((buf_valid[1] && (buf_row[1] == prefetch_row[ROWW - 1:0])) && (buf_col[1] == prefetch_col))
							disp_sel <= 1'b1;
					end
				end
				if (row_advance) begin
					if (hit0)
						disp_sel <= 1'b0;
					else if (hit1)
						disp_sel <= 1'b1;
					else
						disp_sel <= ~disp_sel;
					disp_row <= req_row;
				end
				if (!loading) begin
					scan_req <= 1'b0;
					if (start_disp_load) begin
						tgt_sel <= disp_sel;
						tgt_row <= disp_row;
						tgt_col <= disp_col;
						li <= 9'd0;
						loading <= 1'b1;
						buf_valid[disp_sel] <= 1'b0;
					end
					else if (start_next_load) begin
						tgt_sel <= ~disp_sel;
						tgt_row <= next_row;
						tgt_col <= next_col;
						li <= 9'd0;
						loading <= 1'b1;
						buf_valid[~disp_sel] <= 1'b0;
					end
				end
				else if (scan_req && scan_ack) begin
					if (tgt_sel)
						lb1[tgt_col + li] <= scan_data;
					else
						lb0[tgt_col + li] <= scan_data;
					scan_req <= 1'b0;
					if (li == (REFILL_WORDS - 1)) begin
						loading <= 1'b0;
						buf_row[tgt_sel] <= tgt_row;
						buf_col[tgt_sel] <= tgt_col;
						buf_valid[tgt_sel] <= 1'b1;
					end
					else
						li <= li + 9'd1;
				end
				else if (!scan_req)
					scan_req <= 1'b1;
				if (invalidate_on) begin
					if (buf_valid[0] && (buf_row[0] == invalidate_row[ROWW - 1:0]))
						buf_valid[0] <= 1'b0;
					if (buf_valid[1] && (buf_row[1] == invalidate_row[ROWW - 1:0]))
						buf_valid[1] <= 1'b0;
					if (loading && (tgt_row == invalidate_row[ROWW - 1:0])) begin
						loading <= 1'b0;
						scan_req <= 1'b0;
						buf_valid[tgt_sel] <= 1'b0;
					end
				end
			end
			if (snoop_to0)
				ov0[snoop_col] <= snoop_data;
			if (snoop_to1)
				ov1[snoop_col] <= snoop_data;
		end
	assign scan_addr = {tgt_row[8:0], tgt_col + li};
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_video_top (
	clk,
	rst,
	ce_pix,
	bpp4,
	use_dynamic_display,
	display_contract_valid,
	display_line_event,
	display_line_valid,
	display_line_row_phys,
	display_line_col_word,
	display_prefetch_valid,
	display_prefetch_row_phys,
	display_prefetch_col_word,
	visible_px,
	flip_x,
	snoop_we,
	snoop_addr,
	snoop_data,
	invalidate_valid,
	invalidate_row,
	pal_raddr,
	pal_rdata,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de,
	vblank_irq
);
	parameter signed [31:0] H_ACT = 410;
	parameter signed [31:0] H_FP = 6;
	parameter signed [31:0] H_SYNC = 44;
	parameter signed [31:0] H_BP = 46;
	parameter signed [31:0] V_ACT = 256;
	parameter signed [31:0] V_FP = 13;
	parameter signed [31:0] V_SYNC = 4;
	parameter signed [31:0] V_BP = 16;
	parameter signed [31:0] DISP_ROW0 = 0;
	parameter signed [31:0] NCOL = 512;
	input wire clk;
	input wire rst;
	input wire ce_pix;
	input wire bpp4;
	input wire use_dynamic_display;
	input wire display_contract_valid;
	input wire display_line_event;
	input wire display_line_valid;
	input wire [8:0] display_line_row_phys;
	input wire [8:0] display_line_col_word;
	input wire display_prefetch_valid;
	input wire [8:0] display_prefetch_row_phys;
	input wire [8:0] display_prefetch_col_word;
	input wire [11:0] visible_px;
	input wire flip_x;
	input wire snoop_we;
	input wire [17:0] snoop_addr;
	input wire [15:0] snoop_data;
	input wire invalidate_valid;
	input wire [8:0] invalidate_row;
	output wire [11:0] pal_raddr;
	input wire [15:0] pal_rdata;
	output wire scan_req;
	output wire [17:0] scan_addr;
	input wire [15:0] scan_data;
	input wire scan_ack;
	output wire [7:0] vid_r;
	output wire [7:0] vid_g;
	output wire [7:0] vid_b;
	output wire hsync;
	output wire vsync;
	output wire hblank;
	output wire vblank;
	output wire de;
	output wire vblank_irq;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	wire [17:0] vram_raddr;
	wire [15:0] vram_rdata;
	wire vblank_i;
	wire vblank_scan;
	wire line_cache_ready;
	yunit_video #(
		.H_ACT(H_ACT),
		.H_FP(H_FP),
		.H_SYNC(H_SYNC),
		.H_BP(H_BP),
		.V_ACT(V_ACT),
		.V_FP(V_FP),
		.V_SYNC(V_SYNC),
		.V_BP(V_BP),
		.DISP_ROW0(DISP_ROW0)
	) u_video(
		.clk(clk),
		.rst(rst),
		.ce_pix(ce_pix),
		.bpp4(bpp4),
		.use_dynamic_display(use_dynamic_display),
		.display_contract_valid(display_contract_valid),
		.line_event(display_line_event),
		.line_desc_valid(display_line_valid),
		.line_desc_row_phys(display_line_row_phys),
		.line_desc_col_word(display_line_col_word),
		.line_cache_ready(line_cache_ready),
		.visible_px(visible_px),
		.flip_x(flip_x),
		.vram_raddr(vram_raddr),
		.vram_rdata(vram_rdata),
		.pal_raddr(pal_raddr),
		.pal_rdata(pal_rdata),
		.vid_r(vid_r),
		.vid_g(vid_g),
		.vid_b(vid_b),
		.hsync(hsync),
		.vsync(vsync),
		.hblank(hblank),
		.vblank(vblank_i),
		.de(de),
		.vblank_raw(vblank_scan),
		.vblank_irq(vblank_irq)
	);
	assign vblank = vblank_i;
	wire scanline_vblank = vblank_scan;
	yunit_scanline #(
		.FB_ADDR_W(yunit_pkg_FB_ADDR_W),
		.NCOL(NCOL),
		.FIRST_ROW(DISP_ROW0)
	) u_scan(
		.clk(clk),
		.rst(rst),
		.ce_pix(ce_pix),
		.vblank(scanline_vblank),
		.use_dynamic_display(use_dynamic_display),
		.line_event(display_line_event),
		.current_line_valid(display_line_valid),
		.current_line_row(display_line_row_phys),
		.current_line_col(display_line_col_word),
		.prefetch_valid(display_prefetch_valid),
		.prefetch_row(display_prefetch_row_phys),
		.prefetch_col(display_prefetch_col_word),
		.current_row_ready(line_cache_ready),
		.vram_raddr(vram_raddr),
		.vram_rdata(vram_rdata),
		.snoop_we(snoop_we),
		.snoop_addr(snoop_addr),
		.snoop_data(snoop_data),
		.invalidate_valid(invalidate_valid),
		.invalidate_row(invalidate_row),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack)
	);
endmodule
`default_nettype wire
`default_nettype none
module yunit_palram (
	clk,
	rst,
	we_a,
	aa,
	awd,
	we_b,
	ba,
	bwd,
	raddr,
	rdata
);
	reg _sv2v_0;
	parameter signed [31:0] AW = 13;
	parameter signed [31:0] DEPTH = 1 << AW;
	input wire clk;
	input wire rst;
	input wire we_a;
	input wire [AW - 1:0] aa;
	input wire [15:0] awd;
	input wire we_b;
	input wire [AW - 1:0] ba;
	input wire [15:0] bwd;
	input wire [AW - 1:0] raddr;
	output reg [15:0] rdata;
	(* ramstyle = "no_rw_check" *) reg [15:0] mem [0:DEPTH - 1];
	localparam signed [31:0] QAW = 2;
	reg [AW + 15:0] q [0:3];
	reg [QAW:0] wptr;
	reg [QAW:0] rptr;
	wire qempty = wptr == rptr;
	reg w_we;
	reg [AW - 1:0] w_aa;
	reg [15:0] w_awd;
	always @(*) begin
		if (_sv2v_0)
			;
		w_we = !qempty;
		w_aa = q[rptr[1:0]][AW + 15:16];
		w_awd = q[rptr[1:0]][15:0];
	end
	always @(posedge clk)
		if (rst) begin
			wptr <= 1'sb0;
			rptr <= 1'sb0;
		end
		else begin
			if (!qempty)
				rptr <= rptr + 1'b1;
			if (we_a && we_b) begin
				q[wptr[1:0]] <= {aa, awd};
				q[wptr[1:0] + 1'b1] <= {ba, bwd};
				wptr <= wptr + 2'd2;
			end
			else if (we_a) begin
				q[wptr[1:0]] <= {aa, awd};
				wptr <= wptr + 1'b1;
			end
			else if (we_b) begin
				q[wptr[1:0]] <= {ba, bwd};
				wptr <= wptr + 1'b1;
			end
		end
	always @(posedge clk)
		if (w_we)
			mem[w_aa] <= w_awd;
	always @(posedge clk) rdata <= mem[raddr];
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_sdram_arb (
	clk,
	rst,
	vsd_addr,
	vsd_din,
	vsd_be,
	vsd_rd,
	vsd_wr,
	vsd_dout,
	vsd_ack,
	cgfx_rd,
	cgfx_addr,
	cgfx_data,
	cgfx_ack,
	src_rd,
	src_addr,
	src_data,
	src_ack,
	snd_rd,
	snd_addr,
	snd_data,
	snd_wdata,
	snd_ack,
	iol_rd,
	iol_wr,
	iol_addr,
	iol_din,
	iol_be,
	iol_dout,
	iol_ack,
	sd_addr,
	sd_din,
	sd_be,
	sd_rd,
	sd_wr,
	sd_dout,
	sd_ack
);
	reg _sv2v_0;
	parameter signed [31:0] SD_AW = 25;
	parameter [SD_AW - 1:0] GFXW_BASE = 25'h0000000;
	parameter [SD_AW - 1:0] ROMW_BASE = 25'h00c0000;
	parameter [SD_AW - 1:0] VRAMW_BASE = 25'h00e0000;
	parameter [SD_AW - 1:0] SOUNDW_BASE = 25'h0120000;
	parameter [23:0] GFX_BYTES = 24'h180000;
	input wire clk;
	input wire rst;
	input wire [SD_AW - 1:0] vsd_addr;
	input wire [15:0] vsd_din;
	input wire [1:0] vsd_be;
	input wire vsd_rd;
	input wire vsd_wr;
	output reg [15:0] vsd_dout;
	output reg vsd_ack;
	input wire cgfx_rd;
	input wire [23:0] cgfx_addr;
	output reg [15:0] cgfx_data;
	output reg cgfx_ack;
	input wire src_rd;
	input wire [23:0] src_addr;
	output reg [7:0] src_data;
	output reg src_ack;
	input wire snd_rd;
	input wire [20:0] snd_addr;
	output reg [7:0] snd_data;
	output reg [15:0] snd_wdata;
	output reg snd_ack;
	input wire iol_rd;
	input wire iol_wr;
	input wire [SD_AW - 1:0] iol_addr;
	input wire [15:0] iol_din;
	input wire [1:0] iol_be;
	output reg [15:0] iol_dout;
	output reg iol_ack;
	output reg [SD_AW - 1:0] sd_addr;
	output reg [15:0] sd_din;
	output reg [1:0] sd_be;
	output reg sd_rd;
	output reg sd_wr;
	input wire [15:0] sd_dout;
	input wire sd_ack;
	wire [SD_AW - 1:0] cgfx_word = (cgfx_addr < GFX_BYTES ? GFXW_BASE + {1'b0, cgfx_addr[23:1]} : ROMW_BASE + {1'b0, (cgfx_addr - GFX_BYTES) >> 1});
	wire [SD_AW - 1:0] src_word = GFXW_BASE + {1'b0, src_addr[23:1]};
	wire src_bsel = src_addr[0];
	wire [SD_AW - 1:0] snd_word = SOUNDW_BASE + {{SD_AW - 20 {1'b0}}, snd_addr[20:1]};
	wire snd_bsel = snd_addr[0];
	wire [SD_AW - 1:0] vsd_word = VRAMW_BASE + vsd_addr;
	localparam [2:0] G_NONE = 3'd0;
	localparam [2:0] G_IOL = 3'd1;
	localparam [2:0] G_VSD = 3'd2;
	localparam [2:0] G_CGFX = 3'd3;
	localparam [2:0] G_SRC = 3'd4;
	localparam [2:0] G_SOUND = 3'd5;
	wire vsd_req = vsd_rd | vsd_wr;
	wire iol_req = iol_rd | iol_wr;
	reg [2:0] gnt;
	reg gnt_held;
	reg [2:0] gnt_r;
	reg bubble;
	always @(*) begin
		if (_sv2v_0)
			;
		if (gnt_held)
			gnt = gnt_r;
		else if (bubble)
			gnt = G_NONE;
		else if (iol_req)
			gnt = G_IOL;
		else if (vsd_req)
			gnt = G_VSD;
		else if (snd_rd)
			gnt = G_SOUND;
		else if (cgfx_rd)
			gnt = G_CGFX;
		else if (src_rd)
			gnt = G_SRC;
		else
			gnt = G_NONE;
	end
	always @(posedge clk)
		if (rst) begin
			gnt_held <= 1'b0;
			gnt_r <= G_NONE;
			bubble <= 1'b0;
		end
		else begin
			bubble <= 1'b0;
			if (!gnt_held) begin
				if (!bubble && (gnt != G_NONE)) begin
					gnt_held <= 1'b1;
					gnt_r <= gnt;
				end
			end
			else if (sd_ack) begin
				gnt_held <= 1'b0;
				bubble <= 1'b1;
			end
		end
	reg src_bsel_q;
	reg snd_bsel_q;
	always @(posedge clk) begin
		if (gnt == G_SRC)
			src_bsel_q <= src_bsel;
		if (gnt == G_SOUND)
			snd_bsel_q <= snd_bsel;
	end
	always @(*) begin
		if (_sv2v_0)
			;
		sd_addr = 1'sb0;
		sd_din = 16'h0000;
		sd_be = 2'b00;
		sd_rd = 1'b0;
		sd_wr = 1'b0;
		vsd_ack = 1'b0;
		cgfx_ack = 1'b0;
		src_ack = 1'b0;
		snd_ack = 1'b0;
		iol_ack = 1'b0;
		vsd_dout = sd_dout;
		iol_dout = sd_dout;
		cgfx_data = sd_dout;
		src_data = (src_bsel_q ? sd_dout[15:8] : sd_dout[7:0]);
		snd_data = (snd_bsel_q ? sd_dout[15:8] : sd_dout[7:0]);
		snd_wdata = sd_dout;
		case (gnt)
			G_IOL: begin
				sd_addr = iol_addr;
				sd_din = iol_din;
				sd_be = iol_be;
				sd_rd = iol_rd;
				sd_wr = iol_wr;
				iol_ack = sd_ack;
			end
			G_VSD: begin
				sd_addr = vsd_word;
				sd_din = vsd_din;
				sd_be = vsd_be;
				sd_rd = vsd_rd;
				sd_wr = vsd_wr;
				vsd_ack = sd_ack;
			end
			G_CGFX: begin
				sd_addr = cgfx_word;
				sd_be = 2'b00;
				sd_rd = 1'b1;
				cgfx_ack = sd_ack;
			end
			G_SRC: begin
				sd_addr = src_word;
				sd_be = 2'b00;
				sd_rd = 1'b1;
				src_ack = sd_ack;
			end
			G_SOUND: begin
				sd_addr = snd_word;
				sd_be = 2'b00;
				sd_rd = 1'b1;
				snd_ack = sd_ack;
			end
			default:
				;
		endcase
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_sdram_burst_arb (
	clk,
	rst,
	scan_brd_req,
	scan_brd_addr,
	scan_brd_len,
	scan_brd_dout,
	scan_brd_dvalid,
	scan_brd_done,
	erase_brd_req,
	erase_brd_addr,
	erase_brd_len,
	erase_brd_dout,
	erase_brd_dvalid,
	erase_brd_done,
	erase_bwr_req,
	erase_bwr_addr,
	erase_bwr_len,
	erase_bwr_din,
	erase_bwr_wtbt,
	erase_bwr_valid,
	erase_bwr_ready,
	erase_bwr_done,
	brd_req,
	brd_addr,
	brd_len,
	brd_dout,
	brd_dvalid,
	brd_done,
	bwr_req,
	bwr_addr,
	bwr_len,
	bwr_din,
	bwr_wtbt,
	bwr_valid,
	bwr_ready,
	bwr_done,
	scan_owned,
	erase_owned,
	request_bubble,
	erase_waiting,
	protocol_error
);
	input wire clk;
	input wire rst;
	input wire scan_brd_req;
	input wire [24:0] scan_brd_addr;
	input wire [9:0] scan_brd_len;
	output wire [15:0] scan_brd_dout;
	output wire scan_brd_dvalid;
	output wire scan_brd_done;
	input wire erase_brd_req;
	input wire [24:0] erase_brd_addr;
	input wire [9:0] erase_brd_len;
	output wire [15:0] erase_brd_dout;
	output wire erase_brd_dvalid;
	output wire erase_brd_done;
	input wire erase_bwr_req;
	input wire [24:0] erase_bwr_addr;
	input wire [9:0] erase_bwr_len;
	input wire [15:0] erase_bwr_din;
	input wire [1:0] erase_bwr_wtbt;
	input wire erase_bwr_valid;
	output wire erase_bwr_ready;
	output wire erase_bwr_done;
	output wire brd_req;
	output wire [24:0] brd_addr;
	output wire [9:0] brd_len;
	input wire [15:0] brd_dout;
	input wire brd_dvalid;
	input wire brd_done;
	output wire bwr_req;
	output wire [24:0] bwr_addr;
	output wire [9:0] bwr_len;
	output wire [15:0] bwr_din;
	output wire [1:0] bwr_wtbt;
	output wire bwr_valid;
	input wire bwr_ready;
	input wire bwr_done;
	output wire scan_owned;
	output wire erase_owned;
	output wire request_bubble;
	output reg erase_waiting;
	output reg protocol_error;
	reg [1:0] state;
	reg [24:0] read_addr_q;
	reg [9:0] read_len_q;
	reg [24:0] write_addr_q;
	reg [9:0] write_len_q;
	reg erase_read_complete;
	wire erase_pair = erase_brd_req && erase_bwr_req;
	wire erase_half_request = erase_brd_req ^ erase_bwr_req;
	assign scan_owned = state == 2'd1;
	assign erase_owned = state == 2'd2;
	assign request_bubble = state == 2'd3;
	assign brd_req = scan_owned || erase_owned;
	assign brd_addr = read_addr_q;
	assign brd_len = read_len_q;
	assign bwr_req = erase_owned;
	assign bwr_addr = write_addr_q;
	assign bwr_len = write_len_q;
	assign bwr_din = erase_bwr_din;
	assign bwr_wtbt = erase_bwr_wtbt;
	assign bwr_valid = erase_owned && erase_bwr_valid;
	assign scan_brd_dout = (scan_owned ? brd_dout : 16'd0);
	assign scan_brd_dvalid = scan_owned && brd_dvalid;
	assign scan_brd_done = scan_owned && brd_done;
	assign erase_brd_dout = (erase_owned ? brd_dout : 16'd0);
	assign erase_brd_dvalid = erase_owned && brd_dvalid;
	assign erase_brd_done = erase_owned && brd_done;
	assign erase_bwr_ready = erase_owned && bwr_ready;
	assign erase_bwr_done = erase_owned && bwr_done;
	always @(posedge clk)
		if (rst) begin
			state <= 2'd0;
			erase_waiting <= 1'b0;
			protocol_error <= 1'b0;
			read_addr_q <= 25'd0;
			read_len_q <= 10'd0;
			write_addr_q <= 25'd0;
			write_len_q <= 10'd0;
			erase_read_complete <= 1'b0;
		end
		else begin
			if (erase_half_request && (state != 2'd2))
				protocol_error <= 1'b1;
			if (erase_pair && (state == 2'd1))
				erase_waiting <= 1'b1;
			else if (erase_waiting && !erase_pair) begin
				erase_waiting <= 1'b0;
				protocol_error <= 1'b1;
			end
			(* full_case, parallel_case *)
			case (state)
				2'd0:
					if (erase_waiting && erase_pair) begin
						read_addr_q <= erase_brd_addr;
						read_len_q <= erase_brd_len;
						write_addr_q <= erase_bwr_addr;
						write_len_q <= erase_bwr_len;
						erase_read_complete <= 1'b0;
						erase_waiting <= 1'b0;
						state <= 2'd2;
					end
					else if (scan_brd_req) begin
						read_addr_q <= scan_brd_addr;
						read_len_q <= scan_brd_len;
						if (erase_pair)
							erase_waiting <= 1'b1;
						state <= 2'd1;
					end
					else if (erase_pair) begin
						read_addr_q <= erase_brd_addr;
						read_len_q <= erase_brd_len;
						write_addr_q <= erase_bwr_addr;
						write_len_q <= erase_bwr_len;
						erase_read_complete <= 1'b0;
						erase_waiting <= 1'b0;
						state <= 2'd2;
					end
				2'd1: begin
					if (!scan_brd_req && !brd_done)
						protocol_error <= 1'b1;
					if (brd_done)
						state <= 2'd3;
				end
				2'd2: begin
					if (((!erase_read_complete && !erase_brd_req) && !brd_done) || (!erase_bwr_req && !bwr_done))
						protocol_error <= 1'b1;
					if (brd_done)
						erase_read_complete <= 1'b1;
					if (bwr_done)
						state <= 2'd3;
				end
				2'd3: state <= 2'd0;
				default: state <= 2'd0;
			endcase
		end
endmodule
`default_nettype wire
module sdram_stock (
	init,
	clk,
	SDRAM_DQ,
	SDRAM_A,
	SDRAM_DQML,
	SDRAM_DQMH,
	SDRAM_BA,
	SDRAM_nCS,
	SDRAM_nWE,
	SDRAM_nRAS,
	SDRAM_nCAS,
	SDRAM_CKE,
	wtbt,
	addr,
	dout,
	din,
	we,
	rd,
	ready,
	brd_req,
	brd_addr,
	brd_len,
	brd_dout,
	brd_dvalid,
	brd_done,
	bwr_req,
	bwr_addr,
	bwr_len,
	bwr_din,
	bwr_wtbt,
	bwr_valid,
	bwr_ready,
	bwr_done
);
	input init;
	input clk;
	inout [15:0] SDRAM_DQ;
	output reg [12:0] SDRAM_A;
	output reg SDRAM_DQML;
	output reg SDRAM_DQMH;
	output reg [1:0] SDRAM_BA;
	output wire SDRAM_nCS;
	output wire SDRAM_nWE;
	output wire SDRAM_nRAS;
	output wire SDRAM_nCAS;
	output wire SDRAM_CKE;
	input [1:0] wtbt;
	input [24:0] addr;
	output wire [15:0] dout;
	input [15:0] din;
	input we;
	input rd;
	output reg ready;
	input brd_req;
	input [24:0] brd_addr;
	input [9:0] brd_len;
	output reg [15:0] brd_dout;
	output reg brd_dvalid;
	output reg brd_done;
	input bwr_req;
	input [24:0] bwr_addr;
	input [9:0] bwr_len;
	input [15:0] bwr_din;
	input [1:0] bwr_wtbt;
	input bwr_valid;
	output wire bwr_ready;
	output reg bwr_done;
	localparam BURST_LENGTH = 3'b000;
	localparam ACCESS_TYPE = 1'b0;
	localparam CAS_LATENCY = 3'd2;
	localparam OP_MODE = 2'b00;
	localparam NO_WRITE_BURST = 1'b1;
	localparam MODE = {3'b000, NO_WRITE_BURST, OP_MODE, CAS_LATENCY, ACCESS_TYPE, BURST_LENGTH};
	localparam sdram_startup_cycles = 14'd12100;
	localparam cycles_per_refresh = 14'd780;
	localparam startup_refresh_max = 14'b11111111111111;
	localparam [2:0] CMD_NOP = 3'b111;
	localparam [2:0] CMD_ACTIVE = 3'b011;
	localparam [2:0] CMD_READ = 3'b101;
	localparam [2:0] CMD_WRITE = 3'b100;
	localparam [2:0] CMD_PRECHARGE = 3'b010;
	localparam [2:0] CMD_AUTO_REFRESH = 3'b001;
	localparam [2:0] CMD_LOAD_MODE = 3'b000;
	reg [2:0] command;
	reg [13:0] refresh_count = startup_refresh_max - sdram_startup_cycles;
	reg [24:0] save_addr;
	reg [15:0] data;
	reg old_we;
	reg old_rd;
	reg [CAS_LATENCY + 1:0] data_ready_delay;
	reg [15:0] dq_r;
	reg [15:0] new_data;
	reg [1:0] new_wtbt;
	reg new_we;
	reg new_rd;
	reg save_we = 1'b1;
	reg [31:0] state = 32'd0;
	reg [15:0] sdram_dq_out;
	reg sdram_dq_oe;
	reg old_brd;
	reg new_brd;
	reg [12:0] brd_row;
	reg [1:0] brd_bank;
	reg [8:0] brd_col;
	reg [9:0] brd_i;
	reg [9:0] brd_len_l;
	reg [CAS_LATENCY + 1:0] brd_vdelay;
	wire brd_issue = (state == 32'd12) && (brd_i < brd_len_l);
	reg old_bwr;
	reg new_bwr;
	reg [12:0] bwr_row;
	reg [1:0] bwr_bank;
	reg [8:0] bwr_col;
	reg [9:0] bwr_i;
	reg [9:0] bwr_len_l;
	wire bwr_beat = ((state == 32'd16) && (bwr_i < bwr_len_l)) && bwr_valid;
	assign bwr_ready = (state == 32'd16) && (bwr_i < bwr_len_l);
	assign SDRAM_DQ = (sdram_dq_oe ? sdram_dq_out : 16'bzzzzzzzzzzzzzzzz);
	assign SDRAM_CKE = 1;
	assign SDRAM_nCS = 0;
	assign SDRAM_nRAS = command[2];
	assign SDRAM_nCAS = command[1];
	assign SDRAM_nWE = command[0];
	wire [2:1] sv2v_tmp_B68B7;
	assign sv2v_tmp_B68B7 = SDRAM_A[12:11];
	always @(*) {SDRAM_DQMH, SDRAM_DQML} = sv2v_tmp_B68B7;
	assign dout = (save_addr[0] ? {data[7:0], data[15:8]} : {data[15:8], data[7:0]});
	always @(posedge clk) begin
		sdram_dq_oe <= 1'b0;
		command <= CMD_NOP;
		refresh_count <= refresh_count + 1'b1;
		dq_r <= SDRAM_DQ;
		data_ready_delay <= {1'b0, data_ready_delay[CAS_LATENCY + 1:1]};
		if (data_ready_delay[0])
			{ready, data} <= {1'b1, dq_r};
		brd_dvalid <= 1'b0;
		brd_done <= 1'b0;
		bwr_done <= 1'b0;
		brd_vdelay <= {brd_issue, brd_vdelay[CAS_LATENCY + 1:1]};
		if (brd_vdelay[0]) begin
			brd_dvalid <= 1'b1;
			brd_dout <= dq_r;
		end
		case (state)
			32'd0: begin
				SDRAM_A <= 0;
				SDRAM_BA <= 0;
				if (refresh_count == 16352) begin
					command <= CMD_PRECHARGE;
					SDRAM_A[10] <= 1;
					SDRAM_BA <= 2'b00;
				end
				if (refresh_count == 16360)
					command <= CMD_AUTO_REFRESH;
				if (refresh_count == 16368)
					command <= CMD_AUTO_REFRESH;
				if (refresh_count == 16376) begin
					command <= CMD_LOAD_MODE;
					SDRAM_A <= MODE;
				end
				if (!refresh_count) begin
					state <= 32'd3;
					ready <= 1;
					refresh_count <= 0;
				end
			end
			32'd10: state <= 32'd9;
			32'd9: state <= 32'd8;
			32'd8: state <= 32'd7;
			32'd7: state <= 32'd6;
			32'd6: state <= 32'd5;
			32'd5: state <= 32'd4;
			32'd4: begin
				state <= 32'd3;
				if (refresh_count > cycles_per_refresh) begin
					state <= 32'd10;
					command <= CMD_AUTO_REFRESH;
					refresh_count <= 0;
				end
			end
			32'd3:
				if (refresh_count > (cycles_per_refresh << 1))
					state <= 32'd4;
				else if (new_brd) begin
					new_brd <= 0;
					brd_i <= 10'd0;
					state <= 32'd11;
					command <= CMD_ACTIVE;
					SDRAM_A <= brd_row;
					SDRAM_BA <= brd_bank;
				end
				else if (new_bwr) begin
					new_bwr <= 0;
					bwr_i <= 10'd0;
					state <= 32'd15;
					command <= CMD_ACTIVE;
					SDRAM_A <= bwr_row;
					SDRAM_BA <= bwr_bank;
				end
				else if (new_rd | new_we) begin
					new_we <= 0;
					new_rd <= 0;
					save_we <= new_we;
					state <= 32'd1;
					command <= CMD_ACTIVE;
					SDRAM_A <= save_addr[22:10];
					SDRAM_BA <= save_addr[24:23];
				end
			32'd1: state <= 32'd2;
			32'd2: begin
				SDRAM_A <= {save_we & (new_wtbt ? ~new_wtbt[1] : ~save_addr[0]), save_we & (new_wtbt ? ~new_wtbt[0] : save_addr[0]), 2'b10, save_addr[9:1]};
				if (save_we) begin
					command <= CMD_WRITE;
					sdram_dq_out <= (new_wtbt ? new_data : {new_data[7:0], new_data[7:0]});
					sdram_dq_oe <= 1'b1;
					ready <= 1;
					state <= 32'd5;
				end
				else begin
					command <= CMD_READ;
					data_ready_delay[CAS_LATENCY + 1] <= 1;
					state <= 32'd8;
				end
			end
			32'd11: state <= 32'd12;
			32'd12:
				if (brd_i < brd_len_l) begin
					command <= CMD_READ;
					SDRAM_A <= {4'b0000, brd_col};
					brd_col <= brd_col + 9'd1;
					brd_i <= brd_i + 10'd1;
				end
				else
					state <= 32'd13;
			32'd13:
				if (brd_vdelay == 0) begin
					command <= CMD_PRECHARGE;
					SDRAM_A[10] <= 1'b1;
					state <= 32'd14;
				end
			32'd14: begin
				brd_done <= 1'b1;
				state <= 32'd3;
			end
			32'd15: state <= 32'd16;
			32'd16:
				if (bwr_i < bwr_len_l) begin
					if (bwr_beat) begin
						command <= CMD_WRITE;
						SDRAM_A <= {~bwr_wtbt[1], ~bwr_wtbt[0], 2'b00, bwr_col};
						sdram_dq_out <= bwr_din;
						sdram_dq_oe <= 1'b1;
						bwr_col <= bwr_col + 9'd1;
						bwr_i <= bwr_i + 10'd1;
					end
				end
				else
					state <= 32'd17;
			32'd17: state <= 32'd18;
			32'd18: begin
				command <= CMD_PRECHARGE;
				SDRAM_A[10] <= 1'b1;
				state <= 32'd19;
			end
			32'd19: begin
				bwr_done <= 1'b1;
				state <= 32'd3;
			end
			default: state <= 32'd3;
		endcase
		if (init) begin
			state <= 32'd0;
			refresh_count <= startup_refresh_max - sdram_startup_cycles;
			new_brd <= 1'b0;
			brd_vdelay <= 0;
			new_bwr <= 1'b0;
			bwr_i <= 10'd0;
		end
		old_we <= we;
		if (we & ~old_we) begin
			save_addr <= addr;
			{ready, new_we, new_data, new_wtbt} <= {2'b01, din, wtbt};
		end
		old_rd <= rd;
		if (rd & ~old_rd) begin
			save_addr <= addr;
			if (!((ready & ~save_we) & (save_addr[24:1] == addr[24:1])))
				{ready, new_rd} <= 2'b01;
		end
		old_brd <= brd_req;
		if (brd_req & ~old_brd) begin
			brd_row <= brd_addr[22:10];
			brd_bank <= brd_addr[24:23];
			brd_col <= brd_addr[9:1];
			brd_len_l <= brd_len;
			new_brd <= 1'b1;
		end
		old_bwr <= bwr_req;
		if (bwr_req & ~old_bwr) begin
			bwr_row <= bwr_addr[22:10];
			bwr_bank <= bwr_addr[24:23];
			bwr_col <= bwr_addr[9:1];
			bwr_len_l <= bwr_len;
			new_bwr <= 1'b1;
		end
	end
endmodule
`default_nettype none
module yunit_sdram_adapter (
	clk,
	rst,
	sd_addr,
	sd_din,
	sd_be,
	sd_rd,
	sd_wr,
	sd_dout,
	sd_ack,
	sdram_ready,
	ctl_addr,
	ctl_din,
	ctl_wtbt,
	ctl_rd,
	ctl_we,
	ctl_dout,
	ctl_ready
);
	input wire clk;
	input wire rst;
	input wire [24:0] sd_addr;
	input wire [15:0] sd_din;
	input wire [1:0] sd_be;
	input wire sd_rd;
	input wire sd_wr;
	output reg [15:0] sd_dout;
	output reg sd_ack;
	output wire sdram_ready;
	output reg [24:0] ctl_addr;
	output reg [15:0] ctl_din;
	output reg [1:0] ctl_wtbt;
	output reg ctl_rd;
	output reg ctl_we;
	input wire [15:0] ctl_dout;
	input wire ctl_ready;
	reg startup_done;
	reg [1:0] astate;
	always @(posedge clk)
		if (rst) begin
			astate <= 2'd0;
			ctl_rd <= 1'b0;
			ctl_we <= 1'b0;
			sd_ack <= 1'b0;
			startup_done <= 1'b0;
		end
		else begin
			sd_ack <= 1'b0;
			ctl_rd <= 1'b0;
			ctl_we <= 1'b0;
			if (ctl_ready)
				startup_done <= 1'b1;
			case (astate)
				2'd0:
					if (((sd_rd | sd_wr) & ctl_ready) & startup_done) begin
						ctl_addr <= {sd_addr[23:0], 1'b0};
						ctl_din <= sd_din;
						ctl_wtbt <= sd_be;
						ctl_rd <= sd_rd;
						ctl_we <= sd_wr;
						astate <= 2'd1;
					end
				2'd1: astate <= 2'd2;
				2'd2:
					if (ctl_ready) begin
						sd_dout <= ctl_dout;
						sd_ack <= 1'b1;
						astate <= 2'd3;
					end
				2'd3: astate <= 2'd0;
			endcase
		end
	assign sdram_ready = startup_done;
endmodule
`default_nettype wire
`default_nettype none
module yunit_src_cache (
	clk,
	rst,
	src_req,
	src_addr,
	src_data,
	src_ack,
	brd_req,
	brd_addr,
	brd_len,
	brd_dout,
	brd_dvalid,
	brd_done
);
	parameter [23:0] GFXW_BASE = 24'h000000;
	input wire clk;
	input wire rst;
	input wire src_req;
	input wire [23:0] src_addr;
	output reg [7:0] src_data;
	output reg src_ack;
	output reg brd_req;
	output reg [24:0] brd_addr;
	output reg [9:0] brd_len;
	input wire [15:0] brd_dout;
	input wire brd_dvalid;
	input wire brd_done;
	localparam signed [31:0] DEPTH = 16;
	localparam [9:0] FILL = 10'd8;
	reg [15:0] ring [0:15];
	reg [22:0] rw0;
	reg [4:0] cnt;
	reg [3:0] head;
	reg [3:0] st_idx;
	reg retarget;
	reg [5:0] cool;
	reg [1:0] fst;
	wire [22:0] q_word = src_addr[23:1];
	wire [22:0] q_off = q_word - rw0;
	wire in_win = q_off < {18'd0, cnt};
	wire serve = (src_req && !src_ack) && in_win;
	wire miss = (src_req && !src_ack) && !in_win;
	wire flush = miss && (q_word != rw0);
	wire [3:0] q_off4 = q_off[3:0];
	wire st = ((brd_dvalid && (fst == 2'd1)) && !retarget) && !flush;
	wire [22:0] f_word = rw0 + {18'd0, cnt};
	wire [9:0] col_left = 10'd512 - {1'b0, f_word[8:0]};
	wire [9:0] f_len = (col_left < FILL ? col_left : FILL);
	always @(posedge clk)
		if (rst) begin
			cnt <= 5'd0;
			head <= 4'd0;
			rw0 <= 23'd0;
			st_idx <= 4'd0;
			fst <= 2'd0;
			retarget <= 1'b0;
			brd_req <= 1'b0;
			brd_addr <= 25'd0;
			brd_len <= 10'd1;
			src_ack <= 1'b0;
			src_data <= 8'h00;
			cool <= 6'd40;
		end
		else begin
			src_ack <= 1'b0;
			if (cool != 6'd0)
				cool <= cool - 6'd1;
			if (serve) begin
				src_data <= (src_addr[0] ? ring[head + q_off4][15:8] : ring[head + q_off4][7:0]);
				src_ack <= 1'b1;
			end
			rw0 <= (flush ? q_word : (serve ? rw0 + q_off : rw0));
			cnt <= (flush ? 5'd0 : (cnt - (serve ? {1'b0, q_off4} : 5'd0)) + (st ? 5'd1 : 5'd0));
			head <= (flush ? 4'd0 : head + (serve ? q_off4 : 4'd0));
			if (st) begin
				ring[st_idx] <= brd_dout;
				st_idx <= st_idx + 4'd1;
			end
			if (flush)
				st_idx <= 4'd0;
			case (fst)
				2'd0:
					if (((cool == 6'd0) && (cnt <= 5'd8)) && !flush) begin
						st_idx <= head + cnt[3:0];
						brd_addr <= {1'b0, GFXW_BASE[22:0] + f_word, 1'b0};
						brd_len <= f_len;
						brd_req <= 1'b1;
						fst <= 2'd1;
					end
				2'd1: begin
					if (flush)
						retarget <= 1'b1;
					if (brd_done) begin
						brd_req <= 1'b0;
						retarget <= 1'b0;
						fst <= 2'd2;
					end
				end
				2'd2: fst <= 2'd0;
				default: fst <= 2'd0;
			endcase
		end
endmodule
`default_nettype wire
`default_nettype none
module yunit_gfx_unpack (
	clk,
	rst,
	start,
	plane_words,
	bpp4,
	busy,
	done,
	unp_rd,
	unp_wr,
	unp_addr,
	unp_din,
	unp_dout,
	unp_ack
);
	reg _sv2v_0;
	parameter signed [31:0] SD_AW = 25;
	parameter [SD_AW - 1:0] SCRATCH_WBASE = 25'h0120000;
	parameter [SD_AW - 1:0] GFXW_BASE = 25'h0000000;
	parameter [23:0] PLANE_WORDS = 24'h030000;
	input wire clk;
	input wire rst;
	input wire start;
	input wire [23:0] plane_words;
	input wire bpp4;
	output wire busy;
	output wire done;
	output reg unp_rd;
	output reg unp_wr;
	output reg [SD_AW - 1:0] unp_addr;
	output reg [15:0] unp_din;
	input wire [15:0] unp_dout;
	input wire unp_ack;
	function automatic [7:0] mkpix;
		input [7:0] b0;
		input [7:0] b1;
		input [7:0] b2;
		input [1:0] m;
		reg [1:0] d0;
		reg [1:0] d1;
		reg [1:0] d2;
		begin
			d0 = (b0 >> {m, 1'b0}) & 2'b11;
			d1 = (b1 >> {m, 1'b0}) & 2'b11;
			d2 = (b2 >> {m, 1'b0}) & 2'b11;
			mkpix = {2'b00, d2, d1, d0};
		end
	endfunction
	reg [3:0] st;
	reg [23:0] w;
	reg [15:0] p0;
	reg [15:0] p1;
	reg [15:0] fw0;
	reg [15:0] fw1;
	reg [15:0] fw2;
	reg [15:0] fw3;
	wire [23:0] pw = (^plane_words === 1'bx ? PLANE_WORDS : plane_words);
	wire is4 = bpp4 === 1'b1;
	wire [25:0] fourw = {w, 2'b00};
	wire [SD_AW - 1:0] a0 = SCRATCH_WBASE + {{SD_AW - 24 {1'b0}}, w};
	wire [SD_AW - 1:0] a1 = (SCRATCH_WBASE + pw) + {{SD_AW - 24 {1'b0}}, w};
	wire [SD_AW - 1:0] a2 = (SCRATCH_WBASE + (2 * pw)) + {{SD_AW - 24 {1'b0}}, w};
	wire [SD_AW - 1:0] wbase = GFXW_BASE + fourw[SD_AW - 1:0];
	always @(*) begin
		if (_sv2v_0)
			;
		unp_rd = 1'b0;
		unp_wr = 1'b0;
		unp_addr = 1'sb0;
		unp_din = 16'h0000;
		case (st)
			4'd1: begin
				unp_rd = 1'b1;
				unp_addr = a0;
			end
			4'd2: begin
				unp_rd = 1'b1;
				unp_addr = a1;
			end
			4'd3: begin
				unp_rd = 1'b1;
				unp_addr = a2;
			end
			4'd4: begin
				unp_wr = 1'b1;
				unp_addr = wbase;
				unp_din = fw0;
			end
			4'd5: begin
				unp_wr = 1'b1;
				unp_addr = wbase + 25'd1;
				unp_din = fw1;
			end
			4'd6: begin
				unp_wr = 1'b1;
				unp_addr = wbase + 25'd2;
				unp_din = fw2;
			end
			4'd7: begin
				unp_wr = 1'b1;
				unp_addr = wbase + 25'd3;
				unp_din = fw3;
			end
			default:
				;
		endcase
	end
	assign busy = (st != 4'd0) && (st != 4'd9);
	assign done = st == 4'd9;
	always @(posedge clk)
		if (rst) begin
			st <= 4'd0;
			w <= 24'd0;
		end
		else
			case (st)
				4'd0:
					if (start) begin
						w <= 24'd0;
						st <= 4'd1;
					end
				4'd1:
					if (unp_ack) begin
						p0 <= unp_dout;
						st <= 4'd2;
					end
				4'd2:
					if (unp_ack) begin
						p1 <= unp_dout;
						if (is4) begin
							fw0 <= {mkpix(p0[7:0], unp_dout[7:0], 8'h00, 2'd1), mkpix(p0[7:0], unp_dout[7:0], 8'h00, 2'd0)};
							fw1 <= {mkpix(p0[7:0], unp_dout[7:0], 8'h00, 2'd3), mkpix(p0[7:0], unp_dout[7:0], 8'h00, 2'd2)};
							fw2 <= {mkpix(p0[15:8], unp_dout[15:8], 8'h00, 2'd1), mkpix(p0[15:8], unp_dout[15:8], 8'h00, 2'd0)};
							fw3 <= {mkpix(p0[15:8], unp_dout[15:8], 8'h00, 2'd3), mkpix(p0[15:8], unp_dout[15:8], 8'h00, 2'd2)};
							st <= 4'd4;
						end
						else
							st <= 4'd3;
					end
				4'd3:
					if (unp_ack) begin
						fw0 <= {mkpix(p0[7:0], p1[7:0], unp_dout[7:0], 2'd1), mkpix(p0[7:0], p1[7:0], unp_dout[7:0], 2'd0)};
						fw1 <= {mkpix(p0[7:0], p1[7:0], unp_dout[7:0], 2'd3), mkpix(p0[7:0], p1[7:0], unp_dout[7:0], 2'd2)};
						fw2 <= {mkpix(p0[15:8], p1[15:8], unp_dout[15:8], 2'd1), mkpix(p0[15:8], p1[15:8], unp_dout[15:8], 2'd0)};
						fw3 <= {mkpix(p0[15:8], p1[15:8], unp_dout[15:8], 2'd3), mkpix(p0[15:8], p1[15:8], unp_dout[15:8], 2'd2)};
						st <= 4'd4;
					end
				4'd4:
					if (unp_ack)
						st <= 4'd5;
				4'd5:
					if (unp_ack)
						st <= 4'd6;
				4'd6:
					if (unp_ack)
						st <= 4'd7;
				4'd7:
					if (unp_ack)
						st <= 4'd8;
				4'd8:
					if (w == (pw - 24'd1))
						st <= 4'd9;
					else begin
						w <= w + 24'd1;
						st <= 4'd1;
					end
				4'd9:
					if (start) begin
						w <= 24'd0;
						st <= 4'd1;
					end
				default: st <= 4'd0;
			endcase
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_download_mapper (
	clk,
	ioctl_download,
	ioctl_wr,
	ioctl_index,
	ioctl_addr,
	ioctl_dout,
	game_id,
	gfx_download,
	rom_download,
	mapped_wr,
	mapped_addr,
	mapped_dout,
	mapped_be,
	snd_wr,
	snd_addr,
	snd_data
);
	parameter [24:0] DL_ROMHI_BASE = 25'h0080000;
	parameter [24:0] SCRATCH_WBASE = 25'h0500000;
	parameter [24:0] ROMW_BASE = 25'h0400000;
	parameter [24:0] SOUNDW_BASE = 25'h0800000;
	input wire clk;
	input wire ioctl_download;
	input wire ioctl_wr;
	input wire [7:0] ioctl_index;
	input wire [24:0] ioctl_addr;
	input wire [7:0] ioctl_dout;
	output reg [3:0] game_id = 4'd0;
	output wire gfx_download;
	output wire rom_download;
	output reg mapped_wr;
	output reg [24:0] mapped_addr;
	output reg [15:0] mapped_dout;
	output reg [1:0] mapped_be;
	output reg snd_wr;
	output reg [17:0] snd_addr;
	output reg [7:0] snd_data;
	wire prog_download = ioctl_download && (ioctl_index == 8'd1);
	wire snd_download = ioctl_download && (ioctl_index == 8'd2);
	wire adpcm_snd_tap_ok = ioctl_addr[24:18] == 7'd0;
	assign gfx_download = ioctl_download && (ioctl_index == 8'd0);
	assign rom_download = (gfx_download || prog_download) || snd_download;
	reg [7:0] pair_lo;
	localparam [1:0] yunit_pkg_YS_ADPCM = 2'd2;
	localparam [3:0] yunit_pkg_YG_HIIMPACT = 4'd2;
	localparam [3:0] yunit_pkg_YG_MK = 4'd5;
	localparam [3:0] yunit_pkg_YG_SHIMPACT = 4'd3;
	localparam [3:0] yunit_pkg_YG_TERM2 = 4'd6;
	localparam [3:0] yunit_pkg_YG_TOTCARN = 4'd7;
	localparam [3:0] yunit_pkg_YG_YUNITTST = 4'd8;
	localparam [1:0] yunit_pkg_YS_CVSD_LARGE = 2'd1;
	localparam [1:0] yunit_pkg_YS_CVSD_SMALL = 2'd0;
	function automatic [1:0] yunit_pkg_yunit_sound_type;
		input reg [3:0] game;
		if (((game == yunit_pkg_YG_MK) || (game == yunit_pkg_YG_TERM2)) || (game == yunit_pkg_YG_TOTCARN))
			yunit_pkg_yunit_sound_type = yunit_pkg_YS_ADPCM;
		else if (((game == yunit_pkg_YG_HIIMPACT) || (game == yunit_pkg_YG_SHIMPACT)) || (game == yunit_pkg_YG_YUNITTST))
			yunit_pkg_yunit_sound_type = yunit_pkg_YS_CVSD_LARGE;
		else
			yunit_pkg_yunit_sound_type = yunit_pkg_YS_CVSD_SMALL;
	endfunction
	always @(posedge clk) begin
		mapped_wr <= 1'b0;
		snd_wr <= 1'b0;
		if (((ioctl_download && ioctl_wr) && (ioctl_index == 8'd3)) && (ioctl_addr == 25'd0))
			game_id <= ioctl_dout[3:0];
		if (ioctl_wr) begin
			if (gfx_download) begin
				if (!ioctl_addr[0])
					pair_lo <= ioctl_dout;
				else begin
					mapped_addr <= SCRATCH_WBASE + {1'b0, ioctl_addr[24:1]};
					mapped_dout <= {ioctl_dout, pair_lo};
					mapped_be <= 2'b11;
					mapped_wr <= 1'b1;
				end
			end
			else if (prog_download && (ioctl_addr < DL_ROMHI_BASE)) begin
				mapped_addr <= ROMW_BASE + ioctl_addr;
				mapped_dout <= {8'h00, ioctl_dout};
				mapped_be <= 2'b01;
				mapped_wr <= 1'b1;
			end
			else if (prog_download) begin
				mapped_addr <= ROMW_BASE + (ioctl_addr - DL_ROMHI_BASE);
				mapped_dout <= {ioctl_dout, 8'h00};
				mapped_be <= 2'b10;
				mapped_wr <= 1'b1;
			end
			else if (snd_download) begin
				if (!ioctl_addr[0])
					pair_lo <= ioctl_dout;
				else begin
					mapped_addr <= SOUNDW_BASE + {1'b0, ioctl_addr[24:1]};
					mapped_dout <= {ioctl_dout, pair_lo};
					mapped_be <= 2'b11;
					mapped_wr <= 1'b1;
				end
			end
		end
		if (snd_download && ioctl_wr) begin
			if (yunit_pkg_yunit_sound_type(game_id) == yunit_pkg_YS_ADPCM) begin
				snd_addr <= ioctl_addr[17:0];
				snd_data <= ioctl_dout;
				snd_wr <= adpcm_snd_tap_ok;
			end
			else begin
				snd_addr <= {ioctl_addr[18:17], ioctl_addr[15:0]};
				snd_data <= ioctl_dout;
				snd_wr <= 1'b1;
			end
		end
	end
endmodule
`default_nettype wire
module crt_adjust (
	clk,
	pxl_cen,
	pxl2_cen,
	active,
	hsize,
	hoffset,
	voffset,
	r_in,
	g_in,
	b_in,
	hs_in,
	vs_in,
	hb_in,
	vb_in,
	r_out,
	g_out,
	b_out,
	hs_out,
	vs_out,
	hb_out,
	vb_out,
	hs_ref_out
);
	parameter VTOTAL = 263;
	parameter HTOTAL = 384;
	parameter HPOS_MODE = 1;
	input clk;
	input pxl_cen;
	input pxl2_cen;
	input active;
	input signed [4:0] hsize;
	input signed [8:0] hoffset;
	input signed [5:0] voffset;
	input [7:0] r_in;
	input [7:0] g_in;
	input [7:0] b_in;
	input hs_in;
	input vs_in;
	input hb_in;
	input vb_in;
	output reg [7:0] r_out;
	output reg [7:0] g_out;
	output reg [7:0] b_out;
	output reg hs_out;
	output reg vs_out;
	output reg hb_out;
	output reg vb_out;
	output wire hs_ref_out;
	localparam integer AW = 10;
	reg [7:0] r_in_q;
	reg [7:0] g_in_q;
	reg [7:0] b_in_q;
	reg hs_in_q;
	reg hb_in_q;
	reg vs_in_q;
	reg vb_in_q;
	reg hs_in_d;
	initial begin
		r_in_q = 0;
		g_in_q = 0;
		b_in_q = 0;
		hs_in_q = 0;
		hb_in_q = 1;
		vs_in_q = 0;
		vb_in_q = 0;
		hs_in_d = 0;
	end
	always @(posedge clk)
		if (pxl_cen) begin
			r_in_q <= r_in;
			g_in_q <= g_in;
			b_in_q <= b_in;
			hs_in_q <= hs_in;
			hb_in_q <= hb_in;
			vs_in_q <= vs_in;
			vb_in_q <= vb_in;
			hs_in_d <= hs_in;
		end
	wire hs_rise_native = pxl_cen && (hs_in & ~hs_in_d);
	function automatic signed [9:0] sv2v_cast_10_signed;
		input reg signed [9:0] inp;
		sv2v_cast_10_signed = inp;
	endfunction
	wire signed [9:0] hshift_tap = (hoffset[8] ? sv2v_cast_10_signed(HTOTAL) + {hoffset[8], hoffset} : {1'd0, hoffset});
	reg [HTOTAL - 1:0] hsync_pix_shreg;
	initial hsync_pix_shreg = 0;
	always @(posedge clk)
		if (pxl_cen)
			hsync_pix_shreg <= {hsync_pix_shreg[HTOTAL - 2:0], hs_in};
	reg hs_shifted;
	initial hs_shifted = 0;
	always @(posedge clk)
		if (pxl_cen)
			hs_shifted <= (hshift_tap == 10'd0 ? hs_in : hsync_pix_shreg[hshift_tap - 10'd1]);
	wire hs_read_ref = (HPOS_MODE == 0 ? hs_shifted : hs_in);
	assign hs_ref_out = hs_read_ref;
	reg hs_ref_d1;
	initial hs_ref_d1 = 0;
	always @(posedge clk)
		if (pxl_cen)
			hs_ref_d1 <= hs_read_ref;
	wire hs_rise_in = pxl_cen && (hs_read_ref & ~hs_ref_d1);
	(* ramstyle = "no_rw_check, M10K" *) reg [23:0] mem [0:(1 << AW) - 1];
	integer ii;
	initial for (ii = 0; ii < (1 << AW); ii = ii + 1)
		mem[ii] = 24'd0;
	reg [AW - 1:0] wrp;
	reg [AW - 1:0] hmax;
	reg [AW - 1:0] hb0;
	reg [AW - 1:0] hb1;
	reg lhb_l;
	reg bank;
	initial begin
		wrp = 0;
		hmax = 0;
		hb0 = 0;
		hb1 = 0;
		lhb_l = 0;
		bank = 0;
	end
	wire lhb = ~hb_in;
	always @(posedge clk)
		if (pxl_cen) begin
			lhb_l <= lhb;
			mem[{bank, wrp[AW - 2:0]}] <= {r_in, g_in, b_in};
			if (hs_rise_in) begin
				wrp <= {AW {1'b0}};
				hmax <= wrp;
				bank <= ~bank;
			end
			else
				wrp <= wrp + 1'b1;
			if (lhb & ~lhb_l)
				hb1 <= wrp;
			if (~lhb & lhb_l)
				hb0 <= wrp;
		end
	reg [AW - 1:0] rdcnt;
	reg hs_in_d2;
	reg hs_rise_pending;
	initial begin
		rdcnt = 0;
		hs_in_d2 = 0;
		hs_rise_pending = 0;
	end
	always @(posedge clk) begin
		hs_in_d2 <= hs_read_ref;
		if (hs_read_ref & ~hs_in_d2)
			hs_rise_pending <= 1'b1;
		else if (pxl2_cen)
			hs_rise_pending <= 1'b0;
	end
	always @(posedge clk)
		if (pxl2_cen) begin
			if (hs_rise_pending)
				rdcnt <= {AW {1'b0}};
			else
				rdcnt <= rdcnt + 1'b1;
		end
	reg [23:0] rd_data;
	reg pass_q;
	initial begin
		rd_data = 0;
		pass_q = 0;
	end
	reg vb_line;
	reg vb_active;
	initial begin
		vb_line = 0;
		vb_active = 0;
	end
	always @(posedge clk)
		if (hs_rise_in) begin
			vb_line <= vb_in;
			vb_active <= vb_line;
		end
	wire signed [AW + 1:0] hoff_s = (HPOS_MODE == 1 ? $signed(hoffset) : {AW + 2 {1'b0}});
	wire signed [AW + 1:0] rdcnt_s = $signed({2'b00, rdcnt});
	wire signed [AW + 1:0] hb1_s = $signed({2'b00, hb1});
	wire signed [AW + 1:0] hb0_s = $signed({2'b00, hb0});
	wire [AW - 1:0] rd_addr = rdcnt_s - hoff_s;
	always @(posedge clk)
		if (pxl2_cen) begin
			rd_data <= mem[{~bank, rd_addr[AW - 2:0]}];
			pass_q <= ((rdcnt_s >= (hb1_s + hoff_s)) && (rdcnt_s < (hb0_s + hoff_s))) && ~vb_active;
		end
	function automatic signed [8:0] sv2v_cast_9_signed;
		input reg signed [8:0] inp;
		sv2v_cast_9_signed = inp;
	endfunction
	wire signed [8:0] vshift_tap = (voffset[5] ? sv2v_cast_9_signed(VTOTAL) + {{3 {voffset[5]}}, voffset} : {3'd0, voffset});
	reg [VTOTAL - 1:0] vsync_line_shreg;
	initial vsync_line_shreg = 0;
	always @(posedge clk)
		if (hs_rise_in)
			vsync_line_shreg <= {vsync_line_shreg[VTOTAL - 2:0], vs_in};
	reg vs_shifted;
	initial vs_shifted = 0;
	always @(posedge clk)
		if (hs_rise_in)
			vs_shifted <= (vshift_tap == 9'd0 ? vs_in : vsync_line_shreg[vshift_tap - 9'd1]);
	wire hs_pos_out = (HPOS_MODE == 0 ? hs_shifted : hs_in_q);
	wire bypass = ~active;
	initial begin
		r_out = 0;
		g_out = 0;
		b_out = 0;
		hs_out = 0;
		vs_out = 0;
		hb_out = 1;
		vb_out = 0;
	end
	always @(posedge clk)
		if (bypass) begin
			if (pxl_cen) begin
				r_out <= r_in_q;
				g_out <= g_in_q;
				b_out <= b_in_q;
				hb_out <= hb_in_q;
				hs_out <= hs_in_q;
				vs_out <= vs_in_q;
				vb_out <= vb_in_q;
			end
		end
		else if (pxl2_cen) begin
			if (pass_q) begin
				r_out <= rd_data[23:16];
				g_out <= rd_data[15:8];
				b_out <= rd_data[7:0];
			end
			else begin
				r_out <= 8'd0;
				g_out <= 8'd0;
				b_out <= 8'd0;
			end
			hb_out <= ~pass_q;
			hs_out <= hs_pos_out;
			vs_out <= vs_shifted;
			vb_out <= vb_in_q;
		end
endmodule
`default_nettype none
module yunit_crt_adjust (
	clk,
	ce_pix,
	active_in,
	hsize_code,
	hpos_code,
	vshift_code,
	r_in,
	g_in,
	b_in,
	hs_in,
	vs_in,
	hb_in,
	vb_in,
	ce_pix_out,
	r_out,
	g_out,
	b_out,
	hs_out,
	vs_out,
	hb_out,
	vb_out
);
	input wire clk;
	input wire ce_pix;
	input wire active_in;
	input wire [4:0] hsize_code;
	input wire [6:0] hpos_code;
	input wire [4:0] vshift_code;
	input wire [7:0] r_in;
	input wire [7:0] g_in;
	input wire [7:0] b_in;
	input wire hs_in;
	input wire vs_in;
	input wire hb_in;
	input wire vb_in;
	output wire ce_pix_out;
	output wire [7:0] r_out;
	output wire [7:0] g_out;
	output wire [7:0] b_out;
	output wire hs_out;
	output wire vs_out;
	output wire hb_out;
	output wire vb_out;
	localparam integer H_TOTAL = 506;
	localparam integer V_TOTAL = 289;
	localparam [7:0] READ_PERIOD_BASE = 8'd48;
	localparam integer CRT_HPOS_SYNCSHIFT = 0;
	wire signed [5:0] hsize_request_wide = -$signed({1'b0, hsize_code});
	wire signed [4:0] hsize_request = (hsize_code <= 5'd4 ? hsize_request_wide[4:0] : 5'sd0);
	wire signed [8:0] hpos_request = (hpos_code <= 7'd44 ? $signed({2'b00, hpos_code}) : (hpos_code <= 7'd48 ? $signed({2'b00, hpos_code}) - 9'sd49 : 9'sd0));
	wire [8:0] hpos_phase_request = (hpos_code == 7'd0 ? 9'd505 : (hpos_code <= 7'd44 ? {2'b00, hpos_code} - 9'd1 : (hpos_code <= 7'd48 ? 9'd456 + {2'b00, hpos_code} : 9'd505)));
	wire signed [5:0] vshift_request = (vshift_code <= 5'd13 ? $signed({1'b0, vshift_code}) : (vshift_code <= 5'd25 ? $signed({1'b0, vshift_code}) - 6'sd26 : 6'sd0));
	wire [8:0] vshift_phase_request = (vshift_code <= 5'd13 ? {4'd0, vshift_code} : (vshift_code <= 5'd25 ? 9'd263 + {4'd0, vshift_code} : 9'd0));
	reg active_pending = 1'b0;
	reg sync_active_q = 1'b0;
	reg signed [4:0] hsize_pending = 5'sd0;
	reg active_q = 1'b0;
	reg signed [4:0] hsize_q = 5'sd0;
	reg signed [8:0] hpos_q = 9'sd0;
	reg [8:0] hpos_phase_q = 9'd0;
	reg signed [5:0] vshift_q = 6'sd0;
	reg [8:0] vshift_phase_q = 9'd0;
	reg native_hs_d = 1'b0;
	reg native_vs_d = 1'b0;
	reg native_hb_d = 1'b1;
	reg native_vb_d = 1'b0;
	reg [1:0] mode_switch_delay = 2'd0;
	reg [8:0] hphase_q = 9'd0;
	wire native_hs_rise = (ce_pix && hs_in) && !native_hs_d;
	wire native_vs_rise = (ce_pix && vs_in) && !native_vs_d;
	wire native_active_start = (ce_pix && !hb_in) && native_hb_d;
	wire native_vblank_end = (ce_pix && !vb_in) && native_vb_d;
	wire [8:0] hphase_now = (native_hs_rise ? 9'd0 : (hphase_q == 9'd505 ? 9'd0 : hphase_q + 9'd1));
	wire [9:0] hsync_end = {1'b0, hpos_phase_q} + 10'd44;
	wire hs_pre = (hsync_end <= 10'd506 ? (hphase_now >= hpos_phase_q) && ({1'b0, hphase_now} < hsync_end) : (hphase_now >= hpos_phase_q) || ({1'b0, hphase_now} < (hsync_end - 10'd506)));
	reg hs_pre_d = 1'b0;
	wire hs_pre_rise = (ce_pix && hs_pre) && !hs_pre_d;
	always @(posedge clk)
		if (ce_pix) begin
			native_hs_d <= hs_in;
			native_vs_d <= vs_in;
			native_hb_d <= hb_in;
			native_vb_d <= vb_in;
			hs_pre_d <= hs_pre;
			hphase_q <= hphase_now;
			if (native_active_start) begin
				hpos_q <= hpos_request;
				hpos_phase_q <= hpos_phase_request;
				hsize_pending <= hsize_request;
				if (mode_switch_delay != 2'd0) begin
					if (mode_switch_delay == 2'd1) begin
						sync_active_q <= active_in;
						active_pending <= active_in;
					end
					mode_switch_delay <= mode_switch_delay - 2'd1;
				end
			end
			if (native_vblank_end)
				mode_switch_delay <= 2'd2;
			if (hs_pre_rise && active_pending) begin
				hsize_q <= hsize_pending;
				active_q <= 1'b1;
			end
			if ((ce_pix && (hphase_now == 9'd505)) && !active_pending) begin
				hsize_q <= hsize_pending;
				active_q <= 1'b0;
			end
			if (native_vs_rise) begin
				vshift_q <= vshift_request;
				vshift_phase_q <= vshift_phase_request;
			end
		end
	reg native_vs_line_d = 1'b0;
	reg [8:0] vphase_q = 9'd0;
	reg vs_pre_q = 1'b0;
	wire native_vs_line_rise = vs_in && !native_vs_line_d;
	wire [8:0] vphase_now = (native_vs_line_rise ? 9'd0 : (vphase_q == 9'd288 ? 9'd0 : vphase_q + 9'd1));
	wire [9:0] vsync_end = {1'b0, vshift_phase_q} + 10'd4;
	wire vs_pre_now = (vsync_end <= 10'd289 ? (vphase_now >= vshift_phase_q) && ({1'b0, vphase_now} < vsync_end) : (vphase_now >= vshift_phase_q) || ({1'b0, vphase_now} < (vsync_end - 10'd289)));
	always @(posedge clk)
		if (hs_pre_rise) begin
			native_vs_line_d <= vs_in;
			vphase_q <= vphase_now;
			vs_pre_q <= vs_pre_now;
		end
	wire [7:0] stretch_r;
	wire [7:0] stretch_g;
	wire [7:0] stretch_b;
	wire stretch_hs_unused;
	wire stretch_vs_unused;
	wire stretch_hb;
	wire stretch_vb_unused;
	wire hs_ref;
	reg hs_ref_d = 1'b0;
	wire rate_hs_ref = hs_ref;
	always @(posedge clk) hs_ref_d <= rate_hs_ref;
	wire hs_ref_rise = rate_hs_ref & ~hs_ref_d;
	wire [7:0] read_period = READ_PERIOD_BASE + {{3 {hsize_q[4]}}, hsize_q};
	reg [7:0] read_acc = 8'd0;
	wire read_tick = ({1'b0, read_acc} + 9'd4) >= {1'b0, read_period};
	always @(posedge clk)
		if (hs_ref_rise)
			read_acc <= 8'd0;
		else if (read_tick)
			read_acc <= (read_acc + 8'd4) - read_period;
		else
			read_acc <= read_acc + 8'd4;
	assign ce_pix_out = (active_q ? read_tick : ce_pix);
	crt_adjust #(
		.VTOTAL(V_TOTAL),
		.HTOTAL(H_TOTAL),
		.HPOS_MODE(CRT_HPOS_SYNCSHIFT)
	) u_crt_adjust(
		.clk(clk),
		.pxl_cen(ce_pix),
		.pxl2_cen(ce_pix_out),
		.active(active_q),
		.hsize(hsize_q),
		.hoffset(9'sd0),
		.voffset(6'sd0),
		.r_in(r_in),
		.g_in(g_in),
		.b_in(b_in),
		.hs_in(hs_pre),
		.vs_in(vs_pre_q),
		.hb_in(hb_in | vb_in),
		.vb_in(vb_in),
		.r_out(stretch_r),
		.g_out(stretch_g),
		.b_out(stretch_b),
		.hs_out(stretch_hs_unused),
		.vs_out(stretch_vs_unused),
		.hb_out(stretch_hb),
		.vb_out(stretch_vb_unused),
		.hs_ref_out(hs_ref)
	);
	reg hs_ref_full_d = 1'b0;
	reg vb_line_q = 1'b0;
	reg vb_active_q = 1'b0;
	reg vs_sync_q = 1'b0;
	always @(posedge clk) begin
		hs_ref_full_d <= hs_ref;
		if (hs_ref && !hs_ref_full_d) begin
			vb_line_q <= vb_in;
			vb_active_q <= vb_line_q;
			vs_sync_q <= vs_pre_q;
		end
	end
	wire adjusted_retrace = vb_active_q | hs_ref;
	assign r_out = (active_q ? (adjusted_retrace ? 8'd0 : stretch_r) : r_in);
	assign g_out = (active_q ? (adjusted_retrace ? 8'd0 : stretch_g) : g_in);
	assign b_out = (active_q ? (adjusted_retrace ? 8'd0 : stretch_b) : b_in);
	assign hs_out = (sync_active_q ? hs_ref : hs_in);
	assign vs_out = (sync_active_q ? vs_sync_q : vs_in);
	assign hb_out = (active_q ? (vb_active_q ? hb_in | hs_ref : stretch_hb | hs_ref) : hb_in);
	assign vb_out = (active_q ? vb_active_q : vb_in);
endmodule
`default_nettype wire
`default_nettype none
module yunit_mem_cdc (
	clk_cpu,
	ce_cpu,
	rst_cpu,
	c_req,
	c_we,
	c_addr,
	c_size,
	c_wdata,
	c_ack,
	c_rdata,
	clk_sys,
	rst_sys,
	m_req,
	m_we,
	m_addr,
	m_size,
	m_wdata,
	m_rdata,
	m_ack
);
	parameter AW = 32;
	parameter DW = 32;
	parameter SW = 6;
	input wire clk_cpu;
	input wire ce_cpu;
	input wire rst_cpu;
	input wire c_req;
	input wire c_we;
	input wire [AW - 1:0] c_addr;
	input wire [SW - 1:0] c_size;
	input wire [DW - 1:0] c_wdata;
	output reg c_ack;
	output reg [DW - 1:0] c_rdata;
	input wire clk_sys;
	input wire rst_sys;
	output reg m_req;
	output reg m_we;
	output reg [AW - 1:0] m_addr;
	output reg [SW - 1:0] m_size;
	output reg [DW - 1:0] m_wdata;
	input wire [DW - 1:0] m_rdata;
	input wire m_ack;
	reg req_tgl;
	reg ack_tgl;
	reg p_we;
	reg [AW - 1:0] p_addr;
	reg [SW - 1:0] p_size;
	reg [DW - 1:0] p_wdata;
	reg [DW - 1:0] resp;
	reg [1:0] cst;
	reg [2:0] ackt_sync;
	always @(posedge clk_cpu)
		if ((ce_cpu !== 1'b0) || rst_cpu) begin
			if (rst_cpu) begin
				cst <= 2'd0;
				req_tgl <= 1'b0;
				c_ack <= 1'b0;
				ackt_sync <= 3'b000;
			end
			else begin
				ackt_sync <= {ackt_sync[1:0], ack_tgl};
				c_ack <= 1'b0;
				case (cst)
					2'd0:
						if (c_req) begin
							p_we <= c_we;
							p_addr <= c_addr;
							p_size <= c_size;
							p_wdata <= c_wdata;
							req_tgl <= ~req_tgl;
							cst <= 2'd1;
						end
					2'd1:
						if (ackt_sync[2] ^ ackt_sync[1]) begin
							c_rdata <= resp;
							c_ack <= 1'b1;
							cst <= 2'd2;
						end
					2'd2: cst <= 2'd0;
					default: cst <= 2'd0;
				endcase
			end
		end
	reg [1:0] sst;
	reg [2:0] reqt_sync;
	always @(posedge clk_sys)
		if (rst_sys) begin
			sst <= 2'd0;
			m_req <= 1'b0;
			ack_tgl <= 1'b0;
			reqt_sync <= 3'b000;
		end
		else begin
			reqt_sync <= {reqt_sync[1:0], req_tgl};
			case (sst)
				2'd0:
					if (reqt_sync[2] ^ reqt_sync[1]) begin
						m_we <= p_we;
						m_addr <= p_addr;
						m_size <= p_size;
						m_wdata <= p_wdata;
						m_req <= 1'b1;
						sst <= 2'd1;
					end
				2'd1:
					if (m_ack) begin
						resp <= m_rdata;
						m_req <= 1'b0;
						ack_tgl <= ~ack_tgl;
						sst <= 2'd0;
					end
				default: sst <= 2'd0;
			endcase
		end
endmodule
`default_nettype wire
`default_nettype none
module yunit_sound_cdc (
	clk_sys,
	clk_snd,
	rst_pon,
	snd_select,
	snd_trig,
	snd_reset,
	sel_snd,
	trig_snd,
	reset_snd
);
	parameter integer SYS_HOLD_CYCLES = 128;
	input wire clk_sys;
	input wire clk_snd;
	input wire rst_pon;
	input wire [7:0] snd_select;
	input wire snd_trig;
	input wire snd_reset;
	output reg [7:0] sel_snd;
	output wire trig_snd;
	output wire reset_snd;
	localparam integer HOLD_W = (SYS_HOLD_CYCLES < 2 ? 1 : $clog2(SYS_HOLD_CYCLES + 1));
	reg [HOLD_W - 1:0] trig_hold;
	reg [HOLD_W - 1:0] reset_hold;
	reg [7:0] select_hold;
	function automatic signed [HOLD_W - 1:0] sv2v_cast_CFAF4_signed;
		input reg signed [HOLD_W - 1:0] inp;
		sv2v_cast_CFAF4_signed = inp;
	endfunction
	always @(posedge clk_sys)
		if (rst_pon) begin
			trig_hold <= sv2v_cast_CFAF4_signed(SYS_HOLD_CYCLES);
			reset_hold <= sv2v_cast_CFAF4_signed(SYS_HOLD_CYCLES);
			select_hold <= 8'h00;
		end
		else begin
			if (!snd_trig) begin
				trig_hold <= sv2v_cast_CFAF4_signed(SYS_HOLD_CYCLES);
				select_hold <= snd_select;
			end
			else if (trig_hold != 0)
				trig_hold <= trig_hold - 1'b1;
			if (snd_reset)
				reset_hold <= sv2v_cast_CFAF4_signed(SYS_HOLD_CYCLES);
			else if (reset_hold != 0)
				reset_hold <= reset_hold - 1'b1;
		end
	wire trig_sys = snd_trig && (trig_hold == 0);
	wire reset_sys = snd_reset || (reset_hold != 0);
	wire [7:0] select_sys = select_hold;
	(* preserve *) reg [1:0] trig_sync = 2'b00;
	(* preserve *) reg [1:0] reset_sync = 2'b11;
	reg [7:0] sel_meta = 8'h00;
	always @(posedge clk_snd)
		if (rst_pon) begin
			trig_sync <= 2'b00;
			reset_sync <= 2'b11;
			sel_meta <= 8'h00;
			sel_snd <= 8'h00;
		end
		else begin
			trig_sync <= {trig_sync[0], trig_sys};
			reset_sync <= {reset_sync[0], reset_sys};
			sel_meta <= select_sys;
			sel_snd <= sel_meta;
		end
	assign trig_snd = trig_sync[1];
	assign reset_snd = reset_sync[1];
endmodule
`default_nettype wire
`default_nettype none
module yunit_sound_rom_cache (
	clk,
	rst,
	active,
	client_addr,
	client_data,
	client_ok,
	mem_rd,
	mem_addr,
	mem_rdata,
	mem_ack
);
	reg _sv2v_0;
	input wire clk;
	input wire rst;
	input wire active;
	input wire [20:0] client_addr;
	output reg [7:0] client_data;
	output reg client_ok;
	output reg mem_rd;
	output reg [20:0] mem_addr;
	input wire [15:0] mem_rdata;
	input wire mem_ack;
	reg [19:0] current_addr;
	reg [19:0] prefetch_addr;
	reg [15:0] current_word;
	reg [15:0] prefetch_word;
	reg current_valid;
	reg prefetch_valid;
	reg fetch_is_prefetch;
	wire [19:0] wanted_word = client_addr[20:1];
	wire current_hit = current_valid && (current_addr == wanted_word);
	wire prefetch_hit = prefetch_valid && (prefetch_addr == wanted_word);
	wire [15:0] hit_word = (current_hit ? current_word : prefetch_word);
	always @(*) begin
		if (_sv2v_0)
			;
		client_ok = active && (current_hit || prefetch_hit);
		client_data = (client_addr[0] ? hit_word[15:8] : hit_word[7:0]);
	end
	always @(posedge clk)
		if (rst || !active) begin
			mem_rd <= 1'b0;
			mem_addr <= 21'd0;
			current_valid <= 1'b0;
			prefetch_valid <= 1'b0;
			fetch_is_prefetch <= 1'b0;
			current_addr <= 20'd0;
			prefetch_addr <= 20'd0;
			current_word <= 16'd0;
			prefetch_word <= 16'd0;
		end
		else if (mem_rd) begin
			if (mem_ack) begin
				mem_rd <= 1'b0;
				if (fetch_is_prefetch) begin
					prefetch_addr <= mem_addr[20:1];
					prefetch_word <= mem_rdata;
					prefetch_valid <= 1'b1;
				end
				else begin
					current_addr <= mem_addr[20:1];
					current_word <= mem_rdata;
					current_valid <= 1'b1;
					prefetch_valid <= 1'b0;
				end
			end
		end
		else if (prefetch_hit) begin
			current_addr <= prefetch_addr;
			current_word <= prefetch_word;
			current_valid <= 1'b1;
			prefetch_valid <= 1'b0;
		end
		else if (!current_hit) begin
			mem_addr <= {wanted_word, 1'b0};
			fetch_is_prefetch <= 1'b0;
			mem_rd <= 1'b1;
		end
		else if (!prefetch_valid) begin
			mem_addr <= {current_addr + 20'd1, 1'b0};
			fetch_is_prefetch <= 1'b1;
			mem_rd <= 1'b1;
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_audio_mix (
	clk,
	rst,
	ym_l,
	ym_r,
	speech_u,
	pia_u,
	audio_l,
	audio_r
);
	input wire clk;
	input wire rst;
	input wire signed [15:0] ym_l;
	input wire signed [15:0] ym_r;
	input wire [15:0] speech_u;
	input wire [7:0] pia_u;
	output reg signed [15:0] audio_l;
	output reg signed [15:0] audio_r;
	reg signed [24:0] cvsd_dc;
	wire signed [16:0] cvsd_x = $signed({1'b0, speech_u});
	always @(posedge clk)
		if (rst)
			cvsd_dc <= 25'sd0;
		else
			cvsd_dc <= cvsd_dc + (($signed({cvsd_x, 8'd0}) - cvsd_dc) >>> 18);
	wire signed [17:0] speech_ac = $signed({cvsd_x[16], cvsd_x}) - $signed(cvsd_dc[24:8]);
	wire signed [15:0] speech_s = (speech_ac > 18'sd32767 ? 16'sd32767 : (speech_ac < -18'sd32768 ? -16'sd32768 : speech_ac[15:0]));
	wire signed [16:0] ym_mono = $signed({ym_l[15], ym_l}) + $signed({ym_r[15], ym_r});
	wire signed [16:0] ym_mix_l = ym_mono;
	wire signed [16:0] ym_mix_r = ym_mono;
	wire signed [16:0] pia_s = ($signed({1'b0, pia_u}) - 17'sd128) <<< 8;
	localparam signed [31:0] YM_COEFF = 32'sd26;
	localparam signed [31:0] CVSD_COEFF = 32'sd47;
	wire signed [31:0] ym_term_l = ($signed(ym_mix_l) * YM_COEFF) >>> 8;
	wire signed [31:0] ym_term_r = ($signed(ym_mix_r) * YM_COEFF) >>> 8;
	wire signed [31:0] cvsd_term = ($signed(speech_s) * CVSD_COEFF) >>> 8;
	wire signed [31:0] pia_term = ($signed(pia_s) * 32'sd64) >>> 8;
	wire signed [31:0] mix_l = (ym_term_l + cvsd_term) + pia_term;
	wire signed [31:0] mix_r = (ym_term_r + cvsd_term) + pia_term;
	always @(posedge clk)
		if (rst) begin
			audio_l <= 16'sd0;
			audio_r <= 16'sd0;
		end
		else begin
			audio_l <= (mix_l > 32'sd32767 ? 16'sd32767 : (mix_l < -32'sd32768 ? -16'sd32768 : mix_l[15:0]));
			audio_r <= (mix_r > 32'sd32767 ? 16'sd32767 : (mix_r < -32'sd32768 ? -16'sd32768 : mix_r[15:0]));
		end
endmodule
`default_nettype wire
`default_nettype none
module yunit_adpcm_board (
	clk,
	reset_pon,
	reset,
	sound_select,
	sound_trig,
	game,
	ext_rom_addr,
	ext_rom_data,
	ext_rom_ok,
	snd_dl_clk,
	snd_dl_addr,
	snd_dl_data,
	snd_dl_we,
	audio_l,
	audio_r,
	irq_state
);
	reg _sv2v_0;
	input wire clk;
	input wire reset_pon;
	input wire reset;
	input wire [7:0] sound_select;
	input wire sound_trig;
	input wire [3:0] game;
	output wire [20:0] ext_rom_addr;
	input wire [7:0] ext_rom_data;
	input wire ext_rom_ok;
	input wire snd_dl_clk;
	input wire [17:0] snd_dl_addr;
	input wire [7:0] snd_dl_data;
	input wire snd_dl_we;
	output reg signed [15:0] audio_l;
	output reg signed [15:0] audio_r;
	output reg irq_state;
	reg [8:0] por_count = 9'h1ff;
	wire [15:0] cpu_addr;
	reg [7:0] cpu_din;
	wire [7:0] cpu_dout;
	wire cpu_rnw;
	reg cpu_irq;
	always @(posedge clk)
		if (reset_pon)
			por_count <= 9'h1ff;
		else if (por_count != 0)
			por_count <= por_count - 1'b1;
	wire board_reset = (reset | reset_pon) | (por_count != 0);
	wire child_reset = reset_pon | (por_count != 0);
	reg en_half;
	reg [1:0] div_count;
	reg cpu_e_en;
	reg cpu_q_en;
	reg cpu_write;
	wire cpu_rom_ready;
	wire cpu_rom_wait;
	wire e_hold = (en_half && (div_count == 2'd0)) && cpu_rom_wait;
	always @(posedge clk) begin
		cpu_e_en <= 1'b0;
		cpu_q_en <= 1'b0;
		cpu_write <= 1'b0;
		if (board_reset) begin
			en_half <= 1'b0;
			div_count <= 2'd0;
		end
		else if (!e_hold) begin
			en_half <= ~en_half;
			if (en_half) begin
				div_count <= (div_count == 2'd2 ? 2'd0 : div_count + 1'b1);
				if (div_count == 2'd0)
					cpu_e_en <= 1'b1;
				if (div_count == 2'd2) begin
					cpu_q_en <= 1'b1;
					cpu_write <= ~cpu_rnw;
				end
			end
		end
	end
	wire ym_irq_n;
	mc6809is u_cpu(
		.CLK(clk),
		.fallE_en(cpu_e_en),
		.fallQ_en(cpu_q_en),
		.OP(cpu_din),
		.D(cpu_din),
		.DOut(cpu_dout),
		.ADDR(cpu_addr),
		.RnW(cpu_rnw),
		.BS(),
		.BA(),
		.nIRQ(~cpu_irq),
		.nFIRQ(ym_irq_n),
		.nNMI(1'b1),
		.AVMA(),
		.BUSY(),
		.LIC(),
		.nHALT(1'b1),
		.nRESET(~board_reset),
		.nDMABREQ(1'b1),
		.RegData()
	);
	reg [7:0] ram [0:8191];
	reg [7:0] ram_q;
	always @(posedge clk) begin
		ram_q <= ram[cpu_addr[12:0]];
		if (cpu_write && (cpu_addr < 16'h2000))
			ram[cpu_addr[12:0]] <= cpu_dout;
	end
	wire io_bank = cpu_addr[15:10] == 6'b001000;
	wire io_ym = cpu_addr[15:10] == 6'b001001;
	wire io_dac = cpu_addr[15:10] == 6'b001010;
	wire io_oki = cpu_addr[15:10] == 6'b001011;
	wire io_cmd = cpu_addr[15:10] == 6'b001100;
	wire io_okibnk = cpu_addr[15:10] == 6'b001101;
	wire io_talk = cpu_addr[15:10] == 6'b001111;
	wire cpu_rom = cpu_addr >= 16'h4000;
	localparam signed [31:0] PROT_N = 64;
	localparam [3:0] yunit_pkg_YG_MK = 4'd5;
	localparam [3:0] yunit_pkg_YG_TERM2 = 4'd6;
	localparam [3:0] yunit_pkg_YG_TOTCARN = 4'd7;
	function automatic [15:0] yunit_pkg_yunit_adpcm_prot_start;
		input reg [3:0] game;
		case (game)
			yunit_pkg_YG_MK: yunit_pkg_yunit_adpcm_prot_start = 16'hfb9c;
			yunit_pkg_YG_TERM2: yunit_pkg_yunit_adpcm_prot_start = 16'hfa8d;
			yunit_pkg_YG_TOTCARN: yunit_pkg_yunit_adpcm_prot_start = 16'hfc04;
			default: yunit_pkg_yunit_adpcm_prot_start = 16'h0000;
		endcase
	endfunction
	wire [15:0] prot_start = yunit_pkg_yunit_adpcm_prot_start(game);
	function automatic [15:0] yunit_pkg_yunit_adpcm_prot_end;
		input reg [3:0] game;
		case (game)
			yunit_pkg_YG_MK: yunit_pkg_yunit_adpcm_prot_end = 16'hfbc6;
			yunit_pkg_YG_TERM2: yunit_pkg_yunit_adpcm_prot_end = 16'hfa9c;
			yunit_pkg_YG_TOTCARN: yunit_pkg_yunit_adpcm_prot_end = 16'hfc2e;
			default: yunit_pkg_yunit_adpcm_prot_end = 16'h0000;
		endcase
	endfunction
	wire [15:0] prot_end = yunit_pkg_yunit_adpcm_prot_end(game);
	function automatic yunit_pkg_yunit_has_adpcm_prot;
		input reg [3:0] game;
		yunit_pkg_yunit_has_adpcm_prot = ((game == yunit_pkg_YG_MK) || (game == yunit_pkg_YG_TERM2)) || (game == yunit_pkg_YG_TOTCARN);
	endfunction
	wire prot_en = yunit_pkg_yunit_has_adpcm_prot(game);
	wire [15:0] prot_off = cpu_addr - prot_start;
	wire prot_hit = (prot_en && (cpu_addr >= prot_start)) && (cpu_addr <= prot_end);
	reg [7:0] prot_ram [0:63];
	reg [7:0] prot_q;
	initial begin : sv2v_autoblock_1
		reg signed [31:0] i;
		for (i = 0; i < PROT_N; i = i + 1)
			prot_ram[i] = 8'h00;
	end
	always @(posedge clk) begin
		prot_q <= prot_ram[prot_off[5:0]];
		if (cpu_write && prot_hit)
			prot_ram[prot_off[5:0]] <= cpu_dout;
	end
	reg [2:0] cpu_bank;
	reg [2:0] oki_bank;
	reg [7:0] dac_data;
	reg [7:0] talkback;
	reg [7:0] command_latch;
	reg [7:0] irq_clear_count;
	reg [8:0] command_seen;
	wire [8:0] command_now = {sound_trig, sound_select};
	always @(posedge clk)
		if (board_reset) begin
			cpu_bank <= 3'd0;
			oki_bank <= 3'd0;
			dac_data <= 8'h80;
			talkback <= 8'h00;
			command_latch <= 8'h00;
			command_seen <= command_now;
			cpu_irq <= 1'b0;
			irq_state <= 1'b0;
			irq_clear_count <= 8'd0;
		end
		else begin
			if (command_now != command_seen) begin
				command_seen <= command_now;
				command_latch <= sound_select;
				if (!sound_trig) begin
					cpu_irq <= 1'b1;
					irq_state <= 1'b1;
					irq_clear_count <= 8'd0;
				end
			end
			if (irq_clear_count != 0) begin
				irq_clear_count <= irq_clear_count - 1'b1;
				if (irq_clear_count == 1)
					irq_state <= 1'b0;
			end
			if (cpu_write) begin
				if (io_bank)
					cpu_bank <= cpu_dout[2:0];
				else if (io_dac)
					dac_data <= cpu_dout;
				else if (io_okibnk)
					oki_bank <= cpu_dout[2:0];
				else if (io_talk)
					talkback <= cpu_dout;
			end
			if ((cpu_rnw && cpu_e_en) && io_cmd) begin
				cpu_irq <= 1'b0;
				irq_clear_count <= 8'd120;
			end
		end
	reg [9:0] ym_acc;
	reg ym_cen;
	reg ym_cen_p1;
	reg ym_alt;
	always @(posedge clk) begin
		ym_cen <= 1'b0;
		ym_cen_p1 <= 1'b0;
		if (child_reset) begin
			ym_acc <= 10'd0;
			ym_alt <= 1'b0;
		end
		else if ((ym_acc + 10'd105) >= 10'd352) begin
			ym_acc <= ym_acc + (10'd105 - 10'd352);
			ym_cen <= 1'b1;
			ym_alt <= ~ym_alt;
			ym_cen_p1 <= ym_alt;
		end
		else
			ym_acc <= ym_acc + 10'd105;
	end
	wire [7:0] ym_dout;
	wire signed [15:0] ym_left;
	wire signed [15:0] ym_right;
	jt51 u_ym(
		.rst(child_reset),
		.clk(clk),
		.cen(ym_cen),
		.cen_p1(ym_cen_p1),
		.cs_n(~io_ym),
		.wr_n(~(cpu_write && io_ym)),
		.a0(cpu_addr[0]),
		.din(cpu_dout),
		.dout(ym_dout),
		.ct1(),
		.ct2(),
		.irq_n(ym_irq_n),
		.sample(),
		.left(),
		.right(),
		.xleft(ym_left),
		.xright(ym_right)
	);
	reg [3:0] oki_div;
	reg oki_cen;
	always @(posedge clk) begin
		oki_cen <= 1'b0;
		if (child_reset)
			oki_div <= 4'd0;
		else if (oki_div == 4'd11) begin
			oki_div <= 4'd0;
			oki_cen <= 1'b1;
		end
		else
			oki_div <= oki_div + 1'b1;
	end
	wire [7:0] oki_dout;
	wire [17:0] oki_addr;
	wire signed [13:0] oki_sound;
	reg [7:0] oki_rom_data;
	reg oki_rom_ok;
	jt6295 #(.INTERPOL(1)) u_oki(
		.rst(child_reset),
		.clk(clk),
		.cen(oki_cen),
		.ss(1'b1),
		.wrn(~(cpu_write && io_oki)),
		.din(cpu_dout),
		.dout(oki_dout),
		.rom_addr(oki_addr),
		.rom_data(oki_rom_data),
		.rom_ok(oki_rom_ok),
		.sound(oki_sound),
		.sample()
	);
	reg [20:0] cpu_rom_want;
	reg [14:0] cpu_bank_offset;
	always @(*) begin
		if (_sv2v_0)
			;
		cpu_bank_offset = cpu_addr - 16'h4000;
		if (cpu_addr < 16'hc000)
			cpu_rom_want = {3'd0, cpu_bank, cpu_bank_offset};
		else
			cpu_rom_want = 21'h03c000 + {7'd0, cpu_addr[13:0]};
	end
	(* ramstyle = "M10K" *) reg [7:0] fixbank [0:16383];
	reg [7:0] fix_q;
	reg [13:0] fix_aq;
	always @(posedge snd_dl_clk) begin
		if (snd_dl_we && (snd_dl_addr[17:14] == 4'hf))
			fixbank[snd_dl_addr[13:0]] <= snd_dl_data;
		fix_q <= fixbank[cpu_addr[13:0]];
		fix_aq <= cpu_addr[13:0];
	end
	wire cpu_fixed = cpu_addr[15:14] == 2'b11;
	wire fix_ready = cpu_fixed && (fix_aq == cpu_addr[13:0]);
	reg [20:0] oki_logical;
	always @(*) begin
		if (_sv2v_0)
			;
		if (!oki_addr[17])
			case (oki_bank)
				3'd0, 3'd1: oki_logical = 21'h040000 + {4'd0, oki_addr[16:0]};
				3'd2: oki_logical = 21'h020000 + {4'd0, oki_addr[16:0]};
				3'd3: oki_logical = {4'd0, oki_addr[16:0]};
				3'd4: oki_logical = 21'h0e0000 + {4'd0, oki_addr[16:0]};
				3'd5: oki_logical = 21'h0c0000 + {4'd0, oki_addr[16:0]};
				3'd6: oki_logical = 21'h0a0000 + {4'd0, oki_addr[16:0]};
				default: oki_logical = 21'h080000 + {4'd0, oki_addr[16:0]};
			endcase
		else
			oki_logical = 21'h040000 + {3'd0, oki_addr};
	end
	wire [20:0] oki_rom_want = 21'h040000 + oki_logical;
	reg [19:0] cpu_tag [0:1];
	reg [15:0] cpu_dat [0:1];
	reg [1:0] cpu_v [0:1];
	reg cpu_lru;
	reg [19:0] oki_tag [0:1];
	reg [15:0] oki_dat [0:1];
	reg [1:0] oki_v [0:1];
	reg oki_lru;
	wire [19:0] cpu_word = cpu_rom_want[20:1];
	wire cpu_bsel = cpu_rom_want[0];
	wire cpu_hit0 = (cpu_tag[0] == cpu_word) && cpu_v[0][cpu_bsel];
	wire cpu_hit1 = (cpu_tag[1] == cpu_word) && cpu_v[1][cpu_bsel];
	wire [15:0] cpu_hit_word = (cpu_hit0 ? cpu_dat[0] : cpu_dat[1]);
	wire [7:0] cpu_rom_data = (cpu_bsel ? cpu_hit_word[15:8] : cpu_hit_word[7:0]);
	wire [19:0] oki_word = oki_rom_want[20:1];
	wire oki_bsel = oki_rom_want[0];
	wire oki_hit0 = (oki_tag[0] == oki_word) && oki_v[0][oki_bsel];
	wire oki_hit1 = (oki_tag[1] == oki_word) && oki_v[1][oki_bsel];
	wire [15:0] oki_hit_word = (oki_hit0 ? oki_dat[0] : oki_dat[1]);
	assign cpu_rom_ready = (cpu_fixed ? fix_ready : cpu_hit0 || cpu_hit1);
	assign cpu_rom_wait = (cpu_rnw && cpu_rom) && !cpu_rom_ready;
	wire cpu_need = ((cpu_rnw && cpu_rom) && !cpu_fixed) && !cpu_rom_ready;
	wire oki_need = !(oki_hit0 || oki_hit1);
	reg [1:0] fetch_kind;
	reg fetch_on;
	reg [20:0] fetch_addr;
	assign ext_rom_addr = fetch_addr;
	wire [19:0] fill_word = fetch_addr[20:1];
	wire fill_bsel = fetch_addr[0];
	wire fill_cpu = fetch_kind != 2'd1;
	wire cpu_fill_hit0 = (cpu_tag[0] == fill_word) && (cpu_v[0] != 2'b00);
	wire cpu_fill_hit1 = (cpu_tag[1] == fill_word) && (cpu_v[1] != 2'b00);
	wire cpu_fill_e = (cpu_fill_hit0 ? 1'b0 : (cpu_fill_hit1 ? 1'b1 : cpu_lru));
	wire cpu_fill_fresh = !(cpu_fill_hit0 || cpu_fill_hit1);
	wire oki_fill_hit0 = (oki_tag[0] == fill_word) && (oki_v[0] != 2'b00);
	wire oki_fill_hit1 = (oki_tag[1] == fill_word) && (oki_v[1] != 2'b00);
	wire oki_fill_e = (oki_fill_hit0 ? 1'b0 : (oki_fill_hit1 ? 1'b1 : oki_lru));
	wire oki_fill_fresh = !(oki_fill_hit0 || oki_fill_hit1);
	always @(posedge clk)
		if (board_reset) begin
			fetch_on <= 1'b0;
			fetch_kind <= 2'd0;
			fetch_addr <= 21'd0;
			cpu_tag[0] <= 20'd0;
			cpu_tag[1] <= 20'd0;
			cpu_dat[0] <= 16'h0000;
			cpu_dat[1] <= 16'h0000;
			cpu_v[0] <= 2'b00;
			cpu_v[1] <= 2'b00;
			cpu_lru <= 1'b0;
			oki_tag[0] <= 20'd0;
			oki_tag[1] <= 20'd0;
			oki_dat[0] <= 16'h0000;
			oki_dat[1] <= 16'h0000;
			oki_v[0] <= 2'b00;
			oki_v[1] <= 2'b00;
			oki_lru <= 1'b0;
		end
		else begin
			if (cpu_hit0)
				cpu_lru <= 1'b1;
			else if (cpu_hit1)
				cpu_lru <= 1'b0;
			if (oki_hit0)
				oki_lru <= 1'b1;
			else if (oki_hit1)
				oki_lru <= 1'b0;
			if (fetch_on) begin
				if (ext_rom_ok) begin
					fetch_on <= 1'b0;
					if (fill_cpu) begin
						cpu_tag[cpu_fill_e] <= fill_word;
						if (fill_bsel)
							cpu_dat[cpu_fill_e][15:8] <= ext_rom_data;
						else
							cpu_dat[cpu_fill_e][7:0] <= ext_rom_data;
						cpu_v[cpu_fill_e] <= (cpu_fill_fresh ? 2'b00 : cpu_v[cpu_fill_e]) | (fill_bsel ? 2'b10 : 2'b01);
					end
					else begin
						oki_tag[oki_fill_e] <= fill_word;
						if (fill_bsel)
							oki_dat[oki_fill_e][15:8] <= ext_rom_data;
						else
							oki_dat[oki_fill_e][7:0] <= ext_rom_data;
						oki_v[oki_fill_e] <= (oki_fill_fresh ? 2'b00 : oki_v[oki_fill_e]) | (fill_bsel ? 2'b10 : 2'b01);
						if (oki_fill_fresh)
							oki_lru <= ~oki_fill_e;
					end
					if (fill_cpu && cpu_fill_fresh)
						cpu_lru <= ~cpu_fill_e;
				end
			end
			else if (cpu_need) begin
				fetch_addr <= cpu_rom_want;
				fetch_kind <= 2'd0;
				fetch_on <= 1'b1;
			end
			else if (oki_need) begin
				fetch_addr <= oki_rom_want;
				fetch_kind <= 2'd1;
				fetch_on <= 1'b1;
			end
		end
	always @(*) begin
		if (_sv2v_0)
			;
		oki_rom_ok = oki_hit0 || oki_hit1;
		oki_rom_data = (oki_bsel ? oki_hit_word[15:8] : oki_hit_word[7:0]);
	end
	always @(*) begin
		if (_sv2v_0)
			;
		if (!cpu_rnw)
			cpu_din = cpu_dout;
		else if (cpu_addr < 16'h2000)
			cpu_din = ram_q;
		else if (io_ym)
			cpu_din = ym_dout;
		else if (io_oki)
			cpu_din = oki_dout;
		else if (io_cmd)
			cpu_din = command_latch;
		else if (prot_hit)
			cpu_din = prot_q;
		else if (cpu_rom && cpu_rom_ready)
			cpu_din = (cpu_fixed ? fix_q : cpu_rom_data);
		else
			cpu_din = 8'hff;
	end
	reg signed [17:0] dac_signed;
	reg signed [17:0] oki_signed;
	reg signed [31:0] mix;
	always @(*) begin
		if (_sv2v_0)
			;
		dac_signed = ($signed({1'b0, dac_data}) - 18'sd128) <<< 8;
		oki_signed = {{4 {oki_sound[13]}}, oki_sound};
		mix = (((($signed(ym_left) * 32'sd26) >>> 8) + (($signed(ym_right) * 32'sd26) >>> 8)) + ((dac_signed * 32'sd26) >>> 8)) + ((oki_signed * 32'sd614) >>> 8);
	end
	always @(posedge clk)
		if (mix > 32'sd32767) begin
			audio_l <= 16'sh7fff;
			audio_r <= 16'sh7fff;
		end
		else if (mix < -32'sd32768) begin
			audio_l <= -16'sh8000;
			audio_r <= -16'sh8000;
		end
		else begin
			audio_l <= mix[15:0];
			audio_r <= mix[15:0];
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_input_mapper (
	game_id,
	joy0,
	joy1,
	joy2,
	joy3,
	dsw_raw,
	adpcm_irq,
	inputs
);
	reg _sv2v_0;
	input wire [3:0] game_id;
	input wire [15:0] joy0;
	input wire [15:0] joy1;
	input wire [15:0] joy2;
	input wire [15:0] joy3;
	input wire [15:0] dsw_raw;
	input wire adpcm_irq;
	output reg [63:0] inputs;
	reg [15:0] in0;
	reg [15:0] in1;
	reg [15:0] in2;
	reg [15:0] dsw;
	reg test_mode;
	reg [3:0] start_bit;
	reg [3:0] coin_bit;
	localparam [3:0] yunit_pkg_YG_HIIMPACT = 4'd2;
	localparam [3:0] yunit_pkg_YG_MK = 4'd5;
	localparam [3:0] yunit_pkg_YG_SAURNFRNT = 4'd9;
	localparam [3:0] yunit_pkg_YG_SHIMPACT = 4'd3;
	localparam [3:0] yunit_pkg_YG_SMASHTV = 4'd0;
	localparam [3:0] yunit_pkg_YG_STRKFORC = 4'd4;
	localparam [3:0] yunit_pkg_YG_TERM2 = 4'd6;
	localparam [3:0] yunit_pkg_YG_TOTCARN = 4'd7;
	localparam [3:0] yunit_pkg_YG_TROG = 4'd1;
	localparam [3:0] yunit_pkg_YG_YUNITTST = 4'd8;
	function automatic [3:0] yunit_pkg_yunit_action_buttons;
		input reg [3:0] game;
		case (game)
			yunit_pkg_YG_SMASHTV: yunit_pkg_yunit_action_buttons = 4'd5;
			yunit_pkg_YG_STRKFORC, yunit_pkg_YG_SAURNFRNT: yunit_pkg_yunit_action_buttons = 4'd3;
			yunit_pkg_YG_MK: yunit_pkg_yunit_action_buttons = 4'd6;
			yunit_pkg_YG_TERM2: yunit_pkg_yunit_action_buttons = 4'd4;
			yunit_pkg_YG_TOTCARN: yunit_pkg_yunit_action_buttons = 4'd4;
			default: yunit_pkg_yunit_action_buttons = 4'd1;
		endcase
	endfunction
	function automatic [3:0] yunit_pkg_yunit_coin_bit;
		input reg [3:0] game;
		yunit_pkg_yunit_coin_bit = 4'd5 + yunit_pkg_yunit_action_buttons(game);
	endfunction
	function automatic [3:0] yunit_pkg_yunit_start_bit;
		input reg [3:0] game;
		yunit_pkg_yunit_start_bit = 4'd4 + yunit_pkg_yunit_action_buttons(game);
	endfunction
	function automatic yunit_pkg_yunit_test_mode;
		input reg [3:0] game;
		input reg [15:0] dsw;
		case (game)
			yunit_pkg_YG_SMASHTV, yunit_pkg_YG_STRKFORC: yunit_pkg_yunit_test_mode = ~dsw[15];
			yunit_pkg_YG_SAURNFRNT: yunit_pkg_yunit_test_mode = dsw[14];
			yunit_pkg_YG_TROG, yunit_pkg_YG_HIIMPACT, yunit_pkg_YG_SHIMPACT, yunit_pkg_YG_MK, yunit_pkg_YG_TERM2, yunit_pkg_YG_TOTCARN: yunit_pkg_yunit_test_mode = ~dsw[8];
			yunit_pkg_YG_YUNITTST: yunit_pkg_yunit_test_mode = 1'b1;
			default: yunit_pkg_yunit_test_mode = 1'b0;
		endcase
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		in0 = 16'hffff;
		in1 = 16'hffff;
		in2 = 16'hffff;
		dsw = dsw_raw;
		test_mode = yunit_pkg_yunit_test_mode(game_id, dsw_raw);
		start_bit = yunit_pkg_yunit_start_bit(game_id);
		coin_bit = yunit_pkg_yunit_coin_bit(game_id);
		in1[0] = ~joy0[coin_bit];
		in1[1] = ~joy1[coin_bit];
		in1[2] = ~(joy0[start_bit] | (test_mode && (game_id == yunit_pkg_YG_TERM2 ? joy0[3] | joy1[3] : joy0[4])));
		in1[5] = ~(joy1[start_bit] | (test_mode && (game_id == yunit_pkg_YG_TERM2 ? joy0[2] | joy1[2] : joy1[4])));
		if (game_id == yunit_pkg_YG_SMASHTV)
			in1[6] = ~joy0[8];
		case (game_id)
			yunit_pkg_YG_SMASHTV, yunit_pkg_YG_TOTCARN: begin
				in0[0] = ~joy0[3];
				in0[1] = ~joy0[2];
				in0[2] = ~joy0[1];
				in0[3] = ~joy0[0];
				in0[8] = ~joy1[3];
				in0[9] = ~joy1[2];
				in0[10] = ~joy1[1];
				in0[11] = ~joy1[0];
				in0[4] = ~joy0[4];
				in0[5] = ~joy0[5];
				in0[6] = ~joy0[6];
				in0[7] = ~joy0[7];
				in0[12] = ~joy1[4];
				in0[13] = ~joy1[5];
				in0[14] = ~joy1[6];
				in0[15] = ~joy1[7];
				in1[9] = ~joy2[coin_bit];
				if (game_id == yunit_pkg_YG_SMASHTV)
					dsw = dsw_raw | 16'h4000;
				if (game_id == yunit_pkg_YG_TOTCARN)
					in1[14] = ~adpcm_irq;
			end
			yunit_pkg_YG_TROG, yunit_pkg_YG_HIIMPACT, yunit_pkg_YG_SHIMPACT, yunit_pkg_YG_YUNITTST: begin
				in0[0] = ~joy0[3];
				in0[1] = ~joy0[2];
				in0[2] = ~joy0[1];
				in0[3] = ~joy0[0];
				in0[8] = ~joy1[3];
				in0[9] = ~joy1[2];
				in0[10] = ~joy1[1];
				in0[11] = ~joy1[0];
				in0[4] = ~joy0[4];
				in0[12] = ~joy1[4];
				in1[9] = ~joy2[start_bit];
				in1[10] = ~joy3[start_bit];
				in1[11] = ~joy2[3];
				in1[12] = ~joy2[2];
				in1[13] = ~joy2[1];
				in1[14] = ~joy2[0];
				in1[15] = ~joy2[4];
				in2[0] = ~joy3[3];
				in2[1] = ~joy3[2];
				in2[2] = ~joy3[1];
				in2[3] = ~joy3[0];
				in2[4] = ~joy3[4];
				if (game_id == yunit_pkg_YG_TROG)
					in2[5] = ~joy2[coin_bit];
				else begin
					in1[7] = ~joy2[coin_bit];
					in2[5] = ~joy3[coin_bit];
				end
			end
			yunit_pkg_YG_STRKFORC, yunit_pkg_YG_SAURNFRNT: begin
				in0[0] = ~joy0[3];
				in0[1] = ~joy0[2];
				in0[2] = ~joy0[1];
				in0[3] = ~joy0[0];
				in0[8] = ~joy1[3];
				in0[9] = ~joy1[2];
				in0[10] = ~joy1[1];
				in0[11] = ~joy1[0];
				in0[4] = ~joy0[4];
				in0[5] = ~joy0[5];
				in0[6] = ~joy0[6];
				in0[12] = ~joy1[4];
				in0[13] = ~joy1[5];
				in0[14] = ~joy1[6];
				in1[7] = ~joy2[coin_bit];
				in1[9] = ~joy3[coin_bit];
			end
			yunit_pkg_YG_MK: begin
				in0[0] = ~joy0[3];
				in0[1] = ~joy0[2];
				in0[2] = ~joy0[1];
				in0[3] = ~joy0[0];
				in0[8] = ~joy1[3];
				in0[9] = ~joy1[2];
				in0[10] = ~joy1[1];
				in0[11] = ~joy1[0];
				in0[4] = ~joy0[4];
				in0[5] = ~joy0[6];
				in0[6] = ~joy0[7];
				in0[12] = ~joy1[4];
				in0[13] = ~joy1[6];
				in0[14] = ~joy1[7];
				in1[8] = ~joy2[coin_bit];
				in1[9] = ~joy1[5];
				in1[10] = ~joy1[8];
				in1[11] = ~joy1[9];
				in1[12] = ~joy0[5];
				in1[13] = ~joy0[8];
				in1[14] = ~adpcm_irq;
				in1[15] = ~joy0[9];
			end
			yunit_pkg_YG_TERM2: begin
				in0[4] = ~joy0[4];
				in0[5] = ~joy0[5];
				in0[12] = ~(joy1[4] | joy0[6]);
				in0[13] = ~(joy1[5] | joy0[7]);
				in1[7] = ~joy2[coin_bit];
				in1[9] = ~joy3[coin_bit];
				in1[14] = ~adpcm_irq;
			end
			default:
				;
		endcase
		inputs = {dsw, in2, in1, in0};
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_twinstick (
	clk,
	reset,
	game_id,
	l_analog_0,
	r_analog_0,
	l_analog_1,
	r_analog_1,
	joy0_or,
	joy1_or
);
	reg _sv2v_0;
	input wire clk;
	input wire reset;
	input wire [3:0] game_id;
	input wire [15:0] l_analog_0;
	input wire [15:0] r_analog_0;
	input wire [15:0] l_analog_1;
	input wire [15:0] r_analog_1;
	output reg [7:0] joy0_or;
	output reg [7:0] joy1_or;
	localparam signed [31:0] REF_DELAY = 2097152;
	reg [21:0] ref_cnt;
	reg ref_latched;
	reg signed [7:0] ref_l0x;
	reg signed [7:0] ref_l0y;
	reg signed [7:0] ref_r0x;
	reg signed [7:0] ref_r0y;
	reg signed [7:0] ref_l1x;
	reg signed [7:0] ref_l1y;
	reg signed [7:0] ref_r1x;
	reg signed [7:0] ref_r1y;
	always @(posedge clk)
		if (reset) begin
			ref_cnt <= 1'sb0;
			ref_latched <= 1'b0;
		end
		else if (!ref_latched) begin
			ref_cnt <= ref_cnt + 22'd1;
			if (ref_cnt == REF_DELAY[21:0]) begin
				ref_l0x <= l_analog_0[7:0];
				ref_l0y <= l_analog_0[15:8];
				ref_r0x <= r_analog_0[7:0];
				ref_r0y <= r_analog_0[15:8];
				ref_l1x <= l_analog_1[7:0];
				ref_l1y <= l_analog_1[15:8];
				ref_r1x <= r_analog_1[7:0];
				ref_r1y <= r_analog_1[15:8];
				ref_latched <= 1'b1;
			end
		end
	function automatic [3:0] dirs;
		input reg [15:0] axes;
		input reg signed [7:0] refx;
		input reg signed [7:0] refy;
		reg signed [8:0] dx;
		reg signed [8:0] dy;
		begin
			dx = {axes[7], axes[7:0]} - {refx[7], refx};
			dy = {axes[15], axes[15:8]} - {refy[7], refy};
			dirs = {dy < -9'sd64, dy > 9'sd64, dx < -9'sd64, dx > 9'sd64};
		end
	endfunction
	localparam [3:0] yunit_pkg_YG_SMASHTV = 4'd0;
	localparam [3:0] yunit_pkg_YG_TOTCARN = 4'd7;
	wire twinstick_title = (game_id == yunit_pkg_YG_SMASHTV) || (game_id == yunit_pkg_YG_TOTCARN);
	localparam [3:0] yunit_pkg_YG_TERM2 = 4'd6;
	wire term2_title = game_id == yunit_pkg_YG_TERM2;
	wire live = ((twinstick_title || term2_title) && ref_latched) && !reset;
	reg [3:0] m0;
	reg [3:0] f0;
	reg [3:0] m1;
	reg [3:0] f1;
	always @(*) begin
		if (_sv2v_0)
			;
		m0 = dirs(l_analog_0, ref_l0x, ref_l0y);
		f0 = dirs(r_analog_0, ref_r0x, ref_r0y);
		m1 = dirs(l_analog_1, ref_l1x, ref_l1y);
		f1 = dirs(r_analog_1, ref_r1x, ref_r1y);
		joy0_or = 8'h00;
		joy1_or = 8'h00;
		if (live) begin
			if (twinstick_title) begin
				joy0_or = {f0[0], f0[1], f0[2], f0[3], m0};
				joy1_or = {f1[0], f1[1], f1[2], f1[3], m1};
			end
			else begin
				joy0_or = {4'h0, m0};
				joy1_or = {4'h0, m1};
			end
		end
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_cpu_cadence (
	clk,
	rst,
	game,
	ce_micro,
	arch_cycle,
	arch_step
);
	reg _sv2v_0;
	input wire clk;
	input wire rst;
	input wire [3:0] game;
	output wire ce_micro;
	output wire arch_cycle;
	output reg [5:0] arch_step;
	localparam [9:0] PHASE_DEN = 10'd384;
	(* preserve *) reg ce_micro_q;
	reg [8:0] phase;
	wire [9:0] phase_sum;
	reg [8:0] micro_phase;
	wire [9:0] micro_sum;
	wire [8:0] micro_phase_next;
	wire [9:0] micro_sum_next;
	wire micro_wrap;
	wire micro_tick_next;
	localparam [1:0] yunit_pkg_YC_FAST = 2'd1;
	localparam [1:0] yunit_pkg_YC_FASTER = 2'd2;
	localparam [1:0] yunit_pkg_YC_SLOWER = 2'd0;
	localparam [3:0] yunit_pkg_YG_MK = 4'd5;
	localparam [3:0] yunit_pkg_YG_SAURNFRNT = 4'd9;
	localparam [3:0] yunit_pkg_YG_STRKFORC = 4'd4;
	localparam [3:0] yunit_pkg_YG_TERM2 = 4'd6;
	localparam [3:0] yunit_pkg_YG_TOTCARN = 4'd7;
	function automatic [1:0] yunit_pkg_yunit_clock_class;
		input reg [3:0] game;
		if (game == yunit_pkg_YG_TERM2)
			yunit_pkg_yunit_clock_class = yunit_pkg_YC_FASTER;
		else if ((((game == yunit_pkg_YG_STRKFORC) || (game == yunit_pkg_YG_SAURNFRNT)) || (game == yunit_pkg_YG_MK)) || (game == yunit_pkg_YG_TOTCARN))
			yunit_pkg_yunit_clock_class = yunit_pkg_YC_FAST;
		else
			yunit_pkg_yunit_clock_class = yunit_pkg_YC_SLOWER;
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		case (yunit_pkg_yunit_clock_class(game))
			yunit_pkg_YC_FAST: arch_step = 6'd24;
			yunit_pkg_YC_FASTER: arch_step = 6'd25;
			default: arch_step = 6'd20;
		endcase
	end
	assign phase_sum = {1'b0, phase} + {4'b0000, arch_step};
	assign micro_sum = {1'b0, micro_phase} + 10'd100;
	assign arch_cycle = phase_sum >= PHASE_DEN;
	assign ce_micro = ce_micro_q;
	assign micro_wrap = micro_sum >= PHASE_DEN;
	function automatic [8:0] sv2v_cast_9;
		input reg [8:0] inp;
		sv2v_cast_9 = inp;
	endfunction
	assign micro_phase_next = (micro_wrap ? sv2v_cast_9(micro_sum - PHASE_DEN) : micro_sum[8:0]);
	assign micro_sum_next = {1'b0, micro_phase_next} + 10'd100;
	assign micro_tick_next = micro_sum_next >= PHASE_DEN;
	always @(posedge clk)
		if (rst) begin
			phase <= 9'd0;
			micro_phase <= 9'd0;
			ce_micro_q <= 1'b0;
		end
		else begin
			if (arch_cycle)
				phase <= sv2v_cast_9(phase_sum - PHASE_DEN);
			else
				phase <= phase_sum[8:0];
			micro_phase <= micro_phase_next;
			ce_micro_q <= micro_tick_next;
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_top (
	clk,
	clk_cpu,
	ce_pix,
	cpu_div_sel,
	clk_snd,
	rst,
	rst_pon,
	sdram_por,
	inputs,
	game_id,
	term2_analog,
	cmos_quiesce,
	nvram_ext_en,
	nvram_ext_wr,
	nvram_ext_addr,
	nvram_ext_wdata,
	nvram_ext_rdata,
	cmos_cpu_busy,
	cmos_cpu_write_pulse,
	ioctl_download,
	gfx_download,
	sound_download,
	ioctl_wr,
	ioctl_addr,
	ioctl_dout,
	ioctl_be,
	ioctl_wait,
	snd_dl_wr,
	snd_dl_addr,
	snd_dl_data,
	SDRAM_DQ,
	SDRAM_A,
	SDRAM_BA,
	SDRAM_DQML,
	SDRAM_DQMH,
	SDRAM_nCS,
	SDRAM_nRAS,
	SDRAM_nCAS,
	SDRAM_nWE,
	SDRAM_CKE,
	DDRAM_ADDR,
	DDRAM_BURSTCNT,
	DDRAM_RD,
	DDRAM_DIN,
	DDRAM_BE,
	DDRAM_WE,
	DDRAM_BUSY,
	DDRAM_DOUT,
	DDRAM_DOUT_READY,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de,
	audio_l,
	audio_r,
	adpcm_irq,
	pc_dbg,
	illegal_dbg,
	dbg_core_rst,
	dbg_sdram_ready,
	dbg_unp_done,
	dbg_cpu_req,
	dbg_mem_ack,
	dbg_int1,
	dbg_vblank_irq,
	dbg_cpu_ce,
	dbg_p1ctrl,
	dbg_bdir,
	dbg_snd_select,
	dbg_snd_trig,
	dbg_derailed,
	dbg_culprit_pc,
	dbg_culprit_instr,
	dbg_derail_pc,
	dbg_disp_flips,
	dbg_disp_rows,
	autoerase_off,
	dbg_iol_drop,
	dbg_iol_wrs,
	dbg_dma_we,
	dbg_dma_addr,
	dbg_dma_wdata,
	dbg_dma_render_overflow,
	dbg_dma_render_level,
	dbg_dma_vram_order_stall,
	dbg_src_data,
	dbg_src_ack,
	dbg_scan_data,
	dbg_scan_ack,
	dbg_cgfx_grants,
	dbg_snd_grants,
	dbg_cgfx_maxwait,
	dbg_snd_miss,
	dbg_snd_busy16,
	dbg_cvsd_moves,
	dbg_adpcm_moves,
	dbg_blank_pix,
	dbg_cpu_pc_moves,
	dbg_snd_acks,
	dbg_snd_first_words,
	dbg_snd_region_seen,
	dbg_snd_board_rst,
	dbg_restart_cnt
);
	reg _sv2v_0;
	parameter ROM_HEX = "smashtv_maindata.hex";
	parameter signed [31:0] H_ACT = 410;
	parameter signed [31:0] H_FP = 6;
	parameter signed [31:0] H_SYNC = 44;
	parameter signed [31:0] H_BP = 46;
	parameter signed [31:0] V_ACT = 256;
	parameter signed [31:0] V_FP = 13;
	parameter signed [31:0] V_SYNC = 4;
	parameter signed [31:0] V_BP = 16;
	parameter signed [31:0] DISP_ROW0 = 0;
	parameter [24:0] GFXW_BASE = 25'h0000000;
	parameter [24:0] ROMW_BASE = 25'h00c0000;
	parameter [24:0] VRAMW_BASE = 25'h00e0000;
	parameter [23:0] GFX_BYTES = 24'h180000;
	parameter [24:0] SCRATCH_WBASE = 25'h0120000;
	parameter [24:0] SOUNDW_BASE = 25'h0120000;
	parameter [23:0] PLANE_WORDS = 24'h030000;
	parameter signed [31:0] ROM_WORDS = 32'h00020000;
	parameter signed [31:0] ROM_WORD_OFFSET = 32'h00060000;
	input wire clk;
	input wire clk_cpu;
	input wire ce_pix;
	input wire [2:0] cpu_div_sel;
	input wire clk_snd;
	input wire rst;
	input wire rst_pon;
	input wire sdram_por;
	input wire [63:0] inputs;
	input wire [3:0] game_id;
	input wire [31:0] term2_analog;
	input wire cmos_quiesce;
	input wire nvram_ext_en;
	input wire nvram_ext_wr;
	input wire [14:0] nvram_ext_addr;
	input wire [7:0] nvram_ext_wdata;
	output wire [7:0] nvram_ext_rdata;
	output wire cmos_cpu_busy;
	output wire cmos_cpu_write_pulse;
	input wire ioctl_download;
	input wire gfx_download;
	input wire sound_download;
	input wire ioctl_wr;
	input wire [24:0] ioctl_addr;
	input wire [15:0] ioctl_dout;
	input wire [1:0] ioctl_be;
	output wire ioctl_wait;
	input wire snd_dl_wr;
	input wire [17:0] snd_dl_addr;
	input wire [7:0] snd_dl_data;
	inout wire [15:0] SDRAM_DQ;
	output wire [12:0] SDRAM_A;
	output wire [1:0] SDRAM_BA;
	output wire SDRAM_DQML;
	output wire SDRAM_DQMH;
	output wire SDRAM_nCS;
	output wire SDRAM_nRAS;
	output wire SDRAM_nCAS;
	output wire SDRAM_nWE;
	output wire SDRAM_CKE;
	output wire [28:0] DDRAM_ADDR;
	output wire [7:0] DDRAM_BURSTCNT;
	output wire DDRAM_RD;
	output wire [63:0] DDRAM_DIN;
	output wire [7:0] DDRAM_BE;
	output wire DDRAM_WE;
	input wire DDRAM_BUSY;
	input wire [63:0] DDRAM_DOUT;
	input wire DDRAM_DOUT_READY;
	output wire [7:0] vid_r;
	output wire [7:0] vid_g;
	output wire [7:0] vid_b;
	output wire hsync;
	output wire vsync;
	output wire hblank;
	output wire vblank;
	output wire de;
	output reg signed [15:0] audio_l;
	output reg signed [15:0] audio_r;
	output wire adpcm_irq;
	output wire [31:0] pc_dbg;
	output wire illegal_dbg;
	output wire dbg_core_rst;
	output wire dbg_sdram_ready;
	output wire dbg_unp_done;
	output wire dbg_cpu_req;
	output wire dbg_mem_ack;
	output wire dbg_int1;
	output wire dbg_vblank_irq;
	output wire dbg_cpu_ce;
	output wire [31:0] dbg_p1ctrl;
	output wire [31:0] dbg_bdir;
	output wire [7:0] dbg_snd_select;
	output wire dbg_snd_trig;
	output reg dbg_derailed;
	output reg [31:0] dbg_culprit_pc;
	output reg [15:0] dbg_culprit_instr;
	output reg [31:0] dbg_derail_pc;
	output wire [31:0] dbg_disp_flips;
	output wire [31:0] dbg_disp_rows;
	input wire autoerase_off;
	output wire [31:0] dbg_iol_drop;
	output wire [31:0] dbg_iol_wrs;
	output wire dbg_dma_we;
	output wire [3:0] dbg_dma_addr;
	output wire [15:0] dbg_dma_wdata;
	output wire dbg_dma_render_overflow;
	output wire [9:0] dbg_dma_render_level;
	output wire dbg_dma_vram_order_stall;
	output wire [7:0] dbg_src_data;
	output wire dbg_src_ack;
	output wire [15:0] dbg_scan_data;
	output wire dbg_scan_ack;
	output wire [15:0] dbg_cgfx_grants;
	output wire [15:0] dbg_snd_grants;
	output wire [31:0] dbg_cgfx_maxwait;
	output wire [15:0] dbg_snd_miss;
	output wire [15:0] dbg_snd_busy16;
	output wire [15:0] dbg_cvsd_moves;
	output wire [15:0] dbg_adpcm_moves;
	output wire [15:0] dbg_blank_pix;
	output wire [31:0] dbg_cpu_pc_moves;
	output wire [31:0] dbg_snd_acks;
	output wire [31:0] dbg_snd_first_words;
	output wire dbg_snd_region_seen;
	output wire dbg_snd_board_rst;
	output wire [15:0] dbg_restart_cnt;
	wire sdram_ready;
	localparam [3:0] yunit_pkg_YG_SMASHTV = 4'd0;
	wire [3:0] game = (^game_id === 1'bx ? yunit_pkg_YG_SMASHTV : game_id);
	localparam [3:0] yunit_pkg_YG_SAURNFRNT = 4'd9;
	localparam [3:0] yunit_pkg_YG_STRKFORC = 4'd4;
	localparam [3:0] yunit_pkg_YG_TROG = 4'd1;
	function automatic yunit_pkg_yunit_is_4bpp;
		input reg [3:0] game;
		yunit_pkg_yunit_is_4bpp = ((game == yunit_pkg_YG_TROG) || (game == yunit_pkg_YG_STRKFORC)) || (game == yunit_pkg_YG_SAURNFRNT);
	endfunction
	wire game_bpp4 = yunit_pkg_yunit_is_4bpp(game);
	localparam [3:0] yunit_pkg_YG_HIIMPACT = 4'd2;
	localparam [3:0] yunit_pkg_YG_MK = 4'd5;
	localparam [3:0] yunit_pkg_YG_SHIMPACT = 4'd3;
	localparam [3:0] yunit_pkg_YG_TERM2 = 4'd6;
	localparam [3:0] yunit_pkg_YG_TOTCARN = 4'd7;
	function automatic [23:0] yunit_pkg_yunit_plane_words;
		input reg [3:0] game;
		case (game)
			yunit_pkg_YG_TROG: yunit_pkg_yunit_plane_words = 24'h060000;
			yunit_pkg_YG_HIIMPACT: yunit_pkg_yunit_plane_words = 24'h040000;
			yunit_pkg_YG_SHIMPACT: yunit_pkg_yunit_plane_words = 24'h080000;
			yunit_pkg_YG_STRKFORC, yunit_pkg_YG_SAURNFRNT: yunit_pkg_yunit_plane_words = 24'h060000;
			yunit_pkg_YG_MK, yunit_pkg_YG_TERM2: yunit_pkg_yunit_plane_words = 24'h100000;
			yunit_pkg_YG_TOTCARN: yunit_pkg_yunit_plane_words = 24'h080000;
			default: yunit_pkg_yunit_plane_words = 24'h030000;
		endcase
	endfunction
	wire [23:0] game_plane_words = (PLANE_WORDS != 24'h030000 ? PLANE_WORDS : yunit_pkg_yunit_plane_words(game));
	function automatic [23:0] yunit_pkg_yunit_gfx_bytes;
		input reg [3:0] game;
		reg [23:0] pw;
		begin
			pw = yunit_pkg_yunit_plane_words(game);
			yunit_pkg_yunit_gfx_bytes = {pw[20:0], 3'b000};
		end
	endfunction
	wire [23:0] game_gfx_bytes = yunit_pkg_yunit_gfx_bytes(game);
	wire unp_done;
	wire download_path_busy;
	wire core_rst = (((rst | ~sdram_ready) | ioctl_download) | download_path_busy) | ~unp_done;
	wire cpu_micro_tick;
	wire cpu_ce;
	wire cpu_arch_cycle;
	wire [5:0] cpu_arch_step;
	yunit_cpu_cadence u_cpu_cadence(
		.clk(clk),
		.rst(core_rst),
		.game(game),
		.ce_micro(cpu_micro_tick),
		.arch_cycle(cpu_arch_cycle),
		.arch_step(cpu_arch_step)
	);
	reg core_rst_sys_m;
	reg core_rst_sys;
	always @(posedge clk) begin
		core_rst_sys_m <= core_rst;
		core_rst_sys <= core_rst_sys_m;
	end
	wire cpu_instr_start;
	wire cpu_instr_retire;
	wire [15:0] cpu_instr_cycles;
	wire cpu_instr_cycles_valid;
	wire cpu_cadence_stall;
	wire cpu_cadence_overrun;
	(* keep *) reg cpu_cycle_budget_invalid;
	tms34010_cycle_scheduler u_cpu_scheduler(
		.clk(clk),
		.rst(core_rst_sys),
		.micro_tick(cpu_micro_tick),
		.arch_step(cpu_arch_step),
		.instr_start(cpu_instr_start),
		.instr_retire(cpu_instr_retire),
		.instr_cycles((cpu_instr_cycles_valid ? cpu_instr_cycles : 16'd1)),
		.ce_cpu(cpu_ce),
		.cadence_stall(cpu_cadence_stall),
		.cadence_overrun(cpu_cadence_overrun)
	);
	always @(posedge clk)
		if (core_rst_sys)
			cpu_cycle_budget_invalid <= 1'b0;
		else if (cpu_instr_retire && !cpu_instr_cycles_valid)
			cpu_cycle_budget_invalid <= 1'b1;
	wire int1;
	wire cpu_req;
	wire cpu_we;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	wire [31:0] cpu_addr;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	wire [5:0] cpu_size;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	wire [31:0] cpu_wdata;
	wire [31:0] cpu_rdata;
	wire [31:0] core_mem_rdata;
	wire cpu_ack;
	wire core_mem_ack;
	wire cpu_shiftreg_req;
	wire cpu_shiftreg_write;
	wire [31:0] cpu_shiftreg_bit_addr;
	wire sr_req_ready;
	wire sr_read_busy;
	wire sr_done;
	wire sr_error;
	wire [15:0] sr_read_data;
	wire sr_mem_valid;
	wire sr_mem_ready;
	wire sr_mem_write;
	wire [17:0] sr_mem_addr;
	wire [15:0] sr_mem_wdata;
	wire [15:0] sr_mem_rdata;
	wire sr_engine_req_valid;
	wire sr_engine_req_write;
	wire [31:0] sr_engine_req_bit_addr;
	wire sr_core_ack;
	(* keep *) wire sr_error_sticky;
	wire [5:0] state_w;
	localparam [31:0] tms34010_pkg_INSTR_WORD_WIDTH = 16;
	wire [15:0] instr_w;
	reg ce_pix_ph;
	wire timing_start;
	wire tms_display_wr_valid;
	localparam [31:0] tms34010_pkg_IO_REG_IDX_W = 5;
	wire [4:0] tms_display_wr_idx;
	wire [15:0] tms_display_wr_data;
	wire tms_display_line_wrap;
	wire [15:0] display_dpyadr_live;
	always @(posedge clk)
		if (core_rst_sys || timing_start)
			ce_pix_ph <= 1'b0;
		else if (ce_pix)
			ce_pix_ph <= ~ce_pix_ph;
	wire ce_pix_cnt = ce_pix & ce_pix_ph;
	tms34010_core u_core(
		.clk(clk),
		.ce_cpu(cpu_ce),
		.ce_pix(ce_pix_cnt),
		.rst(core_rst_sys),
		.mem_req(cpu_req),
		.mem_we(cpu_we),
		.mem_addr(cpu_addr),
		.mem_size(cpu_size),
		.mem_wdata(cpu_wdata),
		.mem_rdata(core_mem_rdata),
		.mem_ack(core_mem_ack),
		.state_o(state_w),
		.pc_o(pc_dbg),
		.instr_word_o(instr_w),
		.illegal_opcode_o(illegal_dbg),
		.srt_fill_ack_i(1'b0),
		.instruction_start_o(cpu_instr_start),
		.instruction_retire_o(cpu_instr_retire),
		.instruction_cycles_o(cpu_instr_cycles),
		.instruction_cycles_valid_o(cpu_instr_cycles_valid),
		.timing_start_o(timing_start),
		.display_wr_valid_o(tms_display_wr_valid),
		.display_wr_idx_o(tms_display_wr_idx),
		.display_wr_data_o(tms_display_wr_data),
		.display_line_wrap_o(tms_display_line_wrap),
		.display_dpyadr_live_i(display_dpyadr_live),
		.display_dpyadr_live_valid_i(1'b1),
		.srt_fill_exact_enable_i(1'b0),
		.shiftreg_req_o(cpu_shiftreg_req),
		.shiftreg_write_o(cpu_shiftreg_write),
		.shiftreg_bit_addr_o(cpu_shiftreg_bit_addr),
		.lint1_in(int1)
	);
	yunit_shiftreg_command_bridge #(.AW(tms34010_pkg_ADDR_WIDTH)) u_shiftreg_cmd(
		.clk(clk),
		.rst(core_rst_sys),
		.cpu_ce(cpu_ce),
		.cpu_req(cpu_shiftreg_req),
		.cpu_write(cpu_shiftreg_write),
		.cpu_bit_addr(cpu_shiftreg_bit_addr),
		.engine_req_valid(sr_engine_req_valid),
		.engine_req_ready(sr_req_ready),
		.engine_req_write(sr_engine_req_write),
		.engine_req_bit_addr(sr_engine_req_bit_addr),
		.engine_done(sr_done),
		.engine_error(sr_error),
		.core_ack(sr_core_ack),
		.error_sticky(sr_error_sticky)
	);
	assign core_mem_ack = (cpu_shiftreg_req ? sr_core_ack : cpu_ack);
	assign core_mem_rdata = (cpu_shiftreg_req ? {{16 {1'b0}}, sr_read_data} : cpu_rdata);
	yunit_shiftreg_engine u_shiftreg(
		.clk(clk),
		.rst(core_rst_sys),
		.req_valid(sr_engine_req_valid),
		.req_ready(sr_req_ready),
		.req_write(sr_engine_req_write),
		.req_bit_addr(sr_engine_req_bit_addr),
		.read_data(sr_read_data),
		.busy(sr_read_busy),
		.done(sr_done),
		.error(sr_error),
		.mem_valid(sr_mem_valid),
		.mem_ready(sr_mem_ready),
		.mem_write(sr_mem_write),
		.mem_addr(sr_mem_addr),
		.mem_wdata(sr_mem_wdata),
		.mem_rdata(sr_mem_rdata),
		.mem_error(1'b0)
	);
	wire display_line_tick = timing_start | tms_display_line_wrap;
	wire [15:0] display_vcount_live;
	wire display_line_event;
	wire display_scanout_valid;
	wire [15:0] display_scanout_vcount;
	wire [11:0] display_scanout_row_raw;
	wire [8:0] display_scanout_row_phys;
	wire [17:0] display_scanout_base_word;
	wire [13:0] display_scanout_coladdr;
	wire [8:0] display_scanout_col_word;
	wire [1:0] display_scanout_yoffset;
	wire display_prefetch_valid;
	wire [15:0] display_prefetch_vcount;
	wire [11:0] display_prefetch_row_raw;
	wire [8:0] display_prefetch_row_phys;
	wire [17:0] display_prefetch_base_word;
	wire [13:0] display_prefetch_coladdr;
	wire [8:0] display_prefetch_col_word;
	wire [1:0] display_prefetch_yoffset;
	wire display_line_consumed_valid;
	wire [11:0] display_line_consumed_row_raw;
	wire [8:0] display_line_consumed_row_phys;
	wire [17:0] display_line_consumed_base_word;
	wire display_contract_valid;
	(* keep *) wire display_unsupported_mode;
	(* keep *) wire display_config_invalid;
	(* keep *) wire display_timing_conflict_pulse;
	(* keep *) wire display_timing_conflict_sticky;
	(* keep *) wire display_line_deferred_pulse;
	(* keep *) wire display_line_deferred_sticky;
	(* keep *) wire display_sequence_error_pulse;
	(* keep *) wire display_sequence_error_sticky;
	wire mem_fb_busy;
	localparam [4:0] tms34010_pkg_IO_IDX_DPYADR = 5'h1e;
	localparam [4:0] tms34010_pkg_IO_IDX_DPYCTL = 5'h08;
	localparam [4:0] tms34010_pkg_IO_IDX_DPYSTRT = 5'h09;
	localparam [4:0] tms34010_pkg_IO_IDX_DPYTAP = 5'h1b;
	localparam [4:0] tms34010_pkg_IO_IDX_VEBLNK = 5'h05;
	localparam [4:0] tms34010_pkg_IO_IDX_VSBLNK = 5'h06;
	localparam [4:0] tms34010_pkg_IO_IDX_VTOTAL = 5'h07;
	yunit_display_address_sequencer u_display_address(
		.clk(clk),
		.rst(core_rst_sys),
		.line_tick(display_line_tick),
		.dpyctl_we(tms_display_wr_valid && (tms_display_wr_idx == tms34010_pkg_IO_IDX_DPYCTL)),
		.dpyctl_wdata(tms_display_wr_data),
		.dpystart_we(tms_display_wr_valid && (tms_display_wr_idx == tms34010_pkg_IO_IDX_DPYSTRT)),
		.dpystart_wdata(tms_display_wr_data),
		.dpytap_we(tms_display_wr_valid && (tms_display_wr_idx == tms34010_pkg_IO_IDX_DPYTAP)),
		.dpytap_wdata(tms_display_wr_data),
		.dpyadr_we(tms_display_wr_valid && (tms_display_wr_idx == tms34010_pkg_IO_IDX_DPYADR)),
		.dpyadr_wdata(tms_display_wr_data),
		.veblnk_we(tms_display_wr_valid && (tms_display_wr_idx == tms34010_pkg_IO_IDX_VEBLNK)),
		.veblnk_wdata(tms_display_wr_data),
		.vsblnk_we(tms_display_wr_valid && (tms_display_wr_idx == tms34010_pkg_IO_IDX_VSBLNK)),
		.vsblnk_wdata(tms_display_wr_data),
		.vtotal_we(tms_display_wr_valid && (tms_display_wr_idx == tms34010_pkg_IO_IDX_VTOTAL)),
		.vtotal_wdata(tms_display_wr_data),
		.flip_hold(1'b0),
		.vcount_live(display_vcount_live),
		.dpyadr_live(display_dpyadr_live),
		.line_event(display_line_event),
		.scanout_valid(display_scanout_valid),
		.scanout_vcount(display_scanout_vcount),
		.scanout_row_raw(display_scanout_row_raw),
		.scanout_row_phys(display_scanout_row_phys),
		.scanout_base_word(display_scanout_base_word),
		.scanout_coladdr(display_scanout_coladdr),
		.scanout_col_word(display_scanout_col_word),
		.scanout_yoffset(display_scanout_yoffset),
		.prefetch_valid(display_prefetch_valid),
		.prefetch_vcount(display_prefetch_vcount),
		.prefetch_row_raw(display_prefetch_row_raw),
		.prefetch_row_phys(display_prefetch_row_phys),
		.prefetch_base_word(display_prefetch_base_word),
		.prefetch_coladdr(display_prefetch_coladdr),
		.prefetch_col_word(display_prefetch_col_word),
		.prefetch_yoffset(display_prefetch_yoffset),
		.line_consumed_valid(display_line_consumed_valid),
		.line_consumed_row_raw(display_line_consumed_row_raw),
		.line_consumed_row_phys(display_line_consumed_row_phys),
		.line_consumed_base_word(display_line_consumed_base_word),
		.contract_valid(display_contract_valid),
		.unsupported_mode(display_unsupported_mode),
		.config_invalid(display_config_invalid),
		.timing_conflict_pulse(display_timing_conflict_pulse),
		.timing_conflict_sticky(display_timing_conflict_sticky),
		.line_deferred_pulse(display_line_deferred_pulse),
		.line_deferred_sticky(display_line_deferred_sticky),
		.sequence_error_pulse(display_sequence_error_pulse),
		.sequence_error_sticky(display_sequence_error_sticky)
	);
	wire mem_req;
	wire mem_we;
	wire [31:0] mem_addr;
	wire [5:0] mem_size;
	wire [31:0] mem_wdata;
	wire [31:0] mem_rdata;
	wire mem_ack;
	yunit_mem_cdc #(
		.AW(tms34010_pkg_ADDR_WIDTH),
		.DW(tms34010_pkg_DATA_WIDTH),
		.SW(tms34010_pkg_FIELD_SIZE_WIDTH)
	) u_memcdc(
		.clk_cpu(clk),
		.ce_cpu(cpu_ce),
		.rst_cpu(core_rst_sys),
		.c_req(cpu_req && !cpu_shiftreg_req),
		.c_we(cpu_we),
		.c_addr(cpu_addr),
		.c_size(cpu_size),
		.c_wdata(cpu_wdata),
		.c_ack(cpu_ack),
		.c_rdata(cpu_rdata),
		.clk_sys(clk),
		.rst_sys(core_rst_sys),
		.m_req(mem_req),
		.m_we(mem_we),
		.m_addr(mem_addr),
		.m_size(mem_size),
		.m_wdata(mem_wdata),
		.m_rdata(mem_rdata),
		.m_ack(mem_ack)
	);
	wire src_req;
	wire [23:0] src_addr;
	wire [7:0] src_data;
	wire src_ack;
	reg sndrom_rd;
	wire sndrom_ack;
	reg [20:0] sndrom_addr;
	wire [7:0] sndrom_data;
	wire cgfx_rd;
	wire [23:0] cgfx_addr;
	wire [15:0] cgfx_data;
	wire cgfx_ack;
	wire scan_req;
	wire [17:0] scan_addr;
	wire [15:0] scan_data;
	wire scan_ack;
	wire [24:0] vsd_addr;
	wire [15:0] vsd_din;
	wire [15:0] vsd_dout;
	wire [1:0] vsd_be;
	wire vsd_rd;
	wire vsd_wr;
	wire vsd_ack;
	wire [7:0] snd_select;
	wire snd_trig;
	wire snd_reset;
	wire [1:0] term2_adc_sel;
	reg [7:0] term2_adc;
	always @(*) begin
		if (_sv2v_0)
			;
		case (term2_adc_sel)
			2'd0: term2_adc = term2_analog[7:0];
			2'd1: term2_adc = term2_analog[15:8];
			2'd2: term2_adc = term2_analog[23:16];
			default: term2_adc = term2_analog[31:24];
		endcase
	end
	assign dbg_snd_select = snd_select;
	assign dbg_snd_trig = snd_trig;
	wire erase_busy;
	wire legacy_erase_busy;
	wire blit_busy;
	wire autoerase_enable;
	wire fb_snoop_we;
	wire [17:0] fb_snoop_addr;
	wire [15:0] fb_snoop_data;
	wire sr_mem_write_commit = (sr_mem_valid && sr_mem_ready) && sr_mem_write;
	wire video_snoop_we = fb_snoop_we || sr_mem_write_commit;
	wire [17:0] video_snoop_addr = (sr_mem_write_commit ? sr_mem_addr : fb_snoop_addr);
	wire [15:0] video_snoop_data = (sr_mem_write_commit ? sr_mem_wdata : fb_snoop_data);
	wire ae_line_invalidate;
	reg [8:0] ae_active_dst_row;
	wire palv_we_a;
	wire palv_we_b;
	wire [12:0] palv_aa;
	wire [12:0] palv_ba;
	wire [15:0] palv_awd;
	wire [15:0] palv_bwd;
	wire vblank_irq;
	yunit_memsys #(
		.ROM_HEX(ROM_HEX),
		.ROM_WORDS(ROM_WORDS),
		.ROM_WORD_OFFSET(ROM_WORD_OFFSET),
		.GFX_PIXELS(GFX_BYTES)
	) u_sys(
		.clk(clk),
		.rst(core_rst),
		.mem_req(mem_req),
		.mem_we(mem_we),
		.mem_addr(mem_addr),
		.mem_size(mem_size),
		.mem_wdata(mem_wdata),
		.mem_rdata(mem_rdata),
		.mem_ack(mem_ack),
		.src_req(src_req),
		.src_addr(src_addr),
		.src_data(src_data),
		.src_ack(src_ack),
		.inputs(inputs),
		.game_id(game),
		.game_gfx_bytes(game_gfx_bytes),
		.term2_adc(term2_adc),
		.term2_adc_sel(term2_adc_sel),
		.int1(int1),
		.snd_select(snd_select),
		.snd_trig(snd_trig),
		.snd_reset(snd_reset),
		.dbg_p1ctrl(dbg_p1ctrl),
		.dbg_bdir(dbg_bdir),
		.cmos_quiesce(cmos_quiesce),
		.nvram_ext_en(nvram_ext_en),
		.nvram_ext_wr(nvram_ext_wr),
		.nvram_ext_addr(nvram_ext_addr),
		.nvram_ext_wdata(nvram_ext_wdata),
		.nvram_ext_rdata(nvram_ext_rdata),
		.cmos_cpu_busy(cmos_cpu_busy),
		.cmos_cpu_write_pulse(cmos_cpu_write_pulse),
		.autoerase_enable(autoerase_enable),
		.erase_start(1'b0),
		.erase_row0(9'd0),
		.erase_lines(10'd0),
		.erase_line_valid(display_line_consumed_valid),
		.erase_line_row(display_line_consumed_row_phys),
		.erase_busy(legacy_erase_busy),
		.blit_busy(blit_busy),
		.dma_render_overflow(dbg_dma_render_overflow),
		.dma_render_level(dbg_dma_render_level),
		.dma_vram_order_stall(dbg_dma_vram_order_stall),
		.fb_busy(mem_fb_busy),
		.fb_snoop_we(fb_snoop_we),
		.fb_snoop_addr(fb_snoop_addr),
		.fb_snoop_data(fb_snoop_data),
		.dbg_dma_we(dbg_dma_we),
		.dbg_dma_addr(dbg_dma_addr),
		.dbg_dma_wdata(dbg_dma_wdata),
		.cpu_gfx_rd(cgfx_rd),
		.cpu_gfx_raddr(cgfx_addr),
		.cpu_gfx_rdata(cgfx_data),
		.cpu_gfx_rack(cgfx_ack),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack),
		.sdram_por(sdram_por),
		.ddram_addr(DDRAM_ADDR),
		.ddram_burstcnt(DDRAM_BURSTCNT),
		.ddram_rd(DDRAM_RD),
		.ddram_we(DDRAM_WE),
		.ddram_din(DDRAM_DIN),
		.ddram_be(DDRAM_BE),
		.ddram_busy(DDRAM_BUSY),
		.ddram_dout(DDRAM_DOUT),
		.ddram_dout_ready(DDRAM_DOUT_READY),
		.palv_we_a(palv_we_a),
		.palv_aa(palv_aa),
		.palv_awd(palv_awd),
		.palv_we_b(palv_we_b),
		.palv_ba(palv_ba),
		.palv_bwd(palv_bwd)
	);
	wire [11:0] pal_raddr;
	wire [15:0] pal_rdata;
	wire video_rst = core_rst_sys;
	wire video_phase_rst = video_rst | timing_start;
	yunit_video_top #(
		.H_ACT(H_ACT),
		.H_FP(H_FP),
		.H_SYNC(H_SYNC),
		.H_BP(H_BP),
		.V_ACT(V_ACT),
		.V_FP(V_FP),
		.V_SYNC(V_SYNC),
		.V_BP(V_BP),
		.DISP_ROW0(DISP_ROW0),
		.NCOL(H_ACT)
	) u_video(
		.clk(clk),
		.rst(video_phase_rst),
		.ce_pix(ce_pix),
		.bpp4(game_bpp4),
		.use_dynamic_display(1'b1),
		.display_contract_valid(display_contract_valid),
		.display_line_event(display_line_event),
		.display_line_valid(display_scanout_valid),
		.display_line_row_phys(display_scanout_row_phys),
		.display_line_col_word(display_scanout_col_word),
		.display_prefetch_valid(display_prefetch_valid),
		.display_prefetch_row_phys(display_prefetch_row_phys),
		.display_prefetch_col_word(display_prefetch_col_word),
		.snoop_we(video_snoop_we),
		.snoop_addr(video_snoop_addr),
		.snoop_data(video_snoop_data),
		.invalidate_valid(ae_line_invalidate),
		.invalidate_row(ae_active_dst_row),
		.pal_raddr(pal_raddr),
		.pal_rdata(pal_rdata),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack),
		.vid_r(vid_r),
		.vid_g(vid_g),
		.vid_b(vid_b),
		.hsync(hsync),
		.vsync(vsync),
		.hblank(hblank),
		.vblank(vblank),
		.de(de),
		.vblank_irq(vblank_irq)
	);
	yunit_palram #(.AW(13)) u_pal(
		.clk(clk),
		.rst(core_rst),
		.we_a(palv_we_a),
		.aa(palv_aa),
		.awd(palv_awd),
		.we_b(palv_we_b),
		.ba(palv_ba),
		.bwd(palv_bwd),
		.raddr({1'b0, pal_raddr}),
		.rdata(pal_rdata)
	);
	wire [24:0] sd_addr;
	wire [15:0] sd_din;
	wire [15:0] sd_dout;
	wire [1:0] sd_be;
	wire sd_rd;
	wire sd_wr;
	wire sd_ack;
	wire iol_ack;
	localparam signed [31:0] IOL_AW = 9;
	localparam signed [31:0] IOL_HWM = 256;
	reg [42:0] iol_fifo [0:511];
	reg [IOL_AW:0] iol_wp;
	reg [IOL_AW:0] iol_rp;
	wire [IOL_AW:0] iol_occ = iol_wp - iol_rp;
	wire iol_full = iol_occ == 512;
	wire iol_empty = iol_wp == iol_rp;
	reg iol_hold;
	reg unp_owner;
	assign download_path_busy = ~iol_empty | iol_hold;
	reg [24:0] iol_addr_r;
	reg [15:0] iol_din_r;
	reg [1:0] iol_be_r;
	reg [31:0] iol_drop_cnt;
	reg [31:0] iol_wr_cnt;
	always @(posedge clk)
		if (sdram_por) begin
			iol_wp <= 1'sb0;
			iol_rp <= 1'sb0;
			iol_hold <= 1'b0;
			iol_drop_cnt <= 1'sb0;
			iol_wr_cnt <= 1'sb0;
		end
		else begin
			if (ioctl_wr && !iol_full) begin
				iol_fifo[iol_wp[8:0]] <= {ioctl_addr, ioctl_dout, ioctl_be};
				iol_wp <= iol_wp + 1'b1;
				iol_wr_cnt <= iol_wr_cnt + 1'b1;
			end
			else if (ioctl_wr && iol_full)
				iol_drop_cnt <= iol_drop_cnt + 1'b1;
			if (!unp_owner) begin
				if (iol_hold && iol_ack)
					iol_hold <= 1'b0;
				if ((!iol_hold || (iol_hold && iol_ack)) && !iol_empty) begin
					{iol_addr_r, iol_din_r, iol_be_r} <= iol_fifo[iol_rp[8:0]];
					iol_hold <= 1'b1;
					iol_rp <= iol_rp + 1'b1;
				end
			end
		end
	assign ioctl_wait = iol_occ >= IOL_HWM[IOL_AW:0];
	wire unp_rd;
	wire unp_wr;
	wire unp_ack;
	wire [24:0] unp_addr;
	wire [15:0] unp_din;
	wire [15:0] unp_dout;
	wire b_iol_rd = (unp_owner ? unp_rd : 1'b0);
	wire b_iol_wr = (unp_owner ? unp_wr : iol_hold);
	wire [24:0] b_iol_addr = (unp_owner ? unp_addr : iol_addr_r);
	wire [15:0] b_iol_din = (unp_owner ? unp_din : iol_din_r);
	wire [1:0] b_iol_be = (unp_owner ? 2'b11 : iol_be_r);
	wire [15:0] iol_dout;
	assign unp_dout = iol_dout;
	assign unp_ack = (iol_ack & unp_owner) & (unp_rd | unp_wr);
	wire [24:0] arb_vsd_addr;
	wire [15:0] arb_vsd_din;
	wire [15:0] arb_vsd_dout;
	wire [1:0] arb_vsd_be;
	wire arb_vsd_rd;
	wire arb_vsd_wr;
	wire arb_vsd_ack;
	(* keep *) wire vram_word_arb_error;
	yunit_vram_word_arb #(.ADDR_WIDTH(25)) u_vram_word_arb(
		.clk(clk),
		.rst(sdram_por),
		.normal_addr(25'd0),
		.normal_din(16'd0),
		.normal_be(2'd0),
		.normal_rd(1'b0),
		.normal_wr(1'b0),
		.normal_dout(vsd_dout),
		.normal_ack(vsd_ack),
		.shift_valid(sr_mem_valid),
		.shift_write(sr_mem_write),
		.shift_addr(sr_mem_addr),
		.shift_wdata(sr_mem_wdata),
		.shift_rdata(sr_mem_rdata),
		.shift_ready(sr_mem_ready),
		.shared_addr(arb_vsd_addr),
		.shared_din(arb_vsd_din),
		.shared_be(arb_vsd_be),
		.shared_rd(arb_vsd_rd),
		.shared_wr(arb_vsd_wr),
		.shared_dout(arb_vsd_dout),
		.shared_ack(arb_vsd_ack),
		.shift_owned(),
		.protocol_error(vram_word_arb_error)
	);
	yunit_sdram_arb #(
		.SD_AW(25),
		.GFXW_BASE(GFXW_BASE),
		.ROMW_BASE(ROMW_BASE),
		.VRAMW_BASE(VRAMW_BASE),
		.SOUNDW_BASE(SOUNDW_BASE),
		.GFX_BYTES(GFX_BYTES)
	) u_arb(
		.clk(clk),
		.rst(sdram_por),
		.vsd_addr(arb_vsd_addr),
		.vsd_din(arb_vsd_din),
		.vsd_be(arb_vsd_be),
		.vsd_rd(arb_vsd_rd),
		.vsd_wr(arb_vsd_wr),
		.vsd_dout(arb_vsd_dout),
		.vsd_ack(arb_vsd_ack),
		.cgfx_rd(cgfx_rd),
		.cgfx_addr(cgfx_addr),
		.cgfx_data(cgfx_data),
		.cgfx_ack(cgfx_ack),
		.src_rd(1'b0),
		.src_addr(24'd0),
		.src_data(),
		.src_ack(),
		.snd_rd(sndrom_rd),
		.snd_addr(sndrom_addr),
		.snd_data(sndrom_data),
		.snd_ack(sndrom_ack),
		.iol_rd(b_iol_rd),
		.iol_wr(b_iol_wr),
		.iol_addr(b_iol_addr),
		.iol_din(b_iol_din),
		.iol_be(b_iol_be),
		.iol_dout(iol_dout),
		.iol_ack(iol_ack),
		.sd_addr(sd_addr),
		.sd_din(sd_din),
		.sd_be(sd_be),
		.sd_rd(sd_rd),
		.sd_wr(sd_wr),
		.sd_dout(sd_dout),
		.sd_ack(sd_ack)
	);
	reg sound_dl_q;
	reg dl_seen;
	reg unp_pending;
	reg unp_start;
	wire unp_fsm_done;
	reg unp_done_q;
	always @(posedge clk) begin
		sound_dl_q <= sound_download;
		unp_start <= 1'b0;
		unp_done_q <= unp_fsm_done;
		if (sdram_por) begin
			dl_seen <= 1'b0;
			unp_pending <= 1'b0;
			unp_owner <= 1'b0;
			unp_done_q <= 1'b0;
		end
		else begin
			if (gfx_download)
				dl_seen <= 1'b1;
			if ((dl_seen && sound_dl_q) && !sound_download)
				unp_pending <= 1'b1;
			else if ((((unp_pending && !ioctl_download) && iol_empty) && !iol_hold) && !unp_owner) begin
				unp_pending <= 1'b0;
				unp_owner <= 1'b1;
				unp_start <= 1'b1;
			end
			if ((unp_owner && unp_fsm_done) && !unp_done_q)
				unp_owner <= 1'b0;
		end
	end
	yunit_gfx_unpack #(
		.SD_AW(25),
		.SCRATCH_WBASE(SCRATCH_WBASE),
		.GFXW_BASE(GFXW_BASE),
		.PLANE_WORDS(PLANE_WORDS)
	) u_unpack(
		.clk(clk),
		.rst(sdram_por),
		.start(unp_start),
		.plane_words(game_plane_words),
		.bpp4(game_bpp4),
		.busy(),
		.done(unp_fsm_done),
		.unp_rd(unp_rd),
		.unp_wr(unp_wr),
		.unp_addr(unp_addr),
		.unp_din(unp_din),
		.unp_dout(unp_dout),
		.unp_ack(unp_ack)
	);
	assign unp_done = ~dl_seen | unp_fsm_done;
	wire scan_brd_req;
	wire [24:0] scan_brd_addr;
	wire [9:0] scan_brd_len;
	wire [15:0] scan_brd_dout;
	wire scan_brd_dvalid;
	wire scan_brd_done;
	wire erase_brd_req;
	wire [24:0] erase_brd_addr;
	wire [9:0] erase_brd_len;
	wire [15:0] erase_brd_dout;
	wire erase_brd_dvalid;
	wire erase_brd_done;
	wire erase_bwr_req;
	wire [24:0] erase_bwr_addr;
	wire [9:0] erase_bwr_len;
	wire [15:0] erase_bwr_din;
	wire [1:0] erase_bwr_wtbt;
	wire erase_bwr_valid;
	wire erase_bwr_ready;
	wire erase_bwr_done;
	wire brd_req;
	wire [24:0] brd_addr;
	wire [9:0] brd_len;
	wire [15:0] brd_dout;
	wire brd_dvalid;
	wire brd_done;
	wire bwr_req;
	wire [24:0] bwr_addr;
	wire [9:0] bwr_len;
	wire [15:0] bwr_din;
	wire [1:0] bwr_wtbt;
	wire bwr_valid;
	wire bwr_ready;
	wire bwr_done;
	wire ae_job_valid;
	wire ae_job_ready;
	wire ae_job_done;
	wire ae_job_inflight;
	wire [8:0] ae_job_src_row;
	wire [8:0] ae_job_dst_row;
	wire [1:0] ae_pending_count;
	wire ae_overflow_pulse;
	(* keep *) wire ae_overflow_sticky;
	(* keep *) wire ae_backend_error;
	(* keep *) wire burst_arb_error;
	wire ae_job_launch = ae_job_valid && ae_job_ready;
	wire row_cache_invalidate = (ae_job_launch || ae_job_done) || sr_mem_write_commit;
	wire [8:0] row_cache_invalidate_row = (sr_mem_write_commit ? sr_mem_addr[17:9] : (ae_job_done ? ae_active_dst_row : ae_job_dst_row));
	wire beam_erase_busy;
	assign ae_line_invalidate = ae_job_done;
	always @(posedge clk)
		if (sdram_por)
			ae_active_dst_row <= 9'd0;
		else if (ae_job_launch)
			ae_active_dst_row <= ae_job_dst_row;
	assign ae_job_valid = 1'b0;
	assign ae_job_ready = 1'b1;
	assign ae_job_done = 1'b0;
	assign ae_job_src_row = 9'd0;
	assign ae_job_dst_row = 9'd0;
	assign ae_job_inflight = 1'b0;
	assign ae_pending_count = 2'd0;
	assign ae_overflow_pulse = 1'b0;
	assign ae_overflow_sticky = 1'b0;
	assign ae_backend_error = 1'b0;
	assign erase_brd_req = 1'b0;
	assign erase_brd_addr = 25'd0;
	assign erase_brd_len = 10'd0;
	assign erase_bwr_req = 1'b0;
	assign erase_bwr_addr = 25'd0;
	assign erase_bwr_len = 10'd0;
	assign erase_bwr_din = 16'd0;
	assign erase_bwr_wtbt = 2'd0;
	assign erase_bwr_valid = 1'b0;
	assign beam_erase_busy = 1'b0;
	assign erase_busy = legacy_erase_busy | beam_erase_busy;
	yunit_src_cache #(.GFXW_BASE(GFXW_BASE[23:0])) u_srccache(
		.clk(clk),
		.rst(core_rst),
		.src_req(src_req),
		.src_addr(src_addr),
		.src_data(src_data),
		.src_ack(src_ack),
		.brd_req(scan_brd_req),
		.brd_addr(scan_brd_addr),
		.brd_len(scan_brd_len),
		.brd_dout(scan_brd_dout),
		.brd_dvalid(scan_brd_dvalid),
		.brd_done(scan_brd_done)
	);
	yunit_sdram_burst_arb u_burst_arb(
		.clk(clk),
		.rst(sdram_por),
		.scan_brd_req(scan_brd_req),
		.scan_brd_addr(scan_brd_addr),
		.scan_brd_len(scan_brd_len),
		.scan_brd_dout(scan_brd_dout),
		.scan_brd_dvalid(scan_brd_dvalid),
		.scan_brd_done(scan_brd_done),
		.erase_brd_req(erase_brd_req),
		.erase_brd_addr(erase_brd_addr),
		.erase_brd_len(erase_brd_len),
		.erase_brd_dout(erase_brd_dout),
		.erase_brd_dvalid(erase_brd_dvalid),
		.erase_brd_done(erase_brd_done),
		.erase_bwr_req(erase_bwr_req),
		.erase_bwr_addr(erase_bwr_addr),
		.erase_bwr_len(erase_bwr_len),
		.erase_bwr_din(erase_bwr_din),
		.erase_bwr_wtbt(erase_bwr_wtbt),
		.erase_bwr_valid(erase_bwr_valid),
		.erase_bwr_ready(erase_bwr_ready),
		.erase_bwr_done(erase_bwr_done),
		.brd_req(brd_req),
		.brd_addr(brd_addr),
		.brd_len(brd_len),
		.brd_dout(brd_dout),
		.brd_dvalid(brd_dvalid),
		.brd_done(brd_done),
		.bwr_req(bwr_req),
		.bwr_addr(bwr_addr),
		.bwr_len(bwr_len),
		.bwr_din(bwr_din),
		.bwr_wtbt(bwr_wtbt),
		.bwr_valid(bwr_valid),
		.bwr_ready(bwr_ready),
		.bwr_done(bwr_done),
		.scan_owned(),
		.erase_owned(),
		.request_bubble(),
		.erase_waiting(),
		.protocol_error(burst_arb_error)
	);
	wire [24:0] ctl_addr;
	wire [15:0] ctl_din;
	wire [15:0] ctl_dout;
	wire [1:0] ctl_wtbt;
	wire ctl_rd;
	wire ctl_we;
	wire ctl_ready;
	yunit_sdram_adapter u_sdadapt(
		.clk(clk),
		.rst(sdram_por),
		.sd_addr(sd_addr),
		.sd_din(sd_din),
		.sd_be(sd_be),
		.sd_rd(sd_rd),
		.sd_wr(sd_wr),
		.sd_dout(sd_dout),
		.sd_ack(sd_ack),
		.sdram_ready(sdram_ready),
		.ctl_addr(ctl_addr),
		.ctl_din(ctl_din),
		.ctl_wtbt(ctl_wtbt),
		.ctl_rd(ctl_rd),
		.ctl_we(ctl_we),
		.ctl_dout(ctl_dout),
		.ctl_ready(ctl_ready)
	);
	sdram_stock u_sdram(
		.init(sdram_por),
		.clk(clk),
		.addr(ctl_addr),
		.din(ctl_din),
		.wtbt(ctl_wtbt),
		.we(ctl_we),
		.rd(ctl_rd),
		.dout(ctl_dout),
		.ready(ctl_ready),
		.brd_req(brd_req),
		.brd_addr(brd_addr),
		.brd_len(brd_len),
		.brd_dout(brd_dout),
		.brd_dvalid(brd_dvalid),
		.brd_done(brd_done),
		.bwr_req(bwr_req),
		.bwr_addr(bwr_addr),
		.bwr_len(bwr_len),
		.bwr_din(bwr_din),
		.bwr_wtbt(bwr_wtbt),
		.bwr_valid(bwr_valid),
		.bwr_ready(bwr_ready),
		.bwr_done(bwr_done),
		.SDRAM_DQ(SDRAM_DQ),
		.SDRAM_A(SDRAM_A),
		.SDRAM_BA(SDRAM_BA),
		.SDRAM_DQML(SDRAM_DQML),
		.SDRAM_DQMH(SDRAM_DQMH),
		.SDRAM_nCS(SDRAM_nCS),
		.SDRAM_nRAS(SDRAM_nRAS),
		.SDRAM_nCAS(SDRAM_nCAS),
		.SDRAM_nWE(SDRAM_nWE),
		.SDRAM_CKE(SDRAM_CKE)
	);
	wire [7:0] sel_sync;
	wire strig_snd;
	wire srst_snd;
	yunit_sound_cdc u_sound_cdc(
		.clk_sys(clk),
		.clk_snd(clk_snd),
		.rst_pon(rst_pon),
		.snd_select(snd_select),
		.snd_trig(snd_trig),
		.snd_reset(snd_reset),
		.sel_snd(sel_sync),
		.trig_snd(strig_snd),
		.reset_snd(srst_snd)
	);
	wire [7:0] pia_audio;
	wire [15:0] speech_out;
	wire signed [15:0] ym_l;
	wire signed [15:0] ym_r;
	wire [31:0] snd_dbg;
	wire signed [15:0] cvsd_audio_l;
	wire signed [15:0] cvsd_audio_r;
	wire signed [15:0] adpcm_audio_l;
	wire signed [15:0] adpcm_audio_r;
	wire [20:0] adpcm_ext_addr;
	localparam [1:0] yunit_pkg_YS_CVSD_LARGE = 2'd1;
	localparam [3:0] yunit_pkg_YG_YUNITTST = 4'd8;
	localparam [1:0] yunit_pkg_YS_ADPCM = 2'd2;
	localparam [1:0] yunit_pkg_YS_CVSD_SMALL = 2'd0;
	function automatic [1:0] yunit_pkg_yunit_sound_type;
		input reg [3:0] game;
		if (((game == yunit_pkg_YG_MK) || (game == yunit_pkg_YG_TERM2)) || (game == yunit_pkg_YG_TOTCARN))
			yunit_pkg_yunit_sound_type = yunit_pkg_YS_ADPCM;
		else if (((game == yunit_pkg_YG_HIIMPACT) || (game == yunit_pkg_YG_SHIMPACT)) || (game == yunit_pkg_YG_YUNITTST))
			yunit_pkg_yunit_sound_type = yunit_pkg_YS_CVSD_LARGE;
		else
			yunit_pkg_yunit_sound_type = yunit_pkg_YS_CVSD_SMALL;
	endfunction
	wire use_ext_cvsd = yunit_pkg_yunit_sound_type(game) == yunit_pkg_YS_CVSD_LARGE;
	wire use_adpcm = yunit_pkg_yunit_sound_type(game) == yunit_pkg_YS_ADPCM;
	wire use_ext_sound = use_ext_cvsd | use_adpcm;
	wire [20:0] cvsd_ext_addr;
	reg [20:0] sndrom_cached_addr;
	reg [7:0] cvsd_ext_data;
	reg sndrom_valid;
	wire [20:0] sound_ext_addr = (use_adpcm ? adpcm_ext_addr : cvsd_ext_addr);
	wire sound_ext_ok = sndrom_valid && (sndrom_cached_addr == sound_ext_addr);
	always @(posedge clk)
		if (sdram_por || !use_ext_sound) begin
			sndrom_rd <= 1'b0;
			sndrom_addr <= 21'd0;
			sndrom_cached_addr <= 21'd0;
			sndrom_valid <= 1'b0;
			cvsd_ext_data <= 8'h00;
		end
		else if (sndrom_rd) begin
			if (sndrom_ack) begin
				sndrom_rd <= 1'b0;
				sndrom_cached_addr <= sndrom_addr;
				sndrom_valid <= 1'b1;
				cvsd_ext_data <= sndrom_data;
			end
		end
		else if (!sndrom_valid || (sound_ext_addr != sndrom_cached_addr)) begin
			sndrom_addr <= sound_ext_addr;
			sndrom_rd <= 1'b1;
		end
	williams_cvsd_board u_board(
		.clock_12(clk_snd),
		.reset(srst_snd | use_adpcm),
		.reset_pon(rst_pon),
		.sound_select(sel_sync),
		.sound_trig(strig_snd),
		.game_id(game),
		.pia_audio(pia_audio),
		.speech_out(speech_out),
		.ym2151_left(ym_l),
		.ym2151_right(ym_r),
		.dbg_out(snd_dbg),
		.snd_dl_clk(clk),
		.snd_dl_addr(snd_dl_addr),
		.snd_dl_data(snd_dl_data),
		.snd_dl_we(snd_dl_wr),
		.use_ext_rom(use_ext_cvsd),
		.ext_rom_addr(cvsd_ext_addr),
		.ext_rom_data(cvsd_ext_data),
		.ext_rom_ok(sound_ext_ok)
	);
	yunit_adpcm_board u_adpcm_board(
		.clk(clk_snd),
		.reset_pon(rst_pon),
		.reset(srst_snd | ~use_adpcm),
		.sound_select(sel_sync),
		.sound_trig(strig_snd),
		.game(game),
		.ext_rom_addr(adpcm_ext_addr),
		.ext_rom_data(cvsd_ext_data),
		.ext_rom_ok(sound_ext_ok),
		.snd_dl_clk(clk),
		.snd_dl_addr(snd_dl_addr),
		.snd_dl_data(snd_dl_data),
		.snd_dl_we(snd_dl_wr),
		.audio_l(adpcm_audio_l),
		.audio_r(adpcm_audio_r),
		.irq_state(adpcm_irq)
	);
	yunit_audio_mix u_audio_mix(
		.clk(clk_snd),
		.rst(rst_pon),
		.ym_l(ym_l),
		.ym_r(ym_r),
		.speech_u(speech_out),
		.pia_u(pia_audio),
		.audio_l(cvsd_audio_l),
		.audio_r(cvsd_audio_r)
	);
	always @(*) begin
		if (_sv2v_0)
			;
		audio_l = (use_adpcm ? adpcm_audio_l : cvsd_audio_l);
		audio_r = (use_adpcm ? adpcm_audio_r : cvsd_audio_r);
	end
	assign dbg_core_rst = core_rst;
	assign dbg_sdram_ready = sdram_ready;
	assign dbg_unp_done = unp_done;
	assign dbg_cpu_req = cpu_req;
	assign dbg_mem_ack = mem_ack;
	assign dbg_int1 = int1;
	assign dbg_vblank_irq = vblank_irq;
	assign dbg_src_data = src_data;
	assign dbg_src_ack = src_ack;
	assign dbg_scan_data = scan_data;
	assign dbg_scan_ack = scan_ack;
	assign dbg_cpu_ce = cpu_ce;
	assign dbg_iol_drop = iol_drop_cnt;
	assign dbg_iol_wrs = iol_wr_cnt;
	assign dbg_disp_flips = 32'd0;
	assign dbg_disp_rows = 32'd0;
	assign dbg_cgfx_grants = 16'd0;
	assign dbg_snd_grants = 16'd0;
	assign dbg_cgfx_maxwait = 32'd0;
	assign dbg_snd_miss = 16'd0;
	assign dbg_snd_busy16 = 16'd0;
	assign dbg_cvsd_moves = 16'd0;
	assign dbg_adpcm_moves = 16'd0;
	assign dbg_blank_pix = 16'd0;
	assign dbg_cpu_pc_moves = 32'd0;
	assign dbg_snd_acks = 32'd0;
	assign dbg_snd_first_words = 32'd0;
	assign dbg_snd_region_seen = 1'b0;
	assign dbg_snd_board_rst = 1'b0;
	assign dbg_restart_cnt = 16'd0;
	reg [1:0] rd_cnt;
	reg ack_q;
	reg d_started;
	reg [31:0] d_prevpc;
	always @(posedge clk)
		if (cpu_ce || core_rst_sys) begin
			if (core_rst_sys) begin
				dbg_derailed <= 1'b0;
				rd_cnt <= 2'd0;
				ack_q <= 1'b0;
				d_started <= 1'b0;
				d_prevpc <= 32'hffffffff;
				dbg_culprit_pc <= 32'hdeadbeef;
				dbg_culprit_instr <= 16'h0000;
				dbg_derail_pc <= 32'hdeadbeef;
			end
			else begin
				ack_q <= cpu_ack;
				if (((cpu_ack && !ack_q) && !cpu_we) && (rd_cnt == 2'd0)) begin
					dbg_culprit_pc <= cpu_rdata;
					rd_cnt <= 2'd1;
				end
				if (pc_dbg !== d_prevpc) begin
					if (pc_dbg == 32'hffe0f5c0) begin
						dbg_derail_pc <= d_prevpc;
						dbg_culprit_instr <= dbg_culprit_instr + 16'd1;
					end
					d_prevpc <= pc_dbg;
					if (pc_dbg[31:23] == 9'h1ff)
						d_started <= 1'b1;
				end
			end
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module smashtv_cabinet_inputs (
	joy0,
	joy1,
	dsw_raw,
	inputs
);
	reg _sv2v_0;
	input wire [15:0] joy0;
	input wire [15:0] joy1;
	input wire [15:0] dsw_raw;
	output reg [63:0] inputs;
	reg [15:0] in0;
	reg [15:0] in1;
	reg [15:0] dsw;
	always @(*) begin
		if (_sv2v_0)
			;
		in0 = 16'hffff;
		in0[0] = ~joy0[3];
		in0[1] = ~joy0[2];
		in0[2] = ~joy0[1];
		in0[3] = ~joy0[0];
		in0[4] = ~joy0[4];
		in0[5] = ~joy0[5];
		in0[6] = ~joy0[6];
		in0[7] = ~joy0[7];
		in0[8] = ~joy1[3];
		in0[9] = ~joy1[2];
		in0[10] = ~joy1[1];
		in0[11] = ~joy1[0];
		in0[12] = ~joy1[4];
		in0[13] = ~joy1[5];
		in0[14] = ~joy1[6];
		in0[15] = ~joy1[7];
		in1 = 16'hffff;
		in1[0] = ~joy0[9];
		in1[1] = ~joy1[9];
		in1[2] = ~joy0[8];
		in1[5] = ~joy1[8];
		dsw = dsw_raw | 16'h4000;
		inputs = {dsw, 16'hffff, in1, in0};
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module smashtv_legacy_download_mapper (
	clk,
	ioctl_download,
	ioctl_wr,
	ioctl_index,
	ioctl_addr,
	ioctl_dout,
	rom_download,
	mapped_wr,
	mapped_addr,
	mapped_dout,
	mapped_be,
	snd_wr,
	snd_addr,
	snd_data
);
	reg _sv2v_0;
	parameter [24:0] SCRATCH_WBASE = 25'h0120000;
	parameter [24:0] ROMW_BASE = 25'h00c0000;
	input wire clk;
	input wire ioctl_download;
	input wire ioctl_wr;
	input wire [7:0] ioctl_index;
	input wire [24:0] ioctl_addr;
	input wire [7:0] ioctl_dout;
	output reg rom_download;
	output reg mapped_wr;
	output reg [24:0] mapped_addr;
	output reg [15:0] mapped_dout;
	output reg [1:0] mapped_be;
	output reg snd_wr;
	output reg [17:0] snd_addr;
	output reg [7:0] snd_data;
	localparam [24:0] DL_ROM_BASE = 25'h0120000;
	localparam [24:0] DL_ROMHI_BASE = 25'h0140000;
	localparam [24:0] DL_SND_BASE = 25'h0160000;
	localparam [24:0] DL_END = 25'h0190000;
	reg [7:0] pair_lo;
	always @(*) begin
		if (_sv2v_0)
			;
		rom_download = ioctl_download && (ioctl_index == 8'd0);
	end
	always @(posedge clk) begin
		mapped_wr <= 1'b0;
		snd_wr <= 1'b0;
		if (rom_download && ioctl_wr) begin
			if (ioctl_addr < DL_ROM_BASE) begin
				if (!ioctl_addr[0])
					pair_lo <= ioctl_dout;
				else begin
					mapped_addr <= SCRATCH_WBASE + {1'b0, ioctl_addr[24:1]};
					mapped_dout <= {ioctl_dout, pair_lo};
					mapped_be <= 2'b11;
					mapped_wr <= 1'b1;
				end
			end
			else if (ioctl_addr < DL_ROMHI_BASE) begin
				mapped_addr <= ROMW_BASE + (ioctl_addr - DL_ROM_BASE);
				mapped_dout <= {8'h00, ioctl_dout};
				mapped_be <= 2'b01;
				mapped_wr <= 1'b1;
			end
			else if (ioctl_addr < DL_SND_BASE) begin
				mapped_addr <= ROMW_BASE + (ioctl_addr - DL_ROMHI_BASE);
				mapped_dout <= {ioctl_dout, 8'h00};
				mapped_be <= 2'b10;
				mapped_wr <= 1'b1;
			end
			else if (ioctl_addr < DL_END) begin
				snd_addr <= ioctl_addr - DL_SND_BASE;
				snd_data <= ioctl_dout;
				snd_wr <= 1'b1;
			end
		end
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_mem_smash_firefix (
	clk,
	rst,
	mem_req,
	mem_we,
	mem_addr,
	mem_size,
	mem_wdata,
	mem_rdata,
	mem_ack,
	fb_we,
	fb_addr,
	fb_wdata,
	dma_palette,
	inputs,
	snd_select,
	snd_trig,
	snd_reset,
	dbg_p1ctrl,
	dbg_bdir,
	erase_start,
	erase_row0,
	erase_lines,
	erase_busy,
	gfx_rd,
	gfx_raddr,
	gfx_rdata,
	gfx_rack,
	fb_ack,
	fb_busy,
	fb_flush,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	sdram_por,
	ddram_addr,
	ddram_burstcnt,
	ddram_rd,
	ddram_we,
	ddram_din,
	ddram_be,
	ddram_busy,
	ddram_dout,
	ddram_dout_ready,
	palv_we_a,
	palv_aa,
	palv_awd,
	palv_we_b,
	palv_ba,
	palv_bwd
);
	reg _sv2v_0;
	parameter signed [31:0] ROM_WORDS = 32'h00020000;
	parameter signed [31:0] RAM_WORDS = 32'h00010000;
	parameter signed [31:0] VRAM_WORDS = 32'h00040000;
	parameter signed [31:0] PAL_WORDS = 32'h00002000;
	parameter signed [31:0] CMOS_WORDS = 32'h00004000;
	parameter signed [31:0] GFX_PIXELS = 32'h00180000;
	parameter ROM_HEX = "smashtv_maindata.hex";
	parameter GFX_HEX = "build/smashtv_gfx.hex";
	input wire clk;
	input wire rst;
	input wire mem_req;
	input wire mem_we;
	input wire [31:0] mem_addr;
	input wire [5:0] mem_size;
	input wire [31:0] mem_wdata;
	output reg [31:0] mem_rdata;
	output reg mem_ack;
	input wire fb_we;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	input wire [17:0] fb_addr;
	input wire [15:0] fb_wdata;
	input wire [15:0] dma_palette;
	input wire [63:0] inputs;
	output reg [7:0] snd_select;
	output reg snd_trig;
	output reg snd_reset;
	output reg [31:0] dbg_p1ctrl;
	output reg [31:0] dbg_bdir;
	input wire erase_start;
	input wire [8:0] erase_row0;
	input wire [9:0] erase_lines;
	output wire erase_busy;
	output reg gfx_rd;
	output wire [23:0] gfx_raddr;
	input wire [15:0] gfx_rdata;
	input wire gfx_rack;
	output wire fb_ack;
	output wire fb_busy;
	input wire fb_flush;
	input wire scan_req;
	input wire [17:0] scan_addr;
	output wire [15:0] scan_data;
	output wire scan_ack;
	input wire sdram_por;
	output wire [28:0] ddram_addr;
	output wire [7:0] ddram_burstcnt;
	output wire ddram_rd;
	output wire ddram_we;
	output wire [63:0] ddram_din;
	output wire [7:0] ddram_be;
	input wire ddram_busy;
	input wire [63:0] ddram_dout;
	input wire ddram_dout_ready;
	output reg palv_we_a;
	output reg [12:0] palv_aa;
	output reg [15:0] palv_awd;
	output reg palv_we_b;
	output reg [12:0] palv_ba;
	output reg [15:0] palv_bwd;
	localparam [3:0] R_NONE = 4'd0;
	localparam [3:0] R_VRAM = 4'd1;
	localparam [3:0] R_RAM = 4'd2;
	localparam [3:0] R_CMOS = 4'd3;
	localparam [3:0] R_PAL = 4'd4;
	localparam [3:0] R_DMA = 4'd5;
	localparam [3:0] R_INPUT = 4'd6;
	localparam [3:0] R_PROT = 4'd7;
	localparam [3:0] R_SOUND = 4'd8;
	localparam [3:0] R_CTRL = 4'd9;
	localparam [3:0] R_GFX = 4'd10;
	localparam [3:0] R_ROM = 4'd11;
	localparam [31:0] yunit_pkg_YMAP_RAM_BASE = 32'h01000000;
	function automatic [27:0] sv2v_cast_28;
		input reg [27:0] inp;
		sv2v_cast_28 = inp;
	endfunction
	localparam [27:0] WB_RAM = sv2v_cast_28(yunit_pkg_YMAP_RAM_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_MAINDATA_BASE = 32'hff800000;
	localparam [27:0] WB_ROM = sv2v_cast_28(yunit_pkg_YMAP_MAINDATA_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_VRAM_BASE = 32'h00000000;
	localparam [27:0] WB_VRAM = sv2v_cast_28(yunit_pkg_YMAP_VRAM_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_PAL_BASE = 32'h01800000;
	localparam [27:0] WB_PAL = sv2v_cast_28(yunit_pkg_YMAP_PAL_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_CMOS_BASE = 32'h01400000;
	localparam [27:0] WB_CMOS = sv2v_cast_28(yunit_pkg_YMAP_CMOS_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_INPUT_BASE = 32'h01c00000;
	localparam [27:0] WB_INPUT = sv2v_cast_28(yunit_pkg_YMAP_INPUT_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_GFX_BASE = 32'h02000000;
	localparam [27:0] WB_GFX = sv2v_cast_28(yunit_pkg_YMAP_GFX_BASE >> 4);
	localparam [27:0] ROM_PROG_OFF = 28'h0060000;
	(* ramstyle = "no_rw_check" *) reg [15:0] ram [0:RAM_WORDS - 1];
	(* ramstyle = "no_rw_check" *) reg [15:0] pal [0:PAL_WORDS - 1];
	reg videobank = 1'b0;
	reg [1:0] cmos_page = 2'd0;
	reg autoerase = 1'b0;
	reg er_run = 1'b0;
	wire [8:0] er_row;
	wire [8:0] er_x;
	wire [9:0] er_left;
	(* ramstyle = "no_rw_check" *) reg [15:0] nvram [0:CMOS_WORDS - 1];
	localparam [3:0] M_IDLE = 4'd0;
	localparam [3:0] M_ACK = 4'd1;
	localparam [3:0] M_GFX = 4'd2;
	localparam [3:0] M_HR1 = 4'd3;
	localparam [3:0] M_HR2 = 4'd4;
	localparam [3:0] M_HFIN = 4'd5;
	localparam [3:0] M_HW2 = 4'd6;
	localparam [3:0] M_VRD = 4'd7;
	localparam [3:0] M_VWR0 = 4'd8;
	localparam [3:0] M_VWR1 = 4'd9;
	localparam [3:0] M_VWW0 = 4'd10;
	localparam [3:0] M_VWW1 = 4'd11;
	localparam [3:0] M_VSD = 4'd12;
	localparam [3:0] M_HFIN2 = 4'd13;
	localparam [3:0] M_RDLY = 4'd14;
	localparam [3:0] M_SBH = 4'd15;
	localparam [4:0] M_EXD = 5'd16;
	reg [4:0] state;
	function automatic signed [23:0] sv2v_cast_24_signed;
		input reg signed [23:0] inp;
		sv2v_cast_24_signed = inp;
	endfunction
	localparam [23:0] SDRAM_ROMB = sv2v_cast_24_signed(GFX_PIXELS);
	reg [23:0] gfx_base;
	reg [1:0] gfx_cnt;
	reg [1:0] gfx_need;
	reg gfx_isrom;
	reg [15:0] gw0;
	reg [15:0] gw1;
	reg [23:0] gfx_raddr_q;
	reg [3:0] boff_r;
	reg [47:0] rmask_r;
	localparam signed [31:0] SB_N = 8;
	reg [15:0] sb_q [0:7];
	reg [22:0] sb_base;
	reg [3:0] sb_fill;
	reg sb_vld;
	reg pf_run;
	reg pf_busy;
	reg [31:0] a_q;
	reg we_q;
	reg [31:0] wd_q;
	reg [5:0] sz_q;
	wire [27:0] widx = a_q[31:4];
	wire [3:0] boff = a_q[3:0];
	wire [5:0] sz = sz_q;
	reg [3:0] region;
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		casez (a_q[31:20])
			12'h000, 12'h001: region = R_VRAM;
			12'h010: region = R_RAM;
			12'h014: region = R_CMOS;
			12'h018: region = R_PAL;
			12'h01a: region = ((a_q[18:8] == 11'h000) && (a_q[7:4] <= 4'd9) ? R_DMA : R_NONE);
			12'h01c: region = (a_q[7:4] >= 4'd6 ? R_PROT : R_INPUT);
			12'h01e: region = R_SOUND;
			12'h01f: region = R_CTRL;
			12'h020, 12'h021, 12'h022, 12'h023, 12'h024, 12'h025, 12'h026, 12'h027, 12'h028, 12'h029, 12'h02a, 12'h02b, 12'h02c, 12'h02d, 12'h02e, 12'h02f, 12'h030, 12'h031, 12'h032, 12'h033, 12'h034, 12'h035, 12'h036, 12'h037, 12'h038, 12'h039, 12'h03a, 12'h03b, 12'h03c, 12'h03d, 12'h03e, 12'h03f, 12'h040, 12'h041, 12'h042, 12'h043, 12'h044, 12'h045, 12'h046, 12'h047, 12'h048, 12'h049, 12'h04a, 12'h04b, 12'h04c, 12'h04d, 12'h04e, 12'h04f, 12'h050, 12'h051, 12'h052, 12'h053, 12'h054, 12'h055, 12'h056, 12'h057, 12'h058, 12'h059, 12'h05a, 12'h05b, 12'h05c, 12'h05d, 12'h05e, 12'h05f: region = R_GFX;
			12'hff8, 12'hff9, 12'hffa, 12'hffb, 12'hffc, 12'hffd, 12'hffe, 12'hfff: region = R_ROM;
			default: region = R_NONE;
		endcase
	end
	wire is_hwvram = region == R_VRAM;
	localparam [27:0] ROMW = ROM_WORDS[27:0];
	localparam [27:0] RAMW = RAM_WORDS[27:0];
	localparam [27:0] VRAMW = VRAM_WORDS[27:0];
	localparam [27:0] PALW = PAL_WORDS[27:0];
	localparam [27:0] CMOSW = CMOS_WORDS[27:0];
	localparam [27:0] GFXPIXW = GFX_PIXELS[27:0];
	function automatic [15:0] read_word;
		input reg [3:0] rgn;
		input reg [27:0] gw;
		reg [27:0] rel;
		begin
			read_word = 16'h0000;
			if (rgn == R_ROM)
				;
			else if (rgn == R_RAM)
				;
			else if (rgn == R_VRAM)
				;
			else if (rgn == R_PAL)
				;
			else if (rgn == R_CMOS)
				;
			else if (rgn == R_INPUT) begin
				rel = gw - WB_INPUT;
				case (rel[1:0])
					2'd0: read_word = inputs[15:0];
					2'd1: read_word = inputs[31:16];
					2'd2: read_word = inputs[47:32];
					2'd3: read_word = inputs[63:48];
					default: read_word = 16'hffff;
				endcase
				if (rel > 28'd3)
					read_word = 16'hffff;
			end
			else if (rgn == R_GFX)
				rel = gw - WB_GFX;
		end
	endfunction
	wire [47:0] rmask = (48'd1 << sz) - 48'd1;
	wire [47:0] smask = rmask << boff;
	wire [5:0] lastb = (boff + sz) - 6'd1;
	assign gfx_raddr = gfx_raddr_q;
	always @(posedge clk) begin
		boff_r <= boff;
		rmask_r <= rmask;
	end
	reg ext_fetch;
	reg ext_isrom;
	reg [23:0] ext_base;
	reg [27:0] rom_rel;
	function automatic [23:0] sv2v_cast_24;
		input reg [23:0] inp;
		sv2v_cast_24 = inp;
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		ext_fetch = 1'b0;
		ext_isrom = 1'b0;
		ext_base = 24'd0;
		rom_rel = widx - WB_ROM;
		if ((region == R_GFX) && !we_q) begin
			ext_fetch = 1'b1;
			ext_base = sv2v_cast_24((widx - WB_GFX) << 1);
		end
		if ((((region == R_ROM) && !we_q) && (rom_rel >= ROM_PROG_OFF)) && ((rom_rel - ROM_PROG_OFF) < ROMW)) begin
			ext_fetch = 1'b1;
			ext_isrom = 1'b1;
			ext_base = SDRAM_ROMB + sv2v_cast_24((rom_rel - ROM_PROG_OFF) << 1);
		end
	end
	wire [1:0] extnw = 2'd1 + lastb[5:4];
	wire [22:0] ext_waddr = ext_base[23:1];
	reg [23:0] exd_base;
	reg [22:0] exd_waddr;
	reg exd_isrom;
	reg [1:0] exd_need;
	wire [22:0] exd_off = exd_waddr - sb_base;
	wire exd_hit = ((sb_vld && exd_isrom) && (exd_off < 23'd8)) && (({1'b0, exd_off[2:0]} + {2'b00, exd_need}) <= sb_fill);
	wire [15:0] exd_w0 = sb_q[exd_off[2:0]];
	wire [15:0] exd_w1 = sb_q[exd_off[2:0] + 3'd1];
	wire [15:0] exd_w2 = sb_q[exd_off[2:0] + 3'd2];
	function automatic [22:0] sv2v_cast_23;
		input reg [22:0] inp;
		sv2v_cast_23 = inp;
	endfunction
	localparam [22:0] SB_ROM_WEND = sv2v_cast_23((SDRAM_ROMB >> 1) + ROM_WORDS);
	wire pf_inrange = (sb_base + {19'd0, sb_fill}) < SB_ROM_WEND;
	reg is_hwram;
	reg [1:0] hsel;
	reg [17:0] hidx [0:2];
	reg hval [0:2];
	reg [27:0] hr;
	always @(*) begin
		if (_sv2v_0)
			;
		is_hwram = 1'b0;
		hsel = 2'd0;
		hr = 28'd0;
		begin : sv2v_autoblock_1
			reg signed [31:0] j;
			for (j = 0; j < 3; j = j + 1)
				begin
					hidx[j] = 18'd0;
					hval[j] = 1'b0;
				end
		end
		if (region == R_RAM) begin
			is_hwram = 1'b1;
			hsel = 2'd0;
			begin : sv2v_autoblock_2
				reg signed [31:0] j;
				for (j = 0; j < 3; j = j + 1)
					begin
						hr = (widx + j[27:0]) - WB_RAM;
						hidx[j] = hr[17:0];
						hval[j] = hr < RAMW;
					end
			end
		end
		else if (region == R_PAL) begin
			is_hwram = 1'b1;
			hsel = 2'd1;
			begin : sv2v_autoblock_3
				reg signed [31:0] j;
				for (j = 0; j < 3; j = j + 1)
					begin
						hr = (widx + j[27:0]) - WB_PAL;
						hidx[j] = hr[17:0];
						hval[j] = hr < PALW;
					end
			end
		end
		else if (region == R_CMOS) begin
			is_hwram = 1'b1;
			hsel = 2'd2;
			begin : sv2v_autoblock_4
				reg signed [31:0] j;
				for (j = 0; j < 3; j = j + 1)
					begin
						hr = (widx + j[27:0]) - WB_CMOS;
						hidx[j] = {4'd0, cmos_page, hr[11:0]};
						hval[j] = hr < CMOSW;
					end
			end
		end
	end
	reg [15:0] rd0;
	reg [15:0] rd1;
	reg [15:0] rd2;
	wire [47:0] hwin = {(hval[2] ? rd2 : 16'h0000), (hval[1] ? rd1 : 16'h0000), (hval[0] ? rd0 : 16'h0000)};
	wire [47:0] hmerged = (hwin & ~smask) | (({16'h0000, wd_q} << boff) & smask);
	reg [47:0] smask_q;
	reg [47:0] rmask_q;
	reg [47:0] wsh_q;
	reg [47:0] hwin_q;
	reg [3:0] boff_q;
	always @(posedge clk) begin
		smask_q <= smask;
		rmask_q <= rmask;
		boff_q <= boff;
		wsh_q <= {16'h0000, wd_q} << boff;
		hwin_q <= hwin;
	end
	wire [47:0] hmerged2 = (hwin_q & ~smask_q) | (wsh_q & smask_q);
	reg [17:0] eng_aa;
	reg [17:0] eng_ba;
	reg eng_awe;
	reg eng_bwe;
	reg [15:0] eng_awd;
	reg [15:0] eng_bwd;
	reg [15:0] eng_aq;
	reg [15:0] eng_bq;
	always @(*) begin
		if (_sv2v_0)
			;
		eng_aa = hidx[0];
		eng_ba = hidx[1];
		eng_awe = 1'b0;
		eng_bwe = 1'b0;
		eng_awd = hmerged2[15:0];
		eng_bwd = hmerged2[31:16];
		case (state)
			M_HR1: eng_aa = hidx[2];
			M_HFIN2:
				if (we_q) begin
					eng_aa = hidx[0];
					eng_awe = hval[0];
					eng_ba = hidx[1];
					eng_bwe = (lastb >= 6'd16) & hval[1];
				end
			M_HW2: begin
				eng_aa = hidx[2];
				eng_awe = (lastb >= 6'd32) & hval[2];
				eng_awd = hmerged2[47:32];
			end
			default:
				;
		endcase
	end
	reg [16:0] ram_aa;
	reg [16:0] ram_ba;
	reg ram_awe;
	reg ram_bwe;
	reg [15:0] ram_awd;
	reg [15:0] ram_bwd;
	reg [15:0] ram_aq;
	reg [15:0] ram_bq;
	reg [12:0] pal_aa;
	reg [12:0] pal_ba;
	reg pal_awe;
	reg pal_bwe;
	reg [15:0] pal_awd;
	reg [15:0] pal_bwd;
	reg [15:0] pal_aq;
	reg [15:0] pal_bq;
	reg [14:0] nv_aa;
	reg [14:0] nv_ba;
	reg nv_awe;
	reg nv_bwe;
	reg [15:0] nv_awd;
	reg [15:0] nv_bwd;
	reg [15:0] nv_aq;
	reg [15:0] nv_bq;
	always @(*) begin
		if (_sv2v_0)
			;
		ram_aa = eng_aa[16:0];
		ram_ba = eng_ba[16:0];
		ram_awd = eng_awd;
		ram_bwd = eng_bwd;
		pal_aa = eng_aa[12:0];
		pal_ba = eng_ba[12:0];
		pal_awd = eng_awd;
		pal_bwd = eng_bwd;
		nv_aa = eng_aa[14:0];
		nv_ba = eng_ba[14:0];
		nv_awd = eng_awd;
		nv_bwd = eng_bwd;
		ram_awe = (hsel == 2'd0) & eng_awe;
		ram_bwe = (hsel == 2'd0) & eng_bwe;
		pal_awe = (hsel == 2'd1) & eng_awe;
		pal_bwe = (hsel == 2'd1) & eng_bwe;
		nv_awe = (hsel == 2'd2) & eng_awe;
		nv_bwe = (hsel == 2'd2) & eng_bwe;
		eng_aq = (hsel == 2'd0 ? ram_aq : (hsel == 2'd1 ? pal_aq : nv_aq));
		eng_bq = (hsel == 2'd0 ? ram_bq : (hsel == 2'd1 ? pal_bq : nv_bq));
	end
	always @(posedge clk) begin
		if (ram_awe)
			ram[ram_aa] <= ram_awd;
		ram_aq <= ram[ram_aa];
	end
	always @(posedge clk) begin
		if (ram_bwe)
			ram[ram_ba] <= ram_bwd;
		ram_bq <= ram[ram_ba];
	end
	always @(posedge clk)
		if (rst) begin
			dbg_p1ctrl <= 32'd0;
			dbg_bdir <= 32'd0;
		end
		else begin
			if (ram_awe && (ram_aa == 'h865b))
				dbg_p1ctrl <= {ram_awd, dbg_p1ctrl[15:0] + 16'd1};
			if (ram_bwe && (ram_ba == 'h865b))
				dbg_p1ctrl <= {ram_bwd, dbg_p1ctrl[15:0] + 16'd1};
			if (ram_awe && (ram_aa == 'hde48))
				dbg_bdir <= {ram_awd, dbg_bdir[15:0] + 16'd1};
			if (ram_bwe && (ram_ba == 'hde48))
				dbg_bdir <= {ram_bwd, dbg_bdir[15:0] + 16'd1};
		end
	always @(posedge clk) begin
		if (pal_awe)
			pal[pal_aa] <= pal_awd;
		pal_aq <= pal[pal_aa];
	end
	always @(posedge clk) begin
		if (pal_bwe)
			pal[pal_ba] <= pal_bwd;
		pal_bq <= pal[pal_ba];
	end
	always @(posedge clk) begin
		if (nv_awe)
			nvram[nv_aa] <= nv_awd;
		nv_aq <= nvram[nv_aa];
	end
	always @(posedge clk) begin
		if (nv_bwe)
			nvram[nv_ba] <= nv_bwd;
		nv_bq <= nvram[nv_ba];
	end
	always @(posedge clk) begin
		palv_we_a <= pal_awe;
		palv_aa <= {1'b0, pal_aa[11:0]};
		palv_awd <= pal_awd;
		palv_we_b <= pal_bwe;
		palv_ba <= {1'b0, pal_ba[11:0]};
		palv_bwd <= pal_bwd;
	end
	reg vsd_req;
	wire vsd_done;
	wire [31:0] vsd_rdata;
	stv_vram_ddr_top #(
		.VRAMW(VRAM_WORDS),
		.VRAM_DDR_BASE(29'h06400000)
	) u_vram_sdram(
		.clk(clk),
		.rst(rst),
		.sdram_por(sdram_por),
		.req(vsd_req),
		.we(we_q),
		.widx(widx),
		.boff(boff),
		.sz(sz_q),
		.wd(wd_q),
		.videobank(videobank),
		.dma_palette(dma_palette),
		.rdata(vsd_rdata),
		.done(vsd_done),
		.fb_we(fb_we),
		.fb_addr(fb_addr),
		.fb_wdata(fb_wdata),
		.fb_ack(fb_ack),
		.fb_busy(fb_busy),
		.fb_flush(fb_flush),
		.erase_en(autoerase),
		.erase_busy(erase_busy),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack),
		.ddram_addr(ddram_addr),
		.ddram_burstcnt(ddram_burstcnt),
		.ddram_rd(ddram_rd),
		.ddram_we(ddram_we),
		.ddram_din(ddram_din),
		.ddram_be(ddram_be),
		.ddram_busy(ddram_busy),
		.ddram_dout(ddram_dout),
		.ddram_dout_ready(ddram_dout_ready)
	);
	reg [47:0] win_s;
	reg [47:0] merged_s;
	reg [47:0] win_s_q;
	wire [27:0] wrel;
	function automatic [31:0] sv2v_cast_32;
		input reg [31:0] inp;
		sv2v_cast_32 = inp;
	endfunction
	always @(posedge clk)
		if (rst) begin
			state <= M_IDLE;
			mem_ack <= 1'b0;
			mem_rdata <= 32'h00000000;
			snd_select <= 8'h00;
			snd_trig <= 1'b0;
			snd_reset <= 1'b1;
			er_run <= 1'b0;
			gfx_rd <= 1'b0;
			sb_vld <= 1'b0;
			sb_fill <= 4'd0;
			sb_base <= 23'd0;
			pf_run <= 1'b0;
			pf_busy <= 1'b0;
			vsd_req <= 1'b0;
		end
		else begin
			if (pf_busy && gfx_rack) begin
				pf_busy <= 1'b0;
				gfx_rd <= 1'b0;
				if ((pf_run && sb_vld) && (sb_fill < SB_N)) begin
					sb_q[sb_fill[2:0]] <= gfx_rdata;
					sb_fill <= sb_fill + 4'd1;
				end
			end
			else if (((((((((pf_run && sb_vld) && !pf_busy) && !gfx_rd) && (sb_fill < SB_N)) && pf_inrange) && (state != M_GFX)) && (state != M_SBH)) && (state != M_EXD)) && !((state == M_ACK) && ext_fetch)) begin
				gfx_raddr_q <= {sb_base + {19'd0, sb_fill}, 1'b0};
				gfx_rd <= 1'b1;
				pf_busy <= 1'b1;
			end
			(* full_case, parallel_case *)
			case (state)
				M_IDLE: begin
					mem_ack <= 1'b0;
					if (mem_req && !mem_ack) begin
						a_q <= mem_addr;
						we_q <= mem_we;
						wd_q <= mem_wdata;
						sz_q <= mem_size;
						if (mem_we) begin
							sb_vld <= 1'b0;
							pf_run <= 1'b0;
						end
						state <= M_ACK;
					end
				end
				M_ACK:
					if (ext_fetch) begin
						mem_ack <= 1'b0;
						exd_base <= ext_base;
						exd_waddr <= ext_waddr;
						exd_isrom <= ext_isrom;
						exd_need <= extnw;
						state <= M_EXD;
					end
					else if (is_hwram) begin
						mem_ack <= 1'b0;
						state <= M_HR1;
					end
					else if (is_hwvram) begin
						mem_ack <= 1'b0;
						vsd_req <= 1'b1;
						state <= M_VSD;
					end
					else begin
						win_s = {read_word(region, widx + 28'd2), read_word(region, widx + 28'd1), read_word(region, widx)};
						merged_s = (win_s & ~smask) | (({16'h0000, wd_q} << boff) & smask);
						if (we_q) begin
							(* full_case, parallel_case *)
							case (region)
								default:
									;
							endcase
							if (region == R_CTRL) begin
								videobank <= wd_q[5];
								cmos_page <= wd_q[7:6];
								autoerase <= ~wd_q[4];
							end
							if (region == R_SOUND) begin
								snd_select <= wd_q[7:0];
								snd_trig <= wd_q[9];
								snd_reset <= ~wd_q[8];
							end
							mem_rdata <= 32'h00000000;
							mem_ack <= 1'b1;
							state <= M_IDLE;
						end
						else begin
							win_s_q <= win_s;
							mem_ack <= 1'b0;
							state <= M_RDLY;
						end
					end
				M_EXD:
					if (exd_hit) begin
						win_s_q <= {exd_w2, exd_w1, exd_w0};
						state <= M_SBH;
					end
					else if (pf_busy)
						;
					else begin
						gfx_base <= exd_base;
						gfx_cnt <= 2'd0;
						gfx_need <= exd_need;
						gfx_isrom <= exd_isrom;
						if (exd_isrom) begin
							sb_vld <= 1'b0;
							sb_base <= exd_waddr;
							sb_fill <= 4'd0;
							pf_run <= 1'b0;
						end
						gfx_raddr_q <= exd_base;
						gfx_rd <= 1'b1;
						state <= M_GFX;
					end
				M_GFX:
					if (gfx_rack) begin
						gfx_rd <= 1'b0;
						if (gfx_isrom)
							sb_q[{1'b0, gfx_cnt}] <= gfx_rdata;
						if (gfx_cnt == 2'd0)
							gw0 <= gfx_rdata;
						if (gfx_cnt == 2'd1)
							gw1 <= gfx_rdata;
						if (({1'b0, gfx_cnt} + 3'd1) >= {1'b0, gfx_need}) begin
							win_s_q <= (gfx_need == 2'd1 ? {32'h00000000, gfx_rdata} : (gfx_need == 2'd2 ? {16'h0000, gfx_rdata, gw0} : {gfx_rdata, gw1, gw0}));
							if (gfx_isrom) begin
								sb_fill <= {2'b00, gfx_cnt} + 4'd1;
								sb_vld <= 1'b1;
								pf_run <= 1'b1;
							end
							state <= M_SBH;
						end
						else
							gfx_cnt <= gfx_cnt + 2'd1;
					end
					else if (!gfx_rd) begin
						gfx_raddr_q <= gfx_base + {21'd0, gfx_cnt, 1'b0};
						gfx_rd <= 1'b1;
					end
				M_SBH: begin
					mem_rdata <= sv2v_cast_32((win_s_q >> boff_r) & rmask_r);
					mem_ack <= 1'b1;
					state <= M_IDLE;
				end
				M_HR1: begin
					rd0 <= eng_aq;
					rd1 <= eng_bq;
					state <= M_HR2;
				end
				M_HR2: begin
					rd2 <= eng_aq;
					state <= M_HFIN;
				end
				M_HFIN: state <= M_HFIN2;
				M_HFIN2:
					if (we_q) begin
						if ((lastb >= 6'd32) && hval[2])
							state <= M_HW2;
						else begin
							mem_ack <= 1'b1;
							state <= M_IDLE;
						end
					end
					else begin
						mem_rdata <= sv2v_cast_32((hwin_q >> boff_q) & rmask_q);
						mem_ack <= 1'b1;
						state <= M_IDLE;
					end
				M_HW2: begin
					mem_ack <= 1'b1;
					state <= M_IDLE;
				end
				M_RDLY: begin
					mem_rdata <= sv2v_cast_32((win_s_q >> boff_q) & rmask_q);
					mem_ack <= 1'b1;
					state <= M_IDLE;
				end
				M_VSD: begin
					vsd_req <= 1'b0;
					if (vsd_done) begin
						mem_rdata <= vsd_rdata;
						mem_ack <= 1'b1;
						state <= M_IDLE;
					end
				end
				default: begin
					state <= M_IDLE;
					mem_ack <= 1'b0;
				end
			endcase
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_dma_smash_firefix (
	clk,
	rst,
	reg_we,
	reg_addr,
	reg_wdata,
	reg_rdata,
	src_req,
	src_addr,
	src_data,
	src_ack,
	fb_we,
	fb_addr,
	fb_wdata,
	fb_ack,
	fb_busy,
	fb_flush,
	busy,
	trigger_blocked,
	blit_irq,
	dma_palette
);
	reg _sv2v_0;
	input wire clk;
	input wire rst;
	input wire reg_we;
	input wire [3:0] reg_addr;
	input wire [15:0] reg_wdata;
	output wire [15:0] reg_rdata;
	output wire src_req;
	output wire [23:0] src_addr;
	input wire [7:0] src_data;
	input wire src_ack;
	output reg fb_we;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	output reg [17:0] fb_addr;
	output reg [15:0] fb_wdata;
	input wire fb_ack;
	input wire fb_busy;
	output wire fb_flush;
	output wire busy;
	output wire trigger_blocked;
	output reg blit_irq;
	output wire [15:0] dma_palette;
	localparam signed [31:0] yunit_pkg_DMA_NREGS = 16;
	reg [15:0] regf [0:15];
	reg [15:0] launchf [0:15];
	reg [15:0] pendf [0:15];
	reg busy_r;
	reg abort_r;
	reg pend_trig;
	reg [25:0] pace_cnt;
	reg pace_arm;
	localparam [3:0] yunit_pkg_DMA_COMMAND = 4'd0;
	wire [15:0] cmd_reg = regf[yunit_pkg_DMA_COMMAND];
	wire [15:0] launch_cmd = launchf[yunit_pkg_DMA_COMMAND];
	localparam signed [31:0] yunit_pkg_DMA_CMD_FLIPX_BIT = 4;
	wire flipx_w = launch_cmd[yunit_pkg_DMA_CMD_FLIPX_BIT];
	wire [3:0] mode_w = launch_cmd[3:0];
	localparam [3:0] yunit_pkg_DMA_PALETTE = 4'd8;
	wire [7:0] pal_lo = launchf[yunit_pkg_DMA_PALETTE][7:0];
	localparam [3:0] yunit_pkg_DMA_COLOR = 4'd9;
	wire [7:0] col_lo = launchf[yunit_pkg_DMA_COLOR][7:0];
	localparam signed [31:0] yunit_pkg_DMA_CMD_TRIG_BIT = 15;
	wire wdata_trig = reg_wdata[yunit_pkg_DMA_CMD_TRIG_BIT];
	assign busy = busy_r;
	assign dma_palette = regf[yunit_pkg_DMA_PALETTE];
	assign reg_rdata = (reg_addr == yunit_pkg_DMA_COMMAND ? {busy_r, cmd_reg[14:0]} : regf[reg_addr]);
	reg [2:0] state;
	reg [2:0] state_n;
	wire trigger_write = (reg_we && (reg_addr == yunit_pkg_DMA_COMMAND)) && wdata_trig;
	wire direct_accept = (trigger_write && (state == 3'd0)) && !pend_trig;
	wire pending_accept = (trigger_write && (state != 3'd0)) && !pend_trig;
	assign trigger_blocked = pend_trig;
	reg [3:0] mode_c;
	reg flipx_c;
	reg readmode_c;
	reg signed [11:0] width_c;
	reg signed [11:0] height_c;
	reg signed [11:0] xpos_c;
	reg signed [11:0] ypos_c;
	reg signed [31:0] rowbytes_c;
	reg [15:0] pal16_c;
	reg [15:0] color16_c;
	reg signed [11:0] row_i;
	reg signed [11:0] col_i;
	reg signed [11:0] tx;
	reg [8:0] ty;
	reg signed [31:0] cur_off;
	reg signed [31:0] o_ptr;
	reg [7:0] px;
	reg signed [31:0] rb_in;
	reg signed [31:0] xs_in;
	reg signed [31:0] ys_in;
	reg [15:0] w_in;
	reg [15:0] h_in;
	reg [31:0] gfxoff0;
	reg [31:0] gfxoff1;
	reg [31:0] gfxoff2;
	reg signed [31:0] rb_adj;
	reg signed [31:0] xpos0;
	reg signed [31:0] ypos1;
	reg signed [31:0] height1a;
	reg signed [31:0] height1;
	reg signed [31:0] xpos_f;
	reg signed [31:0] width_f;
	reg signed [31:0] offbytes_c;
	localparam [3:0] yunit_pkg_DMA_HEIGHT = 4'd7;
	localparam [3:0] yunit_pkg_DMA_OFFSETHI = 4'd3;
	localparam [3:0] yunit_pkg_DMA_OFFSETLO = 4'd2;
	localparam [3:0] yunit_pkg_DMA_ROWBYTES = 4'd1;
	localparam [3:0] yunit_pkg_DMA_WIDTH = 4'd6;
	localparam [3:0] yunit_pkg_DMA_XSTART = 4'd4;
	localparam [3:0] yunit_pkg_DMA_YSTART = 4'd5;
	always @(*) begin
		if (_sv2v_0)
			;
		rb_in = $signed(launchf[yunit_pkg_DMA_ROWBYTES]);
		xs_in = $signed(launchf[yunit_pkg_DMA_XSTART]);
		ys_in = $signed(launchf[yunit_pkg_DMA_YSTART]);
		w_in = launchf[yunit_pkg_DMA_WIDTH];
		h_in = launchf[yunit_pkg_DMA_HEIGHT];
		gfxoff0 = {launchf[yunit_pkg_DMA_OFFSETHI], launchf[yunit_pkg_DMA_OFFSETLO]};
		rb_adj = (flipx_w ? ((rb_in - $signed({16'd0, w_in})) + 32'sd3) & ~32'sd3 : ((rb_in + $signed({16'd0, w_in})) + 32'sd3) & ~32'sd3);
		xpos0 = (flipx_w ? (xs_in + $signed({16'd0, w_in})) - 32'sd1 : xs_in);
		gfxoff1 = (flipx_w ? gfxoff0 - (({16'd0, w_in} - 32'd1) << 3) : gfxoff0);
		ypos1 = (ys_in < 0 ? 32'sd0 : ys_in);
		height1a = (ys_in < 0 ? $signed({16'd0, h_in}) + ys_in : $signed({16'd0, h_in}));
		height1 = ((ypos1 + height1a) > 32'sd512 ? 32'sd512 - ypos1 : height1a);
		if (!flipx_w) begin
			if (xpos0 < 0) begin
				width_f = $signed({16'd0, w_in}) + xpos0;
				xpos_f = 32'sd0;
			end
			else begin
				width_f = $signed({16'd0, w_in});
				xpos_f = xpos0;
			end
			if ((xpos_f + width_f) > 32'sd512)
				width_f = 32'sd512 - xpos_f;
		end
		else begin
			if (xpos0 >= 32'sd512) begin
				width_f = $signed({16'd0, w_in}) - (xpos0 - 32'sd511);
				xpos_f = 32'sd511;
			end
			else begin
				width_f = $signed({16'd0, w_in});
				xpos_f = xpos0;
			end
			if ((xpos_f - width_f) < 0)
				width_f = xpos_f;
		end
		gfxoff2 = (gfxoff1 < 32'h02000000 ? gfxoff1 + 32'h02000000 : gfxoff1);
		offbytes_c = ($signed(gfxoff2) - 32'sh02000000) >>> 3;
	end
	wire [11:0] width12 = width_f[11:0];
	wire [11:0] height12 = height1[11:0];
	wire [11:0] xpos12 = xpos_f[11:0];
	wire [11:0] ypos12 = ypos1[11:0];
	wire readmode_w = (mode_w >= 4'h1) && (mode_w <= 4'hb);
	reg pix_we;
	reg [15:0] pix_data;
	always @(*) begin
		if (_sv2v_0)
			;
		pix_we = 1'b0;
		pix_data = 16'h0000;
		(* full_case, parallel_case *)
		case (mode_c)
			4'h0:
				;
			4'h1: begin
				pix_we = px == 8'd0;
				pix_data = pal16_c;
			end
			4'h2: begin
				pix_we = px != 8'd0;
				pix_data = pal16_c | {8'd0, px};
			end
			4'h3: begin
				pix_we = 1'b1;
				pix_data = pal16_c | {8'd0, px};
			end
			4'h4, 4'h5: begin
				pix_we = px == 8'd0;
				pix_data = color16_c;
			end
			4'h6, 4'h7: begin
				pix_we = 1'b1;
				pix_data = (px == 8'd0 ? color16_c : pal16_c | {8'd0, px});
			end
			4'h8, 4'ha: begin
				pix_we = px != 8'd0;
				pix_data = color16_c;
			end
			4'h9, 4'hb: begin
				pix_we = 1'b1;
				pix_data = (px != 8'd0 ? color16_c : pal16_c | {8'd0, px});
			end
			default: begin
				pix_we = 1'b1;
				pix_data = color16_c;
			end
		endcase
	end
	wire row_overrun = ($unsigned(cur_off) >= 32'h06000000) && (mode_c < 4'hc);
	wire [8:0] tx9 = tx[8:0];
	wire [8:0] ty_next = ypos_c[8:0] + row_i[8:0];
	wire dma_done_ok = pace_cnt == 26'd0;
	always @(*) begin
		if (_sv2v_0)
			;
		state_n = state;
		(* full_case, parallel_case *)
		case (state)
			3'd0:
				if (pend_trig)
					state_n = 3'd1;
				else if (direct_accept)
					state_n = 3'd1;
			3'd1: state_n = 3'd2;
			3'd2:
				if ((height1 <= 0) || (width_f <= 0))
					state_n = 3'd6;
				else
					state_n = 3'd3;
			3'd3:
				if (row_i >= height_c)
					state_n = 3'd6;
				else if (row_overrun)
					state_n = 3'd3;
				else
					state_n = 3'd4;
			3'd4:
				if (!readmode_c)
					state_n = 3'd5;
				else if (src_ack)
					state_n = 3'd5;
			3'd5:
				if (pix_we && !fb_ack)
					state_n = 3'd5;
				else if (col_i >= (width_c - 12'sd1))
					state_n = 3'd3;
				else
					state_n = 3'd4;
			3'd6:
				if (dma_done_ok)
					state_n = 3'd0;
			default: state_n = 3'd0;
		endcase
	end
	assign src_req = (state == 3'd4) && readmode_c;
	assign src_addr = o_ptr[23:0];
	assign fb_flush = state == 3'd6;
	integer i;
	always @(posedge clk)
		if (rst) begin
			state <= 3'd0;
			fb_we <= 1'b0;
			blit_irq <= 1'b0;
			busy_r <= 1'b0;
			pace_cnt <= 26'd0;
			pace_arm <= 1'b0;
			abort_r <= 1'b0;
			pend_trig <= 1'b0;
			for (i = 0; i < yunit_pkg_DMA_NREGS; i = i + 1)
				begin
					regf[i] <= 16'h0000;
					launchf[i] <= 16'h0000;
					pendf[i] <= 16'h0000;
				end
		end
		else begin
			state <= state_n;
			fb_we <= 1'b0;
			if (reg_we) begin
				regf[reg_addr] <= reg_wdata;
				if (reg_addr == yunit_pkg_DMA_COMMAND) begin
					blit_irq <= 1'b0;
					if (wdata_trig) begin
						if (direct_accept) begin
							for (i = 0; i < 10; i = i + 1)
								launchf[i] <= (i == yunit_pkg_DMA_COMMAND ? reg_wdata : regf[i]);
							busy_r <= 1'b1;
						end
						else if (pending_accept) begin
							for (i = 0; i < 10; i = i + 1)
								pendf[i] <= (i == yunit_pkg_DMA_COMMAND ? reg_wdata : regf[i]);
							pend_trig <= 1'b1;
							busy_r <= 1'b1;
						end
					end
					else if (state == 3'd0)
						busy_r <= 1'b0;
					else begin
						busy_r <= 1'b0;
						if (state_n != 3'd0)
							abort_r <= 1'b1;
					end
				end
			end
			if (abort_r && (state_n == 3'd0))
				abort_r <= 1'b0;
			if ((state == 3'd0) && pend_trig) begin
				for (i = 0; i < 10; i = i + 1)
					launchf[i] <= pendf[i];
				pend_trig <= 1'b0;
			end
			pace_arm <= state == 3'd2;
			if (pace_arm)
				pace_cnt <= ({14'd0, width_c[11:0]} * {14'd0, height_c[11:0]}) << 2;
			else if (pace_cnt != 26'd0)
				pace_cnt <= pace_cnt - 26'd1;
			(* full_case, parallel_case *)
			case (state)
				3'd2: begin
					mode_c <= mode_w;
					flipx_c <= flipx_w;
					readmode_c <= readmode_w;
					width_c <= (width_f <= 32'sd0 ? 12'sd0 : $signed(width12));
					height_c <= (height1 <= 32'sd0 ? 12'sd0 : $signed(height12));
					xpos_c <= $signed(xpos12);
					ypos_c <= $signed(ypos12);
					rowbytes_c <= rb_adj;
					pal16_c <= {pal_lo, 8'h00};
					color16_c <= {pal_lo, col_lo};
					row_i <= 12'sd0;
					cur_off <= offbytes_c;
				end
				3'd3: begin
					ty <= ty_next;
					tx <= xpos_c;
					col_i <= 12'sd0;
					o_ptr <= cur_off;
					if (row_i < height_c) begin
						cur_off <= cur_off + rowbytes_c;
						row_i <= row_i + 12'sd1;
					end
				end
				3'd4:
					if (readmode_c && src_ack)
						px <= src_data;
				3'd5: begin
					if (pix_we) begin
						fb_we <= 1'b1;
						fb_addr <= {ty, tx9};
						fb_wdata <= pix_data;
					end
					if (!pix_we || fb_ack) begin
						tx <= tx + (flipx_c ? -12'sd1 : 12'sd1);
						col_i <= col_i + 12'sd1;
						if (readmode_c)
							o_ptr <= o_ptr + 32'sd1;
					end
				end
				3'd6:
					if (dma_done_ok) begin
						if (pend_trig || pending_accept)
							blit_irq <= 1'b0;
						else begin
							busy_r <= 1'b0;
							blit_irq <= 1'b1;
						end
					end
				default:
					;
			endcase
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_memsys_smash_firefix (
	clk,
	rst,
	mem_req,
	mem_we,
	mem_addr,
	mem_size,
	mem_wdata,
	mem_rdata,
	mem_ack,
	src_req,
	src_addr,
	src_data,
	src_ack,
	inputs,
	int1,
	snd_select,
	snd_trig,
	snd_reset,
	dbg_p1ctrl,
	dbg_bdir,
	erase_start,
	erase_row0,
	erase_lines,
	erase_busy,
	blit_busy,
	fb_snoop_we,
	fb_snoop_addr,
	fb_snoop_data,
	dbg_dma_we,
	dbg_dma_addr,
	dbg_dma_wdata,
	cpu_gfx_rd,
	cpu_gfx_raddr,
	cpu_gfx_rdata,
	cpu_gfx_rack,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	sdram_por,
	ddram_addr,
	ddram_burstcnt,
	ddram_rd,
	ddram_we,
	ddram_din,
	ddram_be,
	ddram_busy,
	ddram_dout,
	ddram_dout_ready,
	palv_we_a,
	palv_aa,
	palv_awd,
	palv_we_b,
	palv_ba,
	palv_bwd
);
	parameter ROM_HEX = "smashtv_maindata.hex";
	input wire clk;
	input wire rst;
	input wire mem_req;
	input wire mem_we;
	input wire [31:0] mem_addr;
	input wire [5:0] mem_size;
	input wire [31:0] mem_wdata;
	output wire [31:0] mem_rdata;
	output wire mem_ack;
	output wire src_req;
	output wire [23:0] src_addr;
	input wire [7:0] src_data;
	input wire src_ack;
	input wire [63:0] inputs;
	output wire int1;
	output wire [7:0] snd_select;
	output wire snd_trig;
	output wire snd_reset;
	output wire [31:0] dbg_p1ctrl;
	output wire [31:0] dbg_bdir;
	input wire erase_start;
	input wire [8:0] erase_row0;
	input wire [9:0] erase_lines;
	output wire erase_busy;
	output wire blit_busy;
	output wire fb_snoop_we;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	output wire [17:0] fb_snoop_addr;
	output wire [15:0] fb_snoop_data;
	output wire dbg_dma_we;
	output wire [3:0] dbg_dma_addr;
	output wire [15:0] dbg_dma_wdata;
	output wire cpu_gfx_rd;
	output wire [23:0] cpu_gfx_raddr;
	input wire [15:0] cpu_gfx_rdata;
	input wire cpu_gfx_rack;
	input wire scan_req;
	input wire [17:0] scan_addr;
	output wire [15:0] scan_data;
	output wire scan_ack;
	input wire sdram_por;
	output wire [28:0] ddram_addr;
	output wire [7:0] ddram_burstcnt;
	output wire ddram_rd;
	output wire ddram_we;
	output wire [63:0] ddram_din;
	output wire [7:0] ddram_be;
	input wire ddram_busy;
	input wire [63:0] ddram_dout;
	input wire ddram_dout_ready;
	output wire palv_we_a;
	output wire [12:0] palv_aa;
	output wire [15:0] palv_awd;
	output wire palv_we_b;
	output wire [12:0] palv_ba;
	output wire [15:0] palv_bwd;
	wire is_dma_now = mem_addr[31:20] == 12'h01a;
	wire mem_req_m;
	wire [31:0] mem_rdata_m;
	wire mem_ack_m;
	wire dma_reg_we;
	wire [3:0] dma_reg_addr;
	wire [15:0] dma_reg_wdata;
	wire [15:0] dma_reg_rdata;
	wire dma_fb_we;
	wire [17:0] dma_fb_addr;
	wire [15:0] dma_fb_wdata;
	wire [15:0] dma_palette;
	wire dma_trigger_blocked;
	wire mem_fb_ack;
	wire dma_fb_ack = mem_fb_ack;
	wire mem_fb_busy;
	wire dma_fb_busy = mem_fb_busy;
	wire dma_fb_flush;
	assign fb_snoop_we = dma_fb_we && dma_fb_ack;
	assign fb_snoop_addr = dma_fb_addr;
	assign fb_snoop_data = dma_fb_wdata;
	yunit_mem_smash_firefix #(.ROM_HEX(ROM_HEX)) u_mem(
		.clk(clk),
		.rst(rst),
		.mem_req(mem_req_m),
		.mem_we(mem_we),
		.mem_addr(mem_addr),
		.mem_size(mem_size),
		.mem_wdata(mem_wdata),
		.mem_rdata(mem_rdata_m),
		.mem_ack(mem_ack_m),
		.fb_we(dma_fb_we),
		.fb_addr(dma_fb_addr),
		.fb_wdata(dma_fb_wdata),
		.dma_palette(dma_palette),
		.inputs(inputs),
		.snd_select(snd_select),
		.snd_trig(snd_trig),
		.snd_reset(snd_reset),
		.dbg_p1ctrl(dbg_p1ctrl),
		.dbg_bdir(dbg_bdir),
		.erase_start(erase_start),
		.erase_row0(erase_row0),
		.erase_lines(erase_lines),
		.erase_busy(erase_busy),
		.gfx_rd(cpu_gfx_rd),
		.gfx_raddr(cpu_gfx_raddr),
		.gfx_rdata(cpu_gfx_rdata),
		.gfx_rack(cpu_gfx_rack),
		.fb_ack(mem_fb_ack),
		.fb_busy(mem_fb_busy),
		.fb_flush(dma_fb_flush),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack),
		.sdram_por(sdram_por),
		.ddram_addr(ddram_addr),
		.ddram_burstcnt(ddram_burstcnt),
		.ddram_rd(ddram_rd),
		.ddram_we(ddram_we),
		.ddram_din(ddram_din),
		.ddram_be(ddram_be),
		.ddram_busy(ddram_busy),
		.ddram_dout(ddram_dout),
		.ddram_dout_ready(ddram_dout_ready),
		.palv_we_a(palv_we_a),
		.palv_aa(palv_aa),
		.palv_awd(palv_awd),
		.palv_we_b(palv_we_b),
		.palv_ba(palv_ba),
		.palv_bwd(palv_bwd)
	);
	yunit_dma_smash_firefix u_dma(
		.clk(clk),
		.rst(rst),
		.reg_we(dma_reg_we),
		.reg_addr(dma_reg_addr),
		.reg_wdata(dma_reg_wdata),
		.reg_rdata(dma_reg_rdata),
		.src_req(src_req),
		.src_addr(src_addr),
		.src_data(src_data),
		.src_ack(src_ack),
		.fb_we(dma_fb_we),
		.fb_addr(dma_fb_addr),
		.fb_wdata(dma_fb_wdata),
		.fb_ack(dma_fb_ack),
		.fb_busy(dma_fb_busy),
		.fb_flush(dma_fb_flush),
		.busy(blit_busy),
		.trigger_blocked(dma_trigger_blocked),
		.blit_irq(int1),
		.dma_palette(dma_palette)
	);
	reg [1:0] dstate;
	reg [31:0] d_addr_q;
	reg d_we_q;
	reg [31:0] d_wd_q;
	reg [5:0] d_sz_q;
	reg dma_ack;
	wire d_second = dstate == 2'd2;
	assign dma_reg_addr = (d_second ? d_addr_q[7:4] + 4'd1 : d_addr_q[7:4]);
	assign dma_reg_wdata = (d_second ? d_wd_q[31:16] : d_wd_q[15:0]);
	assign dbg_dma_we = dma_reg_we;
	assign dbg_dma_addr = dma_reg_addr;
	assign dbg_dma_wdata = dma_reg_wdata;
	assign dma_reg_we = (dstate == 2'd1) || (dstate == 2'd2);
	localparam signed [31:0] yunit_pkg_DMA_CMD_TRIG_BIT = 15;
	localparam [3:0] yunit_pkg_DMA_COMMAND = 4'd0;
	always @(posedge clk)
		if (rst) begin
			dstate <= 2'd0;
			dma_ack <= 1'b0;
		end
		else
			(* full_case, parallel_case *)
			case (dstate)
				2'd0: begin
					dma_ack <= 1'b0;
					if ((mem_req && is_dma_now) && !mem_ack) begin
						if (((mem_we && (mem_addr[7:4] == yunit_pkg_DMA_COMMAND)) && mem_wdata[yunit_pkg_DMA_CMD_TRIG_BIT]) && dma_trigger_blocked)
							;
						else begin
							d_addr_q <= mem_addr;
							d_we_q <= mem_we;
							d_wd_q <= mem_wdata;
							d_sz_q <= mem_size;
							dstate <= (mem_we ? 2'd1 : 2'd3);
						end
					end
				end
				2'd1: dstate <= (d_sz_q > 6'd16 ? 2'd2 : 2'd3);
				2'd2: dstate <= 2'd3;
				2'd3: begin
					dma_ack <= 1'b1;
					dstate <= 2'd0;
				end
				default: dstate <= 2'd0;
			endcase
	assign mem_req_m = mem_req && !is_dma_now;
	assign mem_ack = (is_dma_now ? dma_ack : mem_ack_m);
	assign mem_rdata = (is_dma_now ? {16'h0000, dma_reg_rdata} : mem_rdata_m);
endmodule
`default_nettype wire
`default_nettype none
module yunit_video_smash_firefix (
	clk,
	rst,
	ce_pix,
	vram_raddr,
	vram_rdata,
	pal_raddr,
	pal_rdata,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de,
	vblank_raw,
	vblank_irq
);
	reg _sv2v_0;
	parameter signed [31:0] H_ACT = 410;
	parameter signed [31:0] H_FP = 6;
	parameter signed [31:0] H_SYNC = 40;
	parameter signed [31:0] H_BP = 50;
	parameter signed [31:0] V_ACT = 256;
	parameter signed [31:0] V_FP = 13;
	parameter signed [31:0] V_SYNC = 8;
	parameter signed [31:0] V_BP = 12;
	parameter signed [31:0] DISP_ROW0 = 0;
	input wire clk;
	input wire rst;
	input wire ce_pix;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	output wire [17:0] vram_raddr;
	input wire [15:0] vram_rdata;
	output wire [11:0] pal_raddr;
	input wire [15:0] pal_rdata;
	output reg [7:0] vid_r;
	output reg [7:0] vid_g;
	output reg [7:0] vid_b;
	output reg hsync;
	output reg vsync;
	output reg hblank;
	output reg vblank;
	output reg de;
	output wire vblank_raw;
	output reg vblank_irq;
	localparam signed [31:0] H_TOTAL = ((H_ACT + H_FP) + H_SYNC) + H_BP;
	localparam signed [31:0] V_TOTAL = ((V_ACT + V_FP) + V_SYNC) + V_BP;
	reg [11:0] hc;
	reg [11:0] vc;
	reg s0_de;
	reg s0_hs;
	reg s0_vs;
	reg s0_hb;
	reg s0_vb;
	reg [11:0] s0_x;
	reg [11:0] s0_y;
	function automatic signed [11:0] sv2v_cast_12_signed;
		input reg signed [11:0] inp;
		sv2v_cast_12_signed = inp;
	endfunction
	always @(posedge clk)
		if (rst) begin
			hc <= sv2v_cast_12_signed(H_ACT + H_FP);
			vc <= sv2v_cast_12_signed((V_ACT + V_FP) - 1);
			vblank_irq <= 1'b0;
		end
		else if (ce_pix) begin
			vblank_irq <= 1'b0;
			if (hc == (H_TOTAL - 1)) begin
				hc <= 1'sb0;
				if (vc == (V_TOTAL - 1))
					vc <= 1'sb0;
				else begin
					vc <= vc + 12'd1;
					if (vc == (V_ACT - 1))
						vblank_irq <= 1'b1;
				end
			end
			else
				hc <= hc + 12'd1;
		end
	always @(*) begin
		if (_sv2v_0)
			;
		s0_x = hc;
		s0_y = vc;
		s0_de = (hc < H_ACT) && (vc < V_ACT);
		s0_hb = hc >= H_ACT;
		s0_vb = vc >= V_ACT;
		s0_hs = (hc >= (H_ACT + H_FP)) && (hc < ((H_ACT + H_FP) + H_SYNC));
		s0_vs = (vc >= (V_ACT + V_FP)) && (vc < ((V_ACT + V_FP) + V_SYNC));
	end
	localparam signed [31:0] yunit_pkg_FB_ROWSHIFT = 9;
	function automatic [17:0] sv2v_cast_18;
		input reg [17:0] inp;
		sv2v_cast_18 = inp;
	endfunction
	assign vram_raddr = sv2v_cast_18(((DISP_ROW0 + s0_y) << yunit_pkg_FB_ROWSHIFT) + (s0_x & 12'h1ff));
	assign vblank_raw = s0_vb;
	reg s1_de;
	reg s1_hs;
	reg s1_vs;
	reg s1_hb;
	reg s1_vb;
	reg s2_de;
	reg s2_hs;
	reg s2_vs;
	reg s2_hb;
	reg s2_vb;
	always @(posedge clk)
		if (rst) begin
			s1_de <= 0;
			s1_hs <= 0;
			s1_vs <= 0;
			s1_hb <= 0;
			s1_vb <= 0;
			s2_de <= 0;
			s2_hs <= 0;
			s2_vs <= 0;
			s2_hb <= 0;
			s2_vb <= 0;
		end
		else if (ce_pix) begin
			s1_de <= s0_de;
			s1_hs <= s0_hs;
			s1_vs <= s0_vs;
			s1_hb <= s0_hb;
			s1_vb <= s0_vb;
			s2_de <= s1_de;
			s2_hs <= s1_hs;
			s2_vs <= s1_vs;
			s2_hb <= s1_hb;
			s2_vb <= s1_vb;
		end
	function automatic [11:0] yunit_pkg_pen_map6;
		input reg [15:0] w;
		yunit_pkg_pen_map6 = {w[11:8], w[15:14], w[5:0]};
	endfunction
	assign pal_raddr = yunit_pkg_pen_map6(vram_rdata);
	wire [23:0] rgb;
	function automatic [23:0] yunit_pkg_rgb555_to_888;
		input reg [15:0] c;
		reg [4:0] r5;
		reg [4:0] g5;
		reg [4:0] b5;
		begin
			r5 = c[14:10];
			g5 = c[9:5];
			b5 = c[4:0];
			yunit_pkg_rgb555_to_888 = {r5, r5[4:2], g5, g5[4:2], b5, b5[4:2]};
		end
	endfunction
	assign rgb = yunit_pkg_rgb555_to_888(pal_rdata);
	always @(posedge clk)
		if (rst) begin
			de <= 0;
			hsync <= 0;
			vsync <= 0;
			hblank <= 0;
			vblank <= 0;
			vid_r <= 0;
			vid_g <= 0;
			vid_b <= 0;
		end
		else if (ce_pix) begin
			de <= s2_de;
			hsync <= s2_hs;
			vsync <= s2_vs;
			hblank <= s2_hb;
			vblank <= s2_vb;
			vid_r <= (s2_de ? rgb[23:16] : 8'h00);
			vid_g <= (s2_de ? rgb[15:8] : 8'h00);
			vid_b <= (s2_de ? rgb[7:0] : 8'h00);
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_scanline_smash_firefix (
	clk,
	rst,
	ce_pix,
	vblank,
	vram_raddr,
	vram_rdata,
	snoop_we,
	snoop_addr,
	snoop_data,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack
);
	reg _sv2v_0;
	parameter signed [31:0] FB_ADDR_W = 18;
	parameter signed [31:0] NCOL = 512;
	parameter signed [31:0] FIRST_ROW = 0;
	input wire clk;
	input wire rst;
	input wire ce_pix;
	input wire vblank;
	input wire [FB_ADDR_W - 1:0] vram_raddr;
	output reg [15:0] vram_rdata;
	input wire snoop_we;
	input wire [FB_ADDR_W - 1:0] snoop_addr;
	input wire [15:0] snoop_data;
	output reg scan_req;
	output wire [17:0] scan_addr;
	input wire [15:0] scan_data;
	input wire scan_ack;
	localparam signed [31:0] ROWW = FB_ADDR_W - 9;
	wire [ROWW - 1:0] req_row = vram_raddr[FB_ADDR_W - 1:9];
	wire [8:0] req_col = vram_raddr[8:0];
	(* ramstyle = "no_rw_check" *) reg [15:0] lb0 [0:511];
	(* ramstyle = "no_rw_check" *) reg [15:0] lb1 [0:511];
	(* ramstyle = "no_rw_check" *) reg [15:0] ov0 [0:511];
	(* ramstyle = "no_rw_check" *) reg [15:0] ov1 [0:511];
	reg [511:0] ov0_valid;
	reg [511:0] ov1_valid;
	reg disp_sel;
	reg [ROWW - 1:0] disp_row;
	wire sel_now = (req_row == disp_row ? disp_sel : ~disp_sel);
	function automatic signed [ROWW - 1:0] sv2v_cast_AD1AC_signed;
		input reg signed [ROWW - 1:0] inp;
		sv2v_cast_AD1AC_signed = inp;
	endfunction
	wire [ROWW - 1:0] planned_row0 = (vblank ? sv2v_cast_AD1AC_signed(FIRST_ROW) : (sel_now ? req_row + 1'b1 : req_row));
	wire [ROWW - 1:0] planned_row1 = (vblank ? sv2v_cast_AD1AC_signed(FIRST_ROW + 1) : (sel_now ? req_row : req_row + 1'b1));
	always @(posedge clk)
		if (ce_pix) begin
			if (sel_now)
				vram_rdata <= (ov1_valid[req_col] ? ov1[req_col] : lb1[req_col]);
			else
				vram_rdata <= (ov0_valid[req_col] ? ov0[req_col] : lb0[req_col]);
		end
	reg [ROWW - 1:0] buf_row [0:1];
	reg buf_valid [0:1];
	wire [ROWW - 1:0] next_row = disp_row + 1'b1;
	wire [ROWW - 1:0] snoop_row = snoop_addr[FB_ADDR_W - 1:9];
	wire [8:0] snoop_col = snoop_addr[8:0];
	reg loading;
	reg tgt_sel;
	reg [ROWW - 1:0] tgt_row;
	reg [8:0] li;
	reg vbl_q;
	wire frame_start = !vbl_q && vblank;
	wire row_advance = !vblank && (req_row != disp_row);
	wire snoop_to0 = ((snoop_we && (snoop_col < NCOL)) && (snoop_row == planned_row0)) && (vblank || sel_now);
	wire snoop_to1 = ((snoop_we && (snoop_col < NCOL)) && (snoop_row == planned_row1)) && (vblank || !sel_now);
	reg [511:0] ov0_valid_next;
	reg [511:0] ov1_valid_next;
	always @(*) begin
		if (_sv2v_0)
			;
		ov0_valid_next = ov0_valid;
		ov1_valid_next = ov1_valid;
		if (frame_start) begin
			ov0_valid_next = 1'sb0;
			ov1_valid_next = 1'sb0;
		end
		else if (row_advance) begin
			if (disp_sel)
				ov1_valid_next = 1'sb0;
			else
				ov0_valid_next = 1'sb0;
		end
		if (snoop_to0)
			ov0_valid_next[snoop_col] = 1'b1;
		if (snoop_to1)
			ov1_valid_next[snoop_col] = 1'b1;
	end
	wire disp_stale = !buf_valid[disp_sel] || (buf_row[disp_sel] != disp_row);
	wire load_stale = !buf_valid[~disp_sel] || (buf_row[~disp_sel] != next_row);
	always @(posedge clk)
		if (rst) begin
			loading <= 1'b0;
			scan_req <= 1'b0;
			disp_sel <= 1'b0;
			disp_row <= 1'sb0;
			buf_valid[0] <= 1'b0;
			buf_valid[1] <= 1'b0;
			ov0_valid <= 1'sb0;
			ov1_valid <= 1'sb0;
			vbl_q <= 1'b0;
		end
		else begin
			vbl_q <= vblank;
			ov0_valid <= ov0_valid_next;
			ov1_valid <= ov1_valid_next;
			if (frame_start) begin
				disp_sel <= 1'b0;
				disp_row <= sv2v_cast_AD1AC_signed(FIRST_ROW);
				buf_valid[0] <= 1'b0;
				buf_valid[1] <= 1'b0;
				loading <= 1'b0;
				scan_req <= 1'b0;
			end
			else begin
				if (row_advance) begin
					disp_sel <= ~disp_sel;
					disp_row <= req_row;
				end
				if (!loading) begin
					if (disp_stale) begin
						tgt_sel <= disp_sel;
						tgt_row <= disp_row;
						li <= 9'd0;
						loading <= 1'b1;
					end
					else if (load_stale) begin
						tgt_sel <= ~disp_sel;
						tgt_row <= next_row;
						li <= 9'd0;
						loading <= 1'b1;
					end
				end
				else if (scan_req && scan_ack) begin
					if (tgt_sel)
						lb1[li] <= scan_data;
					else
						lb0[li] <= scan_data;
					scan_req <= 1'b0;
					if (li == (NCOL - 1)) begin
						loading <= 1'b0;
						buf_row[tgt_sel] <= tgt_row;
						buf_valid[tgt_sel] <= 1'b1;
					end
					else
						li <= li + 9'd1;
				end
				else if (!scan_req)
					scan_req <= 1'b1;
			end
			if (snoop_to0)
				ov0[snoop_col] <= snoop_data;
			if (snoop_to1)
				ov1[snoop_col] <= snoop_data;
		end
	assign scan_addr = {tgt_row[8:0], li};
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_video_top_smash_firefix (
	clk,
	rst,
	ce_pix,
	snoop_we,
	snoop_addr,
	snoop_data,
	pal_raddr,
	pal_rdata,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de,
	vblank_irq
);
	parameter signed [31:0] H_ACT = 410;
	parameter signed [31:0] H_FP = 6;
	parameter signed [31:0] H_SYNC = 40;
	parameter signed [31:0] H_BP = 50;
	parameter signed [31:0] V_ACT = 256;
	parameter signed [31:0] V_FP = 13;
	parameter signed [31:0] V_SYNC = 8;
	parameter signed [31:0] V_BP = 12;
	parameter signed [31:0] DISP_ROW0 = 0;
	parameter signed [31:0] NCOL = 512;
	input wire clk;
	input wire rst;
	input wire ce_pix;
	input wire snoop_we;
	input wire [17:0] snoop_addr;
	input wire [15:0] snoop_data;
	output wire [11:0] pal_raddr;
	input wire [15:0] pal_rdata;
	output wire scan_req;
	output wire [17:0] scan_addr;
	input wire [15:0] scan_data;
	input wire scan_ack;
	output wire [7:0] vid_r;
	output wire [7:0] vid_g;
	output wire [7:0] vid_b;
	output wire hsync;
	output wire vsync;
	output wire hblank;
	output wire vblank;
	output wire de;
	output wire vblank_irq;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	wire [17:0] vram_raddr;
	wire [15:0] vram_rdata;
	wire vblank_i;
	wire vblank_scan;
	yunit_video_smash_firefix #(
		.H_ACT(H_ACT),
		.H_FP(H_FP),
		.H_SYNC(H_SYNC),
		.H_BP(H_BP),
		.V_ACT(V_ACT),
		.V_FP(V_FP),
		.V_SYNC(V_SYNC),
		.V_BP(V_BP),
		.DISP_ROW0(DISP_ROW0)
	) u_video(
		.clk(clk),
		.rst(rst),
		.ce_pix(ce_pix),
		.vram_raddr(vram_raddr),
		.vram_rdata(vram_rdata),
		.pal_raddr(pal_raddr),
		.pal_rdata(pal_rdata),
		.vid_r(vid_r),
		.vid_g(vid_g),
		.vid_b(vid_b),
		.hsync(hsync),
		.vsync(vsync),
		.hblank(hblank),
		.vblank(vblank_i),
		.de(de),
		.vblank_raw(vblank_scan),
		.vblank_irq(vblank_irq)
	);
	assign vblank = vblank_i;
	wire scanline_vblank = vblank_scan;
	yunit_scanline_smash_firefix #(
		.FB_ADDR_W(yunit_pkg_FB_ADDR_W),
		.NCOL(NCOL),
		.FIRST_ROW(DISP_ROW0)
	) u_scan(
		.clk(clk),
		.rst(rst),
		.ce_pix(ce_pix),
		.vblank(scanline_vblank),
		.vram_raddr(vram_raddr),
		.vram_rdata(vram_rdata),
		.snoop_we(snoop_we),
		.snoop_addr(snoop_addr),
		.snoop_data(snoop_data),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack)
	);
endmodule
`default_nettype wire
`default_nettype none
module yunit_top_smash_firefix (
	clk,
	clk_cpu,
	ce_pix,
	cpu_div_sel,
	clk_snd,
	rst,
	rst_pon,
	sdram_por,
	inputs,
	game_id,
	term2_analog,
	cmos_quiesce,
	nvram_ext_en,
	nvram_ext_wr,
	nvram_ext_addr,
	nvram_ext_wdata,
	nvram_ext_rdata,
	cmos_cpu_busy,
	cmos_cpu_write_pulse,
	ioctl_download,
	gfx_download,
	sound_download,
	ioctl_wr,
	ioctl_addr,
	ioctl_dout,
	ioctl_be,
	ioctl_wait,
	snd_dl_wr,
	snd_dl_addr,
	snd_dl_data,
	SDRAM_DQ,
	SDRAM_A,
	SDRAM_BA,
	SDRAM_DQML,
	SDRAM_DQMH,
	SDRAM_nCS,
	SDRAM_nRAS,
	SDRAM_nCAS,
	SDRAM_nWE,
	SDRAM_CKE,
	DDRAM_ADDR,
	DDRAM_BURSTCNT,
	DDRAM_RD,
	DDRAM_DIN,
	DDRAM_BE,
	DDRAM_WE,
	DDRAM_BUSY,
	DDRAM_DOUT,
	DDRAM_DOUT_READY,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de,
	audio_l,
	audio_r,
	adpcm_irq,
	pc_dbg,
	illegal_dbg,
	dbg_core_rst,
	dbg_sdram_ready,
	dbg_unp_done,
	dbg_cpu_req,
	dbg_mem_ack,
	dbg_int1,
	dbg_vblank_irq,
	dbg_cpu_ce,
	dbg_p1ctrl,
	dbg_bdir,
	dbg_snd_select,
	dbg_snd_trig,
	dbg_derailed,
	dbg_culprit_pc,
	dbg_culprit_instr,
	dbg_derail_pc,
	dbg_disp_flips,
	dbg_disp_rows,
	autoerase_off,
	dbg_iol_drop,
	dbg_iol_wrs,
	dbg_dma_we,
	dbg_dma_addr,
	dbg_dma_wdata,
	dbg_src_data,
	dbg_src_ack,
	dbg_scan_data,
	dbg_scan_ack,
	dbg_cgfx_grants,
	dbg_snd_grants,
	dbg_cgfx_maxwait,
	dbg_snd_miss,
	dbg_snd_busy16,
	dbg_cvsd_moves,
	dbg_adpcm_moves,
	dbg_blank_pix,
	dbg_cpu_pc_moves,
	dbg_snd_acks,
	dbg_snd_first_words,
	dbg_snd_region_seen,
	dbg_snd_board_rst,
	dbg_restart_cnt
);
	reg _sv2v_0;
	parameter ROM_HEX = "smashtv_maindata.hex";
	parameter signed [31:0] H_ACT = 410;
	parameter signed [31:0] H_FP = 6;
	parameter signed [31:0] H_SYNC = 40;
	parameter signed [31:0] H_BP = 50;
	parameter signed [31:0] V_ACT = 256;
	parameter signed [31:0] V_FP = 13;
	parameter signed [31:0] V_SYNC = 8;
	parameter signed [31:0] V_BP = 12;
	parameter signed [31:0] DISP_ROW0 = 0;
	parameter [24:0] GFXW_BASE = 25'h0000000;
	parameter [24:0] ROMW_BASE = 25'h00c0000;
	parameter [24:0] VRAMW_BASE = 25'h00e0000;
	parameter [23:0] GFX_BYTES = 24'h180000;
	parameter [24:0] SCRATCH_WBASE = 25'h0120000;
	parameter [24:0] SOUNDW_BASE = 25'h0120000;
	parameter [23:0] PLANE_WORDS = 24'h030000;
	input wire clk;
	input wire clk_cpu;
	input wire ce_pix;
	input wire [2:0] cpu_div_sel;
	input wire clk_snd;
	input wire rst;
	input wire rst_pon;
	input wire sdram_por;
	input wire [63:0] inputs;
	input wire [3:0] game_id;
	input wire [31:0] term2_analog;
	input wire cmos_quiesce;
	input wire nvram_ext_en;
	input wire nvram_ext_wr;
	input wire [14:0] nvram_ext_addr;
	input wire [7:0] nvram_ext_wdata;
	output wire [7:0] nvram_ext_rdata;
	output wire cmos_cpu_busy;
	output wire cmos_cpu_write_pulse;
	input wire ioctl_download;
	input wire gfx_download;
	input wire sound_download;
	input wire ioctl_wr;
	input wire [24:0] ioctl_addr;
	input wire [15:0] ioctl_dout;
	input wire [1:0] ioctl_be;
	output wire ioctl_wait;
	input wire snd_dl_wr;
	input wire [17:0] snd_dl_addr;
	input wire [7:0] snd_dl_data;
	inout wire [15:0] SDRAM_DQ;
	output wire [12:0] SDRAM_A;
	output wire [1:0] SDRAM_BA;
	output wire SDRAM_DQML;
	output wire SDRAM_DQMH;
	output wire SDRAM_nCS;
	output wire SDRAM_nRAS;
	output wire SDRAM_nCAS;
	output wire SDRAM_nWE;
	output wire SDRAM_CKE;
	output wire [28:0] DDRAM_ADDR;
	output wire [7:0] DDRAM_BURSTCNT;
	output wire DDRAM_RD;
	output wire [63:0] DDRAM_DIN;
	output wire [7:0] DDRAM_BE;
	output wire DDRAM_WE;
	input wire DDRAM_BUSY;
	input wire [63:0] DDRAM_DOUT;
	input wire DDRAM_DOUT_READY;
	output wire [7:0] vid_r;
	output wire [7:0] vid_g;
	output wire [7:0] vid_b;
	output wire hsync;
	output wire vsync;
	output wire hblank;
	output wire vblank;
	output wire de;
	output wire signed [15:0] audio_l;
	output wire signed [15:0] audio_r;
	output wire adpcm_irq;
	output wire [31:0] pc_dbg;
	output wire illegal_dbg;
	output wire dbg_core_rst;
	output wire dbg_sdram_ready;
	output wire dbg_unp_done;
	output wire dbg_cpu_req;
	output wire dbg_mem_ack;
	output wire dbg_int1;
	output wire dbg_vblank_irq;
	output wire dbg_cpu_ce;
	output wire [31:0] dbg_p1ctrl;
	output wire [31:0] dbg_bdir;
	output wire [7:0] dbg_snd_select;
	output wire dbg_snd_trig;
	output reg dbg_derailed;
	output reg [31:0] dbg_culprit_pc;
	output reg [15:0] dbg_culprit_instr;
	output reg [31:0] dbg_derail_pc;
	output wire [31:0] dbg_disp_flips;
	output wire [31:0] dbg_disp_rows;
	input wire autoerase_off;
	output wire [31:0] dbg_iol_drop;
	output wire [31:0] dbg_iol_wrs;
	output wire dbg_dma_we;
	output wire [3:0] dbg_dma_addr;
	output wire [15:0] dbg_dma_wdata;
	output wire [7:0] dbg_src_data;
	output wire dbg_src_ack;
	output wire [15:0] dbg_scan_data;
	output wire dbg_scan_ack;
	output wire [15:0] dbg_cgfx_grants;
	output wire [15:0] dbg_snd_grants;
	output wire [31:0] dbg_cgfx_maxwait;
	output wire [15:0] dbg_snd_miss;
	output wire [15:0] dbg_snd_busy16;
	output wire [15:0] dbg_cvsd_moves;
	output wire [15:0] dbg_adpcm_moves;
	output wire [15:0] dbg_blank_pix;
	output wire [31:0] dbg_cpu_pc_moves;
	output wire [31:0] dbg_snd_acks;
	output wire [31:0] dbg_snd_first_words;
	output wire dbg_snd_region_seen;
	output wire dbg_snd_board_rst;
	output wire [15:0] dbg_restart_cnt;
	assign nvram_ext_rdata = 8'h00;
	assign cmos_cpu_busy = 1'b0;
	assign cmos_cpu_write_pulse = 1'b0;
	assign adpcm_irq = 1'b0;
	wire unused_wrapper_inputs = ^{game_id, term2_analog, cmos_quiesce, nvram_ext_en, nvram_ext_wr, nvram_ext_addr, nvram_ext_wdata, gfx_download, sound_download, SOUNDW_BASE, GFX_BYTES};
	wire sdram_ready;
	wire unp_done;
	wire core_rst = ((rst | ~sdram_ready) | ioctl_download) | ~unp_done;
	reg [4:0] cpu_ce_div;
	always @(*) begin
		if (_sv2v_0)
			;
		case (cpu_div_sel)
			3'd0: cpu_ce_div = 5'd4;
			3'd1: cpu_ce_div = 5'd6;
			3'd2: cpu_ce_div = 5'd8;
			3'd3: cpu_ce_div = 5'd10;
			3'd4: cpu_ce_div = 5'd12;
			3'd5: cpu_ce_div = 5'd14;
			3'd6: cpu_ce_div = 5'd16;
			default: cpu_ce_div = 5'd20;
		endcase
	end
	reg [4:0] ce_div;
	always @(posedge clk)
		if (rst)
			ce_div <= 5'd0;
		else
			ce_div <= (ce_div == (cpu_ce_div - 5'd1) ? 5'd0 : ce_div + 5'd1);
	wire cpu_ce = ce_div == 5'd0;
	reg core_rst_sys_m;
	reg core_rst_sys;
	always @(posedge clk) begin
		core_rst_sys_m <= core_rst;
		core_rst_sys <= core_rst_sys_m;
	end
	wire int1;
	wire cpu_req;
	wire cpu_we;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	wire [31:0] cpu_addr;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	wire [5:0] cpu_size;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	wire [31:0] cpu_wdata;
	wire [31:0] cpu_rdata;
	wire cpu_ack;
	wire [5:0] state_w;
	localparam [31:0] tms34010_pkg_INSTR_WORD_WIDTH = 16;
	wire [15:0] instr_w;
	reg ce_pix_ph;
	wire timing_start;
	always @(posedge clk)
		if (core_rst_sys || timing_start)
			ce_pix_ph <= 1'b0;
		else if (ce_pix)
			ce_pix_ph <= ~ce_pix_ph;
	wire ce_pix_cnt = ce_pix & ce_pix_ph;
	tms34010_core u_core(
		.clk(clk),
		.ce_cpu(cpu_ce),
		.ce_pix(ce_pix_cnt),
		.rst(core_rst_sys),
		.mem_req(cpu_req),
		.mem_we(cpu_we),
		.mem_addr(cpu_addr),
		.mem_size(cpu_size),
		.mem_wdata(cpu_wdata),
		.mem_rdata(cpu_rdata),
		.mem_ack(cpu_ack),
		.state_o(state_w),
		.pc_o(pc_dbg),
		.instr_word_o(instr_w),
		.illegal_opcode_o(illegal_dbg),
		.srt_fill_ack_i(1'b0),
		.instruction_start_o(),
		.instruction_retire_o(),
		.instruction_cycles_o(),
		.instruction_cycles_valid_o(),
		.timing_start_o(timing_start),
		.display_wr_valid_o(),
		.display_wr_idx_o(),
		.display_wr_data_o(),
		.display_line_wrap_o(),
		.display_dpyadr_live_i(16'd0),
		.display_dpyadr_live_valid_i(1'b0),
		.srt_fill_exact_enable_i(1'b0),
		.shiftreg_req_o(),
		.shiftreg_write_o(),
		.shiftreg_bit_addr_o(),
		.lint1_in(int1)
	);
	wire mem_req;
	wire mem_we;
	wire [31:0] mem_addr;
	wire [5:0] mem_size;
	wire [31:0] mem_wdata;
	wire [31:0] mem_rdata;
	wire mem_ack;
	yunit_mem_cdc #(
		.AW(tms34010_pkg_ADDR_WIDTH),
		.DW(tms34010_pkg_DATA_WIDTH),
		.SW(tms34010_pkg_FIELD_SIZE_WIDTH)
	) u_memcdc(
		.clk_cpu(clk),
		.ce_cpu(cpu_ce),
		.rst_cpu(core_rst_sys),
		.c_req(cpu_req),
		.c_we(cpu_we),
		.c_addr(cpu_addr),
		.c_size(cpu_size),
		.c_wdata(cpu_wdata),
		.c_ack(cpu_ack),
		.c_rdata(cpu_rdata),
		.clk_sys(clk),
		.rst_sys(core_rst_sys),
		.m_req(mem_req),
		.m_we(mem_we),
		.m_addr(mem_addr),
		.m_size(mem_size),
		.m_wdata(mem_wdata),
		.m_rdata(mem_rdata),
		.m_ack(mem_ack)
	);
	wire src_req;
	wire [23:0] src_addr;
	wire [7:0] src_data;
	wire src_ack;
	wire cgfx_rd;
	wire [23:0] cgfx_addr;
	wire [15:0] cgfx_data;
	wire cgfx_ack;
	wire scan_req;
	wire [17:0] scan_addr;
	wire [15:0] scan_data;
	wire scan_ack;
	wire [7:0] snd_select;
	wire snd_trig;
	wire snd_reset;
	assign dbg_snd_select = snd_select;
	assign dbg_snd_trig = snd_trig;
	wire erase_busy;
	wire blit_busy;
	wire fb_snoop_we;
	wire [17:0] fb_snoop_addr;
	wire [15:0] fb_snoop_data;
	wire palv_we_a;
	wire palv_we_b;
	wire [12:0] palv_aa;
	wire [12:0] palv_ba;
	wire [15:0] palv_awd;
	wire [15:0] palv_bwd;
	wire vblank_irq;
	function automatic signed [8:0] sv2v_cast_9_signed;
		input reg signed [8:0] inp;
		sv2v_cast_9_signed = inp;
	endfunction
	function automatic signed [9:0] sv2v_cast_10_signed;
		input reg signed [9:0] inp;
		sv2v_cast_10_signed = inp;
	endfunction
	yunit_memsys_smash_firefix #(.ROM_HEX(ROM_HEX)) u_sys(
		.clk(clk),
		.rst(core_rst),
		.mem_req(mem_req),
		.mem_we(mem_we),
		.mem_addr(mem_addr),
		.mem_size(mem_size),
		.mem_wdata(mem_wdata),
		.mem_rdata(mem_rdata),
		.mem_ack(mem_ack),
		.src_req(src_req),
		.src_addr(src_addr),
		.src_data(src_data),
		.src_ack(src_ack),
		.inputs(inputs),
		.int1(int1),
		.snd_select(snd_select),
		.snd_trig(snd_trig),
		.snd_reset(snd_reset),
		.dbg_p1ctrl(dbg_p1ctrl),
		.dbg_bdir(dbg_bdir),
		.erase_start(vblank_irq),
		.erase_row0(sv2v_cast_9_signed(DISP_ROW0)),
		.erase_lines(sv2v_cast_10_signed(V_ACT)),
		.erase_busy(erase_busy),
		.blit_busy(blit_busy),
		.fb_snoop_we(fb_snoop_we),
		.fb_snoop_addr(fb_snoop_addr),
		.fb_snoop_data(fb_snoop_data),
		.dbg_dma_we(dbg_dma_we),
		.dbg_dma_addr(dbg_dma_addr),
		.dbg_dma_wdata(dbg_dma_wdata),
		.cpu_gfx_rd(cgfx_rd),
		.cpu_gfx_raddr(cgfx_addr),
		.cpu_gfx_rdata(cgfx_data),
		.cpu_gfx_rack(cgfx_ack),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack),
		.sdram_por(sdram_por),
		.ddram_addr(DDRAM_ADDR),
		.ddram_burstcnt(DDRAM_BURSTCNT),
		.ddram_rd(DDRAM_RD),
		.ddram_we(DDRAM_WE),
		.ddram_din(DDRAM_DIN),
		.ddram_be(DDRAM_BE),
		.ddram_busy(DDRAM_BUSY),
		.ddram_dout(DDRAM_DOUT),
		.ddram_dout_ready(DDRAM_DOUT_READY),
		.palv_we_a(palv_we_a),
		.palv_aa(palv_aa),
		.palv_awd(palv_awd),
		.palv_we_b(palv_we_b),
		.palv_ba(palv_ba),
		.palv_bwd(palv_bwd)
	);
	wire [11:0] pal_raddr;
	wire [15:0] pal_rdata;
	wire video_rst = core_rst_sys;
	wire video_phase_rst = video_rst | timing_start;
	yunit_video_top_smash_firefix #(
		.H_ACT(H_ACT),
		.H_FP(H_FP),
		.H_SYNC(H_SYNC),
		.H_BP(H_BP),
		.V_ACT(V_ACT),
		.V_FP(V_FP),
		.V_SYNC(V_SYNC),
		.V_BP(V_BP),
		.DISP_ROW0(DISP_ROW0),
		.NCOL(H_ACT)
	) u_video(
		.clk(clk),
		.rst(video_phase_rst),
		.ce_pix(ce_pix),
		.snoop_we(fb_snoop_we),
		.snoop_addr(fb_snoop_addr),
		.snoop_data(fb_snoop_data),
		.pal_raddr(pal_raddr),
		.pal_rdata(pal_rdata),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack),
		.vid_r(vid_r),
		.vid_g(vid_g),
		.vid_b(vid_b),
		.hsync(hsync),
		.vsync(vsync),
		.hblank(hblank),
		.vblank(vblank),
		.de(de),
		.vblank_irq(vblank_irq)
	);
	yunit_palram #(.AW(13)) u_pal(
		.clk(clk),
		.rst(core_rst),
		.we_a(palv_we_a),
		.aa(palv_aa),
		.awd(palv_awd),
		.we_b(palv_we_b),
		.ba(palv_ba),
		.bwd(palv_bwd),
		.raddr({1'b0, pal_raddr}),
		.rdata(pal_rdata)
	);
	wire [24:0] sd_addr;
	wire [15:0] sd_din;
	wire [15:0] sd_dout;
	wire [1:0] sd_be;
	wire sd_rd;
	wire sd_wr;
	wire sd_ack;
	wire iol_ack;
	localparam signed [31:0] IOL_AW = 9;
	localparam signed [31:0] IOL_HWM = 256;
	reg [42:0] iol_fifo [0:511];
	reg [IOL_AW:0] iol_wp;
	reg [IOL_AW:0] iol_rp;
	wire [IOL_AW:0] iol_occ = iol_wp - iol_rp;
	wire iol_full = iol_occ == 512;
	wire iol_empty = iol_wp == iol_rp;
	reg iol_hold;
	reg unp_owner;
	reg [24:0] iol_addr_r;
	reg [15:0] iol_din_r;
	reg [1:0] iol_be_r;
	reg [31:0] iol_drop_cnt;
	reg [31:0] iol_wr_cnt;
	always @(posedge clk)
		if (sdram_por) begin
			iol_wp <= 1'sb0;
			iol_rp <= 1'sb0;
			iol_hold <= 1'b0;
			iol_drop_cnt <= 1'sb0;
			iol_wr_cnt <= 1'sb0;
		end
		else begin
			if (ioctl_wr && !iol_full) begin
				iol_fifo[iol_wp[8:0]] <= {ioctl_addr, ioctl_dout, ioctl_be};
				iol_wp <= iol_wp + 1'b1;
				iol_wr_cnt <= iol_wr_cnt + 1'b1;
			end
			else if (ioctl_wr && iol_full)
				iol_drop_cnt <= iol_drop_cnt + 1'b1;
			if (!unp_owner) begin
				if (iol_hold && iol_ack)
					iol_hold <= 1'b0;
				if ((!iol_hold || (iol_hold && iol_ack)) && !iol_empty) begin
					{iol_addr_r, iol_din_r, iol_be_r} <= iol_fifo[iol_rp[8:0]];
					iol_hold <= 1'b1;
					iol_rp <= iol_rp + 1'b1;
				end
			end
		end
	assign ioctl_wait = iol_occ >= IOL_HWM[IOL_AW:0];
	wire unp_rd;
	wire unp_wr;
	wire unp_ack;
	wire [24:0] unp_addr;
	wire [15:0] unp_din;
	wire [15:0] unp_dout;
	wire b_iol_rd = (unp_owner ? unp_rd : 1'b0);
	wire b_iol_wr = (unp_owner ? unp_wr : iol_hold);
	wire [24:0] b_iol_addr = (unp_owner ? unp_addr : iol_addr_r);
	wire [15:0] b_iol_din = (unp_owner ? unp_din : iol_din_r);
	wire [1:0] b_iol_be = (unp_owner ? 2'b11 : iol_be_r);
	wire [15:0] iol_dout;
	assign unp_dout = iol_dout;
	assign unp_ack = (iol_ack & unp_owner) & (unp_rd | unp_wr);
	yunit_sdram_arb #(
		.SD_AW(25),
		.GFXW_BASE(GFXW_BASE),
		.ROMW_BASE(ROMW_BASE),
		.VRAMW_BASE(VRAMW_BASE),
		.GFX_BYTES(24'h180000)
	) u_arb(
		.clk(clk),
		.rst(sdram_por),
		.vsd_addr(25'd0),
		.vsd_din(16'd0),
		.vsd_be(2'd0),
		.vsd_rd(1'b0),
		.vsd_wr(1'b0),
		.vsd_dout(),
		.vsd_ack(),
		.cgfx_rd(cgfx_rd),
		.cgfx_addr(cgfx_addr),
		.cgfx_data(cgfx_data),
		.cgfx_ack(cgfx_ack),
		.src_rd(1'b0),
		.src_addr(24'd0),
		.src_data(),
		.src_ack(),
		.snd_rd(1'b0),
		.snd_addr(21'd0),
		.snd_data(),
		.snd_ack(),
		.iol_rd(b_iol_rd),
		.iol_wr(b_iol_wr),
		.iol_addr(b_iol_addr),
		.iol_din(b_iol_din),
		.iol_be(b_iol_be),
		.iol_dout(iol_dout),
		.iol_ack(iol_ack),
		.sd_addr(sd_addr),
		.sd_din(sd_din),
		.sd_be(sd_be),
		.sd_rd(sd_rd),
		.sd_wr(sd_wr),
		.sd_dout(sd_dout),
		.sd_ack(sd_ack)
	);
	reg dl_q;
	reg dl_seen;
	reg unp_pending;
	reg unp_start;
	wire unp_fsm_done;
	reg unp_done_q;
	always @(posedge clk) begin
		dl_q <= ioctl_download;
		unp_start <= 1'b0;
		unp_done_q <= unp_fsm_done;
		if (sdram_por) begin
			dl_seen <= 1'b0;
			unp_pending <= 1'b0;
			unp_owner <= 1'b0;
			unp_done_q <= 1'b0;
		end
		else begin
			if (ioctl_download)
				dl_seen <= 1'b1;
			if (dl_q & ~ioctl_download)
				unp_pending <= 1'b1;
			else if ((unp_pending & ~iol_hold) & ~unp_owner) begin
				unp_pending <= 1'b0;
				unp_start <= 1'b1;
				unp_owner <= 1'b1;
			end
			if ((unp_owner && unp_fsm_done) && !unp_done_q)
				unp_owner <= 1'b0;
		end
	end
	yunit_gfx_unpack #(
		.SD_AW(25),
		.SCRATCH_WBASE(SCRATCH_WBASE),
		.GFXW_BASE(GFXW_BASE),
		.PLANE_WORDS(PLANE_WORDS)
	) u_unpack(
		.clk(clk),
		.rst(sdram_por),
		.start(unp_start),
		.plane_words(PLANE_WORDS),
		.bpp4(1'b0),
		.busy(),
		.done(unp_fsm_done),
		.unp_rd(unp_rd),
		.unp_wr(unp_wr),
		.unp_addr(unp_addr),
		.unp_din(unp_din),
		.unp_dout(unp_dout),
		.unp_ack(unp_ack)
	);
	assign unp_done = ~dl_seen | unp_fsm_done;
	wire brd_req;
	wire [24:0] brd_addr;
	wire [9:0] brd_len;
	wire [15:0] brd_dout;
	wire brd_dvalid;
	wire brd_done;
	yunit_src_cache #(.GFXW_BASE(GFXW_BASE[23:0])) u_srccache(
		.clk(clk),
		.rst(core_rst),
		.src_req(src_req),
		.src_addr(src_addr),
		.src_data(src_data),
		.src_ack(src_ack),
		.brd_req(brd_req),
		.brd_addr(brd_addr),
		.brd_len(brd_len),
		.brd_dout(brd_dout),
		.brd_dvalid(brd_dvalid),
		.brd_done(brd_done)
	);
	wire [24:0] ctl_addr;
	wire [15:0] ctl_din;
	wire [15:0] ctl_dout;
	wire [1:0] ctl_wtbt;
	wire ctl_rd;
	wire ctl_we;
	wire ctl_ready;
	yunit_sdram_adapter u_sdadapt(
		.clk(clk),
		.rst(sdram_por),
		.sd_addr(sd_addr),
		.sd_din(sd_din),
		.sd_be(sd_be),
		.sd_rd(sd_rd),
		.sd_wr(sd_wr),
		.sd_dout(sd_dout),
		.sd_ack(sd_ack),
		.sdram_ready(sdram_ready),
		.ctl_addr(ctl_addr),
		.ctl_din(ctl_din),
		.ctl_wtbt(ctl_wtbt),
		.ctl_rd(ctl_rd),
		.ctl_we(ctl_we),
		.ctl_dout(ctl_dout),
		.ctl_ready(ctl_ready)
	);
	sdram_stock u_sdram(
		.init(sdram_por),
		.clk(clk),
		.addr(ctl_addr),
		.din(ctl_din),
		.wtbt(ctl_wtbt),
		.we(ctl_we),
		.rd(ctl_rd),
		.dout(ctl_dout),
		.ready(ctl_ready),
		.brd_req(brd_req),
		.brd_addr(brd_addr),
		.brd_len(brd_len),
		.brd_dout(brd_dout),
		.brd_dvalid(brd_dvalid),
		.brd_done(brd_done),
		.bwr_req(1'b0),
		.bwr_addr(25'd0),
		.bwr_len(10'd0),
		.bwr_din(16'd0),
		.bwr_wtbt(2'b00),
		.bwr_valid(1'b0),
		.bwr_ready(),
		.bwr_done(),
		.SDRAM_DQ(SDRAM_DQ),
		.SDRAM_A(SDRAM_A),
		.SDRAM_BA(SDRAM_BA),
		.SDRAM_DQML(SDRAM_DQML),
		.SDRAM_DQMH(SDRAM_DQMH),
		.SDRAM_nCS(SDRAM_nCS),
		.SDRAM_nRAS(SDRAM_nRAS),
		.SDRAM_nCAS(SDRAM_nCAS),
		.SDRAM_nWE(SDRAM_nWE),
		.SDRAM_CKE(SDRAM_CKE)
	);
	wire [7:0] sel_sync;
	wire strig_snd;
	wire srst_snd;
	yunit_sound_cdc u_sound_cdc(
		.clk_sys(clk),
		.clk_snd(clk_snd),
		.rst_pon(rst_pon),
		.snd_select(snd_select),
		.snd_trig(snd_trig),
		.snd_reset(snd_reset),
		.sel_snd(sel_sync),
		.trig_snd(strig_snd),
		.reset_snd(srst_snd)
	);
	wire [7:0] pia_audio;
	wire [15:0] speech_out;
	wire signed [15:0] ym_l;
	wire signed [15:0] ym_r;
	wire [31:0] snd_dbg;
	williams_cvsd_board u_board(
		.clock_12(clk_snd),
		.reset(srst_snd),
		.reset_pon(rst_pon),
		.sound_select(sel_sync),
		.sound_trig(strig_snd),
		.game_id(4'd0),
		.pia_audio(pia_audio),
		.speech_out(speech_out),
		.ym2151_left(ym_l),
		.ym2151_right(ym_r),
		.dbg_out(snd_dbg),
		.snd_dl_clk(clk),
		.snd_dl_addr(snd_dl_addr),
		.snd_dl_data(snd_dl_data),
		.snd_dl_we(snd_dl_wr),
		.use_ext_rom(1'b0),
		.ext_rom_addr(),
		.ext_rom_data(8'h00),
		.ext_rom_ok(1'b0)
	);
	yunit_audio_mix u_audio_mix(
		.clk(clk_snd),
		.rst(rst_pon),
		.ym_l(ym_l),
		.ym_r(ym_r),
		.speech_u(speech_out),
		.pia_u(pia_audio),
		.audio_l(audio_l),
		.audio_r(audio_r)
	);
	assign dbg_core_rst = core_rst;
	assign dbg_sdram_ready = sdram_ready;
	assign dbg_unp_done = unp_done;
	assign dbg_cpu_req = cpu_req;
	assign dbg_mem_ack = mem_ack;
	assign dbg_int1 = int1;
	assign dbg_vblank_irq = vblank_irq;
	assign dbg_src_data = src_data;
	assign dbg_src_ack = src_ack;
	assign dbg_scan_data = scan_data;
	assign dbg_scan_ack = scan_ack;
	assign dbg_cpu_ce = cpu_ce;
	assign dbg_iol_drop = iol_drop_cnt;
	assign dbg_iol_wrs = iol_wr_cnt;
	assign dbg_disp_flips = 32'd0;
	assign dbg_disp_rows = 32'd0;
	assign dbg_cgfx_grants = 16'd0;
	assign dbg_snd_grants = 16'd0;
	assign dbg_cgfx_maxwait = 32'd0;
	assign dbg_snd_miss = 16'd0;
	assign dbg_snd_busy16 = 16'd0;
	assign dbg_cvsd_moves = 16'd0;
	assign dbg_adpcm_moves = 16'd0;
	assign dbg_blank_pix = 16'd0;
	assign dbg_cpu_pc_moves = 32'd0;
	assign dbg_snd_acks = 32'd0;
	assign dbg_snd_first_words = 32'd0;
	assign dbg_snd_region_seen = 1'b0;
	assign dbg_snd_board_rst = 1'b0;
	assign dbg_restart_cnt = 16'd0;
	reg [1:0] rd_cnt;
	reg ack_q;
	reg d_started;
	reg [31:0] d_prevpc;
	always @(posedge clk)
		if (cpu_ce) begin
			if (core_rst_sys) begin
				dbg_derailed <= 1'b0;
				rd_cnt <= 2'd0;
				ack_q <= 1'b0;
				d_started <= 1'b0;
				d_prevpc <= 32'hffffffff;
				dbg_culprit_pc <= 32'hdeadbeef;
				dbg_culprit_instr <= 16'h0000;
				dbg_derail_pc <= 32'hdeadbeef;
			end
			else begin
				ack_q <= cpu_ack;
				if (((cpu_ack && !ack_q) && !cpu_we) && (rd_cnt == 2'd0)) begin
					dbg_culprit_pc <= cpu_rdata;
					rd_cnt <= 2'd1;
				end
				if (pc_dbg !== d_prevpc) begin
					if (pc_dbg == 32'hffe0f5c0) begin
						dbg_derail_pc <= d_prevpc;
						dbg_culprit_instr <= dbg_culprit_instr + 16'd1;
					end
					d_prevpc <= pc_dbg;
					if (pc_dbg[31:23] == 9'h1ff)
						d_started <= 1'b1;
				end
			end
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_service_counters (
	clk,
	rst,
	frame_tick,
	cgfx_rd,
	cgfx_ack,
	snd_rd,
	snd_ack,
	snd_rdata,
	cvsd_addr,
	adpcm_addr,
	cpu_ce,
	pc,
	in_active,
	de,
	pix_ce,
	cnt_cgfx_grants,
	cnt_snd_grants,
	cnt_cgfx_maxwait,
	cnt_snd_miss,
	cnt_snd_busy16,
	cnt_cvsd_moves,
	cnt_adpcm_moves,
	cnt_blank_pix,
	cnt_cpu_pc_moves,
	cnt_snd_acks,
	snd_first_words,
	snd_region_seen
);
	input wire clk;
	input wire rst;
	input wire frame_tick;
	input wire cgfx_rd;
	input wire cgfx_ack;
	input wire snd_rd;
	input wire snd_ack;
	input wire [15:0] snd_rdata;
	input wire [20:0] cvsd_addr;
	input wire [20:0] adpcm_addr;
	input wire cpu_ce;
	input wire [31:0] pc;
	input wire in_active;
	input wire de;
	input wire pix_ce;
	output reg [15:0] cnt_cgfx_grants;
	output reg [15:0] cnt_snd_grants;
	output reg [31:0] cnt_cgfx_maxwait;
	output reg [15:0] cnt_snd_miss;
	output reg [15:0] cnt_snd_busy16;
	output reg [15:0] cnt_cvsd_moves;
	output reg [15:0] cnt_adpcm_moves;
	output reg [15:0] cnt_blank_pix;
	output reg [31:0] cnt_cpu_pc_moves;
	output reg [31:0] cnt_snd_acks;
	output reg [31:0] snd_first_words;
	output reg snd_region_seen;
	function automatic [15:0] inc16;
		input reg [15:0] v;
		inc16 = (v == 16'hffff ? 16'hffff : v + 16'd1);
	endfunction
	function automatic [31:0] inc32;
		input reg [31:0] v;
		inc32 = (v == 32'hffffffff ? 32'hffffffff : v + 32'd1);
	endfunction
	reg [15:0] a_cgfx;
	reg [15:0] a_snd;
	reg [15:0] a_miss;
	reg [15:0] a_blank;
	reg [15:0] a_cvsd;
	reg [15:0] a_adpcm;
	reg [31:0] a_pcmov;
	reg [31:0] a_wait;
	reg [31:0] a_waitmax;
	reg [31:0] a_busy;
	reg snd_rd_q;
	reg [20:0] cvsd_q;
	reg [20:0] adpcm_q;
	reg [31:0] pc_q;
	reg [1:0] first_words_got;
	wire snd_fetch_start = snd_rd & ~snd_rd_q;
	always @(posedge clk)
		if (rst) begin
			a_cgfx <= 16'd0;
			a_snd <= 16'd0;
			a_miss <= 16'd0;
			a_blank <= 16'd0;
			a_cvsd <= 16'd0;
			a_adpcm <= 16'd0;
			a_pcmov <= 32'd0;
			a_wait <= 32'd0;
			a_waitmax <= 32'd0;
			a_busy <= 32'd0;
			snd_rd_q <= 1'b0;
			cvsd_q <= 21'd0;
			adpcm_q <= 21'd0;
			pc_q <= 32'hffffffff;
			cnt_cgfx_grants <= 16'd0;
			cnt_snd_grants <= 16'd0;
			cnt_cgfx_maxwait <= 32'd0;
			cnt_snd_miss <= 16'd0;
			cnt_snd_busy16 <= 16'd0;
			cnt_cvsd_moves <= 16'd0;
			cnt_adpcm_moves <= 16'd0;
			cnt_blank_pix <= 16'd0;
			cnt_cpu_pc_moves <= 32'd0;
			cnt_snd_acks <= 32'd0;
			snd_first_words <= 32'd0;
			first_words_got <= 2'd0;
			snd_region_seen <= 1'b0;
		end
		else begin
			snd_rd_q <= snd_rd;
			if (cgfx_ack)
				a_cgfx <= inc16(a_cgfx);
			if (snd_ack)
				a_snd <= inc16(a_snd);
			if (snd_rd)
				a_busy <= inc32(a_busy);
			if (cgfx_rd && !cgfx_ack) begin
				a_wait <= inc32(a_wait);
				if (a_wait > a_waitmax)
					a_waitmax <= a_wait;
			end
			else
				a_wait <= 32'd0;
			if (snd_fetch_start)
				a_miss <= inc16(a_miss);
			if (snd_ack) begin
				cnt_snd_acks <= inc32(cnt_snd_acks);
				if (first_words_got == 2'd0) begin
					snd_first_words[31:16] <= snd_rdata;
					first_words_got <= 2'd1;
				end
				else if (first_words_got == 2'd1) begin
					snd_first_words[15:0] <= snd_rdata;
					first_words_got <= 2'd2;
				end
				if ((snd_rdata != 16'h0000) && (snd_rdata != 16'hffff))
					snd_region_seen <= 1'b1;
			end
			cvsd_q <= cvsd_addr;
			adpcm_q <= adpcm_addr;
			if (cvsd_addr != cvsd_q)
				a_cvsd <= inc16(a_cvsd);
			if (adpcm_addr != adpcm_q)
				a_adpcm <= inc16(a_adpcm);
			if ((pix_ce && in_active) && !de)
				a_blank <= inc16(a_blank);
			if (cpu_ce) begin
				pc_q <= pc;
				if (pc != pc_q)
					a_pcmov <= inc32(a_pcmov);
			end
			if (frame_tick) begin
				cnt_cgfx_grants <= a_cgfx;
				a_cgfx <= 16'd0;
				cnt_snd_grants <= a_snd;
				a_snd <= 16'd0;
				cnt_snd_miss <= a_miss;
				a_miss <= 16'd0;
				cnt_blank_pix <= a_blank;
				a_blank <= 16'd0;
				cnt_cvsd_moves <= a_cvsd;
				a_cvsd <= 16'd0;
				cnt_adpcm_moves <= a_adpcm;
				a_adpcm <= 16'd0;
				cnt_cpu_pc_moves <= a_pcmov;
				a_pcmov <= 32'd0;
				cnt_snd_busy16 <= (a_busy > 32'h000fffff ? 16'hffff : a_busy[19:4]);
				a_busy <= 32'd0;
				cnt_cgfx_maxwait <= (a_wait > a_waitmax ? a_wait : a_waitmax);
				a_waitmax <= 32'd0;
			end
		end
endmodule
`default_nettype wire
`default_nettype none
module family2_cabinet_inputs (
	game_id,
	joy0,
	joy1,
	joy2,
	joy3,
	dsw_raw,
	adpcm_irq,
	inputs
);
	reg _sv2v_0;
	input wire [3:0] game_id;
	input wire [15:0] joy0;
	input wire [15:0] joy1;
	input wire [15:0] joy2;
	input wire [15:0] joy3;
	input wire [15:0] dsw_raw;
	input wire adpcm_irq;
	output reg [63:0] inputs;
	reg [15:0] in0;
	reg [15:0] in1;
	reg [15:0] in2;
	reg [15:0] dsw;
	reg test_mode;
	reg [3:0] start_bit;
	reg [3:0] coin_bit;
	localparam [3:0] yunit_pkg_YG_HIIMPACT = 4'd2;
	localparam [3:0] yunit_pkg_YG_MK = 4'd5;
	localparam [3:0] yunit_pkg_YG_SAURNFRNT = 4'd9;
	localparam [3:0] yunit_pkg_YG_SHIMPACT = 4'd3;
	localparam [3:0] yunit_pkg_YG_SMASHTV = 4'd0;
	localparam [3:0] yunit_pkg_YG_STRKFORC = 4'd4;
	localparam [3:0] yunit_pkg_YG_TERM2 = 4'd6;
	localparam [3:0] yunit_pkg_YG_TOTCARN = 4'd7;
	localparam [3:0] yunit_pkg_YG_TROG = 4'd1;
	localparam [3:0] yunit_pkg_YG_YUNITTST = 4'd8;
	function automatic [3:0] yunit_pkg_yunit_action_buttons;
		input reg [3:0] game;
		case (game)
			yunit_pkg_YG_SMASHTV: yunit_pkg_yunit_action_buttons = 4'd5;
			yunit_pkg_YG_STRKFORC, yunit_pkg_YG_SAURNFRNT: yunit_pkg_yunit_action_buttons = 4'd3;
			yunit_pkg_YG_MK: yunit_pkg_yunit_action_buttons = 4'd6;
			yunit_pkg_YG_TERM2: yunit_pkg_yunit_action_buttons = 4'd4;
			yunit_pkg_YG_TOTCARN: yunit_pkg_yunit_action_buttons = 4'd4;
			default: yunit_pkg_yunit_action_buttons = 4'd1;
		endcase
	endfunction
	function automatic [3:0] yunit_pkg_yunit_coin_bit;
		input reg [3:0] game;
		yunit_pkg_yunit_coin_bit = 4'd5 + yunit_pkg_yunit_action_buttons(game);
	endfunction
	function automatic [3:0] yunit_pkg_yunit_start_bit;
		input reg [3:0] game;
		yunit_pkg_yunit_start_bit = 4'd4 + yunit_pkg_yunit_action_buttons(game);
	endfunction
	function automatic yunit_pkg_yunit_test_mode;
		input reg [3:0] game;
		input reg [15:0] dsw;
		case (game)
			yunit_pkg_YG_SMASHTV, yunit_pkg_YG_STRKFORC: yunit_pkg_yunit_test_mode = ~dsw[15];
			yunit_pkg_YG_SAURNFRNT: yunit_pkg_yunit_test_mode = dsw[14];
			yunit_pkg_YG_TROG, yunit_pkg_YG_HIIMPACT, yunit_pkg_YG_SHIMPACT, yunit_pkg_YG_MK, yunit_pkg_YG_TERM2, yunit_pkg_YG_TOTCARN: yunit_pkg_yunit_test_mode = ~dsw[8];
			yunit_pkg_YG_YUNITTST: yunit_pkg_yunit_test_mode = 1'b1;
			default: yunit_pkg_yunit_test_mode = 1'b0;
		endcase
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		in0 = 16'hffff;
		in1 = 16'hffff;
		in2 = 16'hffff;
		dsw = dsw_raw;
		test_mode = yunit_pkg_yunit_test_mode(game_id, dsw_raw);
		start_bit = yunit_pkg_yunit_start_bit(game_id);
		coin_bit = yunit_pkg_yunit_coin_bit(game_id);
		in1[0] = ~joy0[coin_bit];
		in1[1] = ~joy1[coin_bit];
		in1[2] = ~(joy0[start_bit] | (test_mode && (game_id == yunit_pkg_YG_TERM2 ? joy0[3] | joy1[3] : joy0[4])));
		in1[5] = ~(joy1[start_bit] | (test_mode && (game_id == yunit_pkg_YG_TERM2 ? joy0[2] | joy1[2] : joy1[4])));
		if (game_id == yunit_pkg_YG_SMASHTV)
			in1[6] = ~joy0[8];
		case (game_id)
			yunit_pkg_YG_SMASHTV, yunit_pkg_YG_TOTCARN: begin
				in0[0] = ~joy0[3];
				in0[1] = ~joy0[2];
				in0[2] = ~joy0[1];
				in0[3] = ~joy0[0];
				in0[8] = ~joy1[3];
				in0[9] = ~joy1[2];
				in0[10] = ~joy1[1];
				in0[11] = ~joy1[0];
				in0[4] = ~joy0[4];
				in0[5] = ~joy0[5];
				in0[6] = ~joy0[6];
				in0[7] = ~joy0[7];
				in0[12] = ~joy1[4];
				in0[13] = ~joy1[5];
				in0[14] = ~joy1[6];
				in0[15] = ~joy1[7];
				in1[9] = ~joy2[coin_bit];
				if (game_id == yunit_pkg_YG_SMASHTV)
					dsw = dsw_raw | 16'h4000;
				if (game_id == yunit_pkg_YG_TOTCARN)
					in1[14] = ~adpcm_irq;
			end
			yunit_pkg_YG_TROG, yunit_pkg_YG_HIIMPACT, yunit_pkg_YG_SHIMPACT, yunit_pkg_YG_YUNITTST: begin
				in0[0] = ~joy0[3];
				in0[1] = ~joy0[2];
				in0[2] = ~joy0[1];
				in0[3] = ~joy0[0];
				in0[8] = ~joy1[3];
				in0[9] = ~joy1[2];
				in0[10] = ~joy1[1];
				in0[11] = ~joy1[0];
				in0[4] = ~joy0[4];
				in0[12] = ~joy1[4];
				in1[9] = ~joy2[start_bit];
				in1[10] = ~joy3[start_bit];
				in1[11] = ~joy2[3];
				in1[12] = ~joy2[2];
				in1[13] = ~joy2[1];
				in1[14] = ~joy2[0];
				in1[15] = ~joy2[4];
				in2[0] = ~joy3[3];
				in2[1] = ~joy3[2];
				in2[2] = ~joy3[1];
				in2[3] = ~joy3[0];
				in2[4] = ~joy3[4];
				if (game_id == yunit_pkg_YG_TROG)
					in2[5] = ~joy2[coin_bit];
				else begin
					in1[7] = ~joy2[coin_bit];
					in2[5] = ~joy3[coin_bit];
				end
			end
			yunit_pkg_YG_STRKFORC, yunit_pkg_YG_SAURNFRNT: begin
				in0[0] = ~joy0[3];
				in0[1] = ~joy0[2];
				in0[2] = ~joy0[1];
				in0[3] = ~joy0[0];
				in0[8] = ~joy1[3];
				in0[9] = ~joy1[2];
				in0[10] = ~joy1[1];
				in0[11] = ~joy1[0];
				in0[4] = ~joy0[4];
				in0[5] = ~joy0[5];
				in0[6] = ~joy0[6];
				in0[12] = ~joy1[4];
				in0[13] = ~joy1[5];
				in0[14] = ~joy1[6];
				in1[7] = ~joy2[coin_bit];
				in1[9] = ~joy3[coin_bit];
			end
			yunit_pkg_YG_MK: begin
				in0[0] = ~joy0[3];
				in0[1] = ~joy0[2];
				in0[2] = ~joy0[1];
				in0[3] = ~joy0[0];
				in0[8] = ~joy1[3];
				in0[9] = ~joy1[2];
				in0[10] = ~joy1[1];
				in0[11] = ~joy1[0];
				in0[4] = ~joy0[4];
				in0[5] = ~joy0[6];
				in0[6] = ~joy0[7];
				in0[12] = ~joy1[4];
				in0[13] = ~joy1[6];
				in0[14] = ~joy1[7];
				in1[8] = ~joy2[coin_bit];
				in1[9] = ~joy1[5];
				in1[10] = ~joy1[8];
				in1[11] = ~joy1[9];
				in1[12] = ~joy0[5];
				in1[13] = ~joy0[8];
				in1[14] = ~adpcm_irq;
				in1[15] = ~joy0[9];
			end
			yunit_pkg_YG_TERM2: begin
				in0[4] = ~joy0[4];
				in0[5] = ~joy0[5];
				in0[12] = ~(joy1[4] | joy0[6]);
				in0[13] = ~(joy1[5] | joy0[7]);
				in1[7] = ~joy2[coin_bit];
				in1[9] = ~joy3[coin_bit];
				in1[14] = ~adpcm_irq;
			end
			default:
				;
		endcase
		inputs = {dsw, in2, in1, in0};
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module family2_download_mapper (
	clk,
	ioctl_download,
	ioctl_wr,
	ioctl_index,
	ioctl_addr,
	ioctl_dout,
	game_id,
	gfx_download,
	rom_download,
	mapped_wr,
	mapped_addr,
	mapped_dout,
	mapped_be,
	snd_wr,
	snd_addr,
	snd_data
);
	parameter [24:0] DL_ROMHI_BASE = 25'h0080000;
	parameter [24:0] SCRATCH_WBASE = 25'h0500000;
	parameter [24:0] ROMW_BASE = 25'h0400000;
	parameter [24:0] SOUNDW_BASE = 25'h0800000;
	input wire clk;
	input wire ioctl_download;
	input wire ioctl_wr;
	input wire [7:0] ioctl_index;
	input wire [24:0] ioctl_addr;
	input wire [7:0] ioctl_dout;
	output reg [3:0] game_id;
	output wire gfx_download;
	output wire rom_download;
	output reg mapped_wr;
	output reg [24:0] mapped_addr;
	output reg [15:0] mapped_dout;
	output reg [1:0] mapped_be;
	output reg snd_wr;
	output reg [17:0] snd_addr;
	output reg [7:0] snd_data;
	initial game_id = 4'd0;
	wire prog_download = ioctl_download && (ioctl_index == 8'd1);
	wire snd_download = ioctl_download && (ioctl_index == 8'd2);
	wire adpcm_snd_tap_ok = ioctl_addr[24:18] == 7'd0;
	assign gfx_download = ioctl_download && (ioctl_index == 8'd0);
	assign rom_download = (gfx_download || prog_download) || snd_download;
	reg [7:0] pair_lo;
	localparam [1:0] yunit_pkg_YS_ADPCM = 2'd2;
	localparam [3:0] yunit_pkg_YG_HIIMPACT = 4'd2;
	localparam [3:0] yunit_pkg_YG_MK = 4'd5;
	localparam [3:0] yunit_pkg_YG_SHIMPACT = 4'd3;
	localparam [3:0] yunit_pkg_YG_TERM2 = 4'd6;
	localparam [3:0] yunit_pkg_YG_TOTCARN = 4'd7;
	localparam [3:0] yunit_pkg_YG_YUNITTST = 4'd8;
	localparam [1:0] yunit_pkg_YS_CVSD_LARGE = 2'd1;
	localparam [1:0] yunit_pkg_YS_CVSD_SMALL = 2'd0;
	function automatic [1:0] yunit_pkg_yunit_sound_type;
		input reg [3:0] game;
		if (((game == yunit_pkg_YG_MK) || (game == yunit_pkg_YG_TERM2)) || (game == yunit_pkg_YG_TOTCARN))
			yunit_pkg_yunit_sound_type = yunit_pkg_YS_ADPCM;
		else if (((game == yunit_pkg_YG_HIIMPACT) || (game == yunit_pkg_YG_SHIMPACT)) || (game == yunit_pkg_YG_YUNITTST))
			yunit_pkg_yunit_sound_type = yunit_pkg_YS_CVSD_LARGE;
		else
			yunit_pkg_yunit_sound_type = yunit_pkg_YS_CVSD_SMALL;
	endfunction
	always @(posedge clk) begin
		mapped_wr <= 1'b0;
		snd_wr <= 1'b0;
		if (((ioctl_download && ioctl_wr) && (ioctl_index == 8'd3)) && (ioctl_addr == 25'd0))
			game_id <= ioctl_dout[3:0];
		if (ioctl_wr) begin
			if (gfx_download) begin
				if (!ioctl_addr[0])
					pair_lo <= ioctl_dout;
				else begin
					mapped_addr <= SCRATCH_WBASE + {1'b0, ioctl_addr[24:1]};
					mapped_dout <= {ioctl_dout, pair_lo};
					mapped_be <= 2'b11;
					mapped_wr <= 1'b1;
				end
			end
			else if (prog_download && (ioctl_addr < DL_ROMHI_BASE)) begin
				mapped_addr <= ROMW_BASE + ioctl_addr;
				mapped_dout <= {8'h00, ioctl_dout};
				mapped_be <= 2'b01;
				mapped_wr <= 1'b1;
			end
			else if (prog_download) begin
				mapped_addr <= ROMW_BASE + (ioctl_addr - DL_ROMHI_BASE);
				mapped_dout <= {ioctl_dout, 8'h00};
				mapped_be <= 2'b10;
				mapped_wr <= 1'b1;
			end
			else if (snd_download) begin
				if (!ioctl_addr[0])
					pair_lo <= ioctl_dout;
				else begin
					mapped_addr <= SOUNDW_BASE + {1'b0, ioctl_addr[24:1]};
					mapped_dout <= {ioctl_dout, pair_lo};
					mapped_be <= 2'b11;
					mapped_wr <= 1'b1;
				end
			end
		end
		if (snd_download && ioctl_wr) begin
			if (yunit_pkg_yunit_sound_type(game_id) == yunit_pkg_YS_ADPCM) begin
				snd_addr <= ioctl_addr[17:0];
				snd_data <= ioctl_dout;
				snd_wr <= adpcm_snd_tap_ok;
			end
			else begin
				snd_addr <= {ioctl_addr[18:17], ioctl_addr[15:0]};
				snd_data <= ioctl_dout;
				snd_wr <= 1'b1;
			end
		end
	end
endmodule
`default_nettype wire
`default_nettype none
module yunit_mem_family2 (
	clk,
	rst,
	mem_req,
	mem_we,
	mem_addr,
	mem_size,
	mem_wdata,
	mem_rdata,
	mem_ack,
	fb_we,
	fb_addr,
	fb_wdata,
	dma_palette,
	inputs,
	game_id,
	cpu_pc,
	term2_adc,
	term2_adc_sel,
	bpp4,
	gfx_bytes,
	snd_select,
	snd_trig,
	snd_reset,
	dbg_p1ctrl,
	dbg_bdir,
	cmos_quiesce,
	nvram_ext_en,
	nvram_ext_wr,
	nvram_ext_addr,
	nvram_ext_wdata,
	nvram_ext_rdata,
	cmos_cpu_busy,
	cmos_cpu_write_pulse,
	shift_req,
	shift_write,
	shift_entry,
	shift_rdata,
	shift_ready,
	shift_done,
	shift_invalidate_valid,
	shift_invalidate_row,
	erase_start,
	erase_row0,
	erase_lines,
	erase_line_valid,
	erase_line_first,
	erase_line_row,
	erase_frame_raw_ok,
	erase_frame_start,
	autoerase_off,
	erase_busy,
	gfx_rd,
	gfx_raddr,
	gfx_rdata,
	gfx_rack,
	fb_ack,
	fb_busy,
	fb_flush,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	sdram_por,
	ddram_addr,
	ddram_burstcnt,
	ddram_rd,
	ddram_we,
	ddram_din,
	ddram_be,
	ddram_busy,
	ddram_dout,
	ddram_dout_ready,
	palv_we_a,
	palv_aa,
	palv_awd,
	palv_we_b,
	palv_ba,
	palv_bwd
);
	reg _sv2v_0;
	parameter signed [31:0] ROM_WORDS = 32'h00020000;
	parameter signed [31:0] ROM_WORD_OFFSET = 32'h00060000;
	parameter signed [31:0] RAM_WORDS = 32'h00010000;
	parameter signed [31:0] VRAM_WORDS = 32'h00040000;
	parameter signed [31:0] PAL_WORDS = 32'h00002000;
	parameter signed [31:0] CMOS_WORDS = 32'h00004000;
	parameter signed [31:0] GFX_PIXELS = 32'h00180000;
	parameter ROM_HEX = "smashtv_maindata.hex";
	parameter GFX_HEX = "build/smashtv_gfx.hex";
	input wire clk;
	input wire rst;
	input wire mem_req;
	input wire mem_we;
	input wire [31:0] mem_addr;
	input wire [5:0] mem_size;
	input wire [31:0] mem_wdata;
	output reg [31:0] mem_rdata;
	output reg mem_ack;
	input wire fb_we;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	input wire [17:0] fb_addr;
	input wire [15:0] fb_wdata;
	input wire [15:0] dma_palette;
	input wire [63:0] inputs;
	input wire [3:0] game_id;
	input wire [31:0] cpu_pc;
	input wire [7:0] term2_adc;
	output reg [1:0] term2_adc_sel;
	input wire bpp4;
	input wire [23:0] gfx_bytes;
	output reg [7:0] snd_select;
	output reg snd_trig;
	output reg snd_reset;
	output reg [31:0] dbg_p1ctrl;
	output reg [31:0] dbg_bdir;
	input wire cmos_quiesce;
	input wire nvram_ext_en;
	input wire nvram_ext_wr;
	input wire [14:0] nvram_ext_addr;
	input wire [7:0] nvram_ext_wdata;
	output wire [7:0] nvram_ext_rdata;
	output wire cmos_cpu_busy;
	output wire cmos_cpu_write_pulse;
	input wire shift_req;
	input wire shift_write;
	input wire [17:0] shift_entry;
	output wire [15:0] shift_rdata;
	output wire shift_ready;
	output wire shift_done;
	output wire shift_invalidate_valid;
	output wire [8:0] shift_invalidate_row;
	input wire erase_start;
	input wire [8:0] erase_row0;
	input wire [9:0] erase_lines;
	input wire erase_line_valid;
	input wire erase_line_first;
	input wire [8:0] erase_line_row;
	input wire erase_frame_raw_ok;
	input wire erase_frame_start;
	input wire autoerase_off;
	output wire erase_busy;
	output reg gfx_rd;
	output wire [23:0] gfx_raddr;
	input wire [15:0] gfx_rdata;
	input wire gfx_rack;
	output wire fb_ack;
	output wire fb_busy;
	input wire fb_flush;
	input wire scan_req;
	input wire [17:0] scan_addr;
	output wire [15:0] scan_data;
	output wire scan_ack;
	input wire sdram_por;
	output wire [28:0] ddram_addr;
	output wire [7:0] ddram_burstcnt;
	output wire ddram_rd;
	output wire ddram_we;
	output wire [63:0] ddram_din;
	output wire [7:0] ddram_be;
	input wire ddram_busy;
	input wire [63:0] ddram_dout;
	input wire ddram_dout_ready;
	output reg palv_we_a;
	output reg [12:0] palv_aa;
	output reg [15:0] palv_awd;
	output reg palv_we_b;
	output reg [12:0] palv_ba;
	output reg [15:0] palv_bwd;
	localparam [3:0] R_NONE = 4'd0;
	localparam [3:0] R_VRAM = 4'd1;
	localparam [3:0] R_RAM = 4'd2;
	localparam [3:0] R_CMOS = 4'd3;
	localparam [3:0] R_PAL = 4'd4;
	localparam [3:0] R_DMA = 4'd5;
	localparam [3:0] R_INPUT = 4'd6;
	localparam [3:0] R_PROT = 4'd7;
	localparam [3:0] R_SOUND = 4'd8;
	localparam [3:0] R_CTRL = 4'd9;
	localparam [3:0] R_GFX = 4'd10;
	localparam [3:0] R_ROM = 4'd11;
	localparam [31:0] yunit_pkg_YMAP_RAM_BASE = 32'h01000000;
	function automatic [27:0] sv2v_cast_28;
		input reg [27:0] inp;
		sv2v_cast_28 = inp;
	endfunction
	localparam [27:0] WB_RAM = sv2v_cast_28(yunit_pkg_YMAP_RAM_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_MAINDATA_BASE = 32'hff800000;
	localparam [27:0] WB_ROM = sv2v_cast_28(yunit_pkg_YMAP_MAINDATA_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_VRAM_BASE = 32'h00000000;
	localparam [27:0] WB_VRAM = sv2v_cast_28(yunit_pkg_YMAP_VRAM_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_PAL_BASE = 32'h01800000;
	localparam [27:0] WB_PAL = sv2v_cast_28(yunit_pkg_YMAP_PAL_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_CMOS_BASE = 32'h01400000;
	localparam [27:0] WB_CMOS = sv2v_cast_28(yunit_pkg_YMAP_CMOS_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_INPUT_BASE = 32'h01c00000;
	localparam [27:0] WB_INPUT = sv2v_cast_28(yunit_pkg_YMAP_INPUT_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_GFX_BASE = 32'h02000000;
	localparam [27:0] WB_GFX = sv2v_cast_28(yunit_pkg_YMAP_GFX_BASE >> 4);
	localparam [27:0] ROM_PROG_OFF = ROM_WORD_OFFSET[27:0];
	localparam [3:0] yunit_pkg_YG_SMASHTV = 4'd0;
	wire [3:0] game = (^game_id === 1'bx ? yunit_pkg_YG_SMASHTV : game_id);
	(* ramstyle = "no_rw_check" *) reg [15:0] ram [0:RAM_WORDS - 1];
	(* ramstyle = "no_rw_check" *) reg [15:0] pal [0:PAL_WORDS - 1];
	reg videobank = 1'b0;
	reg [1:0] cmos_page = 2'd0;
	reg autoerase = 1'b0;
	reg er_run = 1'b0;
	wire [8:0] er_row;
	wire [8:0] er_x;
	wire [9:0] er_left;
	(* ramstyle = "no_rw_check" *) reg [15:0] nvram [0:CMOS_WORDS - 1];
	reg [15:0] strike_shadow;
	wire [15:0] prot_result;
	localparam [3:0] M_IDLE = 4'd0;
	localparam [3:0] M_ACK = 4'd1;
	localparam [3:0] M_GFX = 4'd2;
	localparam [3:0] M_HR1 = 4'd3;
	localparam [3:0] M_HR2 = 4'd4;
	localparam [3:0] M_HFIN = 4'd5;
	localparam [3:0] M_HW2 = 4'd6;
	localparam [3:0] M_VRD = 4'd7;
	localparam [3:0] M_VWR0 = 4'd8;
	localparam [3:0] M_VWR1 = 4'd9;
	localparam [3:0] M_VWW0 = 4'd10;
	localparam [3:0] M_VWW1 = 4'd11;
	localparam [3:0] M_VSD = 4'd12;
	localparam [3:0] M_HFIN2 = 4'd13;
	localparam [3:0] M_RDLY = 4'd14;
	localparam [3:0] M_SBH = 4'd15;
	localparam [4:0] M_EXD = 5'd16;
	localparam [4:0] M_DEC = 5'd17;
	localparam [4:0] M_SBR = 5'd18;
	reg [4:0] state;
	reg sbr_hw;
	reg [2:0] sbr_oidx;
	reg sbr_oor;
	wire cmos_quiesce_on = cmos_quiesce === 1'b1;
	wire nvram_ext_en_on = nvram_ext_en === 1'b1;
	wire nvram_ext_wr_on = nvram_ext_en_on && (nvram_ext_wr === 1'b1);
	wire cmos_req_now = (mem_addr[31:20] == 12'h014) && (mem_addr[19:16] == 4'h0);
	function automatic signed [23:0] sv2v_cast_24_signed;
		input reg signed [23:0] inp;
		sv2v_cast_24_signed = inp;
	endfunction
	localparam [23:0] SDRAM_ROMB = sv2v_cast_24_signed(GFX_PIXELS);
	reg [23:0] gfx_base;
	reg [1:0] gfx_cnt;
	reg [1:0] gfx_need;
	reg gfx_isrom;
	reg [15:0] gw0;
	reg [15:0] gw1;
	reg [23:0] gfx_raddr_q;
	reg [3:0] boff_r;
	reg [47:0] rmask_r;
	localparam signed [31:0] SB_N = 8;
	reg [15:0] sb_q [0:1][0:7];
	reg [22:0] sb_base [0:1];
	reg [3:0] sb_fill [0:1];
	reg sb_vld [0:1];
	reg sb_mru;
	reg sbw;
	reg pfw;
	reg pf_run;
	reg pf_busy;
	reg [31:0] a_q;
	reg we_q;
	reg [31:0] wd_q;
	reg [5:0] sz_q;
	wire [27:0] widx = a_q[31:4];
	reg [27:0] widx_q;
	always @(posedge clk) widx_q <= widx;
	wire [3:0] boff = a_q[3:0];
	wire [5:0] sz = sz_q;
	reg [3:0] region;
	wire prot_wr = ((state == M_ACK) && we_q) && (region == R_PROT);
	yunit_protection u_protection(
		.clk(clk),
		.rst(rst),
		.game_id(game),
		.wr(prot_wr),
		.wdata(wd_q[15:0]),
		.strike_word(strike_shadow),
		.result(prot_result)
	);
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		casez (a_q[31:20])
			12'h000, 12'h001: region = R_VRAM;
			12'h010: region = R_RAM;
			12'h014: region = (a_q[19:16] == 4'h0 ? R_CMOS : R_NONE);
			12'h018: region = R_PAL;
			12'h01a: region = ((a_q[18:8] == 11'h000) && (a_q[7:4] <= 4'd9) ? R_DMA : R_NONE);
			12'h01c: region = (a_q[7:4] >= 4'd6 ? R_PROT : R_INPUT);
			12'h01e: region = R_SOUND;
			12'h01f: region = R_CTRL;
			12'h020, 12'h021, 12'h022, 12'h023, 12'h024, 12'h025, 12'h026, 12'h027, 12'h028, 12'h029, 12'h02a, 12'h02b, 12'h02c, 12'h02d, 12'h02e, 12'h02f, 12'h030, 12'h031, 12'h032, 12'h033, 12'h034, 12'h035, 12'h036, 12'h037, 12'h038, 12'h039, 12'h03a, 12'h03b, 12'h03c, 12'h03d, 12'h03e, 12'h03f, 12'h040, 12'h041, 12'h042, 12'h043, 12'h044, 12'h045, 12'h046, 12'h047, 12'h048, 12'h049, 12'h04a, 12'h04b, 12'h04c, 12'h04d, 12'h04e, 12'h04f, 12'h050, 12'h051, 12'h052, 12'h053, 12'h054, 12'h055, 12'h056, 12'h057, 12'h058, 12'h059, 12'h05a, 12'h05b, 12'h05c, 12'h05d, 12'h05e, 12'h05f: region = R_GFX;
			12'hff8, 12'hff9, 12'hffa, 12'hffb, 12'hffc, 12'hffd, 12'hffe, 12'hfff: region = R_ROM;
			default: region = R_NONE;
		endcase
	end
	wire is_hwvram = region == R_VRAM;
	localparam [27:0] ROMW = ROM_WORDS[27:0];
	localparam [27:0] RAMW = RAM_WORDS[27:0];
	localparam [27:0] VRAMW = VRAM_WORDS[27:0];
	localparam [27:0] PALW = PAL_WORDS[27:0];
	localparam [27:0] CMOS_PAGEW = 28'h0001000;
	localparam [27:0] GFXPIXW = GFX_PIXELS[27:0];
	localparam [3:0] yunit_pkg_YG_TERM2 = 4'd6;
	function automatic [15:0] read_word;
		input reg [3:0] rgn;
		input reg [27:0] gw;
		reg [27:0] rel;
		reg [7:0] gb0;
		reg [7:0] gb1;
		begin
			read_word = 16'h0000;
			if (rgn == R_ROM)
				;
			else if (rgn == R_RAM)
				;
			else if (rgn == R_VRAM)
				;
			else if (rgn == R_PAL)
				;
			else if (rgn == R_CMOS)
				;
			else if (rgn == R_INPUT) begin
				rel = gw - WB_INPUT;
				case (rel[1:0])
					2'd0: read_word = inputs[15:0];
					2'd1: read_word = inputs[31:16];
					2'd2: read_word = (game == yunit_pkg_YG_TERM2 ? {8'hff, term2_adc} : inputs[47:32]);
					2'd3: read_word = inputs[63:48];
					default: read_word = 16'hffff;
				endcase
				if (rel > 28'd3)
					read_word = 16'hffff;
			end
			else if (rgn == R_PROT)
				read_word = prot_result;
			else if (rgn == R_GFX)
				rel = gw - WB_GFX;
		end
	endfunction
	wire [47:0] rmask = (48'd1 << sz) - 48'd1;
	wire [47:0] smask = rmask << boff;
	wire [5:0] lastb = (boff + sz) - 6'd1;
	assign gfx_raddr = gfx_raddr_q;
	always @(posedge clk) begin
		boff_r <= boff;
		rmask_r <= rmask;
	end
	reg ext_fetch;
	reg ext_isrom;
	reg [23:0] ext_base;
	reg [27:0] rom_rel;
	function automatic [23:0] sv2v_cast_24;
		input reg [23:0] inp;
		sv2v_cast_24 = inp;
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		ext_fetch = 1'b0;
		ext_isrom = 1'b0;
		ext_base = 24'd0;
		rom_rel = widx - WB_ROM;
		if ((region == R_GFX) && !we_q) begin
			ext_fetch = 1'b1;
			ext_base = sv2v_cast_24((widx - WB_GFX) << 1);
		end
		if ((((region == R_ROM) && !we_q) && (rom_rel >= ROM_PROG_OFF)) && ((rom_rel - ROM_PROG_OFF) < ROMW)) begin
			ext_fetch = 1'b1;
			ext_isrom = 1'b1;
			ext_base = SDRAM_ROMB + sv2v_cast_24((rom_rel - ROM_PROG_OFF) << 1);
		end
	end
	wire [1:0] extnw = 2'd1 + lastb[5:4];
	wire [22:0] ext_waddr = ext_base[23:1];
	reg [23:0] exd_base;
	reg exd_isrom;
	wire exd_gfx_oor = !exd_isrom && (exd_base >= gfx_bytes);
	function automatic [15:0] sv2v_cast_16;
		input reg [15:0] inp;
		sv2v_cast_16 = inp;
	endfunction
	function automatic [15:0] gfx4_alias;
		input reg [15:0] w;
		reg [7:0] b0;
		reg [7:0] b1;
		begin
			b0 = w[7:0];
			b1 = w[15:8];
			gfx4_alias = ((sv2v_cast_16(b0) | (sv2v_cast_16(b0) << 4)) | (sv2v_cast_16(b1) << 8)) | (sv2v_cast_16(b1) << 12);
		end
	endfunction
	wire exd_alias = !exd_isrom && bpp4;
	reg [23:0] gfx_lim1;
	reg [23:0] gfx_lim2;
	always @(posedge clk) begin
		gfx_lim1 <= (gfx_bytes >= 24'd2 ? gfx_bytes - 24'd2 : 24'd0);
		gfx_lim2 <= (gfx_bytes >= 24'd4 ? gfx_bytes - 24'd4 : 24'd0);
	end
	wire exd_oor1 = !exd_isrom && (exd_base >= gfx_lim1);
	wire exd_oor2 = !exd_isrom && (exd_base >= gfx_lim2);
	wire [15:0] gfx_rd_a = (exd_alias ? gfx4_alias(gfx_rdata) : gfx_rdata);
	wire [15:0] gxa0 = (exd_gfx_oor ? 16'h0000 : (gfx_need == 2'd1 ? gfx_rd_a : gw0));
	wire [15:0] gxa1 = (exd_oor1 ? 16'h0000 : (gfx_need == 2'd2 ? gfx_rd_a : gw1));
	wire [15:0] gxa2 = (exd_oor2 ? 16'h0000 : gfx_rd_a);
	reg [22:0] exd_waddr;
	reg [1:0] exd_need;
	wire [22:0] exd_off0 = exd_waddr - sb_base[0];
	wire [22:0] exd_off1 = exd_waddr - sb_base[1];
	wire exd_hit0 = ((sb_vld[0] && exd_isrom) && (exd_off0 < 23'd8)) && (({1'b0, exd_off0[2:0]} + {2'b00, exd_need}) <= sb_fill[0]);
	wire exd_hit1 = ((sb_vld[1] && exd_isrom) && (exd_off1 < 23'd8)) && (({1'b0, exd_off1[2:0]} + {2'b00, exd_need}) <= sb_fill[1]);
	wire exd_hit = exd_hit0 || exd_hit1;
	wire exd_hw = exd_hit1 && !exd_hit0;
	wire [2:0] exd_oidx = (exd_hw ? exd_off1[2:0] : exd_off0[2:0]);
	wire [15:0] exd_w0 = sb_q[exd_hw][exd_oidx];
	wire [15:0] exd_w1 = sb_q[exd_hw][exd_oidx + 3'd1];
	wire [15:0] exd_w2 = sb_q[exd_hw][exd_oidx + 3'd2];
	function automatic [22:0] sv2v_cast_23;
		input reg [22:0] inp;
		sv2v_cast_23 = inp;
	endfunction
	localparam [22:0] SB_ROM_WEND = sv2v_cast_23((SDRAM_ROMB >> 1) + ROM_WORDS);
	wire pf_inrange = (sb_base[sb_mru] + {19'd0, sb_fill[sb_mru]}) < SB_ROM_WEND;
	reg is_hwram;
	reg [1:0] hsel;
	reg [17:0] hidx [0:2];
	reg hval [0:2];
	reg [27:0] hr;
	always @(*) begin
		if (_sv2v_0)
			;
		is_hwram = 1'b0;
		hsel = 2'd0;
		hr = 28'd0;
		begin : sv2v_autoblock_1
			reg signed [31:0] j;
			for (j = 0; j < 3; j = j + 1)
				begin
					hidx[j] = 18'd0;
					hval[j] = 1'b0;
				end
		end
		if (region == R_RAM) begin
			is_hwram = 1'b1;
			hsel = 2'd0;
			begin : sv2v_autoblock_2
				reg signed [31:0] j;
				for (j = 0; j < 3; j = j + 1)
					begin
						hr = (widx + j[27:0]) - WB_RAM;
						hidx[j] = hr[17:0];
						hval[j] = hr < RAMW;
					end
			end
		end
		else if (region == R_PAL) begin
			is_hwram = 1'b1;
			hsel = 2'd1;
			begin : sv2v_autoblock_3
				reg signed [31:0] j;
				for (j = 0; j < 3; j = j + 1)
					begin
						hr = (widx + j[27:0]) - WB_PAL;
						hidx[j] = hr[17:0];
						hval[j] = hr < PALW;
					end
			end
		end
		else if (region == R_CMOS) begin
			is_hwram = 1'b1;
			hsel = 2'd2;
			begin : sv2v_autoblock_4
				reg signed [31:0] j;
				for (j = 0; j < 3; j = j + 1)
					begin
						hr = (widx + j[27:0]) - WB_CMOS;
						hidx[j] = {4'd0, cmos_page, hr[11:0]};
						hval[j] = hr < CMOS_PAGEW;
					end
			end
		end
	end
	reg [15:0] rd0;
	reg [15:0] rd1;
	reg [15:0] rd2;
	reg [17:0] hidx_q [0:2];
	reg hval_q [0:2];
	always @(posedge clk) begin : sv2v_autoblock_5
		reg signed [31:0] j;
		for (j = 0; j < 3; j = j + 1)
			begin
				hidx_q[j] <= hidx[j];
				hval_q[j] <= hval[j];
			end
	end
	wire [47:0] hwin = {(hval_q[2] ? rd2 : 16'h0000), (hval_q[1] ? rd1 : 16'h0000), (hval_q[0] ? rd0 : 16'h0000)};
	wire [47:0] hmerged = (hwin & ~smask) | (({16'h0000, wd_q} << boff) & smask);
	reg [47:0] smask_q;
	reg [47:0] rmask_q;
	reg [47:0] wsh_q;
	reg [47:0] hwin_q;
	reg [3:0] boff_q;
	always @(posedge clk) begin
		smask_q <= smask;
		rmask_q <= rmask;
		boff_q <= boff;
		wsh_q <= {16'h0000, wd_q} << boff;
		hwin_q <= hwin;
	end
	wire [47:0] hmerged2 = (hwin_q & ~smask_q) | (wsh_q & smask_q);
	reg [17:0] eng_aa;
	reg [17:0] eng_ba;
	reg eng_awe;
	reg eng_bwe;
	reg [15:0] eng_awd;
	reg [15:0] eng_bwd;
	reg [15:0] eng_aq;
	reg [15:0] eng_bq;
	always @(*) begin
		if (_sv2v_0)
			;
		eng_aa = hidx_q[0];
		eng_ba = hidx_q[1];
		eng_awe = 1'b0;
		eng_bwe = 1'b0;
		eng_awd = hmerged2[15:0];
		eng_bwd = hmerged2[31:16];
		case (state)
			M_HR1: eng_aa = hidx_q[2];
			M_HFIN2:
				if (we_q) begin
					eng_aa = hidx_q[0];
					eng_awe = hval_q[0];
					eng_ba = hidx_q[1];
					eng_bwe = (lastb >= 6'd16) & hval_q[1];
				end
			M_HW2: begin
				eng_aa = hidx_q[2];
				eng_awe = (lastb >= 6'd32) & hval_q[2];
				eng_awd = hmerged2[47:32];
			end
			default:
				;
		endcase
	end
	reg [16:0] ram_aa;
	reg [16:0] ram_ba;
	reg ram_awe;
	reg ram_bwe;
	reg [15:0] ram_awd;
	reg [15:0] ram_bwd;
	reg [15:0] ram_aq;
	reg [15:0] ram_bq;
	reg [12:0] pal_aa;
	reg [12:0] pal_ba;
	reg pal_awe;
	reg pal_bwe;
	reg [15:0] pal_awd;
	reg [15:0] pal_bwd;
	reg [15:0] pal_aq;
	reg [15:0] pal_bq;
	reg [14:0] nv_aa;
	reg [14:0] nv_ba;
	reg nv_awe;
	reg nv_bwe;
	reg [15:0] nv_awd;
	reg [15:0] nv_bwd;
	reg [15:0] nv_aq;
	reg [15:0] nv_bq;
	reg [13:0] nv_ext_word_addr;
	reg nv_ext_lane_q;
	reg [13:0] nv_ext_fwd_addr;
	reg [15:0] nv_ext_fwd_word;
	reg nv_ext_fwd_v;
	wire [15:0] nv_ext_base = (nv_ext_fwd_v && (nv_ext_fwd_addr == nv_ext_word_addr) ? nv_ext_fwd_word : nv_aq);
	wire [15:0] nv_ext_merged = (nvram_ext_addr[0] ? {nvram_ext_wdata, nv_ext_base[7:0]} : {nv_ext_base[15:8], nvram_ext_wdata});
	always @(*) begin
		if (_sv2v_0)
			;
		ram_aa = eng_aa[16:0];
		ram_ba = eng_ba[16:0];
		ram_awd = eng_awd;
		ram_bwd = eng_bwd;
		pal_aa = eng_aa[12:0];
		pal_ba = eng_ba[12:0];
		pal_awd = eng_awd;
		pal_bwd = eng_bwd;
		nv_ext_word_addr = (nvram_ext_en_on ? nvram_ext_addr[14:1] : 14'd0);
		nv_aa = (nvram_ext_en_on ? {1'b0, nv_ext_word_addr} : eng_aa[14:0]);
		nv_ba = eng_ba[14:0];
		nv_awd = (nvram_ext_en_on ? nv_ext_merged : eng_awd);
		nv_bwd = eng_bwd;
		ram_awe = (hsel == 2'd0) & eng_awe;
		ram_bwe = (hsel == 2'd0) & eng_bwe;
		pal_awe = (hsel == 2'd1) & eng_awe;
		pal_bwe = (hsel == 2'd1) & eng_bwe;
		nv_awe = (nvram_ext_en_on ? nvram_ext_wr_on : (hsel == 2'd2) & eng_awe);
		nv_bwe = (!nvram_ext_en_on && (hsel == 2'd2)) && eng_bwe;
		eng_aq = (hsel == 2'd0 ? ram_aq : (hsel == 2'd1 ? pal_aq : nv_aq));
		eng_bq = (hsel == 2'd0 ? ram_bq : (hsel == 2'd1 ? pal_bq : nv_bq));
	end
	always @(posedge clk) begin
		if (ram_awe)
			ram[ram_aa] <= ram_awd;
		ram_aq <= ram[ram_aa];
	end
	always @(posedge clk) begin
		if (ram_bwe)
			ram[ram_ba] <= ram_bwd;
		ram_bq <= ram[ram_ba];
	end
	always @(posedge clk)
		if (rst) begin
			dbg_p1ctrl <= 32'd0;
			dbg_bdir <= 32'd0;
		end
		else begin
			if (ram_awe && (ram_aa == 'h865b))
				dbg_p1ctrl <= {ram_awd, dbg_p1ctrl[15:0] + 16'd1};
			if (ram_bwe && (ram_ba == 'h865b))
				dbg_p1ctrl <= {ram_bwd, dbg_p1ctrl[15:0] + 16'd1};
			if (ram_awe && (ram_aa == 'hde48))
				dbg_bdir <= {ram_awd, dbg_bdir[15:0] + 16'd1};
			if (ram_bwe && (ram_ba == 'hde48))
				dbg_bdir <= {ram_bwd, dbg_bdir[15:0] + 16'd1};
		end
	always @(posedge clk) begin
		if (pal_awe)
			pal[pal_aa] <= pal_awd;
		pal_aq <= pal[pal_aa];
	end
	always @(posedge clk) begin
		if (pal_bwe)
			pal[pal_ba] <= pal_bwd;
		pal_bq <= pal[pal_ba];
	end
	always @(posedge clk) begin
		if (nv_awe)
			nvram[nv_aa] <= nv_awd;
		nv_aq <= nvram[nv_aa];
		nv_ext_lane_q <= (nvram_ext_en_on ? nvram_ext_addr[0] : 1'b0);
	end
	always @(posedge clk) begin
		if (nv_bwe)
			nvram[nv_ba] <= nv_bwd;
		nv_bq <= nvram[nv_ba];
	end
	always @(posedge clk)
		if (nvram_ext_wr_on) begin
			nv_ext_fwd_addr <= nv_ext_word_addr;
			nv_ext_fwd_word <= nv_ext_merged;
			nv_ext_fwd_v <= 1'b1;
		end
		else if (rst && !nvram_ext_en_on)
			nv_ext_fwd_v <= 1'b0;
	assign nvram_ext_rdata = (nvram_ext_en_on ? (nv_ext_lane_q ? nv_aq[15:8] : nv_aq[7:0]) : 8'h00);
	always @(posedge clk) begin
		palv_we_a <= pal_awe;
		palv_aa <= (bpp4 ? {5'b00000, pal_aa[7:0]} : {1'b0, pal_aa[11:0]});
		palv_awd <= pal_awd;
		palv_we_b <= pal_bwe;
		palv_ba <= (bpp4 ? {5'b00000, pal_ba[7:0]} : {1'b0, pal_ba[11:0]});
		palv_bwd <= pal_bwd;
	end
	assign cmos_cpu_busy = (!rst && (state != M_IDLE)) && (region == R_CMOS);
	assign cmos_cpu_write_pulse = (mem_ack && we_q) && (region == R_CMOS);
	reg vsd_req;
	wire vsd_done;
	wire [31:0] vsd_rdata;
	stv_vram_ddr_top #(
		.VRAMW(VRAM_WORDS),
		.VRAM_DDR_BASE(29'h06400000)
	) u_vram_sdram(
		.clk(clk),
		.rst(rst),
		.sdram_por(sdram_por),
		.req(vsd_req),
		.we(we_q),
		.widx(widx),
		.boff(boff),
		.sz(sz_q),
		.wd(wd_q),
		.videobank(videobank),
		.dma_palette(dma_palette),
		.rdata(vsd_rdata),
		.done(vsd_done),
		.fb_we(fb_we),
		.fb_addr(fb_addr),
		.fb_wdata(fb_wdata),
		.fb_ack(fb_ack),
		.fb_busy(fb_busy),
		.fb_flush(fb_flush),
		.erase_en(autoerase && !autoerase_off),
		.erase_busy(erase_busy),
		.erase_line_valid(erase_line_valid),
		.erase_line_first(erase_line_first),
		.erase_line_row(erase_line_row),
		.erase_frame_start(erase_frame_start),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack),
		.shift_req(shift_req),
		.shift_write(shift_write),
		.shift_entry(shift_entry),
		.shift_rdata(shift_rdata),
		.shift_ready(shift_ready),
		.shift_done(shift_done),
		.shift_invalidate_valid(shift_invalidate_valid),
		.shift_invalidate_row(shift_invalidate_row),
		.ddram_addr(ddram_addr),
		.ddram_burstcnt(ddram_burstcnt),
		.ddram_rd(ddram_rd),
		.ddram_we(ddram_we),
		.ddram_din(ddram_din),
		.ddram_be(ddram_be),
		.ddram_busy(ddram_busy),
		.ddram_dout(ddram_dout),
		.ddram_dout_ready(ddram_dout_ready)
	);
	reg [47:0] win_s;
	reg [47:0] merged_s;
	reg [47:0] win_s_q;
	wire [27:0] wrel;
	function automatic [31:0] sv2v_cast_32;
		input reg [31:0] inp;
		sv2v_cast_32 = inp;
	endfunction
	always @(posedge clk)
		if (rst) begin
			state <= M_IDLE;
			mem_ack <= 1'b0;
			mem_rdata <= 32'h00000000;
			snd_select <= 8'h00;
			snd_trig <= 1'b0;
			snd_reset <= 1'b1;
			term2_adc_sel <= 2'd0;
			strike_shadow <= 16'h0000;
			er_run <= 1'b0;
			gfx_rd <= 1'b0;
			sb_vld[0] <= 1'b0;
			sb_vld[1] <= 1'b0;
			sb_fill[0] <= 4'd0;
			sb_fill[1] <= 4'd0;
			sb_base[0] <= 23'd0;
			sb_base[1] <= 23'd0;
			sb_mru <= 1'b0;
			sbw <= 1'b0;
			pfw <= 1'b0;
			pf_run <= 1'b0;
			pf_busy <= 1'b0;
			vsd_req <= 1'b0;
		end
		else begin
			if (pf_busy && gfx_rack) begin
				pf_busy <= 1'b0;
				gfx_rd <= 1'b0;
				if ((pf_run && sb_vld[pfw]) && (sb_fill[pfw] < SB_N)) begin
					sb_q[pfw][sb_fill[pfw][2:0]] <= gfx_rdata;
					sb_fill[pfw] <= sb_fill[pfw] + 4'd1;
				end
			end
			else if (((((((((pf_run && sb_vld[sb_mru]) && !pf_busy) && !gfx_rd) && (sb_fill[sb_mru] < SB_N)) && pf_inrange) && (state != M_GFX)) && (state != M_SBH)) && (state != M_EXD)) && !((state == M_ACK) && ext_fetch)) begin
				gfx_raddr_q <= {sb_base[sb_mru] + {19'd0, sb_fill[sb_mru]}, 1'b0};
				pfw <= sb_mru;
				gfx_rd <= 1'b1;
				pf_busy <= 1'b1;
			end
			if (((state != M_IDLE) && (region == R_CMOS)) && nvram_ext_en_on) begin
				state <= M_ACK;
				mem_ack <= 1'b0;
			end
			else
				(* full_case, parallel_case *)
				case (state)
					M_IDLE: begin
						mem_ack <= 1'b0;
						if ((mem_req && !mem_ack) && !(cmos_req_now && (cmos_quiesce_on || nvram_ext_en_on))) begin
							a_q <= mem_addr;
							we_q <= mem_we;
							wd_q <= mem_wdata;
							sz_q <= mem_size;
							if (mem_we && (mem_addr[31:4] == (WB_RAM + 28'h000a439)))
								strike_shadow <= mem_wdata[15:0];
							if (((mem_we && (game == yunit_pkg_YG_TERM2)) && (mem_addr[31:4] == (WB_RAM + 28'h000aa0f))) && (cpu_pc == 32'hffce6520))
								wd_q <= 32'h00000000;
							if (mem_we) begin
								sb_vld[0] <= 1'b0;
								sb_vld[1] <= 1'b0;
								pf_run <= 1'b0;
							end
							state <= M_DEC;
						end
					end
					M_DEC: state <= M_ACK;
					M_ACK:
						if (ext_fetch) begin
							mem_ack <= 1'b0;
							exd_base <= ext_base;
							exd_waddr <= ext_waddr;
							exd_isrom <= ext_isrom;
							exd_need <= extnw;
							state <= M_EXD;
						end
						else if (is_hwram) begin
							mem_ack <= 1'b0;
							state <= M_HR1;
						end
						else if (is_hwvram) begin
							mem_ack <= 1'b0;
							vsd_req <= 1'b1;
							state <= M_VSD;
						end
						else begin
							win_s = {read_word(region, widx_q + 28'd2), read_word(region, widx_q + 28'd1), read_word(region, widx_q)};
							merged_s = (win_s & ~smask) | (({16'h0000, wd_q} << boff) & smask);
							if (we_q) begin
								(* full_case, parallel_case *)
								case (region)
									default:
										;
								endcase
								if (region == R_CTRL) begin
									videobank <= wd_q[5];
									cmos_page <= wd_q[7:6];
									autoerase <= ~wd_q[4];
								end
								if (region == R_SOUND) begin
									snd_select <= wd_q[7:0];
									snd_trig <= wd_q[9];
									snd_reset <= ~wd_q[8];
									if (game == yunit_pkg_YG_TERM2)
										term2_adc_sel <= wd_q[13:12];
								end
								mem_rdata <= 32'h00000000;
								mem_ack <= 1'b1;
								state <= M_IDLE;
							end
							else begin
								win_s_q <= win_s;
								mem_ack <= 1'b0;
								state <= M_RDLY;
							end
						end
					M_EXD:
						if (exd_hit) begin
							sbr_hw <= exd_hw;
							sbr_oidx <= exd_oidx;
							sbr_oor <= exd_gfx_oor;
							sb_mru <= exd_hw;
							state <= M_SBR;
						end
						else if (pf_busy)
							;
						else begin
							gfx_base <= exd_base;
							gfx_cnt <= 2'd0;
							gfx_need <= exd_need;
							gfx_isrom <= exd_isrom;
							if (exd_isrom) begin
								sbw <= ~sb_mru;
								sb_vld[~sb_mru] <= 1'b0;
								sb_base[~sb_mru] <= exd_waddr;
								sb_fill[~sb_mru] <= 4'd0;
								pf_run <= 1'b0;
							end
							gfx_raddr_q <= exd_base;
							gfx_rd <= 1'b1;
							state <= M_GFX;
						end
					M_GFX:
						if (gfx_rack) begin
							gfx_rd <= 1'b0;
							if (gfx_isrom)
								sb_q[sbw][{1'b0, gfx_cnt}] <= gfx_rdata;
							if (gfx_cnt == 2'd0)
								gw0 <= gfx_rd_a;
							if (gfx_cnt == 2'd1)
								gw1 <= gfx_rd_a;
							if (({1'b0, gfx_cnt} + 3'd1) >= {1'b0, gfx_need}) begin
								win_s_q <= (gfx_need == 2'd1 ? {32'h00000000, gxa0} : (gfx_need == 2'd2 ? {16'h0000, gxa1, gxa0} : {gxa2, gxa1, gxa0}));
								if (gfx_isrom) begin
									sb_fill[sbw] <= {2'b00, gfx_cnt} + 4'd1;
									sb_vld[sbw] <= 1'b1;
									sb_mru <= sbw;
									pf_run <= 1'b1;
								end
								state <= M_SBH;
							end
							else
								gfx_cnt <= gfx_cnt + 2'd1;
						end
						else if (!gfx_rd) begin
							gfx_raddr_q <= gfx_base + {21'd0, gfx_cnt, 1'b0};
							gfx_rd <= 1'b1;
						end
					M_SBR: begin
						win_s_q <= (sbr_oor ? 48'd0 : {sb_q[sbr_hw][sbr_oidx + 3'd2], sb_q[sbr_hw][sbr_oidx + 3'd1], sb_q[sbr_hw][sbr_oidx]});
						state <= M_SBH;
					end
					M_SBH: begin
						mem_rdata <= sv2v_cast_32((win_s_q >> boff_r) & rmask_r);
						mem_ack <= 1'b1;
						state <= M_IDLE;
					end
					M_HR1: begin
						rd0 <= eng_aq;
						rd1 <= eng_bq;
						state <= M_HR2;
					end
					M_HR2: begin
						rd2 <= eng_aq;
						state <= M_HFIN;
					end
					M_HFIN: state <= M_HFIN2;
					M_HFIN2:
						if (we_q) begin
							if ((lastb >= 6'd32) && hval_q[2])
								state <= M_HW2;
							else begin
								mem_ack <= 1'b1;
								state <= M_IDLE;
							end
						end
						else begin
							mem_rdata <= sv2v_cast_32((hwin_q >> boff_q) & rmask_q);
							mem_ack <= 1'b1;
							state <= M_IDLE;
						end
					M_HW2: begin
						mem_ack <= 1'b1;
						state <= M_IDLE;
					end
					M_RDLY: begin
						mem_rdata <= sv2v_cast_32((win_s_q >> boff_q) & rmask_q);
						mem_ack <= 1'b1;
						state <= M_IDLE;
					end
					M_VSD: begin
						vsd_req <= 1'b0;
						if (vsd_done) begin
							mem_rdata <= vsd_rdata;
							mem_ack <= 1'b1;
							state <= M_IDLE;
						end
					end
					default: begin
						state <= M_IDLE;
						mem_ack <= 1'b0;
					end
				endcase
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_dma_family2 (
	clk,
	rst,
	reg_we,
	reg_addr,
	reg_wdata,
	reg_rdata,
	src_req,
	src_addr,
	src_data,
	src_ack,
	fb_we,
	fb_addr,
	fb_wdata,
	fb_ack,
	fb_busy,
	fb_flush,
	busy,
	engine_active,
	trigger_blocked,
	blit_irq,
	dma_palette,
	dbg_blit_total,
	dbg_blit_thin
);
	reg _sv2v_0;
	input wire clk;
	input wire rst;
	input wire reg_we;
	input wire [3:0] reg_addr;
	input wire [15:0] reg_wdata;
	output wire [15:0] reg_rdata;
	output wire src_req;
	output wire [23:0] src_addr;
	input wire [7:0] src_data;
	input wire src_ack;
	output reg fb_we;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	output reg [17:0] fb_addr;
	output reg [15:0] fb_wdata;
	input wire fb_ack;
	input wire fb_busy;
	output wire fb_flush;
	output wire busy;
	output wire engine_active;
	output wire trigger_blocked;
	output reg blit_irq;
	output wire [15:0] dma_palette;
	output reg [31:0] dbg_blit_total;
	output reg [31:0] dbg_blit_thin;
	localparam signed [31:0] yunit_pkg_DMA_NREGS = 16;
	reg [15:0] regf [0:15];
	reg [15:0] launchf [0:15];
	reg [15:0] pendf [0:15];
	reg busy_r;
	reg abort_r;
	reg pend_trig;
	reg [25:0] pace_cnt;
	reg pace_arm;
	localparam [3:0] yunit_pkg_DMA_COMMAND = 4'd0;
	wire [15:0] cmd_reg = regf[yunit_pkg_DMA_COMMAND];
	wire [15:0] launch_cmd = launchf[yunit_pkg_DMA_COMMAND];
	localparam signed [31:0] yunit_pkg_DMA_CMD_FLIPX_BIT = 4;
	wire flipx_w = launch_cmd[yunit_pkg_DMA_CMD_FLIPX_BIT];
	wire [3:0] mode_w = launch_cmd[3:0];
	localparam [3:0] yunit_pkg_DMA_PALETTE = 4'd8;
	wire [7:0] pal_lo = launchf[yunit_pkg_DMA_PALETTE][7:0];
	localparam [3:0] yunit_pkg_DMA_COLOR = 4'd9;
	wire [7:0] col_lo = launchf[yunit_pkg_DMA_COLOR][7:0];
	localparam signed [31:0] yunit_pkg_DMA_CMD_TRIG_BIT = 15;
	wire wdata_trig = reg_wdata[yunit_pkg_DMA_CMD_TRIG_BIT];
	assign busy = busy_r;
	assign dma_palette = regf[yunit_pkg_DMA_PALETTE];
	assign reg_rdata = (reg_addr == yunit_pkg_DMA_COMMAND ? {busy_r, cmd_reg[14:0]} : regf[reg_addr]);
	reg [2:0] state;
	reg [2:0] state_n;
	assign engine_active = (state != 3'd0) || pend_trig;
	wire trigger_write = (reg_we && (reg_addr == yunit_pkg_DMA_COMMAND)) && wdata_trig;
	wire direct_accept = (trigger_write && (state == 3'd0)) && !pend_trig;
	wire pending_accept = (trigger_write && (state != 3'd0)) && !pend_trig;
	assign trigger_blocked = pend_trig;
	reg [3:0] mode_c;
	reg flipx_c;
	reg readmode_c;
	reg signed [11:0] width_c;
	reg signed [11:0] height_c;
	reg signed [11:0] xpos_c;
	reg signed [11:0] ypos_c;
	reg signed [31:0] rowbytes_c;
	reg [15:0] pal16_c;
	reg [15:0] color16_c;
	reg signed [11:0] row_i;
	reg signed [11:0] col_i;
	reg signed [11:0] tx;
	reg [8:0] ty;
	reg signed [31:0] cur_off;
	reg signed [31:0] o_ptr;
	reg [7:0] px;
	reg px_zero;
	reg signed [31:0] rb_in;
	reg signed [31:0] xs_in;
	reg signed [31:0] ys_in;
	reg [15:0] w_in;
	reg [15:0] h_in;
	reg [31:0] gfxoff0;
	reg [31:0] gfxoff1;
	reg [31:0] gfxoff2;
	reg signed [31:0] rb_adj;
	reg signed [31:0] xpos0;
	reg signed [31:0] ypos1;
	reg signed [31:0] height1a;
	reg signed [31:0] height1;
	reg signed [31:0] xpos_f;
	reg signed [31:0] width_f;
	reg signed [31:0] offbytes_c;
	localparam [3:0] yunit_pkg_DMA_HEIGHT = 4'd7;
	localparam [3:0] yunit_pkg_DMA_OFFSETHI = 4'd3;
	localparam [3:0] yunit_pkg_DMA_OFFSETLO = 4'd2;
	localparam [3:0] yunit_pkg_DMA_ROWBYTES = 4'd1;
	localparam [3:0] yunit_pkg_DMA_WIDTH = 4'd6;
	localparam [3:0] yunit_pkg_DMA_XSTART = 4'd4;
	localparam [3:0] yunit_pkg_DMA_YSTART = 4'd5;
	always @(*) begin
		if (_sv2v_0)
			;
		rb_in = $signed(launchf[yunit_pkg_DMA_ROWBYTES]);
		xs_in = $signed(launchf[yunit_pkg_DMA_XSTART]);
		ys_in = $signed(launchf[yunit_pkg_DMA_YSTART]);
		w_in = launchf[yunit_pkg_DMA_WIDTH];
		h_in = launchf[yunit_pkg_DMA_HEIGHT];
		gfxoff0 = {launchf[yunit_pkg_DMA_OFFSETHI], launchf[yunit_pkg_DMA_OFFSETLO]};
		rb_adj = (flipx_w ? ((rb_in - $signed({16'd0, w_in})) + 32'sd3) & ~32'sd3 : ((rb_in + $signed({16'd0, w_in})) + 32'sd3) & ~32'sd3);
		xpos0 = (flipx_w ? (xs_in + $signed({16'd0, w_in})) - 32'sd1 : xs_in);
		gfxoff1 = (flipx_w ? gfxoff0 - (({16'd0, w_in} - 32'd1) << 3) : gfxoff0);
		ypos1 = (ys_in < 0 ? 32'sd0 : ys_in);
		height1a = (ys_in < 0 ? $signed({16'd0, h_in}) + ys_in : $signed({16'd0, h_in}));
		height1 = ((ypos1 + height1a) > 32'sd512 ? 32'sd512 - ypos1 : height1a);
		if (!flipx_w) begin
			if (xpos0 < 0) begin
				width_f = $signed({16'd0, w_in}) + xpos0;
				xpos_f = 32'sd0;
			end
			else begin
				width_f = $signed({16'd0, w_in});
				xpos_f = xpos0;
			end
			if ((xpos_f + width_f) > 32'sd512)
				width_f = 32'sd512 - xpos_f;
		end
		else begin
			if (xpos0 >= 32'sd512) begin
				width_f = $signed({16'd0, w_in}) - (xpos0 - 32'sd511);
				xpos_f = 32'sd511;
			end
			else begin
				width_f = $signed({16'd0, w_in});
				xpos_f = xpos0;
			end
			if ((xpos_f - width_f) < 0)
				width_f = xpos_f;
		end
		gfxoff2 = (gfxoff1 < 32'h02000000 ? gfxoff1 + 32'h02000000 : gfxoff1);
		offbytes_c = ($signed(gfxoff2) - 32'sh02000000) >>> 3;
	end
	wire [11:0] width12 = width_f[11:0];
	wire [11:0] height12 = height1[11:0];
	wire [11:0] xpos12 = xpos_f[11:0];
	wire [11:0] ypos12 = ypos1[11:0];
	wire readmode_w = (mode_w >= 4'h1) && (mode_w <= 4'hb);
	reg pix_we;
	reg [15:0] pix_data;
	always @(*) begin
		if (_sv2v_0)
			;
		pix_we = 1'b0;
		pix_data = 16'h0000;
		(* full_case, parallel_case *)
		case (mode_c)
			4'h0:
				;
			4'h1: begin
				pix_we = px_zero;
				pix_data = pal16_c;
			end
			4'h2: begin
				pix_we = !px_zero;
				pix_data = pal16_c | {8'd0, px};
			end
			4'h3: begin
				pix_we = 1'b1;
				pix_data = pal16_c | {8'd0, px};
			end
			4'h4, 4'h5: begin
				pix_we = px_zero;
				pix_data = color16_c;
			end
			4'h6, 4'h7: begin
				pix_we = 1'b1;
				pix_data = (px_zero ? color16_c : pal16_c | {8'd0, px});
			end
			4'h8, 4'ha: begin
				pix_we = !px_zero;
				pix_data = color16_c;
			end
			4'h9, 4'hb: begin
				pix_we = 1'b1;
				pix_data = (!px_zero ? color16_c : pal16_c | {8'd0, px});
			end
			default: begin
				pix_we = 1'b1;
				pix_data = color16_c;
			end
		endcase
	end
	wire row_overrun = ($unsigned(cur_off) >= 32'h06000000) && (mode_c < 4'hc);
	wire [8:0] tx9 = tx[8:0];
	wire [8:0] ty_next = ypos_c[8:0] + row_i[8:0];
	wire dma_done_ok = pace_cnt == 26'd0;
	always @(posedge clk)
		if (rst) begin
			dbg_blit_total <= 32'd0;
			dbg_blit_thin <= 32'd0;
		end
		else if (state == 3'd1) begin
			dbg_blit_total <= dbg_blit_total + 32'd1;
			if (launchf[yunit_pkg_DMA_HEIGHT] == 16'd1)
				dbg_blit_thin <= dbg_blit_thin + 32'd1;
		end
	always @(*) begin
		if (_sv2v_0)
			;
		state_n = state;
		(* full_case, parallel_case *)
		case (state)
			3'd0:
				if (pend_trig)
					state_n = 3'd1;
				else if (direct_accept)
					state_n = 3'd1;
			3'd1: state_n = 3'd2;
			3'd2:
				if ((height1 <= 0) || (width_f <= 0))
					state_n = 3'd6;
				else
					state_n = 3'd3;
			3'd3:
				if (row_i >= height_c)
					state_n = 3'd6;
				else if (row_overrun)
					state_n = 3'd3;
				else
					state_n = 3'd4;
			3'd4:
				if (!readmode_c)
					state_n = 3'd5;
				else if (src_ack)
					state_n = 3'd5;
			3'd5:
				if (pix_we && !fb_ack)
					state_n = 3'd5;
				else if (col_i >= (width_c - 12'sd1))
					state_n = 3'd3;
				else
					state_n = 3'd4;
			3'd6:
				if (dma_done_ok)
					state_n = 3'd0;
			default: state_n = 3'd0;
		endcase
	end
	assign src_req = (state == 3'd4) && readmode_c;
	assign src_addr = o_ptr[23:0];
	assign fb_flush = state == 3'd6;
	integer i;
	always @(posedge clk)
		if (rst) begin
			state <= 3'd0;
			fb_we <= 1'b0;
			blit_irq <= 1'b0;
			busy_r <= 1'b0;
			pace_cnt <= 26'd0;
			pace_arm <= 1'b0;
			abort_r <= 1'b0;
			pend_trig <= 1'b0;
			for (i = 0; i < yunit_pkg_DMA_NREGS; i = i + 1)
				begin
					regf[i] <= 16'h0000;
					launchf[i] <= 16'h0000;
					pendf[i] <= 16'h0000;
				end
		end
		else begin
			state <= state_n;
			fb_we <= 1'b0;
			if (reg_we) begin
				regf[reg_addr] <= reg_wdata;
				if (reg_addr == yunit_pkg_DMA_COMMAND) begin
					blit_irq <= 1'b0;
					if (wdata_trig) begin
						if (direct_accept) begin
							for (i = 0; i < 10; i = i + 1)
								launchf[i] <= (i == yunit_pkg_DMA_COMMAND ? reg_wdata : regf[i]);
							busy_r <= 1'b1;
						end
						else if (pending_accept) begin
							for (i = 0; i < 10; i = i + 1)
								pendf[i] <= (i == yunit_pkg_DMA_COMMAND ? reg_wdata : regf[i]);
							pend_trig <= 1'b1;
							busy_r <= 1'b1;
						end
					end
					else if (state == 3'd0)
						busy_r <= 1'b0;
					else begin
						busy_r <= 1'b0;
						if (state_n != 3'd0)
							abort_r <= 1'b1;
					end
				end
			end
			if (abort_r && (state_n == 3'd0))
				abort_r <= 1'b0;
			if ((state == 3'd0) && pend_trig) begin
				for (i = 0; i < 10; i = i + 1)
					launchf[i] <= pendf[i];
				pend_trig <= 1'b0;
			end
			pace_arm <= state == 3'd2;
			if (pace_arm)
				pace_cnt <= ({14'd0, width_c[11:0]} * {14'd0, height_c[11:0]}) << 2;
			else if (pace_cnt != 26'd0)
				pace_cnt <= pace_cnt - 26'd1;
			(* full_case, parallel_case *)
			case (state)
				3'd2: begin
					mode_c <= mode_w;
					flipx_c <= flipx_w;
					readmode_c <= readmode_w;
					width_c <= (width_f <= 32'sd0 ? 12'sd0 : $signed(width12));
					height_c <= (height1 <= 32'sd0 ? 12'sd0 : $signed(height12));
					xpos_c <= $signed(xpos12);
					ypos_c <= $signed(ypos12);
					rowbytes_c <= rb_adj;
					pal16_c <= {pal_lo, 8'h00};
					color16_c <= {pal_lo, col_lo};
					row_i <= 12'sd0;
					cur_off <= offbytes_c;
				end
				3'd3: begin
					ty <= ty_next;
					tx <= xpos_c;
					col_i <= 12'sd0;
					o_ptr <= cur_off;
					if (row_i < height_c) begin
						cur_off <= cur_off + rowbytes_c;
						row_i <= row_i + 12'sd1;
					end
				end
				3'd4:
					if (readmode_c && src_ack) begin
						px <= src_data;
						px_zero <= src_data == 8'd0;
					end
				3'd5: begin
					if (pix_we) begin
						fb_we <= 1'b1;
						fb_addr <= {ty, tx9};
						fb_wdata <= pix_data;
					end
					if (!pix_we || fb_ack) begin
						tx <= tx + (flipx_c ? -12'sd1 : 12'sd1);
						col_i <= col_i + 12'sd1;
						if (readmode_c)
							o_ptr <= o_ptr + 32'sd1;
					end
				end
				3'd6:
					if (dma_done_ok) begin
						if (pend_trig || pending_accept)
							blit_irq <= 1'b0;
						else begin
							busy_r <= 1'b0;
							blit_irq <= 1'b1;
						end
					end
				default:
					;
			endcase
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_memsys_family2 (
	clk,
	rst,
	mem_req,
	mem_we,
	mem_addr,
	mem_size,
	mem_wdata,
	mem_rdata,
	mem_ack,
	src_req,
	src_addr,
	src_data,
	src_ack,
	inputs,
	game_id,
	cpu_pc,
	term2_adc,
	term2_adc_sel,
	bpp4,
	gfx_bytes,
	cmos_quiesce,
	nvram_ext_en,
	nvram_ext_wr,
	nvram_ext_addr,
	nvram_ext_wdata,
	nvram_ext_rdata,
	cmos_cpu_busy,
	cmos_cpu_write_pulse,
	shift_req,
	shift_write,
	shift_entry,
	shift_rdata,
	shift_ready,
	shift_done,
	shift_invalidate_valid,
	shift_invalidate_row,
	int1,
	snd_select,
	snd_trig,
	snd_reset,
	dbg_p1ctrl,
	dbg_bdir,
	erase_start,
	erase_row0,
	erase_lines,
	erase_line_valid,
	erase_line_first,
	erase_line_row,
	erase_frame_raw_ok,
	erase_frame_start,
	autoerase_off,
	erase_busy,
	blit_busy,
	blit_engine_active,
	fb_busy,
	fb_snoop_we,
	fb_snoop_addr,
	fb_snoop_data,
	dbg_blit_total,
	dbg_blit_thin,
	dbg_dma_we,
	dbg_dma_addr,
	dbg_dma_wdata,
	cpu_gfx_rd,
	cpu_gfx_raddr,
	cpu_gfx_rdata,
	cpu_gfx_rack,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	sdram_por,
	ddram_addr,
	ddram_burstcnt,
	ddram_rd,
	ddram_we,
	ddram_din,
	ddram_be,
	ddram_busy,
	ddram_dout,
	ddram_dout_ready,
	palv_we_a,
	palv_aa,
	palv_awd,
	palv_we_b,
	palv_ba,
	palv_bwd
);
	parameter ROM_HEX = "smashtv_maindata.hex";
	parameter signed [31:0] ROM_WORDS = 32'h00020000;
	parameter signed [31:0] ROM_WORD_OFFSET = 32'h00060000;
	parameter signed [31:0] GFX_PIXELS = 32'h00180000;
	input wire clk;
	input wire rst;
	input wire mem_req;
	input wire mem_we;
	input wire [31:0] mem_addr;
	input wire [5:0] mem_size;
	input wire [31:0] mem_wdata;
	output wire [31:0] mem_rdata;
	output wire mem_ack;
	output wire src_req;
	output wire [23:0] src_addr;
	input wire [7:0] src_data;
	input wire src_ack;
	input wire [63:0] inputs;
	input wire [3:0] game_id;
	input wire [31:0] cpu_pc;
	input wire [7:0] term2_adc;
	output wire [1:0] term2_adc_sel;
	input wire bpp4;
	input wire [23:0] gfx_bytes;
	input wire cmos_quiesce;
	input wire nvram_ext_en;
	input wire nvram_ext_wr;
	input wire [14:0] nvram_ext_addr;
	input wire [7:0] nvram_ext_wdata;
	output wire [7:0] nvram_ext_rdata;
	output wire cmos_cpu_busy;
	output wire cmos_cpu_write_pulse;
	input wire shift_req;
	input wire shift_write;
	input wire [17:0] shift_entry;
	output wire [15:0] shift_rdata;
	output wire shift_ready;
	output wire shift_done;
	output wire shift_invalidate_valid;
	output wire [8:0] shift_invalidate_row;
	output wire int1;
	output wire [7:0] snd_select;
	output wire snd_trig;
	output wire snd_reset;
	output wire [31:0] dbg_p1ctrl;
	output wire [31:0] dbg_bdir;
	input wire erase_start;
	input wire [8:0] erase_row0;
	input wire [9:0] erase_lines;
	input wire erase_line_valid;
	input wire erase_line_first;
	input wire [8:0] erase_line_row;
	input wire erase_frame_raw_ok;
	input wire erase_frame_start;
	input wire autoerase_off;
	output wire erase_busy;
	output wire blit_busy;
	output wire blit_engine_active;
	output wire fb_busy;
	output wire fb_snoop_we;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	output wire [17:0] fb_snoop_addr;
	output wire [15:0] fb_snoop_data;
	output wire [31:0] dbg_blit_total;
	output wire [31:0] dbg_blit_thin;
	output wire dbg_dma_we;
	output wire [3:0] dbg_dma_addr;
	output wire [15:0] dbg_dma_wdata;
	output wire cpu_gfx_rd;
	output wire [23:0] cpu_gfx_raddr;
	input wire [15:0] cpu_gfx_rdata;
	input wire cpu_gfx_rack;
	input wire scan_req;
	input wire [17:0] scan_addr;
	output wire [15:0] scan_data;
	output wire scan_ack;
	input wire sdram_por;
	output wire [28:0] ddram_addr;
	output wire [7:0] ddram_burstcnt;
	output wire ddram_rd;
	output wire ddram_we;
	output wire [63:0] ddram_din;
	output wire [7:0] ddram_be;
	input wire ddram_busy;
	input wire [63:0] ddram_dout;
	input wire ddram_dout_ready;
	output wire palv_we_a;
	output wire [12:0] palv_aa;
	output wire [15:0] palv_awd;
	output wire palv_we_b;
	output wire [12:0] palv_ba;
	output wire [15:0] palv_bwd;
	wire is_dma_now = mem_addr[31:20] == 12'h01a;
	wire mem_req_m;
	wire [31:0] mem_rdata_m;
	wire mem_ack_m;
	wire dma_reg_we;
	wire [3:0] dma_reg_addr;
	wire [15:0] dma_reg_wdata;
	wire [15:0] dma_reg_rdata;
	wire dma_fb_we;
	wire [17:0] dma_fb_addr;
	wire [15:0] dma_fb_wdata;
	wire [15:0] dma_palette;
	wire dma_trigger_blocked;
	wire mem_fb_ack;
	wire dma_fb_ack = mem_fb_ack;
	wire mem_fb_busy;
	wire dma_fb_busy = mem_fb_busy;
	wire dma_fb_flush;
	assign fb_snoop_we = dma_fb_we && dma_fb_ack;
	assign fb_snoop_addr = dma_fb_addr;
	assign fb_snoop_data = dma_fb_wdata;
	assign fb_busy = dma_fb_busy;
	yunit_mem_family2 #(
		.ROM_HEX(ROM_HEX),
		.ROM_WORDS(ROM_WORDS),
		.ROM_WORD_OFFSET(ROM_WORD_OFFSET),
		.GFX_PIXELS(GFX_PIXELS)
	) u_mem(
		.clk(clk),
		.rst(rst),
		.mem_req(mem_req_m),
		.mem_we(mem_we),
		.mem_addr(mem_addr),
		.mem_size(mem_size),
		.mem_wdata(mem_wdata),
		.mem_rdata(mem_rdata_m),
		.mem_ack(mem_ack_m),
		.fb_we(dma_fb_we),
		.fb_addr(dma_fb_addr),
		.fb_wdata(dma_fb_wdata),
		.dma_palette(dma_palette),
		.inputs(inputs),
		.game_id(game_id),
		.cpu_pc(cpu_pc),
		.term2_adc(term2_adc),
		.term2_adc_sel(term2_adc_sel),
		.bpp4(bpp4),
		.gfx_bytes(gfx_bytes),
		.cmos_quiesce(cmos_quiesce),
		.nvram_ext_en(nvram_ext_en),
		.nvram_ext_wr(nvram_ext_wr),
		.nvram_ext_addr(nvram_ext_addr),
		.nvram_ext_wdata(nvram_ext_wdata),
		.nvram_ext_rdata(nvram_ext_rdata),
		.cmos_cpu_busy(cmos_cpu_busy),
		.cmos_cpu_write_pulse(cmos_cpu_write_pulse),
		.shift_req(shift_req),
		.shift_write(shift_write),
		.shift_entry(shift_entry),
		.shift_rdata(shift_rdata),
		.shift_ready(shift_ready),
		.shift_done(shift_done),
		.shift_invalidate_valid(shift_invalidate_valid),
		.shift_invalidate_row(shift_invalidate_row),
		.snd_select(snd_select),
		.snd_trig(snd_trig),
		.snd_reset(snd_reset),
		.dbg_p1ctrl(dbg_p1ctrl),
		.dbg_bdir(dbg_bdir),
		.erase_start(erase_start),
		.erase_row0(erase_row0),
		.erase_lines(erase_lines),
		.autoerase_off(autoerase_off),
		.erase_line_valid(erase_line_valid),
		.erase_line_first(erase_line_first),
		.erase_line_row(erase_line_row),
		.erase_frame_raw_ok(erase_frame_raw_ok),
		.erase_frame_start(erase_frame_start),
		.erase_busy(erase_busy),
		.gfx_rd(cpu_gfx_rd),
		.gfx_raddr(cpu_gfx_raddr),
		.gfx_rdata(cpu_gfx_rdata),
		.gfx_rack(cpu_gfx_rack),
		.fb_ack(mem_fb_ack),
		.fb_busy(mem_fb_busy),
		.fb_flush(dma_fb_flush),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack),
		.sdram_por(sdram_por),
		.ddram_addr(ddram_addr),
		.ddram_burstcnt(ddram_burstcnt),
		.ddram_rd(ddram_rd),
		.ddram_we(ddram_we),
		.ddram_din(ddram_din),
		.ddram_be(ddram_be),
		.ddram_busy(ddram_busy),
		.ddram_dout(ddram_dout),
		.ddram_dout_ready(ddram_dout_ready),
		.palv_we_a(palv_we_a),
		.palv_aa(palv_aa),
		.palv_awd(palv_awd),
		.palv_we_b(palv_we_b),
		.palv_ba(palv_ba),
		.palv_bwd(palv_bwd)
	);
	yunit_dma_family2 u_dma(
		.dbg_blit_total(dbg_blit_total),
		.dbg_blit_thin(dbg_blit_thin),
		.clk(clk),
		.rst(rst),
		.reg_we(dma_reg_we),
		.reg_addr(dma_reg_addr),
		.reg_wdata(dma_reg_wdata),
		.reg_rdata(dma_reg_rdata),
		.src_req(src_req),
		.src_addr(src_addr),
		.src_data(src_data),
		.src_ack(src_ack),
		.fb_we(dma_fb_we),
		.fb_addr(dma_fb_addr),
		.fb_wdata(dma_fb_wdata),
		.fb_ack(dma_fb_ack),
		.fb_busy(dma_fb_busy),
		.fb_flush(dma_fb_flush),
		.busy(blit_busy),
		.engine_active(blit_engine_active),
		.trigger_blocked(dma_trigger_blocked),
		.blit_irq(int1),
		.dma_palette(dma_palette)
	);
	reg [1:0] dstate;
	reg [31:0] d_addr_q;
	reg d_we_q;
	reg [31:0] d_wd_q;
	reg [5:0] d_sz_q;
	reg dma_ack;
	wire d_second = dstate == 2'd2;
	assign dma_reg_addr = (d_second ? d_addr_q[7:4] + 4'd1 : d_addr_q[7:4]);
	assign dma_reg_wdata = (d_second ? d_wd_q[31:16] : d_wd_q[15:0]);
	assign dbg_dma_we = dma_reg_we;
	assign dbg_dma_addr = dma_reg_addr;
	assign dbg_dma_wdata = dma_reg_wdata;
	assign dma_reg_we = (dstate == 2'd1) || (dstate == 2'd2);
	localparam signed [31:0] yunit_pkg_DMA_CMD_TRIG_BIT = 15;
	localparam [3:0] yunit_pkg_DMA_COMMAND = 4'd0;
	always @(posedge clk)
		if (rst) begin
			dstate <= 2'd0;
			dma_ack <= 1'b0;
		end
		else
			(* full_case, parallel_case *)
			case (dstate)
				2'd0: begin
					dma_ack <= 1'b0;
					if ((mem_req && is_dma_now) && !mem_ack) begin
						if (((mem_we && (mem_addr[7:4] == yunit_pkg_DMA_COMMAND)) && mem_wdata[yunit_pkg_DMA_CMD_TRIG_BIT]) && dma_trigger_blocked)
							;
						else begin
							d_addr_q <= mem_addr;
							d_we_q <= mem_we;
							d_wd_q <= mem_wdata;
							d_sz_q <= mem_size;
							dstate <= (mem_we ? 2'd1 : 2'd3);
						end
					end
				end
				2'd1: dstate <= (d_sz_q > 6'd16 ? 2'd2 : 2'd3);
				2'd2: dstate <= 2'd3;
				2'd3: begin
					dma_ack <= 1'b1;
					dstate <= 2'd0;
				end
				default: dstate <= 2'd0;
			endcase
	assign mem_req_m = mem_req && !is_dma_now;
	assign mem_ack = (is_dma_now ? dma_ack : mem_ack_m);
	assign mem_rdata = (is_dma_now ? {16'h0000, dma_reg_rdata} : mem_rdata_m);
endmodule
`default_nettype wire
`default_nettype none
module yunit_video_family2 (
	clk,
	rst,
	ce_pix,
	bpp4,
	disp_row_dyn,
	visible_px,
	disp_enable,
	vram_raddr,
	vram_rdata,
	pal_raddr,
	pal_rdata,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de,
	vblank_raw,
	vblank_irq
);
	reg _sv2v_0;
	parameter signed [31:0] H_ACT = 410;
	parameter signed [31:0] H_FP = 6;
	parameter signed [31:0] H_SYNC = 40;
	parameter signed [31:0] H_BP = 50;
	parameter signed [31:0] V_ACT = 256;
	parameter signed [31:0] V_FP = 13;
	parameter signed [31:0] V_SYNC = 8;
	parameter signed [31:0] V_BP = 12;
	parameter signed [31:0] DISP_ROW0 = 0;
	input wire clk;
	input wire rst;
	input wire ce_pix;
	input wire bpp4;
	input wire [8:0] disp_row_dyn;
	input wire [11:0] visible_px;
	input wire disp_enable;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	output wire [17:0] vram_raddr;
	input wire [15:0] vram_rdata;
	output wire [11:0] pal_raddr;
	input wire [15:0] pal_rdata;
	output reg [7:0] vid_r;
	output reg [7:0] vid_g;
	output reg [7:0] vid_b;
	output reg hsync;
	output reg vsync;
	output reg hblank;
	output reg vblank;
	output reg de;
	output wire vblank_raw;
	output reg vblank_irq;
	localparam signed [31:0] H_TOTAL = ((H_ACT + H_FP) + H_SYNC) + H_BP;
	localparam signed [31:0] V_TOTAL = ((V_ACT + V_FP) + V_SYNC) + V_BP;
	reg [11:0] hc;
	reg [11:0] vc;
	reg s0_de;
	reg s0_hs;
	reg s0_vs;
	reg s0_hb;
	reg s0_vb;
	reg [11:0] s0_x;
	reg [11:0] s0_y;
	function automatic signed [11:0] sv2v_cast_12_signed;
		input reg signed [11:0] inp;
		sv2v_cast_12_signed = inp;
	endfunction
	always @(posedge clk)
		if (rst) begin
			hc <= sv2v_cast_12_signed(H_ACT + H_FP);
			vc <= sv2v_cast_12_signed((V_ACT + V_FP) - 1);
			vblank_irq <= 1'b0;
		end
		else if (ce_pix) begin
			vblank_irq <= 1'b0;
			if (hc == (H_TOTAL - 1)) begin
				hc <= 1'sb0;
				if (vc == (V_TOTAL - 1))
					vc <= 1'sb0;
				else begin
					vc <= vc + 12'd1;
					if (vc == (V_ACT - 1))
						vblank_irq <= 1'b1;
				end
			end
			else
				hc <= hc + 12'd1;
		end
	always @(*) begin
		if (_sv2v_0)
			;
		s0_x = hc;
		s0_y = vc;
		s0_de = (hc < H_ACT) && (vc < V_ACT);
		s0_hb = hc >= H_ACT;
		s0_vb = vc >= V_ACT;
		s0_hs = (hc >= (H_ACT + H_FP)) && (hc < ((H_ACT + H_FP) + H_SYNC));
		s0_vs = (vc >= (V_ACT + V_FP)) && (vc < ((V_ACT + V_FP) + V_SYNC));
	end
	function automatic [8:0] sv2v_cast_9;
		input reg [8:0] inp;
		sv2v_cast_9 = inp;
	endfunction
	wire [8:0] fb_row = sv2v_cast_9(disp_row_dyn + sv2v_cast_9(s0_y));
	localparam signed [31:0] yunit_pkg_FB_ROWSHIFT = 9;
	function automatic [17:0] sv2v_cast_18;
		input reg [17:0] inp;
		sv2v_cast_18 = inp;
	endfunction
	assign vram_raddr = sv2v_cast_18((fb_row << yunit_pkg_FB_ROWSHIFT) + (s0_x & 12'h1ff));
	assign vblank_raw = s0_vb;
	reg s1_de;
	reg s1_hs;
	reg s1_vs;
	reg s1_hb;
	reg s1_vb;
	reg s2_de;
	reg s2_hs;
	reg s2_vs;
	reg s2_hb;
	reg s2_vb;
	always @(posedge clk)
		if (rst) begin
			s1_de <= 0;
			s1_hs <= 0;
			s1_vs <= 0;
			s1_hb <= 0;
			s1_vb <= 0;
			s2_de <= 0;
			s2_hs <= 0;
			s2_vs <= 0;
			s2_hb <= 0;
			s2_vb <= 0;
		end
		else if (ce_pix) begin
			s1_de <= s0_de;
			s1_hs <= s0_hs;
			s1_vs <= s0_vs;
			s1_hb <= s0_hb;
			s1_vb <= s0_vb;
			s2_de <= s1_de;
			s2_hs <= s1_hs;
			s2_vs <= s1_vs;
			s2_hb <= s1_hb;
			s2_vb <= s1_vb;
		end
	function automatic [11:0] yunit_pkg_pen_map4;
		input reg [15:0] w;
		yunit_pkg_pen_map4 = {4'b0000, w[15:12], w[3:0]};
	endfunction
	function automatic [11:0] yunit_pkg_pen_map6;
		input reg [15:0] w;
		yunit_pkg_pen_map6 = {w[11:8], w[15:14], w[5:0]};
	endfunction
	assign pal_raddr = (bpp4 === 1'b1 ? yunit_pkg_pen_map4(vram_rdata) : yunit_pkg_pen_map6(vram_rdata));
	wire [23:0] rgb;
	function automatic [23:0] yunit_pkg_rgb555_to_888;
		input reg [15:0] c;
		reg [4:0] r5;
		reg [4:0] g5;
		reg [4:0] b5;
		begin
			r5 = c[14:10];
			g5 = c[9:5];
			b5 = c[4:0];
			yunit_pkg_rgb555_to_888 = {r5, r5[4:2], g5, g5[4:2], b5, b5[4:2]};
		end
	endfunction
	assign rgb = yunit_pkg_rgb555_to_888(pal_rdata);
	wire s0_vis = s0_x < visible_px;
	reg s1_vis;
	reg s2_vis;
	always @(posedge clk)
		if (rst) begin
			s1_vis <= 1'b1;
			s2_vis <= 1'b1;
		end
		else if (ce_pix) begin
			s1_vis <= s0_vis;
			s2_vis <= s1_vis;
		end
	wire s0_env = (disp_enable === 1'b0 ? 1'b0 : 1'b1);
	reg s1_env;
	reg s2_env;
	always @(posedge clk)
		if (rst) begin
			s1_env <= 1'b1;
			s2_env <= 1'b1;
		end
		else if (ce_pix) begin
			s1_env <= s0_env;
			s2_env <= s1_env;
		end
	wire pix_on = (s2_de && s2_vis) && s2_env;
	always @(posedge clk)
		if (rst) begin
			de <= 0;
			hsync <= 0;
			vsync <= 0;
			hblank <= 0;
			vblank <= 0;
			vid_r <= 0;
			vid_g <= 0;
			vid_b <= 0;
		end
		else if (ce_pix) begin
			de <= s2_de;
			hsync <= s2_hs;
			vsync <= s2_vs;
			hblank <= s2_hb;
			vblank <= s2_vb;
			vid_r <= (pix_on ? rgb[23:16] : 8'h00);
			vid_g <= (pix_on ? rgb[15:8] : 8'h00);
			vid_b <= (pix_on ? rgb[7:0] : 8'h00);
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_scanline_family2 (
	clk,
	rst,
	ce_pix,
	vblank,
	first_row_dyn,
	vram_raddr,
	vram_rdata,
	snoop_we,
	snoop_addr,
	snoop_data,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack
);
	reg _sv2v_0;
	parameter signed [31:0] FB_ADDR_W = 18;
	parameter signed [31:0] NCOL = 512;
	parameter signed [31:0] FIRST_ROW = 0;
	input wire clk;
	input wire rst;
	input wire ce_pix;
	input wire vblank;
	input wire [8:0] first_row_dyn;
	input wire [FB_ADDR_W - 1:0] vram_raddr;
	output reg [15:0] vram_rdata;
	input wire snoop_we;
	input wire [FB_ADDR_W - 1:0] snoop_addr;
	input wire [15:0] snoop_data;
	output reg scan_req;
	output wire [17:0] scan_addr;
	input wire [15:0] scan_data;
	input wire scan_ack;
	localparam signed [31:0] ROWW = FB_ADDR_W - 9;
	wire [ROWW - 1:0] req_row = vram_raddr[FB_ADDR_W - 1:9];
	wire [8:0] req_col = vram_raddr[8:0];
	(* ramstyle = "no_rw_check" *) reg [15:0] lb0 [0:511];
	(* ramstyle = "no_rw_check" *) reg [15:0] lb1 [0:511];
	(* ramstyle = "no_rw_check" *) reg [15:0] ov0 [0:511];
	(* ramstyle = "no_rw_check" *) reg [15:0] ov1 [0:511];
	reg [511:0] ov0_valid;
	reg [511:0] ov1_valid;
	reg disp_sel;
	reg [ROWW - 1:0] disp_row;
	wire sel_now = (req_row == disp_row ? disp_sel : ~disp_sel);
	function automatic [ROWW - 1:0] sv2v_cast_AD1AC;
		input reg [ROWW - 1:0] inp;
		sv2v_cast_AD1AC = inp;
	endfunction
	wire [ROWW - 1:0] planned_row0 = (vblank ? sv2v_cast_AD1AC(first_row_dyn) : (sel_now ? req_row + 1'b1 : req_row));
	wire [ROWW - 1:0] planned_row1 = (vblank ? sv2v_cast_AD1AC(first_row_dyn + 9'd1) : (sel_now ? req_row : req_row + 1'b1));
	always @(posedge clk)
		if (ce_pix) begin
			if (sel_now)
				vram_rdata <= (ov1_valid[req_col] ? ov1[req_col] : lb1[req_col]);
			else
				vram_rdata <= (ov0_valid[req_col] ? ov0[req_col] : lb0[req_col]);
		end
	reg [ROWW - 1:0] buf_row [0:1];
	reg buf_valid [0:1];
	wire [ROWW - 1:0] next_row = disp_row + 1'b1;
	wire [ROWW - 1:0] snoop_row = snoop_addr[FB_ADDR_W - 1:9];
	wire [8:0] snoop_col = snoop_addr[8:0];
	reg loading;
	reg tgt_sel;
	reg [ROWW - 1:0] tgt_row;
	reg [8:0] li;
	reg vbl_q;
	wire frame_start = !vbl_q && vblank;
	wire row_advance = !vblank && (req_row != disp_row);
	wire snoop_to0 = ((snoop_we && (snoop_col < NCOL)) && (snoop_row == planned_row0)) && (vblank || sel_now);
	wire snoop_to1 = ((snoop_we && (snoop_col < NCOL)) && (snoop_row == planned_row1)) && (vblank || !sel_now);
	reg [511:0] ov0_valid_next;
	reg [511:0] ov1_valid_next;
	always @(*) begin
		if (_sv2v_0)
			;
		ov0_valid_next = ov0_valid;
		ov1_valid_next = ov1_valid;
		if (frame_start) begin
			ov0_valid_next = 1'sb0;
			ov1_valid_next = 1'sb0;
		end
		else if (row_advance) begin
			if (disp_sel)
				ov1_valid_next = 1'sb0;
			else
				ov0_valid_next = 1'sb0;
		end
		if (snoop_to0)
			ov0_valid_next[snoop_col] = 1'b1;
		if (snoop_to1)
			ov1_valid_next[snoop_col] = 1'b1;
	end
	wire disp_stale = !buf_valid[disp_sel] || (buf_row[disp_sel] != disp_row);
	wire load_stale = !buf_valid[~disp_sel] || (buf_row[~disp_sel] != next_row);
	always @(posedge clk)
		if (rst) begin
			loading <= 1'b0;
			scan_req <= 1'b0;
			disp_sel <= 1'b0;
			disp_row <= 1'sb0;
			buf_valid[0] <= 1'b0;
			buf_valid[1] <= 1'b0;
			ov0_valid <= 1'sb0;
			ov1_valid <= 1'sb0;
			vbl_q <= 1'b0;
		end
		else begin
			vbl_q <= vblank;
			ov0_valid <= ov0_valid_next;
			ov1_valid <= ov1_valid_next;
			if (frame_start) begin
				disp_sel <= 1'b0;
				disp_row <= sv2v_cast_AD1AC(first_row_dyn);
				buf_valid[0] <= 1'b0;
				buf_valid[1] <= 1'b0;
				loading <= 1'b0;
				scan_req <= 1'b0;
			end
			else begin
				if (row_advance) begin
					disp_sel <= ~disp_sel;
					disp_row <= req_row;
				end
				if (!loading) begin
					if (disp_stale) begin
						tgt_sel <= disp_sel;
						tgt_row <= disp_row;
						li <= 9'd0;
						loading <= 1'b1;
					end
					else if (load_stale) begin
						tgt_sel <= ~disp_sel;
						tgt_row <= next_row;
						li <= 9'd0;
						loading <= 1'b1;
					end
				end
				else if (scan_req && scan_ack) begin
					if (tgt_sel)
						lb1[li] <= scan_data;
					else
						lb0[li] <= scan_data;
					scan_req <= 1'b0;
					if (li == (NCOL - 1)) begin
						loading <= 1'b0;
						buf_row[tgt_sel] <= tgt_row;
						buf_valid[tgt_sel] <= 1'b1;
					end
					else
						li <= li + 9'd1;
				end
				else if (!scan_req)
					scan_req <= 1'b1;
			end
			if (snoop_to0)
				ov0[snoop_col] <= snoop_data;
			if (snoop_to1)
				ov1[snoop_col] <= snoop_data;
		end
	assign scan_addr = {tgt_row[8:0], li};
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_video_top_family2 (
	clk,
	rst,
	ce_pix,
	bpp4,
	disp_row_next,
	visible_px,
	disp_enable,
	snoop_we,
	snoop_addr,
	snoop_data,
	pal_raddr,
	pal_rdata,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de,
	vblank_irq
);
	parameter signed [31:0] H_ACT = 410;
	parameter signed [31:0] H_FP = 6;
	parameter signed [31:0] H_SYNC = 40;
	parameter signed [31:0] H_BP = 50;
	parameter signed [31:0] V_ACT = 256;
	parameter signed [31:0] V_FP = 13;
	parameter signed [31:0] V_SYNC = 8;
	parameter signed [31:0] V_BP = 12;
	parameter signed [31:0] DISP_ROW0 = 0;
	parameter signed [31:0] NCOL = 512;
	input wire clk;
	input wire rst;
	input wire ce_pix;
	input wire bpp4;
	input wire [8:0] disp_row_next;
	input wire [11:0] visible_px;
	input wire disp_enable;
	input wire snoop_we;
	input wire [17:0] snoop_addr;
	input wire [15:0] snoop_data;
	output wire [11:0] pal_raddr;
	input wire [15:0] pal_rdata;
	output wire scan_req;
	output wire [17:0] scan_addr;
	input wire [15:0] scan_data;
	input wire scan_ack;
	output wire [7:0] vid_r;
	output wire [7:0] vid_g;
	output wire [7:0] vid_b;
	output wire hsync;
	output wire vsync;
	output wire hblank;
	output wire vblank;
	output wire de;
	output wire vblank_irq;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	wire [17:0] vram_raddr;
	wire [15:0] vram_rdata;
	wire vblank_i;
	wire vblank_scan;
	reg [8:0] disp_row_q;
	reg vbl_scan_q;
	always @(posedge clk)
		if (rst) begin
			disp_row_q <= 9'd0;
			vbl_scan_q <= 1'b0;
		end
		else begin
			vbl_scan_q <= vblank_scan;
			if (vblank_scan && !vbl_scan_q)
				disp_row_q <= disp_row_next;
		end
	yunit_video_family2 #(
		.H_ACT(H_ACT),
		.H_FP(H_FP),
		.H_SYNC(H_SYNC),
		.H_BP(H_BP),
		.V_ACT(V_ACT),
		.V_FP(V_FP),
		.V_SYNC(V_SYNC),
		.V_BP(V_BP),
		.DISP_ROW0(DISP_ROW0)
	) u_video(
		.clk(clk),
		.rst(rst),
		.ce_pix(ce_pix),
		.bpp4(bpp4),
		.disp_row_dyn(disp_row_q),
		.visible_px(visible_px),
		.disp_enable(disp_enable),
		.vram_raddr(vram_raddr),
		.vram_rdata(vram_rdata),
		.pal_raddr(pal_raddr),
		.pal_rdata(pal_rdata),
		.vid_r(vid_r),
		.vid_g(vid_g),
		.vid_b(vid_b),
		.hsync(hsync),
		.vsync(vsync),
		.hblank(hblank),
		.vblank(vblank_i),
		.de(de),
		.vblank_raw(vblank_scan),
		.vblank_irq(vblank_irq)
	);
	assign vblank = vblank_i;
	wire scanline_vblank = vblank_scan;
	yunit_scanline_family2 #(
		.FB_ADDR_W(yunit_pkg_FB_ADDR_W),
		.NCOL(NCOL),
		.FIRST_ROW(DISP_ROW0)
	) u_scan(
		.clk(clk),
		.rst(rst),
		.ce_pix(ce_pix),
		.vblank(scanline_vblank),
		.first_row_dyn(disp_row_next),
		.vram_raddr(vram_raddr),
		.vram_rdata(vram_rdata),
		.snoop_we(snoop_we),
		.snoop_addr(snoop_addr),
		.snoop_data(snoop_data),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack)
	);
endmodule
`default_nettype wire
`default_nettype none
module yunit_top_family2 (
	clk,
	clk_cpu,
	ce_pix,
	cpu_div_sel,
	clk_snd,
	rst,
	rst_pon,
	sdram_por,
	inputs,
	game_id,
	term2_analog,
	cmos_quiesce,
	nvram_ext_en,
	nvram_ext_wr,
	nvram_ext_addr,
	nvram_ext_wdata,
	nvram_ext_rdata,
	cmos_cpu_busy,
	cmos_cpu_write_pulse,
	ioctl_download,
	gfx_download,
	sound_download,
	ioctl_wr,
	ioctl_addr,
	ioctl_dout,
	ioctl_be,
	ioctl_wait,
	snd_dl_wr,
	snd_dl_addr,
	snd_dl_data,
	SDRAM_DQ,
	SDRAM_A,
	SDRAM_BA,
	SDRAM_DQML,
	SDRAM_DQMH,
	SDRAM_nCS,
	SDRAM_nRAS,
	SDRAM_nCAS,
	SDRAM_nWE,
	SDRAM_CKE,
	DDRAM_ADDR,
	DDRAM_BURSTCNT,
	DDRAM_RD,
	DDRAM_DIN,
	DDRAM_BE,
	DDRAM_WE,
	DDRAM_BUSY,
	DDRAM_DOUT,
	DDRAM_DOUT_READY,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de,
	audio_l,
	audio_r,
	adpcm_irq,
	pc_dbg,
	illegal_dbg,
	dbg_core_rst,
	dbg_sdram_ready,
	dbg_unp_done,
	dbg_cpu_req,
	dbg_mem_ack,
	dbg_int1,
	dbg_vblank_irq,
	dbg_cpu_ce,
	dbg_p1ctrl,
	dbg_bdir,
	dbg_snd_select,
	dbg_snd_trig,
	dbg_derailed,
	dbg_culprit_pc,
	dbg_culprit_instr,
	dbg_derail_pc,
	dbg_disp_flips,
	dbg_disp_rows,
	dbg_blit_total,
	dbg_blit_thin,
	autoerase_off,
	dbg_iol_drop,
	dbg_iol_wrs,
	dbg_dma_we,
	dbg_dma_addr,
	dbg_dma_wdata,
	dbg_src_data,
	dbg_src_ack,
	dbg_scan_data,
	dbg_scan_ack,
	dbg_cgfx_grants,
	dbg_snd_grants,
	dbg_cgfx_maxwait,
	dbg_snd_miss,
	dbg_snd_busy16,
	dbg_cvsd_moves,
	dbg_adpcm_moves,
	dbg_blank_pix,
	dbg_cpu_pc_moves,
	dbg_snd_acks,
	dbg_snd_first_words,
	dbg_snd_region_seen,
	dbg_snd_board_rst,
	dbg_restart_cnt
);
	reg _sv2v_0;
	parameter ROM_HEX = "smashtv_maindata.hex";
	parameter signed [31:0] H_ACT = 410;
	parameter signed [31:0] H_FP = 6;
	parameter signed [31:0] H_SYNC = 42;
	parameter signed [31:0] H_BP = 48;
	parameter signed [31:0] V_ACT = 256;
	parameter signed [31:0] V_FP = 13;
	parameter signed [31:0] V_SYNC = 3;
	parameter signed [31:0] V_BP = 17;
	parameter signed [31:0] DISP_ROW0 = 0;
	parameter [24:0] GFXW_BASE = 25'h0000000;
	parameter [24:0] ROMW_BASE = 25'h00c0000;
	parameter [24:0] VRAMW_BASE = 25'h00e0000;
	parameter [23:0] GFX_BYTES = 24'h180000;
	parameter [24:0] SCRATCH_WBASE = 25'h0120000;
	parameter [24:0] SOUNDW_BASE = 25'h0120000;
	parameter [23:0] PLANE_WORDS = 24'h030000;
	parameter signed [31:0] ROM_WORDS = 32'h00020000;
	parameter signed [31:0] ROM_WORD_OFFSET = 32'h00060000;
	input wire clk;
	input wire clk_cpu;
	input wire ce_pix;
	input wire [2:0] cpu_div_sel;
	input wire clk_snd;
	input wire rst;
	input wire rst_pon;
	input wire sdram_por;
	input wire [63:0] inputs;
	input wire [3:0] game_id;
	input wire [31:0] term2_analog;
	input wire cmos_quiesce;
	input wire nvram_ext_en;
	input wire nvram_ext_wr;
	input wire [14:0] nvram_ext_addr;
	input wire [7:0] nvram_ext_wdata;
	output wire [7:0] nvram_ext_rdata;
	output wire cmos_cpu_busy;
	output wire cmos_cpu_write_pulse;
	input wire ioctl_download;
	input wire gfx_download;
	input wire sound_download;
	input wire ioctl_wr;
	input wire [24:0] ioctl_addr;
	input wire [15:0] ioctl_dout;
	input wire [1:0] ioctl_be;
	output wire ioctl_wait;
	input wire snd_dl_wr;
	input wire [17:0] snd_dl_addr;
	input wire [7:0] snd_dl_data;
	inout wire [15:0] SDRAM_DQ;
	output wire [12:0] SDRAM_A;
	output wire [1:0] SDRAM_BA;
	output wire SDRAM_DQML;
	output wire SDRAM_DQMH;
	output wire SDRAM_nCS;
	output wire SDRAM_nRAS;
	output wire SDRAM_nCAS;
	output wire SDRAM_nWE;
	output wire SDRAM_CKE;
	output wire [28:0] DDRAM_ADDR;
	output wire [7:0] DDRAM_BURSTCNT;
	output wire DDRAM_RD;
	output wire [63:0] DDRAM_DIN;
	output wire [7:0] DDRAM_BE;
	output wire DDRAM_WE;
	input wire DDRAM_BUSY;
	input wire [63:0] DDRAM_DOUT;
	input wire DDRAM_DOUT_READY;
	output wire [7:0] vid_r;
	output wire [7:0] vid_g;
	output wire [7:0] vid_b;
	output wire hsync;
	output wire vsync;
	output wire hblank;
	output wire vblank;
	output wire de;
	output wire signed [15:0] audio_l;
	output wire signed [15:0] audio_r;
	output wire adpcm_irq;
	output wire [31:0] pc_dbg;
	output wire illegal_dbg;
	output wire dbg_core_rst;
	output wire dbg_sdram_ready;
	output wire dbg_unp_done;
	output wire dbg_cpu_req;
	output wire dbg_mem_ack;
	output wire dbg_int1;
	output wire dbg_vblank_irq;
	output wire dbg_cpu_ce;
	output wire [31:0] dbg_p1ctrl;
	output wire [31:0] dbg_bdir;
	output wire [7:0] dbg_snd_select;
	output wire dbg_snd_trig;
	output reg dbg_derailed;
	output reg [31:0] dbg_culprit_pc;
	output reg [15:0] dbg_culprit_instr;
	output reg [31:0] dbg_derail_pc;
	output wire [31:0] dbg_disp_flips;
	output wire [31:0] dbg_disp_rows;
	output wire [31:0] dbg_blit_total;
	output wire [31:0] dbg_blit_thin;
	input wire autoerase_off;
	output wire [31:0] dbg_iol_drop;
	output wire [31:0] dbg_iol_wrs;
	output wire dbg_dma_we;
	output wire [3:0] dbg_dma_addr;
	output wire [15:0] dbg_dma_wdata;
	output wire [7:0] dbg_src_data;
	output wire dbg_src_ack;
	output wire [15:0] dbg_scan_data;
	output wire dbg_scan_ack;
	output wire [15:0] dbg_cgfx_grants;
	output wire [15:0] dbg_snd_grants;
	output wire [31:0] dbg_cgfx_maxwait;
	output wire [15:0] dbg_snd_miss;
	output wire [15:0] dbg_snd_busy16;
	output wire [15:0] dbg_cvsd_moves;
	output wire [15:0] dbg_adpcm_moves;
	output wire [15:0] dbg_blank_pix;
	output wire [31:0] dbg_cpu_pc_moves;
	output wire [31:0] dbg_snd_acks;
	output wire [31:0] dbg_snd_first_words;
	output wire dbg_snd_region_seen;
	output wire dbg_snd_board_rst;
	output wire [15:0] dbg_restart_cnt;
	localparam [3:0] yunit_pkg_YG_SAURNFRNT = 4'd9;
	localparam [3:0] yunit_pkg_YG_STRKFORC = 4'd4;
	localparam [3:0] yunit_pkg_YG_TROG = 4'd1;
	function automatic yunit_pkg_yunit_is_4bpp;
		input reg [3:0] game;
		yunit_pkg_yunit_is_4bpp = ((game == yunit_pkg_YG_TROG) || (game == yunit_pkg_YG_STRKFORC)) || (game == yunit_pkg_YG_SAURNFRNT);
	endfunction
	wire game_bpp4 = yunit_pkg_yunit_is_4bpp(game_id);
	localparam [3:0] yunit_pkg_YG_HIIMPACT = 4'd2;
	localparam [3:0] yunit_pkg_YG_MK = 4'd5;
	localparam [3:0] yunit_pkg_YG_SHIMPACT = 4'd3;
	localparam [3:0] yunit_pkg_YG_TERM2 = 4'd6;
	localparam [3:0] yunit_pkg_YG_TOTCARN = 4'd7;
	function automatic [23:0] yunit_pkg_yunit_plane_words;
		input reg [3:0] game;
		case (game)
			yunit_pkg_YG_TROG: yunit_pkg_yunit_plane_words = 24'h060000;
			yunit_pkg_YG_HIIMPACT: yunit_pkg_yunit_plane_words = 24'h040000;
			yunit_pkg_YG_SHIMPACT: yunit_pkg_yunit_plane_words = 24'h080000;
			yunit_pkg_YG_STRKFORC, yunit_pkg_YG_SAURNFRNT: yunit_pkg_yunit_plane_words = 24'h060000;
			yunit_pkg_YG_MK, yunit_pkg_YG_TERM2: yunit_pkg_yunit_plane_words = 24'h100000;
			yunit_pkg_YG_TOTCARN: yunit_pkg_yunit_plane_words = 24'h080000;
			default: yunit_pkg_yunit_plane_words = 24'h030000;
		endcase
	endfunction
	wire [23:0] game_plane_words = (PLANE_WORDS != 24'h030000 ? PLANE_WORDS : yunit_pkg_yunit_plane_words(game_id));
	wire unused_wrapper_inputs = ^{gfx_download, sound_download, 24'h000000};
	wire sdram_ready;
	wire unp_done;
	wire core_rst = ((rst | ~sdram_ready) | ioctl_download) | ~unp_done;
	reg [4:0] cpu_ce_div;
	always @(*) begin
		if (_sv2v_0)
			;
		case (cpu_div_sel)
			3'd0: cpu_ce_div = 5'd4;
			3'd1: cpu_ce_div = 5'd6;
			3'd2: cpu_ce_div = 5'd8;
			3'd3: cpu_ce_div = 5'd10;
			3'd4: cpu_ce_div = 5'd12;
			3'd5: cpu_ce_div = 5'd14;
			3'd6: cpu_ce_div = 5'd16;
			default: cpu_ce_div = 5'd20;
		endcase
	end
	reg [4:0] ce_div;
	always @(posedge clk)
		if (rst)
			ce_div <= 5'd0;
		else
			ce_div <= (ce_div == (cpu_ce_div - 5'd1) ? 5'd0 : ce_div + 5'd1);
	wire cpu_ce = ce_div == 5'd0;
	reg core_rst_sys_m;
	reg core_rst_sys;
	always @(posedge clk) begin
		core_rst_sys_m <= core_rst;
		core_rst_sys <= core_rst_sys_m;
	end
	wire int1;
	wire cpu_req;
	wire cpu_we;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	wire [31:0] cpu_addr;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	wire [5:0] cpu_size;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	wire [31:0] cpu_wdata;
	wire [31:0] cpu_rdata;
	wire cpu_ack;
	wire erase_busy;
	wire blit_busy;
	wire blit_engine_active;
	wire [31:0] core_mem_rdata;
	wire core_mem_ack;
	wire cpu_shiftreg_req;
	wire cpu_shiftreg_write;
	wire [31:0] cpu_shiftreg_bit_addr;
	wire sr_req_ready;
	wire sr_done;
	wire [15:0] sr_read_data;
	wire sr_engine_req_valid;
	wire sr_engine_req_write;
	wire [31:0] sr_engine_req_bit_addr;
	wire sr_burst_req;
	wire [17:0] sr_burst_entry;
	wire sr_backend_ready;
	wire sr_invalidate_valid;
	wire [8:0] sr_invalidate_row;
	wire sr_core_ack;
	wire sr_error_sticky;
	wire sf_shiftreg_addr_ok = (!cpu_shiftreg_write && (cpu_shiftreg_bit_addr == 32'h001fe000)) || (((cpu_shiftreg_write && ((cpu_shiftreg_bit_addr & 32'hffefffff) >= 32'h0002c000)) && ((cpu_shiftreg_bit_addr & 32'hffefffff) <= 32'h000fc000)) && (cpu_shiftreg_bit_addr[12:0] == 13'd0));
	function automatic yunit_pkg_yunit_has_srt_restore;
		input reg [3:0] game;
		yunit_pkg_yunit_has_srt_restore = (game == yunit_pkg_YG_STRKFORC) || (game == yunit_pkg_YG_SAURNFRNT);
	endfunction
	wire sf_shiftreg_req = (cpu_shiftreg_req && yunit_pkg_yunit_has_srt_restore(game_id)) && sf_shiftreg_addr_ok;
	wire tms_display_wr_valid;
	localparam [31:0] tms34010_pkg_IO_REG_IDX_W = 5;
	wire [4:0] tms_display_wr_idx;
	wire [15:0] tms_display_wr_data;
	wire tms_display_line_wrap;
	wire [15:0] display_dpyadr_live;
	wire [5:0] state_w;
	localparam [31:0] tms34010_pkg_INSTR_WORD_WIDTH = 16;
	wire [15:0] instr_w;
	reg ce_pix_ph;
	wire timing_start;
	always @(posedge clk)
		if (core_rst_sys || timing_start)
			ce_pix_ph <= 1'b0;
		else if (ce_pix)
			ce_pix_ph <= ~ce_pix_ph;
	wire ce_pix_cnt = ce_pix & ce_pix_ph;
	tms34010_core u_core(
		.clk(clk),
		.ce_cpu(cpu_ce),
		.ce_pix(ce_pix_cnt),
		.rst(core_rst_sys),
		.mem_req(cpu_req),
		.mem_we(cpu_we),
		.mem_addr(cpu_addr),
		.mem_size(cpu_size),
		.mem_wdata(cpu_wdata),
		.mem_rdata(core_mem_rdata),
		.mem_ack(core_mem_ack),
		.state_o(state_w),
		.pc_o(pc_dbg),
		.instr_word_o(instr_w),
		.illegal_opcode_o(illegal_dbg),
		.instruction_start_o(),
		.instruction_retire_o(),
		.instruction_cycles_o(),
		.instruction_cycles_valid_o(),
		.timing_start_o(timing_start),
		.display_wr_valid_o(tms_display_wr_valid),
		.display_wr_idx_o(tms_display_wr_idx),
		.display_wr_data_o(tms_display_wr_data),
		.srt_fill_ack_i(sr_core_ack),
		.display_line_wrap_o(tms_display_line_wrap),
		.display_dpyadr_live_i(display_dpyadr_live),
		.display_dpyadr_live_valid_i(1'b1),
		.srt_fill_exact_enable_i(yunit_pkg_yunit_has_srt_restore(game_id)),
		.shiftreg_req_o(cpu_shiftreg_req),
		.shiftreg_write_o(cpu_shiftreg_write),
		.shiftreg_bit_addr_o(cpu_shiftreg_bit_addr),
		.lint1_in(int1)
	);
	yunit_shiftreg_command_bridge #(.AW(tms34010_pkg_ADDR_WIDTH)) u_shiftreg_cmd(
		.clk(clk),
		.rst(core_rst_sys),
		.cpu_ce(cpu_ce),
		.cpu_req(sf_shiftreg_req),
		.cpu_write(cpu_shiftreg_write),
		.cpu_bit_addr(cpu_shiftreg_bit_addr),
		.engine_req_valid(sr_engine_req_valid),
		.engine_req_ready(sr_req_ready),
		.engine_req_write(sr_engine_req_write),
		.engine_req_bit_addr(sr_engine_req_bit_addr),
		.engine_done(sr_done),
		.engine_error(1'b0),
		.core_ack(sr_core_ack),
		.error_sticky(sr_error_sticky)
	);
	assign core_mem_ack = cpu_ack | sr_core_ack;
	assign core_mem_rdata = (sr_core_ack ? {{16 {1'b0}}, sr_read_data} : cpu_rdata);
	assign sr_burst_req = sr_engine_req_valid && sr_req_ready;
	assign sr_burst_entry = sr_engine_req_bit_addr[20:3];
	assign sr_req_ready = sr_backend_ready && !blit_engine_active;
	wire display_frame_start;
	wire display_line_consumed_valid;
	wire display_line_consumed_first;
	wire [8:0] display_line_consumed_row;
	wire display_line_tick = timing_start | tms_display_line_wrap;
	wire [15:0] display_vcount_live;
	wire display_line_event;
	wire display_scanout_valid;
	wire [8:0] display_scanout_row_phys;
	wire [8:0] display_scanout_col_word;
	wire display_prefetch_valid;
	wire [8:0] display_prefetch_row_phys;
	wire [8:0] display_prefetch_col_word;
	wire display_contract_valid;
	localparam [4:0] tms34010_pkg_IO_IDX_DPYADR = 5'h1e;
	localparam [4:0] tms34010_pkg_IO_IDX_DPYCTL = 5'h08;
	localparam [4:0] tms34010_pkg_IO_IDX_DPYSTRT = 5'h09;
	localparam [4:0] tms34010_pkg_IO_IDX_DPYTAP = 5'h1b;
	localparam [4:0] tms34010_pkg_IO_IDX_VEBLNK = 5'h05;
	localparam [4:0] tms34010_pkg_IO_IDX_VSBLNK = 5'h06;
	localparam [4:0] tms34010_pkg_IO_IDX_VTOTAL = 5'h07;
	yunit_display_address_sequencer u_display_address(
		.clk(clk),
		.rst(core_rst_sys),
		.line_tick(display_line_tick),
		.dpyctl_we(tms_display_wr_valid && (tms_display_wr_idx == tms34010_pkg_IO_IDX_DPYCTL)),
		.dpyctl_wdata(tms_display_wr_data),
		.dpystart_we(tms_display_wr_valid && (tms_display_wr_idx == tms34010_pkg_IO_IDX_DPYSTRT)),
		.dpystart_wdata(tms_display_wr_data),
		.dpytap_we(tms_display_wr_valid && (tms_display_wr_idx == tms34010_pkg_IO_IDX_DPYTAP)),
		.dpytap_wdata(tms_display_wr_data),
		.dpyadr_we(tms_display_wr_valid && (tms_display_wr_idx == tms34010_pkg_IO_IDX_DPYADR)),
		.dpyadr_wdata(tms_display_wr_data),
		.veblnk_we(tms_display_wr_valid && (tms_display_wr_idx == tms34010_pkg_IO_IDX_VEBLNK)),
		.veblnk_wdata(tms_display_wr_data),
		.vsblnk_we(tms_display_wr_valid && (tms_display_wr_idx == tms34010_pkg_IO_IDX_VSBLNK)),
		.vsblnk_wdata(tms_display_wr_data),
		.vtotal_we(tms_display_wr_valid && (tms_display_wr_idx == tms34010_pkg_IO_IDX_VTOTAL)),
		.vtotal_wdata(tms_display_wr_data),
		.flip_hold(1'b0),
		.vcount_live(display_vcount_live),
		.dpyadr_live(display_dpyadr_live),
		.line_event(display_line_event),
		.scanout_valid(display_scanout_valid),
		.scanout_vcount(),
		.scanout_row_raw(),
		.scanout_row_phys(display_scanout_row_phys),
		.scanout_base_word(),
		.scanout_coladdr(),
		.scanout_col_word(display_scanout_col_word),
		.scanout_yoffset(),
		.prefetch_valid(display_prefetch_valid),
		.prefetch_vcount(),
		.prefetch_row_raw(),
		.prefetch_row_phys(display_prefetch_row_phys),
		.prefetch_base_word(),
		.prefetch_coladdr(),
		.prefetch_col_word(display_prefetch_col_word),
		.prefetch_yoffset(),
		.frame_start_o(display_frame_start),
		.line_consumed_valid(display_line_consumed_valid),
		.line_consumed_first(display_line_consumed_first),
		.line_consumed_row_raw(),
		.line_consumed_row_phys(display_line_consumed_row),
		.line_consumed_base_word(),
		.contract_valid(display_contract_valid),
		.unsupported_mode(),
		.config_invalid(),
		.timing_conflict_pulse(),
		.timing_conflict_sticky(),
		.line_deferred_pulse(),
		.line_deferred_sticky(),
		.sequence_error_pulse(),
		.sequence_error_sticky()
	);
	wire mem_req;
	wire mem_we;
	wire [31:0] mem_addr;
	wire [5:0] mem_size;
	wire [31:0] mem_wdata;
	wire [31:0] mem_rdata;
	wire mem_ack;
	yunit_mem_cdc #(
		.AW(tms34010_pkg_ADDR_WIDTH),
		.DW(tms34010_pkg_DATA_WIDTH),
		.SW(tms34010_pkg_FIELD_SIZE_WIDTH)
	) u_memcdc(
		.clk_cpu(clk),
		.ce_cpu(cpu_ce),
		.rst_cpu(core_rst_sys),
		.c_req(cpu_req && !sf_shiftreg_req),
		.c_we(cpu_we),
		.c_addr(cpu_addr),
		.c_size(cpu_size),
		.c_wdata(cpu_wdata),
		.c_ack(cpu_ack),
		.c_rdata(cpu_rdata),
		.clk_sys(clk),
		.rst_sys(core_rst_sys),
		.m_req(mem_req),
		.m_we(mem_we),
		.m_addr(mem_addr),
		.m_size(mem_size),
		.m_wdata(mem_wdata),
		.m_rdata(mem_rdata),
		.m_ack(mem_ack)
	);
	wire src_req;
	wire [23:0] src_addr;
	wire [7:0] src_data;
	wire src_ack;
	wire cgfx_rd;
	wire [23:0] cgfx_addr;
	wire [15:0] cgfx_data;
	wire cgfx_ack;
	wire scan_req;
	wire [17:0] scan_addr;
	wire [15:0] scan_data;
	wire scan_ack;
	wire [7:0] snd_select;
	wire snd_trig;
	wire snd_reset;
	wire [1:0] term2_adc_sel;
	reg [7:0] term2_adc;
	always @(*) begin
		if (_sv2v_0)
			;
		case (term2_adc_sel)
			2'd0: term2_adc = term2_analog[7:0];
			2'd1: term2_adc = term2_analog[15:8];
			2'd2: term2_adc = term2_analog[23:16];
			default: term2_adc = term2_analog[31:24];
		endcase
	end
	assign dbg_snd_select = snd_select;
	assign dbg_snd_trig = snd_trig;
	wire mem_fb_busy;
	wire fb_snoop_we;
	wire [17:0] fb_snoop_addr;
	wire [15:0] fb_snoop_data;
	wire palv_we_a;
	wire palv_we_b;
	wire [12:0] palv_aa;
	wire [12:0] palv_ba;
	wire [15:0] palv_awd;
	wire [15:0] palv_bwd;
	wire vblank_irq;
	reg [8:0] disp_row_dyn;
	reg erase_frame_raw_ok;
	function automatic [23:0] yunit_pkg_yunit_gfx_bytes;
		input reg [3:0] game;
		reg [23:0] pw;
		begin
			pw = yunit_pkg_yunit_plane_words(game);
			yunit_pkg_yunit_gfx_bytes = {pw[20:0], 3'b000};
		end
	endfunction
	function automatic signed [9:0] sv2v_cast_10_signed;
		input reg signed [9:0] inp;
		sv2v_cast_10_signed = inp;
	endfunction
	yunit_memsys_family2 #(
		.ROM_HEX(ROM_HEX),
		.ROM_WORDS(ROM_WORDS),
		.ROM_WORD_OFFSET(ROM_WORD_OFFSET),
		.GFX_PIXELS({8'h00, GFX_BYTES})
	) u_sys(
		.clk(clk),
		.rst(core_rst),
		.mem_req(mem_req),
		.mem_we(mem_we),
		.mem_addr(mem_addr),
		.mem_size(mem_size),
		.mem_wdata(mem_wdata),
		.mem_rdata(mem_rdata),
		.mem_ack(mem_ack),
		.src_req(src_req),
		.src_addr(src_addr),
		.src_data(src_data),
		.src_ack(src_ack),
		.inputs(inputs),
		.game_id(game_id),
		.cpu_pc(pc_dbg),
		.term2_adc(term2_adc),
		.term2_adc_sel(term2_adc_sel),
		.bpp4(game_bpp4),
		.gfx_bytes(yunit_pkg_yunit_gfx_bytes(game_id)),
		.int1(int1),
		.cmos_quiesce(cmos_quiesce),
		.nvram_ext_en(nvram_ext_en),
		.nvram_ext_wr(nvram_ext_wr),
		.nvram_ext_addr(nvram_ext_addr),
		.nvram_ext_wdata(nvram_ext_wdata),
		.nvram_ext_rdata(nvram_ext_rdata),
		.cmos_cpu_busy(cmos_cpu_busy),
		.cmos_cpu_write_pulse(cmos_cpu_write_pulse),
		.shift_req(sr_burst_req),
		.shift_write(sr_engine_req_write),
		.shift_entry(sr_burst_entry),
		.shift_rdata(sr_read_data),
		.shift_ready(sr_backend_ready),
		.shift_done(sr_done),
		.shift_invalidate_valid(sr_invalidate_valid),
		.shift_invalidate_row(sr_invalidate_row),
		.snd_select(snd_select),
		.snd_trig(snd_trig),
		.snd_reset(snd_reset),
		.dbg_p1ctrl(dbg_p1ctrl),
		.dbg_bdir(dbg_bdir),
		.erase_start(vblank_irq && !autoerase_off),
		.erase_row0(disp_row_dyn),
		.erase_lines(sv2v_cast_10_signed(V_ACT)),
		.erase_frame_start(display_frame_start),
		.erase_line_valid(display_line_consumed_valid),
		.erase_line_first(display_line_consumed_first),
		.erase_line_row(display_line_consumed_row),
		.erase_frame_raw_ok(erase_frame_raw_ok),
		.autoerase_off(autoerase_off),
		.erase_busy(erase_busy),
		.blit_busy(blit_busy),
		.blit_engine_active(blit_engine_active),
		.fb_busy(mem_fb_busy),
		.fb_snoop_we(fb_snoop_we),
		.fb_snoop_addr(fb_snoop_addr),
		.fb_snoop_data(fb_snoop_data),
		.dbg_blit_total(dbg_blit_total),
		.dbg_blit_thin(dbg_blit_thin),
		.dbg_dma_we(dbg_dma_we),
		.dbg_dma_addr(dbg_dma_addr),
		.dbg_dma_wdata(dbg_dma_wdata),
		.cpu_gfx_rd(cgfx_rd),
		.cpu_gfx_raddr(cgfx_addr),
		.cpu_gfx_rdata(cgfx_data),
		.cpu_gfx_rack(cgfx_ack),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack),
		.sdram_por(sdram_por),
		.ddram_addr(DDRAM_ADDR),
		.ddram_burstcnt(DDRAM_BURSTCNT),
		.ddram_rd(DDRAM_RD),
		.ddram_we(DDRAM_WE),
		.ddram_din(DDRAM_DIN),
		.ddram_be(DDRAM_BE),
		.ddram_busy(DDRAM_BUSY),
		.ddram_dout(DDRAM_DOUT),
		.ddram_dout_ready(DDRAM_DOUT_READY),
		.palv_we_a(palv_we_a),
		.palv_aa(palv_aa),
		.palv_awd(palv_awd),
		.palv_we_b(palv_we_b),
		.palv_ba(palv_ba),
		.palv_bwd(palv_bwd)
	);
	wire [11:0] pal_raddr;
	wire [15:0] pal_rdata;
	wire video_rst = core_rst_sys;
	wire video_phase_rst = video_rst | timing_start;
	localparam [4:0] tms34010_pkg_IO_IDX_HEBLNK = 5'h01;
	wire heblnk_we = tms_display_wr_valid && (tms_display_wr_idx == tms34010_pkg_IO_IDX_HEBLNK);
	localparam [4:0] tms34010_pkg_IO_IDX_HSBLNK = 5'h02;
	wire hsblnk_we = tms_display_wr_valid && (tms_display_wr_idx == tms34010_pkg_IO_IDX_HSBLNK);
	reg [11:0] crtc_heblnk;
	reg [11:0] crtc_hsblnk;
	reg crtc_env;
	wire dpyctl_we = tms_display_wr_valid && (tms_display_wr_idx == tms34010_pkg_IO_IDX_DPYCTL);
	always @(posedge clk)
		if (video_rst) begin
			crtc_heblnk <= 12'd45;
			crtc_hsblnk <= 12'd250;
			crtc_env <= 1'b1;
		end
		else begin
			if (heblnk_we)
				crtc_heblnk <= tms_display_wr_data[11:0];
			if (hsblnk_we)
				crtc_hsblnk <= tms_display_wr_data[11:0];
			if (dpyctl_we)
				crtc_env <= tms_display_wr_data[15];
		end
	wire [12:0] crtc_w = {1'b0, crtc_hsblnk} - {1'b0, crtc_heblnk};
	wire [13:0] crtc_px = {crtc_w, 1'b0};
	function automatic signed [13:0] sv2v_cast_14_signed;
		input reg signed [13:0] inp;
		sv2v_cast_14_signed = inp;
	endfunction
	function automatic signed [11:0] sv2v_cast_12_signed;
		input reg signed [11:0] inp;
		sv2v_cast_12_signed = inp;
	endfunction
	wire [11:0] visible_px = (crtc_w[12] || (crtc_px > sv2v_cast_14_signed(H_ACT)) ? sv2v_cast_12_signed(H_ACT) : crtc_px[11:0]);
	wire dpystrt_we = tms_display_wr_valid && (tms_display_wr_idx == tms34010_pkg_IO_IDX_DPYSTRT);
	wire [8:0] dpystrt_row_w = ~tms_display_wr_data[12:4];
	reg [8:0] dpystrt_row_pend;
	reg [8:0] dpystrt_row_ref;
	reg dpystrt_ref_set;
	reg disp_vblank_q;
	reg [31:0] dpystrt_flip_cnt;
	function automatic signed [8:0] sv2v_cast_9_signed;
		input reg signed [8:0] inp;
		sv2v_cast_9_signed = inp;
	endfunction
	wire [8:0] disp_row_next = (dpystrt_ref_set ? dpystrt_row_pend : sv2v_cast_9_signed(DISP_ROW0));
	always @(posedge clk)
		if (video_phase_rst) begin
			dpystrt_row_pend <= sv2v_cast_9_signed(DISP_ROW0);
			dpystrt_row_ref <= 9'd0;
			dpystrt_ref_set <= 1'b0;
			disp_row_dyn <= sv2v_cast_9_signed(DISP_ROW0);
			disp_vblank_q <= 1'b0;
			dpystrt_flip_cnt <= 32'd0;
		end
		else begin
			disp_vblank_q <= vblank;
			if (dpystrt_we) begin
				dpystrt_row_pend <= dpystrt_row_w;
				if (dpystrt_ref_set && (dpystrt_row_w != dpystrt_row_pend))
					dpystrt_flip_cnt <= dpystrt_flip_cnt + 32'd1;
				if (!dpystrt_ref_set) begin
					dpystrt_row_ref <= dpystrt_row_w;
					dpystrt_ref_set <= 1'b1;
				end
			end
			if (vblank && !disp_vblank_q)
				disp_row_dyn <= disp_row_next;
		end
	always @(posedge clk)
		if (video_phase_rst)
			erase_frame_raw_ok <= 1'b1;
		else if (vblank && !disp_vblank_q)
			erase_frame_raw_ok <= ({1'b0, disp_row_next} + sv2v_cast_10_signed(V_ACT)) <= 10'd512;
	wire full_video_snoop_we = fb_snoop_we;
	wire [17:0] full_video_snoop_addr = fb_snoop_addr;
	wire [15:0] full_video_snoop_data = fb_snoop_data;
	function automatic yunit_pkg_yunit_flip_x;
		input reg [3:0] game;
		yunit_pkg_yunit_flip_x = game == yunit_pkg_YG_TERM2;
	endfunction
	yunit_video_top #(
		.H_ACT(H_ACT),
		.H_FP(H_FP),
		.H_SYNC(H_SYNC),
		.H_BP(H_BP),
		.V_ACT(V_ACT),
		.V_FP(V_FP),
		.V_SYNC(V_SYNC),
		.V_BP(V_BP),
		.DISP_ROW0(DISP_ROW0),
		.NCOL(H_ACT)
	) u_video(
		.clk(clk),
		.rst(video_phase_rst),
		.ce_pix(ce_pix),
		.bpp4(game_bpp4),
		.use_dynamic_display(1'b1),
		.display_contract_valid(display_contract_valid),
		.display_line_event(display_line_event),
		.display_line_valid(display_scanout_valid),
		.display_line_row_phys(display_scanout_row_phys),
		.display_line_col_word(display_scanout_col_word),
		.display_prefetch_valid(display_prefetch_valid),
		.display_prefetch_row_phys(display_prefetch_row_phys),
		.display_prefetch_col_word(display_prefetch_col_word),
		.visible_px(visible_px),
		.flip_x(yunit_pkg_yunit_flip_x(game_id)),
		.snoop_we(full_video_snoop_we),
		.snoop_addr(full_video_snoop_addr),
		.snoop_data(full_video_snoop_data),
		.invalidate_valid(sr_invalidate_valid),
		.invalidate_row(sr_invalidate_row),
		.pal_raddr(pal_raddr),
		.pal_rdata(pal_rdata),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack),
		.vid_r(vid_r),
		.vid_g(vid_g),
		.vid_b(vid_b),
		.hsync(hsync),
		.vsync(vsync),
		.hblank(hblank),
		.vblank(vblank),
		.de(de),
		.vblank_irq(vblank_irq)
	);
	yunit_palram #(.AW(13)) u_pal(
		.clk(clk),
		.rst(core_rst),
		.we_a(palv_we_a),
		.aa(palv_aa),
		.awd(palv_awd),
		.we_b(palv_we_b),
		.ba(palv_ba),
		.bwd(palv_bwd),
		.raddr({1'b0, pal_raddr}),
		.rdata(pal_rdata)
	);
	wire [24:0] sd_addr;
	wire [15:0] sd_din;
	wire [15:0] sd_dout;
	wire [1:0] sd_be;
	wire sd_rd;
	wire sd_wr;
	wire sd_ack;
	wire iol_ack;
	localparam signed [31:0] IOL_AW = 9;
	localparam signed [31:0] IOL_HWM = 256;
	reg [42:0] iol_fifo [0:511];
	reg [IOL_AW:0] iol_wp;
	reg [IOL_AW:0] iol_rp;
	wire [IOL_AW:0] iol_occ = iol_wp - iol_rp;
	wire iol_full = iol_occ == 512;
	wire iol_empty = iol_wp == iol_rp;
	reg iol_hold;
	reg unp_owner;
	reg [24:0] iol_addr_r;
	reg [15:0] iol_din_r;
	reg [1:0] iol_be_r;
	reg [31:0] iol_drop_cnt;
	reg [31:0] iol_wr_cnt;
	always @(posedge clk)
		if (sdram_por) begin
			iol_wp <= 1'sb0;
			iol_rp <= 1'sb0;
			iol_hold <= 1'b0;
			iol_drop_cnt <= 1'sb0;
			iol_wr_cnt <= 1'sb0;
		end
		else begin
			if (ioctl_wr && !iol_full) begin
				iol_fifo[iol_wp[8:0]] <= {ioctl_addr, ioctl_dout, ioctl_be};
				iol_wp <= iol_wp + 1'b1;
				iol_wr_cnt <= iol_wr_cnt + 1'b1;
			end
			else if (ioctl_wr && iol_full)
				iol_drop_cnt <= iol_drop_cnt + 1'b1;
			if (!unp_owner) begin
				if (iol_hold && iol_ack)
					iol_hold <= 1'b0;
				if ((!iol_hold || (iol_hold && iol_ack)) && !iol_empty) begin
					{iol_addr_r, iol_din_r, iol_be_r} <= iol_fifo[iol_rp[8:0]];
					iol_hold <= 1'b1;
					iol_rp <= iol_rp + 1'b1;
				end
			end
		end
	assign ioctl_wait = iol_occ >= IOL_HWM[IOL_AW:0];
	wire unp_rd;
	wire unp_wr;
	wire unp_ack;
	wire [24:0] unp_addr;
	wire [15:0] unp_din;
	wire [15:0] unp_dout;
	wire b_iol_rd = (unp_owner ? unp_rd : 1'b0);
	wire b_iol_wr = (unp_owner ? unp_wr : iol_hold);
	wire [24:0] b_iol_addr = (unp_owner ? unp_addr : iol_addr_r);
	wire [15:0] b_iol_din = (unp_owner ? unp_din : iol_din_r);
	wire [1:0] b_iol_be = (unp_owner ? 2'b11 : iol_be_r);
	wire [15:0] iol_dout;
	assign unp_dout = iol_dout;
	assign unp_ack = (iol_ack & unp_owner) & (unp_rd | unp_wr);
	wire sndrom_ack;
	wire [20:0] sndrom_addr;
	wire [7:0] sndrom_data;
	wire sndrom_rd;
	wire [15:0] sndrom_wdata;
	yunit_sdram_arb #(
		.SD_AW(25),
		.GFXW_BASE(GFXW_BASE),
		.ROMW_BASE(ROMW_BASE),
		.VRAMW_BASE(VRAMW_BASE),
		.GFX_BYTES(GFX_BYTES),
		.SOUNDW_BASE(SOUNDW_BASE)
	) u_arb(
		.clk(clk),
		.rst(sdram_por),
		.vsd_addr(25'd0),
		.vsd_din(16'd0),
		.vsd_be(2'd0),
		.vsd_rd(1'b0),
		.vsd_wr(1'b0),
		.vsd_dout(),
		.vsd_ack(),
		.cgfx_rd(cgfx_rd),
		.cgfx_addr(cgfx_addr),
		.cgfx_data(cgfx_data),
		.cgfx_ack(cgfx_ack),
		.src_rd(1'b0),
		.src_addr(24'd0),
		.src_data(),
		.src_ack(),
		.snd_rd(sndrom_rd),
		.snd_addr(sndrom_addr),
		.snd_data(sndrom_data),
		.snd_wdata(sndrom_wdata),
		.snd_ack(sndrom_ack),
		.iol_rd(b_iol_rd),
		.iol_wr(b_iol_wr),
		.iol_addr(b_iol_addr),
		.iol_din(b_iol_din),
		.iol_be(b_iol_be),
		.iol_dout(iol_dout),
		.iol_ack(iol_ack),
		.sd_addr(sd_addr),
		.sd_din(sd_din),
		.sd_be(sd_be),
		.sd_rd(sd_rd),
		.sd_wr(sd_wr),
		.sd_dout(sd_dout),
		.sd_ack(sd_ack)
	);
	reg sdl_q;
	reg dl_seen;
	reg unp_pending;
	reg unp_start;
	wire unp_fsm_done;
	reg unp_done_q;
	always @(posedge clk) begin
		sdl_q <= sound_download;
		unp_start <= 1'b0;
		unp_done_q <= unp_fsm_done;
		if (sdram_por) begin
			dl_seen <= 1'b0;
			unp_pending <= 1'b0;
			unp_owner <= 1'b0;
			unp_done_q <= 1'b0;
		end
		else begin
			if (ioctl_download)
				dl_seen <= 1'b1;
			if (sdl_q & ~sound_download)
				unp_pending <= 1'b1;
			else if ((unp_pending & ~iol_hold) & ~unp_owner) begin
				unp_pending <= 1'b0;
				unp_start <= 1'b1;
				unp_owner <= 1'b1;
			end
			if ((unp_owner && unp_fsm_done) && !unp_done_q)
				unp_owner <= 1'b0;
		end
	end
	yunit_gfx_unpack #(
		.SD_AW(25),
		.SCRATCH_WBASE(SCRATCH_WBASE),
		.GFXW_BASE(GFXW_BASE),
		.PLANE_WORDS(PLANE_WORDS)
	) u_unpack(
		.clk(clk),
		.rst(sdram_por),
		.start(unp_start),
		.plane_words(game_plane_words),
		.bpp4(game_bpp4),
		.busy(),
		.done(unp_fsm_done),
		.unp_rd(unp_rd),
		.unp_wr(unp_wr),
		.unp_addr(unp_addr),
		.unp_din(unp_din),
		.unp_dout(unp_dout),
		.unp_ack(unp_ack)
	);
	assign unp_done = ~dl_seen | unp_fsm_done;
	wire brd_req;
	wire [24:0] brd_addr;
	wire [9:0] brd_len;
	wire [15:0] brd_dout;
	wire brd_dvalid;
	wire brd_done;
	yunit_src_cache #(.GFXW_BASE(GFXW_BASE[23:0])) u_srccache(
		.clk(clk),
		.rst(core_rst),
		.src_req(src_req),
		.src_addr(src_addr),
		.src_data(src_data),
		.src_ack(src_ack),
		.brd_req(brd_req),
		.brd_addr(brd_addr),
		.brd_len(brd_len),
		.brd_dout(brd_dout),
		.brd_dvalid(brd_dvalid),
		.brd_done(brd_done)
	);
	wire [24:0] ctl_addr;
	wire [15:0] ctl_din;
	wire [15:0] ctl_dout;
	wire [1:0] ctl_wtbt;
	wire ctl_rd;
	wire ctl_we;
	wire ctl_ready;
	yunit_sdram_adapter u_sdadapt(
		.clk(clk),
		.rst(sdram_por),
		.sd_addr(sd_addr),
		.sd_din(sd_din),
		.sd_be(sd_be),
		.sd_rd(sd_rd),
		.sd_wr(sd_wr),
		.sd_dout(sd_dout),
		.sd_ack(sd_ack),
		.sdram_ready(sdram_ready),
		.ctl_addr(ctl_addr),
		.ctl_din(ctl_din),
		.ctl_wtbt(ctl_wtbt),
		.ctl_rd(ctl_rd),
		.ctl_we(ctl_we),
		.ctl_dout(ctl_dout),
		.ctl_ready(ctl_ready)
	);
	sdram_stock u_sdram(
		.init(sdram_por),
		.clk(clk),
		.addr(ctl_addr),
		.din(ctl_din),
		.wtbt(ctl_wtbt),
		.we(ctl_we),
		.rd(ctl_rd),
		.dout(ctl_dout),
		.ready(ctl_ready),
		.brd_req(brd_req),
		.brd_addr(brd_addr),
		.brd_len(brd_len),
		.brd_dout(brd_dout),
		.brd_dvalid(brd_dvalid),
		.brd_done(brd_done),
		.bwr_req(1'b0),
		.bwr_addr(25'd0),
		.bwr_len(10'd0),
		.bwr_din(16'd0),
		.bwr_wtbt(2'b00),
		.bwr_valid(1'b0),
		.bwr_ready(),
		.bwr_done(),
		.SDRAM_DQ(SDRAM_DQ),
		.SDRAM_A(SDRAM_A),
		.SDRAM_BA(SDRAM_BA),
		.SDRAM_DQML(SDRAM_DQML),
		.SDRAM_DQMH(SDRAM_DQMH),
		.SDRAM_nCS(SDRAM_nCS),
		.SDRAM_nRAS(SDRAM_nRAS),
		.SDRAM_nCAS(SDRAM_nCAS),
		.SDRAM_nWE(SDRAM_nWE),
		.SDRAM_CKE(SDRAM_CKE)
	);
	wire [7:0] sel_sync;
	wire strig_snd;
	wire srst_snd;
	yunit_sound_cdc u_sound_cdc(
		.clk_sys(clk),
		.clk_snd(clk_snd),
		.rst_pon(rst_pon),
		.snd_select(snd_select),
		.snd_trig(snd_trig),
		.snd_reset(snd_reset),
		.sel_snd(sel_sync),
		.trig_snd(strig_snd),
		.reset_snd(srst_snd)
	);
	wire [7:0] pia_audio;
	wire [15:0] speech_out;
	wire signed [15:0] ym_l;
	wire signed [15:0] ym_r;
	wire [31:0] snd_dbg;
	localparam [3:0] yunit_pkg_YG_SMASHTV = 4'd0;
	wire use_ext_cvsd = game_id != yunit_pkg_YG_SMASHTV;
	wire cvsd_dl_we = snd_dl_wr && (game_id == yunit_pkg_YG_SMASHTV);
	wire use_adpcm = 1'b0;
	wire [20:0] cvsd_ext_addr;
	wire [20:0] adpcm_ext_addr;
	wire use_ext_snd = use_ext_cvsd | use_adpcm;
	wire [20:0] sound_ext_addr = (use_adpcm ? adpcm_ext_addr : cvsd_ext_addr);
	wire sound_ext_ok;
	wire [7:0] cvsd_ext_data;
	yunit_sound_rom_cache u_sound_rom_cache(
		.clk(clk),
		.rst(sdram_por | ioctl_download),
		.active(use_ext_snd),
		.client_addr(sound_ext_addr),
		.client_data(cvsd_ext_data),
		.client_ok(sound_ext_ok),
		.mem_rd(sndrom_rd),
		.mem_addr(sndrom_addr),
		.mem_rdata(sndrom_wdata),
		.mem_ack(sndrom_ack)
	);
	wire signed [15:0] cvsd_l;
	wire signed [15:0] cvsd_r;
	williams_cvsd_board u_board(
		.clock_12(clk_snd),
		.reset(srst_snd),
		.reset_pon(rst_pon),
		.sound_select(sel_sync),
		.sound_trig(strig_snd),
		.game_id(game_id),
		.pia_audio(pia_audio),
		.speech_out(speech_out),
		.ym2151_left(ym_l),
		.ym2151_right(ym_r),
		.dbg_out(snd_dbg),
		.snd_dl_clk(clk),
		.snd_dl_addr(snd_dl_addr),
		.snd_dl_data(snd_dl_data),
		.snd_dl_we(cvsd_dl_we),
		.use_ext_rom(use_ext_cvsd),
		.ext_rom_addr(cvsd_ext_addr),
		.ext_rom_data(cvsd_ext_data),
		.ext_rom_ok(sound_ext_ok)
	);
	yunit_audio_mix u_audio_mix(
		.clk(clk_snd),
		.rst(rst_pon),
		.ym_l(ym_l),
		.ym_r(ym_r),
		.speech_u(speech_out),
		.pia_u(pia_audio),
		.audio_l(cvsd_l),
		.audio_r(cvsd_r)
	);
	assign adpcm_ext_addr = 21'd0;
	assign adpcm_irq = 1'b0;
	assign audio_l = cvsd_l;
	assign audio_r = cvsd_r;
	assign dbg_core_rst = core_rst;
	assign dbg_sdram_ready = sdram_ready;
	assign dbg_unp_done = unp_done;
	assign dbg_cpu_req = cpu_req;
	assign dbg_mem_ack = mem_ack;
	assign dbg_int1 = int1;
	assign dbg_vblank_irq = vblank_irq;
	assign dbg_src_data = src_data;
	assign dbg_src_ack = src_ack;
	assign dbg_scan_data = scan_data;
	assign dbg_scan_ack = scan_ack;
	assign dbg_cpu_ce = cpu_ce;
	assign dbg_disp_flips = dpystrt_flip_cnt;
	assign dbg_disp_rows = {4'd0, dpystrt_ref_set, dpystrt_row_ref, dpystrt_row_pend, disp_row_dyn};
	assign dbg_iol_drop = iol_drop_cnt;
	assign dbg_iol_wrs = iol_wr_cnt;
	reg [1:0] rd_cnt;
	reg ack_q;
	reg d_started;
	reg [31:0] d_prevpc;
	always @(posedge clk)
		if (cpu_ce) begin
			if (core_rst_sys) begin
				dbg_derailed <= 1'b0;
				rd_cnt <= 2'd0;
				ack_q <= 1'b0;
				d_started <= 1'b0;
				d_prevpc <= 32'hffffffff;
				dbg_culprit_pc <= 32'hdeadbeef;
				dbg_culprit_instr <= 16'h0000;
				dbg_derail_pc <= 32'hdeadbeef;
			end
			else begin
				ack_q <= cpu_ack;
				if (((cpu_ack && !ack_q) && !cpu_we) && (rd_cnt == 2'd0)) begin
					dbg_culprit_pc <= cpu_rdata;
					rd_cnt <= 2'd1;
				end
				if (pc_dbg !== d_prevpc) begin
					if (pc_dbg == 32'hffe0f5c0) begin
						dbg_derail_pc <= d_prevpc;
						dbg_culprit_instr <= dbg_culprit_instr + 16'd1;
					end
					d_prevpc <= pc_dbg;
					if (pc_dbg[31:23] == 9'h1ff)
						d_started <= 1'b1;
				end
			end
		end
	assign dbg_snd_board_rst = srst_snd;
	assign dbg_cgfx_grants = 16'd0;
	assign dbg_snd_grants = 16'd0;
	assign dbg_cgfx_maxwait = 32'd0;
	assign dbg_snd_miss = 16'd0;
	assign dbg_snd_busy16 = 16'd0;
	assign dbg_cvsd_moves = 16'd0;
	assign dbg_adpcm_moves = 16'd0;
	assign dbg_blank_pix = 16'd0;
	assign dbg_cpu_pc_moves = 32'd0;
	assign dbg_snd_acks = 32'd0;
	assign dbg_snd_first_words = 32'd0;
	assign dbg_snd_region_seen = 1'b0;
	assign dbg_restart_cnt = 16'd0;
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module smashtv_diag_top (
	clk,
	clk_cpu,
	ce_pix,
	cpu_div_sel,
	clk_snd,
	rst,
	rst_pon,
	sdram_por,
	inputs,
	ioctl_download,
	ioctl_wr,
	ioctl_addr,
	ioctl_dout,
	ioctl_be,
	ioctl_wait,
	snd_dl_wr,
	snd_dl_addr,
	snd_dl_data,
	SDRAM_DQ,
	SDRAM_A,
	SDRAM_BA,
	SDRAM_DQML,
	SDRAM_DQMH,
	SDRAM_nCS,
	SDRAM_nRAS,
	SDRAM_nCAS,
	SDRAM_nWE,
	SDRAM_CKE,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de,
	audio_l,
	audio_r,
	pc_dbg,
	illegal_dbg,
	dbg_core_rst,
	dbg_sdram_ready,
	dbg_unp_done,
	dbg_cpu_req,
	dbg_mem_ack,
	dbg_int1,
	dbg_vblank_irq,
	dbg_derailed,
	dbg_culprit_pc,
	dbg_culprit_instr,
	dbg_derail_pc,
	dbg_cpu_ce,
	dbg_iol_drop,
	dbg_iol_wrs,
	dbg_dma_we,
	dbg_dma_addr,
	dbg_dma_wdata,
	dbg_src_data,
	dbg_src_ack,
	dbg_scan_data,
	dbg_scan_ack,
	DDRAM_ADDR,
	DDRAM_BURSTCNT,
	DDRAM_RD,
	DDRAM_DIN,
	DDRAM_BE,
	DDRAM_WE,
	DDRAM_BUSY,
	DDRAM_DOUT,
	DDRAM_DOUT_READY
);
	reg _sv2v_0;
	parameter ROM_HEX = "";
	parameter signed [31:0] H_ACT = 410;
	parameter signed [31:0] H_FP = 6;
	parameter signed [31:0] H_SYNC = 44;
	parameter signed [31:0] H_BP = 46;
	parameter signed [31:0] V_ACT = 256;
	parameter signed [31:0] V_FP = 13;
	parameter signed [31:0] V_SYNC = 4;
	parameter signed [31:0] V_BP = 16;
	parameter [24:0] DIAG_NWORDS = 25'h0160000;
	input wire clk;
	input wire clk_cpu;
	input wire ce_pix;
	input wire [2:0] cpu_div_sel;
	input wire clk_snd;
	input wire rst;
	input wire rst_pon;
	input wire sdram_por;
	input wire [63:0] inputs;
	input wire ioctl_download;
	input wire ioctl_wr;
	input wire [24:0] ioctl_addr;
	input wire [15:0] ioctl_dout;
	input wire [1:0] ioctl_be;
	output wire ioctl_wait;
	input wire snd_dl_wr;
	input wire [17:0] snd_dl_addr;
	input wire [7:0] snd_dl_data;
	inout wire [15:0] SDRAM_DQ;
	output wire [12:0] SDRAM_A;
	output wire [1:0] SDRAM_BA;
	output wire SDRAM_DQML;
	output wire SDRAM_DQMH;
	output wire SDRAM_nCS;
	output wire SDRAM_nRAS;
	output wire SDRAM_nCAS;
	output wire SDRAM_nWE;
	output wire SDRAM_CKE;
	output reg [7:0] vid_r;
	output reg [7:0] vid_g;
	output reg [7:0] vid_b;
	output reg hsync;
	output reg vsync;
	output reg hblank;
	output reg vblank;
	output reg de;
	output wire signed [15:0] audio_l;
	output wire signed [15:0] audio_r;
	output wire [31:0] pc_dbg;
	output wire illegal_dbg;
	output wire dbg_core_rst;
	output wire dbg_sdram_ready;
	output wire dbg_unp_done;
	output wire dbg_cpu_req;
	output wire dbg_mem_ack;
	output wire dbg_int1;
	output wire dbg_vblank_irq;
	output wire dbg_derailed;
	output wire [31:0] dbg_culprit_pc;
	output wire [15:0] dbg_culprit_instr;
	output wire [31:0] dbg_derail_pc;
	output wire dbg_cpu_ce;
	output wire [31:0] dbg_iol_drop;
	output wire [31:0] dbg_iol_wrs;
	output wire dbg_dma_we;
	output wire [3:0] dbg_dma_addr;
	output wire [15:0] dbg_dma_wdata;
	output wire [7:0] dbg_src_data;
	output wire dbg_src_ack;
	output wire [15:0] dbg_scan_data;
	output wire dbg_scan_ack;
	output wire [28:0] DDRAM_ADDR;
	output wire [7:0] DDRAM_BURSTCNT;
	output wire DDRAM_RD;
	output wire [63:0] DDRAM_DIN;
	output wire [7:0] DDRAM_BE;
	output wire DDRAM_WE;
	input wire DDRAM_BUSY;
	input wire [63:0] DDRAM_DOUT;
	input wire DDRAM_DOUT_READY;
	assign ioctl_wait = 1'b0;
	assign dbg_core_rst = 1'b0;
	assign dbg_sdram_ready = 1'b0;
	assign dbg_unp_done = 1'b0;
	assign dbg_cpu_req = 1'b0;
	assign dbg_mem_ack = 1'b0;
	assign dbg_int1 = 1'b0;
	assign dbg_vblank_irq = 1'b0;
	assign dbg_derailed = 1'b0;
	assign dbg_culprit_pc = 32'd0;
	assign dbg_culprit_instr = 16'd0;
	assign dbg_derail_pc = 32'd0;
	assign audio_l = 16'sd0;
	assign audio_r = 16'sd0;
	assign illegal_dbg = 1'b0;
	assign dbg_cpu_ce = 1'b0;
	assign dbg_iol_drop = 32'd0;
	assign dbg_iol_wrs = 32'd0;
	assign dbg_dma_we = 1'b0;
	assign dbg_dma_addr = 4'd0;
	assign dbg_dma_wdata = 16'd0;
	assign dbg_src_data = 8'd0;
	assign dbg_src_ack = 1'b0;
	assign dbg_scan_data = 16'd0;
	assign dbg_scan_ack = 1'b0;
	assign DDRAM_ADDR = 29'd0;
	assign DDRAM_BURSTCNT = 8'd0;
	assign DDRAM_RD = 1'b0;
	assign DDRAM_DIN = 64'd0;
	assign DDRAM_BE = 8'd0;
	assign DDRAM_WE = 1'b0;
	reg [24:0] ctl_addr;
	reg [15:0] ctl_din;
	wire [15:0] ctl_dout;
	reg [1:0] ctl_wtbt;
	reg ctl_rd;
	reg ctl_we;
	wire ctl_ready;
	sdram_stock u_sdram(
		.init(rst),
		.clk(clk),
		.addr(ctl_addr),
		.din(ctl_din),
		.wtbt(ctl_wtbt),
		.we(ctl_we),
		.rd(ctl_rd),
		.dout(ctl_dout),
		.ready(ctl_ready),
		.SDRAM_DQ(SDRAM_DQ),
		.SDRAM_A(SDRAM_A),
		.SDRAM_BA(SDRAM_BA),
		.SDRAM_DQML(SDRAM_DQML),
		.SDRAM_DQMH(SDRAM_DQMH),
		.SDRAM_nCS(SDRAM_nCS),
		.SDRAM_nRAS(SDRAM_nRAS),
		.SDRAM_nCAS(SDRAM_nCAS),
		.SDRAM_nWE(SDRAM_nWE),
		.SDRAM_CKE(SDRAM_CKE)
	);
	function automatic [15:0] patt;
		input [24:0] i;
		patt = (i[15:0] ^ {i[23:16], i[23:16]}) ^ 16'h5aa5;
	endfunction
	reg [3:0] ds;
	reg [24:0] idx;
	reg [31:0] miscount;
	reg [24:0] first_fail;
	reg failed;
	reg settle;
	wire [15:0] exp = patt(idx);
	always @(posedge clk)
		if (rst) begin
			ds <= 4'd0;
			idx <= 25'd0;
			miscount <= 32'd0;
			first_fail <= 25'h1ffffff;
			failed <= 1'b0;
			ctl_rd <= 1'b0;
			ctl_we <= 1'b0;
			ctl_addr <= 25'd0;
			ctl_din <= 16'd0;
			ctl_wtbt <= 2'b11;
			settle <= 1'b0;
		end
		else begin
			ctl_rd <= 1'b0;
			ctl_we <= 1'b0;
			case (ds)
				4'd0:
					if (ctl_ready) begin
						idx <= 25'd0;
						ds <= 4'd1;
					end
				4'd1:
					if (ctl_ready) begin
						ctl_addr <= {idx[23:0], 1'b0};
						ctl_din <= {8'h00, exp[7:0]};
						ctl_wtbt <= 2'b01;
						ctl_we <= 1'b1;
						settle <= 1'b1;
						ds <= 4'd2;
					end
				4'd2:
					if (settle)
						settle <= 1'b0;
					else if (ctl_ready)
						ds <= 4'd3;
				4'd3:
					if (ctl_ready) begin
						ctl_addr <= {idx[23:0], 1'b0};
						ctl_din <= {exp[15:8], 8'h00};
						ctl_wtbt <= 2'b10;
						ctl_we <= 1'b1;
						settle <= 1'b1;
						ds <= 4'd4;
					end
				4'd4:
					if (settle)
						settle <= 1'b0;
					else if (ctl_ready) begin
						if (idx == (DIAG_NWORDS - 1)) begin
							idx <= 25'd0;
							ds <= 4'd5;
						end
						else begin
							idx <= idx + 25'd1;
							ds <= 4'd1;
						end
					end
				4'd5:
					if (ctl_ready) begin
						ctl_addr <= {idx[23:0], 1'b0};
						ctl_rd <= 1'b1;
						settle <= 1'b1;
						ds <= 4'd6;
					end
				4'd6:
					if (settle)
						settle <= 1'b0;
					else if (ctl_ready) begin
						if (ctl_dout != exp) begin
							miscount <= miscount + 32'd1;
							failed <= 1'b1;
							if (first_fail == 25'h1ffffff)
								first_fail <= idx;
						end
						if (idx == (DIAG_NWORDS - 1))
							ds <= (failed || (ctl_dout != exp) ? 4'd8 : 4'd7);
						else begin
							idx <= idx + 25'd1;
							ds <= 4'd5;
						end
					end
				4'd7: ds <= 4'd7;
				4'd8: ds <= 4'd8;
				default: ds <= 4'd0;
			endcase
		end
	localparam signed [31:0] H_TOTAL = ((H_ACT + H_FP) + H_SYNC) + H_BP;
	localparam signed [31:0] V_TOTAL = ((V_ACT + V_FP) + V_SYNC) + V_BP;
	reg [11:0] hc;
	reg [11:0] vc;
	reg [23:0] frame;
	always @(posedge clk)
		if (rst) begin
			hc <= 0;
			vc <= 0;
			frame <= 0;
		end
		else if (ce_pix) begin
			if (hc == (H_TOTAL - 1)) begin
				hc <= 0;
				if (vc == (V_TOTAL - 1)) begin
					vc <= 0;
					frame <= frame + 24'd1;
				end
				else
					vc <= vc + 12'd1;
			end
			else
				hc <= hc + 12'd1;
		end
	wire s0_de = (hc < H_ACT) && (vc < V_ACT);
	wire s0_hb = hc >= H_ACT;
	wire s0_vb = vc >= V_ACT;
	wire s0_hs = (hc >= (H_ACT + H_FP)) && (hc < ((H_ACT + H_FP) + H_SYNC));
	wire s0_vs = (vc >= (V_ACT + V_FP)) && (vc < ((V_ACT + V_FP) + V_SYNC));
	reg [7:0] br;
	reg [7:0] bg;
	reg [7:0] bb;
	always @(*) begin
		if (_sv2v_0)
			;
		case (ds)
			4'd0: begin
				br = 8'h00;
				bg = 8'h00;
				bb = 8'hc0;
			end
			4'd7: begin
				br = 8'h00;
				bg = 8'hc0;
				bb = 8'h00;
			end
			4'd8: begin
				br = 8'hc0;
				bg = 8'h00;
				bb = 8'h00;
			end
			default: begin
				br = 8'h80;
				bg = 8'h80;
				bb = 8'h00;
			end
		endcase
	end
	localparam signed [31:0] E = H_ACT / 8;
	reg [7:0] cbr;
	reg [7:0] cbg;
	reg [7:0] cbb;
	wire [2:0] bar = (hc < E ? 3'd0 : (hc < (2 * E) ? 3'd1 : (hc < (3 * E) ? 3'd2 : (hc < (4 * E) ? 3'd3 : (hc < (5 * E) ? 3'd4 : (hc < (6 * E) ? 3'd5 : (hc < (7 * E) ? 3'd6 : 3'd7)))))));
	always @(*) begin
		if (_sv2v_0)
			;
		case (bar)
			3'd0: {cbr, cbg, cbb} = 24'hffffff;
			3'd1: {cbr, cbg, cbb} = 24'hffff00;
			3'd2: {cbr, cbg, cbb} = 24'h00ffff;
			3'd3: {cbr, cbg, cbb} = 24'h00ff00;
			3'd4: {cbr, cbg, cbb} = 24'hff00ff;
			3'd5: {cbr, cbg, cbb} = 24'hff0000;
			3'd6: {cbr, cbg, cbb} = 24'h0000ff;
			default: {cbr, cbg, cbb} = 24'h000000;
		endcase
	end
	wire [5:0] milog = (miscount[31] ? 6'd32 : (miscount[24] ? 6'd25 : (miscount[20] ? 6'd21 : (miscount[16] ? 6'd17 : (miscount[12] ? 6'd13 : (miscount[8] ? 6'd9 : (miscount[4] ? 6'd5 : (miscount[1] ? 6'd2 : (miscount[0] ? 6'd1 : 6'd0)))))))));
	wire [15:0] mibar_w = (H_ACT * milog) >> 5;
	wire in_bars = vc < (V_ACT / 8);
	wire in_mibar = vc >= (V_ACT - (V_ACT / 8));
	wire live_col = hc == frame[8:0];
	always @(posedge clk)
		if (ce_pix) begin
			de <= s0_de;
			hsync <= s0_hs;
			vsync <= s0_vs;
			hblank <= s0_hb;
			vblank <= s0_vb;
			if (!s0_de) begin
				vid_r <= 0;
				vid_g <= 0;
				vid_b <= 0;
			end
			else if (in_bars) begin
				vid_r <= cbr;
				vid_g <= cbg;
				vid_b <= cbb;
			end
			else if (live_col) begin
				vid_r <= 8'hff;
				vid_g <= 8'hff;
				vid_b <= 8'hff;
			end
			else if (in_mibar) begin
				if ({4'd0, hc} < mibar_w) begin
					vid_r <= 8'hff;
					vid_g <= 8'h00;
					vid_b <= 8'h00;
				end
				else begin
					vid_r <= 8'h20;
					vid_g <= 8'h20;
					vid_b <= 8'h20;
				end
			end
			else begin
				vid_r <= br;
				vid_g <= bg;
				vid_b <= bb;
			end
		end
	assign pc_dbg = {3'd0, ds, first_fail};
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module smashtv_diag2_overlay (
	clk,
	ce_pix,
	rst,
	core_rst,
	sdram_ready,
	unp_done,
	ioctl_download,
	cpu_req,
	mem_ack,
	int1,
	vblank_irq,
	cpu_ce,
	pc,
	illegal,
	derailed,
	culprit_pc,
	culprit_instr,
	derail_pc,
	g_r,
	g_g,
	g_b,
	g_hs,
	g_vs,
	g_hb,
	g_vb,
	g_de,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de
);
	reg _sv2v_0;
	parameter signed [31:0] H_ACT = 410;
	parameter signed [31:0] H_FP = 6;
	parameter signed [31:0] H_SYNC = 44;
	parameter signed [31:0] H_BP = 46;
	parameter signed [31:0] V_ACT = 256;
	parameter signed [31:0] V_FP = 13;
	parameter signed [31:0] V_SYNC = 4;
	parameter signed [31:0] V_BP = 16;
	input wire clk;
	input wire ce_pix;
	input wire rst;
	input wire core_rst;
	input wire sdram_ready;
	input wire unp_done;
	input wire ioctl_download;
	input wire cpu_req;
	input wire mem_ack;
	input wire int1;
	input wire vblank_irq;
	input wire cpu_ce;
	input wire [31:0] pc;
	input wire illegal;
	input wire derailed;
	input wire [31:0] culprit_pc;
	input wire [15:0] culprit_instr;
	input wire [31:0] derail_pc;
	input wire [7:0] g_r;
	input wire [7:0] g_g;
	input wire [7:0] g_b;
	input wire g_hs;
	input wire g_vs;
	input wire g_hb;
	input wire g_vb;
	input wire g_de;
	output reg [7:0] vid_r;
	output reg [7:0] vid_g;
	output reg [7:0] vid_b;
	output reg hsync;
	output reg vsync;
	output reg hblank;
	output reg vblank;
	output reg de;
	localparam signed [31:0] H_TOTAL = ((H_ACT + H_FP) + H_SYNC) + H_BP;
	localparam signed [31:0] V_TOTAL = ((V_ACT + V_FP) + V_SYNC) + V_BP;
	function automatic [14:0] glyph;
		input [3:0] v;
		case (v)
			4'h0: glyph = 15'b111101101101111;
			4'h1: glyph = 15'b010110010010111;
			4'h2: glyph = 15'b111001111100111;
			4'h3: glyph = 15'b111001111001111;
			4'h4: glyph = 15'b101101111001001;
			4'h5: glyph = 15'b111100111001111;
			4'h6: glyph = 15'b111100111101111;
			4'h7: glyph = 15'b111001001010010;
			4'h8: glyph = 15'b111101111101111;
			4'h9: glyph = 15'b111101111001111;
			4'ha: glyph = 15'b111101111101101;
			4'hb: glyph = 15'b110101110101110;
			4'hc: glyph = 15'b111100100100111;
			4'hd: glyph = 15'b110101101101110;
			4'he: glyph = 15'b111100111100111;
			default: glyph = 15'b111100111100100;
		endcase
	endfunction
	function automatic fpix;
		input [3:0] d;
		input [2:0] col;
		input [2:0] row;
		reg [14:0] g;
		reg [2:0] rb;
		begin
			g = glyph(d);
			case (row)
				3'd0: rb = g[14:12];
				3'd1: rb = g[11:9];
				3'd2: rb = g[8:6];
				3'd3: rb = g[5:3];
				default: rb = g[2:0];
			endcase
			fpix = (col == 3'd0 ? rb[2] : (col == 3'd1 ? rb[1] : (col == 3'd2 ? rb[0] : 1'b0)));
		end
	endfunction
	reg [11:0] gx;
	reg [11:0] gy;
	reg de_q;
	reg vb_q;
	reg [23:0] frame;
	reg [31:0] pc_q;
	reg [31:0] pc_qq;
	reg [31:0] pc_show;
	always @(posedge clk)
		if (rst) begin
			gx <= 0;
			gy <= 0;
			de_q <= 0;
			vb_q <= 0;
			frame <= 0;
			pc_q <= 0;
			pc_qq <= 0;
			pc_show <= 0;
		end
		else if (ce_pix) begin
			de_q <= g_de;
			vb_q <= g_vb;
			pc_q <= pc;
			pc_qq <= pc_q;
			if (g_vb && !vb_q) begin
				gy <= 12'd0;
				gx <= 12'd0;
				frame <= frame + 24'd1;
				if (frame[4:0] == 5'd0)
					pc_show <= pc_qq;
			end
			else if (g_de)
				gx <= gx + 12'd1;
			else if (de_q && !g_de) begin
				gx <= 12'd0;
				gy <= gy + 12'd1;
			end
		end
	wire [11:0] hc = gx << 1;
	wire [11:0] vc = gy << 1;
	wire s0_de = (hc < H_ACT) && (vc < V_ACT);
	wire frame_tick = (ce_pix && g_vb) && !vb_q;
	reg a1_req;
	reg a0_req;
	reg a1_ack;
	reg a0_ack;
	reg a1_i1;
	reg a0_i1;
	reg a1_vb;
	reg a0_vb;
	reg a1_ce;
	reg a0_ce;
	reg alive_req;
	reg alive_ack;
	reg alive_i1;
	reg alive_vb;
	reg alive_ce;
	reg illegal_sticky;
	always @(posedge clk)
		if (rst) begin
			a1_req <= 0;
			a0_req <= 0;
			a1_ack <= 0;
			a0_ack <= 0;
			a1_i1 <= 0;
			a0_i1 <= 0;
			a1_vb <= 0;
			a0_vb <= 0;
			a1_ce <= 0;
			a0_ce <= 0;
			alive_req <= 0;
			alive_ack <= 0;
			alive_i1 <= 0;
			alive_vb <= 0;
			alive_ce <= 0;
			illegal_sticky <= 0;
		end
		else begin
			if (illegal)
				illegal_sticky <= 1'b1;
			if (cpu_req)
				a1_req <= 1'b1;
			else
				a0_req <= 1'b1;
			if (mem_ack)
				a1_ack <= 1'b1;
			else
				a0_ack <= 1'b1;
			if (int1)
				a1_i1 <= 1'b1;
			else
				a0_i1 <= 1'b1;
			if (vblank_irq)
				a1_vb <= 1'b1;
			else
				a0_vb <= 1'b1;
			if (cpu_ce)
				a1_ce <= 1'b1;
			else
				a0_ce <= 1'b1;
			if (frame_tick) begin
				alive_req <= a1_req & a0_req;
				a1_req <= 1'b0;
				a0_req <= 1'b0;
				alive_ack <= a1_ack & a0_ack;
				a1_ack <= 1'b0;
				a0_ack <= 1'b0;
				alive_i1 <= a1_i1 & a0_i1;
				a1_i1 <= 1'b0;
				a0_i1 <= 1'b0;
				alive_vb <= a1_vb & a0_vb;
				a1_vb <= 1'b0;
				a0_vb <= 1'b0;
				alive_ce <= a1_ce & a0_ce;
				a1_ce <= 1'b0;
				a0_ce <= 1'b0;
			end
		end
	localparam signed [31:0] LEDW = H_ACT / 10;
	wire in_leds = (vc >= 12'd44) && (vc < 12'd52);
	wire [3:0] led_lane = (hc < LEDW ? 4'd0 : (hc < (2 * LEDW) ? 4'd1 : (hc < (3 * LEDW) ? 4'd2 : (hc < (4 * LEDW) ? 4'd3 : (hc < (5 * LEDW) ? 4'd4 : (hc < (6 * LEDW) ? 4'd5 : (hc < (7 * LEDW) ? 4'd6 : (hc < (8 * LEDW) ? 4'd7 : (hc < (9 * LEDW) ? 4'd8 : 4'd9)))))))));
	wire [11:0] led_x = hc - (led_lane * LEDW);
	wire led_body = (led_x >= 12'd2) && (led_x < (LEDW - 2));
	reg led_good;
	always @(*) begin
		if (_sv2v_0)
			;
		case (led_lane)
			4'd0: led_good = ~core_rst;
			4'd1: led_good = sdram_ready;
			4'd2: led_good = unp_done;
			4'd3: led_good = ~ioctl_download;
			4'd4: led_good = ~illegal_sticky;
			4'd5: led_good = alive_req;
			4'd6: led_good = alive_ack;
			4'd7: led_good = alive_i1;
			4'd8: led_good = alive_vb;
			default: led_good = alive_ce;
		endcase
	end
	localparam signed [31:0] HE = H_ACT / 8;
	reg [7:0] cbr;
	reg [7:0] cbg;
	reg [7:0] cbb;
	wire [2:0] barx = (hc < HE ? 3'd0 : (hc < (2 * HE) ? 3'd1 : (hc < (3 * HE) ? 3'd2 : (hc < (4 * HE) ? 3'd3 : (hc < (5 * HE) ? 3'd4 : (hc < (6 * HE) ? 3'd5 : (hc < (7 * HE) ? 3'd6 : 3'd7)))))));
	always @(*) begin
		if (_sv2v_0)
			;
		case (barx)
			3'd0: {cbr, cbg, cbb} = 24'hffffff;
			3'd1: {cbr, cbg, cbb} = 24'hffff00;
			3'd2: {cbr, cbg, cbb} = 24'h00ffff;
			3'd3: {cbr, cbg, cbb} = 24'h00ff00;
			3'd4: {cbr, cbg, cbb} = 24'hff00ff;
			3'd5: {cbr, cbg, cbb} = 24'hff0000;
			3'd6: {cbr, cbg, cbb} = 24'h0000ff;
			default: {cbr, cbg, cbb} = 24'h202020;
		endcase
	end
	reg [31:0] rowval;
	reg in_hex;
	reg [11:0] ry0;
	always @(*) begin
		if (_sv2v_0)
			;
		in_hex = 1'b0;
		rowval = 32'd0;
		ry0 = 12'd0;
		if ((vc >= 12'd52) && (vc < 12'd96)) begin
			in_hex = 1'b1;
			ry0 = 12'd52;
			rowval = culprit_pc;
		end
		else if ((vc >= 12'd100) && (vc < 12'd144)) begin
			in_hex = 1'b1;
			ry0 = 12'd100;
			rowval = {16'h0000, culprit_instr};
		end
		else if ((vc >= 12'd148) && (vc < 12'd192)) begin
			in_hex = 1'b1;
			ry0 = 12'd148;
			rowval = derail_pc;
		end
		else if ((vc >= 12'd200) && (vc < 12'd244)) begin
			in_hex = 1'b1;
			ry0 = 12'd200;
			rowval = pc_show;
		end
	end
	localparam signed [31:0] PX0 = 77;
	wire hxin = (hc >= PX0) && (hc < 333);
	wire [7:0] hrx = hc - PX0[11:0];
	wire [2:0] hdig = hrx[7:5];
	wire [1:0] hfcol = hrx[4:3];
	wire [11:0] hry12 = vc - ry0;
	wire [2:0] hfrow = hry12[5:3];
	wire [4:0] hsh = {2'b00, 3'd7 - hdig} << 2;
	wire [3:0] hnyb = rowval >> hsh;
	wire hex_on = (((in_hex && hxin) && (hfcol < 2'd3)) && (hfrow < 3'd5)) && fpix(hnyb, {1'b0, hfcol}, hfrow);
	wire in_status = (vc >= 12'd24) && (vc < 12'd44);
	wire live_col = hc == frame[8:0];
	always @(posedge clk)
		if (ce_pix) begin
			de <= g_de;
			hsync <= g_hs;
			vsync <= g_vs;
			hblank <= g_hb;
			vblank <= g_vb;
			if (!g_de) begin
				vid_r <= 8'd0;
				vid_g <= 8'd0;
				vid_b <= 8'd0;
			end
			else if (!s0_de) begin
				vid_r <= g_r;
				vid_g <= g_g;
				vid_b <= g_b;
			end
			else if (vc < 12'd20) begin
				vid_r <= cbr;
				vid_g <= cbg;
				vid_b <= cbb;
			end
			else if (live_col) begin
				vid_r <= 8'hff;
				vid_g <= 8'hff;
				vid_b <= 8'hff;
			end
			else if (in_status) begin
				if (derailed) begin
					vid_r <= 8'hc0;
					vid_g <= 8'h00;
					vid_b <= 8'h00;
				end
				else begin
					vid_r <= 8'h00;
					vid_g <= 8'hc0;
					vid_b <= 8'h00;
				end
			end
			else if (in_leds) begin
				if (led_body) begin
					if (led_good) begin
						vid_r <= 8'h00;
						vid_g <= 8'he0;
						vid_b <= 8'h00;
					end
					else begin
						vid_r <= 8'he0;
						vid_g <= 8'h00;
						vid_b <= 8'h00;
					end
				end
				else begin
					vid_r <= 8'h00;
					vid_g <= 8'h00;
					vid_b <= 8'h00;
				end
			end
			else if (in_hex) begin
				if (hex_on) begin
					vid_r <= 8'hff;
					vid_g <= 8'hff;
					vid_b <= 8'h00;
				end
				else begin
					vid_r <= 8'h10;
					vid_g <= 8'h10;
					vid_b <= 8'h30;
				end
			end
			else begin
				vid_r <= 8'h08;
				vid_g <= 8'h08;
				vid_b <= 8'h08;
			end
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_diag_service_overlay (
	clk,
	ce_pix,
	rst,
	core_rst,
	sdram_ready,
	ioctl_download,
	cpu_ce,
	cnt_cgfx_grants,
	cnt_snd_grants,
	cnt_cgfx_maxwait,
	cnt_snd_miss,
	cnt_snd_busy16,
	cnt_cvsd_moves,
	cnt_adpcm_moves,
	cnt_blank_pix,
	cnt_cpu_pc_moves,
	cnt_snd_acks,
	snd_first_words,
	snd_region_seen,
	snd_board_rst,
	restart_cnt,
	g_r,
	g_g,
	g_b,
	g_hs,
	g_vs,
	g_hb,
	g_vb,
	g_de,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de
);
	reg _sv2v_0;
	parameter signed [31:0] H_ACT = 410;
	parameter signed [31:0] H_FP = 6;
	parameter signed [31:0] H_SYNC = 44;
	parameter signed [31:0] H_BP = 46;
	parameter signed [31:0] V_ACT = 256;
	parameter signed [31:0] V_FP = 13;
	parameter signed [31:0] V_SYNC = 4;
	parameter signed [31:0] V_BP = 16;
	input wire clk;
	input wire ce_pix;
	input wire rst;
	input wire core_rst;
	input wire sdram_ready;
	input wire ioctl_download;
	input wire cpu_ce;
	input wire [15:0] cnt_cgfx_grants;
	input wire [15:0] cnt_snd_grants;
	input wire [31:0] cnt_cgfx_maxwait;
	input wire [15:0] cnt_snd_miss;
	input wire [15:0] cnt_snd_busy16;
	input wire [15:0] cnt_cvsd_moves;
	input wire [15:0] cnt_adpcm_moves;
	input wire [15:0] cnt_blank_pix;
	input wire [31:0] cnt_cpu_pc_moves;
	input wire [31:0] cnt_snd_acks;
	input wire [31:0] snd_first_words;
	input wire snd_region_seen;
	input wire snd_board_rst;
	input wire [15:0] restart_cnt;
	input wire [7:0] g_r;
	input wire [7:0] g_g;
	input wire [7:0] g_b;
	input wire g_hs;
	input wire g_vs;
	input wire g_hb;
	input wire g_vb;
	input wire g_de;
	output reg [7:0] vid_r;
	output reg [7:0] vid_g;
	output reg [7:0] vid_b;
	output reg hsync;
	output reg vsync;
	output reg hblank;
	output reg vblank;
	output reg de;
	function automatic [14:0] glyph;
		input [3:0] v;
		case (v)
			4'h0: glyph = 15'b111101101101111;
			4'h1: glyph = 15'b010110010010111;
			4'h2: glyph = 15'b111001111100111;
			4'h3: glyph = 15'b111001111001111;
			4'h4: glyph = 15'b101101111001001;
			4'h5: glyph = 15'b111100111001111;
			4'h6: glyph = 15'b111100111101111;
			4'h7: glyph = 15'b111001001010010;
			4'h8: glyph = 15'b111101111101111;
			4'h9: glyph = 15'b111101111001111;
			4'ha: glyph = 15'b111101111101101;
			4'hb: glyph = 15'b110101110101110;
			4'hc: glyph = 15'b111100100100111;
			4'hd: glyph = 15'b110101101101110;
			4'he: glyph = 15'b111100111100111;
			default: glyph = 15'b111100111100100;
		endcase
	endfunction
	function automatic fpix;
		input [3:0] d;
		input [2:0] col;
		input [2:0] row;
		reg [14:0] g;
		reg [2:0] rb;
		begin
			g = glyph(d);
			case (row)
				3'd0: rb = g[14:12];
				3'd1: rb = g[11:9];
				3'd2: rb = g[8:6];
				3'd3: rb = g[5:3];
				default: rb = g[2:0];
			endcase
			fpix = (col == 3'd0 ? rb[2] : (col == 3'd1 ? rb[1] : (col == 3'd2 ? rb[0] : 1'b0)));
		end
	endfunction
	reg [11:0] gx;
	reg [11:0] gy;
	reg de_q;
	reg vb_q;
	reg [23:0] frame;
	always @(posedge clk)
		if (rst) begin
			gx <= 12'd0;
			gy <= 12'd0;
			de_q <= 1'b0;
			vb_q <= 1'b0;
			frame <= 24'd0;
		end
		else if (ce_pix) begin
			de_q <= g_de;
			vb_q <= g_vb;
			if (g_vb && !vb_q) begin
				gy <= 12'd0;
				gx <= 12'd0;
				frame <= frame + 24'd1;
			end
			else if (g_de)
				gx <= gx + 12'd1;
			else if (de_q && !g_de) begin
				gx <= 12'd0;
				gy <= gy + 12'd1;
			end
		end
	wire [11:0] hc = gx << 1;
	wire [11:0] vc = gy << 1;
	wire s0_de = (hc < H_ACT) && (vc < V_ACT);
	wire frame_tick = (ce_pix && g_vb) && !vb_q;
	reg a1_ce;
	reg a0_ce;
	reg alive_ce;
	always @(posedge clk)
		if (rst) begin
			a1_ce <= 1'b0;
			a0_ce <= 1'b0;
			alive_ce <= 1'b0;
		end
		else begin
			if (cpu_ce)
				a1_ce <= 1'b1;
			else
				a0_ce <= 1'b1;
			if (frame_tick) begin
				alive_ce <= a1_ce & a0_ce;
				a1_ce <= 1'b0;
				a0_ce <= 1'b0;
			end
		end
	localparam signed [31:0] LEDW = H_ACT / 10;
	wire in_leds = (vc >= 12'd44) && (vc < 12'd52);
	wire [3:0] led_lane = (hc < LEDW ? 4'd0 : (hc < (2 * LEDW) ? 4'd1 : (hc < (3 * LEDW) ? 4'd2 : (hc < (4 * LEDW) ? 4'd3 : (hc < (5 * LEDW) ? 4'd4 : (hc < (6 * LEDW) ? 4'd5 : (hc < (7 * LEDW) ? 4'd6 : (hc < (8 * LEDW) ? 4'd7 : (hc < (9 * LEDW) ? 4'd8 : 4'd9)))))))));
	wire [11:0] led_x = hc - (led_lane * LEDW);
	wire led_body = (led_x >= 12'd2) && (led_x < (LEDW - 2));
	reg led_good;
	always @(*) begin
		if (_sv2v_0)
			;
		case (led_lane)
			4'd0: led_good = ~core_rst;
			4'd1: led_good = sdram_ready;
			4'd2: led_good = ~ioctl_download;
			4'd3: led_good = snd_region_seen;
			4'd4: led_good = ~snd_board_rst;
			4'd5: led_good = cnt_cvsd_moves != 16'd0;
			4'd6: led_good = cnt_adpcm_moves != 16'd0;
			4'd7: led_good = cnt_cgfx_grants > 16'd64;
			4'd8: led_good = cnt_blank_pix == 16'd0;
			default: led_good = alive_ce;
		endcase
	end
	localparam signed [31:0] HE = H_ACT / 8;
	reg [7:0] cbr;
	reg [7:0] cbg;
	reg [7:0] cbb;
	wire [2:0] barx = (hc < HE ? 3'd0 : (hc < (2 * HE) ? 3'd1 : (hc < (3 * HE) ? 3'd2 : (hc < (4 * HE) ? 3'd3 : (hc < (5 * HE) ? 3'd4 : (hc < (6 * HE) ? 3'd5 : (hc < (7 * HE) ? 3'd6 : 3'd7)))))));
	always @(*) begin
		if (_sv2v_0)
			;
		case (barx)
			3'd0: {cbr, cbg, cbb} = 24'hffffff;
			3'd1: {cbr, cbg, cbb} = 24'hffff00;
			3'd2: {cbr, cbg, cbb} = 24'h00ffff;
			3'd3: {cbr, cbg, cbb} = 24'h00ff00;
			3'd4: {cbr, cbg, cbb} = 24'hff00ff;
			3'd5: {cbr, cbg, cbb} = 24'hff0000;
			3'd6: {cbr, cbg, cbb} = 24'h0000ff;
			default: {cbr, cbg, cbb} = 24'h202020;
		endcase
	end
	reg [31:0] rowval;
	reg in_hex;
	reg [11:0] ry0;
	always @(*) begin
		if (_sv2v_0)
			;
		in_hex = 1'b0;
		rowval = 32'd0;
		ry0 = 12'd0;
		if ((vc >= 12'd52) && (vc < 12'd72)) begin
			in_hex = 1'b1;
			ry0 = 12'd52;
			rowval = {cnt_cgfx_grants, cnt_snd_grants};
		end
		else if ((vc >= 12'd76) && (vc < 12'd96)) begin
			in_hex = 1'b1;
			ry0 = 12'd76;
			rowval = cnt_cgfx_maxwait;
		end
		else if ((vc >= 12'd100) && (vc < 12'd120)) begin
			in_hex = 1'b1;
			ry0 = 12'd100;
			rowval = {cnt_snd_miss, cnt_snd_busy16};
		end
		else if ((vc >= 12'd124) && (vc < 12'd144)) begin
			in_hex = 1'b1;
			ry0 = 12'd124;
			rowval = {cnt_cvsd_moves, cnt_adpcm_moves};
		end
		else if ((vc >= 12'd148) && (vc < 12'd168)) begin
			in_hex = 1'b1;
			ry0 = 12'd148;
			rowval = snd_first_words;
		end
		else if ((vc >= 12'd172) && (vc < 12'd192)) begin
			in_hex = 1'b1;
			ry0 = 12'd172;
			rowval = cnt_snd_acks;
		end
		else if ((vc >= 12'd196) && (vc < 12'd216)) begin
			in_hex = 1'b1;
			ry0 = 12'd196;
			rowval = {cnt_blank_pix, restart_cnt};
		end
		else if ((vc >= 12'd220) && (vc < 12'd240)) begin
			in_hex = 1'b1;
			ry0 = 12'd220;
			rowval = cnt_cpu_pc_moves;
		end
	end
	localparam signed [31:0] PX0 = 8;
	wire hxin = (hc >= PX0) && (hc < 136);
	wire [7:0] hrx = hc - PX0[11:0];
	wire [2:0] hdig = hrx[6:4];
	wire [1:0] hfcol = hrx[3:2];
	wire [11:0] hry12 = vc - ry0;
	wire [2:0] hfrow = hry12[4:2];
	wire [4:0] hsh = {2'b00, 3'd7 - hdig} << 2;
	wire [3:0] hnyb = rowval >> hsh;
	wire hex_on = (((in_hex && hxin) && (hfcol < 2'd3)) && (hfrow < 3'd5)) && fpix(hnyb, {1'b0, hfcol}, hfrow);
	wire healthy = (cnt_cpu_pc_moves != 32'd0) && (cnt_cgfx_grants > 16'd64);
	wire in_status = (vc >= 12'd24) && (vc < 12'd44);
	wire live_col = hc == frame[8:0];
	always @(posedge clk)
		if (ce_pix) begin
			de <= g_de;
			hsync <= g_hs;
			vsync <= g_vs;
			hblank <= g_hb;
			vblank <= g_vb;
			if (!g_de) begin
				vid_r <= 8'd0;
				vid_g <= 8'd0;
				vid_b <= 8'd0;
			end
			else if (!s0_de) begin
				vid_r <= g_r;
				vid_g <= g_g;
				vid_b <= g_b;
			end
			else if (vc < 12'd20) begin
				vid_r <= cbr;
				vid_g <= cbg;
				vid_b <= cbb;
			end
			else if (live_col) begin
				vid_r <= 8'hff;
				vid_g <= 8'hff;
				vid_b <= 8'hff;
			end
			else if (in_status) begin
				if (healthy) begin
					vid_r <= 8'h00;
					vid_g <= 8'hc0;
					vid_b <= 8'h00;
				end
				else begin
					vid_r <= 8'hc0;
					vid_g <= 8'h00;
					vid_b <= 8'h00;
				end
			end
			else if (in_leds) begin
				if (led_body) begin
					if (led_good) begin
						vid_r <= 8'h00;
						vid_g <= 8'he0;
						vid_b <= 8'h00;
					end
					else begin
						vid_r <= 8'he0;
						vid_g <= 8'h00;
						vid_b <= 8'h00;
					end
				end
				else begin
					vid_r <= 8'h00;
					vid_g <= 8'h00;
					vid_b <= 8'h00;
				end
			end
			else if (in_hex) begin
				if (hex_on) begin
					vid_r <= 8'hff;
					vid_g <= 8'hff;
					vid_b <= 8'h00;
				end
				else begin
					vid_r <= 8'h10;
					vid_g <= 8'h10;
					vid_b <= 8'h30;
				end
			end
			else begin
				vid_r <= 8'h08;
				vid_g <= 8'h08;
				vid_b <= 8'h08;
			end
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module smashtv_diag_rom (
	clk,
	clk_cpu,
	ce_pix,
	clk_snd,
	rst,
	rst_pon,
	inputs,
	ioctl_download,
	ioctl_wr,
	ioctl_addr,
	ioctl_dout,
	ioctl_be,
	ioctl_wait,
	snd_dl_wr,
	snd_dl_addr,
	snd_dl_data,
	SDRAM_DQ,
	SDRAM_A,
	SDRAM_BA,
	SDRAM_DQML,
	SDRAM_DQMH,
	SDRAM_nCS,
	SDRAM_nRAS,
	SDRAM_nCAS,
	SDRAM_nWE,
	SDRAM_CKE,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de,
	audio_l,
	audio_r,
	pc_dbg,
	illegal_dbg,
	dbg_core_rst,
	dbg_sdram_ready,
	dbg_unp_done,
	dbg_cpu_req,
	dbg_mem_ack,
	dbg_int1,
	dbg_vblank_irq,
	dbg_derailed,
	dbg_culprit_pc,
	dbg_derail_pc,
	dbg_culprit_instr
);
	reg _sv2v_0;
	parameter ROM_HEX = "";
	parameter signed [31:0] H_ACT = 410;
	parameter signed [31:0] H_FP = 6;
	parameter signed [31:0] H_SYNC = 44;
	parameter signed [31:0] H_BP = 46;
	parameter signed [31:0] V_ACT = 256;
	parameter signed [31:0] V_FP = 13;
	parameter signed [31:0] V_SYNC = 4;
	parameter signed [31:0] V_BP = 16;
	parameter [24:0] ROMW_BASE = 25'h00c0000;
	parameter [24:0] ROM_WORDS = 25'h0020000;
	input wire clk;
	input wire clk_cpu;
	input wire ce_pix;
	input wire clk_snd;
	input wire rst;
	input wire rst_pon;
	input wire [63:0] inputs;
	input wire ioctl_download;
	input wire ioctl_wr;
	input wire [24:0] ioctl_addr;
	input wire [15:0] ioctl_dout;
	input wire [1:0] ioctl_be;
	output wire ioctl_wait;
	input wire snd_dl_wr;
	input wire [17:0] snd_dl_addr;
	input wire [7:0] snd_dl_data;
	inout wire [15:0] SDRAM_DQ;
	output wire [12:0] SDRAM_A;
	output wire [1:0] SDRAM_BA;
	output wire SDRAM_DQML;
	output wire SDRAM_DQMH;
	output wire SDRAM_nCS;
	output wire SDRAM_nRAS;
	output wire SDRAM_nCAS;
	output wire SDRAM_nWE;
	output wire SDRAM_CKE;
	output reg [7:0] vid_r;
	output reg [7:0] vid_g;
	output reg [7:0] vid_b;
	output reg hsync;
	output reg vsync;
	output reg hblank;
	output reg vblank;
	output reg de;
	output wire signed [15:0] audio_l;
	output wire signed [15:0] audio_r;
	output wire [31:0] pc_dbg;
	output wire illegal_dbg;
	output wire dbg_core_rst;
	output wire dbg_sdram_ready;
	output wire dbg_unp_done;
	output wire dbg_cpu_req;
	output wire dbg_mem_ack;
	output wire dbg_int1;
	output wire dbg_vblank_irq;
	output wire dbg_derailed;
	output wire [31:0] dbg_culprit_pc;
	output wire [31:0] dbg_derail_pc;
	output wire [15:0] dbg_culprit_instr;
	assign audio_l = 16'sd0;
	assign audio_r = 16'sd0;
	assign illegal_dbg = 1'b0;
	assign dbg_core_rst = 0;
	assign dbg_sdram_ready = 0;
	assign dbg_unp_done = 0;
	assign dbg_cpu_req = 0;
	assign dbg_mem_ack = 0;
	assign dbg_int1 = 0;
	assign dbg_vblank_irq = 0;
	assign dbg_derailed = 0;
	assign dbg_culprit_pc = 0;
	assign dbg_derail_pc = 0;
	assign dbg_culprit_instr = 0;
	reg [24:0] ctl_addr;
	reg [15:0] ctl_din;
	wire [15:0] ctl_dout;
	reg [1:0] ctl_wtbt;
	reg ctl_rd;
	reg ctl_we;
	wire ctl_ready;
	sdram_stock u_sdram(
		.init(rst),
		.clk(clk),
		.addr(ctl_addr),
		.din(ctl_din),
		.wtbt(ctl_wtbt),
		.we(ctl_we),
		.rd(ctl_rd),
		.dout(ctl_dout),
		.ready(ctl_ready),
		.SDRAM_DQ(SDRAM_DQ),
		.SDRAM_A(SDRAM_A),
		.SDRAM_BA(SDRAM_BA),
		.SDRAM_DQML(SDRAM_DQML),
		.SDRAM_DQMH(SDRAM_DQMH),
		.SDRAM_nCS(SDRAM_nCS),
		.SDRAM_nRAS(SDRAM_nRAS),
		.SDRAM_nCAS(SDRAM_nCAS),
		.SDRAM_nWE(SDRAM_nWE),
		.SDRAM_CKE(SDRAM_CKE)
	);
	localparam signed [31:0] IOL_AW = 9;
	localparam signed [31:0] IOL_HWM = 256;
	reg [42:0] iol_fifo [0:511];
	reg [IOL_AW:0] iol_wp;
	reg [IOL_AW:0] iol_rp;
	wire [IOL_AW:0] iol_occ = iol_wp - iol_rp;
	wire iol_full = iol_occ == 512;
	wire iol_empty = iol_wp == iol_rp;
	reg iol_hold;
	reg [24:0] iol_addr_r;
	reg [15:0] iol_din_r;
	reg [1:0] iol_be_r;
	reg wr_done;
	always @(posedge clk)
		if (rst) begin
			iol_wp <= 1'sb0;
			iol_rp <= 1'sb0;
			iol_hold <= 1'b0;
		end
		else begin
			if (ioctl_wr && !iol_full) begin
				iol_fifo[iol_wp[8:0]] <= {ioctl_addr, ioctl_dout, ioctl_be};
				iol_wp <= iol_wp + 1'b1;
			end
			if (iol_hold && wr_done)
				iol_hold <= 1'b0;
			if ((!iol_hold || (iol_hold && wr_done)) && !iol_empty) begin
				{iol_addr_r, iol_din_r, iol_be_r} <= iol_fifo[iol_rp[8:0]];
				iol_hold <= 1'b1;
				iol_rp <= iol_rp + 1'b1;
			end
		end
	assign ioctl_wait = iol_occ >= IOL_HWM[IOL_AW:0];
	reg [2:0] st;
	reg [24:0] ridx;
	reg [31:0] nonzero;
	reg [31:0] zero;
	reg settle;
	reg dl_seen;
	reg dl_q;
	always @(posedge clk)
		if (rst) begin
			st <= 3'd0;
			ctl_rd <= 1'b0;
			ctl_we <= 1'b0;
			ctl_addr <= 25'd0;
			ctl_din <= 16'd0;
			ctl_wtbt <= 2'b11;
			wr_done <= 1'b0;
			ridx <= 25'd0;
			nonzero <= 32'd0;
			zero <= 32'd0;
			settle <= 1'b0;
			dl_seen <= 1'b0;
			dl_q <= 1'b0;
		end
		else begin
			ctl_rd <= 1'b0;
			ctl_we <= 1'b0;
			wr_done <= 1'b0;
			dl_q <= ioctl_download;
			if (ioctl_download)
				dl_seen <= 1'b1;
			case (st)
				3'd0:
					if (ctl_ready)
						st <= 3'd1;
				3'd1:
					if (iol_hold && ctl_ready) begin
						ctl_addr <= {iol_addr_r[23:0], 1'b0};
						ctl_din <= iol_din_r;
						ctl_wtbt <= iol_be_r;
						ctl_we <= 1'b1;
						settle <= 1'b1;
						st <= 3'd2;
					end
					else if (((dl_seen && (dl_q == 1'b0)) && iol_empty) && !iol_hold) begin
						ridx <= 25'd0;
						nonzero <= 32'd0;
						zero <= 32'd0;
						st <= 3'd3;
					end
				3'd2:
					if (settle)
						settle <= 1'b0;
					else if (ctl_ready) begin
						wr_done <= 1'b1;
						st <= 3'd1;
					end
				3'd3:
					if (ctl_ready) begin
						ctl_addr <= {ROMW_BASE[23:0] + ridx[23:0], 1'b0};
						ctl_rd <= 1'b1;
						settle <= 1'b1;
						st <= 3'd4;
					end
				3'd4:
					if (settle)
						settle <= 1'b0;
					else if (ctl_ready) begin
						if (ctl_dout != 16'h0000)
							nonzero <= nonzero + 32'd1;
						else
							zero <= zero + 32'd1;
						if (ridx == (ROM_WORDS - 1))
							st <= (nonzero >= (ROM_WORDS >> 2) ? 3'd5 : 3'd6);
						else begin
							ridx <= ridx + 25'd1;
							st <= 3'd3;
						end
					end
				3'd5: st <= 3'd5;
				3'd6: st <= 3'd6;
				default: st <= 3'd0;
			endcase
		end
	assign pc_dbg = {2'd0, st, nonzero[24:0]};
	localparam signed [31:0] H_TOTAL = ((H_ACT + H_FP) + H_SYNC) + H_BP;
	localparam signed [31:0] V_TOTAL = ((V_ACT + V_FP) + V_SYNC) + V_BP;
	reg [11:0] hc;
	reg [11:0] vc;
	reg [23:0] frame;
	always @(posedge clk)
		if (rst) begin
			hc <= 0;
			vc <= 0;
			frame <= 0;
		end
		else if (ce_pix) begin
			if (hc == (H_TOTAL - 1)) begin
				hc <= 0;
				if (vc == (V_TOTAL - 1)) begin
					vc <= 0;
					frame <= frame + 24'd1;
				end
				else
					vc <= vc + 12'd1;
			end
			else
				hc <= hc + 12'd1;
		end
	wire s0_de = (hc < H_ACT) && (vc < V_ACT);
	wire s0_hb = hc >= H_ACT;
	wire s0_vb = vc >= V_ACT;
	wire s0_hs = (hc >= (H_ACT + H_FP)) && (hc < ((H_ACT + H_FP) + H_SYNC));
	wire s0_vs = (vc >= (V_ACT + V_FP)) && (vc < ((V_ACT + V_FP) + V_SYNC));
	reg [7:0] br;
	reg [7:0] bg;
	reg [7:0] bb;
	always @(*) begin
		if (_sv2v_0)
			;
		case (st)
			3'd0: begin
				br = 8'h00;
				bg = 8'h00;
				bb = 8'hc0;
			end
			3'd5: begin
				br = 8'h00;
				bg = 8'hc0;
				bb = 8'h00;
			end
			3'd6: begin
				br = 8'hc0;
				bg = 8'h00;
				bb = 8'h00;
			end
			default: begin
				br = 8'h80;
				bg = 8'h80;
				bb = 8'h00;
			end
		endcase
	end
	localparam signed [31:0] E = H_ACT / 8;
	reg [7:0] cbr;
	reg [7:0] cbg;
	reg [7:0] cbb;
	wire [2:0] bar = (hc < E ? 3'd0 : (hc < (2 * E) ? 3'd1 : (hc < (3 * E) ? 3'd2 : (hc < (4 * E) ? 3'd3 : (hc < (5 * E) ? 3'd4 : (hc < (6 * E) ? 3'd5 : (hc < (7 * E) ? 3'd6 : 3'd7)))))));
	always @(*) begin
		if (_sv2v_0)
			;
		case (bar)
			3'd0: {cbr, cbg, cbb} = 24'hffffff;
			3'd1: {cbr, cbg, cbb} = 24'hffff00;
			3'd2: {cbr, cbg, cbb} = 24'h00ffff;
			3'd3: {cbr, cbg, cbb} = 24'h00ff00;
			3'd4: {cbr, cbg, cbb} = 24'hff00ff;
			3'd5: {cbr, cbg, cbb} = 24'hff0000;
			3'd6: {cbr, cbg, cbb} = 24'h0000ff;
			default: {cbr, cbg, cbb} = 24'h000000;
		endcase
	end
	wire [5:0] zlog = (zero[31] ? 6'd32 : (zero[24] ? 6'd25 : (zero[20] ? 6'd21 : (zero[16] ? 6'd17 : (zero[14] ? 6'd15 : (zero[12] ? 6'd13 : (zero[10] ? 6'd11 : (zero[8] ? 6'd9 : (zero[4] ? 6'd5 : (zero[0] ? 6'd1 : 6'd0))))))))));
	wire [15:0] zbar = (H_ACT * zlog) >> 5;
	wire in_bars = vc < (V_ACT / 8);
	wire in_zbar = vc >= (V_ACT - (V_ACT / 8));
	wire live_col = hc == frame[8:0];
	always @(posedge clk)
		if (ce_pix) begin
			de <= s0_de;
			hsync <= s0_hs;
			vsync <= s0_vs;
			hblank <= s0_hb;
			vblank <= s0_vb;
			if (!s0_de) begin
				vid_r <= 0;
				vid_g <= 0;
				vid_b <= 0;
			end
			else if (in_bars) begin
				vid_r <= cbr;
				vid_g <= cbg;
				vid_b <= cbb;
			end
			else if (live_col) begin
				vid_r <= 8'hff;
				vid_g <= 8'hff;
				vid_b <= 8'hff;
			end
			else if (in_zbar) begin
				if ({4'd0, hc} < zbar) begin
					vid_r <= 8'hff;
					vid_g <= 8'h00;
					vid_b <= 8'h00;
				end
				else begin
					vid_r <= 8'h20;
					vid_g <= 8'h20;
					vid_b <= 8'h20;
				end
			end
			else begin
				vid_r <= br;
				vid_g <= bg;
				vid_b <= bb;
			end
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module smashtv_snd_rom (
	clk,
	addr,
	data,
	wrclk,
	we,
	waddr,
	wdata
);
	parameter HEX = "build/snd_u4.hex";
	input wire clk;
	input wire [15:0] addr;
	output reg [7:0] data;
	input wire wrclk;
	input wire we;
	input wire [15:0] waddr;
	input wire [7:0] wdata;
	(* ramstyle = "no_rw_check" *) reg [7:0] mem [0:65535];
	always @(posedge wrclk)
		if (we)
			mem[waddr] <= wdata;
	always @(posedge clk) data <= mem[addr];
endmodule
`default_nettype wire
