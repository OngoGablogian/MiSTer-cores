Y Unit - Family r36
RBF SHA-256: c58d851299b633d2c4d19d3e907627eb500e0130442e21f0bd983bf3303c7418

This archive contains the selected integration source and build support files.
Use Quartus 17.0 Lite for the DE10-Nano / Cyclone V target. See the project
QSF/QIP files and build scripts for the source list and conversion steps.
Third-party files retain their individual copyright and license notices.
No game ROMs, personal settings, fitted databases or game traces are included.
ROMs are loaded by MiSTer at runtime; ROM-driven simulations need local game data.

Source identity: yunit_smash_saurian_r36_20260904
For Wolf Unit use WOLF_MASTER=1,CRT_ADJUST=1,USE_DDR3_GFX=1,USE_DDR3_VRAM=1.
The compiled binary's validation status is recorded in the feed catalog.
