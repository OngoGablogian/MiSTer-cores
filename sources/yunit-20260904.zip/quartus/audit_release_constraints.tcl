# Read-only release audit of SDC collections against the fitted netlist.
#
# This intentionally checks collections whose absence would silently weaken a
# timing exception. Diagnostic collections are optional in production and
# required when DIAG_BOOT is selected.
project_open Arcade-SmashTV -revision Arcade-SmashTV
create_timing_netlist
read_sdc
update_timing_netlist

set build_macro ""
if {[info exists ::env(YUNIT_BUILD_MACRO)]} {
  set build_macro $::env(YUNIT_BUILD_MACRO)
}
proc macro_token_present {macro_string token} {
  foreach macro_token [split $macro_string] {
    if {[lindex [split $macro_token "="] 0] eq $token} {
      return 1
    }
  }
  return 0
}
set diag_build [macro_token_present $build_macro "DIAG_BOOT"]
# DIAG_DLAUDIT (P0020 download audit) REPLACES the default DIAG_BOOT row set:
# rows 1-3 show dbg_iol_drop / dbg_iol_wrs instead of the derail capture. With no
# consumer, the fitter correctly sweeps the derail-capture registers
# (dbg_culprit_pc, dbg_derail_pc, d_prevpc, rd_cnt) -- so requiring them here
# fails a correct build for doing exactly what it is supposed to do. The overlay
# itself is still required below, which is the check that actually matters:
# it proves the instrument reached the fitted netlist.
set dlaudit_build [macro_token_present $build_macro "DIAG_DLAUDIT"]
set derail_rows_shown [expr {$diag_build && !$dlaudit_build}]
set smash_recovery_macro [macro_token_present $build_macro "YUNIT_SMASH_RECOVERY"]
set family2_macro [macro_token_present $build_macro "YUNIT_FAMILY2"]
# YUNIT_FULL is the single all-titles core. It instantiates the SAME
# yunit_top_family2 hierarchy, so it is the same /4-clock-enable design and
# belongs in exactly this class -- it differs only in the memory map and in
# carrying both sound boards, neither of which touches the CE topology.
#
# Omitting it here did not weaken a check, it selected the WRONG RULESET: the
# fitted design still matched yunit_top_family2|ce_div*, so the topology probe
# said "legacy CE" while the macro probe said "no", and the audit fell through
# to the old-family branch. That demanded scheduler_*/dma_timer_*/gfx_*
# register collections this hierarchy deliberately does not contain (they are
# on the elaboration gate's FORBID list) and the old multicycle expectation --
# 1090 cascading failures from one missing token.
set full_macro [macro_token_present $build_macro "YUNIT_FULL"]
# YUNIT_ADPCM is the audio-split sibling (MK / T2 / Total Carnage). It is the SAME
# yunit_top_family2 hierarchy with the same 8 MB map as FULL -- it differs only by not
# carrying the CVSD board, which is a module-presence question and does not touch the CE
# topology. So it belongs in this class too.
#
# This token was missed on the first ADPCM build and reproduced the failure the comment
# above describes, to the digit: the fitted design still matched yunit_top_family2|ce_div*,
# the macro probe said "no", the audit fell through to the old-family branch, and demanded
# scheduler_*/dma_timer_*/gfx_* collections this hierarchy deliberately does not contain.
# 1095 cascading failures from one missing token, with every worst-path slack POSITIVE.
# The tell that it is a ruleset mismatch and not timing: SDC_AUDIT reports failures in the
# thousands while the reported worst path has healthy positive slack.
set adpcm_macro [macro_token_present $build_macro "YUNIT_ADPCM"]
set srt_fill_build [macro_token_present $build_macro "YUNIT_SRT_FILL_BURST"]
set smash_recovery [expr {$smash_recovery_macro || $family2_macro || $full_macro || $adpcm_macro}]
set family_core [expr {$family2_macro || $full_macro || $adpcm_macro}]
puts "SDC_AUDIT build_macro={$build_macro} diag_build=$diag_build dlaudit=$dlaudit_build legacy_ce=$smash_recovery (recovery=$smash_recovery_macro family2=$family2_macro full=$full_macro adpcm=$adpcm_macro srt_fill=$srt_fill_build)"

proc collection_count {collection} {
  set count 0
  foreach_in_collection item $collection {
    incr count
  }
  return $count
}

set failures 0
proc require_collection {label collection} {
  global failures
  set count [collection_count $collection]
  puts "SDC_AUDIT required $label count=$count"
  if {$count == 0} {
    puts "SDC_AUDIT ERROR required collection is empty: $label"
    incr failures
  }
}

proc optional_collection {label collection} {
  puts "SDC_AUDIT optional $label count=[collection_count $collection]"
}

proc require_empty_collection {label collection} {
  global failures
  set count [collection_count $collection]
  puts "SDC_AUDIT forbidden $label count=$count"
  if {$count != 0} {
    puts "SDC_AUDIT ERROR forbidden collection is non-empty: $label"
    incr failures
  }
}

proc require_collection_min_count {label collection expected_min} {
  global failures
  set count [collection_count $collection]
  puts "SDC_AUDIT required $label count=$count expected_min=$expected_min"
  if {$count < $expected_min} {
    puts "SDC_AUDIT ERROR required collection is undersized: $label"
    incr failures
  }
}

proc require_collection_exact_count {label collection expected} {
  global failures
  set count [collection_count $collection]
  puts "SDC_AUDIT required $label count=$count expected=$expected"
  if {$count != $expected} {
    puts "SDC_AUDIT ERROR required collection has wrong size: $label"
    incr failures
  }
}

proc diagnostic_collection {label collection diag_build} {
  if {$diag_build} {
    require_collection $label $collection
  } else {
    optional_collection $label $collection
  }
}

proc require_setup_multicycle {label sources targets expected_start expected_end} {
  global failures
  if {[get_collection_size $sources] == 0 ||
      [get_collection_size $targets] == 0} {
    puts "SDC_AUDIT multicycle $label paths=0 (empty endpoint collection)"
    incr failures
    return
  }
  set paths [get_timing_paths -setup -from $sources -to $targets -npaths 500 -nworst 1]
  set count [get_collection_size $paths]
  puts "SDC_AUDIT multicycle $label paths=$count expected_start=$expected_start expected_end=$expected_end"
  if {$count == 0} {
    incr failures
    return
  }
  set row 0
  set mismatches 0
  foreach_in_collection path $paths {
    incr row
    set source [get_node_info [get_path_info -from $path] -name]
    set target [get_node_info [get_path_info -to $path] -name]
    set start_mc [get_path_info -setup_start_multicycle $path]
    set end_mc [get_path_info -setup_end_multicycle $path]
    set slack [get_path_info -slack $path]
    if {$row <= 3} {
      puts "SDC_AUDIT multicycle_path $label row=$row start=$start_mc end=$end_mc slack=$slack from={$source} to={$target}"
    }
    if {$start_mc != $expected_start || $end_mc != $expected_end} {
      puts "SDC_AUDIT ERROR wrong setup multicycle on $label row=$row"
      incr mismatches
      incr failures
    }
  }
  puts "SDC_AUDIT multicycle_result $label checked=$row mismatches=$mismatches"
}

proc require_no_setup_path {label sources targets} {
  global failures
  if {[get_collection_size $sources] == 0 ||
      [get_collection_size $targets] == 0} {
    puts "SDC_AUDIT no_path $label paths=0 (empty endpoint collection)"
    incr failures
    return
  }
  set paths [get_timing_paths -setup -from $sources -to $targets -npaths 1]
  set count [get_collection_size $paths]
  puts "SDC_AUDIT no_path $label paths=$count expected=0"
  if {$count != 0} {
    foreach_in_collection path $paths {
      set source [get_node_info [get_path_info -from $path] -name]
      set target [get_node_info [get_path_info -to $path] -name]
      puts "SDC_AUDIT ERROR forbidden setup path exists: $label from={$source} to={$target}"
      break
    }
    incr failures
  }
}

# Physical synthesis may clone a preserved register and expose the clone as
# <canonical leaf>~DUPLICATE. A raw collection count then grows even though the
# requested RTL bank remains intact. Check every canonical leaf exactly once
# while permitting only fitter-generated duplicates of those same leaves. A
# duplicate never satisfies a missing canonical bit.
proc require_exact_register_leaves {label collection expected_leaves} {
  global failures
  array set seen {}
  foreach expected_leaf $expected_leaves {
    set seen($expected_leaf) 0
  }

  set duplicate_count 0
  set unexpected_count 0
  foreach_in_collection item $collection {
    set full_name [get_node_info $item -name]
    set leaf [lindex [split $full_name "|"] end]
    if {[info exists seen($leaf)]} {
      incr seen($leaf)
      continue
    }

    set recognized_duplicate 0
    foreach expected_leaf $expected_leaves {
      if {$leaf eq "${expected_leaf}~DUPLICATE"} {
        incr duplicate_count
        set recognized_duplicate 1
        break
      }
    }
    if {$recognized_duplicate} {
      continue
    }

    puts "SDC_AUDIT ERROR unexpected register in $label: {$full_name}"
    incr unexpected_count
  }

  set expected_count [llength $expected_leaves]
  set canonical_count 0
  set canonical_mismatches 0
  foreach expected_leaf $expected_leaves {
    incr canonical_count $seen($expected_leaf)
    if {$seen($expected_leaf) != 1} {
      puts "SDC_AUDIT ERROR required canonical register count is $seen($expected_leaf), expected 1: $label {$expected_leaf}"
      incr canonical_mismatches
    }
  }
  puts "SDC_AUDIT required $label canonical_count=$canonical_count expected=$expected_count duplicates=$duplicate_count unexpected=$unexpected_count"
  if {$canonical_mismatches != 0 || $unexpected_count != 0} {
    incr failures
  }
}

set raw_cpu [get_registers {*tms34010_core:u_core|*}]
set io_fullrate [get_registers {*tms34010_core:u_core|*u_io_regs|*}]
set gated_cpu [remove_from_collection $raw_cpu $io_fullrate]
set mmfm_issue_active [get_registers -nowarn {*tms34010_core:u_core|mmfm_issue_active_q*}]
set mmfm_issue_file [get_registers -nowarn {*tms34010_core:u_core|mmfm_issue_file_q*}]
set mmfm_issue_target [get_registers -nowarn {*tms34010_core:u_core|mmfm_issue_target_q[*]*}]
set mmfm_issue_stage [add_to_collection $mmfm_issue_active $mmfm_issue_file]
set mmfm_issue_stage [add_to_collection $mmfm_issue_stage $mmfm_issue_target]
set mmfm_commit_data [get_registers -nowarn {*tms34010_core:u_core|mmfm_commit_data_q[*]*}]
set mmfm_commit_target [get_registers -nowarn {*tms34010_core:u_core|mmfm_commit_target_q[*]*}]
set mmfm_commit_stage [add_to_collection $mmfm_commit_data $mmfm_commit_target]
# MMFM's accepted read is captured and committed on consecutive full-rate sysclk
# edges. It must not inherit the broad CPU-CE /4 exception merely because the
# boundary registers live inside tms34010_core. The issue registers deliberately
# remain in gated_cpu: they capture only on a CPU opportunity, while the 63-bit
# data/one-hot-target commit bank advances on the following ordinary sysclk edge.
set gated_cpu [remove_from_collection $gated_cpu $mmfm_commit_stage]
set memcdc_cpu [get_registers {*u_memcdc|cst* *u_memcdc|req_tgl* *u_memcdc|c_ack* *u_memcdc|c_rdata* *u_memcdc|ackt_sync* *u_memcdc|p_we* *u_memcdc|p_addr* *u_memcdc|p_size* *u_memcdc|p_wdata*}]
set mmfm_memcdc_rdata [get_registers -nowarn {*u_memcdc|c_rdata*}]
set mmfm_memcdc_ack [get_registers -nowarn {*u_memcdc|c_ack*}]
set recovery_ce [get_registers -nowarn {*yunit_top_smash_firefix:yunit_top|ce_div* *yunit_top_family2:yunit_top|ce_div*}]
set fitted_smash_recovery [expr {[get_collection_size $recovery_ce] > 0}]
if {$fitted_smash_recovery != $smash_recovery} {
  puts "SDC_AUDIT ERROR macro/topology mismatch: macro_recovery=$smash_recovery fitted_recovery=$fitted_smash_recovery"
  incr failures
}
if {$smash_recovery} {
  set cpu_top_debug [get_registers -nowarn {*yunit_top_smash_firefix:yunit_top|rd_cnt* *yunit_top_smash_firefix:yunit_top|ack_q* *yunit_top_smash_firefix:yunit_top|d_started* *yunit_top_smash_firefix:yunit_top|d_prevpc* *yunit_top_smash_firefix:yunit_top|dbg_derailed* *yunit_top_smash_firefix:yunit_top|dbg_culprit_pc* *yunit_top_smash_firefix:yunit_top|dbg_culprit_instr* *yunit_top_smash_firefix:yunit_top|dbg_derail_pc* *yunit_top_family2:yunit_top|rd_cnt* *yunit_top_family2:yunit_top|ack_q* *yunit_top_family2:yunit_top|d_started* *yunit_top_family2:yunit_top|d_prevpc* *yunit_top_family2:yunit_top|dbg_derailed* *yunit_top_family2:yunit_top|dbg_culprit_pc* *yunit_top_family2:yunit_top|dbg_culprit_instr* *yunit_top_family2:yunit_top|dbg_derail_pc*}]
} else {
  set cpu_top_debug [get_registers -nowarn {*yunit_top:yunit_top|rd_cnt* *yunit_top:yunit_top|ack_q* *yunit_top:yunit_top|d_started* *yunit_top:yunit_top|d_prevpc* *yunit_top:yunit_top|dbg_derailed* *yunit_top:yunit_top|dbg_culprit_pc* *yunit_top:yunit_top|dbg_culprit_instr* *yunit_top:yunit_top|dbg_derail_pc*}]
}
set cpu_domain [add_to_collection $gated_cpu $memcdc_cpu]
set cpu_domain [add_to_collection $cpu_domain $cpu_top_debug]
require_collection cpu_ce_registers $gated_cpu
# Physical-synthesis decode OTERM aliases can appear when a diagnostic cut
# segments a path, but a true registered launch must resolve here.  A zero
# count confirms those decode aliases are combinational continuations, not
# unconstrained clocked startpoints.
set decode_retimed [get_registers -nowarn {*tms34010_decode:u_decode|*OTERM*}]
set instruction_launch [get_registers -nowarn {*tms34010_core:u_core|instr_word_q*}]
# The preserved 53-bit command snapshot is the timing boundary between the
# opcode decoder and every execute/writeback consumer.  Require both halves of
# that split explicitly so synthesis cannot collapse it unnoticed.
set decode_snapshot [get_registers -nowarn {*tms34010_core:u_core|decoded*}]
set cpu_regfile [get_registers -nowarn {*tms34010_regfile:u_regfile|a_regs* *tms34010_regfile:u_regfile|b_regs* *tms34010_regfile:u_regfile|sp_q*}]
set mmfm_mask_state [get_registers -nowarn {*tms34010_core:u_core|mm_mask_q[*]*}]
set mmfm_mask_state_expected [list]
for {set bit 0} {$bit < 16} {incr bit} {
  lappend mmfm_mask_state_expected [format {mm_mask_q[%d]} $bit]
}
set mmfm_issue_stage_expected [list {mmfm_issue_active_q} {mmfm_issue_file_q}]
for {set bit 0} {$bit < 31} {incr bit} {
  lappend mmfm_issue_stage_expected [format {mmfm_issue_target_q[%d]} $bit]
}
set mmfm_commit_stage_expected [list]
foreach {bank width} [list mmfm_commit_data_q 32 mmfm_commit_target_q 31] {
  for {set bit 0} {$bit < $width} {incr bit} {
    lappend mmfm_commit_stage_expected [format {%s[%d]} $bank $bit]
  }
}
set gfx_snapshot [get_registers -nowarn {*u_gfx_cycle_counter|dx_q* *u_gfx_cycle_counter|dst_addr_q* *u_gfx_cycle_counter|bpp_shift_q* *u_gfx_cycle_counter|op_timing_q*}]
set gfx_accumulator [get_registers -nowarn {*u_gfx_cycle_counter|acc_q*}]
set scheduler_retire_capture [get_registers -nowarn {*tms34010_cycle_scheduler:u_cpu_scheduler|retire_toggle_q* *tms34010_cycle_scheduler:u_cpu_scheduler|retire_cycles_q*}]
set scheduler_intenb_shadow [get_registers -nowarn {*tms34010_io_cpu_status:u_io_cpu_status|intenb[*]}]
set scheduler_intpend_shadow [get_registers -nowarn {*tms34010_io_cpu_status:u_io_cpu_status|intpend[*]}]
set scheduler_hstctlh_shadow [get_registers -nowarn {*tms34010_io_cpu_status:u_io_cpu_status|hstctlh[*]}]
set scheduler_interrupt_shadow [get_registers -nowarn {*tms34010_io_cpu_status:u_io_cpu_status|intenb[*] *tms34010_io_cpu_status:u_io_cpu_status|intpend[*] *tms34010_io_cpu_status:u_io_cpu_status|hstctlh[*]}]
# P0038-W timing boundary: these 43 preserved bits are the positioned field
# command consumed by the full-rate physical I/O register bank one sysclk later.
# They must survive fit, and this edge must remain an ordinary 1/1 path. The
# CPU-domain /4 relaxation ends at the boundary; extending it into io_reg would
# hide the exact setup regression this bank was introduced to remove.
set io_boundary_wr_idx [get_registers -nowarn {*tms34010_io_write_boundary:u_io_write_boundary|wr_idx[*]}]
set io_boundary_wr_idx_hi [get_registers -nowarn {*tms34010_io_write_boundary:u_io_write_boundary|wr_idx_hi[*]}]
set io_boundary_wr_span2 [get_registers -nowarn {*tms34010_io_write_boundary:u_io_write_boundary|wr_span2*}]
set io_boundary_wr_low_mask [get_registers -nowarn {*tms34010_io_write_boundary:u_io_write_boundary|wr_low_mask[*]}]
set io_boundary_wr_low_data [get_registers -nowarn {*tms34010_io_write_boundary:u_io_write_boundary|wr_low_data[*]}]
set io_boundary_field_meta [add_to_collection $io_boundary_wr_idx $io_boundary_wr_idx_hi]
set io_boundary_field_meta [add_to_collection $io_boundary_field_meta $io_boundary_wr_span2]
set io_boundary_field_meta [add_to_collection $io_boundary_field_meta $io_boundary_wr_low_mask]
set io_boundary_field_meta [add_to_collection $io_boundary_field_meta $io_boundary_wr_low_data]
set io_physical_registers [get_registers -nowarn {*tms34010_io_regs:u_io_regs|io_reg*}]
set scheduler_start_elapsed_cycles [get_registers -nowarn {*tms34010_cycle_scheduler:u_cpu_scheduler|elapsed_cycles*}]
set scheduler_start_elapsed_fraction [get_registers -nowarn {*tms34010_cycle_scheduler:u_cpu_scheduler|elapsed_fraction*}]
set scheduler_start_active [get_registers -nowarn {*tms34010_cycle_scheduler:u_cpu_scheduler|active*}]
set scheduler_start_waiting [get_registers -nowarn {*tms34010_cycle_scheduler:u_cpu_scheduler|waiting*}]
set shiftreg_command_capture [get_registers -nowarn {*yunit_shiftreg_command_bridge:u_shiftreg_cmd|cmd_valid_q* *yunit_shiftreg_command_bridge:u_shiftreg_cmd|cmd_write_q* *yunit_shiftreg_command_bridge:u_shiftreg_cmd|cmd_bit_addr_q*}]
set shadow_valid_bank_stage [get_registers -nowarn {*stv_vram_ddr_top:*|shw_v_bank_q[*]}]
set shadow_valid_bank_select [get_registers -nowarn {*stv_vram_ddr_top:*|shw_v_bank_sel_q[*]}]
set vram_locality_stage [get_registers -nowarn {*stv_vram_ddr_top:*|bsn_fill_row_q[*]* *stv_vram_ddr_top:*|bsn_fillbeat_q[*]* *stv_vram_ddr_top:*|bsn_d_addr_q[*]* *stv_vram_ddr_top:*|bsn_d_blen_q[*]* *stv_vram_ddr_top:*|ack_wc_beat_q[*]* *stv_vram_ddr_top:*|bsn_wc_beat_q[*]*}]
set bsn_commit_valid [get_registers -nowarn {*stv_vram_ddr_top:*|bsn_commit_v*}]
set bsn_commit_addr [get_registers -nowarn {*stv_vram_ddr_top:*|bsn_commit_addr[*]*}]
set bsn_commit_data [get_registers -nowarn {*stv_vram_ddr_top:*|bsn_commit_data[*]*}]
# Keep the full collection in the exact-leaf census so an unexpected physical
# dead-bit register is visible, but use only cabinet-observable data lanes for
# the two timing-path collections.
set bsn_commit_data_live $bsn_commit_data
foreach dead_bit [list 6 7 22 23 38 39 54 55] {
  set dead_regs [get_registers -nowarn [format {*stv_vram_ddr_top:*|bsn_commit_data[%d]*} $dead_bit]]
  set bsn_commit_data_live [remove_from_collection $bsn_commit_data_live $dead_regs]
}
set bsn_commit_stage [add_to_collection $bsn_commit_valid $bsn_commit_addr]
set bsn_commit_stage [add_to_collection $bsn_commit_stage $bsn_commit_data]
set vram_bsn_fillbeat [get_registers -nowarn {*stv_vram_ddr_top:*|bsn_fillbeat_q[*]*}]
# Every registered producer that can feed the BSNOOP merge belongs on the
# capture side of the new boundary. The exact subset with live timing paths may
# vary by fit, but the aggregate collection and its 1/1 path coverage may not
# disappear.
set vram_bsn_merge_sources [get_registers -nowarn {*stv_vram_ddr_top:*|shw_q[*]* *stv_vram_ddr_top:*|d_fwd[*]* *stv_vram_ddr_top:*|wb_data[*]* *stv_vram_ddr_top:*|rb_data[*]* *stv_vram_ddr_top:*|d_wdata[*]* *stv_vram_ddr_top:*|df_data[*]* *stv_vram_ddr_top:*|wc_data[*]*}]
set vram_live_d_address [get_registers -nowarn {*stv_vram_ddr_top:*|d_addr[*]*}]
set vram_live_fillbeat [get_registers -nowarn {*stv_vram_ddr_top:*|fillbeat[*]*}]
set vram_live_wc_beat [get_registers -nowarn {*stv_vram_ddr_top:*|wc_beat[*]*}]
set vram_row_cache_write_data [get_registers -nowarn {*stv_vram_ddr_top:*|altsyncram:rc_rtl_0|*porta_datain_reg*}]
set vram_row_cache_write_address [get_registers -nowarn {*stv_vram_ddr_top:*|altsyncram:rc_rtl_0|*porta_address_reg*}]
set vram_dma_ack_targets [get_registers -nowarn {*yunit_dma_family2:u_dma|tx[*]* *yunit_dma_family2:u_dma|o_ptr[*]*}]
set video_mirror_locality_stage [get_registers -nowarn {*yunit_video:u_video|scan_x_mirror_q[*]}]
set video_live_mirror [get_registers -nowarn {*yunit_video:u_video|x_mirror[*]*}]
set video_overlay_valid [get_registers -nowarn {*yunit_scanline:u_scan|ov0_valid[*]* *yunit_scanline:u_scan|ov1_valid[*]*}]
set shadow_valid_bank_stage_expected [list \
  {shw_v_bank_q[0]} \
  {shw_v_bank_q[1]} \
  {shw_v_bank_q[2]} \
  {shw_v_bank_q[3]} \
  {shw_v_bank_q[4]} \
  {shw_v_bank_q[5]} \
  {shw_v_bank_q[6]} \
  {shw_v_bank_q[7]} \
  {shw_v_bank_q[8]} \
  {shw_v_bank_q[9]} \
  {shw_v_bank_q[10]} \
  {shw_v_bank_q[11]} \
  {shw_v_bank_q[12]} \
  {shw_v_bank_q[13]} \
  {shw_v_bank_q[14]} \
  {shw_v_bank_q[15]}]
set shadow_valid_bank_select_expected [list \
  {shw_v_bank_sel_q[0]} \
  {shw_v_bank_sel_q[1]} \
  {shw_v_bank_sel_q[2]} \
  {shw_v_bank_sel_q[3]}]
set vram_locality_expected [list]
foreach {bank width} [list \
    bsn_fill_row_q 9 \
    bsn_fillbeat_q 7 \
    bsn_d_addr_q 16 \
    bsn_d_blen_q 4 \
    ack_wc_beat_q 16 \
    bsn_wc_beat_q 16] {
  for {set bit 0} {$bit < $width} {incr bit} {
    lappend vram_locality_expected [format {%s[%d]} $bank $bit]
  }
}
set bsn_commit_stage_expected [list {bsn_commit_v}]
for {set bit 0} {$bit < 7} {incr bit} {
  lappend bsn_commit_stage_expected [format {bsn_commit_addr[%d]} $bit]
}
# The production pixel consumers discard bits [7:6] for both supported modes:
# pen_map6={w[11:8],w[15:14],w[5:0]} and
# pen_map4={4'b0000,w[15:12],w[3:0]}.  The 128x64 logical row cache therefore
# maps to a 128x56 physical RAM, and Quartus correctly removes exactly those
# two dead bits from each of the four packed pixels.  Keep the full 64-bit RTL
# stage for simulation/debug fidelity, but require every physically observable
# data leaf and reject any other/missing leaf.  The post-map gate separately
# pins the exact eight-bit removal set and its Lost fanout reason.
set bsn_commit_dead_data_bits [list 6 7 22 23 38 39 54 55]
set bsn_commit_live_data_count 0
for {set bit 0} {$bit < 64} {incr bit} {
  set pixel_bit [expr {$bit % 16}]
  if {$pixel_bit == 6 || $pixel_bit == 7} {
    continue
  }
  lappend bsn_commit_stage_expected [format {bsn_commit_data[%d]} $bit]
  incr bsn_commit_live_data_count
}
# scan_x_mirror_q is declared [11:0], but visible_px is clamped to H_ACT=410
# (yunit_video.sv:28,59) so vis_last_q <= 409 -- a 9-bit value. Bits [11:9] are
# provably constant zero and Quartus sweeps them from the canonical x_mirror AND
# from this locality copy alike. Hardcoding 12 held the copy to a STRICTER
# standard than the register it mirrors, which is what failed the r3 audit at
# canonical_count=9 expected=12.
#
# The real invariant for a same-D copy is that it survives EXACTLY where its
# source survives, so derive the expected leaves from the canonical collection.
# This is STRONGER than any literal: a bit swept on the copy but not on the
# canonical still fails as missing, a bit present on the copy but not the
# canonical still fails as unexpected, and if the visible width ever grows so
# bit 9+ becomes live then all 12 are required on both.
set video_mirror_locality_expected [list]
foreach_in_collection mirror_item $video_live_mirror {
  set mirror_leaf [lindex [split [get_node_info $mirror_item -name] "|"] end]
  if {[regexp {x_mirror\[(\d+)\]} $mirror_leaf -> mirror_bit]} {
    lappend video_mirror_locality_expected       [format {scan_x_mirror_q[%d]} $mirror_bit]
  }
}
set video_mirror_locality_expected   [lsort -unique $video_mirror_locality_expected]
# Zero-coverage guard: an empty derived set would make the exact-leaves check
# vacuously true. The mirror must span at least the 9 bits needed to hold
# H_ACT-1 = 409, so anything less is a real defect, not width optimization.
if {[llength $video_mirror_locality_expected] < 9} {
  puts [format {SDC_AUDIT ERROR video mirror canonical span too small: %d expected>=9}     [llength $video_mirror_locality_expected]]
  incr failures
}
if {$family_core} {
  require_exact_register_leaves shadow_valid_bank_stage \
    $shadow_valid_bank_stage $shadow_valid_bank_stage_expected
  require_exact_register_leaves shadow_valid_bank_select \
    $shadow_valid_bank_select $shadow_valid_bank_select_expected
  require_exact_register_leaves vram_locality_stage \
    $vram_locality_stage $vram_locality_expected
  require_exact_register_leaves bsn_commit_stage \
    $bsn_commit_stage $bsn_commit_stage_expected
  puts [format {SDC_AUDIT bsn_commit_live_mask live_data=%d dead_data=%d dead_bits=%s} \
    $bsn_commit_live_data_count [llength $bsn_commit_dead_data_bits] \
    [join $bsn_commit_dead_data_bits ,]]
  require_collection vram_bsn_fillbeat $vram_bsn_fillbeat
  require_collection vram_bsn_merge_sources $vram_bsn_merge_sources
  require_collection vram_live_d_address $vram_live_d_address
  require_collection vram_live_fillbeat $vram_live_fillbeat
  require_collection vram_live_wc_beat $vram_live_wc_beat
  require_collection vram_row_cache_write_data $vram_row_cache_write_data
  require_collection vram_row_cache_write_address $vram_row_cache_write_address
  require_collection vram_dma_ack_targets $vram_dma_ack_targets
  require_setup_multicycle vram_bsn_fillbeat_to_commit_address \
    $vram_bsn_fillbeat $bsn_commit_addr 1 1
  require_setup_multicycle vram_bsn_merge_to_commit_data \
    $vram_bsn_merge_sources $bsn_commit_data_live 1 1
  require_setup_multicycle vram_bsn_commit_data_to_row_cache_data \
    $bsn_commit_data_live $vram_row_cache_write_data 1 1
  require_setup_multicycle vram_bsn_commit_address_to_row_cache_address \
    $bsn_commit_addr $vram_row_cache_write_address 1 1
  require_no_setup_path vram_bsn_merge_sources_to_row_cache_data \
    $vram_bsn_merge_sources $vram_row_cache_write_data
  require_no_setup_path vram_bsn_fillbeat_to_row_cache_data \
    $vram_bsn_fillbeat $vram_row_cache_write_data
  require_no_setup_path vram_bsn_fillbeat_to_row_cache_address \
    $vram_bsn_fillbeat $vram_row_cache_write_address
  require_no_setup_path vram_live_d_address_to_row_cache_data \
    $vram_live_d_address $vram_row_cache_write_data
  require_no_setup_path vram_live_fillbeat_to_row_cache_data \
    $vram_live_fillbeat $vram_row_cache_write_data
  require_no_setup_path vram_live_wc_beat_to_row_cache_data \
    $vram_live_wc_beat $vram_row_cache_write_data
  require_no_setup_path vram_live_wc_beat_to_dma_ack_targets \
    $vram_live_wc_beat $vram_dma_ack_targets
  if {$srt_fill_build} {
    require_exact_register_leaves video_mirror_locality_stage \
      $video_mirror_locality_stage $video_mirror_locality_expected
    require_collection video_live_mirror $video_live_mirror
    require_collection video_overlay_valid $video_overlay_valid
    require_no_setup_path video_live_mirror_to_overlay_valid \
      $video_live_mirror $video_overlay_valid
  } else {
    optional_collection video_mirror_locality_stage $video_mirror_locality_stage
    optional_collection video_live_mirror $video_live_mirror
    optional_collection video_overlay_valid $video_overlay_valid
  }
} else {
  optional_collection shadow_valid_bank_stage $shadow_valid_bank_stage
  optional_collection shadow_valid_bank_select $shadow_valid_bank_select
  optional_collection vram_locality_stage $vram_locality_stage
  optional_collection bsn_commit_stage $bsn_commit_stage
  optional_collection vram_bsn_fillbeat $vram_bsn_fillbeat
  optional_collection vram_bsn_merge_sources $vram_bsn_merge_sources
  optional_collection vram_live_d_address $vram_live_d_address
  optional_collection vram_live_fillbeat $vram_live_fillbeat
  optional_collection vram_live_wc_beat $vram_live_wc_beat
  optional_collection vram_row_cache_write_data $vram_row_cache_write_data
  optional_collection vram_row_cache_write_address $vram_row_cache_write_address
  optional_collection vram_dma_ack_targets $vram_dma_ack_targets
  optional_collection video_mirror_locality_stage $video_mirror_locality_stage
  optional_collection video_live_mirror $video_live_mirror
  optional_collection video_overlay_valid $video_overlay_valid
}
# Only address bits 13..19 carry the seven-bit exact row-pair index. Other
# command-address flops may be constant-trimmed or retained for explicit PIXT;
# auditing the whole 32-bit bank would therefore be both brittle and weaker.
set shiftreg_command_pair_addr [get_registers -nowarn {*yunit_shiftreg_command_bridge:u_shiftreg_cmd|cmd_bit_addr_q[13] *yunit_shiftreg_command_bridge:u_shiftreg_cmd|cmd_bit_addr_q[14] *yunit_shiftreg_command_bridge:u_shiftreg_cmd|cmd_bit_addr_q[15] *yunit_shiftreg_command_bridge:u_shiftreg_cmd|cmd_bit_addr_q[16] *yunit_shiftreg_command_bridge:u_shiftreg_cmd|cmd_bit_addr_q[17] *yunit_shiftreg_command_bridge:u_shiftreg_cmd|cmd_bit_addr_q[18] *yunit_shiftreg_command_bridge:u_shiftreg_cmd|cmd_bit_addr_q[19]}]
set shiftreg_cpu_response [get_registers -nowarn {*yunit_shiftreg_command_bridge:u_shiftreg_cmd|core_ack_q}]
set shiftreg_command_issued [get_registers -nowarn {*yunit_shiftreg_command_bridge:u_shiftreg_cmd|command_issued_q}]
set shiftreg_ack_pending [get_registers -nowarn {*yunit_shiftreg_command_bridge:u_shiftreg_cmd|ack_pending_q}]
set shiftreg_transaction_state [add_to_collection $shiftreg_command_issued $shiftreg_ack_pending]
set shiftreg_expected_boundary [add_to_collection $shiftreg_transaction_state $shiftreg_cpu_response]
set shiftreg_all_boundary [get_registers -nowarn {*yunit_shiftreg_command_bridge:u_shiftreg_cmd|command_issued_q* *yunit_shiftreg_command_bridge:u_shiftreg_cmd|ack_pending_q* *yunit_shiftreg_command_bridge:u_shiftreg_cmd|core_ack_q*}]
set shiftreg_unexpected_boundary [remove_from_collection $shiftreg_all_boundary $shiftreg_expected_boundary]
set srt_fill_pair [get_registers -nowarn {*tms34010_core:u_core|srt_fill_pair_q[*]}]
set srt_fill_all_pair [get_registers -nowarn {*tms34010_core:u_core|srt_fill_pair_q*}]
set srt_fill_unexpected_pair [remove_from_collection $srt_fill_all_pair $srt_fill_pair]
# R3's preserved 1+32-bit request/address snapshot is rejected.  Its presence
# would prove that a stale generated netlist or the failed recurrence-fed
# topology reached fit instead of the seven-bit exact sequencer.
set srt_fill_legacy_snapshot [get_registers -nowarn {*tms34010_core:u_core|srt_fill_req_q* *tms34010_core:u_core|srt_fill_addr_q*}]
set srt_fill_generic_recurrence [get_registers -nowarn {*tms34010_core:u_core|fill_addr_q* *tms34010_core:u_core|fill_row_base_q* *tms34010_core:u_core|fill_substep_q*}]
set fitted_srt_fill [expr {[get_collection_size $srt_fill_all_pair] > 0}]
if {$fitted_srt_fill != $srt_fill_build} {
  puts "SDC_AUDIT ERROR SRT-FILL macro/topology mismatch: macro=$srt_fill_build fitted=$fitted_srt_fill"
  incr failures
}
optional_collection decode_retimed_registers $decode_retimed
require_collection instruction_launch_registers $instruction_launch
require_collection decode_snapshot_registers $decode_snapshot
require_collection cpu_regfile_registers $cpu_regfile
require_exact_register_leaves mmfm_mask_state \
  $mmfm_mask_state $mmfm_mask_state_expected
require_exact_register_leaves mmfm_issue_stage \
  $mmfm_issue_stage $mmfm_issue_stage_expected
require_exact_register_leaves mmfm_commit_stage \
  $mmfm_commit_stage $mmfm_commit_stage_expected
# Both sides of MMFM's new boundary are deliberately ordinary full-rate paths.
# These 1/1 checks fail if the broad CPU-CE exception ever captures the commit
# bank again, or if synthesis bypasses/collapses the issue/commit split.
require_setup_multicycle mmfm_issue_active_to_commit_target \
  $mmfm_issue_active $mmfm_commit_target 1 1
require_setup_multicycle mmfm_issue_target_to_commit_target \
  $mmfm_issue_target $mmfm_commit_target 1 1
# MMFM is a fixed 32-bit ordinary-memory transfer.  The core's 16-bit on-chip
# I/O read mux must never enter the full-rate commit-data bank.
require_no_setup_path mmfm_io_to_commit_data \
  $io_physical_registers $mmfm_commit_data
# Normal stack reads arrive through the registered memory-CDC response bank.
# Those paths are real and must remain ordinary 1/1.  The live instruction
# decode must have no path to the commit-data bank; r30's decoded.iclass path
# through mem_rdata_eff was a real structural recurrence and missed by ~10 ns.
require_collection mmfm_memcdc_rdata $mmfm_memcdc_rdata
require_collection mmfm_memcdc_ack $mmfm_memcdc_ack
require_setup_multicycle mmfm_memcdc_rdata_to_commit_data \
  $mmfm_memcdc_rdata $mmfm_commit_data 1 1
require_setup_multicycle mmfm_memcdc_ack_to_commit_target \
  $mmfm_memcdc_ack $mmfm_commit_target 1 1
require_no_setup_path mmfm_decode_to_commit_data \
  $decode_snapshot $mmfm_commit_data
# The old mask-priority cone, unlike the legal response mux, must end at the
# CPU-domain one-hot issue bank and never bypass it into the full-rate commit.
require_no_setup_path mmfm_mask_to_commit_stage \
  $mmfm_mask_state $mmfm_commit_stage
require_setup_multicycle mmfm_commit_data_to_regfile \
  $mmfm_commit_data $cpu_regfile 1 1
require_setup_multicycle mmfm_commit_target_to_regfile \
  $mmfm_commit_target $cpu_regfile 1 1
for {set lane 0} {$lane < 32} {incr lane} {
  set source [get_registers -nowarn [format {*tms34010_core:u_core|mmfm_commit_data_q[%d]*} $lane]]
  set response_source [get_registers -nowarn [format {*u_memcdc|c_rdata[%d]*} $lane]]
  require_collection [format {mmfm_commit_data_lane_%d} $lane] $source
  require_collection [format {mmfm_memcdc_rdata_lane_%d} $lane] $response_source
  require_setup_multicycle [format {mmfm_memcdc_rdata_lane_%d_to_commit_data} $lane] \
    $response_source $source 1 1
  require_setup_multicycle [format {mmfm_commit_data_lane_%d_to_regfile} $lane] \
    $source $cpu_regfile 1 1
}
for {set lane 0} {$lane < 31} {incr lane} {
  set issue_source [get_registers -nowarn [format {*tms34010_core:u_core|mmfm_issue_target_q[%d]*} $lane]]
  set commit_source [get_registers -nowarn [format {*tms34010_core:u_core|mmfm_commit_target_q[%d]*} $lane]]
  require_collection [format {mmfm_issue_target_lane_%d} $lane] $issue_source
  require_collection [format {mmfm_commit_target_lane_%d} $lane] $commit_source
  require_setup_multicycle [format {mmfm_issue_target_lane_%d_to_commit_target} $lane] \
    $issue_source $commit_source 1 1
  require_setup_multicycle [format {mmfm_commit_target_lane_%d_to_regfile} $lane] \
    $commit_source $cpu_regfile 1 1
}
# The gfx cycle counter's datapath bank (dx/dst_addr/bpp_shift/op_timing -> acc)
# exists only to produce the per-instruction cycle budget that the FAMILY top's
# tms34010_cycle_scheduler consumes.  The recovery top is the fe7 /4-clock-enable
# design with no scheduler, so `cycles` is unread and the fitter legitimately
# sweeps the whole datapath (measured on the 09ec862 recovery fit: only the
# state/rows/done control registers survive).  Requiring a multicycle exception
# on registers that do not exist constrains nothing -- it was a family-model
# assumption, and it failed the first real recovery fit whose every actual
# timing path was green.  Family builds still REQUIRE both banks below.
if {$smash_recovery} {
  optional_collection gfx_snapshot_registers $gfx_snapshot
  optional_collection gfx_accumulator_registers $gfx_accumulator
} else {
  require_collection gfx_snapshot_registers $gfx_snapshot
  require_collection gfx_accumulator_registers $gfx_accumulator
}
require_collection memcdc_cpu_side $memcdc_cpu

if {$family_core} {
  require_collection_min_count io_boundary_wr_idx $io_boundary_wr_idx 5
  require_collection_min_count io_boundary_wr_idx_hi $io_boundary_wr_idx_hi 5
  require_collection_min_count io_boundary_wr_span2 $io_boundary_wr_span2 1
  require_collection_min_count io_boundary_wr_low_mask $io_boundary_wr_low_mask 16
  require_collection_min_count io_boundary_wr_low_data $io_boundary_wr_low_data 16
  require_collection io_physical_registers $io_physical_registers
  # Check each launch bank separately.  A combined worst-path query could hide
  # an accidentally relaxed subset behind a different bank's ordinary path.
  require_setup_multicycle io_boundary_wr_idx_to_physical_io \
    $io_boundary_wr_idx $io_physical_registers 1 1
  require_setup_multicycle io_boundary_wr_idx_hi_to_physical_io \
    $io_boundary_wr_idx_hi $io_physical_registers 1 1
  require_setup_multicycle io_boundary_wr_span2_to_physical_io \
    $io_boundary_wr_span2 $io_physical_registers 1 1
  require_setup_multicycle io_boundary_wr_low_mask_to_physical_io \
    $io_boundary_wr_low_mask $io_physical_registers 1 1
  require_setup_multicycle io_boundary_wr_low_data_to_physical_io \
    $io_boundary_wr_low_data $io_physical_registers 1 1
} else {
  optional_collection io_boundary_field_meta $io_boundary_field_meta
}

if {$smash_recovery} {
  set recovery_dma_irq [get_registers -nowarn {*u_sys|u_dma|blit_irq*}]
  require_collection recovery_div4_ce $recovery_ce
  require_collection recovery_dma_irq_source $recovery_dma_irq
  require_setup_multicycle cpu_ce_worst_paths $cpu_domain $cpu_domain 1 4
  require_setup_multicycle instruction_to_decode_snapshot $instruction_launch $decode_snapshot 1 4
  require_setup_multicycle decode_snapshot_to_regfile $decode_snapshot $cpu_regfile 1 4
  # Swept-away gfx banks are expected here (see above); if a future recovery fit
  # ever retains them, they sit inside the broad cpu_ce /4 relaxation whose
  # worst paths are checked by cpu_ce_worst_paths, so run the focused checks
  # only when the collections are non-empty rather than failing on absence.
  if {[get_collection_size $gfx_snapshot] > 0} {
    require_setup_multicycle decode_snapshot_to_gfx_snapshot $decode_snapshot $gfx_snapshot 1 4
    if {[get_collection_size $gfx_accumulator] > 0} {
      require_setup_multicycle gfx_snapshot_to_accumulator $gfx_snapshot $gfx_accumulator 1 4
    }
  }
  require_setup_multicycle recovery_dma_irq_to_cpu $recovery_dma_irq $cpu_domain 1 4
  optional_collection scheduler_retire_capture $scheduler_retire_capture
  if {$srt_fill_build} {
    require_collection shiftreg_command_capture $shiftreg_command_capture
    require_collection_exact_count shiftreg_command_pair_addr $shiftreg_command_pair_addr 7
    require_collection_exact_count shiftreg_cpu_response $shiftreg_cpu_response 1
    require_collection_exact_count shiftreg_transaction_state $shiftreg_transaction_state 2
    require_empty_collection shiftreg_unexpected_boundary $shiftreg_unexpected_boundary
    require_collection_exact_count srt_fill_pair $srt_fill_pair 7
    require_empty_collection srt_fill_unexpected_pair $srt_fill_unexpected_pair
    require_empty_collection srt_fill_legacy_snapshot $srt_fill_legacy_snapshot
    require_collection srt_fill_generic_recurrence $srt_fill_generic_recurrence
    require_no_setup_path srt_fill_recurrence_to_pair $srt_fill_generic_recurrence $srt_fill_pair
    for {set lane 0} {$lane < 7} {incr lane} {
      set source [get_registers -nowarn [format {*tms34010_core:u_core|srt_fill_pair_q[%d]} $lane]]
      set command_bit [expr {$lane + 13}]
      set target [get_registers -nowarn [format {*yunit_shiftreg_command_bridge:u_shiftreg_cmd|cmd_bit_addr_q[%d]} $command_bit]]
      require_collection_exact_count [format {srt_fill_pair_lane_%d} $lane] $source 1
      require_collection_exact_count [format {shiftreg_command_pair_bit_%d} $command_bit] $target 1
      require_setup_multicycle [format {srt_fill_pair_lane_%d_to_command_bit_%d} $lane $command_bit] $source $target 1 3
    }
    require_setup_multicycle shiftreg_command_capture $gated_cpu $shiftreg_command_capture 1 3
    require_setup_multicycle shiftreg_response_to_cpu $shiftreg_cpu_response $cpu_domain 1 4
    require_setup_multicycle shiftreg_pending_to_response $shiftreg_ack_pending $shiftreg_cpu_response 1 1
  } else {
    optional_collection shiftreg_command_capture $shiftreg_command_capture
    optional_collection shiftreg_cpu_response $shiftreg_cpu_response
    require_empty_collection srt_fill_pair_feature_off $srt_fill_all_pair
    require_empty_collection srt_fill_legacy_snapshot $srt_fill_legacy_snapshot
  }
} else {
  require_collection scheduler_retire_capture $scheduler_retire_capture
  require_collection scheduler_intenb_shadow $scheduler_intenb_shadow
  require_collection scheduler_intpend_shadow $scheduler_intpend_shadow
  require_collection scheduler_hstctlh_shadow $scheduler_hstctlh_shadow
  require_collection scheduler_interrupt_shadow $scheduler_interrupt_shadow
  require_collection scheduler_start_elapsed_cycles $scheduler_start_elapsed_cycles
  require_collection scheduler_start_elapsed_fraction $scheduler_start_elapsed_fraction
  require_collection scheduler_start_active $scheduler_start_active
  require_collection scheduler_start_waiting $scheduler_start_waiting
  if {$srt_fill_build} {
    require_collection shiftreg_command_capture $shiftreg_command_capture
    require_collection_exact_count shiftreg_command_pair_addr $shiftreg_command_pair_addr 7
    require_collection_exact_count shiftreg_cpu_response $shiftreg_cpu_response 1
    require_collection_exact_count shiftreg_transaction_state $shiftreg_transaction_state 2
    require_empty_collection shiftreg_unexpected_boundary $shiftreg_unexpected_boundary
    require_collection_exact_count srt_fill_pair $srt_fill_pair 7
    require_empty_collection srt_fill_unexpected_pair $srt_fill_unexpected_pair
    require_empty_collection srt_fill_legacy_snapshot $srt_fill_legacy_snapshot
    require_collection srt_fill_generic_recurrence $srt_fill_generic_recurrence
    require_no_setup_path srt_fill_recurrence_to_pair $srt_fill_generic_recurrence $srt_fill_pair
  } else {
    optional_collection shiftreg_command_capture $shiftreg_command_capture
    optional_collection shiftreg_cpu_response $shiftreg_cpu_response
    require_empty_collection srt_fill_pair_feature_off $srt_fill_all_pair
    require_empty_collection srt_fill_legacy_snapshot $srt_fill_legacy_snapshot
  }
  require_setup_multicycle cpu_ce_worst_paths $cpu_domain $cpu_domain 1 3
  require_setup_multicycle instruction_to_decode_snapshot $instruction_launch $decode_snapshot 1 3
  require_setup_multicycle decode_snapshot_to_regfile $decode_snapshot $cpu_regfile 1 3
  require_setup_multicycle decode_snapshot_to_gfx_snapshot $decode_snapshot $gfx_snapshot 1 3
  require_setup_multicycle gfx_snapshot_to_accumulator $gfx_snapshot $gfx_accumulator 1 3
  require_setup_multicycle scheduler_retire_capture $gated_cpu $scheduler_retire_capture 1 3
  require_setup_multicycle intenb_shadow_to_scheduler_elapsed_cycles $scheduler_intenb_shadow $scheduler_start_elapsed_cycles 1 3
  require_setup_multicycle intenb_shadow_to_scheduler_elapsed_fraction $scheduler_intenb_shadow $scheduler_start_elapsed_fraction 1 3
  require_setup_multicycle intenb_shadow_to_scheduler_active $scheduler_intenb_shadow $scheduler_start_active 1 3
  require_setup_multicycle intenb_shadow_to_scheduler_waiting $scheduler_intenb_shadow $scheduler_start_waiting 1 3
  require_setup_multicycle intpend_shadow_to_scheduler_elapsed_cycles $scheduler_intpend_shadow $scheduler_start_elapsed_cycles 1 3
  require_setup_multicycle intpend_shadow_to_scheduler_elapsed_fraction $scheduler_intpend_shadow $scheduler_start_elapsed_fraction 1 3
  require_setup_multicycle intpend_shadow_to_scheduler_active $scheduler_intpend_shadow $scheduler_start_active 1 3
  require_setup_multicycle intpend_shadow_to_scheduler_waiting $scheduler_intpend_shadow $scheduler_start_waiting 1 3
  require_setup_multicycle hstctlh_shadow_to_scheduler_elapsed_cycles $scheduler_hstctlh_shadow $scheduler_start_elapsed_cycles 1 3
  require_setup_multicycle hstctlh_shadow_to_scheduler_elapsed_fraction $scheduler_hstctlh_shadow $scheduler_start_elapsed_fraction 1 3
  require_setup_multicycle hstctlh_shadow_to_scheduler_active $scheduler_hstctlh_shadow $scheduler_start_active 1 3
  require_setup_multicycle hstctlh_shadow_to_scheduler_waiting $scheduler_hstctlh_shadow $scheduler_start_waiting 1 3
  if {$srt_fill_build} {
    for {set lane 0} {$lane < 7} {incr lane} {
      set source [get_registers -nowarn [format {*tms34010_core:u_core|srt_fill_pair_q[%d]} $lane]]
      set command_bit [expr {$lane + 13}]
      set target [get_registers -nowarn [format {*yunit_shiftreg_command_bridge:u_shiftreg_cmd|cmd_bit_addr_q[%d]} $command_bit]]
      require_collection_exact_count [format {srt_fill_pair_lane_%d} $lane] $source 1
      require_collection_exact_count [format {shiftreg_command_pair_bit_%d} $command_bit] $target 1
      require_setup_multicycle [format {srt_fill_pair_lane_%d_to_command_bit_%d} $lane $command_bit] $source $target 1 3
    }
    require_setup_multicycle shiftreg_command_capture $gated_cpu $shiftreg_command_capture 1 3
    require_setup_multicycle shiftreg_response_to_cpu $shiftreg_cpu_response $cpu_domain 1 3
    require_setup_multicycle shiftreg_pending_to_response $shiftreg_ack_pending $shiftreg_cpu_response 1 1
  }
  require_collection game_id [get_registers {*game_id[*]}]
  require_collection dma_irq_source [get_registers {*u_dma_logical_timer|blit_irq*}]
  require_collection dma_timer_clip_precompute [get_registers {*u_sys|timer_nf_x_s1_q* *u_sys|timer_nf_width_s1_q* *u_sys|timer_flip_x_s1_q* *u_sys|timer_flip_width_s1_q* *u_sys|timer_y_s1_q* *u_sys|timer_height_s1_q* *u_sys|timer_nf_clipped_width_q* *u_sys|timer_nf_clipped_height_q* *u_sys|timer_flip_clipped_width_q* *u_sys|timer_flip_clipped_height_q*}]
  require_collection dma_timer_clip_snapshot [get_registers {*u_sys|timer_clipped_width_q* *u_sys|timer_clipped_height_q*}]
  require_collection dma_timer_pixels [get_registers {*u_dma_logical_timer|pixels_q*}]
}

require_collection field_engine_source [get_registers {*u_sys|u_mem|a_q[*]}]
require_collection field_engine_targets [get_registers {*u_sys|u_mem|ram_rtl_0* *u_sys|u_mem|pal_rtl_0* *u_sys|u_mem|nvram_rtl_0*}]
# ioctl_index quasi-static exception (rtl/sdram.sdc). COVERAGE GATE, not just presence:
# if the exception ever stops matching the fitted path, the multicycle check reports
# end=1 and FAILS, instead of the -0.175 ns regression reappearing silently in a corner.
# The seam exists in every revision -- Arcade-SmashTV.sv:726 is the single core-top
# instantiation and it always wires nvram_ext_* from the index-4 bridge.
require_collection ioctl_index_source [get_registers {*hps_io:hps_io|ioctl_index[*]}]
require_collection ioctl_index_nvram_targets [get_registers {*u_sys|u_mem|nvram_rtl_0*}]
require_setup_multicycle ioctl_index_to_nvram \
  [get_registers {*hps_io:hps_io|ioctl_index[*]}] \
  [get_registers {*u_sys|u_mem|nvram_rtl_0*}] 1 2

require_collection dma_launch_source [get_registers {*u_sys|u_dma|launchf[*][*]}]
require_collection dma_launch_targets [get_registers {*u_sys|u_dma|state* *u_sys|u_dma|width_c[*] *u_sys|u_dma|height_c[*] *u_sys|u_dma|xpos_c[*] *u_sys|u_dma|ypos_c[*] *u_sys|u_dma|rowbytes_c[*] *u_sys|u_dma|cur_off[*]}]

require_collection core_clock [get_clocks {emu|pll|pll_inst|altera_pll_i|general[0].gpll~PLL_OUTPUT_COUNTER|divclk}]
require_collection sdram_clock [get_clocks {SDRAM_CLK}]
require_collection sound_clock [get_clocks {emu|pll|pll_inst|altera_pll_i|general[2].gpll~PLL_OUTPUT_COUNTER|divclk}]
require_collection hdmi_internal_clock [get_clocks {*pll_hdmi*output_counter|divclk}]
require_collection hdmi_video_outputs [get_ports {HDMI_TX_D[*] HDMI_TX_DE HDMI_TX_HS HDMI_TX_VS}]

diagnostic_collection diagnostic_registers $cpu_top_debug $derail_rows_shown
diagnostic_collection diag_overlay [get_registers -nowarn {*smashtv_diag2_overlay:u_diag2|*}] $diag_build

# ---------------------------------------------------------------------------
# WORST-PATH DUMP.  Unconditional, and deliberately AFTER every gate above.
#
# The stock Quartus .sta.rpt carries only per-clock summaries: when family2's
# first real timing failure landed (WNS -0.215 on the slow corners) the report
# named the clock and nothing else, and the audit's own multicycle collections
# all showed >= +9.0 ns -- i.e. the failing endpoints were outside every
# collection anyone had thought to sample.  Diagnosing that needed a second
# trip to the shared box for a 60-second report_timing that could have been
# free.  This block makes every future run carry its own worst-path evidence,
# pass or fail: the next timing failure diagnoses itself.
#
# Cost is a few seconds; the paths are printed with full node names so the
# interconnect-vs-cell split can be read directly out of the build log.
proc dump_worst_paths {label npaths} {
  set paths [get_timing_paths -setup -npaths $npaths -nworst 1 -detail path_only]
  set row 0
  foreach_in_collection path $paths {
    incr row
    set slack [get_path_info -slack $path]
    set from  [get_node_info [get_path_info -from $path] -name]
    set to    [get_node_info [get_path_info -to   $path] -name]
    set arr   [get_path_info -arrival_time $path]
    puts "SDC_AUDIT worst_path $label row=$row slack=$slack arrival=$arr"
    puts "SDC_AUDIT worst_path $label row=$row from={$from}"
    puts "SDC_AUDIT worst_path $label row=$row to={$to}"
  }
  puts "SDC_AUDIT worst_path_result $label rows=$row"
}
dump_worst_paths design_wide 20

if {$failures != 0} {
  puts "SDC_AUDIT RESULT: FAIL failures=$failures"
  project_close
  qexit -error
}

puts "SDC_AUDIT RESULT: PASS"
project_close
