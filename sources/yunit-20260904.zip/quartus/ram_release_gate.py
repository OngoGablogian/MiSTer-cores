#!/usr/bin/env python3
"""Fail closed on fitted Y-unit RAM resources and RAM semantics.

This gate consumes Quartus 17 map/fit evidence after a successful fit and
before TimeQuest or the assembler.  It deliberately judges the fitted
implementation rather than source attributes:

* the whole device may use at most 512 of 553 M10Ks;
* the vendored ``crt_adjust.mem`` line buffer must be one 1024x24
  (24,576-bit) ALTSYNCRAM using exactly three M10Ks and zero MLABs;
* the ``crt_adjust`` hierarchy must attribute the same three M10Ks and no
  ALMs used as memory;
* a CRT RAM that fell back to registers is rejected; and
* game-side undefined mixed-port RAM behavior is rejected unless Quartus
  explicitly inserted pass-through logic and the map report contains its
  fitted bypass nodes.

Missing, truncated, contradictory, or unparseable evidence is a failure.
The tool never invokes Quartus or TimeQuest.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import sys
from typing import Any, Iterable


EXPECTED_DEVICE_M10KS = 553
MAX_RELEASE_M10KS = 512
EXPECTED_CRT_BITS = 24_576
EXPECTED_CRT_DEPTH = 1_024
EXPECTED_CRT_WIDTH = 24
EXPECTED_CRT_M10KS = 3
EXPECTED_CRT_MLABS = 0

MIN_MAP_LOG_BYTES = 512
MIN_REPORT_BYTES = 2_048
FAMILY_HIERARCHY_TOKEN = "|yunit_top:yunit_top|"
RECOVERY_HIERARCHY_TOKEN = "|yunit_top_smash_firefix:yunit_top|"
FAMILY2_HIERARCHY_TOKEN = "|yunit_top_family2:yunit_top|"
GAME_HIERARCHY_TOKENS = (
    FAMILY_HIERARCHY_TOKEN,
    RECOVERY_HIERARCHY_TOKEN,
    FAMILY2_HIERARCHY_TOKEN,
)
CRT_FULL_HIERARCHY = (
    "|sys_top|emu:emu|yunit_crt_adjust:u_yunit_crt_adjust|"
    "crt_adjust:u_crt_adjust"
)
DMA_DESCRIPTOR_FIFO_NODE = (
    "emu:emu|yunit_top:yunit_top|yunit_memsys:u_sys|"
    "yunit_dma_descriptor_fifo:u_dma_desc_fifo|mem_rtl_0"
)
# The descriptor FIFO is release-critical even when its fitted RDW columns say
# "New data": Quartus implements that behavior with the 276020 pass-through
# network.  The expected register count is derived below from the fitted RAM
# geometry, not pinned to a stale report.
REQUIRED_PASS_THROUGH_NODES = frozenset({DMA_DESCRIPTOR_FIFO_NODE})
ACCEPTED_RDW_MODES = frozenset({"new data", "old data", "don't care"})
RECOVERY_MACRO = "YUNIT_SMASH_RECOVERY"
RECOVERY_OUTNAME = "Arcade-SmashTV-YUnit-Recovery"
FAMILY2_MACRO = "YUNIT_FAMILY2"
FAMILY2_OUTNAME = "Arcade-SmashTV-YUnit-Family2"
# The SF/Saurian display-column fix: family2 + the FULL display sequencer, NO
# ADPCM board (-DYUNIT_DISPLAY_SEQ). Dedicated stem so it can never install over
# the plain family2 release core (the stale-install ban).
FAMILY2SEQ_OUTNAME = "Arcade-SmashTV-YUnit-Family2Seq"
FAMILY_TOP_INSTANCE = "emu:emu|yunit_top:yunit_top"
RECOVERY_TOP_INSTANCE = (
    "emu:emu|yunit_top_smash_firefix:yunit_top"
)
RECOVERY_MEM_INSTANCE = (
    f"{RECOVERY_TOP_INSTANCE}|yunit_memsys_smash_firefix:u_sys|"
    "yunit_mem_smash_firefix:u_mem"
)
FAMILY2_TOP_INSTANCE = "emu:emu|yunit_top_family2:yunit_top"
FAMILY2_MEM_INSTANCE = (
    f"{FAMILY2_TOP_INSTANCE}|yunit_memsys_family2:u_sys|"
    "yunit_mem_family2:u_mem"
)
FAMILY_TOP_PARAMETERS = {
    "GFXW_BASE": 0x000000,
    "ROMW_BASE": 0x400000,
    "VRAMW_BASE": 0x480000,
    "GFX_BYTES": 0x800000,
    "SCRATCH_WBASE": 0x500000,
    "SOUNDW_BASE": 0x800000,
    "ROM_WORDS": 0x80000,
    "ROM_WORD_OFFSET": 0x00000,
}
RECOVERY_TOP_PARAMETERS = {
    "H_ACT": 410,
    "H_FP": 6,
    "H_SYNC": 40,
    "H_BP": 50,
    "V_ACT": 256,
    "V_FP": 13,
    "V_SYNC": 8,
    "V_BP": 12,
    "GFXW_BASE": 0x000000,
    "ROMW_BASE": 0x0C0000,
    "VRAMW_BASE": 0x0E0000,
    "GFX_BYTES": 0x180000,
    "SCRATCH_WBASE": 0x120000,
    "SOUNDW_BASE": 0x120000,
}
RECOVERY_MEM_PARAMETERS = {
    "ROM_WORDS": 0x20000,
    "RAM_WORDS": 0x10000,
    "VRAM_WORDS": 0x40000,
    "PAL_WORDS": 0x2000,
    "CMOS_WORDS": 0x4000,
    "GFX_PIXELS": 0x180000,
}
# family2 (PLAN-family2-rebase.md): the rebased /4-CE hierarchy carrying the
# FAMILY physical map.  Its raster pulse partition follows the native Y-unit
# timing used by the production top and the MAME-grounded raster gates.  The
# totals match recovery (506 x 289), but the sync/back-porch split deliberately
# does not.  The map and window parameters must likewise be exactly the family
# constants -- a recovery value in any of them recreates the section-3
# mixed-layout failure.
# family2's gfx region is SCOPE-SIZED, not a fixed family constant: 0x400000
# covers the largest in-scope CVSD unpacked image (Super High Impact, 0x80000
# plane-words x 8), and P2 raises it to 0x800000 with the ADPCM trio. Everything
# positional is DERIVED from it so ONE number moves the whole map and this gate
# cannot drift out of step with the wrapper -- which is exactly what happened
# when the wrapper was narrowed and these literals were left behind, costing a
# build slot on a mismatch that was purely in the gate's model.
FAMILY2_GFX_BYTES = 0x400000
FAMILY2_GFXW_BASE = 0x000000
FAMILY2_ROM_WORDS = 0x80000
FAMILY2_ROMW_BASE = FAMILY2_GFXW_BASE + FAMILY2_GFX_BYTES // 2
FAMILY2_VRAMW_BASE = FAMILY2_ROMW_BASE + FAMILY2_ROM_WORDS
FAMILY2_TOP_PARAMETERS = {
    "H_ACT": 410,
    "H_FP": 6,
    "H_SYNC": 42,
    "H_BP": 48,
    "V_ACT": 256,
    "V_FP": 13,
    "V_SYNC": 3,
    "V_BP": 17,
    "GFXW_BASE": FAMILY2_GFXW_BASE,
    "ROMW_BASE": FAMILY2_ROMW_BASE,
    "VRAMW_BASE": FAMILY2_VRAMW_BASE,
    "GFX_BYTES": FAMILY2_GFX_BYTES,
    "SCRATCH_WBASE": 0x500000,
    "SOUNDW_BASE": 0x800000,
    "ROM_WORDS": FAMILY2_ROM_WORDS,
    "ROM_WORD_OFFSET": 0x00000,
}
FAMILY2_MEM_PARAMETERS = {
    "ROM_WORDS": FAMILY2_ROM_WORDS,
    "ROM_WORD_OFFSET": 0x00000,
    "RAM_WORDS": 0x10000,
    "VRAM_WORDS": 0x40000,
    "PAL_WORDS": 0x2000,
    "CMOS_WORDS": 0x4000,
    # The unpacked image occupies exactly the gfx region the arbiter reserves.
    "GFX_PIXELS": FAMILY2_GFX_BYTES,
}
# YUNIT_FULL: the single all-title image. Same rebased family2 hierarchy and
# therefore the SAME instance paths, with the full 8 MB family reservation
# required by MK/T2 and both sound boards selected at runtime by game_id.
#
# Derived from ONE constant for the same reason family2's is: when the wrapper
# was narrowed and this gate kept stale literals, it cost a build slot on a
# mismatch that existed only in the gate's model.
FULL_MACRO = "YUNIT_FULL"
# Named escape hatch back to BRAM-resident CVSD sound (see the residence
# check above and sim/postconv/check_cvsd_sound_residence.py).
CVSD_BRAM_SOUND_DEFINE = "-DYUNIT_CVSD_BRAM_SOUND"
SMASH_BRAM_SOUND_DEFINE = "-DYUNIT_SMASH_BRAM_SOUND"
FULL_OUTNAME = "Arcade-SmashTV-YUnit-Full"
# Diagnostic flavours (the F4 cabinet service instrument) are NOT releases. They carry one
# extra macro token and are REQUIRED to use a non-release stem, so a counter image can never
# be installed as the release. This is strictly additive: without DIAG_SERVICE every check
# below behaves exactly as before, and the diagnostic path FORBIDS what the release path
# demands rather than relaxing it.
# Audio-split ADPCM sibling: MK / T2 / Total Carnage, no CVSD board at all. Shares the FULL
# 8 MB map and the family2 top, so it is told apart by macro + outname exactly as FULL is.
# Its CVSD residence expectation is the strict one (zero smashtv_snd_rom M10Ks) and it may
# NEVER carry the BRAM-sound escape hatch, because it has no CVSD board to put in BRAM.
ADPCM_MACRO = "YUNIT_ADPCM"
ADPCM_OUTNAME = "Arcade-SmashTV-YUnit-ADPCM"
DIAG_SERVICE_MACRO = "DIAG_SERVICE"
# P0020 download audit: DIAG_BOOT selects the boot overlay, DIAG_DLAUDIT selects
# its row set. Unlike DIAG_SERVICE this instrument is emu-only -- it adds no core
# counters and no RAM -- so it is recognised here purely so a diagnostic build is
# not mistaken for a malformed release. The stem prohibition below still applies.
DIAG_EMU_MACROS = ("DIAG_BOOT", "DIAG_DLAUDIT", "DIAG_DISPBASE")
DIAG_EMU_OUTNAME_PREFIX = "Arcade-SmashTV-YUnit-DLAUDIT"
DIAG_SERVICE_OUTNAME_PREFIX = "Arcade-SmashTV-YUnit-SvcDiag"
FULL_GFX_BYTES = 0x800000
FULL_GFXW_BASE = 0x000000
FULL_ROM_WORDS = 0x80000
FULL_ROMW_BASE = FULL_GFXW_BASE + FULL_GFX_BYTES // 2
FULL_VRAMW_BASE = FULL_ROMW_BASE + FULL_ROM_WORDS
FULL_TOP_PARAMETERS = dict(
    FAMILY2_TOP_PARAMETERS,
    GFXW_BASE=FULL_GFXW_BASE,
    ROMW_BASE=FULL_ROMW_BASE,
    VRAMW_BASE=FULL_VRAMW_BASE,
    GFX_BYTES=FULL_GFX_BYTES,
    ROM_WORDS=FULL_ROM_WORDS,
)
FULL_MEM_PARAMETERS = dict(
    FAMILY2_MEM_PARAMETERS,
    ROM_WORDS=FULL_ROM_WORDS,
    GFX_PIXELS=FULL_GFX_BYTES,
)

PARAMETER_TABLE_HEADER_RE = re.compile(
    r"^\s*;\s*Parameter Settings for User Entity Instance:\s*"
    r"(.+?)\s*;\s*$"
)


def is_game_hierarchy(name: str) -> bool:
    return any(token in name for token in GAME_HIERARCHY_TOKENS)

TOTAL_RAM_RE = re.compile(
    r"^;\s*Total RAM Blocks\s*;\s*([\d,]+)\s*/\s*([\d,]+)"
    r"\s*\(\s*\d+\s*%\s*\)\s*;",
    re.MULTILINE,
)
M10K_SUMMARY_RE = re.compile(
    r"^;\s*M10K blocks\s*;\s*([\d,]+)\s*/\s*([\d,]+)\s*;",
    re.MULTILINE,
)
PASS_THROUGH_RE = re.compile(
    r'Warning \(276020\): Inferred RAM node "([^"\r\n]+)" from synchronous '
    r"design logic\.\s+Pass-through logic has been added to match the "
    r"read-during-write behavior of the original design\."
)
UNDEFINED_DUAL_CLOCK_RE = re.compile(
    r'Warning \(276027\): Inferred dual-clock RAM node "([^"\r\n]+)"'
)
UNINFERRED_RAM_RE = re.compile(
    r'Info \(276\d+\): RAM logic "([^"\r\n]+)" is uninferred'
)
BYPASS_ROW_RE = re.compile(
    r"^;\s*(.+?)_bypass\[(\d+)\]\s*;\s*(.+?)\s*;\s*$",
    re.MULTILINE,
)
FITTER_SUCCESS_RE = re.compile(
    r"^Info: Quartus Prime Fitter was successful\. 0 errors,",
    re.MULTILINE,
)
MAP_REPORT_SUCCESS_RE = re.compile(
    r"^Info: Quartus Prime Analysis & Synthesis was successful\. 0 errors,",
    re.MULTILINE,
)
CRT_ENTITY_RE = re.compile(r"(?:^|\|)crt_adjust:[^|]+(?:\||$)")
CRT_MEM_PRIMITIVE_RE = re.compile(
    r"(?:^|\|)crt_adjust:[^|]+(?:\|[^|]+)*"
    r"\|altsyncram:mem_rtl_0\|[^|]+\|ALTSYNCRAM$"
)
CRT_REGISTER_FALLBACK_RE = re.compile(
    r"(?:^|[|;])crt_adjust:[^|\r\n;]+\|[^\r\n;]*"
    r"\bmem(?:_rtl_\d+)?\[\d+\]",
    re.IGNORECASE,
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def atomic_write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(
        json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    os.replace(temp, path)


def split_quartus_row(line: str) -> list[str]:
    stripped = line.strip()
    if not stripped.startswith(";"):
        return []
    return [field.strip() for field in stripped.strip(";").split(";")]


def parse_table(
    text: str,
    *,
    required_columns: frozenset[str],
    table_name: str,
    required_terminator: str | None = None,
) -> tuple[list[dict[str, str]], list[str]]:
    lines = text.splitlines()
    matches: list[tuple[int, list[str]]] = []
    for index, line in enumerate(lines):
        fields = split_quartus_row(line)
        if required_columns.issubset(fields):
            matches.append((index, fields))

    errors: list[str] = []
    if len(matches) != 1:
        errors.append(
            f"{table_name} header count is {len(matches)}, expected exactly 1"
        )
        return [], errors

    start, header = matches[0]
    rows: list[dict[str, str]] = []
    terminator_seen = False
    for line in lines[start + 1 :]:
        fields = split_quartus_row(line)
        if not fields:
            continue
        if len(fields) == 1 and fields[0].startswith("Fitter "):
            if required_terminator is not None:
                if fields[0] == required_terminator:
                    terminator_seen = True
                else:
                    errors.append(
                        f"{table_name} ended at {fields[0]!r}, expected "
                        f"{required_terminator!r}"
                    )
            break
        if len(fields) != len(header):
            continue
        rows.append(dict(zip(header, fields)))

    if not rows:
        errors.append(f"{table_name} contains no parseable rows")
    if required_terminator is not None and not terminator_seen:
        errors.append(
            f"{table_name} has no parsed closing boundary "
            f"{required_terminator!r}; report may be truncated"
        )
    return rows, errors


def parse_int(value: str, label: str, errors: list[str]) -> int | None:
    cleaned = value.replace(",", "").strip()
    if not re.fullmatch(r"\d+", cleaned):
        errors.append(f"{label} is not an integer: {value!r}")
        return None
    return int(cleaned)


def parse_leading_float(
    value: str, label: str, errors: list[str]
) -> float | None:
    match = re.match(r"\s*([-+]?(?:\d+(?:\.\d*)?|\.\d+))", value)
    if not match:
        errors.append(f"{label} has no numeric value: {value!r}")
        return None
    return float(match.group(1))


def normalize_mode(value: str) -> str:
    return value.replace("\u2019", "'").strip().lower()


def logical_ram_node(name: str) -> str | None:
    match = re.search(r"\|altsyncram:([^|]+)", name)
    if not match:
        return None
    return name[: match.start()] + "|" + match.group(1)


def parse_fit_evidence(fit_text: str) -> dict[str, Any]:
    errors: list[str] = []

    if not fit_text.strip():
        errors.append("fit report is empty")
    if not re.search(
        r"^;\s*Fitter Status\s*;\s*Successful\b", fit_text, re.MULTILINE
    ):
        errors.append("fit report has no successful Fitter Status row")
    fitter_successes = FITTER_SUCCESS_RE.findall(fit_text)
    if len(fitter_successes) != 1:
        errors.append(
            "fit report terminal success marker count is "
            f"{len(fitter_successes)}, expected exactly 1"
        )
    if re.search(r"^Error \(", fit_text, re.MULTILINE):
        errors.append("fit report contains a Quartus error")

    total_matches = TOTAL_RAM_RE.findall(fit_text)
    if len(total_matches) != 1:
        errors.append(
            "Total RAM Blocks summary count is "
            f"{len(total_matches)}, expected exactly 1"
        )
        total_used = None
        total_capacity = None
    else:
        total_used = parse_int(
            total_matches[0][0], "Total RAM Blocks used", errors
        )
        total_capacity = parse_int(
            total_matches[0][1], "Total RAM Blocks capacity", errors
        )

    m10k_matches = M10K_SUMMARY_RE.findall(fit_text)
    if len(m10k_matches) != 1:
        errors.append(
            f"M10K resource summary count is {len(m10k_matches)}, expected exactly 1"
        )
        m10k_used = None
        m10k_capacity = None
    else:
        m10k_used = parse_int(
            m10k_matches[0][0], "M10K summary used", errors
        )
        m10k_capacity = parse_int(
            m10k_matches[0][1], "M10K summary capacity", errors
        )

    if total_capacity is not None and total_capacity != EXPECTED_DEVICE_M10KS:
        errors.append(
            f"device RAM capacity is {total_capacity}, expected "
            f"{EXPECTED_DEVICE_M10KS}"
        )
    if total_used is not None and total_used > MAX_RELEASE_M10KS:
        errors.append(
            f"fitted M10K use is {total_used}/{total_capacity}; release limit "
            f"is {MAX_RELEASE_M10KS}/{EXPECTED_DEVICE_M10KS}"
        )
    if (
        total_used is not None
        and m10k_used is not None
        and (total_used, total_capacity) != (m10k_used, m10k_capacity)
    ):
        errors.append(
            "Total RAM Blocks and M10K summaries disagree: "
            f"{total_used}/{total_capacity} vs {m10k_used}/{m10k_capacity}"
        )

    hierarchy_rows, hierarchy_errors = parse_table(
        fit_text,
        required_columns=frozenset(
            {
                "Compilation Hierarchy Node",
                "ALMs used for memory",
                "Block Memory Bits",
                "M10Ks",
                "Full Hierarchy Name",
                "Entity Name",
            }
        ),
        table_name="Fitter Compilation Hierarchy",
    )
    errors.extend(hierarchy_errors)

    top_rows = [
        row
        for row in hierarchy_rows
        if row.get("Full Hierarchy Name") == "|sys_top"
        and row.get("Entity Name") == "sys_top"
    ]
    if len(top_rows) != 1:
        errors.append(
            f"top-level hierarchy row count is {len(top_rows)}, expected exactly 1"
        )
        hierarchy_total_m10ks = None
    else:
        hierarchy_total_m10ks = parse_int(
            top_rows[0].get("M10Ks", ""),
            "top-level hierarchy M10Ks",
            errors,
        )
        if (
            total_used is not None
            and hierarchy_total_m10ks is not None
            and hierarchy_total_m10ks != total_used
        ):
            errors.append(
                "top-level hierarchy M10Ks disagree with resource summary: "
                f"{hierarchy_total_m10ks} vs {total_used}"
            )

    crt_hierarchy_rows = [
        row
        for row in hierarchy_rows
        if row.get("Entity Name") == "crt_adjust"
        and row.get("Full Hierarchy Name") == CRT_FULL_HIERARCHY
    ]
    crt_hierarchy: dict[str, Any] | None = None
    if len(crt_hierarchy_rows) != 1:
        errors.append(
            "crt_adjust hierarchy row count is "
            f"{len(crt_hierarchy_rows)}, expected exactly 1"
        )
    else:
        row = crt_hierarchy_rows[0]
        crt_hierarchy_m10ks = parse_int(
            row.get("M10Ks", ""), "crt_adjust hierarchy M10Ks", errors
        )
        crt_hierarchy_bits = parse_int(
            row.get("Block Memory Bits", ""),
            "crt_adjust hierarchy block-memory bits",
            errors,
        )
        crt_memory_alms = parse_leading_float(
            row.get("ALMs used for memory", ""),
            "crt_adjust ALMs used for memory",
            errors,
        )
        crt_hierarchy = {
            "full_name": row.get("Full Hierarchy Name"),
            "m10ks": crt_hierarchy_m10ks,
            "block_memory_bits": crt_hierarchy_bits,
            "alms_used_for_memory": crt_memory_alms,
        }
        if crt_hierarchy_m10ks != EXPECTED_CRT_M10KS:
            errors.append(
                f"crt_adjust hierarchy uses {crt_hierarchy_m10ks} M10Ks, "
                f"expected {EXPECTED_CRT_M10KS}"
            )
        if crt_hierarchy_bits != EXPECTED_CRT_BITS:
            errors.append(
                f"crt_adjust hierarchy owns {crt_hierarchy_bits} block-memory "
                f"bits, expected {EXPECTED_CRT_BITS}"
            )
        if crt_memory_alms != 0.0:
            errors.append(
                f"crt_adjust uses {crt_memory_alms} ALMs as memory; "
                "register/logic fallback is forbidden"
            )

    ram_rows, ram_errors = parse_table(
        fit_text,
        required_columns=frozenset(
            {
                "Name",
                "Port A Width",
                "Port B Width",
                "Size",
                "M10K blocks",
                "MLAB cells",
                "Mixed Width RDW Mode",
                "Port A RDW Mode",
                "Port B RDW Mode",
            }
        ),
        table_name="Fitter RAM Summary",
        required_terminator="Fitter DSP Block Usage Summary",
    )
    errors.extend(ram_errors)

    # CVSD sound-ROM residence, judged on the FITTED design.
    #
    # The three 64 KiB smashtv_snd_rom BRAMs measured 192 of 553 device M10Ks
    # -- 35% of all block RAM for 192 KiB of samples. Production streams them
    # from SDRAM instead (family2_download_mapper already writes every sound
    # byte to SOUNDW_BASE), which is what lets one core carry every title.
    #
    # Icarus cannot see inside the VHDL sound board, so the source-level pin in
    # sim/postconv/check_cvsd_sound_residence.py cannot prove the blocks are
    # actually gone. This is that proof: if the BRAMs come back, they show up
    # here as fitted M10Ks and the release fails.
    #
    # The escape hatch is +define+YUNIT_CVSD_BRAM_SOUND, recorded in the
    # manifest's sv2v flavor; a build carrying it is ALLOWED to keep them.
    snd_rom_rows = [
        row for row in ram_rows if "smashtv_snd_rom" in row.get("Name", "")
    ]
    snd_rom_m10ks = 0
    for row in snd_rom_rows:
        snd_rom_m10ks += parse_int(
            row.get("M10K blocks", ""), "smashtv_snd_rom M10K blocks", errors
        ) or 0
    crt_ram_rows = [
        row
        for row in ram_rows
        if CRT_ENTITY_RE.search(row.get("Name", ""))
    ]
    crt_ram: dict[str, Any] | None = None
    if len(crt_ram_rows) != 1:
        errors.append(
            f"CRT ALTSYNCRAM row count is {len(crt_ram_rows)}, expected exactly 1"
        )
    else:
        row = crt_ram_rows[0]
        name = row.get("Name", "")
        if not CRT_MEM_PRIMITIVE_RE.search(name):
            errors.append(
                "the sole CRT RAM row is not crt_adjust.mem_rtl_0 ALTSYNCRAM: "
                f"{name}"
            )
        size = parse_int(row.get("Size", ""), "CRT RAM logical size", errors)
        blocks = parse_int(
            row.get("M10K blocks", ""), "CRT RAM M10K blocks", errors
        )
        mlabs = parse_int(
            row.get("MLAB cells", ""), "CRT RAM MLAB cells", errors
        )
        geometry_fields = {
            "port_a_depth": ("Port A Depth", EXPECTED_CRT_DEPTH),
            "port_a_width": ("Port A Width", EXPECTED_CRT_WIDTH),
            "port_b_depth": ("Port B Depth", EXPECTED_CRT_DEPTH),
            "port_b_width": ("Port B Width", EXPECTED_CRT_WIDTH),
            "implementation_port_a_depth": (
                "Implementation Port A Depth",
                EXPECTED_CRT_DEPTH,
            ),
            "implementation_port_a_width": (
                "Implementation Port A Width",
                EXPECTED_CRT_WIDTH,
            ),
            "implementation_port_b_depth": (
                "Implementation Port B Depth",
                EXPECTED_CRT_DEPTH,
            ),
            "implementation_port_b_width": (
                "Implementation Port B Width",
                EXPECTED_CRT_WIDTH,
            ),
            "implementation_bits": (
                "Implementation Bits",
                EXPECTED_CRT_BITS,
            ),
        }
        geometry: dict[str, int | None] = {}
        for key, (column, _) in geometry_fields.items():
            geometry[key] = parse_int(
                row.get(column, ""), f"CRT RAM {column}", errors
            )
        crt_ram = {
            "name": name,
            "size_bits": size,
            "m10ks": blocks,
            "mlab_cells": mlabs,
            "mode": row.get("Mode"),
            "clock_mode": row.get("Clock Mode"),
            "mixed_width_rdw_mode": row.get("Mixed Width RDW Mode"),
            "port_a_rdw_mode": row.get("Port A RDW Mode"),
            "port_b_rdw_mode": row.get("Port B RDW Mode"),
            **geometry,
        }
        if size != EXPECTED_CRT_BITS:
            errors.append(
                f"CRT RAM size is {size} bits, expected {EXPECTED_CRT_BITS}"
            )
        if blocks != EXPECTED_CRT_M10KS:
            errors.append(
                f"CRT RAM consumes {blocks} M10Ks, expected {EXPECTED_CRT_M10KS}"
            )
        if mlabs != EXPECTED_CRT_MLABS:
            errors.append(
                f"CRT RAM consumes {mlabs} MLAB cells; MLAB fallback is forbidden"
            )
        for key, (column, expected) in geometry_fields.items():
            if geometry[key] != expected:
                errors.append(
                    f"CRT RAM {column} is {geometry[key]}, expected {expected}"
                )
        if row.get("Mode") != "Simple Dual Port":
            errors.append(
                f"CRT RAM mode is {row.get('Mode')!r}, expected "
                "'Simple Dual Port'"
            )
        if row.get("Clock Mode") != "Single Clock":
            errors.append(
                f"CRT RAM clock mode is {row.get('Clock Mode')!r}, expected "
                "'Single Clock'"
            )

    register_fallbacks = sorted(
        set(match.group(0) for match in CRT_REGISTER_FALLBACK_RE.finditer(fit_text))
    )
    if register_fallbacks:
        errors.append(
            "fit report contains crt_adjust mem[] register nodes; "
            "register fallback is forbidden"
        )

    return {
        "total_m10ks": total_used,
        "device_m10ks": total_capacity,
        "m10k_summary_used": m10k_used,
        "m10k_summary_capacity": m10k_capacity,
        "hierarchy_total_m10ks": hierarchy_total_m10ks,
        "crt_hierarchy": crt_hierarchy,
        "crt_ram": crt_ram,
        "ram_rows": ram_rows,
        "cvsd_sound_rom_m10ks": snd_rom_m10ks,
        "cvsd_sound_rom_rows": len(snd_rom_rows),
        "register_fallbacks": register_fallbacks,
        "errors": errors,
    }


def derive_bypass_counts(
    ram_rows: list[dict[str, str]],
    nodes: Iterable[str],
    errors: list[str],
) -> tuple[dict[str, int], dict[str, dict[str, Any]]]:
    """Derive Quartus bypass width from the fitted protected-RAM geometry.

    Quartus 17's simple-dual-port pass-through bundle contains the write data,
    both logical addresses, and a write-enable bit.  For the current fitted
    descriptor FIFO that is 160 + 9 + 9 + 1 = 179 registers.  Reading the
    geometry from the same fitted row that is being protected prevents a stale
    source constant or report fixture from silently defining the proof.
    """

    expected_counts: dict[str, int] = {}
    geometry: dict[str, dict[str, Any]] = {}
    for node in sorted(set(nodes)):
        matches = [
            row for row in ram_rows if logical_ram_node(row.get("Name", "")) == node
        ]
        if len(matches) != 1:
            errors.append(
                "pass-through RAM fitted-row count is "
                f"{len(matches)} for {node}, expected exactly 1"
            )
            continue

        row = matches[0]
        row_errors: list[str] = []
        port_a_depth = parse_int(
            row.get("Port A Depth", ""), f"{node} Port A Depth", row_errors
        )
        port_a_width = parse_int(
            row.get("Port A Width", ""), f"{node} Port A Width", row_errors
        )
        port_b_depth = parse_int(
            row.get("Port B Depth", ""), f"{node} Port B Depth", row_errors
        )
        port_b_width = parse_int(
            row.get("Port B Width", ""), f"{node} Port B Width", row_errors
        )
        size = parse_int(row.get("Size", ""), f"{node} Size", row_errors)
        errors.extend(row_errors)

        values = (port_a_depth, port_a_width, port_b_depth, port_b_width, size)
        if any(value is None or value <= 0 for value in values):
            continue
        assert port_a_depth is not None
        assert port_a_width is not None
        assert port_b_depth is not None
        assert port_b_width is not None
        assert size is not None

        if row.get("Mode") != "Simple Dual Port":
            errors.append(
                f"pass-through RAM mode is {row.get('Mode')!r} for "
                f"{node}, expected 'Simple Dual Port'"
            )
        if row.get("Clock Mode") != "Single Clock":
            errors.append(
                f"pass-through RAM clock mode is "
                f"{row.get('Clock Mode')!r} for {node}, expected 'Single Clock'"
            )
        if port_a_depth != port_b_depth or port_a_width != port_b_width:
            errors.append(
                "pass-through RAM has asymmetric fitted ports for "
                f"{node}: {port_a_depth}x{port_a_width} vs "
                f"{port_b_depth}x{port_b_width}"
            )
            continue
        if size != port_a_depth * port_a_width:
            errors.append(
                f"pass-through RAM size disagrees with fitted geometry "
                f"for {node}: {size} vs {port_a_depth}x{port_a_width}"
            )
            continue

        address_bits_a = (port_a_depth - 1).bit_length()
        address_bits_b = (port_b_depth - 1).bit_length()
        expected_count = (
            port_a_width + address_bits_a + address_bits_b + 1
        )
        expected_counts[node] = expected_count
        geometry[node] = {
            "port_a_depth": port_a_depth,
            "port_a_width": port_a_width,
            "port_b_depth": port_b_depth,
            "port_b_width": port_b_width,
            "size_bits": size,
            "address_bits_a": address_bits_a,
            "address_bits_b": address_bits_b,
            "derived_bypass_count": expected_count,
        }

    return expected_counts, geometry


def audit_ram_semantics(
    ram_rows: list[dict[str, str]],
    map_log: str,
    map_report: str,
) -> dict[str, Any]:
    errors: list[str] = []
    if not map_log.strip():
        errors.append("map log is empty")
    if "Quartus Prime Analysis & Synthesis was successful." not in map_log:
        errors.append("map log has no Analysis & Synthesis success marker")
    if re.search(r"^Error \(", map_log, re.MULTILINE):
        errors.append("map log contains a Quartus error")
    if not map_report.strip():
        errors.append("map report is empty")
    map_report_successes = MAP_REPORT_SUCCESS_RE.findall(map_report)
    if len(map_report_successes) != 1:
        errors.append(
            "map report terminal success marker count is "
            f"{len(map_report_successes)}, expected exactly 1"
        )

    pass_through_nodes = sorted(
        {
            node
            for node in PASS_THROUGH_RE.findall(map_log)
            if is_game_hierarchy(node)
        }
    )
    bypass_rows: dict[str, list[tuple[str, int]]] = {}
    for match in BYPASS_ROW_RE.finditer(map_report):
        register_node = match.group(1).strip()
        index = int(match.group(2))
        ram_node = match.group(3).strip()
        if not is_game_hierarchy(ram_node):
            continue
        bypass_rows.setdefault(ram_node, []).append((register_node, index))

    # Select the topology only from fitted RAM rows. Map diagnostics can mention
    # analyzed-but-pruned module names, so allowing a log string to choose this
    # branch could silently waive the family descriptor-FIFO requirement.
    fitted_ram_names = [row.get("Name", "") for row in ram_rows]
    recovery_fitted = any(
        RECOVERY_HIERARCHY_TOKEN in name for name in fitted_ram_names
    )
    family_fitted = any(
        FAMILY_HIERARCHY_TOKEN in name for name in fitted_ram_names
    )
    family2_fitted = any(
        FAMILY2_HIERARCHY_TOKEN in name for name in fitted_ram_names
    )
    if sum((recovery_fitted, family_fitted, family2_fitted)) > 1:
        errors.append(
            "fitted RAM rows contain more than one game hierarchy: "
            f"recovery={recovery_fitted}, family={family_fitted}, "
            f"family2={family2_fitted}"
        )
    # The descriptor FIFO exists only in the scheduler-based family core; both
    # /4-CE flavors (recovery, family2) have the direct DMA path instead.
    required_pass_through_nodes = (
        frozenset()
        if (recovery_fitted or family2_fitted)
        else REQUIRED_PASS_THROUGH_NODES
    )
    protected_nodes: list[str] = []
    bypass_evidence: dict[str, dict[str, Any]] = {}
    nodes_requiring_evidence = sorted(
        set(pass_through_nodes) | set(required_pass_through_nodes)
    )
    required_counts, protected_ram_geometry = derive_bypass_counts(
        ram_rows, nodes_requiring_evidence, errors
    )
    for node in nodes_requiring_evidence:
        warning_present = node in pass_through_nodes
        exact_rows = [
            index
            for register_node, index in bypass_rows.get(node, [])
            if register_node == node
        ]
        unique_indices = set(exact_rows)
        duplicate_indices = sorted(
            {
                index
                for index in unique_indices
                if exact_rows.count(index) > 1
            }
        )
        expected_count = required_counts.get(node)
        missing_indices: list[int] = []
        extra_indices: list[int] = []
        evidence_complete = warning_present and bool(exact_rows)

        if not warning_present:
            errors.append(
                "required RAM pass-through warning (276020) is missing for "
                f"{node}"
            )
            evidence_complete = False

        if expected_count is None:
            evidence_complete = False
        else:
            expected_indices = set(range(expected_count))
            missing_indices = sorted(expected_indices - unique_indices)
            extra_indices = sorted(unique_indices - expected_indices)
            if (
                len(exact_rows) != expected_count
                or unique_indices != expected_indices
            ):
                errors.append(
                    "RAM bypass evidence is incomplete or "
                    f"contradictory for {node}: observed {len(exact_rows)} "
                    f"rows/{len(unique_indices)} unique, expected exactly "
                    f"{expected_count} contiguous rows [0..{expected_count - 1}]"
                )
                evidence_complete = False

        if duplicate_indices:
            errors.append(
                f"map report has duplicate bypass indices for {node}: "
                f"{duplicate_indices}"
            )
            evidence_complete = False

        bypass_evidence[node] = {
            "warning_276020_present": warning_present,
            "expected_count": expected_count,
            "observed_row_count": len(exact_rows),
            "observed_unique_count": len(unique_indices),
            "first_index": min(unique_indices) if unique_indices else None,
            "last_index": max(unique_indices) if unique_indices else None,
            "missing_indices": missing_indices,
            "extra_indices": extra_indices,
            "duplicate_indices": duplicate_indices,
            "passed": evidence_complete,
        }
        if evidence_complete:
            protected_nodes.append(node)

    undefined_dual_clock_nodes = sorted(
        {
            node
            for node in UNDEFINED_DUAL_CLOCK_RE.findall(map_log)
            if is_game_hierarchy(node)
        }
    )
    for node in undefined_dual_clock_nodes:
        errors.append(
            "game-side dual-clock RAM has undefined read-during-write behavior: "
            f"{node}"
        )

    uninferred_crt_nodes = sorted(
        {
            node
            for node in UNINFERRED_RAM_RE.findall(map_log)
            if CRT_ENTITY_RE.search(node)
        }
    )
    for node in uninferred_crt_nodes:
        errors.append(
            f"crt_adjust RAM was left uninferred and may use registers: {node}"
        )

    unsafe_rows: list[dict[str, Any]] = []
    protected_set = set(protected_nodes)
    for row in ram_rows:
        name = row.get("Name", "")
        if not is_game_hierarchy(name):
            continue

        row_errors: list[str] = []
        port_a_width = parse_int(
            row.get("Port A Width", ""),
            f"{name} Port A Width",
            row_errors,
        )
        port_b_width = parse_int(
            row.get("Port B Width", ""),
            f"{name} Port B Width",
            row_errors,
        )
        errors.extend(row_errors)

        port_a_mode = normalize_mode(row.get("Port A RDW Mode", ""))
        port_b_mode = normalize_mode(row.get("Port B RDW Mode", ""))
        mixed_mode = normalize_mode(row.get("Mixed Width RDW Mode", ""))
        if port_a_mode not in ACCEPTED_RDW_MODES:
            errors.append(
                f"game-side fitted RAM has unrecognized Port A RDW mode "
                f"{row.get('Port A RDW Mode', '')!r}: {name}"
            )
        if port_b_mode not in ACCEPTED_RDW_MODES:
            errors.append(
                f"game-side fitted RAM has unrecognized Port B RDW mode "
                f"{row.get('Port B RDW Mode', '')!r}: {name}"
            )

        widths_differ = (
            port_a_width is not None
            and port_b_width is not None
            and port_a_width != port_b_width
        )
        if widths_differ and mixed_mode not in ACCEPTED_RDW_MODES:
            errors.append(
                "game-side fitted mixed-width RAM has unrecognized Mixed "
                f"Width RDW mode {row.get('Mixed Width RDW Mode', '')!r}: "
                f"{name}"
            )

        port_a_undefined = port_a_mode == "don't care"
        port_b_undefined = port_b_mode == "don't care"
        mixed_undefined = (
            widths_differ and mixed_mode == "don't care"
        )
        if not (port_a_undefined or port_b_undefined or mixed_undefined):
            continue

        logical_node = logical_ram_node(name)
        protected = logical_node in protected_set
        unsafe_rows.append(
            {
                "name": name,
                "logical_node": logical_node,
                "port_a_undefined": port_a_undefined,
                "port_b_undefined": port_b_undefined,
                "mixed_width_undefined": mixed_undefined,
                "protected": protected,
            }
        )
        if not protected:
            errors.append(
                "game-side fitted RAM has unprotected DON'T CARE "
                f"read-during-write behavior: {logical_node or name}"
            )

    return {
        "family_fitted": family_fitted,
        "recovery_fitted": recovery_fitted,
        "family2_fitted": family2_fitted,
        "required_pass_through_nodes": sorted(required_pass_through_nodes),
        "pass_through_nodes": pass_through_nodes,
        "protected_nodes": protected_nodes,
        "bypass_evidence": bypass_evidence,
        "protected_ram_geometry": protected_ram_geometry,
        "undefined_dual_clock_nodes": undefined_dual_clock_nodes,
        "uninferred_crt_nodes": uninferred_crt_nodes,
        "unsafe_rows": unsafe_rows,
        "errors": errors,
    }


def evaluate_evidence(
    fit_text: str, map_log: str, map_report: str
) -> dict[str, Any]:
    fitted = parse_fit_evidence(fit_text)
    semantics = audit_ram_semantics(
        fitted.get("ram_rows", []), map_log, map_report
    )
    errors = [*fitted["errors"], *semantics["errors"]]
    fitted = dict(fitted)
    fitted.pop("ram_rows", None)
    return {
        "passed": not errors,
        "limits": {
            "max_release_m10ks": MAX_RELEASE_M10KS,
            "device_m10ks": EXPECTED_DEVICE_M10KS,
            "expected_crt_bits": EXPECTED_CRT_BITS,
            "expected_crt_depth": EXPECTED_CRT_DEPTH,
            "expected_crt_width": EXPECTED_CRT_WIDTH,
            "expected_crt_m10ks": EXPECTED_CRT_M10KS,
            "expected_crt_mlabs": EXPECTED_CRT_MLABS,
        },
        "fitted": fitted,
        "ram_semantics": semantics,
        "errors": errors,
    }


def read_evidence(
    path: Path, label: str, minimum_bytes: int
) -> tuple[str, dict[str, Any] | None, list[str]]:
    resolved = path.resolve()
    try:
        data = resolved.read_bytes()
    except FileNotFoundError:
        return "", None, [f"{label} is missing: {resolved}"]
    except OSError as exc:
        return "", None, [f"{label} could not be read: {resolved}: {exc}"]

    record = {
        "path": str(resolved),
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest().upper(),
    }
    errors: list[str] = []
    if len(data) < minimum_bytes:
        errors.append(
            f"{label} is {len(data)} bytes (< {minimum_bytes}); "
            "truncated evidence is inconclusive"
        )
    return data.decode("utf-8", errors="replace"), record, errors


def parse_parameter_tables(
    map_report: str,
) -> tuple[dict[str, list[dict[str, dict[str, str]]]], list[str]]:
    """Return every Quartus user-entity parameter table keyed by instance."""

    lines = map_report.splitlines()
    tables: dict[str, list[dict[str, dict[str, str]]]] = {}
    errors: list[str] = []
    for index, line in enumerate(lines):
        match = PARAMETER_TABLE_HEADER_RE.match(line)
        if match is None:
            continue
        instance = match.group(1).strip()
        parameters: dict[str, dict[str, str]] = {}
        terminated = False
        for table_line in lines[index + 1 :]:
            if table_line.startswith("Note:"):
                terminated = True
                break
            if PARAMETER_TABLE_HEADER_RE.match(table_line):
                break
            fields = split_quartus_row(table_line)
            if len(fields) != 3 or fields[0] == "Parameter Name":
                continue
            if fields[0] in parameters:
                errors.append(
                    f"duplicate fitted parameter row: {instance}|{fields[0]}"
                )
            parameters[fields[0]] = {
                "value": fields[1],
                "type": fields[2],
            }
        if not terminated:
            errors.append(
                f"fitted parameter table has no closing Note boundary: "
                f"{instance}"
            )
        tables.setdefault(instance, []).append(parameters)
    return tables, errors


def parse_parameter_int(
    instance: str,
    name: str,
    row: dict[str, str],
    errors: list[str],
) -> int | None:
    value = row.get("value", "").strip()
    value_type = row.get("type", "").strip()
    try:
        if "Binary" in value_type and re.fullmatch(r"[01]+", value):
            return int(value, 2)
        if "Integer" in value_type and re.fullmatch(r"-?\d+", value):
            return int(value, 10)
    except ValueError:
        pass
    errors.append(
        f"fitted parameter {instance}|{name} is not a recognized integer: "
        f"value={value!r}, type={value_type!r}"
    )
    return None


def validate_recorded_artifact(
    manifest: dict[str, Any],
    label: str,
) -> tuple[str, list[str]]:
    """Read and hash one artifact recorded relative to the manifest root."""

    errors: list[str] = []
    root_value = manifest.get("root")
    artifacts = manifest.get("artifacts")
    if not isinstance(root_value, str) or not root_value:
        return "", ["build manifest has no valid root"]
    if not isinstance(artifacts, dict):
        return "", ["build manifest has no artifacts object"]
    expected = artifacts.get(label)
    if not isinstance(expected, dict):
        return "", [f"build manifest has no {label} artifact record"]
    path_value = expected.get("path")
    if not isinstance(path_value, str) or not path_value:
        return "", [f"build manifest {label} artifact has no valid path"]

    root = Path(root_value).resolve()
    artifact_path = Path(path_value)
    if not artifact_path.is_absolute():
        artifact_path = root / artifact_path
    try:
        data = artifact_path.resolve().read_bytes()
    except OSError as exc:
        return "", [f"could not read {label} artifact: {exc}"]

    expected_size = expected.get("size")
    expected_hash = expected.get("sha256")
    observed_hash = hashlib.sha256(data).hexdigest().upper()
    if expected_size != len(data):
        errors.append(
            f"{label} size disagrees with build manifest: "
            f"{len(data)} vs {expected_size}"
        )
    if (
        not isinstance(expected_hash, str)
        or expected_hash.upper() != observed_hash
    ):
        errors.append(
            f"{label} SHA256 disagrees with build manifest: "
            f"{observed_hash} vs {expected_hash}"
        )
    return data.decode("utf-8", errors="replace"), errors


def validate_manifest_topology(
    manifest: dict[str, Any],
    result: dict[str, Any],
    map_report: str,
) -> tuple[dict[str, Any], list[str]]:
    """Cross-check manifested macro intent against the fitted core and map."""

    errors: list[str] = []
    project = manifest.get("project")
    if not isinstance(project, dict):
        project = {}
        errors.append("build manifest has no project object")
    macro = project.get("macro")
    if not isinstance(macro, str):
        macro = ""
        errors.append("build manifest project macro is not a string")
    macro_tokens = macro.split()
    nonexact_recovery = [
        token
        for token in macro_tokens
        if token.split("=", 1)[0] == RECOVERY_MACRO
        and token != RECOVERY_MACRO
    ]
    if nonexact_recovery:
        errors.append(
            "recovery macro must be the exact bare token "
            f"{RECOVERY_MACRO}, got {nonexact_recovery}"
        )
    recovery_token_count = macro_tokens.count(RECOVERY_MACRO)
    expected_recovery = recovery_token_count == 1
    if recovery_token_count > 1:
        errors.append(
            f"recovery macro appears {recovery_token_count} times, expected once"
        )
    if expected_recovery and macro_tokens != [RECOVERY_MACRO]:
        errors.append(
            "recovery release manifest contains extra macro tokens: "
            f"{macro_tokens}"
        )
    family2_token_count = macro_tokens.count(FAMILY2_MACRO)
    expected_family2 = family2_token_count == 1
    if family2_token_count > 1:
        errors.append(
            f"family2 macro appears {family2_token_count} times, expected once"
        )
    # build_hw.sh:194-205 already accepts DIAG_BOOT/DIAG_DISPBASE on a family2
    # build (behind ALLOW_EXPERIMENTAL_FAMILY_CORE, release stem forbidden), but
    # this gate was never taught the same thing -- so a family2 instrument could
    # FIT and then fail to package, which is exactly what blocked DIAG_DISPBASE.
    # Strictly additive, per the philosophy at the top of this file: with no
    # diagnostic macro the check below is bit-for-bit the old one.
    family2_diag_emu = any(m in macro_tokens for m in DIAG_EMU_MACROS)
    family2_dispseq = "-DYUNIT_DISPLAY_SEQ" in str(project.get("sv2v_extra", "")).split()
    smash_residence_requested = SMASH_BRAM_SOUND_DEFINE in str(project.get("sv2v_extra", "")).split()
    seq_outname = str(project.get("outname", ""))
    seq_outname_ok = (seq_outname.startswith(FAMILY2SEQ_OUTNAME + "-") and
                      len(seq_outname) > len(FAMILY2SEQ_OUTNAME) + 1) if smash_residence_requested else seq_outname == FAMILY2SEQ_OUTNAME
    if expected_family2:
        if family2_dispseq:
            # DISPLAY_SEQ is a production CVSD flavor (not a diagnostic): it FITS
            # like plain family2 (CVSD BRAM, no ADPCM board) but scans via the
            # sequencer. Require its own dedicated stem, distinct from the family2
            # release stem, so a column-fix core never shadows the plain one.
            if not seq_outname_ok:
                errors.append(
                    "family2 display-seq manifest outname must use the dedicated base (with a suffix for Smash BRAM diagnostic): "
                    f"stem {FAMILY2SEQ_OUTNAME!r}, got {project.get('outname')!r}"
                )
        elif family2_diag_emu:
            # SUBSET, not equality: a DISPBASE build carries DIAG_BOOT +
            # DIAG_DISPBASE and must not be forced to also pass DIAG_DLAUDIT.
            stray_family2 = [
                t for t in macro_tokens
                if t != FAMILY2_MACRO and t not in DIAG_EMU_MACROS
            ]
            if stray_family2:
                errors.append(
                    "family2 diagnostic manifest contains unrecognised macro "
                    f"tokens: {stray_family2}"
                )
        elif macro_tokens != [FAMILY2_MACRO]:
            errors.append(
                "family2 release manifest contains extra macro tokens: "
                f"{macro_tokens}"
            )
    # CVSD sound-ROM residence must match the flavor the build actually asked
    # for. Production streams samples from SDRAM, freeing the 192 M10Ks the
    # three 64 KiB BRAMs measured; +define+YUNIT_CVSD_BRAM_SOUND is the named,
    # manifested escape hatch back to the cabinet-proven BRAM path.
    sv2v_extra = str(project.get("sv2v_extra", ""))
    extra_tokens = sv2v_extra.split()
    broad_bram_sound = CVSD_BRAM_SOUND_DEFINE in extra_tokens
    smash_bram_sound = SMASH_BRAM_SOUND_DEFINE in extra_tokens
    bram_sound_waiver = broad_bram_sound or smash_bram_sound
    if broad_bram_sound and smash_bram_sound:
        errors.append("choose only one CVSD BRAM sound residence option")
    if smash_bram_sound and not (expected_family2 and family2_dispseq):
        errors.append("Smash BRAM diagnostic requires Family2 display-sequencer flavor")
    # The evidence lives under "fitted" -- parse_fit_evidence's dict is nested
    # by evaluate_evidence. Read it explicitly and treat ABSENCE as a failure:
    # defaulting a missing count to 0 would read as "no BRAMs fitted" and wave
    # through exactly the build this is meant to catch.
    fitted_evidence = result.get("fitted")
    if not isinstance(fitted_evidence, dict) or \
            "cvsd_sound_rom_m10ks" not in fitted_evidence:
        errors.append(
            "fitted evidence carries no cvsd_sound_rom_m10ks count; the CVSD "
            "sound-residence check cannot be evaluated"
        )
    else:
        fitted_snd_rom_m10ks = fitted_evidence["cvsd_sound_rom_m10ks"]
        fitted_snd_rom_rows = fitted_evidence.get("cvsd_sound_rom_rows", 0)
        if smash_bram_sound and (fitted_snd_rom_m10ks != 192 or fitted_snd_rom_rows != 3):
            errors.append("Smash BRAM diagnostic requires exactly 3 sound memories / 192 M10Ks; "
                          f"got {fitted_snd_rom_rows} memories / {fitted_snd_rom_m10ks} M10Ks")
        if bram_sound_waiver:
            if fitted_snd_rom_m10ks <= 0:
                errors.append(
                    f"build carries a CVSD BRAM sound option but no "
                    "smashtv_snd_rom M10Ks were fitted; the revert to the "
                    "cabinet-proven BRAM sound path did not take effect"
                )
        elif fitted_snd_rom_m10ks > 0:
            errors.append(
                f"CVSD sound ROM still occupies {fitted_snd_rom_m10ks} fitted "
                f"M10Ks in {fitted_snd_rom_rows} memories. Production streams "
                "CVSD samples from SDRAM; to keep the BRAM images, build with "
                f"{CVSD_BRAM_SOUND_DEFINE} so the choice is recorded in the "
                "manifest"
            )

    adpcm_token_count = macro_tokens.count(ADPCM_MACRO)
    expected_adpcm = adpcm_token_count == 1
    if adpcm_token_count > 1:
        errors.append(
            f"adpcm macro appears {adpcm_token_count} times, expected once"
        )
    if expected_adpcm and macro_tokens != [ADPCM_MACRO]:
        errors.append(
            "adpcm release manifest contains extra macro tokens: "
            f"{macro_tokens}"
        )
    full_token_count = macro_tokens.count(FULL_MACRO)
    expected_full = full_token_count == 1
    if full_token_count > 1:
        errors.append(
            f"full macro appears {full_token_count} times, expected once"
        )
    diag_service = DIAG_SERVICE_MACRO in macro_tokens
    diag_emu = any(m in macro_tokens for m in DIAG_EMU_MACROS)
    allowed_full_tokens = (
        [FULL_MACRO, DIAG_SERVICE_MACRO] if diag_service else [FULL_MACRO]
    )
    if diag_emu:
        allowed_full_tokens = allowed_full_tokens + list(DIAG_EMU_MACROS)
    if expected_full and sorted(macro_tokens) != sorted(allowed_full_tokens):
        errors.append(
            "full release manifest contains extra macro tokens: "
            f"{macro_tokens}"
        )
    if expected_recovery and expected_family2:
        errors.append("manifest requests both recovery and family2")
    if expected_full and (expected_recovery or expected_family2):
        errors.append("manifest requests full together with another flavour")

    semantics = result.get("ram_semantics", {})
    observed_recovery = bool(semantics.get("recovery_fitted"))
    observed_family = bool(semantics.get("family_fitted"))
    observed_family2 = bool(semantics.get("family2_fitted"))
    if expected_recovery:
        if not observed_recovery or observed_family or observed_family2:
            errors.append(
                "manifest requests Smash recovery but fitted RAM hierarchy is "
                f"recovery={observed_recovery}, family={observed_family}, "
                f"family2={observed_family2}"
            )
        if project.get("outname") != RECOVERY_OUTNAME:
            errors.append(
                "recovery manifest outname is not the dedicated package stem: "
                f"{project.get('outname')!r}"
            )
    elif expected_family2:
        if not observed_family2 or observed_family or observed_recovery:
            errors.append(
                "manifest requests family2 but fitted RAM hierarchy is "
                f"recovery={observed_recovery}, family={observed_family}, "
                f"family2={observed_family2}"
            )
        if family2_dispseq:
            # DISPLAY_SEQ (SF/Saurian column fix): production CVSD flavor, its own
            # dedicated stem so it never shadows the plain family2 release core.
            if not seq_outname_ok:
                errors.append(
                    "family2 display-seq manifest outname must use the dedicated base (with a suffix for Smash BRAM diagnostic): "
                    f"stem {FAMILY2SEQ_OUTNAME!r}, got {project.get('outname')!r}"
                )
        elif family2_diag_emu:
            # Same inversion as DIAG_SERVICE / the FULL emu diagnostics: an
            # instrument image must NEVER be installable under the release stem
            # (the stale-install failure the cabinet handoff bans). It must
            # still be recognisable as a family2 image, so require the release
            # stem as a PREFIX -- "Arcade-SmashTV-YUnit-Family2-DISPBASE".
            diag_outname = project.get("outname") or ""
            if diag_outname == FAMILY2_OUTNAME:
                errors.append(
                    "a family2 diagnostic build must not take the release stem "
                    f"{FAMILY2_OUTNAME!r}"
                )
            elif not diag_outname.startswith(FAMILY2_OUTNAME + "-"):
                errors.append(
                    "family2 diagnostic manifest outname must begin with "
                    f"{FAMILY2_OUTNAME + '-'!r}, got {diag_outname!r}"
                )
        elif project.get("outname") != FAMILY2_OUTNAME:
            errors.append(
                "family2 manifest outname is not the dedicated package stem: "
                f"{project.get('outname')!r}"
            )
    elif expected_adpcm:
        # Same family2 top and 8 MB map as FULL, so the fitted RAM hierarchy also reads as
        # family2; macro + outname are what separate them.
        if not observed_family2 or observed_family or observed_recovery:
            errors.append(
                "manifest requests adpcm sibling but fitted RAM hierarchy is "
                f"recovery={observed_recovery}, family={observed_family}, "
                f"family2={observed_family2}"
            )
        if project.get("outname") != ADPCM_OUTNAME:
            errors.append(
                "adpcm manifest outname is not the dedicated package stem: "
                f"{project.get('outname')!r}"
            )
        # The CVSD board is deleted in this sibling, so its sample BRAMs must be absent
        # UNCONDITIONALLY -- there is no escape hatch to excuse them here.
        if fitted_snd_rom_m10ks > 0:
            errors.append(
                f"adpcm sibling carries {fitted_snd_rom_m10ks} fitted CVSD sound-ROM "
                "M10Ks; this flavour has no CVSD board and must have none"
            )
    elif expected_full:
        # Shares the family2 top module, so the fitted RAM hierarchy reads as
        # family2 here; the flavours are told apart by macro and outname.
        if not observed_family2 or observed_family or observed_recovery:
            errors.append(
                "manifest requests adpcm but fitted RAM hierarchy is "
                f"recovery={observed_recovery}, family={observed_family}, "
                f"family2={observed_family2}"
            )
        if diag_service:
            # Inverted on purpose: the diagnostic must NOT be able to take the release
            # stem. A counter image installed under the release name is the exact
            # stale-install failure the cabinet handoff bans.
            diag_outname = project.get("outname") or ""
            if diag_outname == FULL_OUTNAME:
                errors.append(
                    "a DIAG_SERVICE build must not take the release stem "
                    f"{FULL_OUTNAME!r}"
                )
            elif not diag_outname.startswith(DIAG_SERVICE_OUTNAME_PREFIX):
                errors.append(
                    "DIAG_SERVICE manifest outname must begin with "
                    f"{DIAG_SERVICE_OUTNAME_PREFIX!r}, got {diag_outname!r}"
                )
        elif diag_emu:
            # Same inversion as DIAG_SERVICE: an instrument image must never be
            # installable under the release stem.
            diag_outname = project.get("outname") or ""
            if diag_outname == FULL_OUTNAME:
                errors.append(
                    "a DIAG_BOOT/DIAG_DLAUDIT build must not take the release "
                    f"stem {FULL_OUTNAME!r}"
                )
            elif not diag_outname.startswith(DIAG_EMU_OUTNAME_PREFIX):
                errors.append(
                    "download-audit manifest outname must begin with "
                    f"{DIAG_EMU_OUTNAME_PREFIX!r}, got {diag_outname!r}"
                )
        elif project.get("outname") != FULL_OUTNAME:
            errors.append(
                "full manifest outname is not the dedicated package stem: "
                f"{project.get('outname')!r}"
            )
    elif observed_recovery:
        errors.append(
            "non-recovery manifest cannot accept a fitted Smash recovery hierarchy"
        )
    elif observed_family2:
        errors.append(
            "non-family2 manifest cannot accept a fitted family2 hierarchy"
        )
    elif not observed_family:
        errors.append(
            "non-recovery manifest has no fitted family RAM hierarchy"
        )

    if expected_recovery:
        expected_instance = RECOVERY_TOP_INSTANCE
        forbidden_instances = [FAMILY_TOP_INSTANCE, FAMILY2_TOP_INSTANCE]
        expected_parameters = RECOVERY_TOP_PARAMETERS
    elif expected_family2:
        expected_instance = FAMILY2_TOP_INSTANCE
        forbidden_instances = [FAMILY_TOP_INSTANCE, RECOVERY_TOP_INSTANCE]
        expected_parameters = FAMILY2_TOP_PARAMETERS
    elif expected_full or expected_adpcm:
        # Same top module as family2 -- only the memory map differs. The ADPCM sibling
        # shares FULL's 8 MB map exactly; it differs only in having no CVSD board, which
        # is a module-presence question, not a parameter one.
        expected_instance = FAMILY2_TOP_INSTANCE
        forbidden_instances = [FAMILY_TOP_INSTANCE, RECOVERY_TOP_INSTANCE]
        expected_parameters = FULL_TOP_PARAMETERS
    else:
        expected_instance = FAMILY_TOP_INSTANCE
        forbidden_instances = [RECOVERY_TOP_INSTANCE, FAMILY2_TOP_INSTANCE]
        expected_parameters = FAMILY_TOP_PARAMETERS
    tables, table_errors = parse_parameter_tables(map_report)
    errors.extend(table_errors)
    expected_tables = tables.get(expected_instance, [])
    if len(expected_tables) != 1:
        errors.append(
            f"fitted top parameter table count for {expected_instance} is "
            f"{len(expected_tables)}, expected exactly 1"
        )
        parameter_rows: dict[str, dict[str, str]] = {}
    else:
        parameter_rows = expected_tables[0]
    for forbidden_instance in forbidden_instances:
        if tables.get(forbidden_instance, []):
            errors.append(
                f"forbidden fitted top parameter table is present: "
                f"{forbidden_instance}"
            )

    observed_parameters: dict[str, int | None] = {}
    for name, expected_value in expected_parameters.items():
        row = parameter_rows.get(name)
        if row is None:
            errors.append(
                f"fitted top parameter is missing: {expected_instance}|{name}"
            )
            observed_parameters[name] = None
            continue
        observed_value = parse_parameter_int(
            expected_instance, name, row, errors
        )
        observed_parameters[name] = observed_value
        if observed_value is not None and observed_value != expected_value:
            errors.append(
                f"fitted top parameter mismatch: {expected_instance}|{name} "
                f"is 0x{observed_value:x}, expected 0x{expected_value:x}"
            )
    observed_mem_parameters: dict[str, int | None] = {}
    if expected_recovery:
        for forbidden_parameter in ("ROM_WORDS", "ROM_WORD_OFFSET"):
            if forbidden_parameter in parameter_rows:
                errors.append(
                    "recovery fitted top exposes forbidden hybrid parameter: "
                    f"{forbidden_parameter}"
                )
        recovery_mem_tables = tables.get(RECOVERY_MEM_INSTANCE, [])
        if len(recovery_mem_tables) != 1:
            errors.append(
                "fitted recovery memory parameter table count for "
                f"{RECOVERY_MEM_INSTANCE} is {len(recovery_mem_tables)}, "
                "expected exactly 1"
            )
            recovery_mem_rows: dict[str, dict[str, str]] = {}
        else:
            recovery_mem_rows = recovery_mem_tables[0]
        if "ROM_WORD_OFFSET" in recovery_mem_rows:
            errors.append(
                "recovery fitted memory exposes forbidden hybrid parameter: "
                "ROM_WORD_OFFSET"
            )
        for name, expected_value in RECOVERY_MEM_PARAMETERS.items():
            row = recovery_mem_rows.get(name)
            if row is None:
                errors.append(
                    f"fitted recovery memory parameter is missing: "
                    f"{RECOVERY_MEM_INSTANCE}|{name}"
                )
                observed_mem_parameters[name] = None
                continue
            observed_value = parse_parameter_int(
                RECOVERY_MEM_INSTANCE, name, row, errors
            )
            observed_mem_parameters[name] = observed_value
            if observed_value is not None and observed_value != expected_value:
                errors.append(
                    "fitted recovery memory parameter mismatch: "
                    f"{RECOVERY_MEM_INSTANCE}|{name} is "
                    f"0x{observed_value:x}, expected 0x{expected_value:x}"
                )
        audit_log, audit_errors = validate_recorded_artifact(
            manifest, "recovery_transfer_audit"
        )
        errors.extend(audit_errors)
        if audit_log:
            if "SMASH RECOVERY AUDIT PASS:" not in audit_log:
                errors.append(
                    "recorded recovery transfer audit has no PASS marker"
                )
            if "SMASH RECOVERY AUDIT FAIL:" in audit_log:
                errors.append(
                    "recorded recovery transfer audit contains a FAIL marker"
                )
    if expected_family2 or expected_full:
        # Both flavours instantiate yunit_mem_family2 at the same path; only
        # the sizing parameters differ (4 MB CVSD scope vs 8 MB ADPCM scope).
        family2_mem_expected = (
            FULL_MEM_PARAMETERS
            if (expected_full or expected_adpcm)
            else FAMILY2_MEM_PARAMETERS
        )
        family2_mem_tables = tables.get(FAMILY2_MEM_INSTANCE, [])
        if len(family2_mem_tables) != 1:
            errors.append(
                "fitted family2 memory parameter table count for "
                f"{FAMILY2_MEM_INSTANCE} is {len(family2_mem_tables)}, "
                "expected exactly 1"
            )
            family2_mem_rows: dict[str, dict[str, str]] = {}
        else:
            family2_mem_rows = family2_mem_tables[0]
        for name, expected_value in family2_mem_expected.items():
            row = family2_mem_rows.get(name)
            if row is None:
                errors.append(
                    f"fitted family2 memory parameter is missing: "
                    f"{FAMILY2_MEM_INSTANCE}|{name}"
                )
                observed_mem_parameters[name] = None
                continue
            observed_value = parse_parameter_int(
                FAMILY2_MEM_INSTANCE, name, row, errors
            )
            observed_mem_parameters[name] = observed_value
            if observed_value is not None and observed_value != expected_value:
                errors.append(
                    "fitted family2 memory parameter mismatch: "
                    f"{FAMILY2_MEM_INSTANCE}|{name} is "
                    f"0x{observed_value:x}, expected 0x{expected_value:x}"
                )
        audit_log, audit_errors = validate_recorded_artifact(
            manifest, "recovery_transfer_audit"
        )
        errors.extend(audit_errors)
        if audit_log and "SMASH RECOVERY AUDIT PASS:" not in audit_log:
            errors.append(
                "recorded recovery transfer audit has no PASS marker"
            )

    evidence = {
        "macro": macro,
        "expected_recovery": expected_recovery,
        "expected_family2": expected_family2,
        "observed_recovery": observed_recovery,
        "observed_family": observed_family,
        "observed_family2": observed_family2,
        "expected_top_instance": expected_instance,
        "expected_top_table_count": len(expected_tables),
        "forbidden_top_table_count": sum(
            len(tables.get(instance, [])) for instance in forbidden_instances
        ),
        "observed_parameters": observed_parameters,
        "observed_memory_parameters": observed_mem_parameters,
        "passed": not errors,
    }
    return evidence, errors


def load_and_validate_manifest_inputs(
    manifest_path: Path,
    input_records: dict[str, dict[str, Any]],
) -> tuple[dict[str, Any] | None, list[str]]:
    errors: list[str] = []
    try:
        manifest_data = manifest_path.read_bytes()
        manifest = json.loads(manifest_data.decode("utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        return None, [f"could not read build manifest: {exc}"]
    if not isinstance(manifest, dict):
        return None, ["build manifest root is not a JSON object"]

    root_value = manifest.get("root")
    if not isinstance(root_value, str) or not root_value:
        errors.append("build manifest has no valid root")
        root = None
    else:
        root = Path(root_value).resolve()

    artifacts = manifest.get("artifacts")
    if not isinstance(artifacts, dict):
        errors.append("build manifest has no artifacts object")
        artifacts = {}

    for label in ("fit_report", "map_log", "map_report"):
        observed = input_records.get(label)
        expected = artifacts.get(label)
        if observed is None:
            errors.append(
                f"cannot compare missing {label} evidence with build manifest"
            )
            continue
        if not isinstance(expected, dict):
            errors.append(f"build manifest has no {label} artifact record")
            continue

        expected_path_value = expected.get("path")
        if not isinstance(expected_path_value, str) or not expected_path_value:
            errors.append(
                f"build manifest {label} artifact has no valid path"
            )
        elif root is not None:
            expected_path = Path(expected_path_value)
            if not expected_path.is_absolute():
                expected_path = root / expected_path
            expected_resolved = expected_path.resolve()
            if os.path.normcase(str(expected_resolved)) != os.path.normcase(
                observed["path"]
            ):
                errors.append(
                    f"{label} path disagrees with build manifest: "
                    f"{observed['path']} vs {expected_resolved}"
                )

        expected_size = expected.get("size")
        if expected_size != observed["bytes"]:
            errors.append(
                f"{label} size disagrees with build manifest: "
                f"{observed['bytes']} vs {expected_size}"
            )

        expected_hash = expected.get("sha256")
        if (
            not isinstance(expected_hash, str)
            or expected_hash.upper() != observed["sha256"]
        ):
            errors.append(
                f"{label} SHA256 disagrees with build manifest: "
                f"{observed['sha256']} vs {expected_hash}"
            )

    return manifest, errors


def print_result(result: dict[str, Any]) -> None:
    fitted = result["fitted"]
    crt = fitted.get("crt_ram") or {}
    print(
        "RAM gate: total "
        f"{fitted.get('total_m10ks')}/{fitted.get('device_m10ks')} M10Ks "
        f"(limit {MAX_RELEASE_M10KS}/{EXPECTED_DEVICE_M10KS})"
    )
    print(
        "RAM gate: CRT "
        f"{crt.get('size_bits')} bits, {crt.get('m10ks')} M10Ks, "
        f"{crt.get('mlab_cells')} MLAB cells"
    )
    semantics = result["ram_semantics"]
    print(
        "RAM gate: fitted semantics "
        f"{len(semantics['protected_nodes'])} mapper-protected, "
        f"{len(semantics['undefined_dual_clock_nodes'])} undefined dual-clock, "
        f"{len(semantics['uninferred_crt_nodes'])} uninferred CRT"
    )
    if result["passed"]:
        print("RAM_GATE RESULT: PASS")
    else:
        print("RAM_GATE RESULT: FAIL", file=sys.stderr)
        for error in result["errors"]:
            print(f"  - {error}", file=sys.stderr)


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--fit-report", type=Path, required=True)
    parser.add_argument("--map-log", type=Path, required=True)
    parser.add_argument("--map-report", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--manifest", type=Path)
    args = parser.parse_args(argv)

    fit_text, fit_record, fit_errors = read_evidence(
        args.fit_report, "fit report", MIN_REPORT_BYTES
    )
    map_log, map_log_record, map_log_errors = read_evidence(
        args.map_log, "map log", MIN_MAP_LOG_BYTES
    )
    map_report, map_report_record, map_report_errors = read_evidence(
        args.map_report, "map report", MIN_REPORT_BYTES
    )

    result = evaluate_evidence(fit_text, map_log, map_report)
    input_errors = [*fit_errors, *map_log_errors, *map_report_errors]
    input_records = {
        label: record
        for label, record in (
            ("fit_report", fit_record),
            ("map_log", map_log_record),
            ("map_report", map_report_record),
        )
        if record is not None
    }
    manifest: dict[str, Any] | None = None
    manifest_errors: list[str] = []
    topology_evidence: dict[str, Any] | None = None
    if args.manifest:
        manifest, manifest_errors = load_and_validate_manifest_inputs(
            args.manifest, input_records
        )
        input_errors.extend(manifest_errors)
        if manifest is not None:
            topology_evidence, topology_errors = validate_manifest_topology(
                manifest, result, map_report
            )
            input_errors.extend(topology_errors)

    if input_errors:
        result["errors"] = [*input_errors, *result["errors"]]
        result["passed"] = False
    result["checked_at_utc"] = utc_now()
    result["inputs"] = input_records
    result["manifest_input_verification"] = {
        "requested": bool(args.manifest),
        "passed": bool(args.manifest) and not manifest_errors,
    }
    result["manifest_topology_verification"] = {
        "requested": bool(args.manifest),
        **(
            topology_evidence
            if topology_evidence is not None
            else {"passed": False}
        ),
    }

    atomic_write_json(args.output, result)
    if args.manifest:
        if manifest is not None:
            try:
                manifest["ram_gate"] = result
                manifest["updated_at_utc"] = utc_now()
                atomic_write_json(args.manifest, manifest)
            except OSError as exc:
                result["passed"] = False
                result["errors"].append(
                    f"could not update build manifest: {exc}"
                )
                atomic_write_json(args.output, result)
        elif not manifest_errors:
            result["passed"] = False
            result["errors"].append("could not load build manifest")
            atomic_write_json(args.output, result)

    print_result(result)
    return 0 if result["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
