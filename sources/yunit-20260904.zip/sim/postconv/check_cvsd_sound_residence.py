#!/usr/bin/env python3
"""Pin where the CVSD sound ROM lives, in BOTH build states.

MEASURED COST (family2 fit, output_files/Arcade-SmashTV.fit.rpt):

      M10K   depth  width  instance
        64   65536      8  smashtv_snd_rom:bank_a_rom   (U4)
        64   65536      8  smashtv_snd_rom:bank_b_rom   (U19)
        64   65536      8  smashtv_snd_rom:bank_c_rom   (U20)
      ----
       192   of the CVSD board's 203 M10Ks

192 of 553 device M10Ks -- 35% of all block RAM -- to hold 192 KiB of samples.
Streaming them from SDRAM instead is what lets one core carry every Y-unit
title. The bytes are already written to SOUNDW_BASE for every title by
family2_download_mapper, so the default consumes data that was already there.

DEFAULT  : use_ext_cvsd = 1, BRAM write driver tied off -> BRAMs optimized away
REVERT   : +define+YUNIT_CVSD_BRAM_SOUND -> exact prior per-title behaviour

The revert exists because Smash T.V.'s sound is CABINET-PROVEN on the BRAM
path and this change moves it. This checker fails if either state is quietly
altered -- if the default stops being SDRAM, or if the revert path is deleted
so there is nothing to fall back to.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

TOP = Path(__file__).resolve().parents[2] / "rtl/yunit/family2/yunit_top_family2.sv"
MAPPER = (Path(__file__).resolve().parents[2]
          / "rtl/yunit/family2/family2_download_mapper.sv")

REVERT_DEFINE = "YUNIT_CVSD_BRAM_SOUND"


def fail(msg: str) -> int:
    print(f"CVSD-SOUND-RESIDENCE FAIL: {msg}")
    return 1


def main() -> int:
    if not TOP.exists():
        return fail(f"{TOP} not found")
    text = TOP.read_text(encoding="utf-8", errors="replace")

    block = re.search(
        r"`ifdef\s+" + REVERT_DEFINE + r"\b(?P<revert>.*?)`else(?P<default>.*?)`endif",
        text,
        re.S,
    )
    if block is None:
        return fail(
            f"the `ifdef {REVERT_DEFINE} / `else / `endif residence block is "
            "gone -- there is no revert path left"
        )
    revert, default = block.group("revert"), block.group("default")

    # DEFAULT leg: SDRAM for every CVSD title, and the BRAM write driver off.
    if not re.search(r"use_ext_cvsd\s*=\s*1'b1", default):
        return fail(
            "default leg no longer forces use_ext_cvsd = 1'b1; CVSD sound "
            "would silently return to BRAM and cost 192 M10Ks"
        )
    if not re.search(r"cvsd_dl_we\s*=\s*1'b0", default):
        return fail(
            "default leg no longer ties cvsd_dl_we to 1'b0; the BRAMs keep a "
            "write driver and Quartus will retain all 192 M10Ks"
        )

    # REVERT leg: the exact prior per-title behaviour must still be reachable.
    if not re.search(r"use_ext_cvsd\s*=\s*\(\s*yunit_sound_type\(game_id\)\s*=="
                     r"\s*YS_CVSD_LARGE\s*\)", revert):
        return fail(
            "revert leg no longer restores the per-title use_ext_cvsd "
            "selection -- the escape hatch would not reproduce prior behaviour"
        )
    if not re.search(r"cvsd_dl_we\s*=\s*snd_dl_wr", revert):
        return fail(
            "revert leg no longer restores the BRAM write driver -- reverting "
            "would leave the BRAM images empty"
        )

    smash = re.search(r"`elsif\s+YUNIT_SMASH_BRAM_SOUND\b(?P<smash>.*?)`else", text, re.S)
    if smash is None:
        return fail("Smash-only BRAM diagnostic residence branch is missing")
    smash = smash.group("smash")
    if not re.search(r"use_ext_cvsd\s*=\s*\(game_id\s*!=\s*YG_SMASHTV\)", smash):
        return fail("Smash-only branch changed another profile's external-ROM selection")
    if not re.search(r"cvsd_dl_we\s*=\s*snd_dl_wr\s*&&\s*\(game_id\s*==\s*YG_SMASHTV\)", smash):
        return fail("Smash-only BRAM download write gate is missing or wrong")

    # The board instance must consume the gated write enable, not the raw one.
    if not re.search(r"\.snd_dl_we\(\s*cvsd_dl_we\s*\)", text):
        return fail(
            "williams_cvsd_board is not wired to cvsd_dl_we; the gating has no "
            "effect and the BRAMs survive in both states"
        )

    # The whole scheme depends on the sound bytes already reaching SDRAM for
    # EVERY title, not just the large sets.
    if MAPPER.exists():
        mtext = MAPPER.read_text(encoding="utf-8", errors="replace")
        if not re.search(r"snd_download\b[^\n]*\n(?:[^\n]*\n){0,8}?"
                         r"[^\n]*SOUNDW_BASE", mtext):
            return fail(
                "family2_download_mapper no longer writes the sound stream to "
                "SOUNDW_BASE; SDRAM sound would read unwritten memory"
            )

    print("CVSD-SOUND-RESIDENCE PASS: default = SDRAM (frees 192 M10K), "
          f"revert via +define+{REVERT_DEFINE} intact")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
