//============================================================================
//  Arcade: Midway/Williams Y-unit for MiSTer — universal emu wrapper
//
//  Open, anti-paywall TMS34010 Y-unit core. This emu wraps rtl/yunit/yunit_top.sv
//  (the whole synthesizable core: TMS34010 + memory map + DMA blitter + video +
//  palette + CVSD/ADPCM sound + SDRAM controller) in the standard Template_MiSTer chassis.
//  yunit_top OWNS the SDRAM controller, so this wrapper just passes the SDRAM pins
//  through (assign SDRAM_CLK = clk_sdram) and feeds it clocks, inputs, ioctl ROM
//  data, and takes RGB + audio back out.
//
//  GPL (jt51 + darfpga CVSD + 6809 are GPL). No ROM data distributed. See VENDOR.md.
//============================================================================
module emu
(
	input         CLK_50M,
	input         RESET,
	inout  [48:0] HPS_BUS,

	output        CLK_VIDEO,
	output        CE_PIXEL,
	output [12:0] VIDEO_ARX,
	output [12:0] VIDEO_ARY,

	output  [7:0] VGA_R,
	output  [7:0] VGA_G,
	output  [7:0] VGA_B,
	output        VGA_HS,
	output        VGA_VS,
	output        VGA_DE,
	output        VGA_F1,
	output [1:0]  VGA_SL,
	output        VGA_SCALER,
	output        VGA_DISABLE,

	input  [11:0] HDMI_WIDTH,
	input  [11:0] HDMI_HEIGHT,
	output        HDMI_FREEZE,
	output        HDMI_BLACKOUT,
	output        HDMI_BOB_DEINT,

	output        FB_EN,
	output  [4:0] FB_FORMAT,
	output [11:0] FB_WIDTH,
	output [11:0] FB_HEIGHT,
	output [31:0] FB_BASE,
	output [13:0] FB_STRIDE,
	input         FB_VBL,
	input         FB_LL,
	output        FB_FORCE_BLANK,

	output        FB_PAL_CLK,
	output  [7:0] FB_PAL_ADDR,
	output [23:0] FB_PAL_DOUT,
	input  [23:0] FB_PAL_DIN,
	output        FB_PAL_WR,

	output        LED_USER,
	output  [1:0] LED_POWER,
	output  [1:0] LED_DISK,

	output  [1:0] BUTTONS,

	input         CLK_AUDIO,
	output [15:0] AUDIO_L,
	output [15:0] AUDIO_R,
	output        AUDIO_S,
	output  [1:0] AUDIO_MIX,

	inout   [3:0] ADC_BUS,

	output        SD_SCK,
	output        SD_MOSI,
	input         SD_MISO,
	output        SD_CS,
	input         SD_CD,

	output        DDRAM_CLK,
	input         DDRAM_BUSY,
	output  [7:0] DDRAM_BURSTCNT,
	output [28:0] DDRAM_ADDR,
	input  [63:0] DDRAM_DOUT,
	input         DDRAM_DOUT_READY,
	output        DDRAM_RD,
	output [63:0] DDRAM_DIN,
	output  [7:0] DDRAM_BE,
	output        DDRAM_WE,

	output        SDRAM_CLK,
	output        SDRAM_CKE,
	output [12:0] SDRAM_A,
	output  [1:0] SDRAM_BA,
	inout  [15:0] SDRAM_DQ,
	output        SDRAM_DQML,
	output        SDRAM_DQMH,
	output        SDRAM_nCS,
	output        SDRAM_nCAS,
	output        SDRAM_nRAS,
	output        SDRAM_nWE,

	input         UART_CTS,
	output        UART_RTS,
	input         UART_RXD,
	output        UART_TXD,
	output        UART_DTR,
	input         UART_DSR,

	input   [6:0] USER_IN,
	output  [6:0] USER_OUT,

	input         OSD_STATUS
);

// ---- unused chassis features -------------------------------------------------
assign VGA_F1 = 0;
assign VGA_SCALER = 0;   // VGA_SL is driven by arcade_video
assign VGA_DISABLE = 0;
assign HDMI_FREEZE = 0;
assign HDMI_BLACKOUT = 0;
assign HDMI_BOB_DEINT = 0;
assign FB_FORCE_BLANK = 0;
assign {FB_EN, FB_FORMAT, FB_WIDTH, FB_HEIGHT, FB_BASE, FB_STRIDE} = 0;
assign {FB_PAL_CLK, FB_PAL_ADDR, FB_PAL_DOUT, FB_PAL_WR} = 0;
// HPS DDR3 (f2h_sdram1) hosts VRAM under USE_DDR3_VRAM (frees the SDRAM port so scanout no longer
// starves the CPU). DDRAM_CLK is driven from clk_sys — the whole ram1 f2sdram bridge + safe-
// terminator run off this core-supplied clock (sys_top.v:603,1811 + sysmem.sv:203,325,311,421-423),
// so the agent on clk_sys sees NO clock-domain crossing. The 6 master outputs are driven by
// yunit_top (tied to 0 there when USE_DDR3_VRAM is off).
assign DDRAM_CLK = clk_sys;
assign {SD_SCK, SD_MOSI, SD_CS} = 'Z;
assign {UART_RTS, UART_TXD, UART_DTR} = 0;
assign USER_OUT = '1;
assign LED_DISK  = 0;
assign LED_POWER = 0;
assign LED_USER  = ioctl_download | ioctl_upload | nvram_dirty;
assign BUTTONS   = 0;

// Smash T.V. is a horizontal 4:3 game.
assign VIDEO_ARX = status[1] ? 12'd16 : 12'd4;
assign VIDEO_ARY = status[1] ? 12'd9  : 12'd3;

assign AUDIO_S   = 1;              // yunit_top emits signed PCM
assign AUDIO_MIX = 0;

// SDRAM_CLK is forwarded from the phase-shifted PLL output (clk_sdram = outclk_1, -3515ps)
// straight to the pin, exactly like the proven tecmo/jtframe MiSTer cores on this DE10 —
// and rtl/sdram.sdc sources the SDRAM_CLK generated clock from that same general[1] output,
// so the fitter closes the read window against the REAL pin clock. (An earlier build drove
// SDRAM_CLK from a DDIO on clk_sys, which did NOT match the SDC -> reads captured against a
// phantom edge -> black screen on silicon. The stock controller keeps its proven CAS-latency
// capture; only the clock forward reverts to this proven scheme.)
assign SDRAM_CLK = clk_sdram;

`include "build_id.v"
// YUNIT_LEGACY_SMASH_ABI: the emu-level plumbing proven by the cabinet-good
// Smash recovery image (legacy single-stream ROM download, Smash-only
// controller ABI, recovery CONF_STR and physical map).  Since family2 P1.3
// only the FROZEN recovery build selects it: family2 rides the family
// CONF_STR / multi-stream downloads / family physical map, through its own
// mapper clones (PLAN-family2-rebase.md).
`ifdef YUNIT_SMASH_RECOVERY
 `define YUNIT_LEGACY_SMASH_ABI
`endif
// YUNIT_FULL is the single all-title production build. It is the SAME rebased
// datapath as family2 -- same core top, same multi-stream download mapper, and
// same per-profile input mapper -- with the full family memory reservation and
// both physical sound-board implementations:
//
//   family2 : legacy 4 MB CVSD-only engineering flavour
//   full    : 8 MB graphics (MK/T2 need it), CVSD + ADPCM selected by game_id
//
// It deliberately does NOT reuse the older `yunit_top` family core: that top
// was superseded by the cabinet-proven family2 rebase. Everything below keys
// off YUNIT_F2_DATAPATH so the family and full flavours cannot drift apart.
//
// The 8 MB map is the one the pre-existing `else` branches already describe
// (ROMW_BASE_DL 0x400000, GFX_BYTES 0x800000), so YUNIT_FULL falls into them
// by construction rather than by a duplicated set of constants.
// ---- AUDIO-SPLIT SIBLINGS -------------------------------------------------------------
// The all-title FULL core was rejected on the cabinet, and carrying BOTH sound boards is
// what forced CVSD sound off its cabinet-proven BRAM residence onto SDRAM (the three
// smashtv_snd_rom images measure 192 of 553 M10K). Splitting by sound board gives each
// sibling the headroom to do the right thing:
//
//   YUNIT_FAMILY2 (+ -DYUNIT_CVSD_BRAM_SOUND) = the CVSD sibling: 7 CVSD titles, 4 MB map,
//       sound back in BRAM for the four 64 KiB sets. Already fitted at 501/553.
//   YUNIT_ADPCM                               = the ADPCM sibling: MK / T2 / Total Carnage,
//       8 MB map (MK/T2 need it), no CVSD board at all. ~317/553.
//
// YUNIT_ADPCM defines YUNIT_FULL rather than replacing it, following the
// YUNIT_SMASH_RECOVERY -> YUNIT_LEGACY_SMASH_ABI precedent above. That is deliberate and
// load-bearing: YUNIT_FULL is OVERLOADED -- only two of its sites select sound, the rest
// select the 8 MB map and the video hierarchy. A token that replaced it would silently swap
// the video datapath as well.
`ifdef YUNIT_ADPCM
 `define YUNIT_FULL
`endif
`ifdef YUNIT_FULL
 `define YUNIT_F2_DATAPATH
`endif
`ifdef YUNIT_FAMILY2
 `define YUNIT_F2_DATAPATH
`endif
`ifdef YUNIT_LEGACY_SMASH_ABI
// Preserve the cabinet-good Smash-only controller ABI.  Four named game
// buttons means hps_io assigns Fire to joystick bits 4..7, then Start/Coin to
// bits 8/9 exactly as the firefix/mixboot wrapper and recovery mapper expect.
// The current CRT controls retain their existing status-bit allocation; they
// do not add game buttons and therefore cannot move Start/Coin.
localparam CONF_STR = {
	"A.SMASHTV;;",
	"O1,Aspect Ratio,4:3,16:9;",
	"O46,Scandoubler Fx,None,HQ2x,CRT 25%,CRT 50%,CRT 75%;",
	"P1,CRT Adjust;",
	"P1O[10],Enable,Off,On;",
	"H1P1O[15:11],CRT H-Size,0,-1,-2,-3,-4;",
	"H1P1O[22:16],CRT H-Position,0,+1,+2,+3,+4,+5,+6,+7,+8,+9,+10,+11,+12,+13,+14,+15,+16,+17,+18,+19,+20,+21,+22,+23,+24,+25,+26,+27,+28,+29,+30,+31,+32,+33,+34,+35,+36,+37,+38,+39,+40,+41,+42,+43,+44,-4,-3,-2,-1;",
	"H1P1O[27:23],CRT V-Shift,0,+1,+2,+3,+4,+5,+6,+7,+8,+9,+10,+11,+12,+13,-12,-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1;",
	"-;",
	"DIP;",
	"-;",
	"R0,Reset;",
	"J1,Fire Up,Fire Down,Fire Left,Fire Right,Start,Coin,Pause;",
	"jn,A,B,X,Y,Start,Select,R;",
	"V,v",`BUILD_DATE
};
`else
localparam CONF_STR = {
	"A.YUNIT;;",
	"O1,Aspect Ratio,4:3,16:9;",
	"O46,Scandoubler Fx,None,HQ2x,CRT 25%,CRT 50%,CRT 75%;",
	"P1,CRT Adjust;",
	"P1O[10],Enable,Off,On;",
	"H1P1O[15:11],CRT H-Size,0,-1,-2,-3,-4;",
	"H1P1O[22:16],CRT H-Position,0,+1,+2,+3,+4,+5,+6,+7,+8,+9,+10,+11,+12,+13,+14,+15,+16,+17,+18,+19,+20,+21,+22,+23,+24,+25,+26,+27,+28,+29,+30,+31,+32,+33,+34,+35,+36,+37,+38,+39,+40,+41,+42,+43,+44,-4,-3,-2,-1;",
	"H1P1O[27:23],CRT V-Shift,0,+1,+2,+3,+4,+5,+6,+7,+8,+9,+10,+11,+12,+13,-12,-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1;",
	"-;",
	"DIP;",
	"-;",
	"O7,Autosave NVRAM,Off,On;",
	"T8,Save NVRAM;",
	"T9,Clear NVRAM;",
	"-;",
	// The Autoerase On/Off entry (O2) is RETIRED from the OSD. It was a
	// triage lever for the page-flip flash; the erase engine is now
	// root-caused and gated (base-follow + per-leg erase-base gate), the
	// toggle required a reset to take effect, and Off actively breaks every
	// title (no erase = stale-page smearing) -- a pure footgun for users.
	// Status bit 2 stays reserved; autoerase_off is tied off below so the
	// engine ships always-on, identical to the toggle's default.
	"R0,Reset;",
	"J1,Button 1,Button 2,Button 3,Button 4,Button 5,Button 6,Start,Coin;",
	"jn,A,B,X,Y,L,R,Start,Select;",
	"V,v",`BUILD_DATE
};
`endif

////////////////////////////////////////////////////////////////////////////////
// CLOCKS — clk_sys/clk_sdram = 96 MHz (SDRAM+CPU+video), clk_snd = 12 MHz (CVSD)
////////////////////////////////////////////////////////////////////////////////
wire clk_sys, clk_sdram, clk_snd, clk_cpu;
wire locked;

pll pll
(
	.rst(RESET),
	.refclk(CLK_50M),
	.outclk_0(clk_sys),      // 96 MHz
	.outclk_1(clk_sdram),    // 96 MHz, phase-shifted for the SDRAM chip
	.outclk_2(clk_snd),      // 12 MHz sound-board clock
	.outclk_3(clk_cpu),      // 24 MHz CPU clock (TMS34010 execute path maxes ~30 MHz)
	.locked(locked)
);

// pixel-clock enable: 96 MHz / 12 = 8 MHz (Smash T.V. pixel clock)
reg [3:0] cediv = 0;
wire ce_pix = (cediv == 4'd0);
always @(posedge clk_sys) cediv <= (cediv == 4'd11) ? 4'd0 : cediv + 4'd1;

////////////////////////////////////////////////////////////////////////////////
// HPS IO
////////////////////////////////////////////////////////////////////////////////
wire  [1:0] buttons;
wire [31:0] status;
wire        forced_scandoubler;
wire [21:0] gamma_bus;
wire        direct_video;

wire [24:0] ioctl_addr;
wire  [7:0] ioctl_dout;
wire        ioctl_wr;
wire        ioctl_download;
wire        ioctl_upload;
wire        ioctl_rd;
wire        ioctl_upload_req;
wire  [7:0] ioctl_din;
wire  [7:0] ioctl_index;

wire [15:0] joystick_0, joystick_1, joystick_2, joystick_3;
wire [15:0] joy_l_analog_0, joy_l_analog_1;
wire [15:0] joy_r_analog_0, joy_r_analog_1;

hps_io #(.CONF_STR(CONF_STR)) hps_io
(
	.clk_sys(clk_sys),
	.HPS_BUS(HPS_BUS),

	.buttons(buttons),
	.status(status),
	.status_menumask({14'd0, ~status[10], direct_video}),
	.forced_scandoubler(forced_scandoubler),
	.gamma_bus(gamma_bus),
	.direct_video(direct_video),

	.ioctl_addr(ioctl_addr),
	.ioctl_dout(ioctl_dout),
	.ioctl_wr(ioctl_wr),
	.ioctl_wait(yt_ioctl_wait),      // SDRAM download backpressure (from yunit_top)
	.ioctl_download(ioctl_download),
	.ioctl_upload(ioctl_upload),
	.ioctl_upload_req(ioctl_upload_req),
	.ioctl_upload_index(8'd4),
	.ioctl_din(ioctl_din),
	.ioctl_rd(ioctl_rd),
	.ioctl_index(ioctl_index),

	.joystick_0(joystick_0),
	.joystick_1(joystick_1),
	.joystick_2(joystick_2),
	.joystick_3(joystick_3),
	.joystick_l_analog_0(joy_l_analog_0),
	.joystick_l_analog_1(joy_l_analog_1),
	.joystick_r_analog_0(joy_r_analog_0),
	.joystick_r_analog_1(joy_r_analog_1)
);
wire yt_ioctl_wait;

////////////////////////////////////////////////////////////////////////////////
// CMOS PERSISTENCE — one canonical 32 KiB image for every Y-unit profile.
////////////////////////////////////////////////////////////////////////////////
wire        nvram_loading;
wire        nvram_dirty;
wire        cmos_quiesce;
wire        nvram_ext_en;
wire        nvram_ext_wr;
wire [14:0] nvram_ext_addr;
wire  [7:0] nvram_ext_wdata;
wire  [7:0] nvram_ext_rdata;
wire        cmos_cpu_busy;
wire        cmos_cpu_write_pulse;

yunit_nvram_bridge #(.NVRAM_BYTES(32768)) nvram_bridge (
	.clk(clk_sys),
	.rst_pon(rst_pon),
	.ioctl_download(ioctl_download),
	.ioctl_upload(ioctl_upload),
	.ioctl_wr(ioctl_wr),
	.ioctl_index(ioctl_index),
	.ioctl_addr(ioctl_addr),
	.ioctl_dout(ioctl_dout),
	.ioctl_din(ioctl_din),
	.ioctl_upload_req(ioctl_upload_req),
	.autosave(status[7]),
	.manual_save(status[8]),
	.clear_nvram(status[9]),
	.osd_status(OSD_STATUS),
	.cpu_write_pulse(cmos_cpu_write_pulse),
	.cmos_cpu_busy(cmos_cpu_busy),
	.cmos_quiesce(cmos_quiesce),
	.nvram_ext_en(nvram_ext_en),
	.nvram_ext_wr(nvram_ext_wr),
	.nvram_ext_addr(nvram_ext_addr),
	.nvram_ext_wdata(nvram_ext_wdata),
	.nvram_ext_rdata(nvram_ext_rdata),
	.nvram_loading(nvram_loading),
	.nvram_dirty(nvram_dirty)
);

////////////////////////////////////////////////////////////////////////////////
// VIDEO
////////////////////////////////////////////////////////////////////////////////
wire [7:0] r, g, b;
wire       hsync, vsync, hblank, vblank, de;

// boot-instrument taps + overlay video (driven later by the core + smashtv_diag2_overlay)
wire [31:0] dbg_pc; wire dbg_illegal, dbg_core_rst, dbg_sdram_ready, dbg_unp_done, dbg_cpu_req, dbg_mem_ack;
wire dbg_int1, dbg_vblank_irq, dbg_cpu_ce;
wire [31:0] dbg_p1ctrl, dbg_bdir;          // fire-chain watches from yunit_mem
wire [7:0]  dbg_snd_select; wire dbg_snd_trig;   // sound-latch live copies
wire dbg_derailed; wire [31:0] dbg_culprit_pc, dbg_derail_pc; wire [15:0] dbg_culprit_instr;
// cont.24 splash-capture taps (used by the DIAG_SPLASHCAP capture below; harmless wires otherwise)
wire dbg_dma_we; wire [3:0] dbg_dma_addr; wire [15:0] dbg_dma_wdata;
wire [7:0] dbg_src_data; wire dbg_src_ack; wire [15:0] dbg_scan_data; wire dbg_scan_ack;
wire [31:0] dbg_iol_drop, dbg_iol_wrs;      // P0020 download audit (dropped / accepted FIFO pushes)
wire [31:0] dbg_disp_flips, dbg_disp_rows;  // display-base instrument (DIAG_DISPBASE)
wire [31:0] dbg_blit_total, dbg_blit_thin;  // thin-blit census (DIAG_THINBLIT)
// F4 cabinet service instrument (+define+DIAG_SERVICE) — per-frame SDRAM/sound/raster counters.
wire [15:0] dbg_cgfx_grants, dbg_snd_grants, dbg_snd_miss, dbg_snd_busy16;
wire [15:0] dbg_cvsd_moves, dbg_adpcm_moves, dbg_blank_pix, dbg_restart_cnt;
wire [31:0] dbg_cgfx_maxwait, dbg_cpu_pc_moves, dbg_snd_acks, dbg_snd_first_words;
wire        dbg_snd_region_seen, dbg_snd_board_rst;
wire [7:0] ov_r, ov_g, ov_b; wire ov_hs, ov_vs, ov_hb, ov_vb, ov_de;
wire [7:0] sv_r, sv_g, sv_b; wire sv_hs, sv_vs, sv_hb, sv_vb, sv_de;

// arcade_video source: the boot overlay under +define+DIAG_BOOT, else the real core.
`ifdef DIAG_BOOT
wire [7:0] av_r = ov_r, av_g = ov_g, av_b = ov_b;
wire       av_hs = ov_hs, av_vs = ov_vs, av_hb = ov_hb, av_vb = ov_vb;
`elsif DIAG_SERVICE
wire [7:0] av_r = sv_r, av_g = sv_g, av_b = sv_b;
wire       av_hs = sv_hs, av_vs = sv_vs, av_hb = sv_hb, av_vb = sv_vb;
`else
wire [7:0] av_r = r, av_g = g, av_b = b;
wire       av_hs = hsync, av_vs = vsync, av_hb = hblank, av_vb = vblank;
`endif

// Core-side CRT geometry adjustment. The universal Y-unit raster remains
// native 506x289 at 54.71 Hz; this line-buffer stage only changes pixel hold
// time and sync position while preserving line/frame cadence. With the option
// Off, its external mux is a bit-for-bit native passthrough.
wire [7:0] crt_r, crt_g, crt_b;
wire       crt_hs, crt_vs, crt_hb, crt_vb, crt_ce_pix;
yunit_crt_adjust u_yunit_crt_adjust (
	.clk         (clk_sys),
	.ce_pix      (ce_pix),
	.active_in   (status[10]),
	.hsize_code  (status[15:11]),
	.hpos_code   (status[22:16]),
	.vshift_code (status[27:23]),
	.r_in        (av_r),
	.g_in        (av_g),
	.b_in        (av_b),
	.hs_in       (av_hs),
	.vs_in       (av_vs),
	.hb_in       (av_hb),
	.vb_in       (av_vb),
	.ce_pix_out  (crt_ce_pix),
	.r_out       (crt_r),
	.g_out       (crt_g),
	.b_out       (crt_b),
	.hs_out      (crt_hs),
	.vs_out      (crt_vs),
	.hb_out      (crt_hb),
	.vb_out      (crt_vb)
);

arcade_video #(.WIDTH(512), .DW(24)) arcade_video
(
	.clk_video(clk_sys),
	.ce_pix(crt_ce_pix),
	.RGB_in({crt_r, crt_g, crt_b}),
	.HBlank(crt_hb),
	.VBlank(crt_vb),
	.HSync(crt_hs),
	.VSync(crt_vs),

	.CLK_VIDEO(CLK_VIDEO),
	.CE_PIXEL(CE_PIXEL),
	.VGA_R(VGA_R),
	.VGA_G(VGA_G),
	.VGA_B(VGA_B),
	.VGA_HS(VGA_HS),
	.VGA_VS(VGA_VS),
	.VGA_DE(VGA_DE),
	.VGA_SL(VGA_SL),

	.fx(status[6:4]),
	.forced_scandoubler(forced_scandoubler),
	.gamma_bus(gamma_bus)
);

////////////////////////////////////////////////////////////////////////////////
// ROM DOWNLOAD — independent MRA streams for the runtime Y-unit profile, raw
// 4bpp/6bpp graphics planes, the two TMS34010 program-ROM lanes, and either a
// CVSD or ADPCM sound-board image. Graphics are unpacked to one byte per pixel;
// program lanes and sound bytes are packed into fixed SDRAM regions.
////////////////////////////////////////////////////////////////////////////////
// Generic multi-index ABI:
//   index 3: one-byte game profile
//   index 0: raw graphics planes (variable length)
//   index 1: 0x80000-byte low lane + 0x80000-byte high lane
//   index 2: sound-board ROM stream
// Program ROM occupies a fixed 1MB Y-unit window.  Early 0x20000/0x40000
// lane sets are padded by their MRAs; MK/Terminator 2 fill the entire window.
`ifndef YUNIT_SMASH_RECOVERY
localparam [24:0] DL_ROMHI_BASE = 25'h080000;
localparam [24:0] SCRATCH_WBASE = 25'h500000;
// The download mapper must write program ROM exactly where the selected core
// top expects it, and the two flavours no longer agree: family2 sizes its gfx
// region to the legacy CVSD scope (4MB -> ROMW 0x200000), while FULL keeps the
// all-title 8MB reservation (ROMW 0x400000). Sharing one constant
// silently pointed one of them at the other's map -- caught by the production
// ROM contract test, which pins download base == the top's ROMW_BASE.
`ifdef YUNIT_FAMILY2
localparam [24:0] ROMW_BASE_DL  = 25'h200000;
`else
localparam [24:0] ROMW_BASE_DL  = 25'h400000;
`endif
// Keep sound separate from the largest raw graphics scratch span.  Sharing
// 0x500000 made correctness depend on framework download/unpack ordering.
localparam [24:0] SOUNDW_BASE   = 25'h800000;

wire [3:0] game_id_raw;
`ifdef YUNIT_ADPCM
// The ADPCM core boots only MK(5)/T2(6)/TC(7), whose ids share bits[3:2] ==
// 2'b01. Tying them structurally makes every per-title case on game_id
// statically unreachable outside the family -- a design-wide runtime-mux
// fold (the 4:1-mux-as-wide-LUT class, 1.00 wide ALUT/bit measured) aimed at
// the config's routing pressure (four rotating ~-0.14 ns cones, r8a..r13).
// An out-of-family MRA maps to a defined in-family id (wrong game, no X) --
// this RBF ships only with the three ADPCM MRAs.
wire [3:0] game_id = {2'b01, game_id_raw[1:0]};
`else
wire [3:0] game_id = game_id_raw;
`endif

wire        gfx_download;
wire        rom_download;
wire        sound_download = ioctl_download & (ioctl_index == 8'd2);

// ---- planes (packed 2 bytes/word, be=11) + program ROM (byte-interleaved via be) ---
// The 34010 word @ROMW+j is {u89[j] high, u105[j] low} (verified against the golden
// maindata.hex), so u105 writes the LOW lane (be=01) and u89 the HIGH lane (be=10) of
// the same word — a deterministic on-chip interleave (no MRA interleave map needed).
wire        yt_ioctl_wr;
wire [24:0] yt_ioctl_addr;
wire [15:0] yt_ioctl_dout;
wire  [1:0] yt_ioctl_be;
wire        yt_snd_wr;
wire [17:0] yt_snd_addr;
wire  [7:0] yt_snd_data;

// family2 rides the SAME multi-stream family MRA layout through its OWN
// mapper clone (family2/family2_download_mapper.sv, lockstep-gated against
// this proven module by tb_family2_download_mapper). The coherent triple is
// family MRAs + multi-stream mapper + family physical map -- never mixed
// with the legacy single-stream Smash package (HANDOFF section 3 failure #4).
`ifdef YUNIT_F2_DATAPATH
family2_download_mapper #(
	.DL_ROMHI_BASE(DL_ROMHI_BASE),
	.SCRATCH_WBASE(SCRATCH_WBASE),
	.ROMW_BASE(ROMW_BASE_DL),
	.SOUNDW_BASE(SOUNDW_BASE)
) download_mapper (
`else
yunit_download_mapper #(
	.DL_ROMHI_BASE(DL_ROMHI_BASE),
	.SCRATCH_WBASE(SCRATCH_WBASE),
	.ROMW_BASE(ROMW_BASE_DL),
	.SOUNDW_BASE(SOUNDW_BASE)
) download_mapper (
`endif
	.clk(clk_sys),
	.ioctl_download(ioctl_download),
	.ioctl_wr(ioctl_wr),
	.ioctl_index(ioctl_index),
	.ioctl_addr(ioctl_addr),
	.ioctl_dout(ioctl_dout),
	.game_id(game_id_raw),
	.gfx_download(gfx_download),
	.rom_download(rom_download),
	.mapped_wr(yt_ioctl_wr),
	.mapped_addr(yt_ioctl_addr),
	.mapped_dout(yt_ioctl_dout),
	.mapped_be(yt_ioctl_be),
	.snd_wr(yt_snd_wr),
	.snd_addr(yt_snd_addr),
	.snd_data(yt_snd_data)
);
`else
// Exact cabinet-good firefix/mixboot index-0 ABI. Keeping this separate from
// the family mapper makes an incompatible MRA layout fail visibly instead of
// silently loading program or sound bytes as graphics.
localparam [24:0] SCRATCH_WBASE = 25'h120000;
localparam [24:0] ROMW_BASE_DL  = 25'h0c0000;
localparam [24:0] SOUNDW_BASE   = 25'h120000; // unused by direct CVSD loading

wire [3:0]  game_id = 4'd0; // YG_SMASHTV
wire        gfx_download;
wire        rom_download;
wire        sound_download;
wire        yt_ioctl_wr;
wire [24:0] yt_ioctl_addr;
wire [15:0] yt_ioctl_dout;
wire  [1:0] yt_ioctl_be;
wire        yt_snd_wr;
wire [17:0] yt_snd_addr;
wire  [7:0] yt_snd_data;

assign gfx_download    = rom_download && (ioctl_addr < 25'h120000);
assign sound_download  = rom_download && (ioctl_addr >= 25'h160000)
                                     && (ioctl_addr <  25'h190000);

smashtv_legacy_download_mapper #(
	.SCRATCH_WBASE(SCRATCH_WBASE),
	.ROMW_BASE(ROMW_BASE_DL)
) download_mapper (
	.clk(clk_sys),
	.ioctl_download(ioctl_download),
	.ioctl_wr(ioctl_wr),
	.ioctl_index(ioctl_index),
	.ioctl_addr(ioctl_addr),
	.ioctl_dout(ioctl_dout),
	.rom_download(rom_download),
	.mapped_wr(yt_ioctl_wr),
	.mapped_addr(yt_ioctl_addr),
	.mapped_dout(yt_ioctl_dout),
	.mapped_be(yt_ioctl_be),
	.snd_wr(yt_snd_wr),
	.snd_addr(yt_snd_addr),
	.snd_data(yt_snd_data)
);
`endif

// ---- P0021 download-path disambiguation (emu-side, reset on ~locked so it SURVIVES the core
//      reset — unlike yunit_top's FIFO counters). ytwr_cnt = # writes the remap FSM emitted
//      (NOT gated by reset). rst_during_dl = did the core reset overlap the download.
//   overlay row3 = {rst_during_dl, 11'b0, ytwr_cnt[19:0]}:
//     8xxxxxxx = reset was HIGH during download -> (b) FIFO frozen (row2 accepted=0 confirms)
//     000xxxxx, xxxxx>0 = FSM DID emit -> if row2 accepted still 0 & no rst-bit, it's a yt_ioctl_wr
//                         WIRING break between emu and yunit_top
//     00000000 = FSM never emitted -> (a) rom_download & ioctl_wr never true (index/connection)
reg [31:0] dl_ytwr_cnt;
reg        dl_rst_during;
always @(posedge clk_sys) begin
	if (~locked) begin dl_ytwr_cnt <= 32'd0; dl_rst_during <= 1'b0; end
	else begin
		if (yt_ioctl_wr)          dl_ytwr_cnt   <= dl_ytwr_cnt + 1'b1;
		if (rom_download & reset) dl_rst_during <= 1'b1;
	end
end
wire [31:0] dl_diag = {dl_rst_during, 11'b0, dl_ytwr_cnt[19:0]};

////////////////////////////////////////////////////////////////////////////////
// CONTROLS -> Y-unit input word {DSW, IN2, IN1, IN0} (active-low). The runtime
// mapper selects twin-stick, four-player, fighting, conventional, or light-gun
// wiring from the profile byte loaded by the MRA.
////////////////////////////////////////////////////////////////////////////////
wire [15:0] dsw_raw = {sw[1], sw[0]};
wire [63:0] inputs;
wire adpcm_irq;
// Twin-stick titles: move on the left stick, fire on the right, as digital
// OR-contributions ahead of the mapper (rest-bias latched -- see
// yunit_twinstick.sv for the cab-refuted +48-deadzone history). T2 receives
// left-stick direction bits only for its Test-mode menu aliases; the analog
// gun values below and every non-input path remain untouched.
wire [7:0] ts_joy0_or, ts_joy1_or;
yunit_twinstick twinstick (
	.clk(clk_sys), .reset(reset), .game_id(game_id),
	.l_analog_0(joy_l_analog_0), .r_analog_0(joy_r_analog_0),
	.l_analog_1(joy_l_analog_1), .r_analog_1(joy_r_analog_1),
	.joy0_or(ts_joy0_or), .joy1_or(ts_joy1_or)
);
wire [15:0] joy0_ts = joystick_0 | {8'h00, ts_joy0_or};
wire [15:0] joy1_ts = joystick_1 | {8'h00, ts_joy1_or};
`ifndef YUNIT_LEGACY_SMASH_ABI
`ifdef YUNIT_F2_DATAPATH
// family2's own mapper clone (tb_family2_inputs lockstep + anchor gates).
family2_cabinet_inputs input_mapper (
	.game_id(game_id), .joy0(joy0_ts), .joy1(joy1_ts),
	.joy2(joystick_2), .joy3(joystick_3), .dsw_raw(dsw_raw),
	.adpcm_irq(adpcm_irq), .inputs(inputs)
);
`else
yunit_input_mapper input_mapper (
	.game_id(game_id), .joy0(joy0_ts), .joy1(joy1_ts),
	.joy2(joystick_2), .joy3(joystick_3), .dsw_raw(dsw_raw),
	.adpcm_irq(adpcm_irq), .inputs(inputs)
);
`endif
`else
// The cabinet-good MRA uses the legacy Smash-only joystick numbering:
// fire=4..7, Start=8, Coin=9. Keep analog fire entirely outside this path.
smashtv_cabinet_inputs input_mapper (
	.joy0(joystick_0), .joy1(joystick_1),
	.dsw_raw(dsw_raw), .inputs(inputs)
);
`endif

// MAME's Terminator 2 ADC is unsigned/centered at 0x80 and reverses X.
// MiSTer supplies signed, centered joystick axes.
//
// P2's gun ALSO rides controller 0's RIGHT stick (summed signed deltas; both
// rest at 0, so with two pads P2's own left stick works untouched). T2's
// first-boot gun calibration demands a full min/max sweep of BOTH guns --
// with P2 reachable only from a second pad, one player could never leave the
// calibration screen (cabinet 2026-08-17: "got to a calibration screen, no
// in game"; same wall as the 08-16 "calibration needs two controllers").
wire [7:0] p2x_mix = joy_l_analog_1[7:0]  + joy_r_analog_0[7:0];
wire [7:0] p2y_mix = joy_l_analog_1[15:8] + joy_r_analog_0[15:8];
wire [7:0] term_p1x = 8'h80 - joy_l_analog_0[7:0];
wire [7:0] term_p1y = 8'h80 + joy_l_analog_0[15:8];
wire [7:0] term_p2x = 8'h80 - p2x_mix;
wire [7:0] term_p2y = 8'h80 + p2y_mix;
wire [31:0] term2_analog = {term_p2y,term_p2x,term_p1y,term_p1x};

////////////////////////////////////////////////////////////////////////////////
// GAME
////////////////////////////////////////////////////////////////////////////////
wire reset = RESET | status[0] | buttons[1] | ~locked | nvram_loading;
reg  rst_pon = 1'b1;
always @(posedge clk_sys) rst_pon <= RESET | ~locked;   // power-on only (sound board full reset)
// P0022: TRUE power-on for the PERSISTENT SDRAM/download subsystem. ~locked (PLL) synchronized
// into clk_sys (2-FF, clean removal). It is LOW during ANY ROM download (which always follows
// PLL lock), so the capture path keeps running even if the framework holds RESET high across
// the download — the black-screen root cause was that RESET froze the whole SDRAM path. This
// does NOT include RESET (rst_pon does), which is the whole point: rst_pon would freeze too.
reg  sdram_por_m = 1'b1, sdram_por = 1'b1;
always @(posedge clk_sys) begin sdram_por_m <= ~locked; sdram_por <= sdram_por_m; end

// FIRE-BUG ROOT CAUSE (2026-07-21, chain-diag + ROM dasm @FFE1E300): rev 8.00 IMPLEMENTS the
// "Rotary Joystick Enable" DIP (DSW bit 14, DS2:2 — MAME's comment wondered; it's real): bit14=0
// (On) takes B_DIR from a rotary position byte and NEVER calls FIRE_DIRECTION -> with no rotary
// hardware, every shot fires DOWN. sw[] powered up 0 and the MRA had no <switches> section, so
// DSW read 0x0000 = rotary ON (+ test-DIP On, coinage 0). Keep MAME's 0xFFFF defaults, while the
// input guard above additionally forces only bit14 Off so diagnostics/OSD persistence cannot
// re-enable a hardware mode this core does not implement.
reg [7:0] sw[2];
initial begin sw[0] = 8'hFF; sw[1] = 8'hFF; end
always @(posedge clk_sys)
	if (ioctl_wr && (ioctl_index == 254) && !ioctl_addr[24:1]) sw[ioctl_addr[0]] <= ioctl_dout;

// Core-top selection: the real Y-unit core, or (with +define+DIAG_SDRAM) the self-contained
// SDRAM loopback diagnostic (rtl/diag/smashtv_diag_top.sv) — same ports, so no rewiring. The
// diagnostic discards the CPU and paints the SDRAM read/write self-test result to the screen.
`ifdef DIAG_ROM
 `define CORE_TOP smashtv_diag_rom
`elsif DIAG_SDRAM
 `define CORE_TOP smashtv_diag_top
`elsif YUNIT_SMASH_RECOVERY
 `define CORE_TOP yunit_top_smash_firefix
`elsif YUNIT_F2_DATAPATH
 `define CORE_TOP yunit_top_family2
`else
 `define CORE_TOP yunit_top
`endif
`CORE_TOP #(
	.ROM_HEX(""),
`ifdef YUNIT_SMASH_RECOVERY
	// Exact physical map used by the cabinet-good firefix/mixboot image.
	.GFXW_BASE(25'h000000), .ROMW_BASE(25'h0c0000),
	.VRAMW_BASE(25'h0e0000), .GFX_BYTES(24'h180000),
	.SCRATCH_WBASE(25'h120000), .SOUNDW_BASE(25'h120000)
`elsif YUNIT_FAMILY2
	// The family physical map on the rebased hierarchy: full 1MB program
	// window at offset 0 (family MRAs pad both lanes).
	//
	// GFX_BYTES IS SIZED TO THIS BUILD'S SCOPE, NOT THE WHOLE FAMILY. The CVSD
	// titles' largest unpacked image is Super High Impact: yunit_plane_words
	// 0x80000 x 8 pixels/word = 0x400000. Only the ADPCM trio (MK, Terminator 2
	// at 0x100000 plane-words) needs 0x800000, and they are out of scope until
	// P2 ships the ADPCM board. Reserving 8MB here cost real timing: GFX_BYTES
	// is passed to BOTH the memory region math and the shared SDRAM arbiter's
	// gfx/ROM split, widening compares on the critical DDR3/VRAM cone for
	// address space no CVSD title can reach. P2 raises this back to 0x800000
	// together with the ADPCM hierarchy.
	//
	// The map invariant still holds by construction:
	//   ROMW_BASE  = GFXW_BASE + GFX_BYTES/2 = 0x200000
	//   VRAMW_BASE = ROMW_BASE + ROM_WORDS   = 0x280000
	.GFXW_BASE(25'h000000), .ROMW_BASE(25'h200000),
	.VRAMW_BASE(25'h280000), .GFX_BYTES(24'h400000),
	.SCRATCH_WBASE(25'h500000), .SOUNDW_BASE(25'h800000),
	.ROM_WORDS(32'h80000), .ROM_WORD_OFFSET(32'h00000)
`else
	.GFXW_BASE(25'h000000), .ROMW_BASE(25'h400000),
	.VRAMW_BASE(25'h480000), .GFX_BYTES(24'h800000),
	.SCRATCH_WBASE(25'h500000), .SOUNDW_BASE(25'h800000),
	.ROM_WORDS(32'h80000), .ROM_WORD_OFFSET(32'h00000)
`endif
) yunit_top
(
	.clk(clk_sys),
	.clk_cpu(clk_cpu),
	.ce_pix(ce_pix),
	.cpu_div_sel(3'd0),          // legacy port; execution cadence is profile-owned
	.clk_snd(clk_snd),
	.rst(reset),
	.rst_pon(rst_pon),
	.sdram_por(sdram_por),

	.inputs(inputs),
	.game_id(game_id),
	.term2_analog(term2_analog),
	.cmos_quiesce(cmos_quiesce),
	.nvram_ext_en(nvram_ext_en),
	.nvram_ext_wr(nvram_ext_wr),
	.nvram_ext_addr(nvram_ext_addr),
	.nvram_ext_wdata(nvram_ext_wdata),
	.nvram_ext_rdata(nvram_ext_rdata),
	.cmos_cpu_busy(cmos_cpu_busy),
	.cmos_cpu_write_pulse(cmos_cpu_write_pulse),

	.ioctl_download(rom_download),
	.gfx_download(gfx_download),
	.sound_download(sound_download),
	.ioctl_wr(yt_ioctl_wr),
	.ioctl_addr(yt_ioctl_addr),
	.ioctl_dout(yt_ioctl_dout),
	.ioctl_be(yt_ioctl_be),
	.ioctl_wait(yt_ioctl_wait),

	.snd_dl_wr(yt_snd_wr),
	.snd_dl_addr(yt_snd_addr),
	.snd_dl_data(yt_snd_data),

	.SDRAM_DQ(SDRAM_DQ),
	.SDRAM_A(SDRAM_A),
	.SDRAM_BA(SDRAM_BA),
	.SDRAM_DQML(SDRAM_DQML),
	.SDRAM_DQMH(SDRAM_DQMH),
	.SDRAM_nCS(SDRAM_nCS),
	.SDRAM_nRAS(SDRAM_nRAS),
	.SDRAM_nCAS(SDRAM_nCAS),
	.SDRAM_nWE(SDRAM_nWE),
	.SDRAM_CKE(SDRAM_CKE),

	.DDRAM_ADDR(DDRAM_ADDR),
	.DDRAM_BURSTCNT(DDRAM_BURSTCNT),
	.DDRAM_RD(DDRAM_RD),
	.DDRAM_DIN(DDRAM_DIN),
	.DDRAM_BE(DDRAM_BE),
	.DDRAM_WE(DDRAM_WE),
	.DDRAM_BUSY(DDRAM_BUSY),
	.DDRAM_DOUT(DDRAM_DOUT),
	.DDRAM_DOUT_READY(DDRAM_DOUT_READY),

	.vid_r(r), .vid_g(g), .vid_b(b),
	.hsync(hsync), .vsync(vsync), .hblank(hblank), .vblank(vblank), .de(de),

	.audio_l(AUDIO_L), .audio_r(AUDIO_R), .adpcm_irq(adpcm_irq),

	.pc_dbg(dbg_pc), .illegal_dbg(dbg_illegal),
	.dbg_core_rst(dbg_core_rst), .dbg_sdram_ready(dbg_sdram_ready), .dbg_unp_done(dbg_unp_done),
	.dbg_cpu_req(dbg_cpu_req), .dbg_mem_ack(dbg_mem_ack),
	.dbg_int1(dbg_int1), .dbg_vblank_irq(dbg_vblank_irq), .dbg_cpu_ce(dbg_cpu_ce),
	.dbg_p1ctrl(dbg_p1ctrl), .dbg_bdir(dbg_bdir),
	.dbg_snd_select(dbg_snd_select), .dbg_snd_trig(dbg_snd_trig),
	.dbg_derailed(dbg_derailed), .dbg_culprit_pc(dbg_culprit_pc),
	.dbg_culprit_instr(dbg_culprit_instr), .dbg_derail_pc(dbg_derail_pc),
	.dbg_disp_flips(dbg_disp_flips), .dbg_disp_rows(dbg_disp_rows),
	.dbg_blit_total(dbg_blit_total), .dbg_blit_thin(dbg_blit_thin),
	.autoerase_off(1'b0),                // OSD toggle retired; erase always on (gospel)
	.dbg_iol_drop(dbg_iol_drop), .dbg_iol_wrs(dbg_iol_wrs),
	.dbg_dma_we(dbg_dma_we), .dbg_dma_addr(dbg_dma_addr), .dbg_dma_wdata(dbg_dma_wdata),
	.dbg_src_data(dbg_src_data), .dbg_src_ack(dbg_src_ack),
	.dbg_scan_data(dbg_scan_data), .dbg_scan_ack(dbg_scan_ack),
	// F4 service instrument (zero unless the core was built with -DDIAG_SERVICE)
	.dbg_cgfx_grants(dbg_cgfx_grants), .dbg_snd_grants(dbg_snd_grants),
	.dbg_cgfx_maxwait(dbg_cgfx_maxwait),
	.dbg_snd_miss(dbg_snd_miss), .dbg_snd_busy16(dbg_snd_busy16),
	.dbg_cvsd_moves(dbg_cvsd_moves), .dbg_adpcm_moves(dbg_adpcm_moves),
	.dbg_blank_pix(dbg_blank_pix), .dbg_cpu_pc_moves(dbg_cpu_pc_moves),
	.dbg_snd_acks(dbg_snd_acks), .dbg_snd_first_words(dbg_snd_first_words),
	.dbg_snd_region_seen(dbg_snd_region_seen), .dbg_snd_board_rst(dbg_snd_board_rst),
	.dbg_restart_cnt(dbg_restart_cnt)
);

// ---- boot-instrument overlay (+define+DIAG_BOOT): paints the real core's boot state ----
`ifdef DIAG_BOOT
// ---- DDR3 SCANOUT-HEALTH MONITOR (isolate MEMORY vs VIDEO on the cab) ------------------------
// Watches the REAL f2sdram Avalon traffic (DDRAM_* are emu-level, so no core re-threading). A
// read is accepted on (RD & ~BUSY) carrying BURSTCNT beats; each DOUT_READY is one beat. If beats
// stop arriving before the burst is met (>~1500 clk idle mid-burst) the bridge UNDER-DELIVERED
// the burst = the scanout wedge. Single-outstanding (the agent), so one FSM tracks it.
//   ddr_wedge (sticky) -> status bar RED  => the burst STILL under-delivers on silicon (drop BMAX).
//   ddr_wedge 0 + row3 counters climbing   => DDR3 reads COMPLETE (fix landed) -> the garbage is
//                                             DOWNSTREAM (video/palette/page), not memory.
//   row 3 (8 hex) = {DDR reads[15:0], DDR beats[15:0]} -- both should climb together when healthy.
reg [15:0] ddr_reads=16'd0, ddr_beats=16'd0; reg [7:0] ddr_expect=8'd0; reg [11:0] ddr_idle=12'd0;
reg ddr_outst=1'b0, ddr_wedge=1'b0;
always @(posedge clk_sys) begin
	if (~locked) begin ddr_reads<=0; ddr_beats<=0; ddr_expect<=0; ddr_idle<=0; ddr_outst<=0; ddr_wedge<=0; end
	else if (DDRAM_RD & ~DDRAM_BUSY & ~ddr_outst) begin           // burst accepted
		ddr_reads<=ddr_reads+16'd1; ddr_expect<=DDRAM_BURSTCNT; ddr_outst<=1'b1; ddr_idle<=12'd0;
	end else if (ddr_outst) begin
		if (DDRAM_DOUT_READY) begin                                // a beat arrived
			ddr_beats<=ddr_beats+16'd1; ddr_idle<=12'd0;
			ddr_outst<=(ddr_expect>8'd1); ddr_expect<=ddr_expect-8'd1;
		end else begin                                             // mid-burst stall -> wedge
			ddr_idle<=ddr_idle+12'd1; if (ddr_idle>12'd1500) ddr_wedge<=1'b1;
		end
	end
end
wire [31:0] ddr_stat = {ddr_reads, ddr_beats};

// WRITE-side health (P1.5 RMW fix). The cab white/purple was masked single-beat writes clobbering
// the 3 neighbor entries of a shared 64-bit beat (the real f2h_sdram1 drops per-byte BE on a 1-beat
// write). The fix makes EVERY VRAM write a FULL-beat write (be=FF) -- which is immune to BE-drop by
// construction (all 8 bytes written regardless of how the bridge treats BE). So on a healthy silicon
// fix, ddr_masked stays 0 (no be!=FF write ever slips through) and ddr_writes climbs as the blitter
// draws. A masked write here => the RMW path is NOT active => status bar RED.
reg [15:0] ddr_writes=16'd0; reg ddr_masked=1'b0;
always @(posedge clk_sys) begin
	if (~locked) begin ddr_writes<=16'd0; ddr_masked<=1'b0; end
	else if (DDRAM_WE & ~DDRAM_BUSY) begin
		ddr_writes <= ddr_writes + 16'd1;
		if (DDRAM_BE != 8'hFF) ddr_masked <= 1'b1;   // masked write = fix not active on silicon
	end
end

// ---- BLIT-COUNT MONITOR (cont.22): measure the blit-count DEFICIT vs MAME on the cab. dbg_int1 =
// the blitter done-IRQ (exactly one 0->1 edge per COMPLETED blit); dbg_vblank_irq = frame boundary.
// Sim proved our command DELIVERY is complete (all regs, correct values) in the correct-render
// config, so a low count here = the CPU is STARVED out of issuing blits (not dropping commands).
//   row 2 = blit_total[31:0]  (running count -- CLIMBS = blits happening; rate = throughput)
//   row 3 = {blit_max[15:0], blit_last[15:0]}  (PEAK-per-frame, last-frame)
// Let attract run through its screens; read row3 PEAK and compare to the MAME golden (mame-trace/
// dma_cmd.log: ~36 blits/frame avg, the high-score screen is the busiest). blit_max << MAME peak
// = the starvation deficit CONFIRMED (the missing text is blits the CPU never got to issue).
reg int1_d=1'b0, vbl_d=1'b0;
reg [31:0] blit_total=32'd0;
reg [15:0] blit_frame=16'd0, blit_last=16'd0, blit_max=16'd0;
always @(posedge clk_sys) begin
	int1_d <= dbg_int1; vbl_d <= dbg_vblank_irq;
	if (~locked) begin blit_total<=32'd0; blit_frame<=16'd0; blit_last<=16'd0; blit_max<=16'd0; end
	else begin
		if (dbg_int1 & ~int1_d) begin blit_total <= blit_total + 32'd1; blit_frame <= blit_frame + 16'd1; end
		if (dbg_vblank_irq & ~vbl_d) begin                              // frame boundary: latch + reset
			blit_last <= blit_frame;
			if (blit_frame > blit_max) blit_max <= blit_frame;
			blit_frame <= 16'd0;
		end
	end
end
wire [31:0] blit_stat = {blit_max, blit_last};

// RESET-EDGE COUNTER: the cheapest disproof of "our RTL is re-resetting the CPU" (the full
// pipeline+asm audit found NO watchdog model and NO periodic reset generator anywhere in this
// RTL -- `reset`/`core_rst` are a level-combinational OR of RESET/status[0]/buttons[1]/~locked,
// re-evaluated every clock, not edge-latched -- so nothing should re-fire it after the initial
// power-on drop UNLESS something external (PLL relock glitch, a stray OSD/button assert) does).
// Counts every RISING edge of `reset` in the ~locked-only domain (mirrors dl_ytwr_cnt below), so
// it SURVIVES core_rst and answers directly: repeat count stays at its post-boot value (usually 1,
// the initial power-up drop) = the cab's repeating white/purple loop is the GAME'S OWN software
// loop (BURN_IN, historicalsource/smashtv DIAG.ASM:269,500-502, which re-runs RAMCHECK+DSCRCLR+the
// chip screen every attract pass); count climbing = something IS re-asserting reset/core_rst on
// real silicon, a genuine RTL-side bug distinct from the DDR3-slowness/gating fixes already landed.
reg [15:0] rst_edge_cnt=16'd0; reg reset_d=1'b1;
always @(posedge clk_sys) begin
	if (~locked) begin rst_edge_cnt<=16'd0; reset_d<=1'b1; end
	else begin
		reset_d <= reset;
		if (reset & ~reset_d) rst_edge_cnt <= rst_edge_cnt + 16'd1;
	end
end

// ---- cont.24 SPLASH COMMAND-CAPTURE (+define+DIAG_SPLASHCAP): reconstruct the title-splash blit
// commands from the DMA reg-write stream and latch the LEFT (x=5) + RIGHT (x=315) blue-column
// blits, so the cab tells us whether our CPU issues the right command + whether the source reads
// nonzero. Golden (MAME f2050): LEFT cmd=8002 (unflip, bit4=0) SAG=026BD848/026D1688; RIGHT
// cmd=8002 SAG=027D5000/027E8E40; both source bytes NONZERO. Rows (read while the splash is up,
// ~30s no coin): row1=LEFT SAG, row2=LEFT cmd (bit4 set => spurious flip = (A) command corrupt),
// row3={LEFT srcbyte, RIGHT srcbyte, LEFT x, LEFT h} (LEFT srcbyte 00 while RIGHT !=00 => (B) HW
// source reads ZERO at ~0.86MB), row4=boot-scanout CRC (DIAG_BOOTSCAN) else RIGHT SAG.
`ifdef DIAG_INPUTS
// ---- LIVE INPUT-DELIVERY probe (fire-bug layer isolation, 2026-07-21) --------------------------
// Cab fact: fire-down works (shot + sound), the other three fire inputs produce NOTHING (no sound
// = the CPU never spawns the shot). Decode/spawn/packing are all proven bit-exact, movement and
// coin/start deliver -- so the fire nibble dies in the LIVE chain: pad -> hps_io -> joystick_0[7:4]
// / joy_r_analog_0 -> in0. This overlay shows every link at once. Press each fire input in turn:
//   row1 = {joystick_0 LIVE[15:0], STICKY-OR of joystick_0[15:0]}  (sticky = every bit ever seen
//          high since boot -- catches brief presses; expect sticky bits 4/5/6/7 to light as you
//          press Fire Up/Down/Left/Right; a bit that never lights = hps_io/pad layer drop)
//   row2 = in0 LIVE (active-low word the game reads; pressed fire = that bit LOW)
//   row3 = {joy_r_analog_0 [Y:X], STICKY-OR of ~in0}  (left 4 hex = live analog Y,X bytes -- move
//          the right stick, non-00 bytes = analog delivers; right 4 hex = active-in0 sticky)
//   row4 = live PC (CPU-running sanity)
// v2 (fire-CHAIN walk, 2026-07-21): input delivery was PROVEN healthy by v1 (sticky 00F0) and the
// field engine by tb_mem_field_matrix — the remaining unknowns are INSIDE the live game execution.
// These rows walk the chain P1CTRL -> FIRE_DIRECTION -> B_DIR -> spawn, plus the sound latch:
//   row1 = dbg_p1ctrl = {P1CTRL last value, write count}   (does the fire nibble reach the game var?
//          hold fire-up: expect xx1x in the high byte's low nibble... value bits [7:4] = fire nibble)
//   row2 = fdir_hits[15:0]  (count of PC==FFE32520 = FIRE_DIRECTION entries; 0 while firing =
//          the ENDON/nibble gate never passes -> blocker BEFORE the decode)
//   row3 = dbg_bdir = {B_DIR last value, write count}      (decode output: expect 1/2/4/7 per dir)
//   row4 = {snd_cnt[7:0], snd_last[7:0], in0}              (sound-latch strobe count + last command
//          + live in0; MAME golden: the start-sequence tune = ONE command ~FDA0/FFA0 pair)
reg [15:0] fdir_hits=16'd0;  reg [31:0] pc_d=32'd0;
reg [7:0]  snd_cnt=8'd0, snd_last=8'd0;  reg snd_trig_d=1'b0;
always @(posedge clk_sys) begin
	if (~locked) begin fdir_hits<=16'd0; pc_d<=32'd0; snd_cnt<=8'd0; snd_last<=8'd0; snd_trig_d<=1'b0; end
	else begin
		pc_d <= dbg_pc;
		if (dbg_pc == 32'hFFE32520 && pc_d != 32'hFFE32520) fdir_hits <= fdir_hits + 16'd1;
		snd_trig_d <= dbg_snd_trig;
		if (dbg_snd_trig & ~snd_trig_d) begin snd_cnt <= snd_cnt + 8'd1; snd_last <= dbg_snd_select; end
	end
end
wire [31:0] r1v = dbg_p1ctrl;
wire [15:0] r2v = fdir_hits;
wire [31:0] r3v = dbg_bdir;
wire [31:0] r4v = {snd_cnt, snd_last, in0};
`elsif DIAG_SPLASHCAP
reg [15:0] shx=0, shh=0, shol=0, shoh=0;
reg [15:0] Lcmd=0, Rcmd=0; reg [31:0] Lsag=0, Rsag=0; reg [7:0] Lx=0, Lh=0, Lsrcb=0, Rsrcb=0;
reg [15:0] Lany=0, Lmatch=0;   // Lany = last cmd of ANY blit at the left-col position (any mode);
reg [1:0]  pend=2'd0;          // Lmatch = # of READMODE left-col blits captured (splash validity)
// FILLCAP: capture whether the CPU issues narrow-tall (vertical) vs wide-short (horizontal) mode-C fills
reg [15:0] shw=0;                                  // WIDTH (DMA_WIDTH = addr 6)
reg [15:0] NVcnt=0, NWcnt=0, NVcmd=0;              // vertical-fill count, horizontal-fill count, last vert cmd
reg [7:0]  NVw=0, NVh=0; reg [15:0] NVx=0;         // last vertical fill W, H, x
reg [15:0] HWlat=0, HXlat=0;                       // last horizontal fill W, x (control)
// A blit is READMODE (reads gfx source) iff cmd[3:0] in 1..0xB; modes 0xC..0xF are constant FILLS
// (the per-frame left-edge ERASE is mode 0xC, and would otherwise masquerade as the column blit).
wire [15:0] trig_c = dbg_dma_wdata;
wire        rmode  = (trig_c[3:0]>=4'd1) && (trig_c[3:0]<=4'd11);
wire        lpos   = ($signed(shx)>=16'sd3)   && ($signed(shx)<=16'sd10)  && (shh>16'd100);
wire        rpos   = ($signed(shx)>=16'sd310) && ($signed(shx)<=16'sd320) && (shh>16'd100);
always @(posedge clk_sys) begin
	if (~locked) begin shx<=0;shh<=0;shol<=0;shoh<=0;Lcmd<=0;Rcmd<=0;Lsag<=0;Rsag<=0;Lx<=0;Lh<=0;Lsrcb<=0;Rsrcb<=0;Lany<=0;Lmatch<=0;pend<=2'd0;shw<=0;NVcnt<=0;NWcnt<=0;NVcmd<=0;NVw<=0;NVh<=0;NVx<=0;HWlat<=0;HXlat<=0; end
	else begin
		if (dbg_dma_we) begin
			if      (dbg_dma_addr==4'd4) shx <= dbg_dma_wdata;   // XSTART
			else if (dbg_dma_addr==4'd6) shw <= dbg_dma_wdata;   // WIDTH
			else if (dbg_dma_addr==4'd7) shh <= dbg_dma_wdata;   // HEIGHT
			else if (dbg_dma_addr==4'd2) shol<= dbg_dma_wdata;   // OFFSETLO
			else if (dbg_dma_addr==4'd3) shoh<= dbg_dma_wdata;   // OFFSETHI
			else if (dbg_dma_addr==4'd0 && trig_c[15]) begin     // COMMAND trigger
				if (trig_c[3:0]==4'hC) begin                     // FILLCAP: mode-C constant FILL -> classify shape
					if (shw<=16'd6 && shh>=16'd16) begin         // NARROW-TALL = a vertical box side
						NVcnt<=NVcnt+16'd1; NVcmd<=trig_c; NVw<=shw[7:0]; NVh<=shh[7:0]; NVx<=shx;
					end else if (shw>=16'd40 && shh<=16'd8) begin // WIDE-SHORT = a horizontal box side
						NWcnt<=NWcnt+16'd1; HWlat<=shw; HXlat<=shx;
					end
				end
				if (lpos) begin
					Lany <= trig_c;                              // any-mode cmd at left col (catches a corrupted fill)
					if (rmode) begin                             // the REAL readmode column blit
						Lcmd<=trig_c; Lsag<={shoh,shol}; Lx<=shx[7:0]; Lh<=shh[7:0];
						Lmatch<=Lmatch+16'd1; pend<=2'd1;
					end
				end else if (rpos && rmode) begin
					Rcmd<=trig_c; Rsag<={shoh,shol}; pend<=2'd2;
				end
			end
		end
		if (dbg_src_ack && pend!=2'd0) begin        // first source byte of the matched readmode blit
			if (pend==2'd1) Lsrcb<=dbg_src_data; else Rsrcb<=dbg_src_data;
			pend<=2'd0;
		end
	end
end
`ifdef DIAG_BOOTSCAN
// boot-noise scanout CRC vs MAME: accumulate the scanout stream over a boot window (RAM-test
// patterns, deterministic). Compare row4 to the MAME VRAM golden CRC (scene_boot golden).
reg [31:0] bscan_crc=0; reg [15:0] bscan_fr=0; reg bvbl_d=0;
always @(posedge clk_sys) begin
	if (~locked) begin bscan_crc<=0; bscan_fr<=0; bvbl_d<=0; end
	else begin
		bvbl_d <= dbg_vblank_irq;
		if (dbg_vblank_irq & ~bvbl_d) bscan_fr <= bscan_fr + 16'd1;
		if (dbg_scan_ack && bscan_fr>=16'd20 && bscan_fr<16'd120)
			bscan_crc <= {bscan_crc[30:0], bscan_crc[31]} ^ {16'd0, dbg_scan_data};
	end
end
wire [31:0] r4v_unused = bscan_crc;   // boot CRC confirmed stable (122FE75A); row4 now = validity
`endif
// row4 = {Lmatch, Lany}: Lmatch climbs => a READMODE left-column blit fired (we are on the splash +
// the column IS issued as readmode). Lany = last ANY-mode cmd at the left-col position. So:
//   Lmatch climbs, row2=8002        -> column readmode blit fires correctly (read rows 1-3)
//   Lmatch stuck 0, Lany=800C       -> the left-col blit fires ONLY as a FILL = (A) command wrong
//   Lmatch=0, Lany=0 on the splash  -> no left-col blit at all (upstream drop)
// FILLCAP retarget: does the CPU ISSUE the revision-box narrow-tall (W<=6,H>=16) mode-C verticals?
//   row1 r1v = {NVcnt, NWcnt}  -> vert-fill count (left 4 hex) | horiz-fill count (right 4 hex)  <== THE ANSWER
//   row2 r2v = NVcmd           -> 800C if a vertical fill EVER fired, 0000 if never
//   row3 r3v = {NVw,NVh,NVx}   -> last vertical geom: WW HH XXXX (expect 03 23 000A or 03 23 017D)
//   row4 r4v = {HWlat,HXlat}   -> horizontal control geom: WWWW XXXX (expect 0176 000A)
// READOUT on the REVISION screen: NVcnt>0 + row3=0323000A/017D => CPU DOES issue verticals => bug is
// DOWNSTREAM (write/display). NVcnt==0 while NWcnt>0 => CPU draws horizontals but NEVER verticals =>
// UPSTREAM command-gen bug (the whole write-path hunt was a phantom).
wire [31:0] r1v = {NVcnt, NWcnt};
wire [15:0] r2v = NVcmd;
wire [31:0] r3v = {NVw, NVh, NVx};
wire [31:0] r4v = {HWlat, HXlat};
`elsif DIAG_DISPBASE
// ---- DISPLAY-BASE AUDIT (+define+DIAG_BOOT +define+DIAG_DISPBASE) ---------------------
// THE question: does the core actually follow the game's page flip on silicon?
//
// MEASURED in MAME 0.280 live gameplay (yunit_render_profile_gp.lua): 7 of 8 Y-unit
// titles move DPYSTRT every frame -- High Impact 4,784 flips over 5,200 drawing frames,
// Strike Force 4,300/4,300, SHI 4,641/5,045 -- while Smash T.V. writes DPYSTRT ZERO
// times in gameplay and Trog 15 times with one value. The two static titles are the
// only two that render correctly. Family2 pinned the display base to DISP_ROW0=0, so a
// flip was invisible to scanout = whole-screen flash. This overlay shows the fix working
// (or not) without guessing.
//
//   row1 = dbg_disp_flips -> base changes since reset.
//          High Impact / SHI / Strike Force: MUST CLIMB, ~1 per frame.
//          Smash T.V. / Trog: MUST STAY 00000000.
//   row2 = {ref, pending, live} packed 9 bits each (live in the low 9).
//          HI: live must ALTERNATE between two values 256 apart (e.g. 000/100 hex).
//          Smash/Trog: live must read 000 always -- the delta is pinned at zero.
//   row3 = dbg_iol_drop -> unchanged sanity tap; still must read 00000000.
//   row4 = liveness bits, as DIAG_DLAUDIT.
//
// READING IT HONESTLY: row1 frozen at zero is NOT proof of anything on its own -- it is
// also what a dead tap reads. Confirm row2's reference field is populated (bit 27 set)
// before believing a zero. On Smash a zero row1 WITH a live row2 is the expected pass.
assign r1v = dbg_disp_flips;
assign r2v = dbg_disp_rows;
assign r3v = dbg_iol_drop;
assign r4v = {29'd0, dbg_unp_done, dbg_sdram_ready, dbg_core_rst};
`elsif DIAG_THINBLIT
// ---- THIN-BLIT CENSUS (+define+DIAG_BOOT +define+DIAG_THINBLIT) -----------------------
// THE question: for Total Carnage's missing road, does the GAME issue its
// row-by-row blits at all, or are they issued and lost downstream?
//
// MEASURED in MAME 0.289 (mame-trace/blit_vram_oracle.lua + blit_profile_gp.lua):
// TC's road is 49 blits of w=200,h=1 per frame, rows 100..148. Strike Force and
// Saurian Front use the same thin shape in bursts (37.5 / 31.0 per drawing frame);
// Smash T.V. -- our only per-instruction golden -- issues 1.2, which is why nothing
// in the suite exercises the pattern. The blitter itself is PROVEN to draw those
// exact descriptors bit-exact (sim/probe/thin-blit: 9,653 pixels, 0 wrong), so the
// two remaining possibilities are what these counters separate:
//
//   row1 = dbg_blit_total -> every accepted trigger. MUST climb on any title.
//                            Frozen = a dead tap; do not read row2 without it.
//   row2 = dbg_blit_thin  -> triggers with HEIGHT == 1.
//          TC in gameplay: ~49/frame (~2,700/sec) => the game IS drawing the road
//                          and the pixels are lost downstream (write path / erase).
//          TC near zero    => the game never runs its road path at all, and every
//                          video-side theory (erase, width, page) is irrelevant to it.
//          Smash T.V.: ~1/frame -- the control that says the counter is honest.
//   row3 = dbg_disp_rows  -> live|pending|reference display base, as DIAG_DISPBASE.
//   row4 = liveness bits.
assign r1v = dbg_blit_total;
assign r2v = dbg_blit_thin;
assign r3v = dbg_disp_rows;
assign r4v = {29'd0, dbg_unp_done, dbg_sdram_ready, dbg_core_rst};
`elsif DIAG_DLAUDIT
// ---- P0020 DOWNLOAD AUDIT (+define+DIAG_BOOT +define+DIAG_DLAUDIT) ---------------------
// THE question this build exists to answer: does hps_io outrun the boot FIFO's backpressure
// while the gfx-unpack owns the shared iol channel?
//
// yunit_top_family2 muxes the ioctl download and the unpack onto ONE arbiter channel
// (iol_*) on unp_owner. While the unpack owns it the FIFO CANNOT DRAIN -- for the whole
// pass, millions of clocks -- and the family MRA drops rom_download between ioctl_index
// 0/1/2, so the unpack arms on the GRAPHICS falling edge and the program+sound streams
// arrive WHILE it runs. The FIFO is 512 deep (IOL_AW=9) with IOL_HWM=256, so once
// ioctl_wait asserts the design absorbs exactly 256 more delivered words before iol_full
// starts DROPPING them. Whether real hps_io overshoots that is a HARDWARE property that no
// simulation can answer -- hence this build.
//
// These counters have existed since P0020 and have NEVER been read on a cabinet: the
// comment at yunit_top_family2.sv:669 claims they are "displayed on the DIAG_BOOT overlay",
// but before this branch nothing painted them -- dbg_iol_drop reached the emu and stopped.
//
//   row1 = dbg_iol_drop  -> MUST READ 00000000.  Non-zero = download words were dropped and
//                           the ROM image on silicon is INCOMPLETE, which would explain the
//                           game's own power-up ROM test failing its IROM checks.
//   row2 = accepted[31:16]
//   row3 = dbg_iol_wrs   -> accepted pushes; climbs during boot then stops.
//   row4 = {29'b0, unp_done, sdram_ready, core_rst}  boot-state sanity.
wire [31:0] r1v = dbg_iol_drop;
wire [15:0] r2v = dbg_iol_wrs[31:16];
wire [31:0] r3v = dbg_iol_wrs;
wire [31:0] r4v = {29'd0, dbg_unp_done, dbg_sdram_ready, dbg_core_rst};
`else
// cont.26 WATCHDOG-SOURCE diag (replaces the now-resolved blit-count-deficit rows 2/3):
// row1 = dbg_culprit_pc (reset-vector value the CPU read -- ROM-landed sanity check).
// row2 = dbg_culprit_instr, a RESTART COUNT (yunit_top.sv ~line 640): increments every time
//        PC lands on the warm-restart vector FFE0F5C0. 0/static = never restarted; climbing
//        (esp. fast) = we ARE looping through the restart repeatedly -- names "warp loop" /
//        "replay loop" as a REAL repeating restart, not a one-shot mis-render.
// row3 (low 16 hex) = dbg_derail_pc, the JUMP SOURCE PC that landed on FFE0F5C0. Per
//        yunit_top.sv: FFE0E9E0 = the game's OWN software watchdog (JANC, frame-count>=200,
//        MAME dasm) -- if row3 reads FFE0E9E0, throughput/starvation is CONFIRMED (matches
//        the documented DDR3-stall-vs-/12-speed derail). Any OTHER PC names a different real
//        cause (CALLERR process-error, wild jump) instead.
// row4 = dbg_pc (live PC) -- confirms the CPU is actually running, not frozen.
wire [31:0] r1v = dbg_culprit_pc;
wire [15:0] r2v = dbg_culprit_instr;
wire [31:0] r3v = dbg_derail_pc;
wire [31:0] r4v = dbg_pc;
`endif

smashtv_diag2_overlay u_diag2 (
	.clk(clk_sys), .ce_pix(ce_pix), .rst(reset),
	.core_rst(dbg_core_rst), .sdram_ready(dbg_sdram_ready), .unp_done(dbg_unp_done),
	.ioctl_download(rom_download), .cpu_req(dbg_cpu_req), .mem_ack(dbg_mem_ack),
	.int1(dbg_int1), .vblank_irq(dbg_vblank_irq), .cpu_ce(dbg_cpu_ce),
	.pc(r4v), .illegal(dbg_illegal),
	// DDR3 health: status bar RED on a scanout burst under-delivery (ddr_wedge), a masked write
	// (ddr_masked = RMW fix not active), or a real CPU derail. row3 = {DDR reads[15:0], beats[15:0]}
	// (read health, GREEN+climbing = memory read healthy on silicon -- already cab-confirmed this
	// session). row2 = RESET-EDGE COUNT (was ddr_writes -- write health also already cab-confirmed;
	// freed for the higher-priority question right now, see rst_edge_cnt above): stays at its
	// post-boot value = the repeating white/purple loop is the GAME'S OWN software loop (BURN_IN);
	// climbing = our RTL is genuinely re-resetting the CPU on silicon.
	// cont.22 BLIT-COUNT diag: row2 = blit_last (this frame's count), row3 = {PEAK/frame, last/frame}.
	// MAME golden reference: avg 170.7 blits/frame, PEAK 219. Cab peak (row3 high 4 hex) << 219 = deficit.
	.derailed(dbg_derailed | ddr_wedge | ddr_masked), .culprit_pc(r1v),
	.culprit_instr(r2v), .derail_pc(r3v),
	// COMPOSITOR (UMK3 overlay, cont.24): feed the core's live raster in; the diag draws into the
	// top-left quadrant and the game shows through everywhere else -> read the numbers AND see the
	// splash behind them (confirm scene + watch the columns draw/black directly).
	.g_r(r), .g_g(g), .g_b(b), .g_hs(hsync), .g_vs(vsync), .g_hb(hblank), .g_vb(vblank), .g_de(de),
	.vid_r(ov_r), .vid_g(ov_g), .vid_b(ov_b),
	.hsync(ov_hs), .vsync(ov_vs), .hblank(ov_hb), .vblank(ov_vb), .de(ov_de));
`else
assign {ov_r,ov_g,ov_b,ov_hs,ov_vs,ov_hb,ov_vb,ov_de} = '0;
`endif

// ---- F4 service instrument overlay (+define+DIAG_SERVICE) ------------------------------
// Paints the per-frame SDRAM / sound / raster counters into the top-left quadrant with the
// game showing through, so one cabinet photo per title settles Q1 (CPU starvation), Q2
// (sound region populated + served) and Q3 (blanked pixels). Read the map in
// rtl/diag/yunit_diag_service_overlay.sv. DIAG_BOOT takes precedence in the av_* select
// above, so the two instruments never fight over the video path.
`ifdef DIAG_SERVICE
yunit_diag_service_overlay u_svc_overlay (
	.clk(clk_sys), .ce_pix(ce_pix), .rst(reset),
	.core_rst(dbg_core_rst), .sdram_ready(dbg_sdram_ready),
	.ioctl_download(ioctl_download), .cpu_ce(dbg_cpu_ce),
	.cnt_cgfx_grants(dbg_cgfx_grants), .cnt_snd_grants(dbg_snd_grants),
	.cnt_cgfx_maxwait(dbg_cgfx_maxwait),
	.cnt_snd_miss(dbg_snd_miss), .cnt_snd_busy16(dbg_snd_busy16),
	.cnt_cvsd_moves(dbg_cvsd_moves), .cnt_adpcm_moves(dbg_adpcm_moves),
	.cnt_blank_pix(dbg_blank_pix), .cnt_cpu_pc_moves(dbg_cpu_pc_moves),
	.cnt_snd_acks(dbg_snd_acks), .snd_first_words(dbg_snd_first_words),
	.snd_region_seen(dbg_snd_region_seen), .snd_board_rst(dbg_snd_board_rst),
	.restart_cnt(dbg_restart_cnt),
	.g_r(r), .g_g(g), .g_b(b), .g_hs(hsync), .g_vs(vsync),
	.g_hb(hblank), .g_vb(vblank), .g_de(de),
	.vid_r(sv_r), .vid_g(sv_g), .vid_b(sv_b),
	.hsync(sv_hs), .vsync(sv_vs), .hblank(sv_hb), .vblank(sv_vb), .de(sv_de));
`else
assign {sv_r,sv_g,sv_b,sv_hs,sv_vs,sv_hb,sv_vb,sv_de} = '0;
`endif

endmodule
