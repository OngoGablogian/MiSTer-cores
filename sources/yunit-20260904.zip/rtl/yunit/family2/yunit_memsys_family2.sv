// yunit_memsys_family2.sv — Y-unit memory subsystem: yunit_mem_family2 + yunit_dma_family2 glued into
// one slave on the TMS34010 core's request-valid memory interface.
//
// This is the block the CPU talks to. It routes:
//   - the DMA blitter register region (0x01A00000, mirror +0x80000) -> yunit_dma_family2
//   - everything else                                               -> yunit_mem_family2
// and wires the blitter back into VRAM: yunit_dma_family2.fb_* -> yunit_mem_family2 VRAM write
// port, yunit_dma_family2.dma_palette -> yunit_mem_family2 CPU vram_w byte-lane.
//
// The unpacked gfx-ROM read (yunit_dma_family2.src_*) is exposed as ports — on HW it is
// backed by SDRAM; in sim by a gfx model. (CPU reads of the gfx *window*
// 0x02000000, used only by the boot checksum, are still handled by yunit_mem_family2
// and currently return 0 — wired when the boot checksum path is exercised.)
//
// Interrupts (P0016, corrects the 2026-07-04 "poll-driven only" misread): the
// POST/self-test polls DMA_COMMAND bit15, but the GAME's per-frame draw uses a
// blit QUEUE pumped by the INT1 ISR (vector -> ffe00000): DMA-done ASSERTS
// LINT1 (MAME dma_callback), any COMMAND write CLEARS it (MAME dma_w). That is
// yunit_dma_family2.blit_irq -> the int1 output -> tms34010_core.lint1_in.

`default_nettype none

// Mirror yunit_mem_family2's synthesis auto-defines so the guarded ports/wiring here match
// (macros defined in yunit_mem_family2.sv also persist in a single compile, but be explicit).
`ifdef SYNTHESIS
  `ifndef USE_EXT_GFX
    `define USE_EXT_GFX
  `endif
  `ifndef USE_EXT_ROM
    `define USE_EXT_ROM
  `endif
  // VRAM backend: default SDRAM, but -DUSE_HW_VRAM overrides (must mirror yunit_mem_family2.sv's
  // guard exactly so the u_mem port set matches the instantiation). USE_DDR3_VRAM does
  // NOT skip this: DDR3 is a SUB-CASE nested inside USE_SDRAM_VRAM's own scope below
  // (scan_*/ddram_* ports only exist `ifdef USE_SDRAM_VRAM -> `ifdef USE_DDR3_VRAM), so
  // -DUSE_DDR3_VRAM alone REQUIRES USE_SDRAM_VRAM to also auto-define here.
  `ifndef USE_HW_VRAM
  `ifndef USE_SDRAM_VRAM
    `define USE_SDRAM_VRAM
  `endif
  `endif
  `ifndef USE_HW_RAM
    `define USE_HW_RAM
  `endif
`endif
`ifdef USE_EXT_GFX
  `define YM_EXT_RD
`endif
`ifdef USE_EXT_ROM
  `ifndef YM_EXT_RD
    `define YM_EXT_RD
  `endif
`endif

module yunit_memsys_family2
  import yunit_pkg::*;
#(
  parameter ROM_HEX = "smashtv_maindata.hex",
  parameter int ROM_WORDS = 32'h20000,
  parameter int ROM_WORD_OFFSET = 32'h60000,
  parameter int GFX_PIXELS = 32'h180000
)(
  input  logic        clk,
  input  logic        rst,

  // CPU (TMS34010 core) request-valid memory interface.
  input  logic        mem_req,
  input  logic        mem_we,
  input  logic [31:0] mem_addr,          // bit address
  input  logic  [5:0] mem_size,          // field width 1..32
  input  logic [31:0] mem_wdata,
  output logic [31:0] mem_rdata,
  output logic        mem_ack,

  // Unpacked-gfx source (to external gfx ROM / SDRAM): 1 byte/pixel.
  output logic        src_req,
  output logic [23:0] src_addr,
  input  logic  [7:0] src_data,
  input  logic        src_ack,

  // Player inputs (Phase 4): packed {DSW, IN2, IN1, IN0}, active-low.
  input  logic [63:0] inputs,
  input  logic [3:0]  game_id,
  // Live 34010 PC (T2 movie-freeze hack pass-through to u_mem).
  input  logic [31:0] cpu_pc,
  input  logic [7:0]  term2_adc,
  output logic [1:0]  term2_adc_sel,
  // Runtime palette depth: selects MAME's 4bpp/6bpp palette alias mask.
  input  logic        bpp4,
  input  logic [23:0] gfx_bytes,

  // MiSTer index-4 CMOS persistence side port.  Restore runs with the core in
  // reset; upload first quiesces and drains any accepted CPU CMOS operation.
  input  logic        cmos_quiesce,
  input  logic        nvram_ext_en,
  input  logic        nvram_ext_wr,
  input  logic [14:0] nvram_ext_addr,
  input  logic [7:0]  nvram_ext_wdata,
  output logic [7:0]  nvram_ext_rdata,
  output logic        cmos_cpu_busy,
  output logic        cmos_cpu_write_pulse,
`ifdef YUNIT_SRT_FILL_BURST
  // One architectural TMS34010 shift-register command. The DDR backend accepts
  // only while ready and pulses done after all 1024 entries are accepted by
  // the DDR agent/bridge.
  input  logic        shift_req,
  input  logic        shift_write,
  input  logic [17:0] shift_entry,
  output logic [15:0] shift_rdata,
  output logic        shift_ready,
  output logic        shift_done,
  output logic        shift_invalidate_valid,
  output logic [8:0]  shift_invalidate_row,
`endif

  // P0016: DMA-done interrupt line -> TMS34010 LINT1. yunit_dma_family2.blit_irq
  // already implements the MAME semantics (dma_callback ASSERTs on blit
  // completion; any DMA COMMAND write CLEARs — midyunit_v.cpp:370-374/433).
  // The game's blit-queue pump ISR (INT1 vector -> ffe00000) depends on it.
  output logic        int1,

  // Sound latch (Phase 5) -> williams_cvsd_board (see yunit_mem_family2).
  output logic [7:0]  snd_select,
  output logic        snd_trig,
  output logic        snd_reset,

  // DIAG fire-chain watches (pass-through from yunit_mem_family2; see its port decl).
  output logic [31:0] dbg_p1ctrl,
  output logic [31:0] dbg_bdir,

  // Autoerase sweep (SQUAD CHARLIE): frame-paced trigger into yunit_mem_family2's
  // erase engine (MAME midyunit_v.cpp:534-560 semantics; see yunit_mem_family2).
  // System-level intent: pulse from yunit_video_family2's vblank_irq with
  // erase_row0 = DISP_ROW0 and erase_lines = V_ACT; Phase-6 form re-paces
  // this per scanline off the live raster. Left unconnected in legacy TBs.
  input  logic        erase_start,
  input  logic [8:0]  erase_row0,
  input  logic [9:0]  erase_lines,
  // Gospel-guarded per-line erase events (sequencer line_consumed_*) -> the
  // DDR3 beam-locked C engine. See stv_vram_ddr_top erase_line_valid note.
  input  logic        erase_line_valid,
  input  logic        erase_line_first,
  input  logic [8:0]  erase_line_row,
  input  logic        erase_frame_raw_ok,
  // Explicit frame boundary from the display sequencer (vsblnk reload edge);
  // supersedes the >=256 row-delta resync heuristic under YUNIT_ERASE_FRAME_SNAP.
  input  logic        erase_frame_start,
  // Runtime autoerase kill (OSD). MUST reach the LIVE engine, not just the bulk
  // erase_start path: under -DUSE_DDR3_VRAM the bulk sweep is tied OFF at
  // stv_vram_ddr_top.sv:165 and a beam-locked C engine erases instead, enabled
  // by erase_en. Gating only erase_start produced a toggle that changed nothing
  // on the cabinet while passing its own gate.
  input  logic        autoerase_off,
  output logic        erase_busy,

  // Observability
  output logic        blit_busy,
  output logic        blit_engine_active,
  // Framebuffer write-combine drain-in-progress. This is backend
  // observability/ordering state, not an architectural display page token;
  // production must not gate DPYSTRT adoption on it. 0 on SDRAM/BRAM.
  output logic        fb_busy,
  // Accepted DMA pixel stream for the video prefetch-buffer snoop.  This is
  // the logical commit point: the framebuffer backend has accepted the pixel.
  output logic        fb_snoop_we,
  output logic [FB_ADDR_W-1:0] fb_snoop_addr,
  output logic [15:0] fb_snoop_data
  // cont.24 splash-capture diag: expose the raw DMA register-write stream so the emu overlay can
  // reconstruct + latch the title-splash blit commands (LEFT/RIGHT column) on the cab.
  , output logic [31:0] dbg_blit_total
  , output logic [31:0] dbg_blit_thin
  , output logic        dbg_dma_we
  , output logic  [3:0] dbg_dma_addr
  , output logic [15:0] dbg_dma_wdata
`ifdef YM_EXT_RD
  // CPU read-only external port (gfx/ROM in SDRAM) — exposed to the top controller.
  , output logic        cpu_gfx_rd
  , output logic [23:0] cpu_gfx_raddr
  , input  logic [15:0] cpu_gfx_rdata   // PERF: word-wide (aligned word at raddr&~1)
  , input  logic        cpu_gfx_rack
`endif
`ifdef USE_SDRAM_VRAM
  // VRAM SDRAM channel + video scanout read port — exposed to the top controller/video.
  , input  logic        scan_req
  , input  logic [17:0] scan_addr
  , output logic [15:0] scan_data
  , output logic        scan_ack
`ifdef USE_DDR3_VRAM
  , input  logic        sdram_por
  , output logic [28:0] ddram_addr
  , output logic [7:0]  ddram_burstcnt
  , output logic        ddram_rd
  , output logic        ddram_we
  , output logic [63:0] ddram_din
  , output logic [7:0]  ddram_be
  , input  logic        ddram_busy
  , input  logic [63:0] ddram_dout
  , input  logic        ddram_dout_ready
`else
  , output logic [24:0] vsd_addr
  , output logic [15:0] vsd_din
  , output logic [1:0]  vsd_be
  , output logic        vsd_rd
  , output logic        vsd_wr
  , input  logic [15:0] vsd_dout
  , input  logic        vsd_ack
`endif
`endif
`ifdef USE_HW_RAM
  // W3: palette write-tap -> video scanout mirror (yunit_palram, in yunit_top_family2).
  , output logic        palv_we_a
  , output logic [12:0] palv_aa
  , output logic [15:0] palv_awd
  , output logic        palv_we_b
  , output logic [12:0] palv_ba
  , output logic [15:0] palv_bwd
`endif
);

  // ---- DMA-region detect (0x01A00000 and its 0x080000 mirror) -----------
  wire is_dma_now = (mem_addr[31:20] == 12'h01A);

  // ---- yunit_mem_family2 (all non-DMA regions, incl. VRAM/PAL/RAM/ROM/CMOS/CTRL) --
  logic        mem_req_m;
  logic [31:0] mem_rdata_m;
  logic        mem_ack_m;

  // ---- yunit_dma_family2 blitter ------------------------------------------------
  logic        dma_reg_we;
  logic  [3:0] dma_reg_addr;
  logic [15:0] dma_reg_wdata;
  logic [15:0] dma_reg_rdata;
  logic        dma_fb_we;
  logic [FB_ADDR_W-1:0] dma_fb_addr;
  logic [15:0] dma_fb_wdata;
  logic [15:0] dma_palette;
  logic        dma_trigger_blocked;

  // blitter fb write completion: SDRAM path drives it from yunit_mem_family2; BRAM path = 1-cycle.
`ifdef USE_SDRAM_VRAM
  logic mem_fb_ack;
  wire  dma_fb_ack = mem_fb_ack;
  logic mem_fb_busy;                 // DDR3 fb-combine drain-in-progress (commit-gate); 0 on SDRAM
  wire  dma_fb_busy = mem_fb_busy;
`else
  wire  dma_fb_ack = 1'b1;
  wire  dma_fb_busy = 1'b0;
`endif
  logic dma_fb_flush;                // cont.24 done-flush: blit finished -> drain the combiner now
  assign fb_snoop_we   = dma_fb_we && dma_fb_ack;
  assign fb_snoop_addr = dma_fb_addr;
  assign fb_snoop_data = dma_fb_wdata;
  assign fb_busy       = dma_fb_busy;   // expose combiner drain for observability/ordering only

  yunit_mem_family2 #(.ROM_HEX(ROM_HEX), .ROM_WORDS(ROM_WORDS),
                      .ROM_WORD_OFFSET(ROM_WORD_OFFSET),
                      .GFX_PIXELS(GFX_PIXELS)) u_mem (
    .clk(clk), .rst(rst),
    .mem_req(mem_req_m), .mem_we(mem_we), .mem_addr(mem_addr),
    .mem_size(mem_size), .mem_wdata(mem_wdata),
    .mem_rdata(mem_rdata_m), .mem_ack(mem_ack_m),
    .fb_we(dma_fb_we), .fb_addr(dma_fb_addr), .fb_wdata(dma_fb_wdata),
    .dma_palette(dma_palette),
    .inputs(inputs), .game_id(game_id), .cpu_pc(cpu_pc),
    .term2_adc(term2_adc), .term2_adc_sel(term2_adc_sel),
    .bpp4(bpp4), .gfx_bytes(gfx_bytes),
    .cmos_quiesce(cmos_quiesce),
    .nvram_ext_en(nvram_ext_en), .nvram_ext_wr(nvram_ext_wr),
    .nvram_ext_addr(nvram_ext_addr), .nvram_ext_wdata(nvram_ext_wdata),
    .nvram_ext_rdata(nvram_ext_rdata),
    .cmos_cpu_busy(cmos_cpu_busy),
    .cmos_cpu_write_pulse(cmos_cpu_write_pulse),
`ifdef YUNIT_SRT_FILL_BURST
    .shift_req(shift_req), .shift_write(shift_write),
    .shift_entry(shift_entry), .shift_rdata(shift_rdata),
    .shift_ready(shift_ready), .shift_done(shift_done),
    .shift_invalidate_valid(shift_invalidate_valid),
    .shift_invalidate_row(shift_invalidate_row),
`endif
    .snd_select(snd_select), .snd_trig(snd_trig), .snd_reset(snd_reset),
    .dbg_p1ctrl(dbg_p1ctrl), .dbg_bdir(dbg_bdir),
    .erase_start(erase_start), .erase_row0(erase_row0),
    .erase_lines(erase_lines), .autoerase_off(autoerase_off),
    .erase_line_valid(erase_line_valid), .erase_line_first(erase_line_first), .erase_line_row(erase_line_row),
    .erase_frame_raw_ok(erase_frame_raw_ok),
    .erase_frame_start(erase_frame_start),
    .erase_busy(erase_busy)
`ifdef YM_EXT_RD
    , .gfx_rd(cpu_gfx_rd), .gfx_raddr(cpu_gfx_raddr),
      .gfx_rdata(cpu_gfx_rdata), .gfx_rack(cpu_gfx_rack)
`endif
`ifdef USE_SDRAM_VRAM
    , .fb_ack(mem_fb_ack)
    , .fb_busy(mem_fb_busy)
    , .fb_flush(dma_fb_flush)
    , .scan_req(scan_req), .scan_addr(scan_addr), .scan_data(scan_data), .scan_ack(scan_ack)
`ifdef USE_DDR3_VRAM
    , .sdram_por(sdram_por)
    , .ddram_addr(ddram_addr), .ddram_burstcnt(ddram_burstcnt), .ddram_rd(ddram_rd), .ddram_we(ddram_we)
    , .ddram_din(ddram_din), .ddram_be(ddram_be)
    , .ddram_busy(ddram_busy), .ddram_dout(ddram_dout), .ddram_dout_ready(ddram_dout_ready)
`else
    , .vsd_addr(vsd_addr), .vsd_din(vsd_din), .vsd_be(vsd_be), .vsd_rd(vsd_rd), .vsd_wr(vsd_wr)
    , .vsd_dout(vsd_dout), .vsd_ack(vsd_ack)
`endif
`endif
`ifdef USE_HW_RAM
    , .palv_we_a(palv_we_a), .palv_aa(palv_aa), .palv_awd(palv_awd)
    , .palv_we_b(palv_we_b), .palv_ba(palv_ba), .palv_bwd(palv_bwd)
`endif
  );

  yunit_dma_family2 u_dma (
    .dbg_blit_total(dbg_blit_total), .dbg_blit_thin(dbg_blit_thin),
    .clk(clk), .rst(rst),
    .reg_we(dma_reg_we), .reg_addr(dma_reg_addr),
    .reg_wdata(dma_reg_wdata), .reg_rdata(dma_reg_rdata),
    .src_req(src_req), .src_addr(src_addr), .src_data(src_data), .src_ack(src_ack),
    .fb_we(dma_fb_we), .fb_addr(dma_fb_addr), .fb_wdata(dma_fb_wdata),
    .fb_ack(dma_fb_ack),   // SDRAM: yunit_mem_family2.fb_ack (blitter self-paces); BRAM: 1'b1
    .fb_busy(dma_fb_busy), // commit-gate: hold done until the fb-combine drains (DDR3); 0 else
    .fb_flush(dma_fb_flush), // cont.24: S_DONE level -> eager combiner drain (DDR3 consumes)
    .busy(blit_busy), .engine_active(blit_engine_active),
    .trigger_blocked(dma_trigger_blocked),
    .blit_irq(int1), .dma_palette(dma_palette)   // P0016: -> LINT1
  );

  // ---- DMA register access FSM ------------------------------------------
  // The DMA registers are 16-bit at word-aligned bit addresses (reg index =
  // addr[7:4]). The 34010 memory system splits a >16-bit field write into
  // consecutive word writes, so a 32-bit field write to reg N updates reg N
  // (low word) AND reg N+1 (high word) — MAME calls dma_w twice. The custom-
  // chip test relies on this: `MOVE A14,@1A80060h,1` (32-bit) sets WIDTH(6)
  // AND HEIGHT(7). A 16-bit-only FSM dropped HEIGHT -> blit height 0 -> no-op.
  // So: writes visit D_LO (reg idx, wdata[15:0]) then, if size>16, D_HI
  // (reg idx+1, wdata[31:16]); reads go straight to D_ACKR (combinational
  // reg_rdata). One dma_ack pulse per access, after all register writes land.
  typedef enum logic [1:0] { D_IDLE, D_LO, D_HI, D_ACKR } dstate_t;
  dstate_t dstate;
  logic [31:0] d_addr_q;
  logic        d_we_q;
  logic [31:0] d_wd_q;
  logic  [5:0] d_sz_q;
  logic        dma_ack;

  wire d_second = (dstate == D_HI);
  assign dma_reg_addr  = d_second ? (d_addr_q[7:4] + 4'd1) : d_addr_q[7:4];
  assign dma_reg_wdata = d_second ? d_wd_q[31:16]          : d_wd_q[15:0];

  // cont.24 splash-capture: forward the DMA register-write stream to the emu overlay taps.
  assign dbg_dma_we    = dma_reg_we;
  assign dbg_dma_addr  = dma_reg_addr;
  assign dbg_dma_wdata = dma_reg_wdata;
  assign dma_reg_we    = (dstate == D_LO) || (dstate == D_HI); // only entered on writes

  always_ff @(posedge clk) begin
    if (rst) begin
      dstate  <= D_IDLE;
      dma_ack <= 1'b0;
    end else begin
      unique case (dstate)
        D_IDLE: begin
          dma_ack <= 1'b0;
          if (mem_req && is_dma_now && !mem_ack) begin
            // yunit_dma_family2 atomically snapshots every accepted trigger. One command may
            // wait behind the active blit without stalling the CPU; only a full pending
            // slot raises dma_trigger_blocked. It remains high across S_DONE->IDLE and
            // the pending S_TRIG promotion, so a later trigger is held until a snapshot
            // slot is genuinely free. Data-register writes remain unrestricted because
            // accepted commands no longer depend on live regf[]. KILL writes (bit15=0)
            // also remain immediate.
            // KNOWN NARROW GAP (adversarially
            // reviewed, MAME-unreachable): a hypothetical 32-bit write starting at the
            // unused register index 15 would enter here with mem_addr[7:4]=0xF (not
            // DMA_COMMAND) so the stall check misses it, and its D_HI half then wraps
            // (15+1=0) onto DMA_COMMAND unconditionally on the OTHER side of this
            // FSM -- no ASM path issues a 32-bit write to reg 15 (real pairs are
            // COMMAND/ROWBYTES, OFFSETLO/HI, XSTART/YSTART, WIDTH/HEIGHT), so this is
            // not reachable today, but it is not a structural impossibility either.
            if (mem_we && (mem_addr[7:4] == DMA_COMMAND) && mem_wdata[DMA_CMD_TRIG_BIT] && dma_trigger_blocked) begin
              // hold: re-evaluate next cycle; mem_req/mem_addr/mem_wdata stay stable
              // (the CPU's own req/ack handshake keeps them driven until mem_ack).
            end else begin
              d_addr_q <= mem_addr;
              d_we_q   <= mem_we;
              d_wd_q   <= mem_wdata;
              d_sz_q   <= mem_size;
              dstate   <= mem_we ? D_LO : D_ACKR;
            end
          end
        end
        D_LO:   dstate <= (d_sz_q > 6'd16) ? D_HI : D_ACKR; // reg idx written this edge
        D_HI:   dstate <= D_ACKR;                           // reg idx+1 written this edge
        D_ACKR: begin dma_ack <= 1'b1; dstate <= D_IDLE; end
        default: dstate <= D_IDLE;
      endcase
    end
  end

  // ---- output mux -------------------------------------------------------
  // Route the request: DMA region -> the DMA FSM (mem_req_m held low so
  // yunit_mem_family2 ignores it); everything else -> yunit_mem_family2.
  assign mem_req_m = mem_req && !is_dma_now;
  assign mem_ack   = is_dma_now ? dma_ack : mem_ack_m;
  assign mem_rdata = is_dma_now ? {16'h0000, dma_reg_rdata} : mem_rdata_m;

endmodule

`default_nettype wire
