// stv_vram_ddr_top.sv — VRAM-in-DDR3 subsystem (P1). Drop-in for vram_sdram_top: same
// accessor ports, but VRAM lives in the HPS DDR3 (f2h_sdram1) — freeing the SDRAM port so
// the scanout no longer starves the CPU.
//
// INCREMENT 2 (this file): the scanout is now served by a ROW-BURST CACHE (the bandwidth win).
// yunit_scanline (the proven W3 double-buffer) is UNCHANGED and still issues one scan_req per
// column; on the first miss of a row the cache bursts the WHOLE row (128 beats = 512 entries)
// from DDR3 in ONE transaction, then serves every column of that row from a 128x64b BRAM at a
// ~2-clk hit. So a line costs ~1 burst instead of 512 single reads.
//
// Two requesters share the single DDR3 agent (single-outstanding), muxed by a grant-held L2
// arbiter (scanout burst = priority; it is real-time but rare — once per row):
//   A = the proven vram_sdram_top (CPU field RMW + blitter fb + autoerase) with its scanout
//       port tied off; its single 16-bit sd_* word port is translated to single-beat DDR3
//       accesses via the 4:1 packing (entry>>2 = beat, entry[1:0] = lane, 2-byte lane BE).
//   B = the scanout row cache: burst-fills a row, serves scan_req from cache.
//
// 4:1 packing: entry = (row<<9)|col ; beat = entry>>2 ; lane = entry[1:0]. A 512-entry row =
// 128 contiguous beats at beat_base = row<<7. Reset: accessor engines + A/B/L2 on core rst;
// the persistent DDR agent on sdram_por (P0022).
`default_nettype none
module stv_vram_ddr_top #(
    parameter int VRAMW = 32'h40000,
    parameter [28:0] VRAM_DDR_BASE = 29'h6400000
)(
    input  logic         clk,
    input  logic         rst,
    input  logic         sdram_por,
    // CPU field access
    input  logic         req,
    input  logic         we,
    input  logic [27:0]  widx,
    input  logic [3:0]   boff,
    input  logic [5:0]   sz,
    input  logic [31:0]  wd,
    input  logic         videobank,
    input  logic [15:0]  dma_palette,
    output logic [31:0]  rdata,
    output logic         done,
    // blitter framebuffer write
    input  logic         fb_we,
    input  logic [17:0]  fb_addr,
    input  logic [15:0]  fb_wdata,
    output logic         fb_ack,
    input  logic         fb_flush,    // cont.24 done-flush: the blit finished (all pixels accepted) --
                                      // drain the combiner + run-buffer NOW, overlapping the DMA's pace
                                      // wait, instead of the 2x 64-clk idle timeouts (~130clk dead tail
                                      // on every done-serialized blit IRQ).
    output logic         fb_busy,     // D-lane not drained (combiner holds pixels OR flush FSM active).
                                      // The DMA gates its done-report on this so "done" = COMMITTED,
                                      // not merely fb_ack-ACCEPTED (write-behind) -> no mid-draw display.
    // BEAM-LOCKED AUTOERASE (C engine). Replaces the old bulk erase_start/erase_row0/erase_lines
    // ports (that pulse-driven bulk sweep is now dead on the DDR3 path; u_acc's internal bulk engine
    // is tied OFF below). erase_en is the ENABLED-sense autoerase flop (yunit_mem `autoerase`,
    // control_w bit4 active-low). The engine snoops the existing scan_addr for the row-change
    // trigger and erases (displayed_row - 1) one row behind the beam, MAME midyunit_v.cpp:554
    // autoerase_line(rowaddr-1). erase_busy now = the C engine's busy.
    input  logic         erase_en,
    // GOSPEL-GUARDED erase line events (2026-08-18, the SF/Saurian phantom-erase
    // fix). MAME's guard `scanline < 510` (midyunit_v.cpp:538) operates on the
    // UNMASKED rowaddr: titles displaying at raw rowaddr >= 0x200 (Strike Force,
    // Saurian Front, Terminator 2 -- bases 255/511) are NEVER autoerased by real
    // hardware; their raw-and-511-masked physical rows are indistinguishable in
    // scan_addr, so the old req_row snoop erased them anyway and wiped every
    // statically-drawn frame (cab: splash art gone, only per-frame-redrawn
    // flames/starfield survive). The display sequencer's line_consumed events
    // apply the raw-space guard at the source (yunit_display_address_sequencer
    // consumption guards current<=510 / final<510) -- plumbed here, they carry
    // exactly gospel's erase targets and nothing else. Guarded events always
    // have phys == raw (raw <= 509), so the goal space is unchanged.
    // Explicit frame boundary from the display sequencer (vsblnk reload edge).
    input  logic         erase_frame_start,
    input  logic         erase_line_valid,
    input  logic         erase_line_first,
    input  logic [8:0]   erase_line_row,
    output logic         erase_busy,
    // video scanout read
    input  logic         scan_req,
    input  logic [17:0]  scan_addr,
    output logic [15:0]  scan_data,
    output logic         scan_ack,
`ifdef YUNIT_SRT_FILL_BURST
    // One complete TMS34010 shift-register operation.  A small SRT supervisor
    // borrows C's source cache and L2 grant to move 1024 16-bit entries as 256
    // 64-bit beats; ready accepts one command and done is withheld until the
    // DDR agent/bridge has accepted its final sub-burst. Publication metadata
    // protects subsequent reads.
    input  logic         shift_req,
    input  logic         shift_write,
    input  logic [17:0]  shift_entry,
    output logic [15:0]  shift_rdata,
    output logic         shift_ready,
    output logic         shift_done,
    output logic         shift_invalidate_valid,
    output logic [8:0]   shift_invalidate_row,
`endif
    // DDR3 Avalon master
    output logic [28:0]  ddram_addr,
    output logic [ 7:0]  ddram_burstcnt,
    output logic         ddram_rd,
    output logic         ddram_we,
    output logic [63:0]  ddram_din,
    output logic [ 7:0]  ddram_be,
    input  logic         ddram_busy,
    input  logic [63:0]  ddram_dout,
    input  logic         ddram_dout_ready
);
    function automatic logic [7:0] lane_be(input [1:0] l);
        case (l) 2'd0: lane_be=8'h03; 2'd1: lane_be=8'h0C; 2'd2: lane_be=8'h30; default: lane_be=8'hC0; endcase
    endfunction

    // --- FORWARD DECLARATIONS (hoisted for Questa 25.1std declare-before-use, vlog-2730). These
    // are DRIVEN in the B/C/D blocks below but REFERENCED earlier by the A-side coherency snoops/
    // write-throughs. Declaring them here is harmless to iverilog/sv2v (which allow the forward
    // ref) and required by Questa; the driving logic stays in each block. (Same pattern as the
    // core's P0002 hoist.)
    logic [8:0] rc_row;  logic rc_valid;              // B scanout row-cache tag/valid
    logic       rc_fbsel;                             // S4: fb_sel under which rc was filled (front-buffer tag)
    logic       fb_sel;                               // double-buffer draw-buffer select (driven @ trig_wrap below)
    // Double-buffer enable (SPEC S4). Hoisted here (forward-ref by bc_hit/wt_req/pub_fence_en below)
    // per the Questa declare-before-use convention above. -DUSE_DOUBLE_BUFFER selects it.
`ifdef USE_DOUBLE_BUFFER
    localparam bit DBL_EN = 1'b1;
`else
    localparam bit DBL_EN = 1'b0;
`endif
    // S6 (§5.1): the double-buffer must stay OFF during the boot RAMCHECK self-test (CPU field-port
    // write-then-readback) -- otherwise a per-frame fb_sel swap between a cell's write and its readback
    // makes ~64 cells read the wrong physical buffer ("RAM CHIPS BAD"). RAMCHECK never uses the blitter,
    // so arm the feature on the FIRST fb_we (first real draw = past boot). Before arm: dbl_on=0 -> single
    // buffer, full coherency, no swap -> RAMCHECK consistent. After arm: double-buffer for intro+gameplay.
    logic       dbl_arm;                    // latched high on first blitter write, cleared by rst
    wire        dbl_on = DBL_EN & dbl_arm;  // whole double-buffer feature gate (was DBL_EN pre-S6)
    // BSNOOP (2026-07-21 pivot, MEASURED: the game races the beam -- frame-granular double-buffer
    // refuted, see SPEC-doublebuffer §pivot): B scanout row fills are made COHERENT without the old
    // B_DRAIN whole-renderer barrier.  A fill-time SNOOP-MERGE covers writes still resident in
    // wc/rb/in-flight D/wb/d_fwd while B owns the bus.  Retired writes are a different ownership
    // epoch: the HPS bridge may have accepted them after their live merge source disappeared but
    // before DDR reads expose them.  The per-region readback proof below qualifies that epoch before
    // a cold fill.  Together they protect early/static background writes as well as later actors:
    // proof = every retired write through the sampled ordering point; snoop = every newer live write.
    //
    // MUT_NO_BSNOOP restores the old whole-renderer drain before the same proof, preserving the
    // original starvation mutation. MUT_B_SCAN_NO_PROOF keeps the bounded BSNOOP path but removes
    // only the retired-write proof, recreating the cabinet-rejected bounded-shadow behavior.
`ifdef MUT_NO_BSNOOP
    localparam bit BSNOOP = 1'b0;
`else
    localparam bit BSNOOP = 1'b1;
`endif
`ifdef MUT_B_SCAN_NO_PROOF
    localparam bit B_SCAN_PROOF = 1'b0;
`else
    localparam bit B_SCAN_PROOF = 1'b1;
`endif
    logic [63:0] bfill_merged;              // B fill beat after the snoop-merge (assigned below D)
    logic       c_start, c_wr;  logic [25:0] c_addr;  // C erase-engine L2 request
    logic       d_start, d_wr;  logic [25:0] d_addr;  // D fb-combine L2 request
    // Same-D locality copy consumed only by the B-fill snoop. Keeping this
    // launch beside the rc[] data cone prevents the live D request address
    // from spanning the module without changing transaction currency.
    (* preserve, dont_merge *) logic [15:0] bsn_d_addr_q;
    logic       d_is_burst;                           // current D flush is a multi-beat run burst
    logic       d_busy;                               // D owns/holds work (used by A admission)
    logic       b_fill_lock;                          // B drain + atomic row-fill admission lock
    logic       b_bus_lock;                           // B_REQ/B_FILL: L2 grants B only
    logic [1:0] ls;                                    // L2 state (B_DRAIN ownership check)
    logic       tst_busy;                              // persistent agent busy (same check)
    logic       d_add;  logic [15:0] d_add_beat;       // pulse: a full beat was ADDED to the run-buffer
                                                       // (on-add coherency -> A snoop uses these below)
`ifdef YUNIT_SRT_FILL_BURST
    // Strike Force SRT is a supervised sub-mode of C, not a fifth DDR client.
    // The e_* names are retained locally to keep the command policy distinct
    // from C's cabinet-proven autoerase goal/catch-up policy.
    logic       e_start, e_wr; logic [25:0] e_addr;
    logic       e_block;                                // command pending/active; drain and park A/C/D
    logic       e_write_invalidate;                     // completed full-span transfer
    logic [8:0] e_invalidate_row;
    logic [17:0] e_base_entry;
    logic [16:0] e_base_beat;
    logic        e_op_we, e_fbsel;
    logic [8:0]  e_fill;
    logic [7:0]  e_blen;
    logic        e_rd_valid;
    logic [63:0] e_rdata;
    wire         e_done, e_burst_next;
    localparam [3:0] E_IDLE=4'd0, E_DRAIN=4'd1, E_RREQ=4'd2,
                     E_RFILL=4'd3, E_WREQ=4'd4, E_WSTREAM=4'd5,
                     E_INV0=4'd6, E_INV1=4'd7, E_FIN=4'd8;
    logic [3:0] est;
    logic       srt_snapshot_hold;
`endif

    // ================= A: proven accessors (scanout tied off) -> single 16b sd_* port =========
    logic [20:0] sd_addr;  logic [15:0] sd_din;  logic [1:0] sd_be;  logic sd_rd, sd_wr;
    logic [15:0] sd_dout;  logic sd_ack;
    vram_sdram_top #(
        .VRAMW(VRAMW), .SD_AW(21), .VRAM_BASE(21'd0),
        // The live DDR3 C lane below performs beam-locked autoerase.  The
        // nested accessor's legacy bulk engine is unreachable and must not
        // remain in the request/ack timing cone.
        .BULK_ERASE(1'b0)
    ) u_acc (
        .clk(clk), .rst(rst),
        .req(req), .we(we), .widx(widx), .boff(boff), .sz(sz), .wd(wd),
        .videobank(videobank), .dma_palette(dma_palette), .rdata(rdata), .done(done),
        // W-THRU2(D): fb bypasses u_acc's sd path entirely -> the D beat write-combiner below.
        // Frees the sd channel for CPU-only field ops (the second bandwidth win). fb_ack is now
        // driven by the D combiner. Tie u_acc's fb port OFF.
        .fb_we(1'b0), .fb_addr(18'd0), .fb_wdata(16'd0), .fb_ack(),
        // Bulk erase engine inside u_acc is DEAD on the DDR3 path (the beam-locked C engine below
        // replaces it). Tie erase_start OFF; its erase_busy is left unconnected (erase_busy is now
        // driven by the C engine). erase_row0/erase_lines are don't-care with erase_start=0.
        .erase_start(1'b0), .erase_row0(9'd0), .erase_lines(10'd0), .erase_busy(),
        .scan_req(1'b0), .scan_addr(18'd0), .scan_data(), .scan_ack(),
        .sd_addr(sd_addr), .sd_din(sd_din), .sd_be(sd_be), .sd_rd(sd_rd), .sd_wr(sd_wr),
        .sd_dout(sd_dout), .sd_ack(sd_ack) );

    // A-side request to the L2 arbiter (levels held until *_done)
    logic        a_start, a_wr;
    logic [25:0] a_addr;
    logic [63:0] a_wdata;
    logic [ 7:0] a_be;
    logic        a_done, a_rd_valid;   // driven by L2
    logic [63:0] a_rdata;              // driven by L2
    logic [1:0]  a_lane;
    logic [15:0] rmw_din;              // write data held across the read-modify-write
    // ---- own-write SHADOW (deep-posting RMW forward, 2026-07-18) ----------------
    // The beat-cache/d_fwd safety invariants below assume only the MOST RECENT
    // write can be unpublished (1-deep bridge posting). Deep posting falsifies
    // that (sim: 66 stale-RMW-merged entries at cfg_pub_delay=3000; 14 at 1500 --
    // unchanged by any bounded range guard). The shadow records the last-written
    // value of every recently-written beat (2048-entry direct-mapped, indexed by
    // an address hash with a full complementary tag); RMW merges use the shadow as base on HIT --
    // the RTL's own newest data, correct by single-outstanding ordering at ANY
    // publication depth. MISS = not recently written (safe DDR read) or a
    // collision eviction (the measured residual class). Write capture is fed from
    // the agent's accept stream (tst_wnext beats + tst_wr_done final), below.
    // The 11-bit index is {row[3:0],col[6:0]^row_code[6:0]} and the tag is
    // row[8:4], where row_code={row[4],row[5],row[6],row[7],row[8],2'b00}.
    // This extends the old row[4]^col[6] skew through every high row bit.  A
    // complete row remains a collision-free 128-entry permutation and the most
    // recent 16 complete rows still fit exactly, while a fixed-column skinny
    // sprite now maps all 512 rows uniquely instead of aliasing every 32 rows.
    // That matters when scanout consumes this shadow after an accepted write
    // burst but before bridge publication.
    // BRAM form (fit fix: the FF-array + async multi-read version synthesized to
    // 166k registers / 351% ALM). 2048 x {v, tag[4:0], data[63:0]} simple-dual-
    // port M10K; ONE synchronous read port fed by a pipelined candidate lookup
    // (the next A/D read the L2 would grant); hit+base LATCHED at the read grant
    // and consumed at merge. No bulk reset (M10K powers up zero; a re-por leaves
    // stale-but-own values, still valid merge bases).
    (* ramstyle = "M10K" *) logic [69:0] shw_mem [0:2047];
`ifndef SYNTHESIS
    // sim: match the M10K power-up-zero contract (an uninitialized array reads X
    // and X-poisons the hit logic; hardware BRAM initializes to 0).
    initial for (int shwi = 0; shwi < 2048; shwi++) shw_mem[shwi] = 70'd0;
`endif
    logic [69:0] shw_q;  logic [15:0] shw_cand_q;
    logic [63:0] shw_base;  logic shw_base_hit;
    // validity OUTSIDE the BRAM: a never-written BRAM entry reads X under the
    // +define+SYNTHESIS sim config (the ifndef-guarded init is stripped) and an
    // X hit X-selects the merge base. FF vector, por-cleared, read registered
    // in lockstep with the BRAM lookup: valid=0 kills the compare determinis-
    // tically (0 && X == 0) in every simulator and config.
    logic [2047:0] shw_valid;
    // Timing-only split of the registered validity lookup.  The flat vector
    // remains the single POR-cleared/write-owned source of truth; sixteen
    // interleaved 128-entry taps register in parallel, then the registered
    // low index nibble selects the matching tap.  This preserves the original
    // one-clock data/valid/candidate currency while ending the measured
    // tst_rd_valid -> 2048:1 -> shw_v_q path at a four-bit selector register.
    (* preserve, dont_merge *) logic [15:0] shw_v_bank_q;
    (* preserve, dont_merge *) logic [3:0]  shw_v_bank_sel_q;
    wire shw_v_q;
    function automatic logic [10:0] shw_index(input logic [15:0] beat_addr);
        shw_index = {beat_addr[10:7],
                     beat_addr[6:0] ^
                     {beat_addr[11], beat_addr[12], beat_addr[13],
                      beat_addr[14], beat_addr[15], 2'b00}};
    endfunction
`ifdef YUNIT_NO_PUBGUARD
    wire shw_en = 1'b0;    // mutation: shadow off with the fence/guard
`else
    wire shw_en = 1'b1;
`endif

    logic [63:0] rmw_beat;             // the beat being merged (DDR read OR the write-forward copy)
    // WRITE = READ-MODIFY-WRITE of the shared 64-bit beat (4 VRAM entries/beat), be=FF, PLUS a 1-deep
    // WRITE/READ FORWARD of the last beat this side wrote. Two silicon hazards motivate it:
    //   (a) BE: a masked single-beat write relies on the bridge honoring per-byte write-enables on a
    //       1-beat burst, which the real f2h_sdram1 does NOT -> full-beat be=FF write instead.
    //   (b) POSTED WRITES: the bridge accepts a write before the data lands, so a per-entry RMW that
    //       RE-READS the beat for the next entry can read STALE DDR data and clobber the neighbor.
    //       This failed the cab's VRAM self-test ("RAM CHIPS BAD"): the game writes all 4 entries of
    //       every beat back-to-back. FORWARDING makes same-beat accesses use the local copy (fwd_beat)
    //       instead of re-reading DDR -> correct independent of commit latency. The full-beat write
    //       still goes to DDR every time (persist + scanout). Sim's DDR model commits instantly so it
    //       exposed NEITHER hazard -- the same charitable-oracle gap for both.
    wire  [63:0] rmw_merged = (a_lane==2'd0) ? {rmw_beat[63:16], rmw_din}
                            : (a_lane==2'd1) ? {rmw_beat[63:32], rmw_din, rmw_beat[15:0]}
                            : (a_lane==2'd2) ? {rmw_beat[63:48], rmw_din, rmw_beat[31:0]}
                            :                  {rmw_din, rmw_beat[47:0]};
`ifdef PERF_NO_BEATCACHE2
    // MUTATION baseline: the original 1-deep write-allocate-only forward.
    logic [63:0] fwd_beat;             // local copy of the last beat this side wrote
    logic [25:0] fwd_addr;  logic fwd_valid;
`else
    // PERF (boot ~50x-slow fix, part 2): the 1-deep write-forward EXTENDED to a
    // 2-ENTRY BEAT CACHE, read-allocate AND write-allocate. The RAMCHECK's 3-word
    // straddling fields gather 6 entries = 2-3 shared beats per cell, and its
    // ascending sweep overlaps the previous cell's tail beat — with only the
    // last-written beat forwarded, 4-5 of those 6 gather reads re-read DDR3 every
    // cell. Two entries cover the whole working set of the field engine (a field
    // never spans more than 3 beats, and the gather walks them monotonically), so
    // this is 130ish flops, deliberately NOT a general cache and NOT BRAM.
    //
    // PRESERVED semantics: the cache IS the posted-write forward (a write always
    // updates/allocates its entry, and the full-beat be=FF write still goes to
    // DDR3 every time — persist + scanout); wt/srcwt write-throughs fire exactly
    // as before (from A_RMW_MRG, off rmw_merged); reset is the only bulk
    // invalidation, PLUS a C-erase snoop (below) that the 1-deep version lacked.
    //
    // POSTED-WRITE SAFETY invariant: the bridge holds at most the MOST RECENT
    // write uncommitted (the next accepted write flushes it). So a DDR3 re-read
    // is only hazardous for the beat of the most recent write — that beat is
    // always cache-resident: a write updates its entry, and READ-allocation is
    // forbidden from evicting the last-written entry (rd_alloc below). Write-
    // allocation MAY evict it: the RMW's full-beat write ACCEPT flushes the older
    // posted write before any later read can reach DDR3.
    logic [63:0] bc_beat0, bc_beat1;   // cached beats
    logic [25:0] bc_addr0, bc_addr1;   // their beat addresses
    logic        bc_v0, bc_v1;         // entry valid
    logic        bc_lru;               // eviction candidate (least recently used)
    logic        bc_lastwr;            // entry holding the MOST RECENT write
    logic        bc_lastwr_v;
    logic        bc_alloc;             // allocation target latched for the in-flight miss
    // S4 INC2/3: bc is A's own 2-entry BACK-buffer beat cache (filled from a_rdata/rmw_merged). Disable
    // its forward in double-buffer so A never serves a beat cached under the PREVIOUS frame's back buffer
    // (stale across the swap) -> A always reads the current back buffer from DDR. (Correct; loses only fwd.)
    wire         bc_hit0 = !dbl_on && bc_v0 && (bc_addr0 == a_addr);
    wire         bc_hit1 = !dbl_on && bc_v1 && (bc_addr1 == a_addr);
    wire         hit_idx = bc_hit1;    // (hits are exclusive: duplicate tags impossible —
                                       //  a write hit updates in place, never re-allocates)
    wire  [63:0] fwd_beat = bc_hit1 ? bc_beat1 : bc_beat0;
    // allocation targets: an invalid entry first, else LRU; read-allocation must
    // additionally never evict the last-written entry (see invariant above).
    wire         wr_alloc = !bc_v0 ? 1'b0 : !bc_v1 ? 1'b1 : bc_lru;
    wire         rd_alloc = !bc_v0 ? 1'b0 : !bc_v1 ? 1'b1 :
                            (bc_lastwr_v && (bc_lru == bc_lastwr)) ? ~bc_lru : bc_lru;
`endif
    logic        a_is_wr;
    // ------- A-LANE WRITE-BEHIND (A_WBACK, cont.19 CPU-VRAM latency fix) -----------------------
    // MEASURED (tb_vram_ddr_acost): a CPU field RMW = 1 beat-read + 2 same-beat entry-writes = 3 DDR
    // ops = 72 clk, because the field engine writes a 16b field as 2 entries (vram_sdram.sv:11) and
    // the A cache is write-THROUGH (each entry-write -> its own full-beat DDR write). The 2 writes
    // (and an object cluster's read pos/write x/write y) all hit the SAME beat -> coalesce them.
    // wb = 1-deep dirty-beat buffer: A_RMW_MRG defers the DDR write into wb (coalescing same-beat),
    // and wb is FLUSHED before any DIFFERENT-beat access (no eviction/read staleness: wb is written
    // out before the cache is touched for another beat) and on idle. awt/asrcwt still fire every
    // write (B/C caches stay fresh for the displayed row); C/D writing wb's beat invalidates wb.
    logic        wb_v;                 // a deferred (dirty) beat is pending flush
    logic [25:0] wb_addr;              // its beat address
    logic [63:0] wb_data;              // its data
    logic [25:0] a_addr_save;          // request beat held across a flush-before-access
    logic        flush_pend;           // A_FLUSH returns to A_DEC (1) vs A_IDLE (0, idle-flush)
    logic [4:0]  wb_idle;              // idle cycles since wb last touched (hold before idle-flush so
    localparam [4:0] WB_FLUSH_IDLE = 5'd16;  // the field engine's back-to-back entry-writes coalesce)
    // A->B / A->C COHERENCY write-throughs. BOTH the A CPU-RMW lane AND the new D fb-combine lane
    // land real VRAM beats, so each write-through has TWO producers (awt_/asrcwt_ from A, dwt_/
    // dsrcwt_ from D) merged into the wt_/srcwt_ wires the B and C blocks consume. A and D writes
    // are TEMPORALLY EXCLUSIVE (A is granted only when !d_busy, and D accepts no fb pixels while
    // a_start is held -> D is fully idle throughout any A access), so the A-priority mux below can
    // never drop a live D pulse.
    //
    // A->B scanout-cache write-through: a write into the row B currently caches pushes the merged
    // beat into rc[] so a concurrently-scanned row shows FRESH data (else CPU/blitter drawing the
    // displayed buffer while B serves that row from cache = stale-vs-fresh frames = "purple flash").
    logic        awt_req;  logic [6:0] awt_col;  logic [63:0] awt_data;   // from A (A_RMW_MRG)
    logic        dwt_req;  logic [6:0] dwt_col;  logic [63:0] dwt_data;   // from D (fb flush)
    // A->C source-row (510/511) write-through: keeps the C engine's src_cache[] fresh so the beam-
    // locked erase copies live pattern data (parity-select per MAME midyunit_v.cpp:539 510+(line&1)).
    // MYOINIT's pattern fill is a DMA blit = fb writes, which now ride D -> D must produce this too.
    logic        asrcwt_req;  logic [7:0] asrcwt_idx;  logic [63:0] asrcwt_data;   // from A
    logic        dsrcwt_req;  logic [7:0] dsrcwt_idx;  logic [63:0] dsrcwt_data;   // from D
    // merged views (A wins the impossible tie): the B block reads wt_*, the C block reads srcwt_*.
    wire         wt_req  = !dbl_on && (awt_req | dwt_req);  // S4 INC2: no A/D(back) write-through into B's FRONT cache
    wire  [6:0]  wt_col  = awt_req ? awt_col  : dwt_col;
    wire  [63:0] wt_data = awt_req ? awt_data : dwt_data;
    wire         srcwt_req  = asrcwt_req | dsrcwt_req;
    wire  [7:0]  srcwt_idx  = asrcwt_req ? asrcwt_idx  : dsrcwt_idx;
    wire  [63:0] srcwt_data = asrcwt_req ? asrcwt_data : dsrcwt_data;
    // fwd_hit compares the REGISTERED a_addr (latched in A_IDLE) against the cached tags -> reg-to-reg,
    // so the deep u_acc/autoerase address generation never feeds rmw_beat combinationally (that path
    // violated setup by -0.327ns when the compare used the live sd_addr). Decision is taken one cycle
    // later in A_DEC; the extra cycle per VRAM access is negligible vs the once-per-row scanout burst.
    // (The 2-entry cache adds one more 26-bit reg-to-reg compare in parallel — same depth.)
`ifdef PERF_NO_BEATCACHE2
    wire         fwd_hit = fwd_valid && (fwd_addr == a_addr);
`else
    wire         fwd_hit = bc_hit0 | bc_hit1;
`endif
    localparam [2:0] A_IDLE=3'd0, A_DEC=3'd1, A_WAIT=3'd2, A_ACK=3'd3, A_RMW_RD=3'd4, A_RMW_MRG=3'd5, A_FLUSH=3'd6;
    logic [2:0] ats;
    wire a_req_pending = sd_rd || sd_wr;
    wire a_flush_due   = wb_v && (wb_idle >= WB_FLUSH_IDLE);
    // Ownership claim seen by D admission. A live accessor request or a due
    // write-behind flush wins over accepting another framebuffer pixel.
    wire a_claim = (ats != A_IDLE) || a_start || a_req_pending || a_flush_due;
    always_ff @(posedge clk) begin
        if (rst) begin
            ats<=A_IDLE; a_start<=1'b0; a_wr<=1'b0; a_addr<=26'd0; a_wdata<=64'd0; a_be<=8'd0;
            a_lane<=2'd0; rmw_din<=16'd0; rmw_beat<=64'd0; sd_ack<=1'b0; sd_dout<=16'd0;
            wb_v<=1'b0; wb_addr<=26'd0; wb_data<=64'd0; a_addr_save<=26'd0; flush_pend<=1'b0; wb_idle<=5'd0;
`ifdef PERF_NO_BEATCACHE2
            fwd_beat<=64'd0; fwd_addr<=26'd0; fwd_valid<=1'b0;
`else
            bc_beat0<=64'd0; bc_beat1<=64'd0; bc_addr0<=26'd0; bc_addr1<=26'd0;
            bc_v0<=1'b0; bc_v1<=1'b0; bc_lru<=1'b0; bc_lastwr<=1'b0; bc_lastwr_v<=1'b0; bc_alloc<=1'b0;
`endif
            a_is_wr<=1'b0; awt_req<=1'b0;
            asrcwt_req<=1'b0; asrcwt_idx<=8'd0; asrcwt_data<=64'd0;
        end else begin
            sd_ack <= 1'b0; awt_req <= 1'b0; asrcwt_req <= 1'b0;
`ifdef PERF_NO_BEATCACHE2
            // fb-combine (D) or erase (C) writes can supersede A's 1-deep forward copy; never let a
            // CPU RMW merge into a stale forward. (The beat-cache path does an ADDRESSED invalidate.)
            // d_add = a run-buffer beat commit (on-add); (d_start&&d_wr) = partial RMW / burst launch.
            if ((c_start && c_wr) || (d_start && d_wr) || d_add
`ifdef YUNIT_SRT_FILL_BURST
                || e_write_invalidate
`endif
               ) fwd_valid <= 1'b0;
`endif
            case (ats)
                A_IDLE: begin                   // D ownership drains before A may latch/forward/flush
                  if (!d_busy) begin
                    if (b_fill_lock && wb_v) begin
                        // B_DRAIN must commit preexisting A write-behind data before the atomic
                        // row fill starts. Ignore the normal coalescing age; do not admit the held
                        // sd_rd/sd_wr until B publishes the completed row.
                        flush_pend<=1'b0; a_addr<=wb_addr; a_wdata<=wb_data;
                        a_be<=8'hFF; a_wr<=1'b1; a_start<=1'b1; ats<=A_FLUSH;
                    end else if (!b_fill_lock
`ifdef YUNIT_SRT_FILL_BURST
                                && !e_block
`endif
                                && sd_rd) begin
                        a_lane<=sd_addr[1:0]; a_addr<={10'd0,sd_addr[17:2]}; a_addr_save<={10'd0,sd_addr[17:2]}; a_is_wr<=1'b0;
                        if (wb_v && (wb_addr != {10'd0,sd_addr[17:2]})) begin  // flush-before-access
                            flush_pend<=1'b1; a_addr<=wb_addr; a_wdata<=wb_data; a_be<=8'hFF; a_wr<=1'b1; a_start<=1'b1; ats<=A_FLUSH;
                        end else ats<=A_DEC;
                    end else if (!b_fill_lock
`ifdef YUNIT_SRT_FILL_BURST
                                && !e_block
`endif
                                && sd_wr) begin
                        a_lane<=sd_addr[1:0]; a_addr<={10'd0,sd_addr[17:2]}; a_addr_save<={10'd0,sd_addr[17:2]}; rmw_din<=sd_din; a_is_wr<=1'b1;
                        if (wb_v && (wb_addr != {10'd0,sd_addr[17:2]})) begin  // flush-before-access
                            flush_pend<=1'b1; a_addr<=wb_addr; a_wdata<=wb_data; a_be<=8'hFF; a_wr<=1'b1; a_start<=1'b1; ats<=A_FLUSH;
                        end else ats<=A_DEC;
                    end else if (!b_fill_lock && wb_v) begin // normal idle coalescing outside B fill
                        if (wb_idle >= WB_FLUSH_IDLE) begin   // same-beat entry-writes coalesce, THEN flush
                            flush_pend<=1'b0; a_addr<=wb_addr; a_wdata<=wb_data; a_be<=8'hFF; a_wr<=1'b1; a_start<=1'b1; ats<=A_FLUSH;
                        end else wb_idle <= wb_idle + 5'd1;
                    end
                  end
                end
                A_DEC: begin                    // reg-to-reg fwd_hit decision
                    if (fwd_hit) begin
                        if (a_is_wr) begin rmw_beat<=fwd_beat; ats<=A_RMW_MRG; end   // WRITE-FORWARD
                        else begin                                                   // READ-FORWARD
                            case (a_lane)
                                2'd0: sd_dout<=fwd_beat[15:0]; 2'd1: sd_dout<=fwd_beat[31:16];
                                2'd2: sd_dout<=fwd_beat[47:32]; default: sd_dout<=fwd_beat[63:48];
                            endcase
                            sd_ack<=1'b1; ats<=A_ACK;
                        end
`ifndef PERF_NO_BEATCACHE2
                        bc_lru   <= ~hit_idx;                          // hit entry = most recently used
                        bc_alloc <= hit_idx;                           // a write-hit updates IN PLACE
`endif
                    end else begin                                                   // MISS: go to DDR
                        a_wr<=1'b0; a_start<=1'b1; ats<= a_is_wr ? A_RMW_RD : A_WAIT;
`ifndef PERF_NO_BEATCACHE2
                        bc_alloc <= a_is_wr ? wr_alloc : rd_alloc;     // latch the eviction target
`endif
                    end
                end
                A_WAIT: begin                   // completion of a plain READ (sd_rd) OR the RMW full-beat WRITE
                    if (a_rd_valid) begin
                        case (a_lane)
                            2'd0: sd_dout<=a_rdata[15:0]; 2'd1: sd_dout<=a_rdata[31:16];
                            2'd2: sd_dout<=a_rdata[47:32]; default: sd_dout<=a_rdata[63:48];
                        endcase
`ifndef PERF_NO_BEATCACHE2
                        // READ-ALLOCATE the whole beat (miss reads only reach A_WAIT with
                        // a_rd_valid; the RMW write completion has no read beats). rd_alloc
                        // (latched into bc_alloc) never evicts the last-written entry.
                        if (!a_is_wr) begin
                            if (bc_alloc) begin bc_beat1<=a_rdata; bc_addr1<=a_addr; bc_v1<=1'b1; end
                            else          begin bc_beat0<=a_rdata; bc_addr0<=a_addr; bc_v0<=1'b1; end
                            bc_lru <= ~bc_alloc;
                        end
`endif
                    end
                    if (a_done) begin a_start<=1'b0; sd_ack<=1'b1; ats<=A_ACK; end
                end
                A_RMW_RD: begin                 // RMW step 1: read the shared beat from DDR (miss, a_wr=0)
                    // shadow override: a recently-written beat's merge base comes from
                    // the RTL's own newest data, immune to publication depth.
                    if (a_rd_valid) rmw_beat <= (shw_en && shw_base_hit) ? shw_base : a_rdata;
                    if (a_done) begin a_start<=1'b0; ats<=A_RMW_MRG; end   // drop start -> L2 bubbles to IDLE
                end
                A_RMW_MRG: begin                // RMW step 2: merge the lane, write the FULL beat + remember it
`ifndef PERF_NO_WBACK
                    // WRITE-BEHIND (DEFAULT — cab-proven cont.20, fixed the starvation reboot): defer
                    // the DDR write into wb (coalesces the field engine's 2 same-beat entry-writes +
                    // an object cluster into ONE flush; CPU-VRAM RMW 72->59 clk, cluster 51->25). The
                    // cache update + awt/asrcwt below still fire (reads forward from cache, B/C stay
                    // fresh); wb flushes before any different-beat access (A_IDLE) or on idle.
                    // (-DPERF_NO_WBACK reverts to the old write-through for A/B testing.)
                    wb_v<=1'b1; wb_addr<=a_addr; wb_data<=rmw_merged; wb_idle<=5'd0; sd_ack<=1'b1; ats<=A_ACK;
`else
                    a_wdata<=rmw_merged; a_be<=8'hFF; a_wr<=1'b1; a_start<=1'b1; ats<=A_WAIT;
`endif
`ifdef PERF_NO_BEATCACHE2
                    fwd_beat<=rmw_merged; fwd_addr<=a_addr; fwd_valid<=1'b1;
`else
                    // WRITE-ALLOCATE/UPDATE: a hit updates its own entry (bc_alloc was set
                    // to hit_idx in A_DEC — duplicate tags are structurally impossible), a
                    // miss lands in the latched wr_alloc target. This entry is now both the
                    // posted-write forward AND the most recent write.
                    if (bc_alloc) begin bc_beat1<=rmw_merged; bc_addr1<=a_addr; bc_v1<=1'b1; end
                    else          begin bc_beat0<=rmw_merged; bc_addr0<=a_addr; bc_v0<=1'b1; end
                    bc_lru      <= ~bc_alloc;
                    bc_lastwr   <= bc_alloc;
                    bc_lastwr_v <= 1'b1;
`endif
                    awt_req <= (rc_valid && (a_addr[15:7]==rc_row));   // write-through into B's cache if it holds this row
                    awt_col <= a_addr[6:0]; awt_data <= rmw_merged;
                    // A->C source-row cache write-through (rows 510/511). a_addr is the beat index
                    // (entry>>2); its top 9 bits [15:7] are the VRAM row, [6:0] the beat-in-row.
                    // src_cache is 256 deep: [0..127]=row510, [128..255]=row511 (bit7 selects half).
                    asrcwt_req  <= (a_addr[15:7]==9'd510) || (a_addr[15:7]==9'd511);
                    asrcwt_idx  <= {(a_addr[15:7]==9'd511), a_addr[6:0]};
                    asrcwt_data <= rmw_merged;
                end
                A_ACK: ats<=A_IDLE;            // 1-cyc bubble so sd_rd/sd_wr clear
                A_FLUSH: if (a_done) begin     // the deferred write-behind beat committed to DDR
                    a_start<=1'b0; a_wr<=1'b0; wb_v<=1'b0;
                    if (flush_pend) begin a_addr<=a_addr_save; ats<=A_DEC; end  // resume the held request
                    else                  ats<=A_IDLE;                          // idle-flush done
                end
                default: ats<=A_IDLE;
            endcase
`ifndef PERF_NO_BEATCACHE2
            // C-ERASE SNOOP (placed AFTER the case so it wins a same-cycle allocate of
            // the same entry): the autoerase engine writes whole beats behind the beam;
            // a cached copy of an erased beat would serve pre-erase data to a later CPU
            // read. The 1-deep forward had this same staleness window (never invalidated
            // until the next write) — read-allocation would WIDEN it, so close it here.
            // No posted-write hazard opens up: C's write ACCEPT flushes any older posted
            // A write in the bridge before a re-read of the invalidated beat can issue
            // (single-outstanding L2 + the bridge's flush-on-next-write-accept).
            if (c_start && c_wr) begin
                if (bc_v0 && (bc_addr0 == c_addr)) bc_v0 <= 1'b0;
                if (bc_v1 && (bc_addr1 == c_addr)) bc_v1 <= 1'b0;
            end
            // D (fb-combine) SNOOP: a combined fb beat write must invalidate any A beat-cache copy of
            // that beat, else a later CPU read/RMW merges into stale pre-fb data. Two producers now:
            //  (1) ON-ADD (d_add): each FULL beat as it ENTERS the run-buffer -- the burst commits many
            //      beats under ONE d_start, so the per-beat snoop MUST ride the add, not the drain.
            //  (2) the single-beat PARTIAL RMW write (d_start && d_wr && !d_is_burst) -- immediate.
            if (d_add) begin
                if (bc_v0 && (bc_addr0 == {10'd0, d_add_beat})) bc_v0 <= 1'b0;
                if (bc_v1 && (bc_addr1 == {10'd0, d_add_beat})) bc_v1 <= 1'b0;
            end
            if (d_start && d_wr && !d_is_burst) begin
                if (bc_v0 && (bc_addr0 == d_addr)) bc_v0 <= 1'b0;
                if (bc_v1 && (bc_addr1 == d_addr)) bc_v1 <= 1'b0;
            end
`ifdef YUNIT_SRT_FILL_BURST
            // A row-pair transfer replaces 256 beats.  The two-entry A cache
            // is tiny; clearing both entries is cheaper and safer than a span
            // comparator on the cache writeback path.
            if (e_write_invalidate) begin
                bc_v0 <= 1'b0; bc_v1 <= 1'b0; bc_lastwr_v <= 1'b0;
            end
`endif
`endif
            // The deferred A beat exists in BOTH cache configurations. Clear it only when a
            // later C/D write has actually launched ownership of the same beat. For the D-partial
            // wb-bypass path, d_wdata already contains wb_data merged with the new D lanes before
            // this edge, so no A data is discarded. Keep these clears outside BEATCACHE2's ifdef.
            if (c_start && c_wr && wb_v && (wb_addr == c_addr)) wb_v <= 1'b0;
            if (d_add && wb_v && (wb_addr == {10'd0, d_add_beat})) wb_v <= 1'b0;
            if (d_start && d_wr && !d_is_burst && wb_v && (wb_addr == d_addr)) wb_v <= 1'b0;
        end
    end

    // ================= B: scanout row-burst cache ============================================
    (* ramstyle="no_rw_check" *) logic [63:0] rc [0:127];   // one row = 128 beats x 4 entries
    // rc_row, rc_valid hoisted to top (Questa declare-before-use)
    // One-deep full-rate BSNOOP commit stage.  A returned beat is captured here while the
    // preceding entry writes rc[] on the same clock, so the merge cone ends at registers
    // without inserting bubbles in a contiguous DDR return stream.  Preserve these exact
    // audit names: fitter retiming/merging them back into rc[] would recreate the hot path.
    (* preserve, dont_merge *) logic        bsn_commit_v;
    (* preserve, dont_merge *) logic [6:0]  bsn_commit_addr;
    (* preserve, dont_merge *) logic [63:0] bsn_commit_data;
    logic bsn_commit_done_q;             // terminal beat landed; cleared when a new miss starts
`ifndef SYNTHESIS
    logic        bsn_expect_v, bsn_final_commit_q, bsn_rc_valid_q;
    logic [6:0]  bsn_expect_addr;
    logic [63:0] bsn_expect_data;
`endif
    // wt PEND (1-deep, ROW-TAGGED): the rc[] BRAM has a SINGLE write port. A staged refill commit always
    // wins it; an A->B write-through (wt_req) arriving on that same cycle would otherwise be silently
    // DROPPED (the stv_vram_ddr_top.sv:236-239 drop race). Instead, LATCH the colliding write-through
    // (col + data + its ROW) into a 1-deep pending slot and drain it on the next port-free cycle -- but
    // ONLY if rc still caches that row (coherent). The row tag matters because a write-through can only
    // collide with a fill of a DIFFERENT row (B hits, never re-fills, the currently cached row), so the
    // pended write's target row is usually being evicted by that very fill; draining it blindly would
    // stamp stale data into the newly-filled row's cache. The row-tag gate makes the drain a no-op in
    // that (normal) case and correct in any case where the row is still cached. Depth 1 suffices: A
    // issues at most one write-through per multi-cycle RMW, so a second cannot land before the first
    // drains. (DDR always gets the A write regardless -- this only concerns the same-frame cache copy.)
    logic        wtp_v;  logic [6:0] wtp_col;  logic [63:0] wtp_data;  logic [8:0] wtp_row;
    wire  [8:0]  req_row = scan_addr[17:9];   // continuous (NOT `logic = ...`, which is init-only)
    wire  [8:0]  req_col = scan_addr[8:0];
    logic [63:0] rc_q;  wire [6:0] rc_raddr = req_col[8:2];  logic [1:0] rc_rlane;
    always_ff @(posedge clk) rc_q <= rc[rc_raddr];          // reads the CURRENT scan col's beat (1 clk)

    logic        b_start;
    logic [25:0] b_addr;
    logic [7:0]  b_burstlen;           // per-sub-burst length (to L2)
    logic        b_done, b_rd_valid;   // driven by L2
    logic [63:0] b_rdata;              // driven by L2
    logic [7:0]  fillbeat;
    logic [8:0]  fill_row;             // miss row latched for the entire atomic fill
    // Cycle-exact B-fill keys used only by BSNOOP and the commit-stage capture.
    // These are spatial copies, never pipeline stages.
    (* preserve, dont_merge *) logic [8:0] bsn_fill_row_q;
    (* preserve, dont_merge *) logic [6:0] bsn_fillbeat_q;
    // Cycle-exact duplicate of fill_row consumed ONLY by the fb park compare
    // (fb_fill_park): same D, same enables, same clock. fill_row's own copy
    // stays with the fill engine's deep fanout (b_addr/bfill_bt/rc_row); this
    // one lets the fitter place a register AT the fb accept cone instead of
    // routing across it -- the ADPCM config's chronic worst path (r8a STA:
    // fill_row[4] -> yunit_dma o_ptr[*], -0.174 ns; previously +0.176).
    // dont_merge: Quartus's duplicate-register removal would undo the split.
    (* dont_merge *) logic [8:0] park_row;
    // A row = 128 beats, but the REAL HPS f2sdram UNDER-DELIVERS a burst longer than its max
    // (NS ran 32-beat bursts on HW; the 128-beat request stalled the fill on silicon -> the
    // pulsing-line-on-white hang, reproduced in tb_vram_ddr_xdiff with the 32-cap oracle). Fill
    // the row in <=BMAX sub-bursts, re-requesting from wherever fillbeat reached.
    localparam [7:0] BMAX = 8'd32;
    localparam [2:0] B_IDLE=3'd0, B_REQ=3'd1, B_FILL=3'd2, B_HIT=3'd3, B_WAIT=3'd4,
                     B_DRAIN=3'd5, B_COMMIT=3'd6;
    logic [2:0] bts;
`ifdef MUT_BFILL_NOLOCK
    assign b_fill_lock = 1'b0;
    assign b_bus_lock  = 1'b0;
`else
    assign b_fill_lock = (bts==B_DRAIN) || (bts==B_REQ) || (bts==B_FILL) || (bts==B_COMMIT);
    assign b_bus_lock  = (bts==B_REQ) || (bts==B_FILL);
`endif
    always_ff @(posedge clk) begin
        if (rst) begin
            bts<=B_IDLE; b_start<=1'b0; b_addr<=26'd0; b_burstlen<=8'd0; rc_valid<=1'b0; rc_row<=9'd0;
            fillbeat<=8'd0; bsn_fillbeat_q<=7'd0;
            fill_row<=9'd0; bsn_fill_row_q<=9'd0; park_row<=9'd0;
            rc_rlane<=2'd0; scan_ack<=1'b0; scan_data<=16'd0;
            wtp_v<=1'b0; wtp_col<=7'd0; wtp_data<=64'd0; wtp_row<=9'd0;
            bsn_commit_v<=1'b0; bsn_commit_addr<=7'd0; bsn_commit_data<=64'd0;
            bsn_commit_done_q<=1'b0;
        end else begin
            scan_ack <= 1'b0;
            // Capture and commit can both be true: this is a one-entry pipeline, not a skid
            // buffer.  bfill_merged/address are sampled only on a real B return beat.
            bsn_commit_v <= (bts==B_FILL) && b_rd_valid;
            if ((bts==B_FILL) && b_rd_valid) begin
                bsn_commit_addr <= bsn_fillbeat_q;
                bsn_commit_data <= bfill_merged;
            end
            case (bts)
                B_IDLE: if (scan_req) begin
                    // S4: in double-buffer, rc must also match the buffer it was filled under, else a
                    // row cached from the PREVIOUS frame's front (e.g. a vblank reprime of rows 0/1) is
                    // served after the swap = stale scanout (caught by tb_vram_doublebuffer (c)).
                    if (rc_valid && (rc_row==req_row) && (!dbl_on || (rc_fbsel==fb_sel))) begin   // HIT
                        rc_rlane<=req_col[1:0]; bts<=B_HIT;
                    end else begin                                   // MISS -> fill the row in <=BMAX sub-bursts
                        fillbeat<=8'd0; bsn_fillbeat_q<=7'd0;
                        bsn_commit_done_q<=1'b0;
`ifdef MUT_BFILL_NOLOCK
                        bts<=B_REQ;                                  // mutation: old live-tag/non-atomic behavior
`else
                        fill_row<=req_row; bsn_fill_row_q<=req_row; park_row<=req_row;
                        rc_valid<=1'b0; wtp_v<=1'b0;
 `ifdef MUT_NO_BSNOOP
                        bts<=B_DRAIN;    // mutation: the old unbounded drain-wait barrier
 `else
                        bts<=B_REQ;      // BSNOOP: fill immediately; coherency via the bfill_merged snoop
 `endif
`endif
                    end
                end
                B_DRAIN: begin
                    // Drain only PREEXISTING A/D ownership. Held new sd_rd/sd_wr and fb_pend
                    // are deliberately excluded or the barrier would deadlock on work it blocks.
                    if ((ats==A_IDLE) && !a_start && !wb_v && !d_busy && !d_start &&
                        !c_start && (ls==2'd0) && !tst_busy)
                        bts<=B_REQ;
                end
                B_REQ: begin                                        // set up the next sub-burst from fillbeat
`ifdef MUT_BFILL_NOLOCK
                    b_addr     <= {10'd0, req_row, 7'd0} + {18'd0, fillbeat};
`else
                    b_addr     <= {10'd0, fill_row, 7'd0} + {18'd0, fillbeat};
`endif
                    b_burstlen <= ((8'd128 - fillbeat) > BMAX) ? BMAX : (8'd128 - fillbeat);
                    b_start    <= 1'b1; bts <= B_FILL;
                end
                B_FILL: begin
                    if (b_rd_valid) begin
                        fillbeat <= fillbeat + 8'd1;
                        bsn_fillbeat_q <= fillbeat[6:0] + 7'd1;
                    end                                             // merged beat captured into the commit stage below
                    if (b_done) begin                               // sub-burst complete
                        b_start <= 1'b0;
                        if (fillbeat >= 8'd128) begin
                            // Normally b_done arrives on the same edge that commits beat 127.
                            // Fail closed in B_COMMIT if an agent changes that alignment.
                            if (bsn_commit_done_q || (bsn_commit_v && (bsn_commit_addr==7'd127))) begin
                                rc_valid<=1'b1; rc_fbsel<=fb_sel;
`ifdef MUT_BFILL_NOLOCK
                                rc_row<=req_row;
`else
                                rc_row<=fill_row;
`endif
                                bts<=B_IDLE;
                            end else bts<=B_COMMIT;
                        end
                        else bts <= B_REQ;                          // more of the row to fetch
                    end
                end
                B_COMMIT: begin
                    // Keep the row-fill admission lock until the registered terminal beat lands.
                    if (bsn_commit_done_q || (bsn_commit_v && (bsn_commit_addr==7'd127))) begin
                        rc_valid<=1'b1; rc_fbsel<=fb_sel;
`ifdef MUT_BFILL_NOLOCK
                        rc_row<=req_row;
`else
                        rc_row<=fill_row;
`endif
                        bts<=B_IDLE;
                    end
                end
                B_HIT: begin                                          // rc_q valid now
                    case (rc_rlane)
                        2'd0: scan_data<=rc_q[15:0]; 2'd1: scan_data<=rc_q[31:16];
                        2'd2: scan_data<=rc_q[47:32]; default: scan_data<=rc_q[63:48];
                    endcase
                    scan_ack<=1'b1; bts<=B_WAIT;
                end
                B_WAIT: if (!scan_req) bts<=B_IDLE;   // ONE ack per request: wait for the consumer to drop
                                                      // scan_req before re-arming, else B_IDLE re-detects the
                                                      // still-high scan_req as a 2nd hit -> double-serve ->
                                                      // the next column reads this column's beat (col shift).
                default: bts<=B_IDLE;
            endcase
            // rc[] SINGLE write port with 1-deep ROW-TAGGED PEND for write-through collisions:
            //   priority: (1) registered refill COMMIT always wins the port;
            //             (2) else DRAIN a pending write-through, but only if rc still caches its row
            //                 (coherent); if the row was evicted by the fill, discard (clear wtp_v);
            //             (3) else apply a fresh non-colliding wt_req directly.
            // A fresh wt_req colliding with a refill commit (case 1) is CAPTURED into the pend (with its
            // row = rc_row at capture) rather than lost. This closes the :236-239 drop race.
            if (bsn_commit_v) begin
                rc[bsn_commit_addr] <= bsn_commit_data;
                if (bsn_commit_addr == 7'd127) bsn_commit_done_q<=1'b1;
                if (wt_req) begin wtp_v<=1'b1; wtp_col<=wt_col; wtp_data<=wt_data; wtp_row<=rc_row; end  // PEND (was dropped)
            end else if (wtp_v) begin
                if (rc_valid && (rc_row == wtp_row)) rc[wtp_col] <= wtp_data;            // coherent drain
                wtp_v <= 1'b0;                                                            // (else discard: row evicted)
                if (wt_req) begin wtp_v<=1'b1; wtp_col<=wt_col; wtp_data<=wt_data; wtp_row<=rc_row; end  // re-pend a fresh collision
            end else if (wt_req) begin
                rc[wt_col] <= wt_data;                                                   // no collision: apply directly
            end
`ifdef YUNIT_SRT_FILL_BURST
            // Full-span replacement wins over a same-cycle fill completion.
            if (e_write_invalidate && (rc_row == e_invalidate_row)) begin
                rc_valid <= 1'b0;
                wtp_v <= 1'b0;
            end
`endif
        end
    end

    // ================= C: beam-locked per-scanline AUTOERASE engine =========================
    // MAME midyunit_v.cpp:534-559 autoerase_line(scanline): memcpy(&vram[512*line],
    //   &vram[512*(510+(line&1))], 1024) for 0<=line<510, called every scanline as
    //   autoerase_line(rowaddr-1) — ONE ROW BEHIND THE BEAM. We snoop the existing scan_addr's
    //   req_row: on a row change we latch erase_row = displayed_row-1 and copy one row's worth
    //   of 128 pre-merged 64-bit beats from the parity-selected source-row cache to erase_row,
    //   as WHOLE-BEAT be=FF writes (NO per-entry RMW — the old bulk sweep's 5-7M clk/frame cost).
    //
    // Source-row cache: 256x64b BRAM = row510 in [0..127], row511 in [128..255], parity-selected
    // by erase_row[0] (MAME :539 510+(scanline&1)). Kept fresh by the A-side srcwt_* write-through;
    // lazily burst-filled from DDR3 (through L2, like B) at cold start before any write-through.
    (* ramstyle="no_rw_check" *) logic [63:0] src_cache [0:255];
    logic        src510_valid, src511_valid;
    logic [63:0] src_q;                      // 1-clk BRAM read of the current erase beat's source
    logic [7:0]  src_raddr;                  // {parity, c_beat}
`ifdef YUNIT_SRT_FILL_BURST
    // SRT write bursts stream directly from the same synchronous cache C uses.
    // The accepted-beat lookahead keeps src_q one beat ahead of Avalon FWFT.
    wire         srt_stream = (est == E_WREQ) || (est == E_WSTREAM);
    wire [7:0]   src_cache_raddr = srt_stream
                                     ? (e_fill[7:0] + {7'd0, e_burst_next})
                                     : src_raddr;
`else
    wire [7:0]   src_cache_raddr = src_raddr;
`endif
    always_ff @(posedge clk) src_q <= src_cache[src_cache_raddr];

    // Trigger: req_row transition detector (req_row is the B-side wire = scan_addr[17:9]).
    //
    // GOAL/CATCH-UP ARCHITECTURE (the cab-stripes fix, reproduced by tb_vram_ddr_raster):
    // scan_addr comes from yunit_scanline's PREFETCH loader, whose tgt_row (a) runs one row
    // AHEAD of the display, (b) loads row V_ACT (256) during the last visible line, and (c)
    // re-primes rows 0/1 back-to-back DURING vblank -- so row transitions arrive in BURSTS
    // faster than one ~1.2k-clk erase. The old edge-triggered C_IDLE handshake silently
    // DROPPED any transition that fired while C was busy: rows 0-4 were never erased (the
    // white stripes on the cab), and the P1.9b wrap rule erased prefetch row 256 -- VRAM the
    // real hardware never touches (midyunit scanline_update only walks displayed rows).
    // FIX: triggers are DECOUPLED from execution. Every transition latches a GOAL row
    // (er_goal, always 0..255 -- targets outside the visible range are structurally
    // rejected, which also subsumes the old 510/511 skip guard); the erase FSM marches
    // er_next -> er_goal, erasing EVERY row in order, immune to trigger bursts. Erase is
    // ~5x faster than a line, so it stays caught up in steady state and clears the vblank
    // burst backlog within the first few active lines -- every visible row is erased every
    // frame, exactly like the real per-scanline hardware.
    logic [8:0] req_row_d;
    always_ff @(posedge clk) req_row_d <= req_row;
    wire row_changed = (req_row != req_row_d);
    // target row = new_row-1 (MAME :554 one-behind-the-beam, which with the prefetch lead =
    // the currently-displayed row). Frame-WRAP transitions (row decreases -- only possible
    // across vblank) latch NO goal: with the real prefetcher every visible row is already
    // covered by +1 transitions (the row-V_ACT prefetch covers the last visible row; the
    // vblank re-prime's 0->1 covers row 0), and a wrap goal is not merely redundant -- it is
    // the deadlock found by tb_vram_ddr_raster: a stale goal of 255 after er_next wrapped to
    // 0 reads as a 255-row backlog, the catch-up FREE-RUNS ahead during vblank, the fresh
    // goal 0 then lands BEHIND er_next, er_pending goes false, and the engine locks out
    // permanently (each row erased exactly once, then dead = the cab's frozen stripes).
    // (Supersedes P1.9b's wrap-erase, which was designed against a beam-following scan_addr
    // model that the real prefetch loader does not match.)
    wire       trig_wrap = (req_row < req_row_d);
    wire [8:0] trig_nr   = req_row - 9'd1;
    // GOSPEL GUARD, not a visible-range guess.  This filter used to be
    // `!trig_nr[8]` -- "goals are always 0..255 ... the erase can never touch
    // non-displayed VRAM (rows 256+)".  Rows 256+ are non-displayed ONLY when
    // the display base is 0.  MEASURED (MAME 0.289, mame-trace/page_usage.lua,
    // live gameplay): High Impact displays rows 256..511 on 1,275 of 2,931
    // drawing frames, and Strike Force -- a true back-buffer title, drawing
    // into the page it is NOT displaying on 2,945 frames vs 5 -- runs bases
    // 255 and 511, so nearly every row it displays was rejected here.  Their
    // pages were therefore NEVER erased: stale content persisted (Strike Force
    // smearing / missing sprites) and alternated with a correctly-erased page
    // (High Impact's flashing UI, which "improved" with autoerase OFF only
    // because that made both pages equally stale).  Smash T.V. and Trog are
    // base-0 and were unaffected -- the family-blindness signature.
    //
    // MAME's actual rule is autoerase_line(rowaddr-1) with `scanline >= 0 &&
    // scanline < 510` (midyunit_v.cpp:538) -- the ONLY excluded rows are the
    // 510/511 erase-pattern source rows (and the pre-frame -1, which maps here
    // to 511 and is covered by the same test).  NO-REGRESSION BY CONSTRUCTION:
    // with base 0 the prefetch loader never produces req_row > 256, so trig_nr
    // never exceeds 255 and this filter is inert for the cabinet-proven titles.
`ifdef MUT_ERASE_PAGE0_ONLY
    // MUTANT (kill control for sim/probe/erase-base): the pre-fix filter that
    // rejected every goal row >= 256. Must FAIL any non-zero-base leg.
    wire       trig_row_ok = !trig_nr[8];
    wire       ev_row_ok   = !erase_line_row[8];
`else
    wire       trig_row_ok = (trig_nr != 9'd510) && (trig_nr != 9'd511);
    // Guarded events never carry 510/511 (sequencer raw guards <=509); this is
    // a defensive re-check of the same template exclusion, nothing more.
    wire       ev_row_ok   = (erase_line_row < 9'd510);
`endif

    // ---- DOUBLE-BUFFER select (SPEC-doublebuffer-rendering.md S3) --------------------------------
    // fb_sel picks which physical 0x10000-beat framebuffer the BLITTER (back) currently draws to.
    // Toggled ONCE/FRAME on trig_wrap: the single per-frame req_row decrease (~256->0), i.e. the
    // start of vblank -- the beam has just finished scanning the front buffer and the game has
    // redrawn the whole back buffer, so the swap makes that back buffer the new front. trig_wrap is
    // a 1-cycle pulse (req_row_d trails req_row by one clk; 0->1 reprime is an increase, not a wrap).
    // S3: fb_sel is NOT yet wired to any lane address -- all four lanes still address the same base,
    // so behavior is UNCHANGED and the existing coherency gates (tb_vram_ddr_fbcombine g/h +
    // vramcheck) MUST stay green. The lane retarget by this bit is S4.
    always_ff @(posedge clk) begin
        if (rst) begin fb_sel <= 1'b0; dbl_arm <= 1'b0; end
        else begin
            if (fb_we)               dbl_arm <= 1'b1;    // first blitter draw -> arm (past boot RAMCHECK)
            if (dbl_on && trig_wrap) fb_sel  <= ~fb_sel; // swap once/frame, only once armed
        end
    end

    // ---- DOUBLE-BUFFER enable + per-lane physical select (SPEC S4 increment 1) -----------------
    // DBL_EN gates the whole feature. When 0 (default build), sel_back/sel_front are 0 -> bit 16 of
    // every retargeted tst_addr is 0 -> SINGLE buffer, bit-identical to pre-S4 (existing gates green).
    // When 1 (-DUSE_DOUBLE_BUFFER build): A/C/D (blitter draw, CPU field ops, autoerase) draw the BACK
    // buffer = fb_sel; B (scanout) reads the FRONT buffer = ~fb_sel. Back buffer = front + 0x10000 beats
    // (bit 16). At reset fb_sel=0 so back=buf0/front=buf1; each trig_wrap swaps them.
    // NOTE (open, resolved+verified in S5): rows 510/511 are the erase SOURCE CACHE (scratch) that also
    // live inside the 0x10000 buffer span; this increment retargets C uniformly by sel_back -- the
    // source-vs-back-buffer coherence of 510/511 (A-side srcwt @408 vs C source-fill @741) is validated
    // by tb_vram_doublebuffer (S5) and adjusted there if the erase pattern diverges.
    wire sel_back  = dbl_on & fb_sel;    // A/C/D -> back buffer
    wire sel_front = dbl_on & ~fb_sel;   // B (scanout) -> front buffer

    logic [8:0] er_goal;  logic er_goal_v;     // newest erase target (any physical row)
    logic       er_snap;                       // frame-wrap resync (see the always_ff below)
    logic       er_stale;                      // backlog older than the safe window
    // STALENESS BOUND -- an erase that runs LATE destroys game content.
    //
    // MEASURED (MAME 0.289, mame-trace/draw_phase.lua, live gameplay): Total
    // Carnage paints its road 17..64 scanlines BEHIND the beam -- 12,579 of its
    // 13,149 active-region thin blits land in that band. Gospel erases exactly
    // one row behind the beam every scanline (midyunit_v.cpp:554), so a row is
    // always cleared 16..63 lines BEFORE the game repaints it, and the paint
    // survives to be displayed next frame. Our goal/catch-up loop has no such
    // bound: if it falls behind and then bursts, the erase for a row can land
    // AFTER the game painted it and wipe the fresh pixels -- Total Carnage's
    // missing road, and the same class for Strike Force's background.
    // Catch-up still exists (it fixed the cab stripes, where the prefetcher's
    // vblank re-prime burst dropped rows 0-4) but is now capped well inside the
    // 17-line danger threshold: a row more than ER_MAX_LAG behind is DROPPED,
    // exactly as MAME drops it -- MAME erases one row per scanline and never
    // revisits a missed one either.
    //
    // STATUS -- FAITHFULNESS BOUND, *NOT* A PROVEN FIX FOR THE MISSING ROAD.
    // sim/probe/erase-base's paint-behind-beam leg (+PAINTLAG=20 under
    // +busy=20 +rlat=12) paints 4 rows/frame 20 lines behind the beam and they
    // SURVIVE with this bound -- but they also survive with
    // -DMUT_ERASE_UNBOUNDED_CATCHUP, i.e. the bench cannot make the engine run
    // late enough to exhibit the hazard. So the mechanism is UNDEMONSTRATED:
    // keep this only because gospel never erases a row late (one row behind the
    // beam, per scanline, never revisited) and an unbounded catch-up can, which
    // is a divergence on its own terms. Do NOT cite it as the cause of Total
    // Carnage's missing road until something reproduces a late erase.
    localparam [8:0] ER_MAX_LAG = 9'd8;
    logic [8:0] er_next;                       // next row the catch-up loop will erase
    // pending = er_next has not yet passed er_goal (unsigned 9-bit distance < 256; rows are
    // strictly increasing 0..255 within a frame, er_next wraps 255->0 explicitly below)
    logic       er_resync_pending;
    logic [8:0] er_resync_row;
`ifdef YUNIT_DISPLAY_SEQ
 `ifdef YUNIT_ERASE_FRAME_SNAP
    wire erase_first_resync = erase_line_valid && ev_row_ok
                            && (erase_line_first === 1'b1);
 `else
    wire erase_first_resync = 1'b0;
 `endif
`else
    wire erase_first_resync = 1'b0;
`endif
    wire [8:0] er_lag     = er_goal - er_next;
    wire       er_pending = er_goal_v && erase_en && (er_lag < 9'd256);

    // C requester to L2 (cont.24: erase is now a BE=FF BURST write; burst read during a cold fill)
    // c_start, c_wr, c_addr hoisted to top (Questa declare-before-use)
    logic [63:0] c_wdata;
    logic [ 7:0] c_burstlen;
    logic        c_done, c_rd_valid;         // driven by L2
    logic [63:0] c_rdata;                    // driven by L2
`ifdef YUNIT_SRT_FILL_BURST
    wire [8:0] e_fill_rd_n = e_fill + (e_rd_valid ? 9'd1 : 9'd0);
    wire       srt_load_complete = (est == E_RFILL) && e_done
                                 && (e_fill_rd_n >= 9'd256);
    wire       srt_snapshot_release = (est == E_FIN) && e_op_we
                                    && ((e_base_entry == 18'h1F800)
                                        || (e_base_entry == 18'h3F800));
`ifdef MUT_SRT_SNAPSHOT_MUTABLE
    wire       srcwt_cache_allow = 1'b1;
`else
    wire       srcwt_cache_allow = !srt_snapshot_hold;
`endif
`endif
    // ERASE-BURST staging (cont.24): CB_MAX contiguous source beats staged from src_cache into
    // cb_data[], then streamed to the agent as ONE Avalon burst (mux in the L2 block). 128 = 8 x
    // CB_MAX. Was 128 SINGLE-beat writes/row = 128 f2h round-trips = the background repaint fell
    // behind the beam on real HW (cab FLICKER, proven via -DNO_AUTOERASE; sim commits free so the
    // ":512 ~5x-per-line" margin was a SIM ARTIFACT). [[lessons_ddr3_write_burst]].
    localparam [7:0] CB_MAX = 8'd16;         // <= f2h BMAX(32) / sim cfg_maxburst(32); 128 % CB_MAX == 0
    logic [63:0] cb_data [0:15];             // staged sub-burst beats (cb_data[0] = lowest); ~1k flops
    logic [4:0]  c_stg;                      // staging counter 0..CB_MAX
    localparam [4:0] C_STG_READY = 5'd17;    // beat15 captured once; wait here for B lock release
    wire         c_is_burst = c_wr && (c_burstlen > 8'd1);   // C is streaming a be=FF burst write

    logic [8:0]  erase_row;                  // the row currently being erased (from the catch-up loop)
    logic [6:0]  c_beat;                      // 0..127 beat index within the row
    logic [7:0]  c_fill;                      // cold-fill beat counter (0..127)
    logic        c_fill_which;                // 0 = filling row510 half, 1 = row511 half
    wire         erase_par = erase_row[0];    // 0 -> source row 510, 1 -> source row 511 (MAME :539)
    // per-erase source-cache validity, evaluated for er_next at issue time (C_IDLE)
    wire         next_par  = er_next[0];
    wire         next_srcv = next_par ? src511_valid : src510_valid;

    localparam [2:0] C_IDLE=3'd0, C_FILL_REQ=3'd1, C_FILL_RCV=3'd2, C_STAGE=3'd3, C_BWR=3'd4;
    logic [2:0]  cts;
    assign erase_busy = (cts != C_IDLE);

    // srcwt 1-deep PEND: src_cache[] must have exactly ONE write statement chain (below) or Quartus
    // cannot map it to a simple-dual-port M10K and falls back to 16384 LOOSE REGISTERS -- which is
    // exactly what happened on the first beamerase build (routing congestion at seed 1, then a
    // -1.028 ns a_wdata->src_cache[*][*] setup violation at seed 3, +16k registers in the fit
    // summary). Same discipline as rc[]'s single prioritized port + wtp pend: a fill beat wins the
    // port; a colliding A-side write-through PENDS here and drains on the next non-fill cycle.
    logic        swp_v;  logic [7:0] swp_idx;  logic [63:0] swp_data;

    always_ff @(posedge clk) begin
        if (rst) begin
            cts<=C_IDLE; c_start<=1'b0; c_wr<=1'b0; c_addr<=26'd0; c_wdata<=64'd0; c_burstlen<=8'd1;
            c_beat<=7'd0; c_stg<=5'd0; c_fill<=8'd0; c_fill_which<=1'b0; erase_row<=9'd0; src_raddr<=8'd0;
            src510_valid<=1'b0; src511_valid<=1'b0; swp_v<=1'b0; swp_idx<=8'd0; swp_data<=64'd0;
`ifdef YUNIT_SRT_FILL_BURST
            srt_snapshot_hold<=1'b0;
`endif
            er_goal<=9'd0; er_goal_v<=1'b0; er_next<=9'd0;
            er_resync_pending<=1'b0; er_resync_row<=9'd0;
        end else begin
            // A-side write-through validity flags (the DATA goes through the single write port
            // below; a write-through landing -- direct or pended -- marks its source row valid).
            if (srcwt_req
`ifdef YUNIT_SRT_FILL_BURST
                && srcwt_cache_allow
`endif
               ) begin
                if (srcwt_idx[7]) src511_valid <= 1'b1; else src510_valid <= 1'b1;
            end
`ifdef YUNIT_SRT_FILL_BURST
            // ToShiftReg force-refreshes both halves, then freezes the snapshot
            // across all 105 FromShiftReg commands. Source-row write-throughs
            // still reach DDR while frozen, but may not mutate this snapshot.
            if (srt_load_complete) begin
                src510_valid <= 1'b1; src511_valid <= 1'b1;
                srt_snapshot_hold <= 1'b1;
            end
            // Row252/253 or 508/509 is the final pair. Release only after its two
            // invalidations and done state; invalidate C's ordinary cache even
            // if no source write raced, so later autoerase refills from DDR.
            if (srt_snapshot_release) begin
                srt_snapshot_hold <= 1'b0;
                src510_valid <= 1'b0; src511_valid <= 1'b0;
            end
`endif
            // GOAL LATCH -- runs EVERY cycle, independent of the FSM state (the whole point:
            // trigger bursts must never be dropped because C is busy). Targets outside the
            // visible range (bit 8 set: the -1 pre-frame case and any 510/511 alias) are
            // structurally rejected -- goals are always 0..255, which also guarantees the
            // erase can never touch the pattern rows or non-displayed VRAM (rows 256+).
            // (goal_latch is also checked by the CONSUME in C_ADV below: a goal completed and a
            // new goal latched in the same cycle must not lose the new one.)
            // WRAP GOALS ARE LATCHED TOO (they were dropped before). Gospel
            // erases (rowaddr-1) for EVERY displayed line including the first,
            // and for a base whose window does not start at 0 the frame's first
            // transition IS the wrap -- Strike Force at base 255 lost row 254
            // every frame with the old !trig_wrap guard. Dropping wrap goals was
            // a workaround for the stale-backlog free-run; er_snap below now
            // handles a behind-goal correctly, so the workaround is obsolete.
            // TRIGGER SOURCE (2026-08-18): under YUNIT_DISPLAY_SEQ the sequencer's
            // gospel-guarded line events replace the req_row snoop -- see the
            // erase_line_valid port note. The non-FULL (CVSD) config keeps the
            // snoop trigger; its raw-space guard rides erase_en as a per-frame
            // term (yunit_top_family2 erase_frame_raw_ok -- exact for every
            // measured base: 0/255/256/511 never straddle raw 510 mid-frame).
            // The snoop also remains for trig_wrap (double-buffer boundary).
`ifdef MUT_ERASE_PHYS_TRIGGER
            // MUTANT (sim/probe/erase-base SF-persistence leg): the old
            // phys-space snoop trigger ungated -- must re-create the phantom
            // erase on a high-raw-base frame.
            if (row_changed && trig_row_ok) begin
                er_goal <= trig_nr;  er_goal_v <= 1'b1;
            end
`elsif YUNIT_DISPLAY_SEQ
            if (erase_line_valid && ev_row_ok) begin
                er_goal <= erase_line_row;  er_goal_v <= 1'b1;
            end
`elsif YUNIT_FULL
            if (erase_line_valid && ev_row_ok) begin
                er_goal <= erase_line_row;  er_goal_v <= 1'b1;
            end
`else
            if (row_changed && trig_row_ok) begin
                er_goal <= trig_nr;  er_goal_v <= 1'b1;
            end
`endif
            // While the enable is LOW, pin er_next just past the goal so NO backlog accrues:
            // MAME semantics are per-line (a line whose display passed with erase disabled is
            // simply never erased); a catch-up burst on re-enable would wrongly erase rows the
            // game painted while erase was off.
            // mod-512 (was mod-256: goals can now be any physical row)
            if (!erase_en) er_next <= er_goal + 9'd1;
            // FRAME-WRAP RESYNC -- assigned AFTER the FSM below so it takes
            // priority over the same-cycle catch-up advance.
            //
            // The old pointer wrapped 255->0 because goals were clamped to
            // 0..255. With goals spanning the full 512-row space that wrap is
            // wrong at every base, INCLUDING base 0: after erasing row 255 the
            // pointer lands on 256, the next frame's goals (0,1,2...) then sit
            // "behind" it, er_lag reads as a 256+-row backlog, er_pending goes
            // false and the engine dies -- the documented goal-regress
            // deadlock (each row erased exactly once, then frozen = the cab
            // stripes). Measured exactly that way when this filter was first
            // widened. So: a goal that lands behind the pointer means a new
            // frame started -- SNAP the pointer to it rather than trying to
            // march ~500 rows forward to reach it.
`ifdef MUT_ERASE_PHYS_TRIGGER
            er_snap = row_changed && trig_row_ok
                      && ((trig_nr - er_next) >= 9'd256);
`elsif YUNIT_DISPLAY_SEQ
`ifdef YUNIT_ERASE_FRAME_SNAP
            // CAB-DIRECTED (2026-08-27). The >=256 delta heuristic cannot tell a
            // NEW FRAME from a PAGE FLIP: Strike Force and Saurian Front flip
            // between raw rows 511 and 255, a delta of exactly 256, so every flip
            // tripped the resync and the erase march was abandoned mid-page.
            // Static base-0 titles (Smash T.V., Trog) never alias it, which is
            // exactly the working/failing split observed on the cabinet.
            // Use the sequencer's real frame boundary instead of inferring one.
            // The first guarded consumption belongs to the new visible
            // frame. VSBLNK itself precedes the old frame's final event.
            er_snap = erase_first_resync;
`else
            er_snap = erase_line_valid && ev_row_ok
                      && ((erase_line_row - er_next) >= 9'd256);
`endif
`elsif YUNIT_FULL
            er_snap = erase_line_valid && ev_row_ok
                      && ((erase_line_row - er_next) >= 9'd256);
`else
            er_snap = row_changed && trig_row_ok
                      && ((trig_nr - er_next) >= 9'd256);
`endif
            // backlog deeper than the safe window: drop it rather than erase late
`ifdef MUT_ERASE_UNBOUNDED_CATCHUP
            er_stale = 1'b0;                      // MUTANT: the pre-fix unbounded catch-up
`else
            er_stale = er_goal_v && erase_en && !er_snap && !er_resync_pending
                       && ((er_goal - er_next) < 9'd256)
                       && ((er_goal - er_next) > ER_MAX_LAG);
`endif
            case (cts)
                C_IDLE: begin
                    // SKIP the erase-pattern rows without issuing (MAME's
                    // `scanline < 510` guard, midyunit_v.cpp:538). The old
                    // 0..255 goal clamp made this unreachable; with goals now
                    // spanning the full 512-row space a catch-up run can march
                    // across 510/511, and erasing them would destroy the very
                    // source pattern every other erase copies FROM.
                    if (!er_snap && !er_resync_pending && er_pending && (er_next == 9'd510 || er_next == 9'd511)) begin
                        er_next <= er_next + 9'd1;
                    end else if (er_pending && !er_snap && !er_resync_pending && !er_stale
`ifdef YUNIT_SRT_FILL_BURST
                                && !e_block && !srt_snapshot_hold
`endif
                               ) begin                    // catch-up loop: erase er_next
                        erase_row <= er_next;
                        src_raddr <= {next_par, 7'd0};                // pre-read source beat 0 for C_WR
                        c_beat    <= 7'd0;
                        if (!next_srcv) begin
                            c_fill       <= 8'd0;                     // cold start: burst-fill the source row first
                            c_fill_which <= next_par;
                            cts          <= C_FILL_REQ;
                        end else begin
                            c_stg <= 5'd0; cts <= C_STAGE;            // source cached -> stage beats, then burst
                        end
                    end
                end
                // ---- cold-start source-row fill: burst-read the whole source row into src_cache ----
                C_FILL_REQ: begin                              // request a <=BMAX sub-burst from c_fill
                    if (!b_fill_lock) begin
                        c_addr     <= {10'd0, (c_fill_which ? 9'd511 : 9'd510), 7'd0} + {18'd0, c_fill};
                        c_burstlen <= ((8'd128 - c_fill) > BMAX) ? BMAX : (8'd128 - c_fill);
                        c_wr       <= 1'b0; c_start <= 1'b1; cts <= C_FILL_RCV;
                    end
                end
                C_FILL_RCV: begin
                    if (c_rd_valid) begin
                        c_fill <= c_fill + 8'd1;     // src_cache write happens in the single port below
                    end
                    if (c_done) begin
                        c_start <= 1'b0;
                        if (c_fill >= 8'd128) begin
                            if (c_fill_which) src511_valid <= 1'b1; else src510_valid <= 1'b1;
                            src_raddr <= {c_fill_which, 7'd0};   // re-point read for the erase pass
                            c_stg <= 5'd0; cts <= C_STAGE;       // stage beats, then burst
                        end else cts <= C_FILL_REQ;              // more of the source row to fetch
                    end
                end
                // ---- erase pass (cont.24 BURST): stage CB_MAX contiguous beats from src_cache into
                // cb_data[], then ONE be=FF Avalon burst -- the D-lane/B-scanout streaming path.
                // src_q is a REGISTERED src_cache read: src_raddr was pointed at {par,c_beat} the
                // previous cycle (C_IDLE / C_FILL end / a C_BWR sub-burst advance), so at the FIRST
                // C_STAGE cycle src_q already holds beat c_beat. Each cycle captures cb_data[c_stg]=
                // src_q and points src_raddr one beat ahead; after CB_MAX captures, fire the burst.
                C_STAGE: begin
                    if (c_stg == 5'd0) begin
                        // SETTLE (the old C_RD, once per sub-burst): src_raddr was pointed at this
                        // sub-burst's beat0 the PREVIOUS cycle, so src_q -- a REGISTERED src_cache
                        // read -- becomes valid NEXT cycle. Capturing without this settle samples
                        // the previous beat's src_q (the xdiff-caught off-by-one: beat0 = stale
                        // wrong-parity data, every later beat shifted one down, last beat dropped).
                        src_raddr <= {erase_par, (c_beat + 7'd1)};    // pre-point at beat0+1
                        c_stg     <= 5'd1;
                    end else if (c_stg == C_STG_READY) begin
                        // cb_data[15] is already captured. Holding here MUST perform no further
                        // BRAM write: src_q has advanced to beat16 and would corrupt the tail.
                        if (!b_fill_lock) begin
                            c_addr     <= {10'd0, erase_row, c_beat};
                            c_burstlen <= CB_MAX;
                            c_wr       <= 1'b1; c_start <= 1'b1;
                            cts        <= C_BWR;
                        end
                    end else begin
                        cb_data[c_stg[3:0] - 4'd1] <= src_q;          // src_q = beat c_beat+(c_stg-1)
                        if (c_stg == CB_MAX[4:0]) begin               // last beat captured -> fire
                            if (!b_fill_lock) begin
                                c_addr     <= {10'd0, erase_row, c_beat}; // dst beat0 = row*128 + c_beat
                                c_burstlen <= CB_MAX;
                                c_wr       <= 1'b1; c_start <= 1'b1;
                                cts        <= C_BWR;
                            end else c_stg <= C_STG_READY;            // locked: tail captured once, then hold
                        end else begin
                            src_raddr <= {erase_par, (c_beat + {2'b00, c_stg} + 7'd1)};  // next beat
                            c_stg     <= c_stg + 5'd1;
                        end
                    end
                end
                // C_BWR: the L2 arbiter streams cb_data[wstream_idx] as a be=FF burst (mux at the L2
                // block). On c_done, advance to the next CB_MAX sub-burst, or finish the row.
                C_BWR: if (c_done) begin
                    c_start <= 1'b0;
                    if ((c_beat + CB_MAX[6:0]) == 7'd0) begin    // 128 wrapped to 0 (7-bit) = row done
                        // advance the catch-up pointer (255 wraps to 0: goals are always 0..255) and
                        // bounce through C_IDLE, which immediately issues the next backlogged row if
                        // er_pending still holds.
                        // An old in-flight row must finish physically, but
                        // may not advance the pending new-frame cursor.
                        if (!er_snap && !er_resync_pending)
                            er_next <= er_next + 9'd1;   // mod-512
                        // CONSUME the goal when this row completed it. NOT load-bearing (mutation-
                        // verified self-heals); kept as FAITHFULNESS hardening so no VRAM row is
                        // erased ahead of its MAME per-scanline time. Guard a same-cycle NEW goal.
                        if (!er_snap && !er_resync_pending && erase_row == er_goal
`ifdef YUNIT_DISPLAY_SEQ
                            && !(erase_line_valid && ev_row_ok)
`else
                            && !(row_changed && trig_row_ok)
`endif
                           )
                            er_goal_v <= 1'b0;
                        cts <= C_IDLE;
                    end
                    else begin
                        c_beat    <= c_beat + CB_MAX[6:0];                    // next sub-burst
                        src_raddr <= {erase_par, (c_beat + CB_MAX[6:0])};     // prime its beat0
                        c_stg     <= 5'd0;
                        cts       <= C_STAGE;
                    end
                end
                default: cts <= C_IDLE;
            endcase
            // Frame-wrap resync, LAST so it beats the C_BWR catch-up advance in
            // the same cycle (see er_snap above for why the pointer must not be
            // left past the end of a frame's target sequence).
            // Capture the event's own payload. Wait for the already-issued
            // C row to finish, then install it while C_IDLE cannot launch.
            // Latest new-frame marker wins if an entire frame was blocked.
            if (erase_first_resync) begin
                er_resync_pending <= 1'b1;
                er_resync_row <= erase_line_row;
            end
            if (er_resync_pending && (cts == C_IDLE) && !erase_first_resync) begin
                er_next <= er_resync_row;
                er_resync_pending <= 1'b0;
            end
            if (er_snap && !erase_first_resync) er_next <= trig_nr;
            // ...and the staleness drop, later still: skipping a stale row must
            // win over both the advance and a same-cycle snap.
            else if (er_stale) er_next <= er_goal - ER_MAX_LAG;
            // src_cache[] SINGLE write port (M10K inference requirement -- see the swp_v comment
            // above): a cold-fill beat wins; else a live A-side write-through; else drain the pend.
            // A write-through colliding with a fill beat PENDS (1-deep) and lands the next non-fill
            // cycle -- never silently dropped (the erase copies from this cache every line, so a
            // dropped source update would repaint stale pattern data indefinitely).
`ifdef YUNIT_SRT_FILL_BURST
            if (est==E_RFILL && e_rd_valid && !e_op_we) begin
                src_cache[e_fill[7:0]] <= e_rdata;
            end else
`endif
            if (cts==C_FILL_RCV && c_rd_valid) begin
                src_cache[{c_fill_which, c_fill[6:0]}] <= c_rdata;
                if (srcwt_req) begin swp_v <= 1'b1; swp_idx <= srcwt_idx; swp_data <= srcwt_data; end
            end else if (srcwt_req
`ifdef YUNIT_SRT_FILL_BURST
                        && srcwt_cache_allow
`endif
                       ) begin
                src_cache[srcwt_idx] <= srcwt_data;
                // a NEWER direct write to the same beat supersedes a still-pended older one --
                // draining the pend afterwards would clobber fresh data with stale.
                if (swp_v && swp_idx == srcwt_idx) swp_v <= 1'b0;
            end else if (swp_v
`ifdef YUNIT_SRT_FILL_BURST
                        && srcwt_cache_allow
`endif
                       ) begin
                src_cache[swp_idx] <= swp_data;  swp_v <= 1'b0;
            end
        end
    end

    // ================= D: W-THRU2 fb beat WRITE-COMBINE (ported from UMK3 083d55e) =============
    // The blitter fb stream used to ride u_acc's 16-bit sd channel: EVERY pixel cost a full-beat
    // RMW pair (~25 clk/px). That term makes an attract-mode WHOLE-SCREEN redraw take ~2.5 frames
    // on the single-buffered Y-unit -> the process dispatcher falls behind -> the software watchdog
    // (200-frame TIMER) reboots (cab-measured 2026-07-10; SCOPE-wthru2-port.md). Blit rows are
    // sx-sequential, so 4 entries/beat combine naturally: a FULL beat writes be=FF with NO read
    // (bridge-safe); partial beats (row edges) RMW, a 1-deep own-write forward covering consecutive
    // partials of the same beat. Drops fb to ~4 clk/px so a redraw fits in a frame -> watchdog stops.
    //
    // ORDERING / DEADLOCK GUARD: the CPU sd lane (A) is granted only on a DRAINED combiner
    // (a_start && !d_busy in L2), and a_start FORCES a flush + parks new fb accepts for its duration
    // -- without the park the sustained fb stream would never empty the combiner and A would starve
    // (the contention-gate deadlock UMK3 caught 2026-07-10).
    //
    // COHERENCY (the STV-specific part -- UMK3 had only A + B): every combined beat write is a real
    // VRAM write, so it stays coherent with all three caches: it invalidates A's 2-entry beat cache
    // (the D snoop in the A block above), writes through B's scanout row cache when it holds that
    // row (dwt_*), and srcwt's into C's autoerase source cache for rows 510/511 (dsrcwt_*).
    // fb_addr is an 18-bit ENTRY index; beat = fb_addr[17:2], lane = fb_addr[1:0]; beat[15:7]=row,
    // beat[6:0]=beat-in-row -- identical to the A-side encoding, so all coherency tags line up.
`ifdef PERF_NO_FBCOMBINE
    localparam FBCOMB = 1'b0;   // MUTATION: disable same-beat combine -> every pixel a partial RMW
`else                          //           (the cost gate must then FAIL; coherency stays green)
    localparam FBCOMB = 1'b1;
`endif
    logic [15:0] wc_beat;       // fb_addr[17:2]  (STV: 16-bit beat vs UMK3's 17)
    // Same-D copies terminate the remote DMA-ack and B-fill-snoop cones while
    // retaining the exact combinational acknowledgement cycle.
    (* preserve, dont_merge *) logic [15:0] ack_wc_beat_q;
    (* preserve, dont_merge *) logic [15:0] bsn_wc_beat_q;
    logic [3:0]  wc_mask;       // which of the 4 lanes are dirty
    logic [63:0] wc_data;       // combined beat
    logic [7:0]  wc_idle;
    localparam [7:0] FB_WFLUSH_IDLE = 8'd64;
    logic        cmb_fb_we_d;
    logic        fb_pend;       // held request the combiner could not accept at its edge
    wire  [15:0] fb_beat = fb_addr[17:2];
    wire         fb_same = FBCOMB && (wc_mask != 4'd0) && (fb_beat == ack_wc_beat_q);
    wire         fb_new  = fb_we & ~cmb_fb_we_d;      // dma holds fb_we until fb_ack
    wire         fb_req  = fb_new | fb_pend;          // live request (edge or parked)
    // BSNOOP made a row fill coherent with D work that already existed when the fill reached
    // that beat. It is therefore safe (and substantially faster) to keep accepting writes for
    // OTHER rows while B owns the DDR port. Keep only the true race parked: a new write to the
    // row currently being filled could arrive after its beat was copied into rc[], when neither
    // the fill snoop nor rc_valid write-through can repair that already-passed cache beat.
    // MUT_FB_FILL_PARK restores the old whole-fill park for the overlap performance oracle.
`ifdef MUT_FB_FILL_PARK
    wire         fb_fill_park = b_fill_lock;
`else
    wire         fb_fill_park = b_fill_lock && fb_req && (fb_beat[15:7] == park_row);
`endif
    wire         d_flush_req = (wc_mask != 4'd0) &&
                               ((fb_req && !fb_same) || (wc_idle >= FB_WFLUSH_IDLE) || a_start
                                || a_req_pending || fb_fill_park || fb_flush
`ifdef YUNIT_SRT_FILL_BURST
                                || e_block
`endif
                               ); // owner pending -> drain now
    // d_start, d_wr, d_addr hoisted to top (Questa declare-before-use)
    logic [63:0] d_wdata;
    logic [7:0]  d_be;
    logic        d_done, d_rd_valid;                   // driven by L2
    logic [63:0] d_rdata;                              // driven by L2
    logic [63:0] d_fwd;  logic [15:0] d_fwd_beat;  logic d_fwd_v;   // 1-deep own-write forward
    logic [3:0]  df_mask;  logic [63:0] df_data;  logic [15:0] df_beat;  // latched RMW flush job
    localparam [2:0] D_IDLE=3'd0, D_RD=3'd1, D_MRG=3'd2, D_WR=3'd3, D_WRB=3'd4;
    logic [2:0] dst;
    // ---- Piece 2/3: immediate run-buffer -- batch consecutive ASCENDING full be=F beats into ONE
    // Avalon write burst so the (high-latency real f2h) bridge round-trip is paid once per run, not
    // per beat. COHERENCY STAYS ON-ADD (per beat, immediate): the snoop/dwt/dsrcwt fire the cycle a
    // beat ENTERS the buffer (below), exactly like the single-beat path -- accept==commit for A/B/C.
    // Only the physical DDR3 write is deferred to the burst; A-forward would cover the in-flight
    // window, but A is granted only on !d_busy (rb empty) so the run is committed before A can read.
    // Partial (edge) beats never enter rb -> they keep the single-beat RMW path (FIRE the run first).
    localparam [3:0] RB_MAX = 4'd8;
    logic [63:0] rb_data [0:7];        // consecutive full beats awaiting a burst (rb_data[0]=lowest)
    logic [15:0] rb_base;              // beat addr of rb_data[0]
    logic [3:0]  rb_cnt;               // 0..8 (0 = empty)
    logic [7:0]  rb_idle;              // cycles since the last add (drain timeout)
    logic [7:0]  d_blen;               // latched burst length (beats) at FIRE
    (* preserve, dont_merge *) logic [3:0] bsn_d_blen_q; // same-D BSNOOP-local bound
    logic [3:0]  wstream_idx;          // L2 burst-write streaming pointer (driven in the L2 block)
    assign d_busy = (dst != D_IDLE) || (wc_mask != 4'd0) || (rb_cnt != 4'd0);
    assign fb_busy = d_busy;                 // commit-gate signal to the DMA (drain in progress)
    function automatic [63:0] d_lane_merge(input [63:0] base, input [63:0] neu, input [3:0] m);
        d_lane_merge = {m[3] ? neu[63:48] : base[63:48], m[2] ? neu[47:32] : base[47:32],
                        m[1] ? neu[31:16] : base[31:16], m[0] ? neu[15:0]  : base[15:0]};
    endfunction
    wire  [63:0] d_ownmerge = d_lane_merge(d_fwd, wc_data, wc_mask);
    wire  [63:0] d_wbmerge  = d_lane_merge(wb_data, wc_data, wc_mask);
    // Disposition of a completed wc beat: FULL + (empty run | ascending-contiguous) -> extend rb;
    // FULL + run-break, or PARTIAL, or a_start/idle/full -> FIRE the run as a burst (see the FSM).
    wire         fbeat_full = (wc_mask == 4'hF);
    wire         rb_ext     = (rb_cnt != 4'd0) && (rb_cnt < RB_MAX) && (wc_beat == rb_base + {12'd0, rb_cnt});
    // FIRE-on-completed-beat: only when a COMPLETED beat (d_flush_req) won't extend the run -- a full
    // run-break or any partial. Must NOT trigger on an empty combiner (else every lone beat fires as a
    // 1-beat "burst" the cycle after it's added and no run ever accumulates).
    wire         d_want_fire = (rb_cnt != 4'd0) && d_flush_req && (fbeat_full ? !rb_ext : 1'b1);
    // flush_now = a flush LAUNCHES this cycle (wc_mask -> 0 below). accept must exclude it: a same-
    // beat pixel arriving exactly as the idle-timeout fires would otherwise be both combined into wc
    // AND wiped by wc_mask<=0 in the same cycle = a DROPPED pixel. Excluded here -> it parks instead
    // and lands in the next (freshly empty) combiner.
    wire         flush_now = (dst == D_IDLE) && d_flush_req;
    wire         accept    = fb_req && !a_claim && !fb_fill_park
`ifdef YUNIT_SRT_FILL_BURST
                             && !e_block
`endif
                             &&
                             (wc_mask == 4'd0 || fb_same) && !flush_now;
`ifndef MUT_FB_ACK_REGISTERED
    // Ready/accept is same-clock combinational; the pixel data and all combiner state are still
    // captured on the accepting edge below. yunit_dma consequently advances on that SAME edge
    // instead of observing a registered ack one edge later (one recovered clock per drawn pixel).
    // There is no loop: fb_we/fb_addr come only from registered DMA state/coordinates.
    always_comb fb_ack = accept;
`endif
    always_ff @(posedge clk) begin
        if (rst) begin
            wc_beat<=16'd0; ack_wc_beat_q<=16'd0; bsn_wc_beat_q<=16'd0;
            wc_mask<=4'd0; wc_data<=64'd0; wc_idle<=8'd0;
            cmb_fb_we_d<=1'b0; fb_pend<=1'b0;
`ifdef MUT_FB_ACK_REGISTERED
            fb_ack<=1'b0;
`endif
            d_start<=1'b0; d_wr<=1'b0; d_addr<=26'd0; bsn_d_addr_q<=16'd0;
            d_wdata<=64'd0; d_be<=8'd0;
            d_fwd<=64'd0; d_fwd_beat<=16'd0; d_fwd_v<=1'b0;
            df_mask<=4'd0; df_data<=64'd0; df_beat<=16'd0; dst<=D_IDLE;
            dwt_req<=1'b0; dwt_col<=7'd0; dwt_data<=64'd0;
            dsrcwt_req<=1'b0; dsrcwt_idx<=8'd0; dsrcwt_data<=64'd0;
            rb_base<=16'd0; rb_cnt<=4'd0; rb_idle<=8'd0;
            d_blen<=8'd0; bsn_d_blen_q<=4'd0;
            d_is_burst<=1'b0; d_add<=1'b0; d_add_beat<=16'd0;
        end else begin
`ifdef MUT_FB_ACK_REGISTERED
            fb_ack      <= 1'b0;
`endif
            cmb_fb_we_d <= fb_we;
            dwt_req     <= 1'b0;
            dsrcwt_req  <= 1'b0;
            d_add       <= 1'b0;
            // BSNOOP hardening: an autoerase burst of d_fwd's row supersedes the (indefinitely
            // persistent) forward -- without this a static screen's last-flushed beat would be
            // resurrected by the fill snoop over the freshly-erased background every frame (a stuck
            // 4px ghost). Placed FIRST so a same-cycle legitimate d_fwd set below wins.
            if (c_start && c_wr && d_fwd_v && (d_fwd_beat[15:7] == c_addr[15:7]))
                d_fwd_v <= 1'b0;
`ifdef YUNIT_SRT_FILL_BURST
            // The last D single-beat forward can outlive bridge acceptance. A
            // later full SRT replacement of that row supersedes it completely.
            if (e_write_invalidate && d_fwd_v
                && (d_fwd_beat[15:7] == e_invalidate_row))
                d_fwd_v <= 1'b0;
`endif
            if (wc_mask != 4'd0 && wc_idle != 8'hFF) wc_idle <= wc_idle + 8'd1;
            if (rb_cnt  != 4'd0 && rb_idle != 8'hFF) rb_idle <= rb_idle + 8'd1;
            // accept a pixel: empty or (combine-enabled) same-beat combiner, and NOT the flush-launch
            // cycle (one ack per request). Anything not accepted PARKS in fb_pend until a flush frees
            // it -- the dma holds addr/data until ack, so the parked pixel's fb_addr/fb_wdata are
            // still valid when it lands.
            if (accept) begin
                fb_pend <= 1'b0;
                wc_beat <= fb_beat;
                ack_wc_beat_q <= fb_beat;
                bsn_wc_beat_q <= fb_beat;
                wc_mask[fb_addr[1:0]] <= 1'b1;
                wc_data[fb_addr[1:0]*16 +: 16] <= fb_wdata;
`ifdef MUT_FB_ACK_REGISTERED
                fb_ack  <= 1'b1;
`endif
                wc_idle <= 8'd0;
            end else if (fb_new) fb_pend <= 1'b1;   // fresh edge not taken this cycle -> hold it
            // ---- dispatch a completed wc beat / drain the run-buffer (immediate burst-combiner) ----
            if (dst == D_IDLE) begin
                if (rb_cnt != 4'd0 &&
                    (a_start || a_req_pending || fb_fill_park || (rb_cnt == RB_MAX) ||
                     (rb_idle >= FB_WFLUSH_IDLE) || d_want_fire
                     || fb_flush
`ifdef YUNIT_SRT_FILL_BURST
                     || e_block
`endif
                    )) begin   // cont.24: blit done -> fire the accumulated run now
                    // FIRE the accumulated ASCENDING run as ONE Avalon burst (be=FF, addr auto-incs).
                    // CPU wants the port (a_start) / run full / run idle / the next beat won't extend
                    // it (run-break or a partial). The completed wc beat (if any) is NOT consumed here
                    // -> it re-dispatches into the freshly-empty run-buffer once the burst finishes.
                    d_addr <= {10'd0, rb_base};  bsn_d_addr_q <= rb_base;
                    d_blen <= {4'd0, rb_cnt};    bsn_d_blen_q <= rb_cnt;
                    d_wr <= 1'b1;  d_start <= 1'b1;  d_is_burst <= 1'b1;  dst <= D_WRB;
                    rb_cnt <= 4'd0;  rb_idle <= 8'd0;  d_fwd_v <= 1'b0;   // run supersedes the 1-deep fwd
                end else if (d_flush_req) begin
                    // reachable here: rb empty, OR the completed beat extends the run (rb_ext)
                    if (fbeat_full) begin                         // FULL beat -> ADD to the run-buffer
                        if (rb_cnt == 4'd0) rb_base <= wc_beat;    // start a run (else extend at rb_cnt)
                        rb_data[rb_cnt] <= wc_data;  rb_cnt <= rb_cnt + 4'd1;  rb_idle <= 8'd0;
                        wc_mask <= 4'd0;
                        // ON-ADD COHERENCY (immediate, per beat -- identical to the single-beat launch).
                        // MUTATION -DMUT_NO_ONADD drops it: a burst then commits beats whose stale A/B/C
                        // cache copies are never invalidated -> fbcombine (c)/(d) + xdiff MUST fail. That
                        // failure is the proof the burst path is exercised AND on-add is load-bearing.
`ifndef MUT_NO_ONADD
                        d_add <= 1'b1;  d_add_beat <= wc_beat;     // A beat-cache snoop-invalidate (A block)
                        dwt_req  <= (rc_valid && (wc_beat[15:7]==rc_row));  dwt_col <= wc_beat[6:0];  dwt_data <= wc_data;
                        dsrcwt_req <= (wc_beat[15:7]==9'd510) || (wc_beat[15:7]==9'd511);
                        dsrcwt_idx <= {(wc_beat[15:7]==9'd511), wc_beat[6:0]};  dsrcwt_data <= wc_data;
`endif
                        d_fwd_v <= 1'b0;                           // a full beat supersedes the partial fwd
`ifndef MUT_AWB_DPARTIAL_STALE
                    end else if (wb_v && (wb_addr == {10'd0, wc_beat})) begin
                        // PARTIAL over A's dirty write-behind beat: wb_data is the newest whole-beat
                        // image and MUST outrank both D's own forward and DDR. Launch one full merged
                        // write directly; the A-side launched-write snoop clears wb_v on the next
                        // ownership edge, after d_wdata has captured every A and D lane.
                        df_mask <= wc_mask;  df_data <= wc_data;  df_beat <= wc_beat;  wc_mask <= 4'd0;
                        d_wdata <= d_wbmerge;  d_addr <= {10'd0, wc_beat};
                        bsn_d_addr_q <= wc_beat;  d_be <= 8'hFF;
                        d_wr <= 1'b1;  d_start <= 1'b1;  d_is_burst <= 1'b0;  dst <= D_WR;
                        d_fwd <= d_wbmerge;  d_fwd_beat <= wc_beat;  d_fwd_v <= 1'b1;
                        dwt_req  <= (rc_valid && (wc_beat[15:7]==rc_row));
                        dwt_col  <= wc_beat[6:0];  dwt_data <= d_wbmerge;
                        dsrcwt_req <= (wc_beat[15:7]==9'd510) || (wc_beat[15:7]==9'd511);
                        dsrcwt_idx <= {(wc_beat[15:7]==9'd511), wc_beat[6:0]};
                        dsrcwt_data <= d_wbmerge;
`endif
                    end else if (d_fwd_v && (d_fwd_beat == wc_beat)) begin  // PARTIAL: own-write forward
                        df_mask <= wc_mask;  df_data <= wc_data;  df_beat <= wc_beat;  wc_mask <= 4'd0;
                        d_wdata <= d_ownmerge;  d_addr <= {10'd0, wc_beat};
                        bsn_d_addr_q <= wc_beat;  d_be <= 8'hFF;
                        d_wr <= 1'b1;  d_start <= 1'b1;  d_is_burst <= 1'b0;  dst <= D_WR;
                        d_fwd <= d_ownmerge;  d_fwd_beat <= wc_beat;
                        dwt_req  <= (rc_valid && (wc_beat[15:7]==rc_row));  dwt_col <= wc_beat[6:0];  dwt_data <= d_ownmerge;
                        dsrcwt_req <= (wc_beat[15:7]==9'd510) || (wc_beat[15:7]==9'd511);
                        dsrcwt_idx <= {(wc_beat[15:7]==9'd511), wc_beat[6:0]};  dsrcwt_data <= d_ownmerge;
                    end else begin                                // PARTIAL: RMW read first
                        df_mask <= wc_mask;  df_data <= wc_data;  df_beat <= wc_beat;  wc_mask <= 4'd0;
                        d_addr <= {10'd0, wc_beat};  bsn_d_addr_q <= wc_beat;
                        d_wr <= 1'b0;  d_start <= 1'b1;  d_is_burst <= 1'b0;  dst <= D_RD;
                    end
                end
            end
            case (dst)
                D_RD: begin
                    // shadow override (see shw_* decl): stale-RMW-merge immunity at depth
                    if (d_rd_valid) d_wdata <= d_lane_merge(
                        (shw_en && shw_base_hit) ? shw_base : d_rdata,
                        df_data, df_mask);
                    if (d_done) begin d_start <= 1'b0; dst <= D_MRG; end
                end
                D_MRG: begin                               // issue the merged full-beat write
                    d_addr <= {10'd0, df_beat};  bsn_d_addr_q <= df_beat;
                    d_be <= 8'hFF;  d_wr <= 1'b1;  d_start <= 1'b1;
                    d_fwd <= d_wdata;  d_fwd_beat <= df_beat;  d_fwd_v <= 1'b1;
                    dwt_req  <= (rc_valid && (df_beat[15:7]==rc_row));  dwt_col <= df_beat[6:0];  dwt_data <= d_wdata;
                    dsrcwt_req <= (df_beat[15:7]==9'd510) || (df_beat[15:7]==9'd511);
                    dsrcwt_idx <= {(df_beat[15:7]==9'd511), df_beat[6:0]};  dsrcwt_data <= d_wdata;
                    dst <= D_WR;
                end
                D_WR:  if (d_done) begin d_start <= 1'b0; d_wr <= 1'b0; d_is_burst <= 1'b0; dst <= D_IDLE; end
                D_WRB: if (d_done) begin d_start <= 1'b0; d_wr <= 1'b0; d_is_burst <= 1'b0; dst <= D_IDLE; end   // whole run drained
                default: ;
            endcase
        end
    end

`ifdef YUNIT_SRT_FILL_BURST
    // ================= C-owned TMS34010 SRT row-pair supervisor ============================
    // Preserve the Wolf/T architectural boundary (256 packed beats in <=BMAX
    // bursts), but reuse C's 256x64 source cache and grant. This removes the
    // duplicate ebuf M10Ks and fifth L2 requester without perturbing C's
    // autoerase goal/catch-up state machine.
    assign e_block = (est != E_IDLE);
    assign shift_ready = (est == E_IDLE);
    assign e_write_invalidate = e_op_we && ((est == E_INV0) || (est == E_INV1));
    assign e_invalidate_row = e_base_entry[17:9] + ((est == E_INV1) ? 9'd1 : 9'd0);
    assign shift_invalidate_valid = e_write_invalidate;
    assign shift_invalidate_row = e_invalidate_row;
`endif

    // ---- BSNOOP: B fill-time snoop-merge (bounded-time coherent scanout fill) --------------------
    // For the beat the current fill is writing ({fill_row, fillbeat}), overlay the DDR data with any
    // NEWER value still in flight through the write path. Priority oldest -> newest application
    // (later assignment wins): DDR < d_fwd (last flushed single beat, posted-window cover) < wb (A's
    // unflushed write-behind) < in-flight D run burst (rb_data via d_addr/d_blen) < accumulated run
    // buffer (rb_base/rb_cnt) < in-flight D single-beat job (d_wdata final at D_WR; df new-lanes
    // during D_RD/D_MRG) < wc (the combiner's current partial beat, newest of all). Same-data
    // overlaps between sources are harmless. All sources are registered in this module.
    wire [15:0] bfill_bt   = {bsn_fill_row_q, bsn_fillbeat_q}; // beat the fill writes this cycle
`ifdef MUT_NO_BSNOOP
    always_comb bfill_merged = b_rdata;      // mutation: no merge (old design; coherency via barriers)
`else
    wire [15:0] bsn_bstoff = bfill_bt - bsn_d_addr_q;             // offset into an in-flight run burst
    wire        bsn_burst  = d_start && d_wr && d_is_burst && ({8'd0, bsn_bstoff} < {20'd0, bsn_d_blen_q});
    wire        bsn_single = d_start && d_wr && !d_is_burst && (bsn_d_addr_q == bfill_bt);
    wire        bsn_rmwjob = ((dst==D_RD) || (dst==D_MRG)) && (df_beat == bfill_bt);
    wire [15:0] bsn_rboff  = bfill_bt - rb_base;                  // offset into the accumulated run
    wire        bsn_rbacc  = (rb_cnt != 4'd0) && ({12'd0, bsn_rboff[3:0]} < {12'd0, rb_cnt}) && (bsn_rboff[15:4] == 12'd0);
`ifdef MUT_NO_BMERGE
    // coverage mutation (tb_vram_bsnoop): barriers stay removed but the merge is OFF -> a fill racing
    // pending writes returns STALE DDR data -> the strict data check MUST fail.
    always_comb bfill_merged = b_rdata;
`else
    always_comb begin
        bfill_merged = b_rdata;
        // Accepted-write publication bypass. Once a D burst retires, none of
        // the live combiner/run sources below exists, but the Avalon bridge may
        // still return the pre-write DDR image. The persistent shadow is the
        // exact newest accepted beat and is safe to publish to this read-only
        // scan fill. Newer unaccepted/live producers below retain priority.
        if (shw_en && !dbl_on && shw_v_q && shw_q[69]
            && (shw_q[68:64] == bfill_bt[15:11])
            && (shw_cand_q == bfill_bt))
            bfill_merged = shw_q[63:0];
        if (d_fwd_v && (d_fwd_beat == bfill_bt))            bfill_merged = d_fwd;
        if (wb_v && (wb_addr[15:0] == bfill_bt))            bfill_merged = wb_data;
        if (bsn_burst)                                      bfill_merged = rb_data[bsn_bstoff[2:0]];
        if (bsn_rbacc)                                      bfill_merged = rb_data[bsn_rboff[2:0]];
        if (bsn_single)                                     bfill_merged = d_wdata;
        if (bsn_rmwjob)                                     bfill_merged = d_lane_merge(bfill_merged, df_data, df_mask);
        if ((wc_mask != 4'd0) && (bsn_wc_beat_q == bfill_bt)) bfill_merged = d_lane_merge(bfill_merged, wc_data, wc_mask);
    end
`endif
`endif

`ifndef SYNTHESIS
    // The commit boundary is functional, not an implementation hint: every accepted B beat
    // must appear exactly one clock later with its address/data intact, including back-to-back
    // returns.  rc_valid may rise only on the clock after a terminal staged commit was observed.
    always_ff @(posedge clk) begin
        if (rst) begin
            bsn_expect_v<=1'b0; bsn_expect_addr<=7'd0; bsn_expect_data<=64'd0;
            bsn_final_commit_q<=1'b0; bsn_rc_valid_q<=1'b0;
        end else begin
            if (bsn_commit_v !== bsn_expect_v)
                $fatal(1, "BSNOOP commit valid lost/inserted a fill beat");
            if (bsn_expect_v && (bsn_commit_addr !== bsn_expect_addr))
                $fatal(1, "BSNOOP commit address changed across stage");
            if (bsn_expect_v && (bsn_commit_data !== bsn_expect_data))
                $fatal(1, "BSNOOP commit data changed across stage");
            if (rc_valid && !bsn_rc_valid_q && !bsn_commit_done_q && !bsn_final_commit_q)
                $fatal(1, "BSNOOP published rc before terminal staged commit");

            bsn_expect_v <= (bts==B_FILL) && b_rd_valid;
            if ((bts==B_FILL) && b_rd_valid) begin
                bsn_expect_addr <= bsn_fillbeat_q;
                bsn_expect_data <= bfill_merged;
            end
            bsn_final_commit_q <= bsn_commit_v && (bsn_commit_addr==7'd127);
            bsn_rc_valid_q <= rc_valid;
        end
    end

    // Inductive currency proof for the implementation-only locality copies.
    always_ff @(posedge clk) begin
        if (!rst) begin
            if (bsn_fill_row_q !== fill_row)
                $fatal(1, "BSNOOP fill-row locality copy diverged");
            if (bsn_fillbeat_q !== fillbeat[6:0])
                $fatal(1, "BSNOOP fill-beat locality copy diverged");
            if (bsn_d_addr_q !== d_addr[15:0])
                $fatal(1, "BSNOOP D-address locality copy diverged");
            if (bsn_d_blen_q !== d_blen[3:0])
                $fatal(1, "BSNOOP D-length locality copy diverged");
            if (ack_wc_beat_q !== wc_beat)
                $fatal(1, "DMA-ack beat locality copy diverged");
            if (bsn_wc_beat_q !== wc_beat)
                $fatal(1, "BSNOOP combiner-beat locality copy diverged");
        end
    end
`endif

    // ================= L2 arbiter: B > E(SRT) > A > D(fb) > C(erase) -> agent ==================
    logic        tst_wr_req, tst_rd_req;
    logic [25:0] tst_addr;
    logic [63:0] tst_wdata_lat, tst_rdata;             // latched single-beat write value
    wire  [63:0] tst_wdata;                            // granted lane's live write-burst head
    wire         tst_wnext;                            // agent: a burst write beat was accepted
    wire         d_burst_next;
    logic [ 7:0] tst_be, tst_burstcnt;
    logic        tst_rd_valid;

    logic [1:0] l_gnt;   // 0=A, 1=B, 2=C(autoerase or supervised SRT), 3=D(fb-combine)
    // Cycle-exact one-hot copy consumed only by the shadow prefetch address.
    // Keeping this register local removes the late l_gnt decode/route from the
    // synchronous 2048-entry valid lookup without changing which return beat
    // advances the lookahead.  The generic lane routing still uses l_gnt.
    (* dont_merge *) logic shw_b_gnt;
    localparam [1:0] L_IDLE=2'd0, L_ACCEPT=2'd1, L_RUN=2'd2, L_DONE=2'd3;

    // ---- PUBLICATION FENCE (2026-07-18, UMK3/Hangtime coherence transplant) ------------
    // The bridge ACCEPTS a write before the data is physically readable; a read issued in
    // that window returns STALE data, and a stale RMW merge writes the corruption back
    // PERMANENTLY (sim-reproduced: 66-entry vertical strip at RMW-preserved beat lanes
    // under cfg_pub_delay=3000; the cab "missing verticals" class). Fix: 4 independent
    // 128-row regions (beat addr [15:14]) go DIRTY at write acceptance (both endpoints of
    // a burst) and are cleared only when a 1-beat readback of the region's proof address
    // returns the exact final accepted value. Every READ issuer (B scan fill, A CPU read,
    // D partial-RMW read, C source-fill) to a dirty region issues the proof poll instead
    // of its access; WRITES are never gated (single-outstanding ordering). An already-
    // dirty region's proof ADVANCES to each later retired write (a later transaction
    // orders all older ones; without advancement a cross-region burst can strand an old
    // proof address whose value never reappears). Persistent across core rst (sdram_por
    // domain) like the agent. Caveat carried from the source work: readback-equality has
    // an ABA ambiguity if old==new; this is the leading reproduced mechanism, not a
    // documented bridge guarantee.
    logic [3:0]  pub_dirty;
    logic [15:0] pub_addr   [0:3];
    logic [63:0] pub_expect [0:3];
    logic [1:0]  pub_page;
    logic        l_proof;
    logic        tst_wr_done;  logic [25:0] tst_wr_base;
    logic [7:0]  tst_wr_count; logic [63:0] tst_wr_last_data;
    wire  [15:0] pub_ret_base = tst_wr_base[15:0];
    wire  [15:0] pub_ret_last = tst_wr_base[15:0] + {8'd0, tst_wr_count} - 16'd1;
    wire  [3:0]  pub_ret_mask = (4'b0001 << pub_ret_base[15:14]) | (4'b0001 << pub_ret_last[15:14]);
    // retirement-collision hold: metadata lands this edge; no gated read may issue using
    // the previous clean bit on the same cycle.
    wire         pub_hold = tst_wr_done;
    wire         pub_match_evt;

    // ---- bounded posted-range guard (A CPU / D partial-RMW / C source reads) ----------
    // These reads must NOT go through the readback fence: a blit's own write stream
    // re-arms its region's proof forever (measured self-livelock at launch 33). Instead
    // a read OVERLAPPING a recently-accepted write range WAITS until the range ages out
    // (PG_WINDOW clk, sized >= the bridge's realistic publication latency). 4-deep
    // rotating history: deep posting keeps several transactions unpublished at once --
    // a 1-deep range is the reference's own killed mutation. Publication beyond
    // PG_WINDOW remains the documented ABA-class caveat (readback cannot bound it
    // without livelocking the write path).
    localparam int PG_WINDOW = 2047;
    logic [15:0] pg_base [0:3];
    logic [15:0] pg_last [0:3];
    logic [10:0] pg_age  [0:3];
    logic [1:0]  pg_wr;
    integer pge;
    always_ff @(posedge clk) begin
        if (sdram_por) begin
            for (pge = 0; pge < 4; pge = pge + 1) begin
                pg_base[pge] <= 16'd0; pg_last[pge] <= 16'd0; pg_age[pge] <= 11'd0;
            end
            pg_wr <= 2'd0;
        end else begin
            for (pge = 0; pge < 4; pge = pge + 1)
                if (pg_age[pge] != 11'd0) pg_age[pge] <= pg_age[pge] - 11'd1;
            if (tst_wr_done) begin
                pg_base[pg_wr] <= pub_ret_base; pg_last[pg_wr] <= pub_ret_last;
                pg_age[pg_wr]  <= 11'(PG_WINDOW);
                pg_wr <= pg_wr + 2'd1;
            end
        end
    end
    // shadow write capture: every accepted beat, straight off the agent's accept
    // stream -- tst_wnext covers burst beats 0..n-2 (FWFT pops), tst_wr_done's
    // registered {addr,data} covers the final (and any single) beat.
    logic [7:0] shw_cnt;
    wire [15:0] shw_wa = tst_addr[15:0] + {8'd0, shw_cnt};
    // one write port: burst beats stream through tst_wnext; the final (or single)
    // beat lands via tst_wr_done a cycle later.
    always_ff @(posedge clk) begin
`ifdef MUT_SHW_VALID_CORE_RST_CLEAR
        if (sdram_por || rst) begin
`else
        if (sdram_por) begin
`endif
            shw_cnt <= 8'd0;
            shw_valid <= '0;
        end else begin
            if (tst_wr_req) shw_cnt <= 8'd0;
            if (tst_wnext) shw_cnt <= shw_cnt + 8'd1;
            if (tst_wr_done) begin
                shw_mem[shw_index(pub_ret_last)]
                    <= {1'b1, pub_ret_last[15:11], tst_wr_last_data};
                shw_valid[shw_index(pub_ret_last)] <= 1'b1;
            end else if (tst_wnext) begin
                shw_mem[shw_index(shw_wa)]
                    <= {1'b1, shw_wa[15:11], tst_wdata};
                shw_valid[shw_index(shw_wa)] <= 1'b1;
            end
        end
    end
    // Pipelined candidate lookup. B owns the L2 port throughout an atomic fill,
    // so it can borrow the shadow read port without delaying A/D. Consecutive
    // DDR return beats need a one-beat lookahead: on a valid return, fillbeat is
    // incremented at this edge, therefore the M10K address captured at the same
    // edge must already name fillbeat+1 for the following cycle.
    wire shw_b_rd_valid = shw_b_gnt && (ls == L_RUN) && tst_rd_valid && !l_proof;
`ifndef SYNTHESIS
    // The timing duplicate is an implementation-only cut, never new state.
    always_ff @(posedge clk)
        if (!rst && (shw_b_gnt !== (l_gnt == 2'd1)))
            $fatal(1, "shadow B-grant duplicate diverged from l_gnt");
`endif
    wire [15:0] shw_b_cand = bfill_bt + ((bts == B_FILL && shw_b_rd_valid) ? 16'd1 : 16'd0);
    wire [15:0] shw_cand = (bts == B_FILL) ? shw_b_cand
                           : (a_start && !a_wr) ? a_addr[15:0] : d_addr[15:0];
    wire [10:0] shw_cand_idx = shw_index(shw_cand);
    wire [15:0] shw_v_bank_d;
    // Explicit taps are deliberate: avoid a variable indexed part-select that
    // older sv2v/Quartus may lower back into one wide shift/mux cone.
    assign shw_v_bank_d[ 0] = shw_valid[{shw_cand_idx[10:4], 4'h0}];
    assign shw_v_bank_d[ 1] = shw_valid[{shw_cand_idx[10:4], 4'h1}];
    assign shw_v_bank_d[ 2] = shw_valid[{shw_cand_idx[10:4], 4'h2}];
    assign shw_v_bank_d[ 3] = shw_valid[{shw_cand_idx[10:4], 4'h3}];
    assign shw_v_bank_d[ 4] = shw_valid[{shw_cand_idx[10:4], 4'h4}];
    assign shw_v_bank_d[ 5] = shw_valid[{shw_cand_idx[10:4], 4'h5}];
    assign shw_v_bank_d[ 6] = shw_valid[{shw_cand_idx[10:4], 4'h6}];
    assign shw_v_bank_d[ 7] = shw_valid[{shw_cand_idx[10:4], 4'h7}];
    assign shw_v_bank_d[ 8] = shw_valid[{shw_cand_idx[10:4], 4'h8}];
    assign shw_v_bank_d[ 9] = shw_valid[{shw_cand_idx[10:4], 4'h9}];
    assign shw_v_bank_d[10] = shw_valid[{shw_cand_idx[10:4], 4'ha}];
    assign shw_v_bank_d[11] = shw_valid[{shw_cand_idx[10:4], 4'hb}];
    assign shw_v_bank_d[12] = shw_valid[{shw_cand_idx[10:4], 4'hc}];
    assign shw_v_bank_d[13] = shw_valid[{shw_cand_idx[10:4], 4'hd}];
    assign shw_v_bank_d[14] = shw_valid[{shw_cand_idx[10:4], 4'he}];
`ifdef MUT_SHW_VALID_BANK15_ALIAS14
    // Named wiring mutant: alias bank 15 to adjacent bank 14. The directed
    // even/odd validity planes in tb_yunit_shw_valid_retime must kill this.
    assign shw_v_bank_d[15] = shw_valid[{shw_cand_idx[10:4], 4'he}];
`else
    assign shw_v_bank_d[15] = shw_valid[{shw_cand_idx[10:4], 4'hf}];
`endif
`ifdef MUT_SHW_VALID_LIVE_BANK_SELECT
    // Named currency mutant: select the registered tap row with the LIVE
    // candidate bank rather than the bank captured beside shw_q/cand_q.
    assign shw_v_q = shw_v_bank_q[shw_cand_idx[3:0]];
`else
    assign shw_v_q = shw_v_bank_q[shw_v_bank_sel_q];
`endif
    always_ff @(posedge clk) begin
        shw_q             <= shw_mem[shw_cand_idx];
        shw_v_bank_q      <= shw_v_bank_d;
        shw_v_bank_sel_q  <= shw_cand_idx[3:0];
        shw_cand_q        <= shw_cand;
    end
    // S4 INC3: disable the partial-RMW-skip shadow in double-buffer -- its BRAM tag can't carry the sel
    // bit, so an entry from the previous frame's back buffer would alias -> force a real back-buffer
    // RMW read every time (correct; the double-buffer removes the drain-pressure that motivated the skip).
    wire shw_q_hit = !dbl_on && shw_v_q && shw_q[69] &&
                     (shw_q[68:64] == shw_cand_q[15:11]);

    function automatic logic pg_overlap(input logic [15:0] lo, input logic [15:0] hi);
        pg_overlap = ((pg_age[0] != 11'd0) && !(hi < pg_base[0] || lo > pg_last[0]))
                  || ((pg_age[1] != 11'd0) && !(hi < pg_base[1] || lo > pg_last[1]))
                  || ((pg_age[2] != 11'd0) && !(hi < pg_base[2] || lo > pg_last[2]))
                  || ((pg_age[3] != 11'd0) && !(hi < pg_base[3] || lo > pg_last[3]));
    endfunction
    // lane-qualified pipelined hits + lookup CURRENCY (defined regardless of the
    // mutation switch: the grant latch consumes them). CURRENCY: an A/D read may
    // only be granted when the pipelined lookup corresponds to ITS address, or
    // the latch captures a stale miss and merges from possibly-stale DDR data.
    // Guard = eviction backstop on shadow MISSES only (a blanket hold stalled
    // every write-then-readback ~2047 clk; xdiff TIMEOUT).
    wire a_shw_hit  = shw_q_hit && (shw_cand_q == a_addr[15:0]);
    wire d_shw_hit  = shw_q_hit && (shw_cand_q == d_addr[15:0]);
    wire a_lkp_cur  = (shw_cand_q == a_addr[15:0]);
    wire d_lkp_cur  = (shw_cand_q == d_addr[15:0]);
`ifdef YUNIT_NO_PUBGUARD
    // mutation build: whole publication protection off (fence + guard) -> the
    // delayed-publication A/B must re-show the stale-RMW corruption strip.
    wire pub_fence_en = 1'b0;
    wire a_pub_hazard = 1'b0;
    wire d_pub_hazard = 1'b0;
    wire c_pub_hazard = 1'b0;
`ifdef YUNIT_SRT_FILL_BURST
    wire e_pub_hazard = 1'b0;
`endif
`else
    wire pub_fence_en = !dbl_on;   // S4 INC2: B(front) scanout never races back-buffer writes -> no proof fence
    wire a_pub_hazard = (pg_overlap(a_addr[15:0], a_addr[15:0]) && !a_shw_hit) || tst_wr_done || !a_lkp_cur;
    wire d_pub_hazard = (pg_overlap(d_addr[15:0], d_addr[15:0]) && !d_shw_hit) || tst_wr_done || !d_lkp_cur;
    wire c_pub_hazard = pg_overlap(c_addr[15:0], c_addr[15:0] + {8'd0, c_burstlen} - 16'd1) || tst_wr_done;
`ifdef YUNIT_SRT_FILL_BURST
    // A ToShiftReg load must not sample a just-accepted A/C/D burst before it
    // becomes readable.  Reuse Y's all-writer posted-range guard; do not import
    // Wolf's narrower burst-only policy over the 67d protection.
    wire e_pub_hazard = pg_overlap(e_base_beat[15:0], e_base_beat[15:0] + 16'd255)
                      || tst_wr_done;
`endif
`endif
    integer pgi;
    always_ff @(posedge clk) begin
        if (sdram_por) begin
            pub_dirty <= 4'b0000;
            for (pgi = 0; pgi < 4; pgi = pgi + 1) begin
                pub_addr[pgi] <= 16'd0; pub_expect[pgi] <= 64'd0;
            end
        end else begin
            if (pub_match_evt) pub_dirty[pub_page] <= 1'b0;
            if (tst_wr_done)
                for (pgi = 0; pgi < 4; pgi = pgi + 1)
                    if (pub_dirty[pgi] || pub_ret_mask[pgi]) begin
                        pub_dirty[pgi]  <= 1'b1;               // re-dirty wins over a same-edge match
                        pub_addr[pgi]   <= pub_ret_last;
                        pub_expect[pgi] <= tst_wr_last_data;
                    end
        end
    end
    // Burst-write streaming (D fb-combine AND C erase, cont.24): present the granted lane's run-
    // buffer head on tst_wdata (FWFT); each tst_wnext (agent accepted a beat) advances wstream_idx.
    // wstream_idx reset at the burst grant below. Only one lane is granted at a time -> shared idx.
    assign tst_wdata    =
`ifdef YUNIT_SRT_FILL_BURST
                          (l_gnt==2'd2 && e_start) ? src_q :
`endif
                          (l_gnt==2'd3 && d_is_burst) ? rb_data[wstream_idx]
                        : (l_gnt==2'd2 && c_is_burst) ? cb_data[wstream_idx]
                        : tst_wdata_lat;
    assign d_burst_next = (((l_gnt==2'd3 && d_is_burst)
`ifdef YUNIT_SRT_FILL_BURST
                            || (l_gnt==2'd2 && c_is_burst && !e_start)
`else
                            || (l_gnt==2'd2 && c_is_burst)
`endif
                           ) && ls==L_RUN) && tst_wnext;
`ifdef YUNIT_SRT_FILL_BURST
    assign e_burst_next = (l_gnt==2'd2) && e_start && (ls==L_RUN) && tst_wnext;
`endif
    always_ff @(posedge clk) begin
        if (rst) begin
            ls<=L_IDLE; l_gnt<=2'd0; shw_b_gnt<=1'b0; tst_rd_req<=1'b0; tst_wr_req<=1'b0;
            tst_addr<=26'd0; tst_wdata_lat<=64'd0; tst_be<=8'd0; tst_burstcnt<=8'd1;
            a_done<=1'b0; b_done<=1'b0; c_done<=1'b0; d_done<=1'b0;
            wstream_idx<=4'd0;
            l_proof<=1'b0; pub_page<=2'd0;   // fence STATE (pub_dirty/addr/expect) is sdram_por-persistent
        end else begin
            tst_rd_req<=1'b0; tst_wr_req<=1'b0; a_done<=1'b0; b_done<=1'b0; c_done<=1'b0; d_done<=1'b0;
            if (d_burst_next) wstream_idx <= wstream_idx + 4'd1;   // advance the D-burst FWFT source
            case (ls)
                // Gate acceptance on the agent actually being IDLE. The agent runs on sdram_por while
                // A/B/L2 run on core rst (P0022 split): a core_rst pulse mid-burst snaps L2 to L_IDLE
                // while the agent keeps draining its pre-reset transaction. Without this guard L2 would
                // pulse a req the busy agent ignores, then mistake the OLD transaction's tst_busy for
                // its own acceptance and fabricate a completion for an access that never issued
                // ([[lessons_gate_fsm_not_output]] — never sequence on a busy you do not own). Waiting
                // for !tst_busy makes the orphaned burst drain (its beats are dropped: a_rd_valid/
                // b_rd_valid are gated on ls==L_RUN) before any fresh command is issued.
                // PRIORITY (4 grants, W-THRU2+SF-SRT): B (scanout, hard real-time) > supervised
                // SRT-on-C > A (CPU, latency-critical, P1.9e) > D (fb-combine, redraw bulk)
                // > ordinary C erase (beam-paced background). A is gated
                // on !d_busy so the CPU only issues once the combiner has DRAINED to DDR -- combined
                // with a_start forcing a D flush + parking new fb accepts (see the D block), this
                // orders CPU-vs-fb on the shared VRAM and stops the sustained fb stream from starving
                // the CPU lane (the contention-gate deadlock). D above C: the combined fb write is
                // now ~1 beat / 4px (was ~2 RMW ops/px) so its total demand is small, and the beam-
                // paced C engine (goal/catch-up, ~5x per-line slack) keeps up between D's 1-beat
                // flushes (d_start is low while the combiner accumulates, so C is granted then).
                L_IDLE: if (!tst_busy) begin
                    // PUBLICATION FENCE: a cold B fill of a dirty region first issues the
                    // region's 1-beat proof readback (same lane grant, l_proof marked).  B
                    // already has highest priority and b_start remains held, so no newer
                    // write can retire between this ordering point and the real row fill;
                    // newer framebuffer accepts remain in the live BSNOOP structures and
                    // are merged beat-for-beat.  This is deliberately NOT B_DRAIN: the
                    // renderer is never required to become globally empty. pub_hold is the
                    // retirement-collision one-cycle hold.
                    if (b_start) begin                       // B: scanout sub-burst = highest priority
                        if (B_SCAN_PROOF && pub_fence_en && pub_hold) begin end
                        else if (B_SCAN_PROOF && pub_fence_en && pub_dirty[b_addr[15:14]]) begin
                            l_gnt<=2'd1; shw_b_gnt<=1'b1; l_proof<=1'b1; pub_page<=b_addr[15:14];
                            tst_addr<={9'd0, sel_front, pub_addr[b_addr[15:14]]}; tst_burstcnt<=8'd1;  // B: FRONT
                            tst_rd_req<=1'b1; ls<=L_ACCEPT;
                        end else begin
                            l_gnt<=2'd1; shw_b_gnt<=1'b1; tst_addr<={9'd0, sel_front, b_addr[15:0]}; tst_burstcnt<=b_burstlen; tst_rd_req<=1'b1; ls<=L_ACCEPT;  // B: FRONT
                        end
                    end else if (b_bus_lock) begin            // atomic row fill: reserve sub-burst gaps for B
`ifdef YUNIT_SRT_FILL_BURST
                    end else if (e_start) begin               // supervised SRT sub-burst on C's grant/page latch
                        l_gnt<=2'd2; shw_b_gnt<=1'b0;
                        tst_addr<={9'd0, e_fbsel, e_addr[15:0]};
                        tst_burstcnt<=e_blen; tst_be<=8'hFF;
                        if (e_wr) tst_wr_req<=1'b1; else tst_rd_req<=1'b1;
                        ls<=L_ACCEPT;
`endif
                    end else if (a_start && !d_busy) begin    // A: CPU single beat, only on a DRAINED combiner
                        // RMW/CPU reads are NOT fence-gated (a blit's own write stream
                        // re-arms its region forever = self-livelock, measured: wedge at
                        // launch 33). They use the bounded posted-range guard instead.
                        if (!a_wr && a_pub_hazard) begin end  // overlaps a recently-posted window -> wait it out
                        else begin
                            l_gnt<=2'd0; shw_b_gnt<=1'b0; tst_addr<={9'd0, sel_back, a_addr[15:0]}; tst_burstcnt<=8'd1;  // A: BACK
                            if (a_wr) begin tst_wdata_lat<=a_wdata; tst_be<=a_be; tst_wr_req<=1'b1; end
                            else begin tst_rd_req<=1'b1;
                                       shw_base<=shw_q[63:0]; shw_base_hit<=(a_shw_hit === 1'b1); end
                            ls<=L_ACCEPT;
                        end
                    end else if (d_start) begin              // D: fb-combine flush -- BURST run OR single beat
                        if (!d_wr && !d_is_burst && d_pub_hazard) begin end  // partial-RMW read vs posted window
                        else begin
                            l_gnt<=2'd3; shw_b_gnt<=1'b0;
                            if (d_is_burst) begin            // multi-beat run: addr+len ONCE, stream rb_data via tst_wnext
                                tst_addr<={9'd0, sel_back, d_addr[15:0]}; tst_burstcnt<=d_blen; tst_be<=8'hFF; tst_wr_req<=1'b1;  // D: BACK
                                wstream_idx<=4'd0;           // rb_data[0] (=lowest beat) presented on tst_wdata (comb)
                            end else begin                   // single beat: be=FF write (own-fwd) or RMW read
                                tst_addr<={9'd0, sel_back, d_addr[15:0]}; tst_burstcnt<=8'd1;  // D: BACK
                                if (d_wr) begin tst_wdata_lat<=d_wdata; tst_be<=d_be; tst_wr_req<=1'b1; end
                                else begin tst_rd_req<=1'b1;
                                           shw_base<=shw_q[63:0]; shw_base_hit<=(d_shw_hit === 1'b1); end
                            end
                            ls<=L_ACCEPT;
                        end
                    end else if (c_start) begin              // C: erase BURST write OR cold source-fill read
                        if (!c_wr && c_pub_hazard) begin end
                        else begin
                            l_gnt<=2'd2; shw_b_gnt<=1'b0; tst_addr<={9'd0, sel_back, c_addr[15:0]}; tst_burstcnt<=c_burstlen;  // C: BACK
                            if (c_wr) begin                   // erase: stream cb_data[] as a be=FF burst
                                tst_be<=8'hFF; tst_wr_req<=1'b1; wstream_idx<=4'd0;
                            end else begin                    // cold source-fill: burst read
                                tst_rd_req<=1'b1;
                            end
                            ls<=L_ACCEPT;
                        end
                    end
                end
                L_ACCEPT: if (tst_busy) ls<=L_RUN;            // agent accepted the transaction
                L_RUN: if (!tst_busy) begin                  // transaction complete
                        // a publication proof poll completes WITHOUT signalling the lane's
                        // done: the lane's held start re-arbitrates (poll again or, once
                        // pub_match_evt cleared the region this same cycle, run for real).
                        if (!l_proof)
                            case (l_gnt)
                                2'd1:    b_done<=1'b1;
                                2'd2:    c_done<=1'b1;
                                2'd3:    d_done<=1'b1;
                                default: a_done<=1'b1;
                            endcase
                        l_proof<=1'b0;
                        ls<=L_DONE;
                    end
                L_DONE: ls<=L_IDLE;                           // bubble: requester clears its start level before re-arbitrate
                default: ls<=L_IDLE;
            endcase
        end
    end
    // route read beats to the granted consumer (a proof poll's beat goes to NO lane)
    assign a_rd_valid = (l_gnt==2'd0) && (ls==L_RUN) && tst_rd_valid && !l_proof;
    assign b_rd_valid = (l_gnt==2'd1) && (ls==L_RUN) && tst_rd_valid && !l_proof;
    assign c_rd_valid = (l_gnt==2'd2) && (ls==L_RUN) && tst_rd_valid && !l_proof;
    assign d_rd_valid = (l_gnt==2'd3) && (ls==L_RUN) && tst_rd_valid && !l_proof;
`ifdef YUNIT_SRT_FILL_BURST
    assign e_rd_valid = c_rd_valid && e_start;
`endif
    // publication proof: the 1-beat poll returned the exact final accepted value
    assign pub_match_evt = l_proof && (ls==L_RUN) && tst_rd_valid &&
                           (tst_rdata == pub_expect[pub_page]);
    assign a_rdata = tst_rdata;
    assign b_rdata = tst_rdata;
    assign c_rdata = tst_rdata;
    assign d_rdata = tst_rdata;
`ifdef YUNIT_SRT_FILL_BURST
    assign e_rdata = tst_rdata;
    assign e_done  = c_done;

    // C-owned SRT supervisor. Capture one command, drain/park every back-buffer
    // writer plus any in-flight ordinary C job, then execute eight <=32-beat
    // sub-bursts through C's grant. B scanout retains hard priority between
    // sub-bursts. Completion follows two explicit line-buffer invalidations.
    always_ff @(posedge clk) begin
        if (rst) begin
            est<=E_IDLE; e_start<=1'b0; e_wr<=1'b0; e_addr<=26'd0;
            e_blen<=8'd1; e_fill<=9'd0; e_base_entry<=18'd0;
            e_base_beat<=17'd0; e_op_we<=1'b0; e_fbsel<=1'b0;
            shift_done<=1'b0; shift_rdata<=16'd0;
        end else begin
            shift_done <= 1'b0;
            case (est)
                E_IDLE: if (shift_req && shift_ready) begin
                    e_base_entry <= shift_entry;
                    e_base_beat  <= shift_entry[17:2];
                    e_op_we      <= shift_write;
                    e_fbsel      <= sel_back;
                    e_fill       <= 9'd0;
                    est          <= E_DRAIN;
                end
                E_DRAIN: if ((ats == A_IDLE) && !a_start && !wb_v
                             && !d_busy && !d_start && (cts == C_IDLE) && !swp_v
                             && (ls == L_IDLE) && !tst_busy
                             && (e_op_we || !e_pub_hazard))
                    est <= e_op_we ? E_WREQ : E_RREQ;
                E_RREQ: begin
                    e_addr  <= {9'd0, e_base_beat} + {17'd0, e_fill};
                    e_blen  <= ((9'd256 - e_fill) > {1'b0, BMAX})
                             ? BMAX : 8'((9'd256 - e_fill));
                    e_wr    <= 1'b0; e_start <= 1'b1; est <= E_RFILL;
                end
                E_RFILL: begin
                    if (e_rd_valid) begin
                        if (e_fill == 9'd0) shift_rdata <= e_rdata[15:0];
                        e_fill <= e_fill_rd_n;
                    end
                    if (e_done) begin
`ifdef MUT_SRT_EARLY_DONE
                        if (e_fill_rd_n < 9'd256) shift_done <= 1'b1;
`endif
                        e_start <= 1'b0;
                        est <= (e_fill_rd_n >= 9'd256) ? E_FIN : E_RREQ;
                    end
                end
                E_WREQ: begin
                    e_addr  <= {9'd0, e_base_beat} + {17'd0, e_fill};
                    e_blen  <= ((9'd256 - e_fill) > {1'b0, BMAX})
                             ? BMAX : 8'((9'd256 - e_fill));
                    e_wr    <= 1'b1; e_start <= 1'b1; est <= E_WSTREAM;
                end
                E_WSTREAM: begin
                    // tst_wnext advances the FWFT buffer on every accepted
                    // beat except the final beat of a burst.
                    if (e_burst_next) e_fill <= e_fill + 9'd1;
                    if (e_done) begin
`ifdef MUT_SRT_EARLY_DONE
                        if ((e_fill + 9'd1) < 9'd256) shift_done <= 1'b1;
`endif
                        // Count the final accepted beat here; tst_wnext
                        // deliberately does not pulse for that beat.
                        e_start <= 1'b0; e_wr <= 1'b0; e_fill <= e_fill + 9'd1;
                        est <= ((e_fill + 9'd1) >= 9'd256) ? E_INV0 : E_WREQ;
                    end
                end
                E_INV0: est <= E_INV1;
                E_INV1: est <= E_FIN;
                E_FIN: begin shift_done <= 1'b1; est <= E_IDLE; end
                default: est <= E_IDLE;
            endcase
        end
    end

`ifndef SYNTHESIS
    // SF's measured bases are row-pair/64-bit aligned (first entry 0x05800,
    // then +0x400 for 105 commands). Reject a future unsupported command in
    // simulation rather than silently invalidating the wrong span.
    always_ff @(posedge clk)
        if (!rst && shift_req && shift_ready && (shift_entry[9:0] != 10'd0))
            $fatal(1, "unaligned SF SRT row-pair entry %05x", shift_entry);
`endif
`endif

    stv_vram_ddr_agent #(.VRAM_DDR_BASE(VRAM_DDR_BASE)) u_agent (
        .clk(clk), .sdram_por(sdram_por),
        .tst_wr_req(tst_wr_req), .tst_rd_req(tst_rd_req), .tst_addr(tst_addr),
        .tst_wdata(tst_wdata), .tst_be(tst_be), .tst_burstcnt(tst_burstcnt),
        .tst_rdata(tst_rdata), .tst_rd_valid(tst_rd_valid), .tst_busy(tst_busy), .tst_wnext(tst_wnext),
        .tst_wr_done(tst_wr_done), .tst_wr_base(tst_wr_base),
        .tst_wr_count(tst_wr_count), .tst_wr_last_data(tst_wr_last_data),
        .ddram_addr(ddram_addr), .ddram_burstcnt(ddram_burstcnt), .ddram_rd(ddram_rd), .ddram_we(ddram_we),
        .ddram_din(ddram_din), .ddram_be(ddram_be),
        .ddram_busy(ddram_busy), .ddram_dout(ddram_dout), .ddram_dout_ready(ddram_dout_ready) );
endmodule
`default_nettype wire
