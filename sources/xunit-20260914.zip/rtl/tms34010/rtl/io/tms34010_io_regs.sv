// -----------------------------------------------------------------------------
// tms34010_io_regs.sv
//
// On-chip memory-mapped I/O register file for the TMS34010.
//
// Per the 1988 User's Guide Figure 6-1 (page 6-3), the GSP has 32 internal
// 16-bit registers occupying the bit-address range 0xC0000000-0xC00001FF.
// Each register sits at a 0x10-bit-aligned address (16 bits apart). The CPU
// (and, on real silicon, the host) reaches them through the ordinary
// bit-addressed memory interface; an address decodes to I/O space when its
// two MSBs are 11 and bits[29:9] are 0. The register index is addr[8:4].
//
// "All I/O registers ... are cleared to 0 at reset" (UG §6, Reset). The one
// documented exception concerns the HLT bit's dependence on the HCS pin of
// the host interface, which this FPGA reimplementation does not yet model;
// resetting every register to 0 is therefore correct here.
//
// Scope (Task 0081 — foundation; P00xx — live video counters):
//   - Plain read/write storage for the control/graphics registers that the
//     instruction set reads (PSIZE, PMASK, CONVSP, CONVDP, CONTROL, DPYCTL, ...).
//   - HCOUNT/VCOUNT are now the LIVE horizontal/vertical counters from u_video
//     (read-only on silicon; see the rdata mux). REFCNT/DPYADR remain plain
//     storage; INTPEND bits are software-clear with device set-on-event (DI/WV).
//
// Port shape:
//   - Synchronous active-high reset (assumption A0003), all registers -> 0.
//   - One synchronous write port (req & we & is_io).
//   - One combinational (async) read port. The 32x16 array is tiny (512
//     bits) and async read keeps this composable with the core's existing
//     register-style reads; FPGA maps it to flops + a 32:1 mux.
//   - `is_io` tells the caller whether `addr` decoded as I/O space, so the
//     surrounding memory fabric can route reads/writes here vs. external RAM.
//
// Spec source:
//   third_party/TMS34010_Info/docs/ti-official/1988_TI_TMS34010_Users_Guide.pdf
//   Figure 6-1 (I/O Register Memory Map), §6 "I/O Registers".
// -----------------------------------------------------------------------------

`default_nettype none
module tms34010_io_regs
  import tms34010_pkg::*;
(
  input  wire logic                  clk,
  input  wire logic                  rst,

  input  wire logic                  req,      // access strobe
  input  wire logic                  we,       // 1 = write, 0 = read
  // Registered write-command address.  In the core integration this comes
  // only from tms34010_io_write_boundary, never from the live CPU datapath.
  input  wire logic [ADDR_WIDTH-1:0] addr,
  input  wire logic [15:0]           wdata,
  // Field size of the registered write command (1..32). A sub-word write must
  // read-modify-write only the addressed bits; see io_field_merge.
  input  wire logic [FIELD_SIZE_WIDTH-1:0] wr_size,
  // RESIDUAL-TIMING (B): CE-registered precomputed field mask + pre-shifted
  // write data from tms34010_io_write_boundary.  When wr_pre_valid=1 the write
  // commit is the short (current & ~wr_mask)|wr_data_sh merge; the barrel-shift
  // cone was launched one CE edge upstream and rides the CE multicycle.  Legacy
  // unit TBs leave these unconnected (wr_pre_valid == 'z) and get the internal
  // io_field_merge fallback, so their behaviour is unchanged.
  input  wire logic [15:0]           wr_mask,
  input  wire logic [15:0]           wr_data_sh,
  input  wire logic                  wr_pre_valid,
  input  wire logic                  status_guard,
  // CE-registered extra half for aligned 020 DPYST/DPYNX/DINC long writes.
  // Legacy benches omit it; only an explicit pair-valid enables this path.
  input  wire logic [15:0]           wr_display_hi,
  input  wire logic                  wr_display_pair,

  // TMS34020 SETCDP side-write: when the SETCDP instruction retires the core
  // pulses setcdp_we for one cycle to load the MAME-computed CONVDP value into
  // the CONVDP register (DELTA (f); 34010ops.hxx:2437-2468). Tied 0 on the '010
  // (IS_34020=0) so this port is inert and io_regs stays byte-identical.
  input  wire logic                  setcdp_we,
  input  wire logic [15:0]           setcdp_convdp,

  // Live read/decode address.  Keeping it separate preserves async I/O reads
  // and external-write suppression without letting it reach io_reg[*].D.
  input  wire logic [ADDR_WIDTH-1:0] raddr,

  // Pixel-clock ENABLE for the video-timing counters (u_video). Threaded from
  // the emu (Arcade-SmashTV.sv ce_pix = 96 MHz / 12 = 8 MHz) through the core.
  // Left UNCONNECTED by legacy unit TBs -> u_video defaults to full rate (its
  // own `ce === 1'b0` guard), so those TBs are unaffected.
  input  wire logic                  ce_pix,

  output logic [15:0]           rdata,    // selected register (0 if not I/O)
  output logic [31:0]           display_pair_rdata, // aligned 020 pair, no side effects
  output logic                  is_io,    // addr decodes to I/O space

  // Dedicated taps for the graphics datapath (combinational views of the
  // stored registers). More can be added (PMASK/CONTROL) as the graphics ops
  // that need them land.
  output logic [15:0]           psize_o,  // PSIZE: pixel size in bits (1..16)
  output logic [15:0]           convdp_o, // CONVDP: XY->linear dest pitch shift
  output logic [15:0]           convsp_o, // CONVSP: XY->linear source pitch shift
  output logic [15:0]           control_o,// CONTROL: PPOP[14:10], PBV/PBH, W, T(bit5)
  output logic [15:0]           pmask_o,  // PMASK: plane mask (1 bit = plane masked)
  output logic [15:0]           intenb_o, // INTENB: maskable-interrupt enables
  output logic [15:0]           intpend_o,// INTPEND: maskable-interrupt pending bits
  output logic [15:0]           dpyctl_o, // CORE-2: DPYCTL bit 11 selects shift-register transfer
  output logic [15:0]           dpystrt_o,// DPYSTRT: frame display-address reload value
  output wire [31:0]            dbg_dpyst_value_o, // native 020 DPYST, passive
  output logic                 dbg_dpyst_valid_o, // full native pair write seen
  output logic [15:0]           dpytap_o, // DPYTAP: horizontal display tap
  output logic [15:0]           dpyadr_o, // live hardware/software display address
  output logic [15:0]           display_row_o,
  output logic [15:0]           display_col_o,
  output logic [1:0]            display_yoffset_o,
  output logic                  display_enable_o,
  // TUNIT-P0048: live HEBLNK >= HSBLNK. The TI TMS34010 User's Guide
  // pp. 6-27/6-29 defines HEBLNK as the end and HSBLNK as the start of
  // horizontal blanking, so this ordering leaves no active horizontal span.
  // MAME 0.289 tms34010.cpp:1168,1191-1193 consequently paints the configured
  // visarea black: the [heblnk,hsblnk) callback loop in
  // midtunit_v.cpp:848-856 runs zero times. Export the predicate here so its
  // one decode stays beside every other display-parameter decode.
  output logic                  display_blank_o,
  output logic                  vblank_start_o,
  output logic [15:0]           hstctlh_o,// HSTCTLH: host control (NMI/NMIM in bits 8/9)
  // First timing activation: registered one-cycle pulse on the clock AFTER the
  // write that changes HTOTAL from reset/disabled zero to nonzero.  This puts a
  // hard register boundary between CPU decode/write data and the video reset /
  // rephase tree; the HTOTAL value is already stored when consumers reset.
  output logic                  timing_start_o,
  input  wire logic                  nmi_clear,// 1-cycle: clear HSTCTLH.NMI (device took NMI)
  input  wire logic                  wvp_set,  // 1-cycle: set INTPEND.WV (window violation)
  // P0016: external interrupt pin LINT1 (level). Per the 1988 UG §8.3 the
  // INTPEND.X1P bit REFLECTS the pin level (it is not a latch and cannot be
  // cleared by writing INTPEND) -- so it is OR-mirrored into the INTPEND view
  // (both the dedicated intpend_o tap and CPU reads of the register).
  input  wire logic                  lint1_in,
  input  wire logic                  lint2_in,
  // Read-only board raster taps: UG video timing registers and live counters.
  output logic [15:0] video_hcount_o, video_vcount_o,
  output logic [15:0] video_heblnk_o, video_hsblnk_o, video_veblnk_o, video_vsblnk_o,
  output logic video_hs_o, video_vs_o, video_hb_o, video_vb_o, video_ready_o
);

  // -------------------------------------------------------------------------
  // TMS34020 delta (DELTA (b); step 8). The '020 has 64 x 16-bit I/O regs at
  // 0xC0000000-0xC00003FF (index addr[9:4]) with a DIFFERENT index ordering;
  // the '010 has 32 regs at 0xC0000000-0xC00001FF (index addr[8:4]). IO_N/IO_IW
  // and the RX_* role->index map below select the part; on the '010 every RX_*
  // equals its IO_IDX_* so the module is byte-identical (all values unchanged).
  // Enum: tms34010.h:61-95 ('010) / :183-251 ('020). Side effects: tms34010.cpp
  // :1400-1545 ('020 io_register_w). -------------------------------------------
  // M020 selects the '020 layout. It equals IS_34020 except under the step-8
  // gate mutant MUT_IOREGS_010_ORDER, which forces the '010 register order/count
  // even on the '020 -> the run_020_ioregs checks ('020 index map, CONTROL2
  // alias, DPYNX path) then fail, so the gate discriminates the remap.
`ifdef MUT_IOREGS_010_ORDER
  localparam bit M020 = 1'b0;
`else
  localparam bit M020 = IS_34020;
`endif
  localparam int unsigned IO_N  = M020 ? 64 : IO_REG_COUNT;   // register count
  localparam int unsigned IO_IW = M020 ? 6  : IO_REG_IDX_W;   // index width
  // Role -> raw index. 0-7 are V/H-interleaved on the '020; 8-21 match; 22+
  // diverge (PMASK splits, VCOUNT/HCOUNT swap, DPYTAP/DPYADR match).
  localparam int unsigned RX_HESYNC  = M020 ? 1  : IO_IDX_HESYNC;
  localparam int unsigned RX_HEBLNK  = M020 ? 3  : IO_IDX_HEBLNK;
  localparam int unsigned RX_HSBLNK  = M020 ? 5  : IO_IDX_HSBLNK;
  localparam int unsigned RX_HTOTAL  = M020 ? 7  : IO_IDX_HTOTAL;
  localparam int unsigned RX_VESYNC  = M020 ? 0  : IO_IDX_VESYNC;
  localparam int unsigned RX_VEBLNK  = M020 ? 2  : IO_IDX_VEBLNK;
  localparam int unsigned RX_VSBLNK  = M020 ? 4  : IO_IDX_VSBLNK;
  localparam int unsigned RX_VTOTAL  = M020 ? 6  : IO_IDX_VTOTAL;
  localparam int unsigned RX_DPYCTL  = IO_IDX_DPYCTL;   // 8 both
  localparam int unsigned RX_DPYSTRT = IO_IDX_DPYSTRT;  // 9 both
  localparam int unsigned RX_DPYINT  = IO_IDX_DPYINT;   // 10 both
  localparam int unsigned RX_CONTROL = IO_IDX_CONTROL;  // 11 both
  localparam int unsigned RX_HSTCTLH = IO_IDX_HSTCTLH;  // 16 both
  localparam int unsigned RX_INTENB  = IO_IDX_INTENB;   // 17 both
  localparam int unsigned RX_INTPEND = IO_IDX_INTPEND;  // 18 both
  localparam int unsigned RX_CONVSP  = IO_IDX_CONVSP;   // 19 both
  localparam int unsigned RX_CONVDP  = IO_IDX_CONVDP;   // 20 both
  localparam int unsigned RX_PSIZE   = IO_IDX_PSIZE;    // 21 both
  localparam int unsigned RX_PMASK   = M020 ? 22 : IO_IDX_PMASK;   // '020 PMASKL
  localparam int unsigned RX_DPYTAP  = M020 ? 27 : IO_IDX_DPYTAP;  // 27 both
  localparam int unsigned RX_VCOUNT  = M020 ? 28 : IO_IDX_VCOUNT;  // '010 29 / '020 28
  localparam int unsigned RX_HCOUNT  = M020 ? 29 : IO_IDX_HCOUNT;  // '010 28 / '020 29
  localparam int unsigned RX_DPYADR  = M020 ? 30 : IO_IDX_DPYADR;  // 30 both
  // '020-only registers (DELTA (b)); clamped to 0 on the '010 so io_reg[] index
  // references stay in-bounds (the logic using them is IS_34020-gated and dead
  // on the '010, so reading reg 0 there is harmless / never consumed).
  localparam int unsigned RX_CONTROL2 = M020 ? 25 : 0;
  localparam int unsigned RX_DPYSTL   = M020 ? 32 : 0;
  localparam int unsigned RX_DPYSTH   = M020 ? 33 : 0;
  localparam int unsigned RX_DPYNXL   = M020 ? 34 : 0;
  localparam int unsigned RX_DPYNXH   = M020 ? 35 : 0;
  localparam int unsigned RX_DINCL    = M020 ? 36 : 0;
  localparam int unsigned RX_DINCH    = M020 ? 37 : 0;

  // I/O-space decode. '010: MSBs=11, bits[29:9]=0, idx=addr[8:4].
  //                   '020: MSBs=11, bits[29:10]=0, idx=addr[9:4].
  logic [IO_IW-1:0] rd_idx;
  logic [IO_IW-1:0] wr_idx;
  logic             wr_is_io;
  assign is_io = (raddr[ADDR_WIDTH-1:ADDR_WIDTH-2] == 2'b11)
              && (raddr[ADDR_WIDTH-3:IO_IW+4] == '0);
  assign rd_idx = raddr[IO_IW+3 : 4];
  assign wr_is_io = (addr[ADDR_WIDTH-1:ADDR_WIDTH-2] == 2'b11)
                 && (addr[ADDR_WIDTH-3:IO_IW+4] == '0);
  assign wr_idx = addr[IO_IW+3 : 4];

  // Register storage.
  logic [15:0] io_reg [0:IO_N-1];

  // Value the addressed register takes after this write command, with only the
  // addressed field replaced. Aligned FS=16 writes reduce to `wdata`.
  logic [15:0] wr_merged;
  // RESIDUAL-TIMING (B): short precomputed merge on the board path; internal
  // io_field_merge fallback for legacy unit TBs that leave wr_pre_valid at 'z.
  // The two forms are byte-identical (wr_mask == io_field_mask(bit_off,size),
  // wr_data_sh == (wdata<<bit_off) & wr_mask).
  assign wr_merged = (wr_pre_valid === 1'b1)
                   ? ((io_reg[wr_idx] & ~wr_mask) | wr_data_sh)
                   : io_field_merge(io_reg[wr_idx], wdata, addr[3:0], wr_size);

  logic timing_start_req;
  assign timing_start_req = !rst && req && we && wr_is_io &&
                            (wr_idx == RX_HTOTAL) &&
                            (io_reg[RX_HTOTAL] == 16'd0) &&
                            (wr_merged != 16'd0);

  // The request is true on the HTOTAL write edge.  Its registered image is
  // consumed on the following edge, after io_reg[HTOTAL] has taken wdata.  A
  // held bus request cannot stretch the pulse: after the write edge HTOTAL is
  // nonzero, so timing_start_req falls before this pulse is consumed.
`ifdef MUT_TIMING_COMB_START
  // Mutation coverage for the rejected TimeQuest defect: restore the live CPU
  // decode directly onto the video reset/rephase tree.
  assign timing_start_o = timing_start_req;
`else
  always_ff @(posedge clk) begin
    if (rst) timing_start_o <= 1'b0;
    else     timing_start_o <= timing_start_req;
  end
`endif

  // ---------------------------------------------------------------------------
  // Display-interrupt source + live video counters (P0012 + P00xx).
  // The vendored `tms34010_video` block generates DPYINT_PULSE (a 1-clock strobe
  // at HSBLNK, the start of horizontal blanking at the end of DPYINT's selected
  // line) from the video-timing registers.
  // Wire it here where all the timing registers already live. It is clocked by
  // the io_regs clk and gated by ce_pix (the dot-clock enable) so DPYINT fires
  // ONCE PER FRAME at the DPYINT scan line -- matching real HW / MAME -- instead
  // of at the core clock (the fork-inherited bug: ~12x too fast, which derailed
  // NBA/UMK3 init before the RAM interrupt-dispatch table is built).
  // hcount/vcount are the LIVE counters and are returned on CPU reads of
  // HCOUNT/VCOUNT (see the rdata mux): NBA display_blank spins on VCOUNT
  // (BB.ASM #nxt: `move *VCOUNT,a0; jrz` waits for VCOUNT to leave 0) and hangs
  // forever if the read returns a dead/stored 0.
  // ---------------------------------------------------------------------------
  wire logic   dpyint_pulse;
  wire logic   dpyint_event;
  wire logic   video_line_advance;
  (* preserve *) logic dpyint_event_q;
  (* preserve *) logic wvp_set_q;
  (* preserve *) logic nmi_clear_q;
  // video_ready_q: REGISTERED copy of the HTOTAL/VTOTAL-programmed flag.
  // The combinational form launched a 13 ns full-rate cone (io_reg compare ->
  // video muxes -> gun overlay -> diag tap, signoff -1.1 ns at 97% LABs).
  // The flag is quasi-static (programmed once at boot), so one flop of
  // latency at the 0->1 transition is invisible; the launch becomes local.
  logic video_ready_q;
  logic [15:0] vid_hcount, vid_vcount;
  logic        vid_hs_unused, vid_vs_unused, vid_hb_unused, vid_vb_unused, vid_bl_unused;

  tms34010_video u_video (
    .clk         (clk),
    .rst         (rst),
    .timing_start(timing_start_o),
    .ce          (ce_pix),   // dot-clock enable: HCOUNT/dot, VCOUNT/line, DPYINT/frame
    .hesync      (io_reg[RX_HESYNC]),
    .heblnk      (io_reg[RX_HEBLNK]),
    .hsblnk      (io_reg[RX_HSBLNK]),
    .htotal      (io_reg[RX_HTOTAL]),
    .vesync      (io_reg[RX_VESYNC]),
    .veblnk      (io_reg[RX_VEBLNK]),
    .vsblnk      (io_reg[RX_VSBLNK]),
    .vtotal      (io_reg[RX_VTOTAL]),
    .dpyint      (io_reg[RX_DPYINT]),
    .hcount      (vid_hcount),
    .vcount      (vid_vcount),
    .hsync       (vid_hs_unused),
    .vsync       (vid_vs_unused),
    .hblank      (vid_hb_unused),
    .vblank      (vid_vb_unused),
    .blank       (vid_bl_unused),
    .dpyint_pulse(dpyint_pulse),
    .line_advance(video_line_advance),
    .vblank_start(vblank_start_o)
  );

  assign video_hcount_o = vid_hcount;
  assign video_vcount_o = vid_vcount;
  assign video_heblnk_o = io_reg[RX_HEBLNK];
  assign video_hsblnk_o = io_reg[RX_HSBLNK];
  assign video_veblnk_o = io_reg[RX_VEBLNK];
  assign video_vsblnk_o = io_reg[RX_VSBLNK];
  assign video_hs_o = vid_hs_unused;
  assign video_vs_o = vid_vs_unused;
  assign video_hb_o = vid_hb_unused;
  assign video_vb_o = vid_vb_unused;
  assign video_ready_o = video_ready_q;

  assign dpyint_event = dpyint_pulse &&
                        (io_reg[RX_VTOTAL] != 16'h0) &&
                        io_reg[RX_DPYCTL][15];

  // Async read: the selected register, or 0 when the address is not in
  // I/O space (so a non-I/O read contributes nothing to a merged read bus).
  // P0016: CPU reads of INTPEND see the live LINT1 pin mirrored into X1P.
  // The `=== 1'b1` makes an UNCONNECTED pin (legacy TBs: 'z) read as not
  // asserted in sim; synthesis treats it as plain equality.
  logic lint1_lvl, lint2_lvl;
  assign lint1_lvl = (lint1_in === 1'b1);
  // UG section 8.3: both external pending bits reflect the pin levels.
  // MAME 0.289 midxunit.cpp:300 connects DCS output-full to input line 1.
  assign lint2_lvl = (lint2_in === 1'b1);
  // HCOUNT/VCOUNT are READ-ONLY-ish counters on real silicon (1988 UG Fig 6-1;
  // memory_map.md marks them "read-only on silicon"): a CPU read returns the
  // LIVE horizontal/vertical counter, not the stored io_reg. NBA display_blank
  // spins on VCOUNT (BB.ASM #nxt) and MAME returns a live, sweeping VCOUNT; a
  // dead/stored 0 hangs the spin. Writes still fall through to io_reg[idx] (dead
  // storage for these two indices) -- harmless, and matches MAME, where the
  // stored write does not feed the computed read.
  assign rdata = !is_io ? 16'h0
               : (rd_idx == RX_VCOUNT)  ? vid_vcount
               : (rd_idx == RX_HCOUNT)  ? vid_hcount
               : (rd_idx == RX_INTPEND)
                 ? (io_reg[rd_idx] | (16'(lint1_lvl) << INT_X1_BIT) | (16'(lint2_lvl) << INT_X2_BIT))
                 : io_reg[rd_idx];

  // Small fixed mux over the three complete display pairs. This avoids a
  // general second I/O read port, shadow bypass, or variable-width barrel mux.
  always_comb begin
    display_pair_rdata = 32'd0;
    if (M020) begin
      case (raddr)
        32'hc0000200: display_pair_rdata = {io_reg[RX_DPYSTH],io_reg[RX_DPYSTL]};
        32'hc0000220: display_pair_rdata = {io_reg[RX_DPYNXH],io_reg[RX_DPYNXL]};
        32'hc0000240: display_pair_rdata = {io_reg[RX_DINCH],io_reg[RX_DINCL]};
        default: ;
      endcase
    end
  end

  // Dedicated graphics taps.
  assign psize_o   = io_reg[RX_PSIZE];
  assign convdp_o  = io_reg[RX_CONVDP];
  assign convsp_o  = io_reg[RX_CONVSP];
  assign control_o = io_reg[RX_CONTROL];
  assign pmask_o   = io_reg[RX_PMASK];
  assign intenb_o  = io_reg[RX_INTENB];
  assign dpyctl_o  = io_reg[RX_DPYCTL];
  assign dpystrt_o = io_reg[RX_DPYSTRT];
  assign dbg_dpyst_value_o = M020 ? {io_reg[RX_DPYSTH],io_reg[RX_DPYSTL]} : 32'd0;
  // Native I/O writes do not appear on the external memory bus. Qualify this
  // observation at the exact register-file commit seam; reset zeros alone are
  // not evidence. Once a complete pair has committed, all later partial writes
  // are reflected by the live value as well. No register/control is driven here.
  always_ff @(posedge clk) begin
    if (rst) dbg_dpyst_valid_o<=1'b0;
    else if (M020 && req && we && wr_is_io && wr_display_pair===1'b1 && addr==32'hc0000200)
      dbg_dpyst_valid_o<=1'b1;
  end
  assign dpytap_o  = io_reg[RX_DPYTAP];
  assign dpyadr_o  = io_reg[RX_DPYADR];
  assign display_enable_o = io_reg[RX_DPYCTL][15];
  assign display_blank_o  = (io_reg[RX_HEBLNK] >= io_reg[RX_HSBLNK]);

  // MAME 0.289 tms34010.cpp:get_display_params(), which follows the 34010
  // display-address hardware: origin inversion is applied before both the row
  // and column fields are derived.  T-unit scanout later doubles coladdr
  // because each 34010 video clock emits two physical pixels.
  logic [15:0] display_dpyadr;
  assign display_dpyadr = io_reg[RX_DPYCTL][10]
                         ? io_reg[RX_DPYADR]
                         : (io_reg[RX_DPYADR] ^ 16'hfffc);
  // '010 derives row/col/yoffset from DPYADR/DPYTAP/DPYSTRT; the '020 derives
  // them from DPYNX (DELTA (c); tms34010.cpp:1157-1165). IS_34020 is a compile
  // constant so the '010 selects its branch and stays byte-identical.
  assign display_row_o = M020 ? io_reg[RX_DPYNXH]
                                  : (display_dpyadr >> 4);
  assign display_col_o = M020 ? (io_reg[RX_DPYNXL] & 16'hffe0)
                                  : (((display_dpyadr & 16'h007c) << 4) |
                                     (io_reg[RX_DPYTAP] & 16'h3fff));
  // A020-6: the '020 zoom yoffset = (DPYNXL&0x1f)/(DINCL&0x1f) needs a runtime
  // divide and only sub-positions the video sub-row (not CPU-visible, not
  // boot/gate-critical); deferred to 0 here. rowaddr/coladdr are exact.
  assign display_yoffset_o = M020 ? 2'd0
                                      : ((io_reg[RX_DPYSTRT] -
                                          io_reg[RX_DPYADR]) & 16'h0003);
  // P0016: X1P mirrors the LINT1 pin level into the pending view.
  assign intpend_o = io_reg[RX_INTPEND] | (16'(lint1_lvl) << INT_X1_BIT) | (16'(lint2_lvl) << INT_X2_BIT);
  assign hstctlh_o = io_reg[RX_HSTCTLH];

  // '020 DPYNX/DINC visible-area advance (DELTA (c); tms34010.cpp:1116-1122).
  // dpynx keeps its high bits, steps the low 5 by dinc, and on a low-5 wrap
  // advances the high part by dinc's high bits (zoom-capable). Computed always
  // (indices clamp to 0 on the '010) but only committed under IS_34020.
  logic [31:0] dpynx_cur, dinc_cur, dpynx_step, dpynx_next;
  assign dpynx_cur  = {io_reg[RX_DPYNXH], io_reg[RX_DPYNXL]};
  assign dinc_cur   = {io_reg[RX_DINCH],  io_reg[RX_DINCL]};
  assign dpynx_step = (dpynx_cur & 32'hffffffe0) | ((dpynx_cur + dinc_cur) & 32'h0000001f);
  assign dpynx_next = ((dpynx_step & 32'h0000001f) == 32'h0)
                    ? (dpynx_step + (dinc_cur & 32'hffffffe0))
                    : dpynx_step;

  // Synchronous write + reset. The reset loop is bounded (32 iterations) and
  // fully unrollable, so synthesis treats it as parallel resets.
  always_ff @(posedge clk) begin
    if (rst) begin
      for (int i = 0; i < IO_N; i++) begin
        io_reg[i] <= 16'h0;
      end
      dpyint_event_q <= 1'b0;
      wvp_set_q      <= 1'b0;
      nmi_clear_q    <= 1'b0;
      video_ready_q  <= 1'b0;
    end else begin
      // Local one-cycle history exactly spans the registered CPU-write
      // boundary without creating a full-rate I/O/raster path into the CPU
      // collection. E-1 actions expire by E1; E0 actions are q at E1.
      dpyint_event_q <= dpyint_event;
      wvp_set_q      <= (wvp_set === 1'b1);
      nmi_clear_q    <= (nmi_clear === 1'b1);
      video_ready_q  <= (io_reg[RX_HTOTAL] != 0) && (io_reg[RX_VTOTAL] != 0);

      if (req && we && wr_is_io) begin
        if (wr_idx == RX_INTPEND) begin
`ifdef MUT_IO_INTPEND_WHOLE_WRITE
          io_reg[wr_idx] <= wr_merged;
`else
          io_reg[wr_idx] <= intpend_apply_cpu_write(io_reg[wr_idx],wr_merged);
`endif
        end else begin
          io_reg[wr_idx] <= wr_merged;
        end
        // Only plain display registers can take this adjacent write. The
        // existing first-half field/W0C/control-alias path remains unchanged.
        if (M020 && (wr_display_pair === 1'b1)) begin
          case (addr)
            32'hc0000200: io_reg[RX_DPYSTH] <= wr_display_hi;
            32'hc0000220: io_reg[RX_DPYNXH] <= wr_display_hi;
            32'hc0000240: io_reg[RX_DINCH] <= wr_display_hi;
            default: ;
          endcase
        end
      end
      // '020: a write to CONTROL (11) or CONTROL2 (25) updates BOTH registers
      // (tms34010.cpp:1407-1413). Same value, so the double-write to wr_idx is a
      // harmless no-op; the sibling register gets the alias. Gated on IS_34020
      // (compile constant) so the '010 is byte-identical.
      if (M020 && req && we && wr_is_io &&
          ((wr_idx == RX_CONTROL) || (wr_idx == RX_CONTROL2))) begin
        io_reg[RX_CONTROL]  <= wr_merged;
        io_reg[RX_CONTROL2] <= wr_merged;
      end
`ifdef MUT_IO_EVENT_GAP
      else if (nmi_clear) begin
        // The device automatically clears HSTCTLH.NMI when it takes the NMI
        // (1988 UG §8). A normal I/O write takes precedence (the else-if order):
        // simultaneous host write + take is a don't-care corner.
        io_reg[RX_HSTCTLH][HSTCTL_NMI_BIT] <= 1'b0;
      end else if (wvp_set) begin
        // The graphics engine sets INTPEND.WV on a window violation (1988 UG
        // §7.10). Like nmi_clear, this is a device-internal set, lower priority
        // than a host/program I/O write.
        io_reg[RX_INTPEND][INT_WV_BIT] <= 1'b1;
      end
`else
      // Consume carried E0 actions only with an actual command emitted by the
      // registered boundary. This distinguishes a new same-bit event from an
      // old pending bit without feeding live I/O state back into CPU timing.
      if (req && we && wr_is_io && (status_guard === 1'b1)) begin
        if (wr_idx == RX_INTPEND) begin
          if (wvp_set_q)
            io_reg[RX_INTPEND][INT_WV_BIT] <= 1'b1;
          if (dpyint_event_q)
            io_reg[RX_INTPEND][INT_DI_BIT] <= 1'b1;
        end
        if ((wr_idx == RX_HSTCTLH) && nmi_clear_q)
          io_reg[RX_HSTCTLH][HSTCTL_NMI_BIT] <= 1'b0;
      end

      // Device actions are newer than the CPU transaction, which retired one
      // sysclk earlier, so current-edge actions win at physical commit.
      if (nmi_clear === 1'b1)
        io_reg[RX_HSTCTLH][HSTCTL_NMI_BIT] <= 1'b0;
      if (wvp_set === 1'b1)
        io_reg[RX_INTPEND][INT_WV_BIT] <= 1'b1;
`endif
      // Display interrupt (P0012): when DPYCTL.ENV (bit 15) is enabled, set
      // INTPEND.DI at HSBLNK on the DPYINT line. ENV gates only this SET event;
      // disabling it neither clears an already-pending DI nor stops the raster.
      // Independent of the else-if chain above so a coincident I/O write to a
      // DIFFERENT register cannot drop the frame's DI. A same-cycle write to
      // INTPEND itself: this bit-select assign wins for bit DI (set-dominant),
      // matching the device-sets / software-clears model (the handler clears DI
      // by writing INTPEND). dpyint_pulse is a ce-gated one-clock strobe (once
      // per frame), so it never fights RETI.
      // Gate on a programmed raster (VTOTAL != 0) so the reset state (all timing
      // regs 0 -> pulse whenever ce fires) doesn't spam INTPEND.DI before the
      // game sets up video. Harmless while IE=0, but keep it clean.
`ifndef MUT_REVX_DI_NOSET
      if (dpyint_event) begin
        io_reg[RX_INTPEND][INT_DI_BIT] <= 1'b1;
      end
`else
      // MUTANT (tb_revx_disp_int): never set INTPEND.DI. Misreads the gospel
      // (scanline_callback -> internal_interrupt_callback(TMS34010_DI), :851) so
      // the display interrupt can never fire -> the DI gate MUST fail (a)/(b)/(c).
      if (1'b0) io_reg[RX_INTPEND][INT_DI_BIT] <= 1'b1;
`endif

      // TMS34020 SETCDP: load the MAME-computed CONVDP when the core pulses
      // setcdp_we (one cycle at SETCDP retire). Inert on the '010 (tied 0).
      // No concurrent CONVDP CPU write happens during a SETCDP, so this is the
      // sole writer that cycle.
      if (setcdp_we === 1'b1) begin   // === so an unconnected port (z) is inert
        io_reg[RX_CONVDP] <= setcdp_convdp;
      end

      // MAME 0.289 tms34010.cpp display-address update path. At VSBLNK the
      // device reloads DPYADR from DPYSTRT. On each visible scanline it first
      // walks the
      // two-bit Y subrow down to zero, then subtracts DPYCTL.DUDATE while
      // restoring DPYSTRT's subrow.  A CPU write to DPYADR on this physical
      // edge is newest and therefore wins over the automatic action.
      if (!M020) begin
        // ---- 34010 DPYADR update (DPYADR/DPYSTRT/DPYCTL.DUDATE) -------------
        if (!(req && we && wr_is_io && (wr_idx == RX_DPYADR))) begin
          if (vblank_start_o) begin
            io_reg[RX_DPYADR] <= io_reg[RX_DPYSTRT];
          end else if (video_line_advance &&
                       (vid_vcount >= io_reg[RX_VEBLNK]) &&
                       (vid_vcount <  io_reg[RX_VSBLNK])) begin
            if (io_reg[RX_DPYADR][1:0] == 2'b00) begin
`ifdef MUT_DPYADR_NO_DUDATE
              // Discriminating mutation: hold at the subrow boundary instead of
              // advancing to the next display row.
              io_reg[RX_DPYADR] <= io_reg[RX_DPYADR];
`else
              io_reg[RX_DPYADR] <=
                ((io_reg[RX_DPYADR] & 16'hfffc) -
                 (io_reg[RX_DPYCTL] & 16'h03fc)) |
                (io_reg[RX_DPYSTRT] & 16'h0003);
`endif
            end else begin
              io_reg[RX_DPYADR] <=
                (io_reg[RX_DPYADR] & 16'hfffc) |
                ((io_reg[RX_DPYADR] - 16'd1) & 16'h0003);
            end
          end
        end
      end else begin
        // ---- 34020 DPYNX/DINC update (DELTA (c); tms34010.cpp:1030-1045,
        // 1116-1122). At VSBLNK reload DPYNX from DPYST; on each visible line
        // step DPYNX by DINC. A CPU write to DPYNXL/DPYNXH this edge wins.
        if (!(req && we && wr_is_io &&
              ((wr_idx == RX_DPYNXL) || (wr_idx == RX_DPYNXH)))) begin
          if (vblank_start_o) begin
            io_reg[RX_DPYNXL] <= io_reg[RX_DPYSTL] & 16'hffe0;
            io_reg[RX_DPYNXH] <= io_reg[RX_DPYSTH];
          end else if (video_line_advance &&
                       (vid_vcount >= io_reg[RX_VEBLNK]) &&
                       (vid_vcount <  io_reg[RX_VSBLNK])) begin
`ifdef MUT_DPYADR_NO_DUDATE
            io_reg[RX_DPYNXL] <= io_reg[RX_DPYNXL];
            io_reg[RX_DPYNXH] <= io_reg[RX_DPYNXH];
`else
            io_reg[RX_DPYNXL] <= dpynx_next[15:0];
            io_reg[RX_DPYNXH] <= dpynx_next[31:16];
`endif
          end
        end
      end
    end
  end

endmodule : tms34010_io_regs

`default_nettype wire
