// -----------------------------------------------------------------------------
// tms34010_blmove.sv
//
// TMS34020 BLMOVE S,D block-move engine (DELTA (f); MAME 0.289 34010ops.hxx:
// 2047-2093, tms34020_device::blmove). Copies B7 (bits) bits from B0 (src) to
// B2 (dst): a 16-bit-word loop, then a single field-move tail of the remaining
// <16 bits, exactly as MAME's WRMEM_WORD(RDMEM_WORD) loop + wfield[bits]
// (rfield[bits]) tail. Final B0=src_end, B2=dst_end, B7=0.
//
// RESUME NOTE: MAME slices the move across execute_run timeslices (m_icount)
// and backs up the PC by 0x10 when interrupted mid-move; that PC-backup is a
// pure timeslice ARTIFACT -- the completed B0/B2/B7 + memory are identical
// whether sliced or atomic. This engine, like the ported LINE datapath
// (tms34010_core LINE: "executes the whole line in one FSM visit"), completes
// the move in one visit, so B7 is always 0 at done and no PC-backup is needed.
//
// ALIGNMENT-ERROR CONDITION (MAME logerror :2056-2058): asserted when
// (S==0 && src[3:0]!=0) || (D==0 && dst[3:0]!=0). It is a diagnostic flag only
// -- no behavioural effect (MAME just logs) -- surfaced on `align_err_o`.
//
// Memory: the same field interface the core presents to the board
// (bit-addr + size + right-justified data, req held until ack). Loop accesses
// are 16-bit (WRMEM/RDMEM_WORD); the tail is a `bits`-wide field access.
// -----------------------------------------------------------------------------

`default_nettype none
module tms34010_blmove
  import tms34010_pkg::*;
(
  input  wire logic                    clk,
  input  wire logic                    rst,
  // Clock-enable (P0019 idiom, matches tms34010_core). When this engine is
  // instantiated INSIDE the core it is tied to ce_cpu so it advances in exact
  // lockstep with the core FSM (both guard `if ((ce !== 1'b0) || rst)`). The
  // standalone gate (tb_020_blmove) leaves this port UNCONNECTED -> reads 'z ->
  // (ce !== 1'b0) is true -> free-runs exactly as before (gate unchanged).
  input  wire logic                    ce,

  input  wire logic                    start,     // one-cycle launch pulse
  input  wire logic                    s_bit,     // op[1]
  input  wire logic                    d_bit,     // op[0]
  input  wire logic [ADDR_WIDTH-1:0]   src_in,    // B0
  input  wire logic [ADDR_WIDTH-1:0]   dst_in,    // B2
  input  wire logic [ADDR_WIDTH-1:0]   bits_in,   // B7

  output logic [ADDR_WIDTH-1:0]        b0_o,      // final src
  output logic [ADDR_WIDTH-1:0]        b2_o,      // final dst
  output logic [ADDR_WIDTH-1:0]        b7_o,      // final bits (0 when complete)
  output logic                         align_err_o,
  output logic                         busy_o,
  output logic                         done_o,    // one-cycle completion pulse

  // field memory interface (same contract as sim_memory_model / the core)
  output logic                         mem_req,
  output logic                         mem_we,
  output logic [ADDR_WIDTH-1:0]        mem_addr,
  output logic [FIELD_SIZE_WIDTH-1:0]  mem_size,
  output logic [DATA_WIDTH-1:0]        mem_wdata,
  input  wire logic [DATA_WIDTH-1:0]   mem_rdata,
  input  wire logic                    mem_ack,

`ifdef REVX_BLMOVE_BURST
  // BURST chunk ports (REVX_BLMOVE_BURST). The 16-bit-word loop above issues two
  // single-beat accesses per word; the game's load phase does 1661 ROM->RAM
  // BLMOVEs (measured from the MAME gospel trace: src ROM 1661, dst RAM 1659),
  // each word a read+write pair through the field bus. When BOTH ends are
  // chunk-eligible (burst_ok_in, asserted by the board wrapper for the RAM/ROM
  // regions), >=16 words remain, and both ends are SDRAM-word aligned, the move
  // streams 16-word read-chunks into 16-word write-chunks instead -- the same
  // burst machinery the fetch line-buffer and SRT chunk already use.
  //
  // TIMING CLASS (the 5-question pass): these are CE-domain ports; the burst
  // FSM states advance on ce like the scalar loop. No full-rate cone is added;
  // the only new combinational inputs are the engine's own src_q/dst_q feeds to
  // the board wrapper's region decode (burst_ok_in), which is CE-sampled here.
  //
  // SEMANTICS (gospel): byte-identity with the scalar loop by construction --
  // the chunk reads the SAME ascending 16 words the loop would read and writes
  // them in the SAME ascending order. The architectural cycle budget
  // (instruction_cycles in the core) is UNCHANGED: the burst path keeps the
  // same per-word accounting, so the gospel's BLMOVE cycle count is preserved
  // while the wall-clock shrinks. Final B0/B2/B7 are identical (src += bits,
  // dst += bits, bits = 0).
  output logic                         brb_req,
  output logic [ADDR_WIDTH-1:0]        brb_addr,   // raw bit address of chunk start
  output logic [4:0]                   brb_count,  // words (16; held for the top)
  input  wire logic [255:0]            brb_dout,   // packed ascending 16 words
  input  wire logic                    brb_ack,
  output logic                         bwb_req,
  output logic [ADDR_WIDTH-1:0]        bwb_addr,
  output logic [4:0]                   bwb_count,
  output logic [255:0]                 bwb_data,
  input  wire logic                    bwb_ack,
  input  wire logic                    burst_ok_in // board decode: both ends RAM/ROM
`endif
);

  typedef enum logic [3:0] {
    B_IDLE, B_RD, B_WR, B_TRD, B_TWR, B_DONE
`ifdef REVX_BLMOVE_BURST
    , B_BCR, B_BCW, B_SELECT
`endif
  } bst_t;
  bst_t st_q, st_d;

  logic [ADDR_WIDTH-1:0] src_q, dst_q, bits_q;
  logic [DATA_WIDTH-1:0] word_q;
  logic                  align_q;
`ifdef REVX_BLMOVE_BURST
  logic [255:0]          chunk_q;
  // Re-evaluate AFTER the previous word/chunk advances the addresses. A burst
  // cannot cross either 512-word physical row. Forward overlapping copies with
  // a distance below one chunk must retain read-word/write-word ordering (MAME
  // 34010ops.hxx BLMOVE); pre-reading the chunk would change the result.
  wire [ADDR_WIDTH-1:0] burst_distance = dst_q - src_q;
  wire burst_safe = burst_ok_in && bits_q >= ADDR_WIDTH'(256) &&
      src_q[3:0] == 0 && dst_q[3:0] == 0 &&
      src_q[12:4] <= 9'd496 && dst_q[12:4] <= 9'd496 &&
      !(dst_q > src_q && burst_distance < ADDR_WIDTH'(256));
`endif

  wire [FIELD_SIZE_WIDTH-1:0] tail_sz = bits_q[FIELD_SIZE_WIDTH-1:0];  // <16 at TRD
`ifdef MUT_BLMOVE_NO_TAIL
  // MUTANT: never do the <16-bit tail field move -> a move whose bit count is
  // not a multiple of 16 truncates. MUST be killed by the tail cases.
  localparam bit TAIL_EN = 1'b0;
`else
  localparam bit TAIL_EN = 1'b1;
`endif
`ifdef REVX_BLMOVE_BURST
`ifdef MUT_BLMOVE_BURST_REVERSE
  // MUTANT: reverse the chunk's word order on the write side -> the copy is
  // byte-permuted. MUST be killed by the burst byte-identity checks.
  localparam bit BURST_ASCEND = 1'b0;
`else
  localparam bit BURST_ASCEND = 1'b1;
`endif
`endif

  always_comb begin
    st_d      = st_q;
    mem_req   = 1'b0;
    mem_we    = 1'b0;
    mem_addr  = '0;
    mem_size  = '0;
    mem_wdata = '0;
`ifdef REVX_BLMOVE_BURST
    brb_req   = 1'b0;
    brb_addr  = src_q;
    brb_count = '0;
    bwb_req   = 1'b0;
    bwb_addr  = dst_q;
    bwb_count = '0;
    bwb_data  = '0;
`endif

    unique case (st_q)
      B_IDLE:  if (start) st_d = (bits_in >= ADDR_WIDTH'(16)) ? (
`ifdef REVX_BLMOVE_BURST
                  B_SELECT
`else
                  B_RD
`endif
                  )
                               : (TAIL_EN && (bits_in != '0)) ? B_TRD : B_DONE;
      B_RD: begin
        mem_req  = 1'b1; mem_we = 1'b0; mem_addr = src_q; mem_size = FIELD_SIZE_WIDTH'(16);
        if (mem_ack) st_d = B_WR;
      end
      B_WR: begin
        mem_req  = 1'b1; mem_we = 1'b1; mem_addr = dst_q; mem_size = FIELD_SIZE_WIDTH'(16);
        mem_wdata = word_q;
        if (mem_ack) begin
          // decision uses the POST-decrement bits (bits_q-16)
`ifdef REVX_BLMOVE_BURST
          if ((bits_q - ADDR_WIDTH'(16)) >= ADDR_WIDTH'(16)) st_d = B_SELECT;
          else
`endif
          if ((bits_q - ADDR_WIDTH'(16)) >= ADDR_WIDTH'(16))       st_d = B_RD;
          else if (TAIL_EN && ((bits_q - ADDR_WIDTH'(16)) != '0))  st_d = B_TRD;
          else                                                     st_d = B_DONE;
        end
      end
`ifdef REVX_BLMOVE_BURST
      B_SELECT: st_d = burst_safe ? B_BCR : B_RD;
      B_BCR: begin
        brb_req = 1'b1; brb_addr = src_q; brb_count = 5'd16;
        if (brb_ack) st_d = B_BCW;
      end
      B_BCW: begin
        bwb_req = 1'b1; bwb_addr = dst_q; bwb_count = 5'd16;
        bwb_data = BURST_ASCEND ? chunk_q : {chunk_q[15:0],  chunk_q[31:16],
                                             chunk_q[47:32], chunk_q[63:48],
                                             chunk_q[79:64], chunk_q[95:80],
                                             chunk_q[111:96],chunk_q[127:112],
                                             chunk_q[143:128],chunk_q[159:144],
                                             chunk_q[175:160],chunk_q[191:176],
                                             chunk_q[207:192],chunk_q[223:208],
                                             chunk_q[239:224],chunk_q[255:240]};
        if (bwb_ack) begin
          if ((bits_q - ADDR_WIDTH'(256)) >= ADDR_WIDTH'(16)) st_d = B_SELECT;
          else if (TAIL_EN && ((bits_q - ADDR_WIDTH'(256)) != '0))  st_d = B_TRD;
          else                                                      st_d = B_DONE;
        end
      end
`endif
      B_TRD: begin
        mem_req  = 1'b1; mem_we = 1'b0; mem_addr = src_q; mem_size = tail_sz;
        if (mem_ack) st_d = B_TWR;
      end
      B_TWR: begin
        mem_req  = 1'b1; mem_we = 1'b1; mem_addr = dst_q; mem_size = tail_sz;
        mem_wdata = word_q;
        if (mem_ack) st_d = B_DONE;
      end
      B_DONE: st_d = B_IDLE;
      default: st_d = B_IDLE;
    endcase
  end

  always_ff @(posedge clk) if ((ce !== 1'b0) || rst) begin
    if (rst) begin
      st_q    <= B_IDLE;
      src_q   <= '0; dst_q <= '0; bits_q <= '0; word_q <= '0; align_q <= 1'b0;
      done_o  <= 1'b0;
    end else begin
      done_o <= 1'b0;
      if (st_q == B_IDLE && start) begin
        src_q  <= src_in;
        dst_q  <= dst_in;
        bits_q <= bits_in;
`ifdef MUT_BLMOVE_ALIGN
        // MUTANT: never flag an alignment error -> the alignment case fails.
        align_q <= 1'b0;
`else
        align_q <= (!s_bit && (src_in[3:0] != 4'h0)) ||
                   (!d_bit && (dst_in[3:0] != 4'h0));
`endif
      end
      if (st_q == B_RD && mem_ack)  word_q <= mem_rdata;
      if (st_q == B_TRD && mem_ack) word_q <= mem_rdata;
`ifdef REVX_BLMOVE_BURST
      if (st_q == B_BCR && brb_ack) chunk_q <= brb_dout;
      if (st_q == B_BCW && bwb_ack) begin
        src_q  <= src_q  + ADDR_WIDTH'(256);
        dst_q  <= dst_q  + ADDR_WIDTH'(256);
        bits_q <= bits_q - ADDR_WIDTH'(256);
      end
`endif
      if (st_q == B_WR && mem_ack) begin
        src_q  <= src_q  + ADDR_WIDTH'(16);
        dst_q  <= dst_q  + ADDR_WIDTH'(16);
        bits_q <= bits_q - ADDR_WIDTH'(16);
      end
      if (st_q == B_TWR && mem_ack) begin
        src_q  <= src_q  + {26'd0, tail_sz};
        dst_q  <= dst_q  + {26'd0, tail_sz};
        bits_q <= '0;
      end
      if (st_q == B_DONE) done_o <= 1'b1;
      st_q <= st_d;
    end
  end

  assign b0_o        = src_q;
  assign b2_o        = dst_q;
  assign b7_o        = bits_q;
  assign align_err_o = align_q;
  assign busy_o      = (st_q != B_IDLE);

endmodule
`default_nettype wire
