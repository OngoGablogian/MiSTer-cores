// -----------------------------------------------------------------------------
// tms34010_mem_if.sv
//
// TMS34020-DELTA step 1 (this task): the '020 MEMORY INTERFACE that turns the
// field-oriented command the CPU core issues (bit-address + field-size +
// right-justified data -- exactly the interface sim_memory_model implements for
// the '010) into 32-bit-WORD + byte-enable bus transactions, as MAME 0.289's
// tms34020_device WORD/DWORD memory primitives realize them
// (tms34010.cpp:300-344; docs/TMS34020-DELTA.md (a)).
//
// WHY A SEPARATE MODULE (not new ports on tms34010_core):
//   The kickoff contract (HANDOFF "CPU<->memory contract") and DELTA (g).5 say
//   the '020 lane-mask may be "produced either in the core or the wrapper
//   adapter". Editing the 4296-line core to word-align mem_addr / lane-rotate
//   mem_wdata / reassemble mem_rdata would touch the I/O-decode, io_rdata
//   snapshot and ~200 mem_* consumers -- all risk to the byte-identical
//   IS_34020=0 suite (DESIGN-RULES.md s.8) for zero behavioural gain. So the core is
//   left byte-identical and the '020 bus width lives HERE, the single MAME
//   place it lives (DELTA (a): "byte-lane derivation is contained in the memory
//   interface, not the field state machine"). The board lane instantiates
//   core + this adapter; the '010 suite wires the core straight to the field
//   board and never sees this module.
//
// CONTRACT presented to the 32-bit-word board (per HANDOFF): a little-endian
// 32-bit word selected by bus_addr[31:5]; bus_be[3:0] byte enables; a write
// commits the be-marked bytes of bus_wdata; a read returns the full 32-bit
// word. Same req-held-until-ack / one-cycle-ack protocol as sim_memory_model.
//
// FIELD -> WORD/be mapping (general, all sizes 1..32 at any bit address):
//   A field of `size` bits at bit address A occupies bits [A, A+size-1] of the
//   flat little-endian bitstream, i.e. bits [boff, boff+size-1] of the 64-bit
//   window {word1, word0} where word0 = A & ~0x1F (bus bit-addr), boff = A[4:0],
//   word1 = word0 + 0x20. size<=32 and boff<=31 => the field spans at most two
//   32-bit words (boff+size <= 63). This is the 32-bit-word generalization of
//   MAME's read_dword_unaligned / write_dword-with-mem_mask (:311-344).
//     READ  : read word0 (+word1 if straddling), extract the field
//             right-justified, zero-extended -- the core applies FE sign/zero
//             extension on top (same as sim_memory_model).
//     WRITE : read-modify-write. Merge the field bits over the read-back
//             word(s); be marks every byte the field touches; bytes fully
//             covered by the field skip the read (a direct be write, matching
//             MAME's non-RMW write_dword for whole half-words :321-344).
//
// The Step-1 leaf tms34010_mem_be.sv is INSTANTIATED here (op_dword = size>16):
// it supplies the word addresses word0/word1 that go on bus_addr and the
// WORD/DWORD lane byte-enables for the aligned fast paths, and stands as the
// independent second encoding of MAME's lane rule that the gate cross-checks
// against this module's general byte-mask (DESIGN-RULES.md s.5).
//
// This adapter is '020-only. On P_IS_34020=0 it degenerates to a single
// pass-through transaction (be = the field's byte span) for elaboration; the
// '010 core never uses it.
// -----------------------------------------------------------------------------

`default_nettype none
module tms34010_mem_if
  import tms34010_pkg::*;
#(
  parameter bit P_IS_34020 = IS_34020
) (
  input  wire logic                          clk,
  input  wire logic                          rst,
  // Completion is held until this CPU enable consumes it. Omitted legacy
  // testbench ports retain full-rate behavior, matching the core's CE rule.
  input  wire logic                          ce_cpu,

  // ---- CPU core side (field-oriented; identical to sim_memory_model) --------
  input  wire logic                          core_req,
  input  wire logic                          core_we,
  input  wire logic [ADDR_WIDTH-1:0]         core_addr,   // field BIT address
  input  wire logic [FIELD_SIZE_WIDTH-1:0]   core_size,   // 1..32 bits
  input  wire logic [DATA_WIDTH-1:0]         core_wdata,  // right-justified
  input  wire logic                          core_srt,    // SRT pixel op qualifier
  input  wire logic                          core_fetch,  // PERF: instruction-stream read qualifier
  output logic [DATA_WIDTH-1:0]              core_rdata,  // right-justified
  output logic                               core_ack,

  // ---- 32-bit-word + byte-enable board side --------------------------------
  output logic                               bus_req,
  output logic                               bus_we,
  output logic [ADDR_WIDTH-1:0]              bus_addr,    // word bit-addr (b[31:5])
  output logic [3:0]                         bus_be,
  output logic [DATA_WIDTH-1:0]              bus_wdata,
  output logic                               bus_srt,
  // PERF: 1 while the current bus access is an instruction-stream read.  Valid
  // for the whole access (latched at launch with a_q/sz_q); the board memory
  // system samples it while bus_req is asserted.
  output logic                               bus_fetch,
  input  wire logic [DATA_WIDTH-1:0]         bus_rdata,
  input  wire logic                          bus_ack
);

  // ---- request capture ------------------------------------------------------
  logic [ADDR_WIDTH-1:0]        a_q;
  logic [FIELD_SIZE_WIDTH-1:0]  sz_q;
  logic                         we_q;
  logic                         f_q;        // PERF: launched access is an instruction fetch
  // Valid for the whole access: latched at launch, held until the next launch.
  assign bus_fetch = f_q;
  logic                         srt_q;
  logic [DATA_WIDTH-1:0]        wd_q;

  // ---- read-side geometry (combinational from the latched request) ----------
  // The RESPONSE path stays full-rate and shallow: only boff + size_mask are
  // needed to extract the field right-justified from the fetched 64-bit window.
  logic [4:0]  boff;
  logic [63:0] size_mask;
  assign boff      = a_q[4:0];
  assign size_mask = (sz_q == 6'd0) ? 64'd0 : ((64'd1 << sz_q) - 64'd1);

  // ---- launch-side geometry (combinational from the CORE command inputs) ----
  // Everything the WORD/be bus beats need is derived here from core_addr/
  // core_size/core_wdata -- driven by CE-member core registers -- and REGISTERED
  // into the p_* launch destinations on the cpu_ce launch edge (revx.sdc:
  // -from CE core -to these launch regs, setup 4/hold 3). The bus FSM then only
  // SELECTS a precomputed register by state, so bus_addr/bus_be/bus_wdata launch
  // from a launch register through ~2 logic levels -- NOT the chained 64-bit
  // barrel shifts (1<<size, <<boff) + byte-lane merge this cone used to place on
  // the a_q/sz_q/wd_q -> bus full-rate path. Semantics are bit-identical to the
  // previous transcription (MAME tms34010.cpp:321-344); only STA sees the extra
  // clocks. Names mirror the retired a_q-based signals (n_ = "next command").
  logic [ADDR_WIDTH-1:0] n_word0, n_word1;
  logic [4:0]            n_boff;
  logic [6:0]            n_span;          // boff + size, up to 63
  logic                  n_straddle;
  logic [63:0]           n_size_mask, n_fieldmask, n_wdata_sh;
  logic [3:0]            n_be0, n_be1;    // byte enables per word
  logic [63:0]           n_be_full;       // be expanded to full bytes (0x00/0xFF)
  logic                  n_rmw;

  assign n_boff      = core_addr[4:0];
  assign n_word0     = core_addr & ~(ADDR_WIDTH'('h1F));
  assign n_word1     = n_word0 + ADDR_WIDTH'('h20);
  assign n_span      = {2'b0, n_boff} + {1'b0, core_size};
`ifdef MUT_MEMIF_NO_STRADDLE
  // MUTANT: pretend nothing ever crosses a 32-bit word boundary. The second
  // word is never read/written, so a 32-bit field at bit4=1 (or any field
  // crossing a word boundary) loses its upper part. MUST be killed by the
  // straddle read/write cases in the gate.
  assign n_straddle  = 1'b0;
`else
  assign n_straddle  = (n_span > 7'd32);
`endif
  assign n_size_mask = (core_size == 6'd0) ? 64'd0 : ((64'd1 << core_size) - 64'd1);
  assign n_fieldmask = n_size_mask << n_boff;
  // 34020 aligned word/dword writes drive the complete source register even
  // on disabled lanes (MAME TMS34010_WRMEM_WORD/DWORD). At bit offset 16 the
  // halves rotate; a straddling dword presents that same payload on both beats.
  // X-unit DMA consumes the disabled upper lanes of its 16-bit config store.
  // Other fields retain their masked shift, including partial-byte RMW.
  assign n_wdata_sh  = (P_IS_34020 && core_addr[3:0] == 4'd0 &&
                       (core_size == 6'd16 || core_size == 6'd32)) ?
                      (n_boff[4] ? {2{core_wdata[15:0], core_wdata[31:16]}} :
                                   {32'd0, core_wdata}) :
                      (({32'd0, core_wdata} << n_boff) & n_fieldmask);

  // per-byte enables: byte k is enabled if any field bit lands in it
  always_comb begin
    integer k;
    n_be0 = 4'b0000; n_be1 = 4'b0000;
    for (k = 0; k < 4; k = k + 1) begin
      if (|n_fieldmask[8*k   +: 8]) n_be0[k] = 1'b1;
      if (|n_fieldmask[32+8*k +: 8]) n_be1[k] = 1'b1;
    end
  end
  // be expanded back to whole bytes; equals fieldmask iff the field fills only
  // complete bytes (=> no read-modify-write needed on a write).
  always_comb begin
    integer k;
    n_be_full = 64'd0;
    for (k = 0; k < 4; k = k + 1) begin
      if (n_be0[k]) n_be_full[8*k    +: 8] = 8'hFF;
      if (n_be1[k]) n_be_full[32+8*k  +: 8] = 8'hFF;
    end
  end
  assign n_rmw = (n_be_full != n_fieldmask);

  // ---- precomputed per-beat bus fields (CE launch DESTINATIONS) -------------
  // Captured on the same cpu_ce launch edge as a_q/sz_q/wd_q; read by the FSM
  // one or more cycles later. p_wsh* retain disabled-lane data for aligned
  // 34020 word/dword stores; other fields remain masked. p_nmask* clear RMW bits.
  logic [ADDR_WIDTH-1:0] p_addr0, p_addr1;   // word0 / word1 bus bit-addresses
  logic [3:0]            p_be0, p_be1;        // per-word byte enables
  logic [31:0]           p_wsh0, p_wsh1;      // per-beat write payload
  logic [31:0]           p_nmask0, p_nmask1;  // ~fieldmask halves (RMW clear mask)
  logic                  p_rmw, p_straddle;

  // ---- Step-1 leaf: word addresses + WORD/DWORD lane be (integration) -------
  // op_dword = size>16 (WORD primitive for <=16, DWORD for 17..32), matching
  // MAME's RFIELDMAC/WFIELDMAC width branch (34010ops.h:36-129).
  logic                  leaf_t0_valid, leaf_t1_valid;
  logic [ADDR_WIDTH-1:0] leaf_t0_addr, leaf_t1_addr;
  logic [3:0]            leaf_t0_be, leaf_t1_be;
  logic [31:0]           leaf_t0_wd, leaf_t1_wd, leaf_rdata;
  tms34010_mem_be #(.P_IS_34020(1'b1)) u_leaf (
    .a_bitaddr(a_q),
    .op_dword (sz_q > 6'd16),
    .wdata    (wd_q),
    .r0_word  (32'h0), .r1_word(32'h0),
    .t0_valid (leaf_t0_valid), .t0_addr32(leaf_t0_addr), .t0_be(leaf_t0_be), .t0_wdata(leaf_t0_wd),
    .t1_valid (leaf_t1_valid), .t1_addr32(leaf_t1_addr), .t1_be(leaf_t1_be), .t1_wdata(leaf_t1_wd),
    .rdata    (leaf_rdata)
  );

  // ---- read-back capture + field extraction --------------------------------
  // Full-rate + shallow: fetched word(s) -> shift by boff -> mask to core_rdata.
  // The RMW write merge (win & ~fieldmask | wdata_sh) is now formed per-beat in
  // the FSM from the precomputed p_nmask*/p_wsh* registers, so fieldmask/wdata_sh
  // no longer combinationally reach the bus.
  logic [31:0] rd0_q, rd1_q;
  logic [63:0] win;
  assign win    = {rd1_q, rd0_q};
  logic [63:0] extracted;
  assign extracted = (win >> boff) & size_mask;

  // ---- FSM ------------------------------------------------------------------
  typedef enum logic [2:0] {
    S_IDLE, S_DECODE, S_RD0, S_RD1, S_WR0, S_WR1, S_ACK
  } st_t;
  st_t st_q, st_d;

  // bus / core output registers driven by the FSM
  always_comb begin
    // safe defaults
    st_d      = st_q;
    bus_req   = 1'b0;
    bus_we    = 1'b0;
    bus_addr  = p_addr0;
    bus_be    = 4'b0000;
    bus_wdata = 32'h0;
    bus_srt   = srt_q;

    unique case (st_q)
      // --------------------------------------------------------------------
      S_IDLE: begin
        // Latch the request (FF below) -- a_q/sz_q/wd_q AND the p_* per-beat bus
        // fields precomputed from the core inputs -- then spend one cycle in
        // S_DECODE so the registered p_rmw/p_straddle (and the read-side boff/
        // size_mask off a_q/sz_q) are valid before the first bus beat is chosen.
        // Leave IDLE only on a cpu_ce edge, in lockstep with the launch capture
        // below, so the request is registered from the CPU exactly when its
        // fields are latched -- never a non-CE edge that would decode stale a_q.
        // ce_cpu !== 1'b0 keeps ce=1 / unconnected benches byte-identical.
        if (core_req && !core_ack && (ce_cpu !== 1'b0)) st_d = S_DECODE;
      end
      // --------------------------------------------------------------------
      S_DECODE: begin
        if (we_q && !p_rmw) st_d = S_WR0;  // whole-byte write: no read
        else                st_d = S_RD0;  // read, or RMW write
      end
      // --------------------------------------------------------------------
      S_RD0: begin
        bus_req  = 1'b1;
        bus_we   = 1'b0;
        bus_addr = p_addr0;
        // An aligned 34020 word read is a halfword transaction. This matters
        // for MMIO whose read result depends on the selected lanes. RMW must
        // still read every lane needed to preserve the surrounding bits.
        bus_be   = (P_IS_34020 && !we_q && sz_q == 6'd16 &&
                    a_q[3:0] == 4'd0) ? p_be0 : 4'b1111;
        if (bus_ack) st_d = p_straddle ? S_RD1 : (we_q ? S_WR0 : S_ACK);
      end
      // --------------------------------------------------------------------
      S_RD1: begin
        bus_req  = 1'b1;
        bus_we   = 1'b0;
        bus_addr = p_addr1;
        bus_be   = 4'b1111;
        if (bus_ack) st_d = we_q ? S_WR0 : S_ACK;
      end
      // --------------------------------------------------------------------
      S_WR0: begin
        bus_req  = 1'b1;
        bus_we   = 1'b1;
        bus_addr = p_addr0;
        bus_be   = p_be0;
        // RMW merge over the read-back word from the PRECOMPUTED clear-mask +
        // shifted data (== rmw_needed ? merged[31:0] : wdata_sh[31:0], since a
        // whole-byte write has ~fieldmask==0 in every enabled byte). ~2 levels.
        bus_wdata= p_rmw ? ((rd0_q & p_nmask0) | p_wsh0) : p_wsh0;
        if (bus_ack) st_d = (p_straddle && (p_be1 != 4'b0000)) ? S_WR1 : S_ACK;
      end
      // --------------------------------------------------------------------
      S_WR1: begin
        bus_req  = 1'b1;
        bus_we   = 1'b1;
        bus_addr = p_addr1;
        bus_be   = p_be1;
        bus_wdata= p_rmw ? ((rd1_q & p_nmask1) | p_wsh1) : p_wsh1;
        if (bus_ack) st_d = S_ACK;
      end
      // --------------------------------------------------------------------
      S_ACK: begin
        st_d = S_IDLE;             // registered ACK blocks IDLE until consumed
      end
      // --------------------------------------------------------------------
      default: st_d = S_IDLE;
    endcase
  end

  // sequential state + captures + core handshake
  always_ff @(posedge clk) begin
    if (rst) begin
      st_q       <= S_IDLE;
      a_q        <= '0;
      sz_q       <= '0;
      we_q       <= 1'b0;
      f_q        <= 1'b0;
      srt_q      <= 1'b0;
      wd_q       <= '0;
      rd0_q      <= '0;
      rd1_q      <= '0;
      core_ack   <= 1'b0;
      core_rdata <= '0;
      p_addr0    <= '0;
      p_addr1    <= '0;
      p_be0      <= 4'b0000;
      p_be1      <= 4'b0000;
      p_wsh0     <= '0;
      p_wsh1     <= '0;
      p_nmask0   <= '0;
      p_nmask1   <= '0;
      p_rmw      <= 1'b0;
      p_straddle <= 1'b0;
    end else begin
      // The adapter runs at the full system clock while the CPU may run /2.
      // A one-clock ACK can miss every enabled CPU edge and replay a held
      // request. Keep ACK/data until actual consumption. On that edge IDLE's
      // !core_ack guard also prevents recapturing the retiring command. The
      // next edge may accept a new RMW phase even if core_req never went low.
      if (core_ack && (ce_cpu !== 1'b0)) core_ack <= 1'b0;
      // LAUNCH capture: a_q/sz_q/we_q/srt_q/wd_q hold a CPU-launched command and
      // must be a legitimate multicycle DESTINATION from the core (rtl/revx/
      // revx.sdc: -from CE core -to these launch regs, setup 4/hold 3). Capture
      // only on a cpu_ce edge, in lockstep with the S_IDLE->S_DECODE exit above.
      // The core holds core_req/addr/size/data stable across the CE gap, so the
      // captured value is identical to the old full-rate capture; only STA sees
      // the extra clocks. ce_cpu !== 1'b0 keeps ce=1 benches byte-identical.
      if (st_q == S_IDLE && core_req && !core_ack && (ce_cpu !== 1'b0)) begin
        a_q   <= core_addr;
        sz_q  <= core_size;
        we_q  <= core_we;
        f_q   <= core_fetch;
        srt_q <= core_srt;
        wd_q  <= core_wdata;
        // Precompute the bus beats from the CORE command inputs on this same
        // launch edge, so the deep size/alignment barrel-shift + byte-lane cone
        // is a CE-core -> launch path (setup 4), not an a_q/sz_q/wd_q -> bus
        // full-rate path. core_* are held stable across the CE gap, so these
        // registers hold exactly what the retired a_q-based combinational
        // signals would have produced one cycle later (bit-identical).
        p_addr0    <= n_word0;
        p_addr1    <= n_word1;
        p_be0      <= n_be0;
        p_be1      <= n_be1;
        p_rmw      <= n_rmw;
        p_straddle <= n_straddle;
`ifdef MUT_MEMIF_SWAP_BEATS
        // MUTANT: swap beat-0 and beat-1 write DATA (only; addresses/be stay put)
        // so a straddle write lands each half in the WRONG word. The coremem
        // P_E/P_G straddle cases FAIL. This proves the precomputed p_wsh*/p_nmask*
        // registers are what actually drive bus_wdata -- a live-recompute mutant
        // would be value-identical and could not discriminate the precompute.
        p_wsh0     <= n_wdata_sh[63:32];
        p_wsh1     <= n_wdata_sh[31:0];
        p_nmask0   <= ~n_fieldmask[63:32];
        p_nmask1   <= ~n_fieldmask[31:0];
`else
        p_wsh0     <= n_wdata_sh[31:0];
        p_wsh1     <= n_wdata_sh[63:32];
        p_nmask0   <= ~n_fieldmask[31:0];
        p_nmask1   <= ~n_fieldmask[63:32];
`endif
      end
      if (st_q == S_RD0 && bus_ack) rd0_q <= bus_rdata;
      if (st_q == S_RD1 && bus_ack) rd1_q <= bus_rdata;
      if (st_q == S_ACK) begin
        core_ack   <= 1'b1;
        core_rdata <= we_q ? '0 : {{(DATA_WIDTH-32){1'b0}}, extracted[31:0]};
      end
      st_q <= st_d;
    end
  end

endmodule
`default_nettype wire
