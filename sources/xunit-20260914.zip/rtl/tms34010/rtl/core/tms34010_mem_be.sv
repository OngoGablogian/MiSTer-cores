// -----------------------------------------------------------------------------
// tms34010_mem_be.sv
//
// TMS34020-DELTA step 1: the parameterised program-bus memory PRIMITIVE.
//
// Models MAME 0.289's device-specific WORD/DWORD memory primitives -- the ONLY
// place the 34010 vs 34020 program-bus width lives (docs/TMS34020-DELTA.md (a);
// MAME tms34010.cpp:66,295-344). Given a 16-bit-aligned logical BIT address and
// a WORD (16-bit) / DWORD (32-bit) access class, it emits the 32-bit-bus
// transaction plan: aligned 32-bit word address(es), byte enables `be[3:0]`,
// lane-rotated write data, and the read reassembly of the fetched word(s).
//
//   IS_34020 = 0  (TMS34010, 16-bit external bus)
//     WORD  : one 16-bit access at the 16-bit-aligned address.
//     DWORD : two 16-bit accesses (A, A+16) -- MAME two `write_word`/`read_word`
//             (tms34010.cpp:305-333).
//
//   IS_34020 = 1  (TMS34020, 32-bit external bus)
//     WORD  : a 16-bit access realized on the 32-bit word at A&~0x1F, in the
//             half-word lane selected by bit-address bit 4:
//               bit4=0 -> be=0011 (mem_mask 0x0000ffff), data in [15:0]
//               bit4=1 -> be=1100 (mem_mask 0xffff0000), data in [31:16]
//             (MAME TMS34010_WRMEM_WORD, tms34010.cpp:321-327).
//     DWORD : aligned (bit4=0)  -> one be=1111 access at A.
//             straddle (bit4=1) -> two accesses:
//               word A&~0x1F   : be=1100, low16 of data  (high lane)
//               word (A&~0x1F)+0x20 : be=0011, high16 of data (low lane)
//             (MAME TMS34010_WRMEM_DWORD, tms34010.cpp:335-344; RDMEM_DWORD via
//             read_dword_unaligned :311-314).
//
// This is a pure combinational descriptor: the caller applies each valid
// transaction's `be` to a behavioural 32-bit memory (writes) or feeds the two
// fetched words back in `r0_word`/`r1_word` (reads) and takes `rdata`.
// Sub-16-bit field masking (read-modify-write) is the FIELD layer's job (a
// later delta step); the bus primitive here is 16-bit granular.
//
// Default IS_34020 = 0 so instantiating this leaf never perturbs a 34010 gate.
// -----------------------------------------------------------------------------

`default_nettype none
module tms34010_mem_be
  import tms34010_pkg::*;
#(
  parameter bit P_IS_34020 = IS_34020
) (
  // 16-bit-aligned logical bit address (low 4 bits are the field shift and are
  // ignored here; bit 4 is the meaningful half-word lane selector).
  input  wire logic [ADDR_WIDTH-1:0] a_bitaddr,
  input  wire logic                  op_dword,   // 1 = 32-bit access, 0 = 16-bit
  input  wire logic [31:0]           wdata,      // write data (WORD uses [15:0])
  input  wire logic [31:0]           r0_word,    // word read back from t0_addr32
  input  wire logic [31:0]           r1_word,    // word read back from t1_addr32

  output logic                       t0_valid,
  output logic [ADDR_WIDTH-1:0]      t0_addr32,  // bit address of 32-bit word
  output logic [3:0]                 t0_be,
  output logic [31:0]                t0_wdata,

  output logic                       t1_valid,
  output logic [ADDR_WIDTH-1:0]      t1_addr32,
  output logic [3:0]                 t1_be,
  output logic [31:0]                t1_wdata,

  output logic [31:0]                rdata       // reassembled read value
);

  // 32-bit-word-aligned base (clear the low 5 bits = 32 program bits) and the
  // half-word lane selector (program bit 4).
  logic [ADDR_WIDTH-1:0] word32base;
  logic                  half;
  assign word32base = a_bitaddr & ~(ADDR_WIDTH'('h1F));

`ifdef MUT_BE_IGNORE_BIT4
  // MUTANT: drop the bit-4 lane selector -- always treat the access as the low
  // half / aligned dword. High-half WORD writes and straddling DWORDs then land
  // in the wrong lane. MUST be killed by the bit4=1 cases in tb_020_bus_field.
  assign half = 1'b0;
`else
  assign half = a_bitaddr[4];
`endif

  always_comb begin
    // defaults
    t0_valid  = 1'b1;
    t0_addr32 = word32base;
    t0_be     = 4'b0000;
    t0_wdata  = 32'h0;
    t1_valid  = 1'b0;
    t1_addr32 = word32base + ADDR_WIDTH'('h20);
    t1_be     = 4'b0000;
    t1_wdata  = 32'h0;
    rdata     = 32'h0;

    if (P_IS_34020) begin
      // ------------------------------------------------ TMS34020 (32-bit bus)
      if (!op_dword) begin
        // 16-bit WORD access, half-word lane by bit 4.
        t0_addr32 = word32base;
        if (half) begin
          t0_be    = 4'b1100;
          t0_wdata = {wdata[15:0], 16'h0};
          rdata    = {16'h0, r0_word[31:16]};
        end else begin
          t0_be    = 4'b0011;
          t0_wdata = {16'h0, wdata[15:0]};
          rdata    = {16'h0, r0_word[15:0]};
        end
      end else begin
        // 32-bit DWORD access.
        if (!half) begin
          t0_addr32 = word32base;
          t0_be     = 4'b1111;
          t0_wdata  = wdata;
          rdata     = r0_word;
        end else begin
          // straddles two 32-bit words.
          t0_addr32 = word32base;
          t0_be     = 4'b1100;
          t0_wdata  = {wdata[15:0], 16'h0};
          t1_valid  = 1'b1;
          t1_addr32 = word32base + ADDR_WIDTH'('h20);
          t1_be     = 4'b0011;
          t1_wdata  = {16'h0, wdata[31:16]};
          rdata     = {r1_word[15:0], r0_word[31:16]};
        end
      end
    end else begin
      // ------------------------------------------------ TMS34010 (16-bit bus)
      // Two-half word model: each access carries 16 bits in the low lane at the
      // 16-bit-aligned bit address (be=0011 by convention on the narrow bus).
      t0_addr32 = a_bitaddr & ~(ADDR_WIDTH'('hF));
      t0_be     = 4'b0011;
      t0_wdata  = {16'h0, wdata[15:0]};
      if (!op_dword) begin
        rdata = {16'h0, r0_word[15:0]};
      end else begin
        t1_valid  = 1'b1;
        t1_addr32 = (a_bitaddr & ~(ADDR_WIDTH'('hF))) + ADDR_WIDTH'('h10);
        t1_be     = 4'b0011;
        t1_wdata  = {16'h0, wdata[31:16]};
        rdata     = {r1_word[15:0], r0_word[15:0]};
      end
    end
  end

endmodule
`default_nettype wire
