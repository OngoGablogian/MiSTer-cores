// revx_top.sv -- Midway X-unit (Revolution X) CORE top.  Forked in ROLE from wolf_top.sv:
// it is the synthesizable core the MiSTer emu wrapper (Arcade-RevX.sv) instantiates.  This
// fork carries the X-unit-specific, iverilog-verifiable core logic:
//   * P0019 (DESIGN-RULES.md s.6): the 34020 CPU runs on the system clock with a clock-enable
//     (cpu_ce) for its 40 MHz-equivalent pace (midxunit.cpp:654) -- no async CPU clock.
//   * P0022 (DESIGN-RULES.md s.6): the ioctl DOWNLOAD/capture path is domained on a POWER-ON reset
//     (2-FF-synced ~pll_locked), NOT the core reset, so ROM lands even with the core reset
//     held high across the whole download.  CPU/scanout stay on the core reset.
//   * real memory backends (revx_backends): program ROM (2 MB, 32-bit LE interleave) + main
//     RAM + VRAM data/colour on SDRAM, gfx flat on DDR3, CMOS via the nvram bridge.
//   * palette 32768 x xRGB555 (midxunit.cpp:667) + 34020 scanline scanout addressing
//     (midtunit_v.cpp:859 midxunit scanline_update: fulladdr=((rowaddr<<16)|coladdr)>>3,
//     0x7fff word mask).
//   * CPU is a PLACEHOLDER (revx_cpu_bfm, contract ports); the real 34020 (rtl/tms34010,
//     IS_34020) is the CPU lane's.  DMA-done IRQ (midxunit.cpp:650 -> inputline 0) enters as
//     dma_irq -> the BFM's int0.
//
// DELIBERATELY OUT OF SCOPE here (they live in the emu wrapper Arcade-RevX.sv, Step 4, and are
// not iverilog-elaboratable per project memory "MiSTer sys/ + Questa"): the PLL, ascal/HDMI
// video scaler, OSD, and the DDR3 arbiter cascade.  The gun/ADC/UART/PIC/DCS blocks and the
// wolf_dma blitter (proven at the revx_memsys level in tb_revx_dma_matrix) are wired in the
// emu integration; here dma_irq is the wiring point for their DMA-done interrupt.
//
// Gate: tb_revx_top_smoke.  MUTANT REVX_DL_CORE_RESET gates the capture path on the core
// reset -> download blocked while reset is held -> ROM never lands -> the reset-PC fetch check
// FAILS (proves P0022 is load-bearing).

`default_nettype none
module revx_top #(
  parameter int SD_AW      = 21,
  parameter int VSD_AW     = 19,
  parameter bit SRT_WRITE_CHUNKS = 1'b0,
  parameter bit POSTCAL_DIAG = 1'b0,
  parameter bit QUIET_BOOT_DIAG = 1'b0,
  parameter [SD_AW-1:0] ROM_SDBASE = 21'h100000,   // after 0x80000 RAM words *2 = 0x100000 (2 MiB RAM, midxunit.cpp:511)
  // RESET_PC = the measured L2.0 ROM reset vector (bit addr 0xFFFFFFE0 -> 0xFFFDE000,
  // mame-gospel/README.md; tb_revx_top_boot reads it straight from the ROM image).  On the
  // REAL-CPU path this is OBSERVABILITY ONLY (assign reset_pc = RESET_PC) -- the 34020 fetches
  // its vector from ROM, this parameter never drives a fetch.  Only the bring-up BFM
  // (REVX_USE_BFM_CPU) uses it as its synthetic first-fetch address.
  parameter [31:0] RESET_PC = 32'hFFFDE000,
  parameter int PROG_BYTES = 32'h200000            // program ROM span (2 MB)
)(
  input  logic        clk,
  input  logic        reset,        // core reset (CPU + scanout); held high during download
  input  logic        pll_locked,   // from the PLL (emu); ~locked seeds the power-on reset

  input  logic        cpu_ce,       // 34020 clock-enable (P0019); CPU advances only when high

  // ---- ioctl download (hps_io) ----
  input  logic        ioctl_download,
  input  logic        ioctl_wr,
  input  logic  [7:0] ioctl_index,
  input  logic [24:0] ioctl_addr,
  input  logic  [7:0] ioctl_dout,
  output logic        dl_ready,      // 1 = capture path idle, ready for the next ioctl byte
  output logic        dl_wait,       // aggregate ioctl backpressure (-> hps_io ioctl_wait)

  // ---- ioctl extra streams routed by the loader (BUILD-PREP: revx_loader) ----
  //   DCS sound ROM download -> emu wolf_dcs_ddr_top; CMOS/nvram (index 4) persistence
  //   passes straight through to revx_backends' nvram bridge.
  input  logic        ioctl_upload,
  output logic  [7:0] ioctl_din,
  output logic        ioctl_upload_req,
  input  logic        manual_save,
  input  logic        clear_nvram,
  output logic        dcs_dl_wr,
  output logic [22:0] dcs_dl_addr,
  output logic  [7:0] dcs_dl_data,
  input  logic        dcs_dl_ack,
  output logic  [7:0] profile_byte,
  output logic        profile_valid,

  // ---- boot-audit taps (REVX_DIAG_BOOT overlay in the emu) ----
  output logic [31:0] dbg_acc_prog, dbg_acc_gfx, dbg_acc_dcs,
  output logic  [7:0] dbg_drop_any,
  output logic        dbg_rst_during_dl,
  output logic [31:0] dbg_last_fetch_addr, dbg_last_fetch_data,

  // ---- DIAG v2: derail + first-interrupt + io taps (REVX_DIAG_BOOT overlay, from
  //      revx_derail_capture fed by the real-34020 debug ports).  All frozen once captured,
  //      cleared only by core reset; output-only, no CPU datapath effect. ----
  output logic [31:0] dbg_culprit_pc, dbg_target_pc, dbg_last_good_pc,
  output logic [15:0] dbg_culprit_instr,
  output logic        dbg_derail_captured,
  output logic [31:0] dbg_int_pc, dbg_int_vec_addr, dbg_int_vec_value,
  output logic  [7:0] dbg_int_count,
  output logic        dbg_int_captured,
  output logic [15:0] dbg_intpend, dbg_intenb,
  output logic        dbg_disp_int,
  output logic        dbg_st_ie,          // CPU ST global interrupt-enable (ST[21]); output-only
  output logic [31:0] dbg_foreground_pc, dbg_timers, dbg_process_ptr, dbg_watch_status,
  output wire [287:0] dbg_postcal_early, dbg_postcal_final,

  // ---- DMA-done IRQ (from the blitter integration) -> CPU input line 0 ----
  input  logic        dma_irq,

  // ---- CPU sequencer command port (drives the placeholder CPU) ----
  input  logic        cmd_req,
  input  logic        cmd_we,
  input  logic [31:0] cmd_addr,
  input  logic  [3:0] cmd_be,
  input  logic [31:0] cmd_wdata,
  output logic [31:0] cmd_rdata,
  output logic        cmd_done,

  // ---- scanout (34020 scanline_update) ----
  input  logic        scan_start,
  input  logic [15:0] scan_rowaddr,  // params->rowaddr
  input  logic [15:0] scan_coladdr,  // params->coladdr
  output logic [14:0] scan_pixel,    // xRGB555 (palette-mapped)
  output logic        scan_done,

  // ---- observability ----
  output logic [31:0] reset_pc,
  output logic        int0_seen,
  output logic [31:0] cpu_pc,        // real-CPU program counter (REVX_USE_REAL_CPU)
  output logic        cpu_retire,    // legacy timing-start tap: opcode OR interrupt entry
  output logic [15:0] cpu_instr,     // real-CPU decoded instruction word (debug)
  // Passive native I/O value/validity; the external bus suppresses I/O writes.
  output wire [31:0] diag_dpyst_value,
  output wire diag_dpyst_valid,
  output wire diag_opcode_accept,

  // ---- physical memory channels (to sdram_model / ddr3_avalon_model in the emu/tb) ----
  output logic [SD_AW-1:0] sd_addr, output logic [15:0] sd_din, output logic [1:0] sd_be,
  output logic sd_rd, sd_wr, input logic [15:0] sd_dout, input logic sd_ack,
  output logic [VSD_AW-1:0] vd_addr, output logic [15:0] vd_din, output logic [1:0] vd_be,
  output logic vd_rd, vd_wr, input logic [15:0] vd_dout, input logic vd_ack,
  output logic [2:0] vd_count, output logic [63:0] vd_words, output logic vd_reverse,
  output logic wb_req, output logic [VSD_AW-1:0] wb_addr,
  output logic [6:0] wb_count, output logic [1023:0] wb_data, input logic wb_ack,
`ifdef REVX_BLMOVE_BURST
  // BLMOVE write chunk (SD-space absolute RAM words) -> the phys's wb2 port.
  output logic wb2_req, output logic [SD_AW-1:0] wb2_addr,
  output logic [4:0] wb2_count, output logic [255:0] wb2_data, input logic wb2_ack,
`endif
  // PERF: CPU line-fill burst READ (bypasses the inner arb; -> the emu's outer arb)
  output logic rb_req, output logic [SD_AW-1:0] rb_addr,
  output logic [4:0] rb_count, input logic [255:0] rb_dout, input logic rb_ack,
`ifdef REVX_VRAM_LB
  // VRAM line-buffer fill (canonical 19-bit pixel words; the emu adds the VRAM
  // chip base and muxes it onto the phys's rb with the vlb at the LOWEST priority).
  output logic vlb_rb_req, output logic [VSD_AW-1:0] vlb_rb_addr,
  output logic [4:0] vlb_rb_count, input logic [255:0] vlb_rb_dout, input logic vlb_rb_ack,
`endif
  output logic [VSD_AW-1:0] vc_addr, output logic [15:0] vc_din, output logic [1:0] vc_be,
  output logic vc_rd, vc_wr, input logic [15:0] vc_dout, input logic vc_ack,
  output logic [28:0] gfx_ddram_addr, output logic [7:0] gfx_ddram_burstcnt,
  output logic gfx_ddram_rd, gfx_ddram_we, output logic [63:0] gfx_ddram_din,
  output logic [7:0] gfx_ddram_be, input logic gfx_ddram_busy,
  input logic [63:0] gfx_ddram_dout, input logic gfx_ddram_dout_ready
`ifdef REVX_EMU_INTEG
  // ==== EMU-INTEGRATION frontier (d): CPU I/O peripheral bus (revx_memsys on the CPU path) ====
  //  + frontier (b) taps: palette read (for the emu's revx_scanout) and the 34020 display
  //  registers (params->rowaddr/coladdr).  All guarded so tb_revx_top_boot/smoke compile revx_top
  //  byte-identically (define OFF) -- the emu + the emu-scope gates compile it ON.
  ,
  // pixel-clock enable: runs the 34020 core's video block so DPYSTRT/DPYNX advance the
  // display registers per line (params->rowaddr/coladdr) for the autonomous scanout.
  input  logic        ce_pix,
  // player inputs / DIPs (active-low), gun ADC feed
  input  logic [31:0] in0, in1, in2, dsw,
  input  logic  [7:0] an0, an1, an2, an3, an4, an5,
  // DCS host side (revx_uart <-> the emu's revx_dcs2k bridge)
  input  logic [15:0] dcs_ctrl,
  input  logic  [7:0] dcs_data_in,
  input  logic        dcs_output_full,
  output logic        dcs_data_w,
  output logic  [7:0] dcs_data_o,
  output logic        dcs_data_rd,
  output logic        dcs_reset,        // active-HIGH DCS reset = SYSCTRL1[1] (P0020; 1=held,0=run)
  output logic        dcs_lint1,        // DCS output-full -> CPU LINT2 (see note: core has no LINT2 pin)
  // board control outputs
  output logic  [3:0] sysctrl0, sysctrl1,
  output logic        cmos_write_enable,
  output logic  [2:0] gun_recoil, gun_led,
  output logic        watchdog_kick,
  // 16-bit blitter register port (to the fork-pending wolf_dma)
  output logic        dma_reg_we,
  output logic  [3:0] dma_reg_addr,
  output logic [15:0] dma_reg_wdata,
  output logic [2:0] dma_reg_pair,
  input logic [31:0] dma_pair_rdata,
  input logic [15:0] dma_palette,
  input logic dma_pixel_req,
  input logic [18:0] dma_pixel_addr,
  input logic [15:0] dma_pixel_data,
  input logic [2:0] dma_pixel_count, input logic [63:0] dma_pixel_words, input logic dma_pixel_reverse,
  output logic dma_pixel_ack,
  input logic dma_mem_req, dma_mem_we,
  input logic [31:0] dma_mem_addr, dma_mem_wdata,
  input logic [3:0] dma_mem_be,
  output logic dma_mem_ack,
  output logic [31:0] dma_mem_rdata,
  // palette read port for the emu's autonomous scanout (revx_scanout)
  input  logic [14:0] pal_rd_idx,
  output logic [15:0] pal_rd_data,
  // 34020 display-register taps (params->rowaddr/coladdr) for revx_scanout
  output logic [15:0] disp_row, disp_col,
  output logic        disp_enable,
  output logic [15:0] video_hcount, video_vcount,
  output logic [15:0] video_heblnk, video_hsblnk, video_veblnk, video_vsblnk,
  output logic video_hs, video_vs, video_hb, video_vb, video_ready,
  output logic dbg_pic_status,
  output logic [7:0] dbg_uart_last, dbg_adc_chan, dbg_adc_last
`endif
);
  // ---------------------------------------------------------------- P0022 power-on reset
  logic por_ff1, por_ff2, por;
  always_ff @(posedge clk) begin
    por_ff1 <= ~pll_locked;
    por_ff2 <= por_ff1;
  end
  assign por = por_ff2;

  // capture-path reset domain: revx_loader owns it (por only, P0022; REVX_DL_CORE_RESET mutant
  // inside the loader folds in the core reset to prove the domain is load-bearing).

  // ---------------------------------------------------------------- CPU
  logic        c_req, c_we, c_ack, c_srt, c_fetch; logic [31:0] c_addr, c_wdata, c_rdata; logic [3:0] c_be;
  logic [15:0] core_disp_row, core_disp_col; logic core_disp_en;
  // DIAG v2 core interrupt taps (driven by the real 34020 debug ports; 0 under the BFM).
  logic        cdbg_int_entry;
  logic [31:0] cdbg_int_pc, cdbg_int_vec_addr, cdbg_int_vec_value;
  logic [15:0] cdbg_intpend, cdbg_intenb;
  logic        cdbg_disp_int;
  logic        cdbg_st_ie;
  wire         postcal_irq_begin, postcal_irq_return;
`ifdef REVX_BLMOVE_BURST
  logic be_rb_req, be_rb_ack;
  logic [SD_AW-1:0] be_rb_addr;
  logic [4:0] be_rb_count;
  logic [255:0] be_rb_dout;
`endif
`ifdef REVX_VRAM_LB
  logic be_vlb_rb_req, be_vlb_rb_ack;
  logic [VSD_AW-1:0] be_vlb_rb_addr;
  logic [4:0] be_vlb_rb_count;
  logic [255:0] be_vlb_rb_dout;
  assign vlb_rb_req = be_vlb_rb_req;
  assign vlb_rb_addr = be_vlb_rb_addr;
  assign vlb_rb_count = be_vlb_rb_count;
  assign be_vlb_rb_dout = vlb_rb_dout;
  assign be_vlb_rb_ack = vlb_rb_ack;
`endif
`ifdef REVX_EMU_INTEG
  wire core_lint2 = dcs_lint1;
`else
  wire core_lint2 = 1'b0;
`endif
  //   // 34020 display-reg taps
`ifndef REVX_USE_BFM_CPU
  // -- REAL TMS34020 (rtl/tms34010, IS_34020) -- DEFAULT (shipped) path -------
  //  BUILD-PREP: the real 34020 is now the DEFAULT; -DREVX_USE_BFM_CPU selects the
  //  bring-up placeholder (revx_cpu_bfm) for the smoke/elab gates.  (-DREVX_USE_REAL_CPU
  //  is still accepted -- run_revx_top_boot.sh passes it -- and is now a no-op.)
  // The core speaks the 34010 FIELD interface (mem_size/mem_srt); tms34010_mem_if
  // (P_IS_34020=1) converts it to the RevX 32-bit word + byte-enable bus contract
  // (bus_addr bit-address, bus_be[3:0]) that revx_backends consumes.  P0019: the
  // core runs on the system clock gated by cpu_ce (ce_cpu), no async CPU clock.
  // dma_irq -> LINT1 (midxunit.cpp:650 dma_irq_cb -> inputline 0; the io_regs block
  // mirrors LINT1 into INTPEND).  The CPU lane owns the core -- NOT patched here.
  import tms34010_pkg::*;
  logic        k_req, k_we, k_srt, k_ack, k_fetch; logic [ADDR_WIDTH-1:0] k_addr;
  logic [FIELD_SIZE_WIDTH-1:0] k_size; logic [DATA_WIDTH-1:0] k_wdata, k_rdata;
  logic [ADDR_WIDTH-1:0] k_pc; logic k_retire;
`ifdef REVX_BLMOVE_BURST
  // BLMOVE burst chunk wiring: the core's raw bit-address chunk requests,
  // converted here to SDRAM word indices and muxed onto the rb/wb chunk ports
  // (shared with the fetch/data fill and the SRT writeback).  Region decode is
  // CE-domain logic: the engine's src_q/dst_q feed it and the engine CE-samples
  // burst_ok -- no full-rate cone.  RAM words 0-0x7FFFF, ROM at ROM_SDBASE.
  logic                         blm_brb_req, blm_brb_ack, blm_bwb_req, blm_bwb_ack;
  logic [ADDR_WIDTH-1:0]        blm_brb_addr, blm_bwb_addr;
  logic [4:0]                   blm_brb_count, blm_bwb_count;
  logic [255:0]                 blm_brb_dout, blm_bwb_data;
  logic                         blm_burst_ok;
  // the u_be's chunk outputs -> internal wires -> the mux below (rb only; the
  // SRT wb stays the direct top-level port -- the blmove write rides wb2).
  wire blm_src_ram = (blm_brb_addr[31:24] == 8'h20);
  wire blm_src_rom = (blm_brb_addr[31:24] == 8'hFF);
  wire blm_dst_ram = (blm_bwb_addr[31:24] == 8'h20);
  // burst eligible: source in RAM/ROM, destination in RAM (the ROM is read-only).
  assign blm_burst_ok = (blm_src_ram | blm_src_rom) & blm_dst_ram;
  // SDRAM word index: RAM = (addr-0x20000000)>>4, ROM = ROM_SDBASE + (addr-0xFF000000)>>4
  wire [SD_AW-1:0] blm_rd_word =
      blm_src_rom ? (ROM_SDBASE + {17'd0, (blm_brb_addr[23:0] - 24'h000000) >> 4})
                  : {17'd0, (blm_brb_addr[23:0]) >> 4};
  wire [SD_AW-1:0] blm_wr_word = {17'd0, blm_bwb_addr[23:0] >> 4};
  // Memory acks are single system-clock pulses; the engine advances only on
  // cpu_ce. Full-rate mailboxes retain both completion and read payload.
  logic blm_read_req, blm_read_ack;
  logic [SD_AW-1:0] blm_read_addr;
  logic [4:0] blm_read_count;
  logic [255:0] blm_read_data;
  revx_chunk_mailbox #(.AW(SD_AW)) u_blm_read_mailbox (
    .clk(clk), .rst(reset), .cpu_req(blm_brb_req), .cpu_addr(blm_rd_word),
    .cpu_count(blm_brb_count), .cpu_wdata(256'd0),
    .cpu_ack(blm_brb_ack), .cpu_rdata(blm_brb_dout),
    .req(blm_read_req), .addr(blm_read_addr), .count(blm_read_count), .wdata(),
    .ack(blm_read_ack), .rdata(blm_read_data));
  revx_read_chunk_mux #(.AW(SD_AW)) u_cpu_chunk_mux (
    .clk(clk), .rst(reset),
    .a_req(be_rb_req), .a_addr(be_rb_addr), .a_count(be_rb_count),
    .a_data(be_rb_dout), .a_ack(be_rb_ack),
    .b_req(blm_read_req), .b_addr(blm_read_addr), .b_count(blm_read_count),
    .b_data(blm_read_data), .b_ack(blm_read_ack),
    .req(rb_req), .addr(rb_addr), .count(rb_count), .data(rb_dout), .ack(rb_ack));
  revx_chunk_mailbox #(.AW(SD_AW)) u_blm_write_mailbox (
    .clk(clk), .rst(reset), .cpu_req(blm_bwb_req), .cpu_addr(blm_wr_word),
    .cpu_count(blm_bwb_count), .cpu_wdata(blm_bwb_data),
    .cpu_ack(blm_bwb_ack), .cpu_rdata(),
    .req(wb2_req), .addr(wb2_addr), .count(wb2_count), .wdata(wb2_data),
    .ack(wb2_ack), .rdata(256'd0));
`endif
  // Under REVX_EMU_INTEG the core's video block runs at ce_pix so DPYSTRT/DPYNX advance the
  // display registers per line (the autonomous scanout consumes them); bring-up gates keep it
  // OFF (ce_pix tied 0) so the boot PC stream is unperturbed by video-timing interrupts.
`ifdef REVX_EMU_INTEG
  wire core_ce_pix = ce_pix;
`else
  wire core_ce_pix = 1'b0;
`endif
  tms34010_core u_cpu (
    .clk(clk), .ce_cpu(cpu_ce), .ce_pix(core_ce_pix), .rst(reset),
    .mem_req(k_req), .mem_we(k_we), .mem_addr(k_addr), .mem_size(k_size),
    .mem_wdata(k_wdata), .mem_srt(k_srt), .fetch_access_o(k_fetch), .mem_rdata(k_rdata), .mem_ack(k_ack),
    // Preserve the legacy runtime timing-start signal, including interrupt entry.
    // diag_opcode_accept below excludes IRQ entry before software-route counting.
    .pc_o(k_pc), .instruction_start_o(k_retire), .instr_word_o(cpu_instr),
    .dbg_dpyst_value_o(diag_dpyst_value), .dbg_dpyst_valid_o(diag_dpyst_valid),
    .display_row_o(core_disp_row), .display_col_o(core_disp_col), .display_enable_o(core_disp_en),
    .lint1_in(dma_irq), .lint2_in(core_lint2),
    // DIAG v2 interrupt-entry taps (output-only)
    .dbg_int_entry_o(cdbg_int_entry), .dbg_int_pc_o(cdbg_int_pc),
    .dbg_int_vec_addr_o(cdbg_int_vec_addr), .dbg_int_vec_value_o(cdbg_int_vec_value),
    .dbg_intpend_o(cdbg_intpend), .dbg_intenb_o(cdbg_intenb), .dbg_disp_int_o(cdbg_disp_int),
    .dbg_st_ie_o(cdbg_st_ie), .dbg_int_return_o(postcal_irq_return),
    .dbg_int_begin_o(postcal_irq_begin)
`ifdef REVX_BLMOVE_BURST
    , .blmove_brb_req(blm_brb_req), .blmove_brb_addr(blm_brb_addr), .blmove_brb_count(blm_brb_count)
    , .blmove_brb_dout(blm_brb_dout), .blmove_brb_ack(blm_brb_ack)
    , .blmove_bwb_req(blm_bwb_req), .blmove_bwb_addr(blm_bwb_addr), .blmove_bwb_count(blm_bwb_count)
    , .blmove_bwb_data(blm_bwb_data), .blmove_bwb_ack(blm_bwb_ack)
    , .blmove_burst_ok(blm_burst_ok)
`endif
`ifdef REVX_EMU_INTEG
    , .video_hcount_o(video_hcount), .video_vcount_o(video_vcount),
    .video_heblnk_o(video_heblnk), .video_hsblnk_o(video_hsblnk),
    .video_veblnk_o(video_veblnk), .video_vsblnk_o(video_vsblnk),
    .video_hs_o(video_hs), .video_vs_o(video_vs),
    .video_hb_o(video_hb), .video_vb_o(video_vb), .video_ready_o(video_ready)
`endif
  );
  tms34010_mem_if #(.P_IS_34020(1'b1)) u_mif (
    .clk(clk), .rst(reset), .ce_cpu(cpu_ce),
    .core_req(k_req), .core_we(k_we), .core_addr(k_addr), .core_size(k_size),
    .core_wdata(k_wdata), .core_srt(k_srt), .core_fetch(k_fetch), .core_rdata(k_rdata), .core_ack(k_ack),
    .bus_req(c_req), .bus_we(c_we), .bus_addr(c_addr), .bus_be(c_be),
    .bus_wdata(c_wdata), .bus_srt(c_srt), .bus_fetch(c_fetch), .bus_rdata(c_rdata), .bus_ack(c_ack));
  assign cpu_pc     = k_pc;
  assign cpu_retire = k_retire;
  // The legacy start tap also pulses on interrupt entry with the resume PC.
  // Only actual opcode acceptance may classify game software branches.
  assign diag_opcode_accept = k_retire && !postcal_irq_begin;
  assign reset_pc   = RESET_PC;
  assign cmd_rdata  = 32'd0; assign cmd_done = 1'b0;
  always_ff @(posedge clk) if (reset) int0_seen<=1'b0; else if (dma_irq) int0_seen<=1'b1;
`else
  // -- PLACEHOLDER BFM (only under -DREVX_USE_BFM_CPU; smoke/elab gates drive cmd) -----
  logic        cmd_req_ce;                      // cpu_ce gates the handshake (P0019)
  assign cmd_req_ce = cmd_req & cpu_ce;
  assign c_srt = 1'b0;
  assign c_fetch = 1'b0;
  assign cpu_pc = 32'd0; assign cpu_retire = 1'b0; assign cpu_instr = 16'd0;
  assign diag_dpyst_value=32'd0; assign diag_dpyst_valid=1'b0;
  assign diag_opcode_accept=1'b0;
  assign core_disp_row = 16'd0; assign core_disp_col = 16'd0; assign core_disp_en = 1'b0;
  // DIAG v2 taps unused on the BFM path
  assign cdbg_int_entry = 1'b0; assign cdbg_int_pc = 32'd0;
  assign cdbg_int_vec_addr = 32'd0; assign cdbg_int_vec_value = 32'd0;
  assign cdbg_intpend = 16'd0; assign cdbg_intenb = 16'd0; assign cdbg_disp_int = 1'b0;
  assign cdbg_st_ie = 1'b0;
  assign postcal_irq_return = 1'b0;
  assign postcal_irq_begin = 1'b0;
`ifdef REVX_BLMOVE_BURST
  assign rb_req=be_rb_req;
  assign rb_addr=be_rb_addr;
  assign rb_count=be_rb_count;
  assign be_rb_dout=rb_dout;
  assign be_rb_ack=rb_ack;
  assign wb2_req=1'b0;
  assign wb2_addr='0;
  assign wb2_count='0;
  assign wb2_data='0;
`endif
`ifdef REVX_EMU_INTEG
  assign {video_hcount,video_vcount,video_heblnk,video_hsblnk,video_veblnk,video_vsblnk} = '0;
  assign {video_hs,video_vs,video_hb,video_vb,video_ready} = '0;
`endif
  revx_cpu_bfm #(.RESET_PC(RESET_PC)) u_cpu (
    .clk(clk), .rst(reset),
    .mem_req(c_req), .mem_we(c_we), .mem_addr(c_addr), .mem_be(c_be), .mem_wdata(c_wdata),
    .mem_rdata(c_rdata), .mem_ack(c_ack), .int0(dma_irq),
    .cmd_req(cmd_req_ce), .cmd_we(cmd_we), .cmd_addr(cmd_addr), .cmd_be(cmd_be),
    .cmd_wdata(cmd_wdata), .cmd_rdata(cmd_rdata), .cmd_done(cmd_done),
    .reset_pc(reset_pc), .int0_seen(int0_seen));
`endif

  // ---------------------------------------------------------------- scanout FSM
  // fulladdr (16-bit VRAM word index) = ((rowaddr<<16)|coladdr)>>3 & 0x7fff (midtunit_v.cpp:859)
  wire [31:0] scan_full = (({16'd0, scan_rowaddr} << 16) | {16'd0, scan_coladdr}) >> 3;
  wire [14:0] scan_i0   = scan_full[14:0] & 15'h7fff;
  logic       s_active, s_req; logic [31:0] s_addr; logic s_half;
  logic [15:0] scan_word;
  typedef enum logic [2:0] { SC_IDLE, SC_RD, SC_PAL, SC_PAL2, SC_DONE } sc_t;
  sc_t sc;

  // ---------------------------------------------------------------- CPU/scanout bus mux
  logic        m_req, m_we, m_ack; logic [31:0] m_addr, m_wdata, m_rdata; logic [3:0] m_be;
  assign m_req   = s_active ? s_req  : c_req;
  assign m_we    = s_active ? 1'b0   : c_we;
  assign m_addr  = s_active ? s_addr : c_addr;
  assign m_be    = s_active ? 4'hf   : c_be;
  assign m_wdata = s_active ? 32'd0  : c_wdata;
  assign c_ack    = m_ack & ~s_active;
  assign c_rdata  = m_rdata;

  // ---------------------------------------------------------------- palette (32768 xRGB555)
  // 0xa0800000, 32-bit stride, LOW-16 only (midtunit_v.cpp:403-407).
  // CPU and scanout use separate registered M10K read ports.
  wire         is_pal = (m_addr[31:20] == 12'ha08);      // 0xa0800000-0xa08fffff
  wire [14:0]  pal_idx = m_addr[19:5];                    // (addr-base)>>5
  logic        pal_ack;
  logic        pal_rd_wait;
  logic [15:0] pal_rd_a, pal_rd_b;
`ifdef REVX_EMU_INTEG
  wire [14:0] pal_addr_b = s_active ? scan_word[14:0] : pal_rd_idx;
`else
  wire [14:0] pal_addr_b = scan_word[14:0];
`endif
  wire pal_we_a = !reset && m_req && is_pal && m_we && m_be[0] && !pal_ack && !pal_rd_wait;
  revx_palram #(.DW(16), .AW(15)) u_pal (
    .clk(clk), .we_a(pal_we_a), .addr_a(pal_idx), .wd_a(m_wdata[15:0]),
    .rd_a(pal_rd_a), .addr_b(pal_addr_b), .rd_b(pal_rd_b));

`ifdef REVX_EMU_INTEG
  // ---- frontier (d): CPU I/O peripheral windows -> revx_memsys (revx_mem.sv:144-169) ----
  // SYSCTRL/status/inputs/security/io_w/ADC/UART/DMA.  CMOS(0xa04)/PAL(0xa08) and all memory
  // regions stay with revx_backends / the palette above -- so no double-ack.
  wire is_io = (m_addr[31:28]==4'h4 && m_addr[27:0] >= 28'h0800000)         // 0x40800000+ SYSCTRL0/1
             | (m_addr[31:5]  == (32'h60400000 >> 5))                       // 0x60400000 status/pic-clk
             | (m_addr[31:8]  == 24'h60c000)                                // 0x60c000xx IN/DSW/io_w/security
             | (m_addr[31:5]  == (32'h80800000 >> 5))                       // 0x80800000 ADC0848
             | (m_addr[31:8]  == 24'h80c000)                                // 0x80c000xx UART
             | (m_addr[31:24]==8'hc0 && (m_addr[23:20]==4'h8 || m_addr[23:20]==4'hc)); // 0xc0800000 DMA (+mirror)
  logic [31:0] io_rdata; logic io_ack; logic io_cmos_we_unused;
`else
  wire is_io = 1'b0;
`endif

  // ---------------------------------------------------------------- backends (real memory)
  logic        b_req; logic [31:0] b_rdata; logic b_ack;
  logic        dl_wr_o; logic [SD_AW-1:0] dl_addr_o; logic [15:0] dl_din_o; logic [1:0] dl_be_o; logic dl_ack;
  logic        lgfx_wr; logic [24:0] lgfx_addr; logic [7:0] lgfx_data; logic bgfx_ack, bgfx_idle;
  logic [12:0] lpic_rd_addr; logic [7:0] lpic_rd_data;    // parked-PIC BRAM tap (keeps it live)
  wire cpu_b_req = m_req & ~is_pal & ~is_io;
  logic be_we; logic [31:0] be_addr, be_wdata; logic [3:0] be_be;
  logic be_fetch;                         // PERF: instruction-fetch qualifier (data lane)
  logic be_raw_vram, be_srt;
  logic [15:0] be_dma_palette;
  logic cpu_b_ack;
  logic [VSD_AW-1:0] be_vd_addr;
  logic [15:0] be_vd_din;
  logic [1:0] be_vd_be;
  logic be_vd_rd, be_vd_wr, be_vd_ack;
  logic dma_direct_ack;
  logic [18:0] dma_direct_pixel;
`ifdef REVX_EMU_INTEG
  wire dma_direct = dma_pixel_req === 1'b1;
  assign dma_direct_pixel = dma_pixel_addr;
  // Hold ownership through the backend acknowledgment. Both masters hold the
  // complete request until ack; a bubble prevents stale-ack reacceptance.
  logic [1:0] be_owner;
  wire dma_pixel_claimed;
  wire cpu_vram = m_addr[31:22] == 0 || m_addr[31:22] == 2;
  // Reserve simultaneous CPU admission before the pixel mux can claim DMA.
  // Once claimed, the packet excludes NEW CPU VRAM cache hits until the final
  // physical ACK/snoop. Already-owned CPU work and source/ROM/RAM are unaffected.
  wire cpu_new_vram_claim = be_owner == 0 && !b_ack &&
      !(dma_mem_req === 1'b1) && cpu_b_req && cpu_vram && !dma_pixel_claimed;
  always_ff @(posedge clk) begin
    if (reset) be_owner <= 0;
    else if (be_owner != 0 && b_ack) be_owner <= 0;
    else if (be_owner == 0 && !b_ack) begin
      if (dma_mem_req === 1'b1) be_owner <= 2;
`ifdef DMA_GROUP_NO_CPU_GUARD_MUT
      else if (cpu_b_req) be_owner <= 1;
`else
      else if (cpu_b_req && (!cpu_vram || !dma_pixel_claimed)) be_owner <= 1;
`endif
    end
  end
  assign b_req = (be_owner == 1) ? cpu_b_req : (be_owner == 2) ? dma_mem_req : 1'b0;
  assign be_we = (be_owner == 2) ? dma_mem_we : m_we;
  assign be_addr = (be_owner == 2) ? dma_mem_addr : m_addr;
  assign be_wdata = (be_owner == 2) ? dma_mem_wdata : m_wdata;
  assign be_be = (be_owner == 2) ? dma_mem_be : m_be;
  assign be_raw_vram = (be_owner == 2) ? (dma_mem_addr[31:23] == 0) : s_active;
  assign be_srt = (be_owner == 1) && !s_active && c_srt;
  // PERF (data lane): instruction-fetch qualifier for the backends' line buffers.
  // Only the CPU master fetches; DMA/scanout accesses are data (or VRAM, uncached).
  assign be_fetch = (be_owner == 1) ? c_fetch : 1'b0;
  assign be_dma_palette = dma_palette;
  assign cpu_b_ack = b_ack && (be_owner == 1);
  assign dma_mem_ack = b_ack && (be_owner == 2);
  assign dma_pixel_ack = dma_direct_ack;
  assign dma_mem_rdata = b_rdata;
  revx_vram_write_mux #(.AW(VSD_AW)) u_dma_vram_port (
    .clk(clk), .rst(reset),
    .cpu_reserve(((be_owner == 1) && cpu_vram) || cpu_new_vram_claim),
    .dma_claimed(dma_pixel_claimed),
    .cpu_addr(be_vd_addr), .cpu_data(be_vd_din), .cpu_be(be_vd_be),
    .cpu_rd(be_vd_rd), .cpu_wr(be_vd_wr), .cpu_ack(be_vd_ack),
    .dma_req(dma_direct), .dma_addr(VSD_AW'(dma_direct_pixel)),
    .dma_data(dma_pixel_data), .dma_count(dma_pixel_count), .dma_words(dma_pixel_words), .dma_reverse(dma_pixel_reverse),
    .dma_ack(dma_direct_ack), .addr(vd_addr), .data(vd_din), .be(vd_be),
    .rd(vd_rd), .wr(vd_wr), .ack(vd_ack), .count(vd_count), .words(vd_words), .reverse(vd_reverse));
`else
  assign b_req = cpu_b_req;
  assign be_we = m_we; assign be_addr = m_addr; assign be_wdata = m_wdata; assign be_be = m_be;
  assign be_raw_vram = s_active;
  assign be_srt = !s_active && c_srt;
  // PERF (data lane): only the CPU master fetches.
  assign be_fetch = c_fetch;
  assign be_dma_palette = 16'd0;
  assign cpu_b_ack = b_ack;
  assign vd_addr = be_vd_addr; assign vd_din = be_vd_din; assign vd_be = be_vd_be;
  assign vd_rd = be_vd_rd; assign vd_wr = be_vd_wr; assign be_vd_ack = vd_ack;
  assign vd_count = 3'd1; assign vd_words = {48'd0,be_vd_din}; assign vd_reverse = 1'b0;
  assign dma_direct_ack = 1'b0; assign dma_direct_pixel = '0;
`endif

  revx_backends #(.SD_AW(SD_AW), .VSD_AW(VSD_AW), .ROM_SDBASE(ROM_SDBASE),
                  .SRT_WRITE_CHUNKS(SRT_WRITE_CHUNKS)) u_be (
    .clk(clk), .rst(reset), .rst_pon(por),
    .mem_req(b_req), .mem_we(be_we), .mem_addr(be_addr), .mem_be(be_be), .mem_wdata(be_wdata),
    .mem_raw_vram(be_raw_vram), .mem_srt(be_srt), .mem_fetch(be_fetch), .dma_palette(be_dma_palette),
    .dma_vram_snoop_we(dma_direct_ack), .dma_vram_snoop_addr(dma_direct_pixel),
    .mem_rdata(b_rdata), .mem_ack(b_ack),
`ifdef REVX_BLMOVE_BURST
    .bulk_ram_wr(wb2_req), .bulk_ram_addr({8'h20, wb2_addr[19:0], 4'd0}),
`endif
    .dl_wr(dl_wr_o), .dl_addr(dl_addr_o), .dl_din(dl_din_o), .dl_be(dl_be_o), .dl_ack(dl_ack),
    .sd_addr(sd_addr), .sd_din(sd_din), .sd_be(sd_be), .sd_rd(sd_rd), .sd_wr(sd_wr),
    .sd_dout(sd_dout), .sd_ack(sd_ack),
    .vd_addr(be_vd_addr), .vd_din(be_vd_din), .vd_be(be_vd_be), .vd_rd(be_vd_rd), .vd_wr(be_vd_wr),
    .vd_dout(vd_dout), .vd_ack(be_vd_ack),
    .wb_req(wb_req), .wb_addr(wb_addr), .wb_count(wb_count), .wb_data(wb_data), .wb_ack(wb_ack),
`ifdef REVX_BLMOVE_BURST
    .rb_req(be_rb_req), .rb_addr(be_rb_addr), .rb_count(be_rb_count), .rb_dout(be_rb_dout), .rb_ack(be_rb_ack),
`else
    .rb_req(rb_req), .rb_addr(rb_addr), .rb_count(rb_count), .rb_dout(rb_dout), .rb_ack(rb_ack),
`endif
`ifdef REVX_VRAM_LB
    .vlb_rb_req(be_vlb_rb_req), .vlb_rb_addr(be_vlb_rb_addr), .vlb_rb_count(be_vlb_rb_count),
    .vlb_rb_dout(be_vlb_rb_dout), .vlb_rb_ack(be_vlb_rb_ack),
`endif
    .vc_addr(vc_addr), .vc_din(vc_din), .vc_be(vc_be), .vc_rd(vc_rd), .vc_wr(vc_wr),
    .vc_dout(vc_dout), .vc_ack(vc_ack),
    .gfx_ddram_addr(gfx_ddram_addr), .gfx_ddram_burstcnt(gfx_ddram_burstcnt),
    .gfx_ddram_rd(gfx_ddram_rd), .gfx_ddram_we(gfx_ddram_we), .gfx_ddram_din(gfx_ddram_din),
    .gfx_ddram_be(gfx_ddram_be), .gfx_ddram_busy(gfx_ddram_busy),
    .gfx_ddram_dout(gfx_ddram_dout), .gfx_ddram_dout_ready(gfx_ddram_dout_ready),
    .gfx_dl_wr(lgfx_wr), .gfx_dl_addr(lgfx_addr), .gfx_dl_data(lgfx_data),
    .gfx_dl_ack(bgfx_ack), .gfx_dl_idle(bgfx_idle),
    .ioctl_download(ioctl_download), .ioctl_upload(ioctl_upload), .ioctl_wr(ioctl_wr),
    .ioctl_index(ioctl_index), .ioctl_addr(ioctl_addr), .ioctl_dout(ioctl_dout),
    .ioctl_din(ioctl_din), .ioctl_upload_req(ioctl_upload_req),
    .manual_save(manual_save), .clear_nvram(clear_nvram));

  // ---------------------------------------------------------------- ack/rdata merge (PAL vs I/O vs backends)
`ifdef REVX_EMU_INTEG
  assign m_ack   = is_pal ? pal_ack : is_io ? io_ack   : cpu_b_ack;
  assign m_rdata = is_pal ? {16'd0, pal_rd_a} : is_io ? io_rdata : b_rdata;

  // ---- CPU I/O peripheral bus (frontier d): ADC0848 + guns + UART/DCS + PIC + io_w +
  //      IN/DSW + SYSCTRL + DMA-32->16 split.  IO_ONLY=1 strips revx_mem's RAM/VRAM/PAL/CMOS
  //      behavioral arrays (served by revx_backends / the palette here) -> no dead M10K.
  revx_memsys #(.IO_ONLY(1), .EXTERNAL_DMA(1)) u_periph (
    .clk(clk), .rst(reset),
    .mem_req(m_req & is_io), .mem_we(m_we), .mem_addr(m_addr), .mem_be(m_be),
    .mem_wdata(m_wdata), .mem_rdata(io_rdata), .mem_ack(io_ack),
    .in0(in0), .in1(in1), .in2(in2), .dsw(dsw),
    .an0(an0), .an1(an1), .an2(an2), .an3(an3), .an4(an4), .an5(an5),
    .dcs_ctrl(dcs_ctrl), .dcs_data_in(dcs_data_in), .dcs_output_full(dcs_output_full),
    .dcs_data_w(dcs_data_w), .dcs_data_o(dcs_data_o), .dcs_data_rd(dcs_data_rd),
    .dcs_reset(dcs_reset), .lint1(dcs_lint1),
    .sysctrl0(sysctrl0), .sysctrl1(sysctrl1), .cmos_write_enable(cmos_write_enable),
    .gun_recoil(gun_recoil), .gun_led(gun_led), .watchdog_kick(watchdog_kick),
    .dbg_pic_status(dbg_pic_status), .dbg_uart_last(dbg_uart_last),
    .dbg_adc_chan(dbg_adc_chan), .dbg_adc_last(dbg_adc_last),
    .dma_reg_we(dma_reg_we), .dma_reg_addr(dma_reg_addr), .dma_reg_wdata(dma_reg_wdata),
    .dma_reg_pair(dma_reg_pair), .dma_pair_rdata(dma_pair_rdata),
    .gfx_rd(), .gfx_baddr(), .gfx_rdata(32'd0),
    .rom_rd(), .rom_waddr(), .rom_rdata(32'd0));

  // palette read port (for the emu's revx_scanout) + 34020 display-register taps
  assign pal_rd_data = pal_rd_b;
  assign disp_row    = core_disp_row;
  assign disp_col    = core_disp_col;
  assign disp_enable = core_disp_en;
`else
  assign m_ack   = is_pal ? pal_ack : b_ack;
  assign m_rdata = is_pal ? {16'd0, pal_rd_a} : b_rdata;
`endif

  // Palette reads wait for registered data; writes retain their old ack timing.
  always_ff @(posedge clk) begin
    if (reset) begin pal_ack <= 1'b0; pal_rd_wait <= 1'b0; end
    else begin
      pal_ack <= 1'b0;
      pal_rd_wait <= 1'b0;
      if (pal_rd_wait) pal_ack <= 1'b1;
      else if (m_req & is_pal & ~pal_ack) begin
        if (m_we) pal_ack <= 1'b1;
        else pal_rd_wait <= 1'b1;
      end
    end
  end

  // ---------------------------------------------------------------- scanout FSM body
  // VRAM(data) 32-bit word W = i0>>1 -> CPU bit address = W<<5 (region base 0x00000000)
  assign s_addr = {13'd0, scan_i0[14:1], 5'd0};
  always_ff @(posedge clk) begin
    if (reset) begin sc <= SC_IDLE; s_active <= 1'b0; s_req <= 1'b0; scan_done <= 1'b0; scan_pixel <= 15'd0; end
    else begin
      scan_done <= 1'b0;
      case (sc)
        SC_IDLE: if (scan_start) begin s_half <= scan_i0[0]; s_active <= 1'b1; s_req <= 1'b1; sc <= SC_RD; end
        SC_RD: begin
          s_req <= 1'b1;
          if (m_ack) begin
            s_req <= 1'b0;
            scan_word <= s_half ? m_rdata[31:16] : m_rdata[15:0]; // pick the 16-bit VRAM word
            sc <= SC_PAL;
          end
        end
        SC_PAL: begin
          sc <= SC_PAL2;
        end
        SC_PAL2: begin
          scan_pixel <= pal_rd_b[14:0]; // registered palette read
          s_active   <= 1'b0; scan_done <= 1'b1; sc <= SC_DONE;
        end
        SC_DONE: sc <= SC_IDLE;
        default: sc <= SC_IDLE;
      endcase
    end
  end

  // ---------------------------------------------------------------- capture (download) path, P0022
  // revx_loader demuxes the MRA index-0 byte stream (AUDIT.md s.3) into program ROM (word-packed
  // to the SDRAM boot-load port), gfx (-> backends gfx_dl -> DDR3), DCS (-> emu wolf_dcs_ddr_top),
  // and the parked PIC BRAM; plus the index-3 profile byte and the index-4 nvram audit.  It is
  // domained on the power-on reset (por), NOT the core reset, so ROM lands with reset held high.
  logic [31:0] drop_prog, drop_gfx, drop_dcs, drop_pic;
  revx_loader #(.SD_AW(SD_AW), .ROM_SDBASE(ROM_SDBASE)) u_loader (
    .clk(clk), .por(por), .core_rst(reset),
    .ioctl_download(ioctl_download), .ioctl_wr(ioctl_wr), .ioctl_index(ioctl_index),
    .ioctl_addr(ioctl_addr), .ioctl_dout(ioctl_dout),
    .dl_wr(dl_wr_o), .dl_addr(dl_addr_o), .dl_din(dl_din_o), .dl_be(dl_be_o), .dl_ack(dl_ack),
    .gfx_dl_wr(lgfx_wr), .gfx_dl_addr(lgfx_addr), .gfx_dl_data(lgfx_data), .gfx_dl_ack(bgfx_ack),
    .dcs_dl_wr(dcs_dl_wr), .dcs_dl_addr(dcs_dl_addr), .dcs_dl_data(dcs_dl_data), .dcs_dl_ack(dcs_dl_ack),
    .pic_rd_addr(lpic_rd_addr), .pic_rd_data(lpic_rd_data),
    .profile_byte(profile_byte), .profile_valid(profile_valid),
    .dl_wait(dl_wait), .dl_ready(dl_ready),
    .acc_prog(dbg_acc_prog), .acc_gfx(dbg_acc_gfx), .acc_dcs(dbg_acc_dcs),
    .acc_pic(), .acc_nvram(), .acc_profile(),
    .drop_prog(drop_prog), .drop_gfx(drop_gfx), .drop_dcs(drop_dcs), .drop_pic(drop_pic),
    .rst_during_dl(dbg_rst_during_dl),
    .smp_prog_addr(), .smp_prog_din(), .smp_prog_be(),
    .smp_gfx_addr(), .smp_gfx_data(), .smp_dcs_addr(), .smp_dcs_data());
  // drop_any (diag): the loader honours dl_wait so drops should stay 0; expose a coarse OR so the
  // overlay flags any upstream-break drop.  (Per-destination drops are also available above.)
  assign dbg_drop_any = {4'd0, (|drop_pic), (|drop_dcs), (|drop_gfx), (|drop_prog)};
  assign lpic_rd_addr = 13'd0;                 // parked PIC BRAM tap idle (adapter uses a table)

  // ---------------------------------------------------------------- boot-audit: last CPU fetch
  // Diagnostic tap ONLY (reads the CPU bus; does not drive it).  Latches the address + data of
  // the last completed CPU READ as the CPU received it -- the P0022/boot "what did the CPU get".
  always_ff @(posedge clk) begin
    if (reset) begin dbg_last_fetch_addr <= 32'd0; dbg_last_fetch_data <= 32'd0; end
    else if (c_req & ~c_we & c_ack) begin
      dbg_last_fetch_addr <= c_addr; dbg_last_fetch_data <= c_rdata;
    end
  end

  // The gameplay instrument retires the old boot/derail/postcal captures.
  // Keep their implementations available to historical standalone benches.
  generate if (QUIET_BOOT_DIAG) begin : g_no_boot_diag
    assign dbg_postcal_early = 0; assign dbg_postcal_final = 0;
    assign dbg_foreground_pc = 0; assign dbg_timers = 0;
    assign dbg_process_ptr = 0; assign dbg_watch_status = 0;
    assign dbg_culprit_pc = 0; assign dbg_culprit_instr = 0;
    assign dbg_target_pc = 0; assign dbg_last_good_pc = 0;
    assign dbg_derail_captured = 0; assign dbg_int_pc = 0;
    assign dbg_int_vec_addr = 0; assign dbg_int_vec_value = 0;
    assign dbg_int_count = 0; assign dbg_int_captured = 0;
  end else if (POSTCAL_DIAG) begin : g_postcal_diag
    revx_postcal_capture u_capture (
      .clk(clk), .rst(reset), .cpu_accept(cpu_retire), .cpu_pc(cpu_pc),
      .irq_entry(postcal_irq_begin), .irq_return(postcal_irq_return),
      .bus_req(c_req), .bus_we(c_we), .bus_ack(c_ack), .bus_fetch(c_fetch),
      .bus_addr(c_addr), .bus_wdata(c_wdata), .bus_rdata(c_rdata), .bus_be(c_be),
      .early_sample(dbg_postcal_early), .final_sample(dbg_postcal_final));
    // The cabinet view no longer consumes the boot/derail/timer overlay taps.
    // Keep these ports for existing standalone benches; no legacy capture
    // hardware is instantiated in the POSTCAL_DIAG production configuration.
    assign dbg_foreground_pc = 0;
    assign dbg_timers = 0;
    assign dbg_process_ptr = 0;
    assign dbg_watch_status = 0;
    assign dbg_culprit_pc = 0;
    assign dbg_culprit_instr = 0;
    assign dbg_target_pc = 0;
    assign dbg_last_good_pc = 0;
    assign dbg_derail_captured = 0;
    assign dbg_int_pc = 0;
    assign dbg_int_vec_addr = 0;
    assign dbg_int_vec_value = 0;
    assign dbg_int_count = 0;
    assign dbg_int_captured = 0;
  end else begin : g_legacy_diag
  assign dbg_postcal_early = 0;
  assign dbg_postcal_final = 0;
  revx_timer_capture u_timer_capture (
    .clk(clk), .rst(reset), .cpu_retire(cpu_retire), .cpu_pc(cpu_pc),
    .bus_req(c_req), .bus_we(c_we), .bus_ack(c_ack),
    .bus_addr(c_addr), .bus_wdata(c_wdata), .bus_be(c_be),
    .foreground_pc(dbg_foreground_pc), .timers(dbg_timers),
    .process_ptr(dbg_process_ptr), .watch_status(dbg_watch_status));

  // ---------------------------------------------------------------- DIAG v2 derail capture
  // On-chip DERAIL + FIRST-INTERRUPT instrument (DESIGN-RULES.md s.6 screen-as-LA).  Runs on the CPU
  // clock, samples cpu_retire (full rate) + the core interrupt-entry taps, freezes on the first
  // hit, clears only on core reset.  Feeds the REVX_DIAG_BOOT overlay via the dbg_* ports.
  revx_derail_capture u_derail (
    .clk(clk), .rst(reset),
    .cpu_retire(cpu_retire), .cpu_pc(cpu_pc), .cpu_instr(cpu_instr),
    .int_entry(cdbg_int_entry), .int_pc(cdbg_int_pc),
    .int_vec_addr(cdbg_int_vec_addr), .int_vec_value(cdbg_int_vec_value),
    .culprit_pc(dbg_culprit_pc), .culprit_instr(dbg_culprit_instr), .target_pc(dbg_target_pc),
    .last_good_pc(dbg_last_good_pc), .derail_captured(dbg_derail_captured),
    .int_interrupted_pc(dbg_int_pc), .int_vec_addr_q(dbg_int_vec_addr),
    .int_vec_value_q(dbg_int_vec_value), .int_count(dbg_int_count), .int_captured(dbg_int_captured));
  end endgenerate
  // live io-register views (not frozen -- current values)
  assign dbg_intpend  = cdbg_intpend;
  assign dbg_intenb   = cdbg_intenb;
  assign dbg_disp_int = cdbg_disp_int;
  assign dbg_st_ie    = cdbg_st_ie;
endmodule
`default_nettype wire
