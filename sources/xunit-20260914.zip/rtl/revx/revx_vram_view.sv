// X-unit VRAM byte views over one canonical 0x80000 x 16-bit pixel store.
// MAME 0.289 midtunit_v.cpp:196,281-321: CPU data bytes select pixel low
// bytes and inject alternating DMA_PALETTE bytes; color bytes select only
// pixel high bytes. DMA/diagnostic requests instead address full pixels.
// The physical SDRAM word base is supplied by the existing outer arbiter.
`timescale 1ns/1ps
`default_nettype none
module revx_vram_view #(
  parameter int SD_AW = 19,
  parameter bit SRT_WRITE_CHUNKS = 1'b0
)(
  input logic clk, rst,
  input logic req, we, raw_mode, color_mode,
  input logic srt_mode,
  input logic [31:0] addr, wdata,
  input logic [3:0] be,
  input logic [15:0] palette,
  // Committed full-pixel writes from the independent DMA word port.
  // Older standalone callers may leave this unused input open.
  input logic dma_snoop_we,
  input logic [18:0] dma_snoop_addr,
  output logic [31:0] rdata,
  output logic done, active,
  output logic [SD_AW-1:0] sd_addr,
  output logic [15:0] sd_din,
  output logic [1:0] sd_be,
  output logic sd_rd, sd_wr,
  input logic [15:0] sd_dout,
  input logic sd_ack,
  // Optional full-pixel write chunks. One held request retires 1..16 words;
  // completion includes SDRAM write recovery. Scalar ports stay idle meanwhile.
  output logic wb_req,
  output logic [SD_AW-1:0] wb_addr,
  output logic [6:0] wb_count,
  output logic [1023:0] wb_data,
  input logic wb_ack
`ifdef REVX_VRAM_LB
  // PERF (pixel-op lane v2): read-chunk fill port for the VRAM line buffer.
  // Same held-request contract as the arb's rb: 16 ascending pixel words,
  // packed little-endian (word[0] = the lowest address in bits[15:0]).
  ,output logic        vlb_rb_req
  ,output logic [SD_AW-1:0] vlb_rb_addr
  ,output logic [4:0]  vlb_rb_count
  ,input  logic [255:0] vlb_rb_dout
  ,input  logic        vlb_rb_ack
`endif
);
  typedef enum logic [3:0] {IDLE, PICK, WAIT_WORD, GAP, FINISH,
                            SRT_PREFETCH, SRT_ISSUE, SRT_WAIT,
                            CHUNK_SETUP, CHUNK_PREFETCH, CHUNK_GATHER,
                            CHUNK_WAIT, CHUNK_GAP, HIT_LANE, VLB_WAIT} state_t;
  state_t state;
  logic we_q, raw_q, color_q, srt_q;
  logic [18:0] base_q;
  logic [31:0] data_q;
  logic [15:0] palette_q;
  logic [3:0] be_q;
  logic [1:0] lane_q;
  // MAME midtunit_v.cpp:330-339: each graphics shift-register callback
  // copies 1024 FULL pixel entries beginning at bit_address >> 3. This is
  // neither the packed CPU byte view nor the raw DMA bit_address >> 4 view.
  // The real game loads rows 510/511, then FILL XY restores that row pair.
  // Keep the palette bytes in a synchronous M10K buffer; do not reset RAM.
  (* ramstyle = "no_rw_check, M10K" *) logic [15:0] srt_buf [0:1023];
  logic [9:0] srt_idx;
  logic [15:0] srt_data_q;
  wire [18:0] srt_pixel = base_q + {9'd0,srt_idx};
`ifdef REVX_SRT_SHORT_MUT
  localparam int SRT_LENGTH = 1023;
`else
  localparam int SRT_LENGTH = 1024;
`endif
  wire srt_last = srt_idx == 10'(SRT_LENGTH-1);
  logic [9:0] chunk_read_idx;
  logic [6:0] chunk_gather_idx;
  wire [9:0] srt_read_idx = SRT_WRITE_CHUNKS ? chunk_read_idx : srt_idx;
  function automatic [6:0] length_at(input logic [10:0] index);
    logic [8:0] column;
    logic [10:0] remain;
    logic [5:0] row_words;
    logic row_short, tail_short;
    begin
      // Only the physical column affects the 512-word row boundary. A
      // row can shorten a cap64 packet only at columns 449..511. There,
      // 512-column is the six-bit two's complement of column[5:0].
      column=base_q[8:0]+index[8:0];
      remain=11'(SRT_LENGTH)-index;
      row_words=6'd0-column[5:0];
      row_short=(&column[8:6]) && (|column[5:0]);
`ifdef REVX_SRT_CHUNK_ROW_MUT
      row_short=1'b0;
`endif
      tail_short=remain[10:6]==5'd0;
      if(row_short && (!tail_short || row_words<remain[5:0]))
        length_at={1'b0,row_words};
      else if(tail_short)length_at={1'b0,remain[5:0]};
      else length_at=7'd64;
    end
  endfunction
  wire [6:0] chunk_length=length_at({1'b0,srt_idx});
  // The prefix path starts at index 0 and both supported SRT lengths
  // (1024, or the short-transfer negative's 1023) exceed two cap64 packets.
  // Its second packet is row-limited only when base is at columns 385..447:
  // the first packet adds 64. A shortened first packet instead reaches the
  // next row's column 0. Compute this directly, not length_at(length_at(0)).
  wire [5:0] second_row_words=6'd0-base_q[5:0];
`ifdef REVX_SRT_CHUNK_ROW_MUT
  wire [6:0] second_chunk_length=7'd64;
`else
  wire [6:0] second_chunk_length=(base_q[8:6]==3'd6 && (|base_q[5:0]))
      ? {1'b0,second_row_words} : 7'd64;
`endif
  wire [10:0] chunk_next={1'b0,srt_idx}+{4'd0,wb_count};
  logic [1023:0] next_data,prefix_data;
  logic [10:0] next_start;
  logic [6:0] next_count,next_gather;
  logic [1:0] next_phase;
  logic next_valid,prefix_valid;
  logic srt_rb_req;
  logic [SD_AW-1:0] srt_rb_addr;
  logic [4:0] srt_rb_count,srt_rb_drain;
  logic [255:0] srt_rb_data;
  logic srt_rb_draining;
`ifdef REVX_VRAM_LB
  localparam bit SRT_READ_BURSTS=1;
  wire srt_rb_ack=vlb_rb_ack;
  wire [255:0] srt_rb_payload=vlb_rb_dout;
`else
  localparam bit SRT_READ_BURSTS=0;
  wire srt_rb_ack=0;
  wire [255:0] srt_rb_payload=0;
`endif
  wire [15:0] srt_in_word=srt_rb_draining?srt_rb_data[15:0]:sd_dout;
  wire srt_store=(state==SRT_WAIT)&&!we_q&&
      (srt_rb_draining || (!SRT_READ_BURSTS && sd_ack));
  always_ff @(posedge clk) begin
    if(srt_store) begin
`ifdef SRT_REVERSE_SOURCE
      srt_buf[srt_idx]<=srt_rb_draining?srt_rb_data[31:16]:sd_dout;
`else
      srt_buf[srt_idx]<=srt_in_word;
`endif
    end
    srt_data_q<=srt_buf[srt_read_idx];
  end
  task automatic start_next(input logic [10:0] index, input logic [6:0] count);
    begin
      next_start<=index; next_count<=count; next_gather<=0;
      chunk_read_idx<=index[9:0]; next_phase<=1; next_valid<=0;
    end
  endtask
  // CPU bases are 4-pixel aligned (lanes 0..3), raw bases are 2-pixel
  // aligned (lanes 0..1), and SRT holds lane_q at zero. Thus this low
  // addition cannot carry into bit 2 in any reachable transaction. Keep
  // lane selection out of the cache set/tag carry chain, without a stage.
  wire [1:0] pixel_lane = base_q[1:0] + lane_q;
  wire [18:0] pixel = {base_q[18:2],pixel_lane};
  wire last_lane = raw_q ? (lane_q == 2'd1) : (lane_q == 2'd3);
  wire [1:0] raw_be = lane_q[0] ? be_q[3:2] : be_q[1:0];
  wire [7:0] cpu_byte = data_q[8*lane_q +: 8];
`ifdef REVX_VRAM_PALETTE_SWAP_MUT
  wire [7:0] color_byte = pixel[0] ? palette_q[7:0] : palette_q[15:8];
`else
  wire [7:0] color_byte = pixel[0] ? palette_q[15:8] : palette_q[7:0];
`endif
  assign active = state != IDLE;

`ifdef REVX_VRAM_LB
  // ==== pixel-op lane (v2): VRAM read line buffer =======================
  // 128 sets x 2 ways x 16 pixel words x 16 bits = 8 KiB M10K. The tag is
  // pixel[18:11], the set is pixel[10:4], the word is pixel[3:0] -- the same
  // geometry family as the fetch/data line buffers. FULL-RATE logic: this
  // module has no CPU clock enable. A miss stalls the lane for ONE demand
  // fill, with no duplicate scalar read or speculative background traffic.
  // Every VRAM
  // writer (scalar sd_wr, SRT sd_wr, SRT write chunk) invalidates its lines.
  // Fill and write transactions are serialized by this engine; publication
  // occurs only after all 16 words have landed. No partial line is visible.
  localparam int VLB_SET_BITS = 7;
  // flat 2x128x16 array (iverilog 12 cannot index 3-D unpacked arrays with
  // dynamic indices; the fetch/data LBs use the same flat shape)
  (* ramstyle = "no_rw_check, M10K" *) logic [15:0] vlb_mem [0:4095];
  logic vlb_valid [2][1<<VLB_SET_BITS];
  logic [7:0]  vlb_tag  [2][1<<VLB_SET_BITS];
  logic [(1<<VLB_SET_BITS)-1:0] vlb_lru;   // 0 = way 0 most recent
  wire [VLB_SET_BITS-1:0] vlb_set  = pixel[VLB_SET_BITS+3:4];
  wire [7:0]              vlb_ntag = pixel[18:11];
  wire vlb_hit0 = vlb_valid[0][vlb_set] && (vlb_tag[0][vlb_set] == vlb_ntag);
  wire vlb_hit1 = vlb_valid[1][vlb_set] && (vlb_tag[1][vlb_set] == vlb_ntag);
  wire vlb_hit  = vlb_hit0 || vlb_hit1;
  wire [11:0] vlb_ridx = {vlb_hit1, vlb_set, pixel[3:0]};
  // Registered read (the M10K sync-read pattern, the same as the fetch/data
  // LBs): the word is available one cycle after the address, absorbed by the
  // HIT_LANE state (see the PICK branch).
  logic [15:0] vlb_word_q;
  always_ff @(posedge clk) vlb_word_q <= vlb_mem[vlb_ridx];
  // fill side-channel state. The 16-word payload drains ONE word per clock
  // through a single flat-indexed write port (the fetch/data-LB pattern): a
  // 16-way same-cycle fanout does NOT infer to an M10K (it cost 66K extra
  // flip-flops and a fit failure at 6508 vs 4191 LABs).
  logic             vlb_fill_req, vlb_fill_way;
  logic [VLB_SET_BITS-1:0] vlb_fill_set;
  logic [18:0]      vlb_fill_line;      // canonical pixel word address, low 4 bits zero
  logic             vlb_draining;       // drain in progress (req already acked)
  logic             vlb_fill_dirty;     // DMA committed while this fill was pending
  logic [3:0]       vlb_drain_k;        // drain slot 0..15
  logic [255:0]     vlb_fill_data;      // latched ack payload, shifted as it drains
  // flat pre-computed write index (never a concatenation at the write port)
  wire [11:0] vlb_waddr = {vlb_fill_way, vlb_fill_set, vlb_drain_k};
  wire [SD_AW-1:0] vlb_fill_addr = SD_AW'(vlb_fill_line);
  wire vlb_victim = !vlb_valid[0][vlb_set] ? 1'b0 :
                    !vlb_valid[1][vlb_set] ? 1'b1 : ~vlb_lru[vlb_set];
  wire [18:0] write_pixel = state == SRT_ISSUE ? srt_pixel : pixel;
  wire [VLB_SET_BITS-1:0] write_set = write_pixel[VLB_SET_BITS+3:4];
  // a scalar write invalidates its line; a chunk write invalidates the start
  // and end lines (the chunk spans at most two 16-word lines)
  wire [VLB_SET_BITS-1:0] wb_start_set = wb_addr[VLB_SET_BITS+3:4];
  wire [VLB_SET_BITS+3:0] wb_end_addr = wb_addr[VLB_SET_BITS+3:0] + {{(VLB_SET_BITS-3){1'b0}},wb_count} - 1'b1;
  wire [VLB_SET_BITS-1:0] wb_end_set   = wb_end_addr[VLB_SET_BITS+3:4];
  wire dma_snoop = dma_snoop_we === 1'b1;
  wire [VLB_SET_BITS-1:0] dma_snoop_set = dma_snoop_addr[VLB_SET_BITS+3:4];

  assign vlb_rb_req   = vlb_fill_req || srt_rb_req;
  assign vlb_rb_addr  = srt_rb_req?srt_rb_addr:vlb_fill_addr;
  assign vlb_rb_count = srt_rb_req?srt_rb_count:5'd16;

  // Full-rate single-port fill drain, tags, and write invalidation.
  always_ff @(posedge clk) begin
    if (rst) begin
      for (int w=0; w<2; w++) begin
        for (int s=0; s<(1<<VLB_SET_BITS); s++) vlb_valid[w][s] <= 1'b0;
      end
      vlb_lru <= '0;
      vlb_fill_req <= 1'b0;
      vlb_draining <= 1'b0; vlb_drain_k <= 4'd0;
      vlb_fill_way <= 0; vlb_fill_set <= '0; vlb_fill_line <= '0;
      vlb_fill_dirty <= 1'b0;
    end else begin
`ifndef MUT_VLB_STALE
      // scalar-write invalidation (the PICK's accessing write lanes + the SRT scalar writes)
      if ((state == PICK && we_q && (raw_q ? (|raw_be) : be_q[lane_q])) ||
          (state == SRT_ISSUE && we_q)) begin
        vlb_valid[0][write_set] <= 1'b0;
        vlb_valid[1][write_set] <= 1'b0;
      end
      // SRT chunk-write invalidation (both lines the chunk can touch)
      if (state == CHUNK_WAIT && wb_ack) begin
`ifdef SRT_INVALIDATE_ENDPOINTS_ONLY
        vlb_valid[0][wb_start_set]<=0;vlb_valid[1][wb_start_set]<=0;
        vlb_valid[0][wb_end_set]<=0;vlb_valid[1][wb_end_set]<=0;
`else
        // A64-word unaligned chunk can touch five16-word cache sets.
        for(integer k=0;k<5;k=k+1) if(k<=(( {7'd0,wb_addr[3:0]}+{4'd0,wb_count}-1)>>4)) begin
          vlb_valid[0][7'(wb_start_set+k)]<=0;
          vlb_valid[1][7'(wb_start_set+k)]<=0;
        end
`endif
      end
`endif
      // fill ack: latch the payload, then drain it one word per clock through
      // the single flat-indexed write port. Tag/valid/LRU publish on the LAST
      // drain word. The stalled request cannot launch a writer during a fill.
      if (vlb_fill_req && vlb_rb_ack) begin
        vlb_fill_req  <= 1'b0;
        vlb_draining  <= 1'b1;
        vlb_drain_k   <= 4'd0;
        vlb_fill_data <= vlb_rb_dout;
      end else if (vlb_draining) begin
`ifdef MUT_VLB_FILL_REVERSE
        // MUTANT: the fill lands reversed -> the line serves permuted words.
        // MUST be killed by the byte-identity checks.
        vlb_mem[vlb_waddr] <= vlb_fill_data[255:240];
        vlb_fill_data <= {vlb_fill_data[239:0], 16'd0};
`else
        vlb_mem[vlb_waddr] <= vlb_fill_data[15:0];
        vlb_fill_data <= {16'd0, vlb_fill_data[255:16]};
`endif
        if (vlb_drain_k == 4'd15) begin
          vlb_tag [vlb_fill_way][vlb_fill_set] <= vlb_fill_line[18:11];
          // A pre-write refill must never resurrect a stale cache line.
          vlb_valid[vlb_fill_way][vlb_fill_set] <= !vlb_fill_dirty;
          vlb_lru[vlb_fill_set] <= vlb_fill_way;
          vlb_draining <= 1'b0;
        end else begin
          vlb_drain_k <= vlb_drain_k + 1'b1;
        end
      end
      // hit-side LRU update (HIT_LANE: the way that served becomes MRU; the
      // SINGLE driver block for vlb_lru -- the drain publish above is the only
      // other writer, same block)
      if (state == HIT_LANE) vlb_lru[vlb_set] <= vlb_hit1;
      // Demand miss: invalidate the chosen victim BEFORE overwriting its RAM.
      // Preserve the complete canonical address so tag and refill address use
      // the same units even above pixel 0x7ff and at the top of VRAM.
      if (state == PICK && !we_q && !srt_q && !vlb_hit && !vlb_fill_req &&
          !vlb_draining) begin
        vlb_fill_req  <= 1'b1;
        vlb_fill_set  <= vlb_set;
        vlb_fill_line <= {pixel[18:4],4'd0};
        vlb_fill_way  <= vlb_victim;
        vlb_fill_dirty <= 1'b0;
      end
      // The miss already entered VLB_WAIT and latched these coordinates.
      // Clear the victim on the request edge, before the first fill RAM
      // write, without putting the full miss/victim mux on every valid bit.
      // ACK may arrive on this edge; its payload starts draining next edge.
      if (vlb_fill_req)
        vlb_valid[vlb_fill_way][vlb_fill_set] <= 1'b0;
`ifndef MUT_VLB_DMA_SNOOP
      // Last assignment wins over fill publication on the same clock. A
      // write during earlier drain clocks also suppresses later publication.
      if (dma_snoop) begin
        vlb_valid[0][dma_snoop_set] <= 1'b0;
        vlb_valid[1][dma_snoop_set] <= 1'b0;
        if ((vlb_fill_req || vlb_draining) && dma_snoop_set == vlb_fill_set)
          vlb_fill_dirty <= 1'b1;
      end
`endif
    end
  end
`endif

  always_ff @(posedge clk) begin
    if (rst) begin
      state <= IDLE; done <= 0; rdata <= 0;
      sd_rd <= 0; sd_wr <= 0; sd_addr <= 0; sd_din <= 0; sd_be <= 0;
      we_q <= 0; raw_q <= 0; color_q <= 0; srt_q <= 0; base_q <= 0;
      srt_idx <= 0;
      chunk_read_idx<=0;chunk_gather_idx<=0;next_data<=0;prefix_data<=0;
      next_start<=0;next_count<=0;next_gather<=0;next_phase<=0;next_valid<=0;prefix_valid<=0;
      srt_rb_req<=0;srt_rb_addr<=0;srt_rb_count<=0;srt_rb_drain<=0;srt_rb_data<=0;srt_rb_draining<=0;
      wb_req <= 0; wb_addr <= 0; wb_count <= 0; wb_data <= 0;
      data_q <= 0; palette_q <= 0; be_q <= 0; lane_q <= 0;
    end else begin
      done<=0;
      if(srt_store && srt_idx<64) begin
`ifdef SRT_PREFIX_CORRUPT
        prefix_data[16*srt_idx[5:0]+:16]<=srt_in_word^16'h0001;
`else
        prefix_data[16*srt_idx[5:0]+:16]<=srt_in_word;
`endif
      end
      // Read the next chunk through the original single synchronous RAM port
      // while current wb_addr/count/data remain stable until physical ACK.
      if(next_phase==1) begin
        chunk_read_idx<=next_start[9:0]+1'b1;next_phase<=2;
      end else if(next_phase==2) begin
        next_data[16*next_gather[5:0]+:16]<=srt_data_q;
        if(next_gather+1'b1==next_count)begin next_valid<=1;next_phase<=0;end
        else begin next_gather<=next_gather+1'b1;chunk_read_idx<=chunk_read_idx+1'b1;end
      end
      case (state)
        IDLE: if (req && !done) begin
          we_q <= we; raw_q <= raw_mode; color_q <= color_mode;
          // Raw bus words contain two full pixels; CPU bus words contain
          // four data/color bytes. No 18-bit wrap: DMA X spill uses bit18.
          base_q <= raw_mode ? {addr[22:5],1'b0} : {addr[21:5],2'b00};
          data_q <= wdata; palette_q <= palette; be_q <= be;
          lane_q <= 0; rdata <= 0; state <= PICK;
          srt_q <= 1'b0;
`ifndef REVX_SRT_DROP_MUT
          // Legacy/direct-view callers may leave the new qualifier open.
          if (srt_mode === 1'b1) begin
            srt_q <= 1'b1; srt_idx <= 0; state <= SRT_PREFETCH;
            next_phase<=0;next_valid<=0;if(!we)prefix_valid<=0;
`ifdef REVX_SRT_ADDR_HALF_MUT
            base_q <= addr[22:4];
`else
            base_q <= addr[21:3];
`endif
          end
`endif
        end
        PICK: begin
          if (we_q && !(raw_q ? (|raw_be) : be_q[lane_q])) begin
            if (last_lane) state <= FINISH;
            else lane_q <= lane_q + 1'b1;
          end else begin
`ifdef REVX_VRAM_RAW_WRAP_MUT
            sd_addr <= SD_AW'({1'b0,pixel[17:0]});
`else
            sd_addr <= SD_AW'(pixel);
`endif
            if (raw_q) begin
              sd_din <= lane_q[0] ? data_q[31:16] : data_q[15:0];
              sd_be <= raw_be;
            end else if (color_q) begin
              sd_din <= {cpu_byte,8'd0};
`ifdef REVX_VRAM_COLOR_ALIAS_MUT
              sd_be <= 2'b01;
`else
              sd_be <= 2'b10;
`endif
            end else begin
              sd_din <= {color_byte,cpu_byte};
              sd_be <= 2'b11;
            end
`ifdef REVX_VRAM_LB
            if (!we_q && !srt_q) begin
              // serve the lane from the line buffer in the next state (the
              // registered vlb read lands there) -- no SDRAM word at all
              state <= vlb_hit ? HIT_LANE : VLB_WAIT;
            end else begin
`endif
              sd_rd <= !we_q; sd_wr <= we_q;
              state <= WAIT_WORD;
`ifdef REVX_VRAM_LB
            end
`endif
          end
        end
`ifdef REVX_VRAM_LB
        VLB_WAIT: if (!vlb_fill_req && !vlb_draining && !vlb_rb_ack) state <= PICK;
        HIT_LANE: begin
          // the registered vlb read holds THIS pixel's word; assemble and
          // advance without touching the SDRAM
          if (raw_q) rdata[16*lane_q[0] +: 16] <= vlb_word_q;
          else rdata[8*lane_q +: 8] <= color_q ? vlb_word_q[15:8] : vlb_word_q[7:0];
          if (last_lane) state <= FINISH;
          else begin lane_q <= lane_q + 1'b1; state <= GAP; end
        end
`endif
        WAIT_WORD: if (sd_ack) begin
          sd_rd <= 0; sd_wr <= 0;
          if (!we_q) begin
            if (raw_q) rdata[16*lane_q[0] +: 16] <= sd_dout;
            else rdata[8*lane_q +: 8] <= color_q ? sd_dout[15:8] : sd_dout[7:0];
          end
          if (last_lane) state <= FINISH;
          else begin lane_q <= lane_q + 1'b1; state <= GAP; end
        end
        // A gap waits for the old ACK to deassert before a new SDRAM word.
        GAP: if (!sd_ack) state <= srt_q ? SRT_PREFETCH : PICK;
        SRT_PREFETCH: begin
          if(SRT_WRITE_CHUNKS && we_q)state<=CHUNK_SETUP;
          else if(SRT_READ_BURSTS && !we_q)begin
            srt_rb_addr<=SD_AW'(srt_pixel);
            srt_rb_count<=(length_at({1'b0,srt_idx})<16)?5'(length_at({1'b0,srt_idx})):5'd16;
            srt_rb_req<=1;srt_rb_draining<=0;state<=SRT_WAIT;
          end else state<=SRT_ISSUE;
        end
        SRT_ISSUE: begin
          sd_addr <= SD_AW'(srt_pixel);
`ifdef REVX_SRT_COLOR_LOSS_MUT
          sd_din <= {8'd0,srt_data_q[7:0]};
`else
          sd_din <= srt_data_q;
`endif
          sd_be <= 2'b11;
          sd_rd <= !we_q; sd_wr <= we_q; state <= SRT_WAIT;
        end
        SRT_WAIT: begin
          if(SRT_READ_BURSTS && !we_q)begin
            if(srt_rb_req && srt_rb_ack)begin
              srt_rb_data<=srt_rb_payload;srt_rb_req<=0;srt_rb_draining<=1;srt_rb_drain<=0;
            end else if(srt_rb_draining)begin
              if(srt_idx==0)rdata<={16'd0,srt_in_word};
              srt_rb_data<={16'd0,srt_rb_data[255:16]};
              if(srt_last)begin srt_rb_draining<=0;prefix_valid<=1;state<=FINISH;end
              else begin
                srt_idx<=srt_idx+1'b1;srt_rb_drain<=srt_rb_drain+1'b1;
                if(srt_rb_drain+1'b1==srt_rb_count)begin srt_rb_draining<=0;state<=GAP;end
              end
            end
          end else if(sd_ack)begin
            sd_rd<=0;sd_wr<=0;
            if(!we_q&&srt_idx==0)rdata<={16'd0,sd_dout};
            if(srt_last)begin prefix_valid<=!we_q;state<=FINISH;end
            else begin srt_idx<=srt_idx+1'b1;state<=GAP;end
          end
        end
        CHUNK_SETUP: begin
          wb_addr<=SD_AW'(srt_pixel);wb_count<=chunk_length;
          // Prefix contents are captured during the source load, once per
          // row snapshot, not gathered again for every FILL destination.
          if(srt_idx==0 && prefix_valid)begin
            wb_data<=prefix_data;wb_req<=1;state<=CHUNK_WAIT;
`ifndef SRT_DISABLE_OVERLAP
            if(chunk_length<SRT_LENGTH)start_next({4'd0,chunk_length},second_chunk_length);
`endif
          end else begin
            chunk_read_idx<=srt_idx;chunk_gather_idx<=0;state<=CHUNK_PREFETCH;
          end
        end
        CHUNK_PREFETCH: begin chunk_read_idx<=srt_idx+1'b1;state<=CHUNK_GATHER;end
        CHUNK_GATHER: begin
          wb_data[16*chunk_gather_idx[5:0]+:16]<=srt_data_q;
          if(chunk_gather_idx+1'b1==wb_count)begin
            wb_req<=1;state<=CHUNK_WAIT;
`ifndef SRT_DISABLE_OVERLAP
            if(chunk_next<SRT_LENGTH)start_next(chunk_next,length_at(chunk_next));
`endif
          end else begin chunk_gather_idx<=chunk_gather_idx+1'b1;chunk_read_idx<=chunk_read_idx+1'b1;end
        end
        CHUNK_WAIT: if(wb_ack)begin
          wb_req<=0;
          if(chunk_next==SRT_LENGTH)state<=FINISH;
          else begin
            srt_idx<=chunk_next[9:0];state<=CHUNK_GAP;
`ifdef SRT_DISABLE_OVERLAP
            start_next(chunk_next,length_at(chunk_next));
`endif
          end
        end
        CHUNK_GAP: if(!wb_ack&&next_valid)begin
          wb_addr<=SD_AW'(base_q+next_start);wb_count<=next_count;wb_data<=next_data;
          wb_req<=1;state<=CHUNK_WAIT;next_valid<=0;
`ifndef SRT_DISABLE_OVERLAP
          if(next_start+next_count<SRT_LENGTH)start_next(next_start+next_count,length_at(next_start+next_count));
`endif
        end
        FINISH: begin done <= 1; state <= IDLE; end
        default: state <= IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
