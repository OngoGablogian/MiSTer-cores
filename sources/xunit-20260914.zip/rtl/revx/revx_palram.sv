// Two registered read ports sharing one M10K store. Port A writes or reads;
// port B reads independently. There is no reset on the memory or read registers.
// Cyclone V mixed-port collisions are bypassed explicitly with the new word.
// Palette: A = CPU, B = scanout. CMOS: A = shared writes / upload, B = CPU read.
`default_nettype none
module revx_palram #(
  parameter int DW = 16,
  parameter int AW = 15,
  parameter bit USE_FWD = 1'b1
)(
  input logic clk,
  input logic we_a,
  input logic [AW-1:0] addr_a,
  input logic [DW-1:0] wd_a,
  output logic [DW-1:0] rd_a,
  input logic [AW-1:0] addr_b,
  output logic [DW-1:0] rd_b
);
  localparam int DEPTH = 1 << AW;
  (* ramstyle = "no_rw_check, M10K" *) logic [DW-1:0] mem [0:DEPTH-1];
`ifdef REVX_PALRAM_ASYNC_MUT
  // The timing gate must reject the original asynchronous-read failure shape.
  always_ff @(posedge clk) if (we_a) mem[addr_a] <= wd_a;
  assign rd_a = mem[addr_a];
  assign rd_b = mem[addr_b];
`else
  // Registered write port (TIMING): capture the port-A write command (we_a/addr_a/wd_a) one
  // clock and apply the M10K write from the registered copy, so the M10K data-in (porta_datain)
  // launches from these LOCAL registers instead of the far CPU launch register.  This module is
  // the RevX palette in revx_top; the -2.03 ns porta_datain path ran from the mem_if launch reg
  // (u_mif|sz_q) through m_wdata into wd_a.  The write lands ONE clock later; revx_top holds
  // m_req through its (unchanged) palette-write ack and no consumer reads the entry in that gap
  // -- CPU read-back is serialized through the 2-cycle port-A read + cpu_ce, and the scanout
  // reads port B via the collision-forwarding below (aligned to the delayed write) -- so the +1
  // write latency is invisible.  Port A still does exactly one thing per clock (write when we_a_q,
  // else read) -> unchanged single read/write M10K inference (no async read; ramstyle retained).
  logic          we_a_q;
  logic [AW-1:0] addr_a_q;
  logic [DW-1:0] wd_a_q;
  always_ff @(posedge clk) begin
    we_a_q   <= we_a;
    addr_a_q <= addr_a;
    wd_a_q   <= wd_a;
  end
  always_ff @(posedge clk) begin
    if (we_a_q) mem[addr_a_q] <= wd_a_q;
    else rd_a <= mem[addr_a];
  end
  logic [DW-1:0] rd_b_mem;
  logic fwd_hit_q;
  logic [DW-1:0] fwd_data_q;
  always_ff @(posedge clk) begin
    rd_b_mem <= mem[addr_b];
    // forward the REGISTERED write to a colliding port-B read (aligned with the delayed write)
    fwd_hit_q <= USE_FWD && we_a_q && (addr_a_q == addr_b);
    fwd_data_q <= wd_a_q;
  end
  assign rd_b = fwd_hit_q ? fwd_data_q : rd_b_mem;
`endif
endmodule
`default_nettype wire
