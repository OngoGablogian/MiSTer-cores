// revx_memsys.sv -- Midway X-unit (Revolution X) memory subsystem.
//
// FORK of rtl/wolf/wolf_memsys.sv.  Same structural role: the single slave the CPU
// talks to.  It instantiates revx_mem (X-unit decode, 32-bit bus) and wires the
// device-region taps to the X-unit peripherals:
//   * revx_pic_adapter  (security PIC, midxunit.cpp:456-472)
//   * revx_adc0848      (pots/guns, midxunit.cpp:521 / adc0844.cpp)
//   * revx_uart         (DCS host UART, midxunit.cpp:296-400)
// and splits the 32-bit DMA register window into the pair of 16-bit blitter-register
// writes MAME does (midxunit.cpp:494-499 dma_w: video->dma_w(off*2,lo);
// video->dma_w(off*2+1,hi)).  The 16-bit blitter register port is EXPOSED for the
// (fork-pending) wolf_dma instantiation; a local shadow gives the CPU read-back.
//
// DELTAS vs the Wolf donor: 32-bit CPU bus (mem_be[3:0] vs mem_size); X-unit map;
// PIC via revx_pic_adapter (split command/clock taps) instead of wolf_pic direct;
// ADC0848 + UART are NEW (Wolf had neither); SND_RESET (SYSCTRL1[1]) resets the DCS
// ONLY -- NOT the PIC (P0020: midxunit.cpp:262 resets only m_dcs; the PIC16C57 reset
// line is unmodeled, midxunit.cpp:679).  The SDRAM/DDR3 RAM/VRAM/gfx/ROM backends and the wolf_dma
// blitter are NOT yet forked -- that is the reported frontier (see AUDIT.md); here
// RAM/VRAM/CMOS/PAL are revx_mem's behavioral models and gfx/prog ROM are taps.

`default_nettype none

module revx_memsys #(
    parameter int ADC_CONV_CLKS = 16,
    // IO_ONLY=1 (emu deployment): revx_mem decodes ONLY the I/O windows; its RAM/VRAM/PAL/CMOS
    // arrays shrink to 1 entry (those regions are served by revx_backends / the top's palette).
    parameter bit IO_ONLY = 1'b0,
    parameter bit EXTERNAL_DMA = 1'b0,
    // PIC command-0 bytes captured from u444 under MAME 0.289.  Boot acceptance
    // additionally requires command F; sim/tb_revx_security_game.sv executes the
    // complete real-CPU routine, including PICCHECK and the game's own pass store.
    // byte0 in [7:0]: 45 C4 02 FB 8E 47 17 22 1A 1D 14 F4 AF 1C 9A E8.
    parameter logic [127:0] PIC_RESPONSE_BYTES =
        128'hE89A_1CAF_F414_1D1A_2217_478E_FB02_C445
)(
    input  logic        clk,
    input  logic        rst,

    // ---- CPU (TMS34020) 32-bit request/valid bus, bit-addressed ----
    input  logic        mem_req,
    input  logic        mem_we,
    input  logic [31:0] mem_addr,
    input  logic  [3:0] mem_be,
    input  logic [31:0] mem_wdata,
    output logic [31:0] mem_rdata,
    output logic        mem_ack,

    // ---- player inputs / DIPs (active-low) ----
    input  logic [31:0] in0, in1, in2, dsw,

    // ---- gun ADC feed (from revx_guns, computed in revx_top) ----
    input  logic  [7:0] an0, an1, an2, an3, an4, an5,

    // ---- DCS side (to revx_dcs2k) ----
    input  logic [15:0] dcs_ctrl,
    input  logic  [7:0] dcs_data_in,
    input  logic        dcs_output_full,
    output logic        dcs_data_w,
    output logic  [7:0] dcs_data_o,
    output logic        dcs_data_rd,
    output logic        dcs_reset,        // active-HIGH DCS reset = SYSCTRL1[1] (P0020; 1=held,0=run)
    output logic        lint1,            // CPU LINT1 from DCS output-full

    // ---- board control outputs ----
    output logic  [3:0] sysctrl0, sysctrl1,
    output logic        cmos_write_enable,
    output logic  [2:0] gun_recoil, gun_led,
    output logic        watchdog_kick,
    output logic        dbg_pic_status,
    output logic [7:0]  dbg_uart_last, dbg_adc_chan, dbg_adc_last,

    // ---- blitter register port (16-bit, to fork-pending wolf_dma) ----
    output logic        dma_reg_we,
    output logic  [3:0] dma_reg_addr,
    output logic [15:0] dma_reg_wdata,
    output logic [2:0] dma_reg_pair,
    input logic [31:0] dma_pair_rdata,

    // ---- gfx flat window / program ROM read backends ----
    output logic        gfx_rd,
    output logic [23:0] gfx_baddr,
    input  logic [31:0] gfx_rdata,
    output logic        rom_rd,
    output logic [18:0] rom_waddr,
    input  logic [31:0] rom_rdata
);
    // ---- revx_mem device taps ----
    logic        m_adc_wr, m_adc_rd;      logic [7:0] m_adc_wdata;
    logic        m_uart_wr, m_uart_rd;    logic [2:0] m_uart_reg; logic [7:0] m_uart_wdata;
    logic        m_pic_cmd_we, m_pic_clk_we, m_pic_resp_re; logic [3:0] m_pic_cmd; logic m_pic_clk;
    logic  [7:0] m_adc_rdata, m_uart_rdata, m_pic_data;
    logic        m_adc_done, m_pic_status;
    logic        m_dma_we, m_dma_rd;      logic [2:0] m_dma_pair; logic [31:0] m_dma_wdata, m_dma_rdata;

    // ---- full-rate peripheral request pipeline stage (TIMING) ---------------------------
    // Breaks the combinational cone from the CE-captured mem_if launch registers
    // (tms34010_mem_if.sv a_q/sz_q/we_q/wd_q, driven onto mem_addr/mem_be/mem_wdata) into the
    // full-rate peripheral write endpoints (dbg_uart_last, revx_uart uart[], the DMA regs).
    // The CPU request is captured into pr_* one clock; revx_mem's region decode + every device
    // strobe/payload and dbg_uart_last then run from the REGISTERED copy, so each endpoint
    // launches locally (pr_*) instead of the far launch register.  ack/rdata return one clock
    // later; the mem_if holds bus_req until bus_ack (S_RD0/S_WR0 combinational, drop on the ack
    // transition -- tms34010_mem_if.sv:208-239), so a +1 I/O latency is fully absorbed and
    // invisible to instruction semantics.  Captured EXACTLY ONCE per bus transaction: stg_busy
    // holds while the presented request is in flight, and the !umem_ack guard blocks re-capture
    // on the ack cycle (the revx_backends `mem_req && !mem_ack` pattern, revx_backends.sv:290),
    // so a held request (UART poll loop, io_w RMW) and back-to-back accesses each reach revx_mem
    // exactly once.
    logic        pr_req, pr_we;
    logic [31:0] pr_addr, pr_wdata;
    logic  [3:0] pr_be;
    logic        stg_busy;
    logic [31:0] umem_rdata;
    logic        umem_ack;
    assign mem_rdata = umem_rdata;
    assign mem_ack   = umem_ack;
    always_ff @(posedge clk) begin
        if (rst) begin pr_req <= 1'b0; stg_busy <= 1'b0; end
        else begin
            pr_req <= 1'b0;                       // pr_req is a one-cycle pulse to revx_mem
`ifdef REVX_PERIPH_STAGE_DOUBLE_SERVE
            // MUTANT: drop the once-only guard -> re-capture every cycle the request is held ->
            // revx_mem serves the SAME transaction repeatedly (extra dma_reg / wdog / uart
            // strobes).  tb_revx_memsys once-only checks (nwr==2, watchdog==1) KILL it.
            if (mem_req) begin
                pr_req <= 1'b1; pr_we <= mem_we; pr_addr <= mem_addr; pr_be <= mem_be;
                pr_wdata <= mem_wdata; stg_busy <= 1'b1;
            end
`else
            if (!stg_busy) begin
                if (mem_req && !umem_ack) begin
                    pr_req <= 1'b1; pr_we <= mem_we; pr_addr <= mem_addr; pr_be <= mem_be;
                    pr_wdata <= mem_wdata; stg_busy <= 1'b1;
                end
            end
            else if (umem_ack) stg_busy <= 1'b0;
`endif
        end
    end

    revx_mem #(.IO_ONLY(IO_ONLY)) u_mem (
        .clk(clk), .rst(rst),
        .mem_req(pr_req), .mem_we(pr_we), .mem_addr(pr_addr), .mem_be(pr_be),
        .mem_wdata(pr_wdata), .mem_rdata(umem_rdata), .mem_ack(umem_ack),
        .in0(in0), .in1(in1), .in2(in2), .dsw(dsw),
        .sysctrl0(sysctrl0), .sysctrl1(sysctrl1), .dcs_reset(dcs_reset), .cmos_write_enable(cmos_write_enable),
        .gun_recoil(gun_recoil), .gun_led(gun_led), .watchdog_kick(watchdog_kick),
        .adc_wr(m_adc_wr), .adc_wdata(m_adc_wdata), .adc_rd(m_adc_rd), .adc_rdata(m_adc_rdata), .adc_done(m_adc_done),
        .uart_wr(m_uart_wr), .uart_rd(m_uart_rd), .uart_reg(m_uart_reg), .uart_wdata(m_uart_wdata), .uart_rdata(m_uart_rdata),
        .pic_cmd_we(m_pic_cmd_we), .pic_cmd(m_pic_cmd), .pic_clk_we(m_pic_clk_we), .pic_clk(m_pic_clk),
        .pic_resp_re(m_pic_resp_re), .pic_data(m_pic_data), .pic_status(m_pic_status),
        .dma_we(m_dma_we), .dma_rd(m_dma_rd), .dma_pair(m_dma_pair), .dma_wdata(m_dma_wdata), .dma_rdata(m_dma_rdata),
        .gfx_rd(gfx_rd), .gfx_baddr(gfx_baddr), .gfx_rdata(gfx_rdata),
        .rom_rd(rom_rd), .rom_waddr(rom_waddr), .rom_rdata(rom_rdata),
        .dbg_region()
    );

    assign dbg_pic_status = m_pic_status;
    always_ff @(posedge clk) begin
        if (rst) begin dbg_uart_last <= 0; dbg_adc_chan <= 0; dbg_adc_last <= 0; end
        else begin
            if (m_uart_wr && m_uart_reg == 3) dbg_uart_last <= m_uart_wdata;
            if (m_uart_rd && m_uart_reg == 3) dbg_uart_last <= m_uart_rdata;
            if (m_adc_wr) dbg_adc_chan <= m_adc_wdata;
            if (m_adc_rd) dbg_adc_last <= m_adc_rdata;
        end
    end

    // ---- ADC0848 (pots/guns) ----
    revx_adc0848 #(.CONV_CLKS(ADC_CONV_CLKS)) u_adc (
        .clk(clk), .rst(rst), .wr(m_adc_wr), .wdata(m_adc_wdata), .rd(m_adc_rd),
        .an0(an0), .an1(an1), .an2(an2), .an3(an3), .an4(an4), .an5(an5),
        .result(m_adc_rdata), .done(m_adc_done));

    // ---- host UART (SCC2691 <-> DCS) ----
    revx_uart u_uart (
        .clk(clk), .rst(rst),
        .uart_wr(m_uart_wr), .uart_rd(m_uart_rd), .uart_reg(m_uart_reg), .uart_wdata(m_uart_wdata),
        .uart_rdata(m_uart_rdata),
        .dcs_ctrl(dcs_ctrl), .dcs_data_in(dcs_data_in),
        .dcs_data_w(dcs_data_w), .dcs_data_o(dcs_data_o), .dcs_data_rd(dcs_data_rd),
        .dcs_output_full(dcs_output_full), .lint1(lint1));

    // ---- security PIC ----
    // P0020: the PIC is NOT reset by SND_RESET/SYSCTRL1.  unknown_w (midxunit.cpp:262)
    // drives ONLY m_dcs->reset_w; the X-unit security chip is a real PIC16C57
    // (midxunit.cpp:169,674-678) whose reset line MAME does not model -- "there also
    // should be PIC16 reset line control, unknown at the moment" (midxunit.cpp:679).
    // So the PIC resets only with the core (u_pic .rst(rst) == the device power-on
    // reset + machine_reset midxunit.cpp:440-443) and pic_reset is tied INACTIVE.  The
    // prior `.pic_reset(dcs_reset)` coupled the PIC to the DCS sound-reset bit -- an
    // inherited-Wolf artifact (Wolf's io_w case1 bit5 DOES reset its serial PIC,
    // wolf_mem.sv:1578) -- which held the PIC in reset after boot and would have
    // spuriously reset it on every later SND_RESET.
    revx_pic_adapter #(.RESPONSE_BYTES(PIC_RESPONSE_BYTES)) u_pic (
        .clk(clk), .rst(rst),
        .cmd_we(m_pic_cmd_we), .cmd_nibble(m_pic_cmd),
        .clk_we(m_pic_clk_we), .clk_bit(m_pic_clk),
        .resp_re(m_pic_resp_re), .pic_reset(1'b0),
        .pic_data(m_pic_data), .pic_status(m_pic_status));

    // ---- DMA 32-bit pair -> two 16-bit blitter register writes (midxunit.cpp:494-499) ----
    //  A local 16-entry shadow mirrors the writes for CPU read-back (the fork-pending
    //  wolf_dma keeps the authoritative copy and consumes dma_reg_*).
    logic [15:0] dma_shadow [0:15];
    logic        wr_pending;              // 1 = high half still to write
    logic  [2:0] wr_pair;
    logic [15:0] wr_hi;

    assign dma_reg_pair = m_dma_pair;
    wire [31:0] dma_read_pair = EXTERNAL_DMA ? dma_pair_rdata :
                               {dma_shadow[{m_dma_pair, 1'b1}], dma_shadow[{m_dma_pair, 1'b0}]};
    // X-unit's second 16-bit DMA register is selected by LOW-half enables,
    // for both reads and writes (MAME midxunit_state::dma_r/dma_w). The first
    // register is always accessed, including on a high-half-only transaction.
    assign m_dma_rdata = {((|pr_be[1:0]) ? dma_read_pair[31:16] : 16'd0),
                          dma_read_pair[15:0]};

    always_ff @(posedge clk) begin
        if (rst) begin
            dma_reg_we <= 1'b0; wr_pending <= 1'b0;
        end
        else begin
            dma_reg_we <= 1'b0;
            if (m_dma_we) begin
                // cycle A: low half -> reg pair*2
                dma_reg_we    <= 1'b1;
                dma_reg_addr  <= {m_dma_pair, 1'b0};
                dma_reg_wdata <= m_dma_wdata[15:0];
                dma_shadow[{m_dma_pair, 1'b0}] <= m_dma_wdata[15:0];
                // The low-half strobe clocks the second register regardless
                // of the upper byte enables. Preserve the complete payload.
                wr_pending <= |pr_be[1:0];
                wr_pair    <= m_dma_pair;
                wr_hi      <= m_dma_wdata[31:16];
            end
            else if (wr_pending) begin
`ifndef REVX_DMA_HI_DROP
                // cycle B: high half -> reg pair*2+1 (midxunit.cpp:494-499 video->dma_w(off*2+1,hi))
                dma_reg_we    <= 1'b1;
                dma_reg_addr  <= {wr_pair, 1'b1};
                dma_reg_wdata <= wr_hi;
                dma_shadow[{wr_pair, 1'b1}] <= wr_hi;
`endif
                // MUTANT REVX_DMA_HI_DROP: drop the high half of the 32-bit register write.
                // The high half of pair 0 is DMA_COMMAND (the trigger), so the blit never
                // fires -> the VRAM image diverges from the golden -> tb_revx_dma_matrix KILLS it.
                wr_pending <= 1'b0;
            end
        end
    end
endmodule

`default_nettype wire
