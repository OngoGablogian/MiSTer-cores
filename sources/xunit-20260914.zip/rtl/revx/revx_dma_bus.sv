// Revolution X DMA adapter: proven wolf_dma register/draw engine on the X-unit
// 32-bit physical backend bus. MAME 0.289 midxunit.cpp:482-499 pairs registers;
// midtunit_v.cpp:431-610 supplies draw/address semantics. Independent source
// and pixel mailboxes retain one request per lane. Pixel acknowledgment still
// follows physical completion; source responses have independent ownership.
`default_nettype none
module revx_dma_bus #(parameter integer FB_GROUP_MAX = 1) (
  input logic clk, rst,
  input logic reg_we,
  input logic [3:0] reg_addr,
  input logic [15:0] reg_wdata,
  input logic [2:0] reg_pair,
  output logic [31:0] reg_pair_rdata,
  output logic [15:0] dma_palette,
  output logic irq, busy, overflow,
  // Output-only gameplay diagnostics; no request/ack/control feedback.
  output wire diag_src_wait, diag_fb_wait,
  output wire diag_blit_done,
  output wire [8:0] diag_q_highwater,
  output logic mem_req, mem_we,
  output logic [31:0] mem_addr, mem_wdata,
  output logic [3:0] mem_be,
  input logic mem_ack,
  input logic [31:0] mem_rdata,
  output logic pixel_req,
  output logic [18:0] pixel_addr,
  output logic [15:0] pixel_data,
  output logic [2:0] pixel_count,
  output logic [63:0] pixel_words,
  output logic pixel_reverse,
  input logic pixel_ack
);
  logic src_req, src_ack, fb_we, fb_ack;
  logic [31:0] src_addr;
  logic [7:0] src_data;
  logic [18:0] fb_addr;
  logic [15:0] fb_data;
  logic [2:0] fb_count; logic [63:0] fb_words; logic fb_reverse;
  assign diag_src_wait = src_req && !src_ack;
  assign diag_fb_wait = fb_we && !fb_ack;
  wolf_dma #(.FB_GROUP_MAX(FB_GROUP_MAX)) u_dma (
    .clk(clk), .rst(rst),
    .reg_we(reg_we), .reg_addr(reg_addr), .reg_wdata(reg_wdata), .reg_rdata(),
    .reg_pair_addr(reg_pair), .reg_pair_rdata(reg_pair_rdata),
    .src_req(src_req), .src_addr(src_addr), .src_active(), .src_stream(),
    .src_data(src_data), .src_ack(src_ack),
    .fb_we(fb_we), .fb_addr(fb_addr), .fb_wdata(fb_data), .fb_ack(fb_ack),
    .fb_count(fb_count), .fb_words(fb_words), .fb_reverse(fb_reverse),
    .wr_busy(1'b0), .busy(busy), .blit_irq(irq), .dma_palette(dma_palette),
    .dbg_q_overflow(overflow), .dbg_q_highwater(diag_q_highwater), .dbg_exec_done(diag_blit_done));
  revx_dma_word_bridge u_bus (
    .clk(clk), .rst(rst), .src_req(src_req), .src_addr(src_addr), .src_data(src_data), .src_ack(src_ack),
    .fb_we(fb_we), .fb_addr(fb_addr), .fb_data(fb_data), .fb_ack(fb_ack),
    .fb_count(fb_count), .fb_words(fb_words), .fb_reverse(fb_reverse),
    .mem_req(mem_req), .mem_we(mem_we), .mem_addr(mem_addr), .mem_wdata(mem_wdata), .mem_be(mem_be),
    .mem_ack(mem_ack), .mem_rdata(mem_rdata),
    .pixel_req(pixel_req), .pixel_addr(pixel_addr), .pixel_data(pixel_data), .pixel_ack(pixel_ack),
    .pixel_count(pixel_count), .pixel_words(pixel_words), .pixel_reverse(pixel_reverse));
endmodule

// Transaction adapter is separate so its byte/entry/ack contract is directly tested.
module revx_dma_word_bridge (
  input logic clk, rst,
  input logic src_req,
  input logic [31:0] src_addr,
  output logic [7:0] src_data,
  output logic src_ack,
  input logic fb_we,
  input logic [18:0] fb_addr,
  input logic [15:0] fb_data,
  input logic [2:0] fb_count,
  input logic [63:0] fb_words,
  input logic fb_reverse,
  output logic fb_ack,
  output logic mem_req, mem_we,
  output logic [31:0] mem_addr, mem_wdata,
  output logic [3:0] mem_be,
  input logic mem_ack,
  input logic [31:0] mem_rdata,
  output logic pixel_req,
  output logic [18:0] pixel_addr,
  output logic [15:0] pixel_data,
  output logic [2:0] pixel_count,
  output logic [63:0] pixel_words,
  output logic pixel_reverse,
  input logic pixel_ack
);
  wire fb_group = (fb_count === 3'd2) || (fb_count === 3'd3) || (fb_count === 3'd4);
  typedef enum logic [1:0] {IDLE, WAIT_MEM, RETURN_DATA, GAP} state_t;
  state_t state, write_state;
  logic [1:0] byte_l;
  logic cache_valid;
  logic [21:0] cache_tag;
  logic [31:0] cache_word;
  wire [31:0] mapped_src_addr = 32'hf8000000 + {7'd0,src_addr[23:2],5'd0};
  wire cache_hit = cache_valid && (cache_tag == src_addr[23:2]) &&
                   mapped_src_addr[31:24] >= 8'hf8 && mapped_src_addr[31:24] <= 8'hfe;
  // The existing mapped backend lane now carries source reads only. The
  // canonical full-pixel lane goes through the existing VD owner/physical ACK.
  assign mem_we=1'b0;
  assign mem_wdata=32'd0;
  assign mem_be=4'hf;
  always_ff @(posedge clk) begin
    if (rst) begin
      state<=IDLE; write_state<=IDLE;
      mem_req<=0; mem_addr<=0; byte_l<=0;
      pixel_req<=0; pixel_addr<=0; pixel_data<=0;
      pixel_count<=1; pixel_words<=0; pixel_reverse<=0;
      src_ack<=0; fb_ack<=0; src_data<=0;
`ifdef CACHE_MUTANT_NO_INVALIDATE
      cache_valid<=cache_valid;
`else
      cache_valid<=0;
`endif
      cache_tag<=0; cache_word<=0;
    end else begin
      src_ack<=0; fb_ack<=0;
      case (state)
        IDLE: if (src_req
`ifdef DMA_MUTANT_SERIAL_READ
                  && write_state==IDLE && !fb_we
`endif
                 ) begin
          byte_l<=src_addr[1:0];
          if (cache_hit) begin
`ifdef CACHE_MUTANT_WRONG_BYTE
            src_data<=8'(cache_word >> {(src_addr[1:0] ^ 2'b01),3'b000});
`else
            src_data<=8'(cache_word >> {src_addr[1:0],3'b000});
`endif
            state<=RETURN_DATA;
          end else begin
            mem_addr<=mapped_src_addr; mem_req<=1;
            state<=WAIT_MEM;
          end
        end
        WAIT_MEM: if (mem_ack) begin
          if (mem_addr[31:24] >= 8'hf8 && mem_addr[31:24] <= 8'hfe) begin
            cache_valid<=1; cache_tag<=mem_addr[26:5]; cache_word<=mem_rdata;
          end
          mem_req<=0;
          src_data<=8'(mem_rdata >> {byte_l,3'b000});
          state<=RETURN_DATA;
        end
        RETURN_DATA: begin src_ack<=1; state<=GAP; end
        // Source states can present the next byte without a low request
        // cycle. Preserve the original one-clock response/rearm gap.
        GAP: state<=IDLE;
        default: state<=IDLE;
      endcase
      case (write_state)
        IDLE: if (fb_we) begin
          pixel_req<=1; pixel_addr<=fb_addr; pixel_data<=fb_data;
          pixel_count<=fb_group ? fb_count : 3'd1;
          pixel_words<=fb_group ? fb_words : {48'd0,fb_data};
          pixel_reverse<=fb_group && (fb_reverse === 1'b1);
          write_state<=WAIT_MEM;
        end
        WAIT_MEM: if (pixel_ack) begin
          pixel_req<=0;
`ifdef DMA_MUTANT_SHARED_RESPONSE
          // Negative: the old serialized write-completion assignment corrupts
          // a concurrently owned source response.
          src_data<=8'(mem_rdata >> {byte_l,3'b000});
`endif
          write_state<=RETURN_DATA;
        end
        RETURN_DATA: begin fb_ack<=1; write_state<=GAP; end
        GAP: write_state<=IDLE;
        default: write_state<=IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
