// revx_sdram_phys.sv -- Midway X-unit (Revolution X) PHYSICAL single-MT48 SDRAM path.
//
// EMU-INTEGRATION lane, frontier (a): the real DE10-Nano has ONE MT48LC16M16 SDRAM, but
// revx_top exposes THREE 16-bit word channels (sd = RAM+ROM+boot via its inner arb, vd =
// VRAM data, vc = VRAM colour) plus the video SCANOUT wants a real-time read master.  This
// module folds all of them onto the ONE chip:
//
//   revx_sdram_arb (the UNIFIED 6-master arbiter, scanout-priority proven by
//   tb_revx_sdram_unified) merges  S(scanout) > A(sd) > B > VD > VC > DL  onto one 16-bit
//   word channel, which the real controller rtl/sdram/sdram_phy.sv turns into the MT48 pins
//   (the same controller tb_sdram_phy round-trips against the behavioral sdram_chip).
//
// The three revx_top word channels + the scanout master are ABSOLUTE-word-addressed by the
// caller (the emu adds each region's base within the one chip).  The shipped emu (Arcade-RevX,
// SD_AW=22, one 8 MiB MT48 bank) places RAM/ROM in [0,0x200000) (2 MiB RAM + 2 MiB ROM,
// midxunit.cpp:511) and canonical VRAM at 0x200000; the standalone phys benches
// (tb_revx_sdram_unified / tb_revx_emu_sdram) still exercise the module at the default SD_AW=21
// with VRAM at 0x180000.  This module only muxes + drives the pins, so it is base-agnostic.
//
// P0022 (DESIGN-RULES.md s.6): a self-contained power-up one-shot (boot counter) issues the MT48
// LOAD-MODE/refresh init sequence on config; `ready` rises when it is safe to issue accesses.
// No external reset is needed for the capture path (the boot writer just waits on ack).
//
// MUTANT: none of its own -- the scanout-priority mutant (REVX_ARB_NO_SCAN_PRIO) lives in
// revx_sdram_arb and is exercised through this module by tb_revx_emu_sdram.

`timescale 1ns/1ps
`default_nettype none
module revx_sdram_phys #(
  parameter int SD_AW = 21,          // physical MT48 word-address width (4 MiB)
  parameter int PWRUP = 20000,       // power-up wait in clks (real ~200us; sims shorten it)
  parameter bit SCAN_BURST = 1'b0
)(
  input  logic              clk,

  // ---- master S: video scanout reader (top priority) ----
  input  logic [SD_AW-1:0]  s_addr,
  input  logic              s_rd,
  output logic [15:0]       s_dout,
  output logic              s_ack,
  output logic [255:0]      s_chunk_dout,

  // ---- master A: revx_top sd channel (RAM + ROM + boot-load, inner-arb merged) ----
  input  logic [SD_AW-1:0]  a_addr,
  input  logic [15:0]       a_din,
  input  logic [1:0]        a_be,
  input  logic              a_rd,
  input  logic              a_wr,
  output logic [15:0]       a_dout,
  output logic              a_ack,

  // ---- master VD: revx_top VRAM-data channel ----
  input  logic [SD_AW-1:0]  vd_addr,
  input  logic [15:0]       vd_din,
  input  logic [1:0]        vd_be,
  input  logic              vd_rd,
  input  logic              vd_wr,
  output logic [15:0]       vd_dout,
  output logic              vd_ack,
  input logic [2:0] vd_count, input logic [63:0] vd_words, input logic vd_reverse,

  // ---- master VC: revx_top VRAM-colour channel ----
  input  logic [SD_AW-1:0]  vc_addr,
  input  logic [15:0]       vc_din,
  input  logic [1:0]        vc_be,
  input  logic              vc_rd,
  input  logic              vc_wr,
  output logic [15:0]       vc_dout,
  output logic              vc_ack,

  input logic wb_req,
  input logic [SD_AW-1:0] wb_addr,
  input logic [6:0] wb_count,
  input logic [1023:0] wb_data,
  output logic wb_ack,

`ifdef REVX_BLMOVE_BURST
  // BLMOVE write chunk (SD-space absolute RAM words; see revx_sdram_arb).
  input logic wb2_req,
  input logic [SD_AW-1:0] wb2_addr,
  input logic [4:0] wb2_count,
  input logic [255:0] wb2_data,
  output logic wb2_ack,
`endif

  // PERF: CPU line-fill burst READ (one ACTIVE + consecutive reads in the PHY).
  input logic rb_req,
  input logic [SD_AW-1:0] rb_addr,
  input logic [4:0] rb_count,
  output logic [255:0] rb_dout,
  output logic rb_ack,

  // ---- physical MT48LC16M16 pins ----
  inout  wire  [15:0]       SDRAM_DQ,
  output logic [12:0]       SDRAM_A,
  output logic [1:0]        SDRAM_BA,
  output logic              SDRAM_DQML,
  output logic              SDRAM_DQMH,
  output logic              SDRAM_nCS,
  output logic              SDRAM_nRAS,
  output logic              SDRAM_nCAS,
  output logic              SDRAM_nWE,
  output logic              SDRAM_CKE,

  output logic              ready,        // MT48 init done (safe to issue)

  // ---- DIAG v3 SDRAM lane self-test (armed once at download-complete; see revx_sdram_selftest) ----
  input  logic              st_arm,       // level from the emu: download done, run once while core held
  output logic              st_done,
  output logic [15:0]       st_t1_lo, st_t1_hi,
  output logic [15:0]       st_t2_got,
  output logic [15:0]       st_t3_got1, st_t3_got2,
  output logic [15:0]       st_t4_refresh,
  output logic  [4:0]       st_status
);
  // ---- unified arb -> one 16-bit word channel ----
  logic [SD_AW-1:0] w_addr; logic [15:0] w_din, w_dout; logic [1:0] w_be;
  logic             w_rd, w_wr, w_ack;
  logic w_write_chunk, w_write_reverse;
  logic w_read_chunk;
  logic [6:0] w_chunk_count;
  logic [1023:0] w_chunk_data;
  logic [255:0] w_chunk_dout;

  // ---- self-contained power-up one-shot: a clean init rising edge on config ----
  // boot counts up once from 0; init pulses high only after a couple of low cycles so
  // sdram_phy's init-edge detect (init & ~init_d) fires deterministically in sim + synth.
  // The arb is held in reset (grant<-G_NONE) across the boot window so `grant` initialises
  // deterministically (rst tied 0 would leave it X in sim -> never grants).
  logic [3:0] boot = 4'd0;
  always_ff @(posedge clk) if (boot != 4'hf) boot <= boot + 4'd1;
  wire init_ph = (boot == 4'd4);
  wire arb_rst = (boot < 4'd6);

  revx_sdram_arb #(.SD_AW(SD_AW), .S_READ_CHUNK(SCAN_BURST)) u_arb (
    .clk(clk), .rst(arb_rst),
    .s_addr(s_addr), .s_rd(s_rd), .s_dout(s_dout), .s_ack(s_ack),
    .s_chunk_dout(s_chunk_dout),
    .a_addr(a_addr), .a_din(a_din), .a_be(a_be), .a_rd(a_rd), .a_wr(a_wr), .a_dout(a_dout), .a_ack(a_ack),
    // master B unused here (revx_top's inner arb already folded ROM into sd/A)
    .b_addr({SD_AW{1'b0}}), .b_din(16'd0), .b_be(2'd0), .b_rd(1'b0), .b_wr(1'b0), .b_dout(), .b_ack(),
    .vd_addr(vd_addr), .vd_din(vd_din), .vd_be(vd_be), .vd_rd(vd_rd), .vd_wr(vd_wr), .vd_dout(vd_dout), .vd_ack(vd_ack),
    .vd_count(vd_count), .vd_words(vd_words), .vd_reverse(vd_reverse),
    .vc_addr(vc_addr), .vc_din(vc_din), .vc_be(vc_be), .vc_rd(vc_rd), .vc_wr(vc_wr), .vc_dout(vc_dout), .vc_ack(vc_ack),
    // DL unused here (boot writes ride the sd/A channel out of revx_top's inner arb)
    .dl_addr({SD_AW{1'b0}}), .dl_din(16'd0), .dl_be(2'd0), .dl_wr(1'b0), .dl_ack(),
    .wb_req(wb_req), .wb_addr(wb_addr), .wb_count(wb_count), .wb_data(wb_data), .wb_ack(wb_ack),
`ifdef REVX_BLMOVE_BURST
    .wb2_req(wb2_req), .wb2_addr(wb2_addr), .wb2_count(wb2_count), .wb2_data(wb2_data), .wb2_ack(wb2_ack),
`endif
    .rb_req(rb_req), .rb_addr(rb_addr), .rb_count(rb_count), .rb_dout(rb_dout), .rb_ack(rb_ack),
    .sd_addr(w_addr), .sd_din(w_din), .sd_be(w_be), .sd_rd(w_rd), .sd_wr(w_wr),
    .sd_dout(w_dout), .sd_ack(w_ack), .sd_write_chunk(w_write_chunk),
    .sd_read_chunk(w_read_chunk), .sd_write_reverse(w_write_reverse),
    .sd_chunk_count(w_chunk_count), .sd_chunk_data(w_chunk_data),
    .sd_chunk_dout(w_chunk_dout));

  // ---- DIAG v3 SDRAM lane self-test: a boot-time master inserted as a 2:1 STEAL MUX directly
  //      ahead of the phy word port.  It runs ONCE at download-complete while the core (and thus
  //      every arb master: scanout, CPU sd, VRAM) is held in reset, so no arbiter port is needed
  //      and it addresses the full 25-bit word space (scratch above the 21-bit game map).  Its
  //      power-on one-shot reuses the local boot ramp; results freeze until the next power-up. ----
  logic [24:0] st_maddr; logic [15:0] st_mdin; logic [1:0] st_mbe; logic st_mrd, st_mwr, st_busy;
  logic        st_m_dqm_early;                     // DIAG v4a: self-test asks the phy for early DQM
  logic [15:0] p_dout; logic p_ack;
  wire st_por = (boot != 4'hf);

  revx_sdram_selftest u_selftest (
    .clk(clk), .rst(st_por), .arm(st_arm), .ready(ready),
    .m_addr(st_maddr), .m_din(st_mdin), .m_be(st_mbe), .m_rd(st_mrd), .m_wr(st_mwr),
    .m_dqm_early(st_m_dqm_early),
    .m_dout(p_dout), .m_ack(st_busy ? p_ack : 1'b0), .busy(st_busy),
    .t1_lo(st_t1_lo), .t1_hi(st_t1_hi), .t2_got(st_t2_got),
    .t3_got1(st_t3_got1), .t3_got2(st_t3_got2),
    .t4_after_refresh(st_t4_refresh),
    .status(st_status), .done(st_done));

  // steal mux: the self-test owns the phy word port ONLY while busy; otherwise the arb does.
  wire [24:0] p_addr = st_busy ? st_maddr : {{(25-SD_AW){1'b0}}, w_addr};
  wire [15:0] p_din  = st_busy ? st_mdin  : w_din;
  wire [1:0]  p_be   = st_busy ? st_mbe   : w_be;
  wire        p_rd   = st_busy ? st_mrd   : w_rd;
  wire        p_wr   = st_busy ? st_mwr   : w_wr;
  // DIAG v4a: only the self-test's steal port can request early DQM; every arb write is native.
  wire        p_dqm_early = st_busy ? st_m_dqm_early : 1'b0;
  assign w_dout = p_dout;
  assign w_ack  = st_busy ? 1'b0 : p_ack;   // arb sees no ack while the self-test owns the phy

  // ---- real MT48 controller (word req/ack contract; drives the pins) ----
  sdram_phy #(.CLK_MHZ(80), .RASCAS(3), .CAS(2), .TRP(3), .TRFC(9),
              .REFRESH_IV(600), .PWRUP(PWRUP)) u_phy (
    .clk(clk), .init(init_ph),
    .addr(p_addr), .din(p_din), .be(p_be), .dqm_early(p_dqm_early),
    .rd(p_rd), .wr(p_wr), .dout(p_dout), .ack(p_ack), .ready(ready),
    .write_reverse(!st_busy && w_write_reverse),
    .write_chunk(!st_busy && w_write_chunk), .chunk_count(w_chunk_count), .chunk_data(w_chunk_data),
    .read_chunk(!st_busy && w_read_chunk), .chunk_dout(w_chunk_dout),
    .SDRAM_DQ(SDRAM_DQ), .SDRAM_A(SDRAM_A), .SDRAM_BA(SDRAM_BA),
    .SDRAM_DQML(SDRAM_DQML), .SDRAM_DQMH(SDRAM_DQMH),
    .SDRAM_nCS(SDRAM_nCS), .SDRAM_nRAS(SDRAM_nRAS), .SDRAM_nCAS(SDRAM_nCAS),
    .SDRAM_nWE(SDRAM_nWE), .SDRAM_CKE(SDRAM_CKE));
endmodule
`default_nettype wire
