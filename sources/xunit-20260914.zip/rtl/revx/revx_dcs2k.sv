// revx_dcs2k.sv -- Revolution X DCS Audio 2K board (DCS_AUDIO_2K_UART).
//
// COPIED from tunit/Arcade-TUnit_MiSTer/rtl/tunit/tunit_dcs2k.sv (module + its
// adsp2105/dcs_mem deps ported as revx_adsp2105.sv / revx_dcs_mem.sv, which carry
// the DCS_2K SRAM map the Wolf-tree adsp2105 lacks).  RevX uses DCS_AUDIO_2K_UART
// (midxunit.cpp:693), same 2K core as the T-unit; the T-unit wrapper's semantics
// carry over.  X-UNIT DIFFERENCES (dcs.cpp:293-303, dcs_2k_uart_data_map):
//   * the input/output latch lives at ADSP data 0x3403 (single word), NOT 0x3400.
//   * the surrounding UART registers 0x3400-0x3402 / 0x3404-0x3405 are NO-OPs on
//     the DCS side (map(...).noprw()); the host UART (revx_uart.sv) is the SCC2691
//     on the CPU side.  data_bank_select stays 0x3000-0x33ff, IRAM 0x3800-0x39ff,
//     ADSP control 0x3fe0-0x3fff (all identical to the T-unit 2K map, dcs.cpp:279-303).
// UART_HOST selects the exact3403 map in revx_adsp2105 through DCS_UART.
// The earlier broad2K decode incorrectly turned UART initialization writes into
// output-latch responses and input-latch reads into acknowledgements.
//
// -- original T-unit provenance note --
// MK2 DCS Audio 2K board wrapper. This is deliberately separate from Wolf's
// DCS8K glue: early-DCS host offsets, reset bit, status shift, six-ROM layout,
// and 2 KiB SRAM mapping belong to the T-unit profile.

`default_nettype none
module revx_dcs2k #(
  parameter EXT_ROM = 1,
  parameter PF_LINES = 512,
  // X-unit UART carries byte commands; SYSCTRL1 supplies board reset separately
  // (MAME 0.289 midxunit.cpp:257-266,374-400). Default retains T-unit host ABI.
  parameter UART_HOST = 0,
  parameter MIXER_GAIN = 0
)(
  input  wire logic   clk,
  input  wire logic   rst,
  input  wire logic   dac_ce_31250,
  input  wire logic [3:0] music_attenuation,
  input  wire logic [3:0] sfx_attenuation,

  input  wire logic   cpu_status_rd,
  input  wire logic   cpu_data_rd,
  input  wire logic   cpu_data_wr,
  input  wire logic   cpu_data_offset,
  input  wire logic [15:0] cpu_wdata,
  input  wire logic [1:0] cpu_byte_en,
  output logic [15:0] cpu_status_rdata,
  output logic [15:0] cpu_data_rdata,
  output logic [15:0] uart_control,
  output logic [7:0] uart_response,
  output logic uart_output_full,

  output logic        rom_req,
  output logic [19:0] rom_addr,
  input  wire logic   rom_ready,
  input  wire logic [63:0] rom_rdata,

  output logic signed [15:0] audio,
  output logic        audio_ce,
  output logic        audio_underrun,
  output logic        audio_overrun,
  output logic [13:0] adsp_pc,
  output logic        adsp_valid,
  output logic        adsp_unimplemented
);
  logic dcs_run;
  logic host_cmd_w;
  logic [15:0] host_cmd_data;
  logic [15:0] host_status, host_response;
  logic host_resp_rd;
  logic [15:0] dac_sample;
  logic dac_strobe;
  logic core_ce;
  logic core_phase;
  logic host_cmd_pending;
  logic host_resp_pending;
  logic dac_pending;

  assign uart_control = host_status;
  assign uart_response = host_response[7:0];
  assign uart_output_full = ~host_status[10];
  assign cpu_status_rdata = cpu_status_rd ? (host_status >> 4) : 16'hffff;
  assign cpu_data_rdata = cpu_data_rd ? {8'h00,host_response[7:0]} : 16'hffff;
  assign core_ce = core_phase;
  assign host_resp_rd = core_ce && host_resp_pending;
  assign host_cmd_w = core_ce && host_cmd_pending;
  // A bit-8 board reset is also the physical-output mute boundary.  Do not
  // expose the held sample for the one system clock between the host write and
  // the ADSP's full reset branch; that is enough for a coincident DAC slot to
  // preserve stale PCM outside the sound board.
  assign audio = dcs_run ? $signed(dac_sample) : 16'sd0;
  assign audio_ce = dcs_run && dac_strobe;

  always_ff @(posedge clk) begin
    if (rst) begin
      dcs_run <= 1'b0;
      host_cmd_data <= 16'h0000;
      core_phase <= 1'b0;
      host_cmd_pending <= 1'b0;
      host_resp_pending <= 1'b0;
      dac_pending <= 1'b0;
    end else begin
      core_phase <= ~core_phase;
      if (UART_HOST) dcs_run <= 1'b1;
      // Scrub wrapper-side mailbox/DAC slots for the whole held-reset interval.
      // The Wolf post-death tone survived partly because a pending outer slot
      // outlived the reset even after the inner PCM queue was emptied.
      if (!dcs_run) begin
        host_cmd_pending <= 1'b0;
        host_resp_pending <= 1'b0;
        dac_pending <= 1'b0;
      end else begin
        if (core_ce && host_cmd_pending)
          host_cmd_pending <= 1'b0;
        if (core_ce && host_resp_pending)
          host_resp_pending <= 1'b0;
        if (core_ce && dac_pending)
          dac_pending <= 1'b0;
        if (cpu_data_rd)
          host_resp_pending <= 1'b1;
        if (dac_ce_31250)
          dac_pending <= 1'b1;
      end
      // mk2_state::dcs_w ignores offset 0 and requires both byte lanes. Offset
      // 1 writes reset state from bit 8 and the 8-bit command from bits 7:0.
      if (cpu_data_wr && (UART_HOST || (cpu_data_offset && (cpu_byte_en == 2'b11)))) begin
        dcs_run <= UART_HOST ? 1'b1 : cpu_wdata[8];
        host_cmd_data <= {8'h00,cpu_wdata[7:0]};
        host_cmd_pending <= 1'b1;
      end
    end
  end

  revx_adsp2105 #(
    .DCS_2K(1), .DCS_UART(UART_HOST), .REVX_MIXER_GAIN(MIXER_GAIN),
    .EXT_ROM(EXT_ROM), .PF_LINES(PF_LINES), .PRELOAD_PM(0),
    .CORE_CE_EN(1)
  ) cpu (
    // The DCS reset bit is a held board reset, not a request to reload the
    // boot page forever.  Keep the ADSP and its ROM cache in reset until RUN
    // is asserted; the reset-release edge naturally starts the bank-0 boot.
    .clk(clk), .rst(rst || !dcs_run), .core_ce(core_ce), .host_rst(1'b0),
    .music_attenuation(music_attenuation), .sfx_attenuation(sfx_attenuation),
    .host_cmd_w(host_cmd_w), .host_cmd_data(host_cmd_data),
    .host_status_r(host_status), .host_response_r(host_response),
    .host_resp_rd(host_resp_rd),
    .rom_ddr_req(rom_req), .rom_ddr_addr(rom_addr),
    .rom_ddr_rdy(rom_ready), .rom_ddr_q(rom_rdata),
    .dac_ce_in(core_ce && dac_pending),
    .o_ppc(adsp_pc), .o_valid(adsp_valid), .o_unimpl(adsp_unimplemented),
    .dac_sample(dac_sample), .dac_ce(dac_strobe),
    .audio_underrun(audio_underrun), .audio_overrun(audio_overrun)
  );
endmodule
`default_nettype wire
