// MiSTer index-4 persistence control for the 48 KiB Midway Wolf CMOS image.
//
// The optional MiSTer RTC battery keeps wall-clock time only. Wolf cabinet
// settings, audits, high scores, and unlocks instead travel through hps_io and
// a per-MRA .nvm file. The memory-side interface is byte-wide so the saved
// file is byte-for-byte compatible with MAME's 0x6000 little-endian u16 words.

`default_nettype none
module wolf_nvram_bridge #(
  parameter integer NVRAM_BYTES = 49152,
  // hps_io ioctl index carrying the CMOS image.  Wolf/UMK3 = 4 (donor default) and
  // Revolution X ALSO = 4 (AUDIT.md s.3, mra/Revolution X.mra <nvram index="4">,
  // revx_backends.sv NVRAM_INDEX(8'd4)).  Index 2 is the emu's dcs_download route, so
  // a 2 here never reaches the bridge (board 2-4 verifier finding, fixed 2026-09-06).
  // Parameterised so a fork can pick its index deliberately (DESIGN-RULES.md s.4).
  parameter [7:0]   NVRAM_INDEX = 8'd4
)(
  input  wire logic        clk,
  input  wire logic        rst_pon,
  input  wire logic        ioctl_download,
  input  wire logic        ioctl_upload,
  input  wire logic        ioctl_wr,
  input  wire logic [7:0]  ioctl_index,
  input  wire logic [24:0] ioctl_addr,
  input  wire logic [7:0]  ioctl_dout,
  output logic [7:0]       ioctl_din,
  output logic             ioctl_upload_req,

  input  wire logic        manual_save,
  input  wire logic        clear_nvram,
  input  wire logic        cpu_write_pulse,
  input  wire logic        cmos_cpu_busy,
  output logic             cmos_quiesce,

  output logic             nvram_ext_en,
  output logic             nvram_ext_wr,
  output logic [15:0]      nvram_ext_addr,
  output logic [7:0]       nvram_ext_wdata,
  input  wire logic [7:0]  nvram_ext_rdata,
  output logic             nvram_busy,
  output logic             nvram_dirty
);
  logic clearing;
  logic [15:0] clear_addr;
  logic old_clear, old_manual, old_nvram_upload;
  logic save_pending;

  wire nvram_download = ioctl_download && (ioctl_index == NVRAM_INDEX);
  wire nvram_upload = ioctl_upload && (ioctl_index == NVRAM_INDEX);
  wire nvram_addr_valid = ioctl_addr < NVRAM_BYTES;

  // Restore/clear must hold the game reset because they write CMOS. Upload is
  // read-only: wolf_mem stalls only a simultaneous CPU CMOS access, avoiding a
  // visible game reboot whenever MiSTer saves from the OSD.
  assign nvram_busy = nvram_download || clearing;
  // Coherency: cmos_quiesce freezes CMOS WRITES (not reads) for the whole save
  // (save_pending through upload), so the uploaded image is a coherent,
  // checksum-valid snapshot.
  assign cmos_quiesce = save_pending || nvram_upload || nvram_busy;
  assign nvram_ext_en = nvram_busy || nvram_upload;
  assign nvram_ext_wr = clearing ||
                        (nvram_download && ioctl_wr && nvram_addr_valid);
  assign nvram_ext_addr = clearing ? clear_addr : ioctl_addr[15:0];
  assign nvram_ext_wdata = clearing ? 8'h00 : ioctl_dout;
  assign ioctl_din = (ioctl_index == NVRAM_INDEX && nvram_addr_valid)
                   ? nvram_ext_rdata : 8'h00;
  // STABLE upload request.  hps_io samples ioctl_upload_req on a slow HPS poll;
  // it MUST be a steady level once a save is pending, not gated on the CPU's
  // per-access cmos_cpu_busy (that made the request FLICKER with every CMOS
  // touch -> the poll could catch it low and miss/abort the save, so cabinet
  // saves "did not stick" and every boot re-hit the CMOS-invalid screen).
  // Coherency is handled by cmos_quiesce freezing CMOS writes for the whole
  // save window, NOT by delaying the request. Only nvram_busy (a stable level:
  // a restore/clear is itself writing CMOS) suppresses a concurrent upload.
  assign ioctl_upload_req = save_pending && !nvram_busy;
  wire   _unused_cmos_cpu_busy = cmos_cpu_busy;   // now advisory only

  always_ff @(posedge clk) begin
    if (rst_pon) begin
      clearing <= 1'b0;
      clear_addr <= 16'd0;
      old_clear <= 1'b0;
      old_manual <= 1'b0;
      old_nvram_upload <= 1'b0;
      save_pending <= 1'b0;
      nvram_dirty <= 1'b0;
    end else begin
      old_clear <= clear_nvram;
      old_manual <= manual_save;
      old_nvram_upload <= nvram_upload;

      if (clear_nvram && !old_clear && !clearing) begin
        clearing <= 1'b1;
        clear_addr <= 16'd0;
      end else if (clearing) begin
        if (clear_addr == NVRAM_BYTES-1) begin
          clearing <= 1'b0;
          nvram_dirty <= 1'b1;
        end else begin
          clear_addr <= clear_addr + 1'b1;
        end
      end

      // Manual Save NVRAM is the only action allowed to request an upload.
      // CMOS writes, menu transitions, and Clear NVRAM merely mark the image
      // dirty; they can never produce a background "Saving NVRAM" notification.
      if (manual_save && !old_manual)
        save_pending <= 1'b1;

`ifdef MUTATE_WOLF_NVRAM_AUTOSAVE
      // Regression-only resurrection of the removed background save path.
      if (cpu_write_pulse)
        save_pending <= 1'b1;
`endif

      // hps_io accepted the request and began the index-4 upload.  Clear the
      // dirty snapshot once, at upload start; writes during the transfer must
      // remain dirty for the next save.
      if (nvram_upload && !old_nvram_upload) begin
        save_pending <= 1'b0;
        nvram_dirty <= 1'b0;
      end

      // A restored save is authoritative and starts clean.
      if (nvram_download && ioctl_wr && nvram_addr_valid) begin
        save_pending <= 1'b0;
        nvram_dirty <= 1'b0;
      end

      // This assignment intentionally follows upload/download cleanup.  A CPU
      // CMOS write coincident with either transfer is newer than that snapshot
      // and must not be lost.
      if (cpu_write_pulse)
        nvram_dirty <= 1'b1;
    end
  end
endmodule
`default_nettype wire
