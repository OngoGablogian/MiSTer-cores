// revx_derail_capture.sv -- Revolution X on-chip DERAIL + FIRST-INTERRUPT instrument.
//
// Cabinet reading 2026-09-07 07:40 PT (first silicon): everything under the CPU worked
// (download complete, reset held during download, zero drops, SDRAM+DDR3 init, ~65M
// instructions retired) but the PC looped around 0xFFFFE190 -- a DATA table (words
// 0303/037B/0333/1F1F), i.e. the CPU DERAILED off the legitimate boot path.  No UART byte
// ever, DCS status 0.  The overlay showed WHERE the CPU parked but not WHERE it left the
// path, nor whether it left via a corrupt interrupt vector.
//
// This is the synthesizable, on-chip form of sim/tb_wolf_boot_derail.sv's two instruments
// (a DERAIL detector + the source instruction that jumped).  It runs in the CPU clock domain,
// samples on cpu_retire / interrupt-entry taps, FREEZES on the first hit, and clears ONLY on
// core reset.  Pure flip-flops (no arrays -> no M10K; a few hundred ALM).
//
// (a) DERAIL windows (the game runs UNZIP'd code from DRAM):
//        code ROM : ROM_LO   .. ROM_HI    (0xFF000000 .. 0xFFFFFFFF)
//        code RAM : RAM_LO   .. RAM_HI    (0x20000000 .. 0x20FFFFFF)
//     A retired PC is BAD when it is inside the parked data-table band
//     DERAIL_LO..DERAIL_HI (0xFFFFE000..0xFFFFFBFF -- note this stops BELOW the 0xFFFFFC00
//     trap-vector table so legit vector fetches are never flagged) OR outside both code
//     windows.  On the FIRST bad retired PC: culprit_pc = the PREVIOUS retired PC,
//     culprit_instr = its instruction word, target_pc = the offending PC, derail_captured=1.
//     last_good_pc runs continuously (most recent retired PC in a legit, non-derail window)
//     so the "last PC before the offending window" stays meaningful independent of tuning.
//
// (b) FIRST INTERRUPT: on the first interrupt entry taken by the core (int_entry pulse at the
//     trap-vector read), freeze the interrupted PC, the vector address (int_vec_q), the vector
//     VALUE fetched (the ISR entry loaded into PC) and count every entry (8-bit saturating).
//
// Gate: sim/run_revx_derail_capture.sh (tb_revx_derail_capture.sv) drives a scripted retire
// stream + interrupt taps and cross-checks every frozen field; the NAMED mutant
// REVX_DERAIL_NO_FREEZE removes the freeze -> the gate MUST fail.
`default_nettype none
module revx_derail_capture #(
  parameter [31:0] ROM_LO    = 32'hFF000000,
  parameter [31:0] ROM_HI    = 32'hFFFFFFFF,
  parameter [31:0] RAM_LO    = 32'h20000000,
  parameter [31:0] RAM_HI    = 32'h20FFFFFF,
  parameter [31:0] DERAIL_LO = 32'hFFFFE000,
  parameter [31:0] DERAIL_HI = 32'hFFFFFBFF
)(
  input  logic        clk,
  input  logic        rst,            // core reset: the ONLY thing that clears a capture

  // ---- retire stream (CPU clock domain; cpu_retire = 1-clk pulse per retired instruction) ----
  input  logic        cpu_retire,
  input  logic [31:0] cpu_pc,         // PC of the instruction being retired/accepted
  input  logic [15:0] cpu_instr,      // its decoded instruction word

  // ---- interrupt-entry taps (from tms34010_core debug ports) ----
  input  logic        int_entry,      // 1-clk pulse at the trap-vector read (all fields valid)
  input  logic [31:0] int_pc,         // PC being interrupted (resume address)
  input  logic [31:0] int_vec_addr,   // trap-vector address (int_vec_q)
  input  logic [31:0] int_vec_value,  // trap-vector value = ISR entry (-> PC)

  // ---- DERAIL capture (frozen once derail_captured) ----
  output logic [31:0] culprit_pc,     // previous retired PC (the instruction that left the path)
  output logic [15:0] culprit_instr,  // its instruction word
  output logic [31:0] target_pc,      // the offending PC (first bad retired PC)
  output logic [31:0] last_good_pc,   // running: most recent legit retired PC (safety net)
  output logic        derail_captured,

  // ---- FIRST-INTERRUPT capture (frozen once int_captured) ----
  output logic [31:0] int_interrupted_pc,
  output logic [31:0] int_vec_addr_q,
  output logic [31:0] int_vec_value_q,
  output logic  [7:0] int_count,      // saturating at 0xFF
  output logic        int_captured
);
  // ---- code-window classification of the retired PC ----
  wire in_rom    = (cpu_pc >= ROM_LO)    && (cpu_pc <= ROM_HI);
  wire in_ram    = (cpu_pc >= RAM_LO)    && (cpu_pc <= RAM_HI);
  wire in_derail = (cpu_pc >= DERAIL_LO) && (cpu_pc <= DERAIL_HI);
  wire bad_pc    = in_derail || !(in_rom || in_ram);

  // previous retired instruction (source of the jump)
  logic [31:0] prev_pc;
  logic [15:0] prev_instr;

  always_ff @(posedge clk) begin
    if (rst) begin
      prev_pc<=32'd0; prev_instr<=16'd0;
      culprit_pc<=32'd0; culprit_instr<=16'd0; target_pc<=32'd0;
      last_good_pc<=32'd0; derail_captured<=1'b0;
    end else if (cpu_retire) begin
`ifndef REVX_DERAIL_NO_FREEZE
      // Freeze on the FIRST bad retired PC.  Non-blocking reads of prev_pc/prev_instr use
      // their pre-update (previous-instruction) values -- exactly the culprit.
      if (bad_pc && !derail_captured) begin
        derail_captured <= 1'b1;
        culprit_pc      <= prev_pc;
        culprit_instr   <= prev_instr;
        target_pc       <= cpu_pc;
      end
`else
      // MUTANT REVX_DERAIL_NO_FREEZE: capture nothing -> the gate's derail checks must fail.
      if (bad_pc) begin
        culprit_pc    <= prev_pc;
        culprit_instr <= prev_instr;
        target_pc     <= cpu_pc;   // no derail_captured latch, no first-hit lock
      end
`endif
      if (!bad_pc) last_good_pc <= cpu_pc;   // running last-good (not frozen)
      prev_pc    <= cpu_pc;                   // shift previous for the next retire
      prev_instr <= cpu_instr;
    end
  end

  // ---- first-interrupt capture ----
  always_ff @(posedge clk) begin
    if (rst) begin
      int_interrupted_pc<=32'd0; int_vec_addr_q<=32'd0; int_vec_value_q<=32'd0;
      int_count<=8'd0; int_captured<=1'b0;
    end else if (int_entry) begin
`ifndef REVX_DERAIL_NO_FREEZE
      if (!int_captured) begin
        int_captured       <= 1'b1;
        int_interrupted_pc <= int_pc;
        int_vec_addr_q     <= int_vec_addr;
        int_vec_value_q    <= int_vec_value;
      end
`else
      begin
        int_interrupted_pc <= int_pc;        // MUTANT: overwrite every entry, never lock
        int_vec_addr_q     <= int_vec_addr;
        int_vec_value_q    <= int_vec_value;
      end
`endif
      if (int_count != 8'hFF) int_count <= int_count + 8'd1;   // saturating
    end
  end
endmodule

// Passive L2 foreground discriminator. These are shadows of completed CPU writes,
// not memory probes: no request, stall, or writeback enters the game. Bit addresses
// and byte lanes follow tms34010_mem_if's aligned 32-bit bus. In particular TIMER
// at 20517CF0 occupies the UPPER half of bus word 20517CE0.
module revx_timer_capture (
  input logic clk, rst,
  input logic cpu_retire,
  input logic [31:0] cpu_pc,
  input logic bus_req, bus_we, bus_ack,
  input logic [31:0] bus_addr, bus_wdata,
  input logic [3:0] bus_be,
  output logic [31:0] foreground_pc, timers, process_ptr, watch_status
);
  logic write_q, accept_q, frozen;
  logic [31:0] addr_q, data_q, pc_q;
  logic [3:0] be_q;
  logic [15:0] timer_q, last_timer_q, drain_count;
  logic [11:0] seen;
  assign timers = {last_timer_q, timer_q};
  assign watch_status = {drain_count, 3'd0, frozen, seen};
  always_ff @(posedge clk) begin
    if (rst) begin
      write_q <= 0; accept_q <= 0; frozen <= 0;
      addr_q <= 0; data_q <= 0; pc_q <= 0; be_q <= 0;
      foreground_pc <= 0; process_ptr <= 0;
      timer_q <= 0; last_timer_q <= 0; drain_count <= 0; seen <= 0;
    end else begin
      // Stage the full-rate bus before address decoding; never use ce_pix here.
      write_q <= bus_req && bus_we && bus_ack;
      addr_q <= bus_addr; data_q <= bus_wdata; be_q <= bus_be;
      accept_q <= cpu_retire; pc_q <= cpu_pc;
      if (accept_q && (pc_q == 32'h20813460 || pc_q == 32'hff813460))
        frozen <= 1;
      if (write_q && !frozen) begin
        case (addr_q)
          32'h203f5ae0: begin // game's INTADDR: current display ISR's interrupted PC
            for (integer i=0; i<4; i=i+1) if (be_q[i]) begin
              foreground_pc[i*8 +: 8] <= data_q[i*8 +: 8];
              seen[i] <= 1;
            end
          end
          32'h20517ce0: begin // TIMER is a 16-bit field at +16 bits
            if (be_q[2]) begin timer_q[7:0] <= data_q[23:16]; seen[4] <= 1; end
            if (be_q[3]) begin timer_q[15:8] <= data_q[31:24]; seen[5] <= 1; end
            // Count completed nonzero-to-zero clears, excluding power-up zeroing.
            if (be_q[3:2] == 2'b11 && data_q[31:16] == 0 && timer_q != 0 &&
                &seen[5:4] && drain_count != 16'hffff)
              drain_count <= drain_count + 16'd1;
          end
          32'h20517d00: begin // LAST_TIMER, low 16-bit field
            if (be_q[0]) begin last_timer_q[7:0] <= data_q[7:0]; seen[6] <= 1; end
            if (be_q[1]) begin last_timer_q[15:8] <= data_q[15:8]; seen[7] <= 1; end
          end
          32'h20517c60: begin // THISPROC, 32-bit process pointer
            for (integer i=0; i<4; i=i+1) if (be_q[i]) begin
              process_ptr[i*8 +: 8] <= data_q[i*8 +: 8];
              seen[8+i] <= 1;
            end
          end
          default: ;
        endcase
      end
    end
  end
endmodule
`default_nettype wire
