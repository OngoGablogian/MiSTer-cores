// revx_sdram_selftest.sv -- Revolution X on-chip SDRAM LANE self-test (DIAG v3 -> v4a).
//
// Cabinet build 4 (34020-mode, DIAG v2, 2026-09-07): the derail rows read culprit_pc=0,
// last_good=0, target=FFFFE0E0 -- the reset-vector read returned FFFFE0E0 for FFFDE000, i.e.
// ROM bytes `00 E0 FD FF` arrived as `E0 E0 FF FF`: every 16-bit SDRAM word's LOW byte equals
// its HIGH byte AS RECEIVED BY THE CPU.  CABINET 3 (DIAG v3, 2026-09-07): the SDRAM self-test
// rows measured T1=FFFDE000 (reads/addresses fine after the full-word download), T2=12341234
// (full-word write/read fine), but T3=55555555 -- BOTH masked-write orders read back as the
// LAST write in BOTH lanes.  So the chip does NOT honour the WRITE byte mask (DQM) as driven.
//
// DIAG v4a asks WHY: is DQM ignored for a TIMING reason (H1: the mask arrives a fraction of a
// cycle after DQ/command so the chip samples the idle-low value), or for a non-timing reason
// (H2/H3: pin/board/chip)?  T3 now runs the SAME masked-write sequence TWICE and compares:
//   T3n = NATIVE   masked write (dqm_early=0: DQM asserted only during the WRITE command cycle)
//   T3x = EXTENDED masked write (dqm_early=1: the phy asserts DQM one clock BEFORE the WRITE too)
// If T3n FAILS but T3x PASSES -> H1 (timing; the early-DQM phy option is the silicon fix).
// If BOTH fail -> H2/H3 (DQM ineffective for a non-timing reason; rely on the RMW full-word path).
// If BOTH pass -> the chip is actually fine (flaky / marginal).  The self-test drives the phy
// DIRECTLY through the steal mux (revx_sdram_phys), so it measures the CHIP's DQM behaviour even
// though revx_word_sdram now does read-modify-write for the game's partial writes.
//
// This is a small FSM that runs ONCE at download-complete, while the core is still held in reset
// (P0022 domain), and prints its findings on the DIAG overlay (rows R12-R15) so the cabinet can
// distinguish the classes FROM THE ROWS ALONE (see docs/REVX-CABINET-GUIDE.md decision table).
// It is a boot-time master on the SDRAM word path: revx_sdram_phys inserts it as a 2:1 STEAL MUX
// directly ahead of the sdram_phy word port -- active only while `busy`, when every arb master is
// quiescent (CPU + scanout held in reset, download done), so it needs no new arbiter port and can
// address the full 25-bit word space (scratch above the game map RAM+ROM+VRAM [0,0x280000)).  All results freeze in
// registers; `rst` (a power-on one-shot) clears them.
//
// Sequence (all on 16-bit SDRAM words; held-req-until-ack like the real controller contract):
//   T1  read the two words holding the reset vector (VEC_WORD_LO/HI) -> t1_lo/t1_hi
//       (expect E000 / FFFD).
//   T2  full-word write 0x1234 (be=11) to SCRATCH2, read back -> t2_got (expect 0x1234).  be=11
//       is INSENSITIVE to the write mask, so T2 stays good under a write-mask fault but FAILS
//       under a dead read low-lane.
//   T3n NATIVE masked writes to SCRATCH3   : 0xAAAA be=01 then 0x5555 be=10 -> expect 0x55AA
//       (low<-AA, high<-55) -> t3_got1.  Both writes with dqm_early=0 (native single-cycle mask).
//   T3x EXTENDED masked writes to SCRATCH3X: same 0xAAAA be=01 then 0x5555 be=10, dqm_early=1
//       -> expect 0x55AA -> t3_got2.  A DQM-late chip catches the early mask -> got2 = 55AA even
//       when the native got1 collapses to 5555.
//   T4  read SCRATCH2 twice back-to-back and once after forcing a refresh -> t4_after_refresh
//       (refresh-retention check; the DQM read-capture-timing tap was retired 2026-09-08).
//   status = {done, t1_ok, t2_ok, t3n_ok, t3x_ok}.
//
// Blind of any DUT: expectations are constants transcribed from the cabinet facts + the loader's
// byte-lane pattern, never read back from the RTL (DESIGN-RULES.md s.5).  Pure flip-flops (no arrays
// -> no M10K; a few hundred ALM).  MUTANTs for the gate live in the sim chip (sdram_chip.sv:
// MUT_CHIP_IGNORE_WRITE_DQM, MUT_CHIP_DQM_LATE, MUT_CHIP_LOW_LANE_HIZ), never in this module.
`default_nettype none
module revx_sdram_selftest #(
  // ROM_SDBASE is 0x100000 (after the 2 MiB main RAM, midxunit.cpp:511), so the reset-vector
  // SDRAM words are 0x100000 + (0x1FFFFC>>1)=0xFFFFE -> 0x1FFFFE/0x1FFFFF.
  parameter [24:0] VEC_WORD_LO = 25'h01FFFFE, // SDRAM word holding ROM bytes 0x1FFFFC/D (reset vec lo)
  parameter [24:0] VEC_WORD_HI = 25'h01FFFFF, // SDRAM word holding ROM bytes 0x1FFFFE/F (reset vec hi)
  parameter [15:0] VEC_EXP_LO  = 16'hE000,    // expected content of VEC_WORD_LO
  parameter [15:0] VEC_EXP_HI  = 16'hFFFD,    // expected content of VEC_WORD_HI
  // scratch words ABOVE the game map (RAM+ROM [0,0x200000), VRAM [0x200000,0x280000)).
  parameter [24:0] SCRATCH2    = 25'h0300000, // full-word scratch (above the game map)
  parameter [24:0] SCRATCH3    = 25'h0300001, // native masked-write scratch
  parameter [24:0] SCRATCH3X   = 25'h0300002, // extended (early-DQM) masked-write scratch
  parameter int    REFRESH_WAIT = 800         // clocks to idle so >=1 auto-refresh occurs (T4)
)(
  input  logic        clk,
  input  logic        rst,          // power-on one-shot (P0022 domain): clears the results once
  input  logic        arm,          // level: download complete, run once when ready + not done
  input  logic        ready,        // MT48 init done (safe to issue)

  // ---- word master port -> sdram_phy (via the steal mux in revx_sdram_phys) ----
  output logic [24:0] m_addr,
  output logic [15:0] m_din,
  output logic  [1:0] m_be,
  output logic        m_dqm_early,  // DIAG v4a: ask the phy to assert the write DQM one clock early
  output logic        m_rd,
  output logic        m_wr,
  input  logic [15:0] m_dout,
  input  logic        m_ack,
  output logic        busy,         // steal the phy word port while high

  // ---- frozen results (to the DIAG overlay) ----
  output logic [15:0] t1_lo, t1_hi,
  output logic [15:0] t2_got,
  output logic [15:0] t3_got1, t3_got2,       // T3n native got (exp 55AA) / T3x extended got (exp 55AA)
  output logic [15:0] t4_after_refresh,
  output logic  [4:0] status,       // {done, t1_ok, t2_ok, t3n_ok, t3x_ok}
  output logic        done
);
  // ---------------------------------------------------------------- transaction engine
  // One 16-bit word access at a time, held-req-until-ack + a rd/wr-low gap so the controller's
  // serve-once `served` flag rearms (rtl/sdram/sdram_phy.sv:85,99).
  typedef enum logic [1:0] { TX_IDLE, TX_WAIT, TX_GAP } tx_t;
  tx_t tx;
  logic [24:0] tx_addr; logic [15:0] tx_din; logic [1:0] tx_be; logic tx_we; logic tx_dqm_early;
  logic [15:0] tx_rdata;
  logic        tx_start, tx_done;

  always_ff @(posedge clk) begin
    if (rst) begin
      tx <= TX_IDLE; m_rd <= 1'b0; m_wr <= 1'b0; m_dqm_early <= 1'b0; tx_done <= 1'b0;
      m_addr <= 25'd0; m_din <= 16'd0; m_be <= 2'b00; tx_rdata <= 16'd0;
    end else begin
      tx_done <= 1'b0;
      case (tx)
        TX_IDLE: if (tx_start) begin
                   m_addr <= tx_addr; m_din <= tx_din; m_be <= tx_be;
                   m_dqm_early <= tx_dqm_early & tx_we;   // early DQM only means anything on a write
                   m_rd <= ~tx_we; m_wr <= tx_we;
                   tx <= TX_WAIT;
                 end
        TX_WAIT: if (m_ack) begin
                   if (!tx_we) tx_rdata <= m_dout;
                   m_rd <= 1'b0; m_wr <= 1'b0; m_dqm_early <= 1'b0; tx <= TX_GAP;
                 end
        TX_GAP:  begin tx_done <= 1'b1; tx <= TX_IDLE; end  // one rd/wr-low cycle then complete
        default: tx <= TX_IDLE;
      endcase
    end
  end

  // ---------------------------------------------------------------- sequencer
  typedef enum logic [4:0] {
    S_WAIT_ARM,
    S_T1LO_RD, S_T1LO_CAP, S_T1HI_RD, S_T1HI_CAP,
    S_T2_WR,   S_T2_RD,    S_T2_CAP,
    S_T3N_W1,  S_T3N_W2,   S_T3N_RD, S_T3N_CAP,
    S_T3X_W1,  S_T3X_W2,   S_T3X_RD, S_T3X_CAP,
    S_T4_RD1,  S_T4_RD2,   S_T4_WAIT, S_T4_RD3, S_T4_CAP,
    S_DONE
  } st_t;
  st_t st;
  logic waiting;
  logic [15:0] refwait;
  // Cabinet safety watchdog: the CPU release is gated on `busy` dropping, so a stalled SDRAM must
  // NOT wedge boot.  A healthy run is ~1k cycles; if the FSM has not finished within the 22-bit
  // bound, force S_DONE (stop stealing the phy, release the CPU) -- the frozen rows still show how
  // far it got.  Never fires in a healthy run.
  localparam [21:0] WD_MAX = 22'h3FFFFF;
  logic [21:0] wd;

  // helper: issue a read/write (DE = dqm_early) and advance to `nxt` when it completes
  `define ISSUE(WE, ADDR, DIN, BE, DE, NXT)                         \
    if (!waiting) begin                                              \
      tx_we <= (WE); tx_addr <= (ADDR); tx_din <= (DIN); tx_be <= (BE); \
      tx_dqm_early <= (DE);                                          \
      tx_start <= 1'b1; waiting <= 1'b1;                             \
    end else if (tx_done) begin                                     \
      waiting <= 1'b0; st <= (NXT);                                 \
    end

  always_ff @(posedge clk) begin
    if (rst) begin
      st <= S_WAIT_ARM; waiting <= 1'b0; tx_start <= 1'b0; busy <= 1'b0; done <= 1'b0;
      refwait <= 16'd0; wd <= 22'd0;
      t1_lo <= 16'd0; t1_hi <= 16'd0; t2_got <= 16'd0;
      t3_got1 <= 16'd0; t3_got2 <= 16'd0; t4_after_refresh <= 16'd0;
      tx_we <= 1'b0; tx_addr <= 25'd0; tx_din <= 16'd0; tx_be <= 2'b00; tx_dqm_early <= 1'b0;
    end else begin
      tx_start <= 1'b0;
      if (busy) wd <= wd + 22'd1; else wd <= 22'd0;
      if (busy && wd == WD_MAX) begin
        st <= S_DONE; waiting <= 1'b0;     // watchdog: SDRAM stalled -> release, keep partial rows
      end else
      case (st)
        S_WAIT_ARM: begin
          busy <= 1'b0;
          if (arm && ready && !done) begin busy <= 1'b1; st <= S_T1LO_RD; end
        end
        // ---- T1: reset-vector words ----
        S_T1LO_RD:  begin `ISSUE(1'b0, VEC_WORD_LO, 16'd0, 2'b00, 1'b0, S_T1LO_CAP) end
        S_T1LO_CAP: begin t1_lo <= tx_rdata; st <= S_T1HI_RD; end
        S_T1HI_RD:  begin `ISSUE(1'b0, VEC_WORD_HI, 16'd0, 2'b00, 1'b0, S_T1HI_CAP) end
        S_T1HI_CAP: begin t1_hi <= tx_rdata; st <= S_T2_WR; end
        // ---- T2: full-word (be=11) round-trip on a scratch word ----
        S_T2_WR:    begin `ISSUE(1'b1, SCRATCH2, 16'h1234, 2'b11, 1'b0, S_T2_RD) end
        S_T2_RD:    begin `ISSUE(1'b0, SCRATCH2, 16'd0,    2'b00, 1'b0, S_T2_CAP) end
        S_T2_CAP:   begin t2_got <= tx_rdata; st <= S_T3N_W1; end
        // ---- T3n: NATIVE masked writes (dqm_early=0), expect 0x55AA (low<-AA be01, high<-55 be10) ----
        S_T3N_W1:   begin `ISSUE(1'b1, SCRATCH3, 16'hAAAA, 2'b01, 1'b0, S_T3N_W2) end
        S_T3N_W2:   begin `ISSUE(1'b1, SCRATCH3, 16'h5555, 2'b10, 1'b0, S_T3N_RD) end
        S_T3N_RD:   begin `ISSUE(1'b0, SCRATCH3, 16'd0,    2'b00, 1'b0, S_T3N_CAP) end
        S_T3N_CAP:  begin t3_got1 <= tx_rdata; st <= S_T3X_W1; end
        // ---- T3x: EXTENDED masked writes (dqm_early=1), same sequence, expect 0x55AA ----
        S_T3X_W1:   begin `ISSUE(1'b1, SCRATCH3X, 16'hAAAA, 2'b01, 1'b1, S_T3X_W2) end
        S_T3X_W2:   begin `ISSUE(1'b1, SCRATCH3X, 16'h5555, 2'b10, 1'b1, S_T3X_RD) end
        S_T3X_RD:   begin `ISSUE(1'b0, SCRATCH3X, 16'd0,    2'b00, 1'b0, S_T3X_CAP) end
        S_T3X_CAP:  begin t3_got2 <= tx_rdata; st <= S_T4_RD1; end
        // ---- T4: back-to-back reads, then a read after a forced refresh ----
        S_T4_RD1:   begin `ISSUE(1'b0, SCRATCH2, 16'd0, 2'b00, 1'b0, S_T4_RD2) end
        S_T4_RD2:   begin `ISSUE(1'b0, SCRATCH2, 16'd0, 2'b00, 1'b0, S_T4_WAIT) end
        S_T4_WAIT:  if (refwait >= REFRESH_WAIT[15:0]) begin refwait <= 16'd0; st <= S_T4_RD3; end
                    else refwait <= refwait + 16'd1;
        S_T4_RD3:   begin `ISSUE(1'b0, SCRATCH2, 16'd0, 2'b00, 1'b0, S_T4_CAP) end
        S_T4_CAP:   begin t4_after_refresh <= tx_rdata; st <= S_DONE; end
        S_DONE:     begin done <= 1'b1; busy <= 1'b0; st <= S_WAIT_ARM; end
        default:    st <= S_WAIT_ARM;
      endcase
    end
  end
  `undef ISSUE

  // ---------------------------------------------------------------- verdicts (HW-safe; no === )
  wire t1_ok  = (t1_lo == VEC_EXP_LO) && (t1_hi == VEC_EXP_HI);
  wire t2_ok  = (t2_got == 16'h1234);
  wire t3n_ok = (t3_got1 == 16'h55AA);   // native masked write honoured
  wire t3x_ok = (t3_got2 == 16'h55AA);   // extended (early-DQM) masked write honoured
  assign status = {done, t1_ok, t2_ok, t3n_ok, t3x_ok};
endmodule
`default_nettype wire
