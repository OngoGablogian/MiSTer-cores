// Production POSTCAL_WATCH selects only TC/IP/AC/OB/LA/LD/RT/IR/DR, nine rows
// per column. Legacy modes below remain for standalone bench compatibility and
// are removed by constant elaboration in the production wrapper.
// revx_diag_boot.sv -- Revolution X boot-audit overlay (+define+REVX_DIAG_BOOT).  DIAG v3, Model-1 style.
//
// PIPELINE (see "render PIPELINE" below): the per-pixel text renderer is split into 3 registered
// stages ahead of the output register so the gx->vid_* cone closes slow-corner timing.  Output is
// bit-identical to a flat renderer, delayed 3 ce_pix ticks; passthrough + syncs are delayed to match
// so text lands at the same (gx,gy).  The gate keys capture off the DUT's own output framing.
//
// Screen-as-logic-analyzer (DESIGN-RULES.md s.6): paints the X-unit boot/derail state onto the video
// output as small WHITE text over the LIVE GAME RASTER -- no opaque panel, no colour bars.  Every
// pixel that is NOT a lit glyph pixel passes the game's RGB through UNCHANGED (this is the "no
// background" the user asked for; unlike Model 1 the pass-through is NOT dimmed).  Because the game
// now renders behind it, the text hugs the top-left and top-right corners and the centre + the
// lower ~2/3 of the picture stay clear.
//
// FONT: 5x7 pixel glyphs at 1:1 scale, ported VERBATIM from Model 1's telemetry overlay
//   D:/deck/fpga/segamodel1/phase0/model1-live-list-rtl/rtl/model1_telemetry_overlay.sv:122-177
//   (glyph() ASCII-keyed, 5 bits per row x 7 rows; fixed-row select, NOT a barrel shifter).  Only
//   the characters RevX needs are transcribed: hex 0-9 / A-F plus the tag letters G I L O P R S T.
//   hx() (nibble->ASCII) mirrors that file's hx().
//
// LAYOUT (all coords are ACTIVE-raster pixels; HACT=340, VACT=240):
//   char celln = 6 px wide (5-px glyph + 1-px gap); line pitch = 10 px (7-px glyph + 3-px gap).
//   Each row = a 2-char tag, a space, then 8 hex digits = 11 cells = 66 px wide.
//   8 text rows, y-band r at gy [8+10r .. 14+10r] (rows at 8,18,28,38,48,58,68,78; last ends 84).
//   LEFT  column  X0L = 4   (spans gx  4.. 69)  = rows R0-R7
//   RIGHT column  X0R = 270 (spans gx 270..335) = rows R8-R15
//
//   LEFT column (tag : value):
//     R0 PC  live CPU PC (~2 Hz)
//     R1 FA  last fetch ADDRESS (PS sticky milestones when POST_CHECKPOINTS=1)
//     R2 FD  last fetch DATA    (LP last new milestone PC when POST_CHECKPOINTS=1)
//     R3 RT  retired-instruction counter
//     R4 LD  {acc_prog[23:8], acc_gfx[23:8]}                    loader byte counters
//     R5 DR  {acc_dcs[23:8], 7'0, rst_during_dl, drop_any[7:0]} P0022 reset-during-download latch
//     R6 IS  {sdram_init, ddr3_init, pic_status, 0, 12'0, dcs_status[15:0]}
//     R7 IO  {8'0, adc_chan, uart_last_byte, adc_last}
//   RIGHT column (tag : value) -- DIAG v2 derail (R8-R11) + interrupt state (R13/R14, DIAG v4b) +
//   the two surviving SDRAM canaries (R12 T1, R15 ST):
//     R8  CP culprit_pc    -- PREVIOUS retired PC (the instruction that left the legit path)
//     R9  TG target_pc     -- the offending PC it landed on (e.g. FFFFE190, the data table)
//     R10 LG last_good_pc  -- running: most recent legit retired PC (safety net)
//     R11 CI {culprit_instr[15:0], 14'0, int_captured, derail_captured}  (the source opcode + flags)
//     R12 T1 {st_t1_hi, st_t1_lo}  reset-vector read-back canary (healthy FFFDE000 = FFFD:E000)
//     R13 IE {intpend[15:0], intenb[15:0]}  CPU-domain INTPEND (hi 4 digits) : INTENB (lo 4 digits).
//            INTENB.DI (INT_DI_BIT=10 -> mask bit 0x0400) is the per-source display-int enable.
//     R14 IX {28'0, disp_int, st_ie, int_captured, derail_captured}  (LOW NIBBLE, MSB->LSB):
//            bit3 disp_int      = live INTPEND.DI (a display interrupt IS pending at the pin)
//            bit2 st_ie         = ST[21] live global interrupt enable. Zero can mean initialization,
//                                 an ISR, or the game's deliberate lockup; PS retains earlier EINT.
//                                 One means interrupts are armed: inspect INTENB/INTPEND (R13).
//            bit1 int_captured  = the derail instrument saw the first interrupt entry (ever taken)
//            bit0 derail_captured = the derail instrument latched a bad PC
//            So a healthy "IRQs armed but never fired" reads IX low nibble = 1100..1110; the
//            2026-09-07 poll-loop deadlock is expected to read st_ie=0 (int_captured=0) => nibble 8xx0.
//     R15 ST {3'0, st_status[4:0], 8'0, st_t4_refresh[15:0]}  SDRAM self-test status canary
//            status = {done, T1_ok, T2_ok, T3n_ok, T3x_ok} (healthy 1F -> ST 1F001234).
//   TIMER_WATCH replaces R8..R11 with IP/TC/PR/TS: the game's INTADDR,
//   {LAST_TIMER,TIMER}, THISPROC, and {drain_count,3'b0,frozen,seen_byte_lanes}.
//   Those fields come from completed CPU-write shadows in revx_timer_capture;
//   see docs/REVX-SRT-RATE-CABINET-20260909.md for capture validity.
//   The SDRAM self-test T2/T3 rows were RETIRED here (the chip ignores the write byte-mask -- an
//   ANSWERED question; partial writes now use read-modify-write).  T1 (memory-health canary) and
//   ST (self-test status incl. done/T1/T2/T3n/T3x) remain.  The interrupt decision table is in
//   docs/REVX-CABINET-GUIDE.md.
//
// MUTANTS (both killed by sim/run_revx_diag_boot.sh):
//   REVX_DIAG_GLYPH_MUTANT corrupts one font glyph -> a rendered digit is wrong -> the golden
//     bitmap compare FAILS (the font render is load-bearing).
//   REVX_DIAG_BG_MUTANT re-introduces a background panel behind the text -> a non-glyph overlay
//     pixel no longer equals rgb_in -> the transparency check FAILS (the pass-through is load-bearing).
`default_nettype none
module revx_diag_boot #(
  parameter bit SHOW_TEXT = 1'b1,
  parameter bit POST_CHECKPOINTS = 1'b0,
  parameter bit TIMER_WATCH = 1'b0,
  parameter bit POSTCAL_WATCH = 1'b0
)(
  input  logic        clk, ce_pix, rst,
  // boot-audit taps
  input  logic [31:0] cpu_pc,
  input  logic        cpu_retire,
  input  logic [31:0] last_fetch_addr,
  input  logic [31:0] last_fetch_data,
  input  logic [31:0] acc_prog, acc_gfx, acc_dcs,
  input  logic  [7:0] drop_any,
  input  logic        rst_during_dl,
  input  logic        sdram_init_done, ddr3_init_done,
  input  logic        pic_status,
  input  logic [15:0] dcs_status,
  input  logic  [7:0] uart_last_byte,
  input  logic  [7:0] adc_chan, adc_last,
  // ---- DIAG v2: derail + first-interrupt + io taps (from revx_derail_capture) ----
  input  logic [31:0] culprit_pc, target_pc, last_good_pc,
  input  logic [15:0] culprit_instr,
  input  logic        derail_captured,
  input  logic [31:0] int_pc, int_vec_addr, int_vec_value,
  input  logic  [7:0] int_count,
  input  logic        int_captured,
  input  logic [15:0] intpend, intenb,
  input  logic        disp_int,
  input  logic        st_ie,               // CPU ST global interrupt-enable (ST[21]); decisive bit
  input  logic [31:0] foreground_pc, timers, process_ptr, watch_status,
  // ---- DIAG v3: SDRAM lane self-test rows (revx_sdram_selftest, R12-R15) ----
  input  logic [15:0] st_t1_lo, st_t1_hi,        // T1 reset-vector words (expect E000 / FFFD)
  input  logic [15:0] st_t2_got,                 // T2 full-word (be=11) scratch read-back (expect 1234)
  input  logic [15:0] st_t3_got1, st_t3_got2,    // T3n native / T3x extended-DQM masked write (expect 55AA / 55AA)
  input  logic [15:0] st_t4_refresh,             // T4 post-refresh reread (refresh-retention check)
  input  logic  [4:0] st_status,                 // {done, t1_ok, t2_ok, t3n_ok, t3x_ok}
  // Minimal post-calibration view: early epoch on left, fatal epoch on right.
  input logic [287:0] postcal_early, postcal_final,
  // game video passthrough
  input  logic  [7:0] g_r, g_g, g_b,
  input  logic        g_hs, g_vs, g_hb, g_vb, g_de,
  output logic  [7:0] vid_r, vid_g, vid_b,
  output logic        hsync, vsync, hblank, vblank, de
);
  // Full-rate observer only: sample the existing instruction-acceptance tap before decoding.
  // No ce_pix dependency or CPU feedback; the separate TIMER_WATCH inputs are
  // passive memory-write shadows and do not alter this video pipeline.
  // L2 executes these ROM-resident routines after relocation from FFxxxxxx to 20xxxxxx.
  // Accept either exact alias; a match means instruction accepted, not instruction completed.
  logic [31:0] checkpoint_pc_q, checkpoint_last_pc;
  logic checkpoint_accept_q;
  logic [15:0] checkpoint_hit, checkpoint_seen;
  always_comb begin
    checkpoint_hit = 16'd0;
    if (checkpoint_pc_q[31:24] == 8'h20 || checkpoint_pc_q[31:24] == 8'hff) begin
      case (checkpoint_pc_q[23:0])
        24'h8038b0: checkpoint_hit[0]  = 1'b1; // POST return: call MAIN_INIT
        24'h804410: checkpoint_hit[1]  = 1'b1; // MAIN_INIT entry
        24'haea870: checkpoint_hit[2]  = 1'b1; // SCRCLR entry
        24'haeb1c0: checkpoint_hit[3]  = 1'b1; // CLEAR_PAGE2 entry
        24'haeb340: checkpoint_hit[4]  = 1'b1; // CLEAR_PAGE3 entry
        24'haf6d80: checkpoint_hit[5]  = 1'b1; // QSNDRST entry
        24'h804a50: checkpoint_hit[6]  = 1'b1; // MAIN_INIT restoring saved register
        24'h803900: checkpoint_hit[7]  = 1'b1; // EINT (live IX bit2 confirms current IE)
        24'h803920: checkpoint_hit[8]  = 1'b1; // DISPLAYON=1 store
        24'haf1350: checkpoint_hit[9]  = 1'b1; // PRCDSP entry
        24'h8128a0: checkpoint_hit[10] = 1'b1; // display ISR entry
        24'h8133f0: checkpoint_hit[11] = 1'b1; // TIMER increment store
        24'h8d9750: checkpoint_hit[12] = 1'b1; // queued-DMA ISR entry
        24'h812320: checkpoint_hit[13] = 1'b1; // actual SRT load instruction
        24'h8123c0: checkpoint_hit[14] = 1'b1; // actual SRT write instruction
        24'h813460: checkpoint_hit[15] = 1'b1; // permanent TIMER>=200 lockup
        default: ;
      endcase
    end
  end
  always_ff @(posedge clk) begin
    if (rst) begin
      checkpoint_pc_q <= 32'd0;
      checkpoint_accept_q <= 1'b0;
      checkpoint_seen <= 16'd0;
      checkpoint_last_pc <= 32'd0;
    end else begin
      checkpoint_pc_q <= cpu_pc;
      checkpoint_accept_q <= cpu_retire;
      if (!POSTCAL_WATCH && POST_CHECKPOINTS && checkpoint_accept_q) begin
        checkpoint_seen <= checkpoint_seen | checkpoint_hit;
        // Recurring IRQs cannot overwrite earlier progress. Preserve a captured terminal lockup.
        if (|(checkpoint_hit & ~checkpoint_seen) && !checkpoint_seen[15])
          checkpoint_last_pc <= checkpoint_pc_q;
      end
    end
  end

  // ---- 5x7 font, ported verbatim from model1_telemetry_overlay.sv:122-177 -------------------
  // ASCII-keyed; returns one 5-bit glyph row (MSB = leftmost pixel).  Fixed-row select (no barrel
  // shifter) exactly as the Model 1 source.
  function automatic [7:0] hx(input [3:0] n);   // nibble -> ASCII (mirrors telemetry hx())
    hx = (n < 4'ha) ? (8'h30 + {4'd0,n}) : (8'h41 + {4'd0,n} - 8'd10);
  endfunction
  function automatic [4:0] glyph(input [7:0] ch, input [2:0] row);
    logic [34:0] f;
    case (ch)
      "0": f={5'b01110,5'b10001,5'b10011,5'b10101,5'b11001,5'b10001,5'b01110};
      "1": f={5'b00100,5'b01100,5'b00100,5'b00100,5'b00100,5'b00100,5'b01110};
      "2": f={5'b01110,5'b10001,5'b00001,5'b00010,5'b00100,5'b01000,5'b11111};
      "3": f={5'b11110,5'b00001,5'b00001,5'b01110,5'b00001,5'b00001,5'b11110};
      "4": f={5'b00010,5'b00110,5'b01010,5'b10010,5'b11111,5'b00010,5'b00010};
`ifdef REVX_DIAG_GLYPH_MUTANT
      "5": f={5'b11111,5'b10000,5'b10000,5'b10000,5'b00001,5'b00001,5'b11110}; // MUTANT: row3 corrupted
`else
      "5": f={5'b11111,5'b10000,5'b10000,5'b11110,5'b00001,5'b00001,5'b11110};
`endif
      "6": f={5'b01110,5'b10000,5'b10000,5'b11110,5'b10001,5'b10001,5'b01110};
      "7": f={5'b11111,5'b00001,5'b00010,5'b00100,5'b01000,5'b01000,5'b01000};
      "8": f={5'b01110,5'b10001,5'b10001,5'b01110,5'b10001,5'b10001,5'b01110};
      "9": f={5'b01110,5'b10001,5'b10001,5'b01111,5'b00001,5'b00001,5'b01110};
      "A": f={5'b01110,5'b10001,5'b10001,5'b11111,5'b10001,5'b10001,5'b10001};
      "B": f={5'b11110,5'b10001,5'b10001,5'b11110,5'b10001,5'b10001,5'b11110};
      "C": f={5'b01111,5'b10000,5'b10000,5'b10000,5'b10000,5'b10000,5'b01111};
      "D": f={5'b11110,5'b10001,5'b10001,5'b10001,5'b10001,5'b10001,5'b11110};
      "E": f={5'b11111,5'b10000,5'b10000,5'b11110,5'b10000,5'b10000,5'b11111};
      "F": f={5'b11111,5'b10000,5'b10000,5'b11110,5'b10000,5'b10000,5'b10000};
      "G": f={5'b01111,5'b10000,5'b10000,5'b10111,5'b10001,5'b10001,5'b01111};
      "I": f={5'b01110,5'b00100,5'b00100,5'b00100,5'b00100,5'b00100,5'b01110};
      "L": f={5'b10000,5'b10000,5'b10000,5'b10000,5'b10000,5'b10000,5'b11111};
      "O": f={5'b01110,5'b10001,5'b10001,5'b10001,5'b10001,5'b10001,5'b01110};
      "P": f={5'b11110,5'b10001,5'b10001,5'b11110,5'b10000,5'b10000,5'b10000};
      "R": f={5'b11110,5'b10001,5'b10001,5'b11110,5'b10100,5'b10010,5'b10001};
      "S": f={5'b01111,5'b10000,5'b10000,5'b01110,5'b00001,5'b00001,5'b11110};
      "T": f={5'b11111,5'b00100,5'b00100,5'b00100,5'b00100,5'b00100,5'b00100};
      default: f=35'd0;   // space and anything unused -> blank
    endcase
    case (row)
      3'd0: glyph=f[34:30]; 3'd1: glyph=f[29:25]; 3'd2: glyph=f[24:20];
      3'd3: glyph=f[19:15]; 3'd4: glyph=f[14:10]; 3'd5: glyph=f[9:5];
      3'd6: glyph=f[4:0];   default: glyph=5'd0;
    endcase
  endfunction

  // ---- input-registration stage (TIMING) -------------------------------------------------
  // Latch every display tap + the game-video passthrough once, on ce_pix, before the geometry
  // and the pixel mux.  cpu_retire is NOT latched here -- it feeds the full-rate retired counter
  // below and must count every clk edge, not only ce_pix ticks.
  logic [287:0] postcal_early_q, postcal_final_q;
  logic [31:0] cpu_pc_q, lfa_q, lfd_q, acc_prog_q, acc_gfx_q, acc_dcs_q;
  logic  [7:0] drop_any_q, uart_last_q, adc_chan_q, adc_last_q;
  logic        rst_dl_q, sdram_q, ddr3_q, pic_q;
  logic [15:0] dcs_status_q;
  // DIAG v2 registered taps (only the ones actually displayed)
  logic [31:0] culprit_pc_q, target_pc_q, last_good_pc_q;
  logic [15:0] culprit_instr_q;
  logic        derail_captured_q, int_captured_q;
  logic [15:0] intpend_q, intenb_q;         // DIAG v4b: INTPEND/INTENB shadows for the IE row
  logic        disp_int_q, st_ie_q;          // DIAG v4b: live display-int line + ST global IE for the IX row
  logic [15:0] checkpoint_seen_q;
  logic [31:0] checkpoint_last_pc_q;
  logic [31:0] foreground_pc_q, timers_q, process_ptr_q, watch_status_q;
  // DIAG v3 self-test registered taps
  logic [15:0] st_t1_lo_q, st_t1_hi_q, st_t2_got_q, st_t3_got1_q, st_t3_got2_q, st_t4_refresh_q;
  logic  [4:0] st_status_q;
  // Preserve the short pixel pipeline in logic. Packing these taps into a
  // shared shift RAM erased the intended register boundary at the game raster.
  (* ramstyle = "logic" *) logic [7:0] gr_q, gg_q, gb_q;
  (* ramstyle = "logic" *) logic ghs_q, gvs_q, ghb_q, gvb_q, gde_q;
  always_ff @(posedge clk) if (ce_pix) begin
    postcal_early_q<=postcal_early; postcal_final_q<=postcal_final;
    cpu_pc_q<=cpu_pc; lfa_q<=last_fetch_addr; lfd_q<=last_fetch_data;
    acc_prog_q<=acc_prog; acc_gfx_q<=acc_gfx; acc_dcs_q<=acc_dcs;
    drop_any_q<=drop_any; rst_dl_q<=rst_during_dl; sdram_q<=sdram_init_done;
    ddr3_q<=ddr3_init_done; pic_q<=pic_status; dcs_status_q<=dcs_status;
    uart_last_q<=uart_last_byte; adc_chan_q<=adc_chan; adc_last_q<=adc_last;
    culprit_pc_q<=culprit_pc; target_pc_q<=target_pc; last_good_pc_q<=last_good_pc;
    culprit_instr_q<=culprit_instr; derail_captured_q<=derail_captured;
    int_captured_q<=int_captured;
    intpend_q<=intpend; intenb_q<=intenb; disp_int_q<=disp_int; st_ie_q<=st_ie;
    checkpoint_seen_q<=checkpoint_seen; checkpoint_last_pc_q<=checkpoint_last_pc;
    foreground_pc_q<=foreground_pc; timers_q<=timers;
    process_ptr_q<=process_ptr; watch_status_q<=watch_status;
    st_t1_lo_q<=st_t1_lo; st_t1_hi_q<=st_t1_hi; st_t2_got_q<=st_t2_got;
    st_t3_got1_q<=st_t3_got1; st_t3_got2_q<=st_t3_got2;
    st_t4_refresh_q<=st_t4_refresh; st_status_q<=st_status;
    gr_q<=g_r; gg_q<=g_g; gb_q<=g_b;
    ghs_q<=g_hs; gvs_q<=g_vs; ghb_q<=g_hb; gvb_q<=g_vb; gde_q<=g_de;
  end

  // ---- game raster tracking (real active coords) ----
  logic [11:0] gx, gy; logic de_q, vb_q; logic [23:0] frame;
  logic [31:0] pc_q, pc_show, retired;
  always_ff @(posedge clk) begin
    if (rst) begin gx<=0; gy<=0; de_q<=0; vb_q<=0; frame<=0; pc_q<=0; pc_show<=0; retired<=0; end
    else begin
      if (!POSTCAL_WATCH && cpu_retire) retired <= retired + 32'd1;
      if (ce_pix) begin
        de_q<=gde_q; vb_q<=gvb_q; pc_q<=cpu_pc_q;
        if (gvb_q && !vb_q) begin gy<=12'd0; gx<=12'd0; frame<=frame+24'd1;
          if (frame[4:0]==5'd0) pc_show<=pc_q; end
        else if (gde_q) gx<=gx+12'd1;
        else if (de_q && !gde_q) begin gx<=12'd0; gy<=gy+12'd1; end
      end
    end
  end

  // ---- row value select (4-bit index; R0-R7 left column, R8-R15 right column) ----
  function automatic [31:0] rowval(input [4:0] r);
    logic [287:0] snap;
    if (POSTCAL_WATCH) begin
      snap = r[4] ? postcal_final_q : postcal_early_q;
      case (r[3:0])
        0: rowval=snap[31:0];    1: rowval=snap[63:32];
        2: rowval=snap[95:64];   3: rowval=snap[127:96];
        4: rowval=snap[159:128]; 5: rowval=snap[191:160];
        6: rowval=snap[223:192]; 7: rowval=snap[255:224];
        8: rowval=snap[287:256]; default: rowval=0;
      endcase
    end else case (r[3:0])
      4'd0:  rowval = pc_show;
      4'd1:  rowval = POST_CHECKPOINTS ? {16'd0, checkpoint_seen_q} : lfa_q;
      4'd2:  rowval = POST_CHECKPOINTS ? checkpoint_last_pc_q : lfd_q;
      4'd3:  rowval = retired;
      4'd4:  rowval = {acc_prog_q[23:8], acc_gfx_q[23:8]};
      4'd5:  rowval = {acc_dcs_q[23:8], 7'd0, rst_dl_q, drop_any_q};
      4'd6:  rowval = {sdram_q, ddr3_q, pic_q, 1'b0, 12'd0, dcs_status_q};
      4'd7:  rowval = {8'd0, adc_chan_q, uart_last_q, adc_last_q};
      4'd8:  rowval = TIMER_WATCH ? foreground_pc_q : culprit_pc_q;
      4'd9:  rowval = TIMER_WATCH ? timers_q : target_pc_q;
      4'd10: rowval = TIMER_WATCH ? process_ptr_q : last_good_pc_q;
      4'd11: rowval = TIMER_WATCH ? watch_status_q : {culprit_instr_q, 14'd0, int_captured_q, derail_captured_q};
      4'd12: rowval = {st_t1_hi_q, st_t1_lo_q};                       // T1 reset-vector {hi,lo}
      4'd13: rowval = {intpend_q, intenb_q};                          // IE {INTPEND, INTENB} CPU-domain shadows
      4'd14: rowval = {28'd0, disp_int_q, st_ie_q, int_captured_q, derail_captured_q}; // IX flags (low nibble)
      default: rowval = {3'd0, st_status_q, 8'd0, st_t4_refresh_q};   // R15 status + T4 post-refresh
    endcase
  endfunction

  // ---- 2-char row tag (packed {char0, char1}) ----
  function automatic [15:0] rowtag(input [4:0] r);
    if (POSTCAL_WATCH) begin
      case (r[3:0])
        0: rowtag="TC"; 1: rowtag="IP"; 2: rowtag="AC";
        3: rowtag="OB"; 4: rowtag="LA"; 5: rowtag="LD";
        6: rowtag="RT"; 7: rowtag="IR"; 8: rowtag="DR";
        default: rowtag="  ";
      endcase
    end else case (r[3:0])
      4'd0:  rowtag = "PC";
      4'd1:  rowtag = POST_CHECKPOINTS ? "PS" : "FA";
      4'd2:  rowtag = POST_CHECKPOINTS ? "LP" : "FD";
      4'd3:  rowtag = "RT";
      4'd4:  rowtag = "LD";  4'd5:  rowtag = "DR";  4'd6:  rowtag = "IS";  4'd7:  rowtag = "IO";
      4'd8:  rowtag = TIMER_WATCH ? "IP" : "CP";
      4'd9:  rowtag = TIMER_WATCH ? "TC" : "TG";
      4'd10: rowtag = TIMER_WATCH ? "PR" : "LG";
      4'd11: rowtag = TIMER_WATCH ? "TS" : "CI";
      4'd12: rowtag = "T1";  4'd13: rowtag = "IE";  4'd14: rowtag = "IX";  default: rowtag = "ST";
    endcase
  endfunction

  // ---- geometry: 8 y-bands (pitch 10) x 2 columns x (2 tag + space + 8 hex) cells ----
  localparam int X0L = 4, X0R = 270, CW = 6, NCH = 11, COLW = NCH*CW; // 66 px per column
  // ---- render PIPELINE (TIMING FIX for slow-corner gx -> vid_b cone) --------------------------
  // Model 1's telemetry overlay (model1_telemetry_overlay.sv:259-555) splits the per-pixel text
  // renderer across registered stages so no single combinational cone runs from the pixel counter
  // to the video output.  The RevX restyle (commit 3ca933a) took Model 1's font+layout but kept the
  // renderer FLAT: gx -> (xoff*171 /6) -> rowval() 16:1 mux -> nibble shift -> glyph() ROM -> pixel
  // mux -> vid_* was one cone (STA: 12 logic levels, 16.6 ns @ Slow/100C, slack -4.4 ns).  Below it
  // is cut into 3 registered stages (r1/r2/r3) ahead of the existing output register, mirroring the
  // Model 1 "_s1 addressing stage, then registered rgb_out" shape.
  //
  // LATENCY COMPENSATION: the visible output is IDENTICAL to the flat version, delayed by exactly
  // 3 ce_pix ticks.  The passthrough video AND the sync/de/blank are delayed by the SAME 3 ticks
  // (gr_d*/gg_d*/gb_d* and gde_d*/ghs_d*/... below), so the ENTIRE output stream is uniformly
  // shifted -- every glyph lands at the same (gx,gy) relative to the game raster and the syncs.
  // (Proof: new vid(t)=f(gde,glyph_on(gx),gr) each fed from signals delayed 3, so new vid(t)==old
  // vid(t-3); likewise every sync.)  The gate re-derives (x,y) from the DUT's OWN output de/vblank,
  // so it needs no latency constant and the golden lands at the same coordinates.
  //   S0 (comb, gx/gy):  band decode + column decode + xoff*171 /6 -> celln            -> r1
  //   S1 (comb, r1):     celln*6 -> fx, rowidx, digidx, rowval() 16:1, rowtag()        -> r2
  //   S2 (comb, r2):     nibble select (8:1, == rv>>((7-digidx)*4)) -> ch              -> r3
  //   S3 (comb, r3):     glyph() ROM -> fpix -> {white | passthrough}                  -> output reg

  // -- S0 combinational: geometry from the pixel counters --
  logic [3:0] yrow0; logic [2:0] frow0; logic in_band0;
  always_comb begin
    in_band0=1'b0; yrow0=3'd0; frow0=3'd0;
    if      (gy>=12'd8  && gy<=12'd14) begin yrow0=3'd0; frow0=(gy-12'd8);  in_band0=1'b1; end
    else if (gy>=12'd18 && gy<=12'd24) begin yrow0=3'd1; frow0=(gy-12'd18); in_band0=1'b1; end
    else if (gy>=12'd28 && gy<=12'd34) begin yrow0=3'd2; frow0=(gy-12'd28); in_band0=1'b1; end
    else if (gy>=12'd38 && gy<=12'd44) begin yrow0=3'd3; frow0=(gy-12'd38); in_band0=1'b1; end
    else if (gy>=12'd48 && gy<=12'd54) begin yrow0=3'd4; frow0=(gy-12'd48); in_band0=1'b1; end
    else if (gy>=12'd58 && gy<=12'd64) begin yrow0=3'd5; frow0=(gy-12'd58); in_band0=1'b1; end
    else if (gy>=12'd68 && gy<=12'd74) begin yrow0=3'd6; frow0=(gy-12'd68); in_band0=1'b1; end
    else if (gy>=12'd78 && gy<=12'd84) begin yrow0=4'd7; frow0=(gy-12'd78); in_band0=1'b1; end
    else if (POSTCAL_WATCH && gy>=12'd88 && gy<=12'd94) begin yrow0=4'd8; frow0=(gy-12'd88); in_band0=1'b1; end
  end
  wire        in_left0  = (gx >= X0L) && (gx < X0L + COLW);
  wire        in_right0 = (gx >= X0R) && (gx < X0R + COLW);
  wire        in_col0   = in_left0 || in_right0;
  wire [11:0] xoff0     = in_right0 ? (gx - X0R[11:0]) : (gx - X0L[11:0]);   // 0..65 when in_col
  // floor(xoff/6) == (xoff*171)>>10 over 0..207 -- IDENTICAL to the flat version's divide.
  wire [23:0] xmul0     = xoff0 * 24'd171;
  wire [7:0]  celln0    = xmul0[17:10];                                      // 0..10

  logic in_band_1, in_col_1, colsel_1;
  logic [3:0] yrow_1; logic [2:0] frow_1;
  logic [6:0] xoff_1;                 // 0..65 in-column; only fx uses it
  logic [7:0] celln_1;
  always_ff @(posedge clk) if (ce_pix) begin
    in_band_1<=in_band0; in_col_1<=in_col0; colsel_1<=in_right0;
    yrow_1<=yrow0; frow_1<=frow0; xoff_1<=xoff0[6:0]; celln_1<=celln0;
  end

  // -- S1 combinational: cell/char index resolution + row value/tag mux --
  wire [11:0] cellx6_1 = ({4'd0,celln_1} << 2) + ({4'd0,celln_1} << 1);     // celln*6
  wire [2:0]  fx_1     = xoff_1 - cellx6_1[6:0];                            // 0..5 (5 = gap)
  wire [4:0]  rowidx_1 = POSTCAL_WATCH ? {colsel_1, yrow_1} : {1'b0, colsel_1, yrow_1[2:0]};
  wire [2:0]  digidx_1 = celln_1[2:0] - 3'd3;                               // valid celln 3..10
  wire [31:0] rv_1     = rowval(rowidx_1);
  wire [15:0] tagw_1   = rowtag(rowidx_1);

  logic in_band_2, in_col_2;
  logic [2:0] frow_2, fx_2, digidx_2;
  logic [7:0] celln_2;
  logic [31:0] rv_2; logic [15:0] tagw_2;
  always_ff @(posedge clk) if (ce_pix) begin
    in_band_2<=in_band_1; in_col_2<=in_col_1; frow_2<=frow_1; fx_2<=fx_1;
    digidx_2<=digidx_1; celln_2<=celln_1; rv_2<=rv_1; tagw_2<=tagw_1;
  end

  // -- S2 combinational: select this cell's character --
  // nibble select is an 8:1 mux == (rv_2 >> ((7-digidx_2)*4))[3:0], bit-identical to the flat form
  // and to the gate's exp_rowval>>((10-celln)*4); it avoids a 32-bit barrel shifter on the cone.
  logic [3:0] nyb_2; logic [7:0] ch_2;
  always_comb begin
    case (digidx_2)
      3'd0: nyb_2 = rv_2[31:28]; 3'd1: nyb_2 = rv_2[27:24]; 3'd2: nyb_2 = rv_2[23:20];
      3'd3: nyb_2 = rv_2[19:16]; 3'd4: nyb_2 = rv_2[15:12]; 3'd5: nyb_2 = rv_2[11:8];
      3'd6: nyb_2 = rv_2[7:4];   default: nyb_2 = rv_2[3:0];
    endcase
    ch_2 = (celln_2 == 8'd0) ? tagw_2[15:8] :
           (celln_2 == 8'd1) ? tagw_2[7:0]  :
           (celln_2 == 8'd2) ? 8'h20        : hx(nyb_2);
  end

  logic [7:0] ch_3; logic [2:0] frow_3, fx_3; logic valid_3;
  always_ff @(posedge clk) if (ce_pix) begin
    ch_3<=ch_2; frow_3<=frow_2; fx_3<=fx_2; valid_3<=(in_band_2 && in_col_2);
  end

  // -- S3 combinational: glyph ROM -> this pixel --
  wire [4:0] gbits_3 = glyph(ch_3, frow_3);
  // glyph bit for this column: fx 0..4 select MSB..LSB (leftmost pixel = gbits[4]); fx 5 = gap.
  wire       fpix_3     = (fx_3 < 3'd5) ? gbits_3[3'd4 - fx_3] : 1'b0;
  wire       glyph_on   = SHOW_TEXT && valid_3 && fpix_3;
  wire       in_overlay = SHOW_TEXT && valid_3;     // text region (used only by the BG mutant)

  // -- passthrough video + timing, delayed by the SAME 3 ce_pix ticks as the glyph pipeline --
  (* ramstyle = "logic" *) logic [7:0] gr_d1,gr_d2,gr_d3, gg_d1,gg_d2,gg_d3, gb_d1,gb_d2,gb_d3;
  (* ramstyle = "logic" *) logic ghs_d1,ghs_d2,ghs_d3, gvs_d1,gvs_d2,gvs_d3, ghb_d1,ghb_d2,ghb_d3;
  (* ramstyle = "logic" *) logic gvb_d1,gvb_d2,gvb_d3, gde_d1,gde_d2,gde_d3;
  always_ff @(posedge clk) if (ce_pix) begin
    gr_d1<=gr_q;   gr_d2<=gr_d1;   gr_d3<=gr_d2;
    gg_d1<=gg_q;   gg_d2<=gg_d1;   gg_d3<=gg_d2;
    gb_d1<=gb_q;   gb_d2<=gb_d1;   gb_d3<=gb_d2;
    ghs_d1<=ghs_q; ghs_d2<=ghs_d1; ghs_d3<=ghs_d2;
    gvs_d1<=gvs_q; gvs_d2<=gvs_d1; gvs_d3<=gvs_d2;
    ghb_d1<=ghb_q; ghb_d2<=ghb_d1; ghb_d3<=ghb_d2;
    gvb_d1<=gvb_q; gvb_d2<=gvb_d1; gvb_d3<=gvb_d2;
    gde_d1<=gde_q; gde_d2<=gde_d1; gde_d3<=gde_d2;
  end

  // ---- output: white glyph over unchanged pass-through (no panel, no dim) ----
  always_ff @(posedge clk) if (ce_pix) begin
    de<=gde_d3; hsync<=ghs_d3; vsync<=gvs_d3; hblank<=ghb_d3; vblank<=gvb_d3;
    if (!gde_d3)         begin vid_r<=8'd0;  vid_g<=8'd0;  vid_b<=8'd0;  end   // blank
    else if (glyph_on)   begin vid_r<=8'hFF; vid_g<=8'hFF; vid_b<=8'hFF; end   // white glyph
    else begin
`ifdef REVX_DIAG_BG_MUTANT
      if (in_overlay)    begin vid_r<=8'h10; vid_g<=8'h10; vid_b<=8'h30; end   // MUTANT panel (must FAIL transparency)
      else               begin vid_r<=gr_d3; vid_g<=gg_d3; vid_b<=gb_d3; end
`else
                         begin vid_r<=gr_d3; vid_g<=gg_d3; vid_b<=gb_d3; end   // pass-through UNCHANGED
`endif
    end
  end
endmodule
`default_nettype wire
