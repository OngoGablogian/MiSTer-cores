#!/usr/bin/env bash
# run_revx_converted_boot.sh <run_dir> -- CONVERTED-NETLIST cold-boot gate.
#
# The gate that would have caught cabinet-1 (2026-09-07): the sv2v conversion that Quartus
# actually synthesises had TMS_IS_34020 baked to 1'b0 (builds 1-3), shipping a 34010-mode
# core, while every SIM runner passed -DTMS_IS_34020=1'b1 -> "sim green, cab black"
# (DESIGN-RULES.md s.6).  This gate runs the SAME 8000-row cold-boot PC diff as
# run_revx_top_boot.sh (same bench tb_revx_top_boot, same sim models, same ROM/golden, same
# dedup rule, same PASS criteria) but on <run_dir>/build_syn/revx_core.v -- the exact
# converted file the fitter reads -- and passes NO TMS_IS_34020 define (the value is baked
# into the converted file).  Only the bench + sim models are down-converted by sv2v here; the
# core-under-test is the untouched prepared netlist.
#
# Discrimination: a PC diff ALONE cannot tell 34010 from 34020 (measured: both pass 8000/8000
# byte-identically -- the boot window stays in ROM and the 34010 illegal-opcode handling does
# not trap).  So the gate ALSO runs revx_illop_guard, which asserts the CPU illegal-opcode
# latch (tms34010_core.illegal_q) stays clear across the boot.  A 34010-mode netlist latches
# it at the BLMOVE (instr 0x00F3 @ FFFDE1E0); a correct 34020-mode netlist never does.  The
# gate PASSES only on 8000/8000 AND an ILLOP-GUARD CLEAN.  Exit code = verdict.
set -uo pipefail
export PATH="/c/iverilog/bin:/c/Python314:/c/WINDOWS:/usr/local/bin:/usr/bin:/bin"
SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FIXTURE_ROOT="${2:-$ROOT}"
FIXTURE_ROOT="$(cd "$FIXTURE_ROOT" && pwd)"
B="$FIXTURE_ROOT/sim/build"
TB=tb_revx_top_boot
GUARD="$ROOT/sim/revx_illop_guard.sv"
PY=python; command -v python >/dev/null || PY=py
GOSPEL="$ROOT/mame-gospel/trace/revx_l20_main_pc.ref"
DASM="$ROOT/mame-gospel/dasm/revx_l20_prog.dasm"
# MSYS path->Windows conversion for native-tool ARGUMENTS (git-bash 2.44+ / MSYS2 runtime
# 3.5 no longer auto-converts args; python/iverilog/sv2v/vvp would see /d/... and fail).
W() { cygpath -w "$1"; }
fail() { echo "GATE FAILED ($1)"; exit 1; }

[ $# -ge 1 ] || { echo "usage: run_revx_converted_boot.sh <run_dir>"; exit 2; }
ARG="$1"
if   [ -d "$ARG" ];        then RUN_DIR="$(cd "$ARG" && pwd)"
elif [ -d "$ROOT/$ARG" ];  then RUN_DIR="$(cd "$ROOT/$ARG" && pwd)"
else echo "run_dir not found: $ARG"; exit 2; fi
CORE="$RUN_DIR/build_syn/revx_core.v"
[ -f "$CORE" ] || { echo "converted netlist not found: $CORE"; exit 2; }
[ -x "$SV2V" ] || { echo "sv2v not found at $SV2V"; exit 69; }
RUNID="$(basename "$RUN_DIR")"
EVIDENCE="$RUN_DIR/receipts/converted_boot"
mkdir -p "$EVIDENCE"
BENCH="$EVIDENCE/revx_conv_bench.v"
VVP="$EVIDENCE/converted_boot_${RUNID}.vvp"
LOG="$EVIDENCE/converted_boot_${RUNID}.log"
IVLOG="$EVIDENCE/converted_boot_${RUNID}.iv.log"

# The whole point: the converted file carries IS_34020 baked in; we pass no such define.
BAKED="$(grep -m1 -oE "tms34010_pkg_IS_34020 = 1'b[01]" "$CORE" | grep -oE "1'b[01]")"
echo "==== converted-netlist boot gate ===="
echo "run_dir   : $RUN_DIR"
echo "netlist   : $CORE"
echo "baked IS_34020 (from the converted file, NOT a runner define): ${BAKED:-<not found>}"

# ---- inputs (identical to run_revx_top_boot.sh) ----
[ -s "$B/revx_prog_rom.hex" ] && [ -s "$B/revx_main_pc_ref.hex" ] || fail "existing local fixtures missing"
sha256sum "$B/revx_prog_rom.hex" "$B/revx_main_pc_ref.hex" > "$EVIDENCE/fixtures.sha256" || fail "fixture identity"

# ---- down-convert ONLY the bench + sim models (NO TMS_IS_34020 define) ----
#  The core-under-test is the prepared converted netlist, used as-is.  sv2v leaves the bench's
#  revx_top instantiation as an external reference; iverilog links it to $CORE's revx_top.
n=0; ok=0
while [ $n -lt 3 ]; do
  if "$SV2V" -DREVX_BOOT_DUMP -DREVX_BLMOVE_BURST -DREVX_VRAM_LB "$(W "$ROOT/sim/sdram_model.sv")" "$(W "$ROOT/sim/ddr3_avalon_model.sv")" "$(W "$ROOT/sim/$TB.sv")" \
        > "$BENCH" 2>"$EVIDENCE/revx_conv_bench.sv2v.err" && [ -s "$BENCH" ] && [ ! -s "$EVIDENCE/revx_conv_bench.sv2v.err" ]; then ok=1; break; fi
  n=$((n+1))
done
[ $ok -eq 1 ] || { echo "SV2V-FAIL:"; head -12 "$EVIDENCE/revx_conv_bench.sv2v.err"; fail "sv2v bench"; }

# ---- compile: prepared converted core + down-converted bench + illop guard.  NO TMS define. ----
n=0; ok=0
while [ $n -lt 8 ]; do
  if iverilog -g2012 -s "$TB" -s revx_illop_guard -o "$(W "$VVP")" "$(W "$CORE")" "$(W "$BENCH")" "$(W "$GUARD")" 2>"$IVLOG"; then ok=1; break; fi
  n=$((n+1))
done
[ $ok -eq 1 ] || { echo "COMPILE-FAIL:"; grep -iE "error" "$IVLOG" | grep -vi "Code generator" | head; fail "compile"; }

( cd "$FIXTURE_ROOT" && vvp -n "$(W "$VVP")" ) 2>"$EVIDENCE/vvp.err" | grep -v "^\[ddr3_model\]" > "$LOG"
SIM_RC=${PIPESTATUS[0]}
[ "$SIM_RC" -eq 0 ] || fail "simulation process exit $SIM_RC"
sha256sum -c "$EVIDENCE/fixtures.sha256" > "$EVIDENCE/fixtures.after.log" || fail "fixtures changed during simulation"

echo "==== boot result ===="
grep -E "^CHECKS:|^BOOT:|^FRONTIER:|^FAIL:|^ILLOP-GUARD:|^TEST_RESULT:" "$LOG" || tail -8 "$LOG"

# dasm lookup for a PC divergence (artifact-vs-RTL classification aid)
EXP=$(grep -m1 "^DIVERGE_EXP=" "$LOG" | cut -d= -f2)
GOT=$(grep -m1 "^DIVERGE_GOT=" "$LOG" | cut -d= -f2)
if [ -n "${EXP:-}" ] && [ -f "$DASM" ]; then
  echo "---- dasm at expected PC $EXP ----"; grep -m2 -i "^${EXP}:" "$DASM" || echo "(not found in dasm)"
  echo "---- dasm at got PC $GOT ----";      grep -m2 -i "^${GOT}:" "$DASM" || echo "(not found in dasm)"
fi

# STRICT verdict: PASS only on a full 8000/8000 (the bench's TEST_RESULT) AND a CLEAN illop
# guard (the discriminating check the PC diff cannot provide).  Never weaken either half.
echo "evidence: $LOG"
if grep -q "^TEST_RESULT: PASS" "$LOG" && grep -q "^ILLOP-GUARD: CLEAN" "$LOG"; then
  echo "GATE PASSED: converted-netlist boot 8000/8000 + illegal-opcode latch clean (${BAKED:-?})"; exit 0
elif ! grep -q "^ILLOP-GUARD: CLEAN" "$LOG"; then
  echo "GATE FAILED: converted netlist latched an illegal opcode during boot -- 34010-mode core (TMS_IS_34020 not baked 1'b1)"; exit 1
else
  echo "GATE FAILED: converted-netlist boot did not reach 8000/8000 (see frontier above)"; exit 1
fi
