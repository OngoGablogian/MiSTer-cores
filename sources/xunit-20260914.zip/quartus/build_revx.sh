#!/usr/bin/env bash
# Prepare outside FIFO; physical work consumes one frozen attempt.
# quartus/build_revx.sh --prepare-only diag
# Launch physical work ONLY with quartus/enqueue_revx.sh.
set -Eeuo pipefail
export PATH="/c/Python314:/usr/local/bin:/usr/bin:/bin:${PATH:-}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PY=/c/Python314/python.exe
QBIN=/c/intelFPGA_lite/17.0/quartus/bin64
REV=Arcade-RevX
# MSYS2 runtime 3.5+ (git-bash 2.44+) no longer reliably converts /x/... args for native
# tools (and can mangle them as D:\x\...); the payload's python calls must pass Windows paths.
W() { cygpath -w "$1"; }
case "${1:-}" in
  --prepare-only) exec "$PY" "$(W "$ROOT/quartus/revx_build.py")" prepare "$(W "$ROOT")" "${2:-diag}" ;;
  --physical) ;;
  *) echo 'usage: build_revx.sh --prepare-only {diag|production}; use enqueue_revx.sh to build' >&2; exit 2;;
esac
[ "${REVX_SHARED_QUARTUS_FIFO:-0}" = 1 ] || { echo 'FAIL: physical entry requires project FIFO launcher' >&2; exit 2; }
cd "$ROOT"
# Bounded fail-closed check is the only work before the first Quartus worker.
"$PY" quartus/revx_build.py verify "$(W "$ROOT")"
# RESUME-ASM (2026-09-10): armed by revx_build.py resume-asm, the fit/sta/constraints
# artifacts exist and the source snapshot is frozen -- re-run ONLY the signoff gate
# (pipeline tooling refreshed by the resume) and quartus_asm on the existing fit db.
RESUME_ASM=0
[ ! -f receipts/resume.asm ] || RESUME_ASM=1
if [ "$RESUME_ASM" = 0 ]; then
  [ ! -e receipts/physical.started ] || { echo 'FAIL: attempt already started; prepare a new attempt' >&2; exit 2; }
fi
# Bind the same live owner/ready/command/launcher fields as the established
# Model 1 r65 runner. An environment flag alone is not an ownership receipt.
"$PY" quartus/revx_build.py bind-owner "$(W "$ROOT")"
date -u +%Y-%m-%dT%H:%M:%SZ > receipts/physical.started
STAGE=starting
finish() {
  local rc=$?
  trap - EXIT
  printf '%s\t%s\t%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$STAGE" "$rc" > receipts/physical.status
  exit "$rc"
}
trap finish EXIT
run_stage() {
  STAGE="$1"; shift
  local -a results
  echo "=== $STAGE ==="
  set +e
  "$@" 2>&1 | tee "logs/$STAGE.log"
  results=("${PIPESTATUS[@]}")
  set -e
  printf '%s\t%s\t%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$STAGE" "${results[0]}" >> receipts/stages.tsv
  [ "${results[0]}" -eq 0 ] || return "${results[0]}"
  [ "${results[1]}" -eq 0 ] || { echo 'FAIL: could not retain stage log' >&2; return 2; }
}
if [ "$RESUME_ASM" = 0 ]; then
  run_stage map "$QBIN/quartus_map.exe" --read_settings_files=on --write_settings_files=off "$REV" -c "$REV"
  run_stage fit "$QBIN/quartus_fit.exe" --read_settings_files=off --write_settings_files=off "$REV" -c "$REV"
  STAGE=topology
  "$PY" quartus/revx_physical_gate.py topology "$(W "$ROOT")"
  run_stage sta "$QBIN/quartus_sta.exe" "$REV" -c "$REV" --multicorner=on --do_report_timing
  run_stage constraints "$QBIN/quartus_sta.exe" -t quartus/revx_sta.tcl
fi
STAGE=signoff
# Cabinet-waiver policy travels INSIDE the hashed attempt snapshot (never via the launcher env):
# quartus/revx_waiver.env sets REVX_WAIVER=cabinet + REVX_WAIVER_NS for revx_physical_gate.py.
# Verdict WAIVER (setup-only small misses, fast corners clean, inherited chassis ports) permits
# assembly and is carried as its own label through collect/package. See the gate's header.
if [ -f quartus/revx_waiver.env ]; then set -a; . quartus/revx_waiver.env; set +a; echo "signoff policy: $(tr '
' ' ' < quartus/revx_waiver.env)"; fi
"$PY" quartus/revx_build.py verify "$(W "$ROOT")"
"$PY" quartus/revx_physical_gate.py signoff "$(W "$ROOT")"
run_stage asm "$QBIN/quartus_asm.exe" --read_settings_files=off --write_settings_files=off "$REV" -c "$REV"
STAGE=complete
# No hashing/copying/packaging here. Return for immediate FIFO release.
