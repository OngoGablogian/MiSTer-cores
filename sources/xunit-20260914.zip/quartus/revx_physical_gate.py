#!/usr/bin/env python3
"""Fail-closed RevX fitted RAM and full multicorner signoff report checks.

Consumes only reports in a newly prepared attempt. Missing/unknown report
formats fail; this gate has no timing waiver or platform-I/O allowlist.
"""
import json
import hashlib
from pathlib import Path
import re
import sys
from decimal import Decimal, InvalidOperation
from collections import Counter
from revx_ce_contract import (MANIFEST as CE_MANIFEST, REQUIRED_FAMILIES,
                              classify_member, validate as validate_ce)

REV = "Arcade-RevX"
CORNERS = [f"{speed} 1100mV {temperature}C Model" for speed in ("Slow", "Fast") for temperature in (100, -40)]
KINDS = ["Setup", "Hold", "Recovery", "Removal", "Minimum Pulse Width"]
# Quartus 17.0's complete check_timing summary, verified against the retained
# first RevX report. New, duplicate, missing, or malformed categories fail.
CHECK_TIMING = {
    "no_clock": ("No Clock", "clock association requires node-level review"),
    "multiple_clock": ("Multiple Clock", "multiple clock reachability requires mux/exclusivity proof"),
    "pos_neg_clock_domain": (None, "positive/negative clock domain relationship"),
    "generated_clock": (None, "generated clock validity"),
    "virtual_clock": ("Virtual Clock", "virtual clock presence advisory"),
    "no_input_delay": ("No Input Delay", "input interface delay/exception coverage requires review"),
    "no_output_delay": ("No Output Delay", "output interface delay/exception coverage requires review"),
    "partial_input_delay": (None, "complete min/max input delay coverage"),
    "partial_output_delay": (None, "complete min/max output delay coverage"),
    "io_min_max_delay_consistency": (None, "I/O min/max consistency"),
    "reference_pin": (None, "I/O reference pin validity"),
    "generated_io_delay": (None, "generated I/O delay validity"),
    "latency_override": (None, "clock latency overrides"),
    "partial_multicycle": (None, "complete multicycle pairing"),
    "multicycle_consistency": (None, "multicycle consistency"),
    "loops": (None, "combinational timing loops"),
    "latches": (None, "latch timing"),
    "pll_cross_check": (None, "PLL/SDC consistency"),
    "uncertainty": (None, "clock uncertainty coverage"),
    "partial_min_max_delay": (None, "complete min/max delay coverage"),
    "clock_assignments_on_output_ports": (None, "output clock assignment validity"),
    "input_delay_assigned_to_clock": (None, "input delay assigned to a clock"),
}

# Narrow diagnostic classifications from the immutable first RevX fit. These
# bound synthetic node kinds under exact primitive instances, not exemptions
# for any HPS or video register. Numeric ~FF identifiers may renumber after
# unrelated logic changes; source identity, group counts and kinds must match.
CHASSIS_SOURCE_PINS = {
    "sys/sys_top.v": "823bfd23c8a4aed5408589911dc82a24303312026ba0a61da6342138b9ad7f47",
    "sys/sysmem.sv": "247f4aaa270d45e0c8a44dc1361040a519836bd7d0493d708fe40a00443e4377",
    "sys/sys_top.sdc": "a4c07ce2340692f7e72ea7bf51823f0c90b5eb3c3d763aff2786cfa417af85c0",
}
HPS_NO_CLOCK = {
    "sysmem_lite:sysmem|sysmem_HPS_fpga_interfaces:fpga_interfaces|f2sdram":
        (620, "07ed227a386ba436fcd76a56a62ab31f65de1f7702c12616cddef4f5989ca4c4"),
    "sysmem_lite:sysmem|sysmem_HPS_fpga_interfaces:fpga_interfaces|clocks_resets":
        (619, "1ff89d5c979afc76b2ec002f9b3395b11a28b5c2fce45d50c7636e7a8fa37643"),
    "h2f_gp": (617, "2c378e8323bcc686450419f6727fd2258c2f2dcba92e7f7ddc02ca1bf60e5ab2"),
    "spi": (621, "a878f4925aab5321318a9d48741dadfb5991a4f924df47e7731438a609640234"),
    "hdmi_i2c": (617, "05190f4da93d47999fe04e380a0fea44696b54d0087b3edfde6ea23acc0d208c"),
}
VIDEO_MULTIPLE_CLOCK = (86, "40e3147190804b3b48123ce2890822be28dcb8acafc57ca3f45f6f53ec194ae0")
CORE_CLOCK = "emu|pll|pll_inst|altera_pll_i|general[0].gpll~PLL_OUTPUT_COUNTER|divclk"
HDMI_CLOCK = "pll_hdmi|pll_hdmi_inst|altera_pll_i|cyclonev_pll|counter[0].output_counter|divclk"


def read(path):
    if not path.is_file() or not path.stat().st_size:
        raise ValueError(f"missing/empty required report: {path}")
    return path.read_text(encoding="utf-8", errors="replace")


def tables(text):
    result = {}
    title = None
    for line in text.splitlines():
        if not line.startswith(";"):
            continue
        fields = [x.strip() for x in line.strip().strip(";").split(";")]
        if len(fields) == 1:
            title = fields[0]
            result.setdefault(title, [])
        elif title:
            result[title].append(fields)
    return result


def numeric(value):
    try:
        result = Decimal(value.replace(",", ""))
    except InvalidOperation:
        raise ValueError(f"invalid numeric report value: {value!r}")
    if not result.is_finite():
        raise ValueError(f"nonfinite report value: {value!r}")
    return result


def chassis_diagnostic_evidence(run, diagnostics, sta, ucp):
    """Prove bounded modeled artifacts, leaving every unknown node unresolved.

    HPS declarations: sys_top.v 281/1118/1605; sysmem.sv 330/405. Their ~FF
    aliases model hard-IP internals, not fabric flip-flops needing invented
    clocks. Both clkselect instances and all affected video registers are in
    sys_top.v 1249-1355. Require their source identity and measured bidirectional
    clock-group separation. This does not qualify HPS internals or waive UCPs.
    """
    source_hashes = {name: hashlib.sha256((run / name).read_bytes()).hexdigest()
                     for name in CHASSIS_SOURCE_PINS}
    sources_match = source_hashes == CHASSIS_SOURCE_PINS
    classified = {"no_clock": set(), "multiple_clock": set(),
                  "no_input_delay": set(), "no_output_delay": set()}
    proofs = {"source_hashes": source_hashes, "source_pins_match": sources_match,
              "hps_alias_groups": [], "video_clock_groups": False}
    no_clock = diagnostics.get("No Clock", [])[1:]
    if sources_match:
        for prefix, expected in HPS_NO_CLOCK.items():
            names = sorted(row[0] for row in no_clock if len(row) == 2
                           and row[1] == "No clock feeds this register's clock port."
                           and re.fullmatch(re.escape(prefix) + r"~FF_[0-9]+", row[0]))
            digest = hashlib.sha256("\n".join(names).encode()).hexdigest()
            # IDs are generated names, so record their complete set/hash but
            # match the pinned primitive's synthetic-node kind and population.
            matches = len(names) == expected[0]
            proofs["hps_alias_groups"].append({"instance": prefix, "count": len(names),
                                               "sha256": digest, "primitive_population_match": matches,
                                               "first_fit_node_sha256": expected[1]})
            if matches:
                classified["no_clock"].update(names)
        separated = all(any(len(row) == 6 and row[:2] == [source, target]
                            and row[2:] == ["false path", "0", "0", "0"]
                            for row in sta.get(f"{kind} Transfers", [])[1:])
                        for kind in ("Setup", "Hold")
                        for source, target in ((CORE_CLOCK, HDMI_CLOCK), (HDMI_CLOCK, CORE_CLOCK)))
        names = sorted(row[0] for row in diagnostics.get("Multiple Clock", [])[1:]
                       if len(row) == 2 and row[1] == "More than one clock feeds this register's clock port.")
        digest = hashlib.sha256("\n".join(names).encode()).hexdigest()
        proofs["video_clock_groups"] = separated
        proofs["video_node_sha256"] = digest
        if separated and (len(names), digest) == VIDEO_MULTIPLE_CLOCK:
            classified["multiple_clock"].update(names)
    # Missing-delay diagnostics are broader than unconstrained paths. A port
    # with no UCP path is classified only against complete fitted UCP tables;
    # the remaining ports and every nonzero UCP summary are still blockers.
    summary = ucp.get("Unconstrained Paths Summary", [])
    for direction, category, title in (("Input", "no_input_delay", "No Input Delay"),
                                       ("Output", "no_output_delay", "No Output Delay")):
        rows = ucp.get(f"Unconstrained {direction} Ports", [])
        ports = {row[0] for row in rows if len(row) == 2 and row[0] != f"{direction} Port"}
        counts = [row for row in summary if row[0] == f"Unconstrained {direction} Ports"]
        complete = len(counts) == 1 and counts[0][1:] == [str(len(ports)), str(len(ports))]
        proofs[f"unresolved_{direction.lower()}_ports"] = sorted(ports)
        if complete:
            classified[category] = {row[0] for row in diagnostics.get(title, [])[1:]
                                    if len(row) == 2 and row[0] not in ports}
    return classified, proofs


def classify_check_timing(text, classified=None):
    """Classify diagnostics without treating known platform names as waivers.

    check_timing's missing-delay lists include ports that may have explicit
    false paths; those lists are not equivalent to the UCP report. Nonzero
    counts still require explicit node-level disposition. Exact source and
    fitted-evidence classifications are supplied separately; unknown nodes
    fail. No virtual clock is required merely for using a real SDRAM clock.
    """
    errors, classification = [], []
    classified = classified or {}
    report = tables(text)
    summary = report.get("Summary", [])
    if not summary or summary[0] != ["Check", "Number of Issues Found"]:
        return ["missing/unrecognized check_timing summary"], []
    seen = set()
    for row in summary[1:]:
        if len(row) != 2 or not re.fullmatch(r"[0-9]+", row[1]):
            errors.append(f"malformed check_timing row: {row}")
            continue
        name, count = row[0], int(row[1])
        if name in seen:
            errors.append(f"duplicate check_timing category: {name}")
        seen.add(name)
        if name not in CHECK_TIMING:
            errors.append(f"unclassified check_timing category: {name} count={count}")
            classification.append({"check": name, "count": count, "disposition": "unclassified"})
            continue
        title, meaning = CHECK_TIMING[name]
        details = report.get(title, [])[1:] if title else []
        disposition = "clear" if count == 0 else "unresolved"
        resolved = [row for row in details if row and row[0] in classified.get(name, set())]
        unresolved = [row for row in details if not row or row[0] not in classified.get(name, set())]
        if count and name == "virtual_clock" and count == 1 and details == [["", "No virtual clock was found."]]:
            disposition = "advisory-no-virtual-clock"
        elif count and len(resolved) == count:
            disposition = {"no_clock": "modeled-hard-hps-aliases",
                           "multiple_clock": "exclusive-chassis-video-clock-mux",
                           "no_input_delay": "no-unconstrained-input-paths",
                           "no_output_delay": "no-unconstrained-output-paths"}.get(name, "unresolved")
        elif count:
            errors.append(f"unresolved check_timing diagnostic: {name} count={count-len(resolved)} of {count}; {meaning}")
        if count and title and len(details) != count:
            errors.append(f"check_timing detail coverage mismatch: {name} summary={count} detail={len(details)}")
        groups = Counter(item[0].split("|")[0].split("~")[0] for item in details if item)
        classification.append({"check": name, "count": count, "meaning": meaning,
                               "disposition": disposition, "detail_table": title,
                               "node_groups": dict(groups), "resolved_count": len(resolved),
                               "resolved_nodes": resolved, "unresolved_nodes": unresolved})
    missing = sorted(set(CHECK_TIMING) - seen)
    if missing:
        errors.append(f"check_timing summary omits required categories: {missing}")
    return errors, classification


def stage_ok(run, name):
    lines = read(run / "receipts/stages.tsv").splitlines()
    rows = [line.split("\t") for line in lines if len(line.split("\t")) == 3 and line.split("\t")[1] == name]
    if len(rows) != 1 or rows[0][2] != "0":
        raise ValueError(f"missing/nonunique/failed stage receipt: {name}")
    log = read(run / f"logs/{name}.log")
    if re.search(r"^\s*Error(?:\s*\(|\s*:)", log, re.M):
        raise ValueError(f"error in successful-looking {name} log")
    return log


def topology(run):
    errors = []
    maplog = stage_ok(run, "map")
    stage_ok(run, "fit")

    # ---- audio-disconnected check (Model 1 r88 lesson, 2026-09-08) -------------------
    # A build can be proven SILENT at compile time: if the core's audio inputs to the
    # MiSTer chassis (audio_out|cl[*]/cr[*]) appear in the map report's "Registers Removed
    # During Synthesis" table as "Stuck at GND due to stuck port data_in", the emu is
    # feeding audio_out a constant and no cabinet session can produce sound.  Model 1 r88
    # burned a cabinet session proving this with a square wave when the fit report had
    # already said it: an inherited diagnostic macro (M1_DIAG14) had tied audio_out's
    # inputs to ground and repurposed the audio wires as a diagnostic transport.
    # DISCRIMINATOR, measured 2026-09-08 across three trees: the DC_blocker registers are
    # stuck at GND in EVERY build including Smash TV, which demonstrably makes sound on the
    # cabinet (24 stuck there, 8 here) -- that is the unused filter path and is NOT a
    # defect.  Only cl/cr matter: Smash TV 0, RevX 0, UMK3 16 (that build cannot sound).
    mapr = read(run / f"output_files/{REV}/{REV}.map.rpt")
    silent = re.findall(r"^;\s*(audio_out:audio_out\|c[lr]\[[^;]*?)\s*;\s*Stuck at (?:GND|VCC)",
                        mapr, re.M)
    if silent:
        errors.append("audio path is dead at compile time: the chassis' core audio inputs are "
                      f"stuck ({len(silent)} entries, e.g. {silent[0].strip()}) -- the emu drives "
                      "audio_out a constant, so the build cannot make a sound. Check for an "
                      "inherited/undefined diagnostic macro repurposing the audio wires.")

    fit = read(run / f"output_files/{REV}/{REV}.fit.rpt")
    data = tables(fit)
    rows = data.get("Fitter RAM Summary", [])
    if not rows:
        raise ValueError("missing Fitter RAM Summary")
    header, *body = rows
    columns = ["Name", "Mode", "Port A Input Registers", "Port B Input Registers", "Implementation Bits", "M10K blocks", "MLAB cells"]
    if any(c not in header for c in columns):
        raise ValueError(f"unknown Fitter RAM Summary columns: {header}")
    memories = [dict(zip(header, row)) for row in body if len(row) == len(header)]
    results = {}
    for label, pattern, bits in (("palette", r"\|[^|]*:u_pal\|", 524288),
                                 ("cmos", r"\|[^|]*:u_cmos\|", 65536)):
        matched = [row for row in memories if re.search(pattern, row["Name"])]
        results[label] = [{key: row[key] for key in columns} for row in matched]
        if not matched:
            errors.append(f"missing fitted {label} RAM instance")
            continue
        total = sum(numeric(row["Implementation Bits"]) for row in matched)
        if total < bits:
            errors.append(f"{label} fitted bits {total} < {bits}")
        for row in matched:
            if "Dual Port" not in row["Mode"]:
                errors.append(f"{label} is not dual port: {row['Mode']}")
            if numeric(row["M10K blocks"]) <= 0 or numeric(row["MLAB cells"]) != 0:
                errors.append(f"{label} is not exclusively M10K")
            # Inference can absorb output flops into registered input/address
            # ports. Require clocked RAM accesses without overconstraining its
            # optional second output register stage.
            if any(row[c].lower() != "yes" for c in ("Port A Input Registers", "Port B Input Registers")):
                errors.append(f"{label} lacks clocked access on both RAM ports")
    uninferred = [line.strip() for line in maplog.splitlines() if "(276007)" in line]
    # Any uninferred array is explicitly retained for topology review. Do not
    # hide a second register-explosion behind the two repaired memories.
    errors.extend(uninferred)
    return {"result": "FAIL" if errors else "PASS", "errors": errors, "memories": results,
            "uninferred_arrays": uninferred}



# ---- Cabinet waiver layer (director, 2026-09-07) ---------------------------------------
# USER RULE (memory: cold-corner-is-testable, 2026-08-27 / 2026-09-06): a corner-only STA
# miss of a few hundred ps is valid to take a READING on the cabinet -- assemble anyway and
# ship it as a WAIVER build, listing the missed rows. This layer never turns a FAIL into a
# PASS: the verdict becomes the distinct "WAIVER" and every waived row is recorded. Enabled
# only by REVX_WAIVER=cabinet; REVX_WAIVER_NS (default 1.0) bounds each waived setup miss.
# Waivable: (a) setup/hold summary rows with |slack| <= REVX_WAIVER_NS provided NO Fast-corner
# row fails; (b) the design-wide-TNS row when every failing row was waived; (c) the inherited
# chassis unconstrained INPUT/OUTPUT PORT rows (Wolf/T/Y ship with them; recorded, not fixed);
# (d) warning 332174 (custom-aspect banks) and "Timing requirements not met". Everything
# else -- topology, CE contract, membership, missing/malformed reports -- stays fatal.
WAIVABLE_UCP = ("Unconstrained Input Ports", "Unconstrained Input Port Paths",
                "Unconstrained Output Ports", "Unconstrained Output Port Paths")

def apply_waiver(errors, checks):
    import os
    if os.environ.get("REVX_WAIVER", "") != "cabinet":
        return "FAIL" if errors else "PASS", errors, []
    limit = float(os.environ.get("REVX_WAIVER_NS", "1.0") or "1.0")
    fast_fail = any(c["corner"].startswith("Fast") and numeric(c["slack"]) <= 0 for c in checks)
    waived, fatal, timing_rows = [], [], []
    for e in errors:
        m = re.match(r"^(Slow|Fast) .* Model Setup Summary: (\S+) slack=(\S+) TNS=(\S+)$", e)  # SETUP only: hold/recovery/removal/mpw misses are never waivable
        if m:
            timing_rows.append(e)
            if numeric(m.group(3)) >= -limit and not fast_fail:
                waived.append(e)
            else:
                fatal.append(e)
            continue
        if e.startswith("missing/malformed/nonzero design-wide TNS"):
            (waived if not any(r in fatal for r in timing_rows) else fatal).append(e); continue
        if e.startswith("unresolved unconstrained-path row:") and any(k in e for k in WAIVABLE_UCP):
            waived.append(e); continue
        if re.search(r"no-unconstrained-(input|output)-paths|Unconstrained (Input|Output) Port"
                     r"|unresolved check_timing diagnostic: no_(input|output)_delay", e):
            waived.append(e); continue
        if "332174" in e or "Timing requirements not met" in e:
            waived.append(e); continue
        fatal.append(e)
    # the TNS row is only waivable if no timing row stayed fatal (ordering-independent recheck)
    if any(r in fatal for r in timing_rows):
        fatal += [e for e in waived if e.startswith("missing/malformed/nonzero design-wide TNS")]
        waived = [e for e in waived if not e.startswith("missing/malformed/nonzero design-wide TNS")]
    if fatal:
        return "FAIL", fatal, waived
    return ("WAIVER" if waived else "PASS"), [], waived

# New pin-contract evidence supplements, and never replaces, existing full
# timing/UCP/CPU checks. No alias clock or external-path waiver is introduced.
PIN_SDC_SHA256 = '44bde33e9f839dd50f2e76b448f8ac64b44d3cdb42e1172b202998d5f70b809a'
PIN_STA_SHA256 = '270fd5e25892c45bfa076b11c12accb421f760639e4ea224c2774fa74ab7201d'
PIN_PROTOCOL_SOURCES = {'sys/i2c.v': '09bd7ebd5d84fb57f6a9d569e5214f3154c49e55826c15bd78884f3c781fec5b', 'sys/mcp23009.sv': 'c4b0192014980bb3559727defd3d84cd1eeb0cdbfb98eef68e0f929c32528271', 'sys/i2s.v': '650c796742f69b2dd152c6871064c31be1e33a8aca046668b01a7a79712d689f', 'sys/audio_out.v': 'fdeb1216bb1db0f42c0441e991e2d27c33e3b56041735476d81fe9080a6a8330', 'sys/pll_audio/pll_audio_0002.v': '2b24d2a561d81cc8b20f725884ee9c243e619058e42ebcdcf6f491d33008696c'}
PIN_COLLECTIONS = {
    'core_clock': 1, 'hdmi_clock': 1, 'audio_clock': 1,
    'core_pin': 1, 'hdmi_pin': 1, 'audio_pin': 1,
    'hdmi_tx_clock': 1, 'hdmi_direct_group': 2, 'hdmi_scaler_group': 2,
    'hdmi_video': 27, 'hdmi_audio_master': 1, 'i2s_outputs': 6,
    'spdif_output': 1, 'expander_clock': 1, 'expander_outputs': 2,
    'expander_input': 1, 'expander_receivers': 6, 'hps_i2c_scl': 1,
    'hps_i2c_sda_out': 1, 'hps_i2c_sda_in': 1, 'hps_i2c_scl_in': 1,
    'hdmi_i2c_scl_port': 1, 'hdmi_i2c_sda_port': 1,
    'analog_connector': 7, 'status_leds': 3, 'hps_sda_output_proxy': 1,
    'card_detect_input': 1, 'card_detect_mux_outputs': 6,
}
PIN_PROXY = 'hdmi_i2c~FF_4791'
PIN_ENDPOINT = 'HDMI_I2C_SDA'


def strict_pin_evidence(run, rows, chassis, diagnostic_text):
    errors = []
    evidence = {'scope': 'FPGA pin transport against stated receiver/board budgets; not cabinet electrical measurement',
                'sda_proxy': PIN_PROXY, 'sda_endpoint': PIN_ENDPOINT,
                'sda_transport_ns': {'minimum': 0, 'maximum': 20},
                'external_obligations': ['installed ADV7513 clock-delay configuration',
                                         'board skew and open-drain rise/load budgets',
                                         'HPS I2C firmware/controller timing',
                                         'USER_IO receiver compatibility and analog waveform quality']}
    source_expected = {'quartus/revx_chassis.sdc': PIN_SDC_SHA256,
                       'quartus/revx_sta.tcl': PIN_STA_SHA256, **PIN_PROTOCOL_SOURCES}
    source_actual = {p: hashlib.sha256((run/p).read_bytes()).hexdigest() for p in source_expected}
    evidence['source_hashes'] = source_actual
    if source_actual != source_expected:
        errors.append('strict pin source/constraint identity changed')
    if not chassis.get('source_pins_match'):
        errors.append('strict pin chassis primitive source identity changed')
    # This core must not use the shared pins for secondary-SD traffic. Pin the
    # exact reviewed release assignment and all four identifiers' executable
    # uses, permitting unrelated DMA/diagnostic edits in the wrapper.
    wrapper = re.sub(r'/\*[\s\S]*?\*/|//[^\n]*', '', read(run/'Arcade-RevX.sv'))
    sd_releases = re.findall(r"(?m)^\s*assign\s*\{\s*SD_SCK\s*,\s*SD_MOSI\s*,\s*SD_CS\s*\}\s*=\s*'Z\s*;", wrapper)
    sd_uses = {name:len(re.findall(r'\b'+name+r'\b', wrapper))
               for name in ('SD_SCK','SD_MOSI','SD_CS','SD_MISO')}
    evidence['core_secondary_sd_scope'] = {'released_assignment_count':len(sd_releases), 'identifier_counts':sd_uses,
                                          'card_detect_input':'SDCD_SPDIF',
                                          'excepted_destinations':['SDIO_CLK','SDIO_CMD','SDIO_DAT[0]','SDIO_DAT[1]','SDIO_DAT[2]','SDIO_DAT[3]']}
    if len(sd_releases) != 1 or sd_uses != {'SD_SCK':2,'SD_MOSI':2,'SD_CS':2,'SD_MISO':1}:
        errors.append('strict pin secondary-SD inactive-source contract changed')
    aliases = [r[0] for r in tables(diagnostic_text).get('No Clock', [])[1:]
               if len(r) == 2 and r[1] == "No clock feeds this register's clock port."
               and re.fullmatch(r'hdmi_i2c~FF_[0-9]+', r[0])]
    evidence['hps_i2c_alias_count'] = len(aliases)
    evidence['hps_i2c_alias_sha256'] = hashlib.sha256('\n'.join(sorted(aliases)).encode()).hexdigest()
    if len(aliases) != 617 or len(set(aliases)) != 617 or PIN_PROXY not in aliases:
        errors.append('strict pin hard-HPS proxy population/identity changed')
    groups = [g for g in chassis.get('hps_alias_groups', []) if g.get('instance') == 'hdmi_i2c']
    if (len(groups) != 1 or groups[0].get('count') != 617
            or not groups[0].get('primitive_population_match')):
        errors.append('strict pin hard-HPS diagnostic classification missing')
    map_text = read(run/f'output_files/{REV}/{REV}.map.rpt')
    primitives = re.findall(r'^;\s*arriav_hps_interface_peripheral_i2c\s*;\s*([0-9]+)\s*;', map_text, re.M)
    evidence['mapped_i2c_primitive_counts'] = primitives
    if primitives != ['1']:
        errors.append('strict pin expected exactly one mapped hard I2C primitive')
    collections = [r for r in rows if r[0] == 'pin_collection']
    wanted_collections = {('pin_collection', label, str(count)) for label, count in PIN_COLLECTIONS.items()}
    if len(collections) != len(wanted_collections) or {tuple(r) for r in collections} != wanted_collections:
        errors.append('strict pin collection coverage/count mismatch')
    evidence['collections'] = collections
    # The clockless hard-HPS primitive has physical paths but no setup/hold
    # timing objects in Quartus 17. Enforce its original 0..20 ns allocation
    # on actual max/min routes at every corner; never fabricate STA slack.
    evidence['sda_measurement'] = 'clockless get_path/report_path physical transport; margin is not STA slack'
    expected = {(corner, kind) for corner in CORNERS for kind in ('max', 'min')}
    report_rows = [r for r in rows if r[0] == 'pin_transport_report']
    pair_rows = [r for r in rows if r[0] == 'pin_transport_coverage']
    path_rows = [r for r in rows if r[0] == 'pin_transport']
    source_rows = [r for r in rows if r[0] == 'pin_transport_source']
    if any(r[0] in ('pin_path_report', 'pin_pair_coverage', 'pin_path') for r in rows):
        errors.append('strict pin obsolete setup/hold SDA receipt substituted for physical transport')
    seen = set()
    for report in report_rows:
        key = tuple(report[1:3])
        if len(report) != 5 or key not in expected or key in seen or report[3] != '1':
            errors.append('strict pin malformed/duplicate/missing SDA transport report group')
            continue
        seen.add(key)
        corner, kind = key
        group = [r for r in path_rows if r[1:3] == list(key)]
        coverage = [r for r in pair_rows if r[1:3] == list(key)]
        if coverage != [['pin_transport_coverage', corner, kind, '1', '1']]:
            errors.append(f'strict pin SDA physical fan-in coverage mismatch: {key}')
        sources = [r for r in source_rows if r[1:3] == list(key)]
        if sources != [['pin_transport_source', corner, kind, PIN_PROXY, 'hdmi_i2c',
                        'cyclonev_hps_interface_peripheral_i2c', '0', '1']]:
            errors.append(f'strict pin SDA hard-HPS source/route identity mismatch: {key}')
        if len(group) != 1:
            errors.append(f'strict pin SDA physical path count mismatch: {key}')
        for path in group:
            if len(path) != 10 or path[3:5] != [PIN_PROXY, PIN_ENDPOINT]:
                errors.append(f'strict pin unexpected SDA physical start/end: {key}')
                continue
            try:
                delay, data, minimum, maximum, margin = [numeric(x) for x in path[5:10]]
                equation = maximum-delay if kind == 'max' else delay-minimum
                if (minimum != Decimal('0') or maximum != Decimal('20')
                        or delay < minimum or delay > maximum or data < 0 or margin < 0
                        or abs(delay-data) > Decimal('.002')
                        or abs(equation-margin) > Decimal('.002')):
                    errors.append(f'strict pin wrong/failing SDA physical transport bounds: {key}')
            except ValueError:
                errors.append(f'strict pin malformed SDA physical numeric field: {key}')
        report_path = (run/report[4]).resolve()
        if not report_path.is_relative_to((run/'reports').resolve()):
            errors.append('strict pin report path escapes report directory')
            continue
        report_text = read(report_path)
        summary_tables = tables(report_text)
        path_summary = dict(summary_tables.get('Path Summary', [])[1:])
        if (set(path_summary) != {'From Node', 'To Node', 'Delay'}
                or path_summary.get('From Node') != PIN_PROXY
                or path_summary.get('To Node') != PIN_ENDPOINT):
            errors.append(f'strict pin actual physical report has wrong endpoint/format: {key}')
        if not re.search(r'Delay Model:\s*\n\s*' + re.escape(corner) + r'\s*\n', report_text):
            errors.append(f'strict pin actual physical report has wrong/missing corner: {key}')
        has_min_option = bool(re.search(r'(?m)^\s*-min_path\s*$', report_text))
        if has_min_option != (kind == 'min'):
            errors.append(f'strict pin actual physical report has wrong max/min selection: {key}')
        if not re.search(r';\s*hdmi_i2c\|out_data\s*;', report_text):
            errors.append(f'strict pin actual physical route misses hard out_data pin: {key}')
        try:
            reported_delay = numeric(path_summary['Delay'])
            summary = summary_tables.get('Summary of Paths', [])
            if (len(summary) != 2 or summary[0] != ['Delay', 'From Node', 'To Node']
                    or len(summary[1]) != 3 or summary[1][1:] != [PIN_PROXY, PIN_ENDPOINT]
                    or abs(numeric(summary[1][0])-reported_delay) > Decimal('.002')):
                errors.append(f'strict pin actual physical pair count/summary mismatch: {key}')
            report_kind = 'Longest' if kind == 'max' else 'Shortest'
            headline = re.search(r'Report Path: Found 1 paths\. ' + report_kind + r' delay is ([0-9.+-]+)', report_text)
            if not headline or abs(numeric(headline[1])-reported_delay) > Decimal('.002'):
                errors.append(f'strict pin actual physical report direction/delay mismatch: {key}')
            if reported_delay < 0 or reported_delay > 20:
                errors.append(f'strict pin actual physical report violates transport budget: {key}')
            if not any(len(p) == 10 and p[3:5] == [PIN_PROXY, PIN_ENDPOINT]
                       and abs(numeric(p[5])-reported_delay) <= Decimal('.002') for p in group):
                errors.append(f'strict pin physical report/receipt disagreement: {key}')
        except (KeyError, ValueError):
            errors.append(f'strict pin actual physical report missing/malformed fields: {key}')
    if seen != expected:
        errors.append('strict pin missing corner/max/min SDA physical path coverage')
    for tag, records, width in (('coverage', pair_rows, 5), ('source', source_rows, 8), ('path', path_rows, 10)):
        if (len(records) != len(expected)
                or any(len(r) != width or tuple(r[1:3]) not in expected for r in records)
                or {tuple(r[1:3]) for r in records} != expected):
            errors.append(f'strict pin malformed/duplicate/missing SDA physical {tag} groups')
    evidence['transport_reports'] = report_rows
    evidence['transport_rows'] = path_rows
    evidence['physical_pair_coverage'] = pair_rows
    evidence['physical_source_coverage'] = source_rows
    evidence['result'] = 'FAIL' if errors else 'PASS'
    return errors, evidence


def signoff(run):
    errors = []
    ce_source = validate_ce(run)
    if json.loads(read(run / "receipts/cpu_ce_source.json")) != ce_source:
        errors.append("CPU CE source contract receipt mismatch")
    topo = json.loads(read(run / "receipts/topology.json"))
    if topo.get("result") != "PASS":
        errors.append("RAM topology gate did not pass")
    logs = "\n".join(stage_ok(run, stage) for stage in ("map", "fit", "sta", "constraints"))
    sta = read(run / f"output_files/{REV}/{REV}.sta.rpt")
    table = tables(sta)
    checks = []
    clocks_by_kind = {}
    for corner in CORNERS:
        for kind in KINDS:
            title = f"{corner} {kind} Summary"
            rows = table.get(title, [])
            if not rows or rows[0] != ["Clock", "Slack", "End Point TNS"] or len(rows) < 2:
                errors.append(f"missing/empty/unrecognized {title}")
                continue
            for row in rows[1:]:
                if len(row) != 3:
                    errors.append(f"malformed timing row in {title}: {row}")
                    continue
                clock, slack, tns = row
                if numeric(slack) <= 0 or numeric(tns) != 0:
                    errors.append(f"{title}: {clock} slack={slack} TNS={tns}")
                checks.append({"corner": corner, "kind": kind, "clock": clock, "slack": slack, "tns": tns})
            current_clocks = {row[0] for row in rows[1:] if len(row) == 3}
            if kind in clocks_by_kind and current_clocks != clocks_by_kind[kind]:
                errors.append(f"clock coverage changed across corners for {kind}: {corner}")
            clocks_by_kind[kind] = current_clocks
    multi = table.get("Multicorner Timing Analysis Summary", [])
    design_tns = [row for row in multi if row[0] == "Design-wide TNS"]
    if len(design_tns) != 1 or len(design_tns[0]) != 6 or any(numeric(x) != 0 for x in design_tns[0][1:]):
        errors.append("missing/malformed/nonzero design-wide TNS across all five checks")
    ucp = table.get("Unconstrained Paths Summary", [])
    if not ucp or ucp[0] != ["Property", "Setup", "Hold"] or len(ucp) < 7:
        errors.append("missing/unrecognized unconstrained-path summary")
    else:
        expected_properties = {"Illegal Clocks", "Unconstrained Clocks", "Unconstrained Input Ports",
                               "Unconstrained Input Port Paths", "Unconstrained Output Ports", "Unconstrained Output Port Paths"}
        if {row[0] for row in ucp[1:]} != expected_properties:
            errors.append("incomplete/unrecognized unconstrained-path property coverage")
        for row in ucp[1:]:
            if len(row) != 3 or any(numeric(x) != 0 for x in row[1:]):
                errors.append(f"unresolved unconstrained-path row: {row}")
    clocks = table.get("Clock Status Summary", [])
    if not clocks or len(clocks) < 2:
        errors.append("missing clock-status report")
    elif any(row[-1] != "Constrained" for row in clocks[1:]):
        errors.append("illegal/unconstrained fitted clock")
    constraint_receipt = read(run / "receipts/constraints.tsv")
    if not constraint_receipt.endswith("result\tPASS\n") or "result\tFAIL" in constraint_receipt:
        errors.append("fitted constraint/CPU contract audit did not pass")
    receipt_rows = [line.split("\t") for line in constraint_receipt.splitlines()]
    ce_members = [row for row in receipt_rows if row[0] == "ce_member"]
    ce_names = [row[4] for row in ce_members if len(row) == 5 and row[1] == "ce"]
    full_names = [row[4] for row in ce_members if len(row) == 5 and row[1] == "full"]
    if (not ce_names or not full_names or len(ce_members) != len(ce_names) + len(full_names)
            or len(set(ce_names + full_names)) != len(ce_members)):
        errors.append("missing/malformed/overlapping CPU CE fitted membership")
    contract = json.loads(read(run / CE_MANIFEST))
    for member in ce_members:
        try:
            if len(member) != 5 or member[1:4] != classify_member(contract, member[4]):
                raise ValueError(f"CPU CE membership disagrees with positive source inventory: {member}")
        except ValueError as exc:
            errors.append(str(exc))
    for label, expected in (("cpu", len(ce_members)), ("cpu_ce", len(ce_names)),
                            ("cpu_full_rate", len(full_names))):
        recorded = [row for row in receipt_rows if row[:2] == ["collection", label]]
        if recorded != [["collection", label, str(expected)]] or expected == 0:
            errors.append(f"incomplete fitted membership against {label} collection: {recorded}")
    ce_set, full_set = set(ce_names), set(full_names)
    ce_families = [row for row in receipt_rows if row[0] == "ce_family"]
    if (len(ce_families) != len(ce_source["families"])
            or {row[1] for row in ce_families if len(row) == 3} != set(ce_source["families"])):
        errors.append("incomplete CPU CE fitted family coverage")
    for row in ce_families:
        if len(row) != 3 or not row[2].isdigit() or int(row[2]) != sum(
                len(member) == 5 and member[1:3] == ["ce", row[1]] for member in ce_members):
            errors.append(f"CPU CE family count mismatch: {row}")
    for family in REQUIRED_FAMILIES:
        if not any(len(member) == 5 and member[1:3] == ["ce", family] for member in ce_members):
            errors.append(f"required CPU CE architectural family absent: {family}")
    ce_cycles = int(contract.get("cycles", 2))
    directions = {"ce_to_ce": ce_cycles, "ce_to_launch": ce_cycles, "launch_to_ce": ce_cycles,
                  "ce_to_full": 1, "full_to_ce": 1, "cpu_full_to_full": 1}
    ce_audits = [row for row in receipt_rows if row[0] == "ce_audit"]
    expected_audits = {(corner, direction) for corner in CORNERS for direction in directions}
    observed_audits = set()
    for row in ce_audits:
        key = tuple(row[1:3])
        if (len(row) != 7 or key not in expected_audits or key in observed_audits
                or not row[3].isdigit() or int(row[3]) < 1
                or row[4:] != ["1", str(directions.get(row[2])), "0"]):
            errors.append(f"failed/malformed CPU CE directed audit: {row}")
            continue
        observed_audits.add(key)
        checked = [path for path in receipt_rows if path[0] == "ce_path" and path[1:3] == list(key)]
        if len(checked) != int(row[3]):
            errors.append(f"CPU CE directed path coverage mismatch: {key}")
        for path in checked:
            if len(path) != 8 or path[3:5] != row[4:6]:
                errors.append(f"wrong CPU CE directed path relationship: {path}")
                continue
            source, target = path[6:8]
            # Physical synthesis appends its own tokens to a register it duplicates or
            # retimes (~DUPLICATE(_n), _OTERM<n>, _ITERM<n>, _NEW_REG<n>, and chains of
            # them). Such a copy IS its origin register for scope purposes -- the fitter
            # cloned it to drive a far load, it is not a different endpoint. Strip those
            # tokens before the allow-list match, exactly as the collector does
            # (quartus/revx_ce_contract.py classify_member; commits 448e140, c60a768).
            # Attempt 541ffa2c raised 888 of these on u_mif|p_rmw_OTERM1_OTERM697 and its
            # siblings: retiming is disabled inside u_cpu but not inside u_mif.
            # Unknown suffixes still fail closed -- only these tool tokens are removed.
            def _strip_ps_alias(name):
                prev = None
                while prev != name:
                    prev = name
                    name = re.sub(r"(?:~DUPLICATE(?:_[0-9]+)?|_OTERM[0-9]+|_ITERM[0-9]+|_NEW_REG[0-9]+)$",
                                  "", name, flags=re.I)
                return name
            source, target = _strip_ps_alias(source), _strip_ps_alias(target)
            # Fail-closed allow-list of the exact CE launch-destination stems that
            # $revx_launch_regs pins in revx.sdc: u_mif command launch (a_q/sz_q/
            # we_q/srt_q/wd_q) and the per-beat bus fields precomputed at the same
            # launch edge (p_addr0/1, p_be0/1, p_wsh0/1, p_nmask0/1, p_rmw,
            # p_straddle), the I/O write-command boundary one-shots, the I/O
            # read-request valid, and the '020 SETCDP CONVDP side-write boundary.
            # Any other target of a ce_to_launch path row is rejected.
            launch_stem = (
                re.search(r"tms34010_mem_if:u_mif\|(?:a_q|sz_q|we_q|srt_q|f_q|p_addr0|p_addr1|p_be0|p_be1|p_wsh0|p_wsh1|p_nmask0|p_nmask1|p_rmw|p_straddle)(?:\[\d+\])?$", target)
                or re.search(r"tms34010_io_write_boundary:u_io_write_boundary\|(?:wr_valid|wr_status_guard)$", target)
                or re.search(r"tms34010_core:u_cpu\|(?:io_rdata_req_valid_q|setcdp_we_q|setcdp_convdp_q(?:\[\d+\])?)$", target))
            # The only permitted CE launch SOURCE back into the CE core is the io-read
            # request-valid register ($revx_launch_io_read).
            launch_src_io_read = bool(re.search(r"tms34010_core:u_cpu\|io_rdata_req_valid_q$", source))
            membership_ok = {
                "ce_to_ce": source in ce_set and target in ce_set,
                "ce_to_launch": source in ce_set and target not in ce_set and bool(launch_stem),
                "launch_to_ce": launch_src_io_read and source not in ce_set and target in ce_set,
                "ce_to_full": source in ce_set and target not in ce_set,
                "full_to_ce": source not in ce_set and target in ce_set,
                "cpu_full_to_full": source in full_set and target in full_set,
            }[row[2]]
            if not membership_ok:
                errors.append(f"CPU CE directed path endpoint scope mismatch: {path}")
            numeric(path[5])
    if observed_audits != expected_audits:
        errors.append(f"missing CPU CE directed corner audits: {sorted(expected_audits-observed_audits)}")
    if any(len(row) != 8 or tuple(row[1:3]) not in expected_audits
           for row in receipt_rows if row[0] == "ce_path"):
        errors.append("unexpected/malformed CPU CE directed path row")
    absent = [row for row in receipt_rows if row[0] == "absent"]
    if len(absent) != 4 or {tuple(row) for row in absent} != {
            ("absent", bank, "0") for bank in ("arc1x", "arc1y", "arc2x", "arc2y")}:
        errors.append("custom-aspect bank absence audit missing/failed")
    aspect_banks = [row for row in receipt_rows if row[0] == "aspect_bank"]
    if (len(aspect_banks) != 2 or {row[1] for row in aspect_banks if len(row) == 3} != {"arx", "ary"}
            or any(len(row) != 3 or not row[2].isdigit() for row in aspect_banks)
            or sum(int(row[2]) for row in aspect_banks if len(row) == 3 and row[2].isdigit()) == 0):
        errors.append("standard aspect selector combined membership missing/malformed")
    path_reports = [row for row in receipt_rows if row[0] == "path_report"]
    expected_paths = {(corner, scope, kind) for corner in CORNERS
                      for scope, kind in (("cpu", "setup"), ("cpu", "hold"), ("core", "setup"), ("hdmi", "setup"), ("hdmi", "hold"))}
    observed_paths = set()
    for row in path_reports:
        if len(row) != 6 or not row[4].isdigit() or int(row[4]) < 1:
            errors.append(f"malformed/empty diagnostic path receipt: {row}")
            continue
        key = tuple(row[1:4])
        if key in observed_paths or key not in expected_paths:
            errors.append(f"duplicate/unexpected diagnostic path group: {key}")
        observed_paths.add(key)
        path = (run / row[5]).resolve()
        if not path.is_relative_to((run / "reports").resolve()):
            errors.append(f"diagnostic path report escapes report directory: {row[5]}")
        else:
            read(path)
    if observed_paths != expected_paths:
        errors.append(f"missing diagnostic corner/path groups: {sorted(expected_paths - observed_paths)}")
    for filename in ("revx_clocks.rpt", "revx_check_timing.rpt", "revx_unconstrained.rpt"):
        read(run / "reports" / filename)
    diagnostic_text = read(run / "reports/revx_check_timing.rpt")
    classified, chassis_proofs = chassis_diagnostic_evidence(
        run, tables(diagnostic_text), table, tables(read(run / "reports/revx_unconstrained.rpt")))
    diagnostic_errors, diagnostic_classification = classify_check_timing(diagnostic_text, classified)
    errors.extend(diagnostic_errors)
    pin_errors, pin_evidence = strict_pin_evidence(run, receipt_rows, chassis_proofs, diagnostic_text)
    errors.extend(pin_errors)
    # Constraint warnings and critical warnings are blockers, even when the
    # underlying Quartus process returns zero. Report platform debt explicitly.
    warning_lines = sorted(set(line.strip() for line in (logs + "\n" + sta).splitlines()
        if re.search(r"Critical Warning|Warning \(332(?:049|060|088|148|174)\)|Timing requirements not met", line)))
    errors.extend(warning_lines)
    verdict, errors, waived = apply_waiver(errors, checks)
    return {"result": verdict, "errors": errors, "waived": waived, "corners": CORNERS,
            "checks": checks, "design_wide_tns": design_tns,
            "qualification": {"PASS": "physical-signoff", "WAIVER": "cabinet-waiver"}.get(verdict, "unqualified"),
            "unconstrained_summary": ucp, "constraint_warnings": warning_lines,
            "check_timing_classification": diagnostic_classification,
            "chassis_diagnostic_evidence": chassis_proofs,
            "standard_aspect_selector_banks": aspect_banks,
            "cpu_ce_contract": {"source_proof": ce_source,
                                "ce_register_count": len(ce_names),
                                "full_rate_cpu_register_count": len(full_names),
                                "fitted_members": ce_members, "fitted_families": ce_families,
                                "directed_corner_audits": ce_audits,
                                "path_audit_limit_per_direction_corner": 500},
            "diagnostic_path_reports": path_reports,
            "strict_pin_contract": pin_evidence}


if __name__ == "__main__":
    command, directory = sys.argv[1:]
    run = Path(directory).resolve(strict=True)
    try:
        result = {"topology": topology, "signoff": signoff}[command](run)
    except Exception as exc:
        result = {"result": "FAIL", "errors": [str(exc)]}
    target = run / "receipts" / f"{command}.json"
    target.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"REVX {command.upper()}: {result['result']} ({target})")
    for message in result.get("errors", [])[:30]:
        print(f"  {message}", file=sys.stderr)
    for message in result.get("waived", [])[:30]:
        print(f"  WAIVED: {message}", file=sys.stderr)
    sys.exit(0 if result["result"] in ("PASS", "WAIVER") else 1)
