# RevX clk_sys=80 MHz. Only positive, source-pinned CPU CE register pairs
# receive the actual /3 enable contract; every other direction stays one cycle.
# Chassis clocks and platform exceptions remain in sys/sys_top.sdc.
# SDRAM MT48LC16M16 CAS2 pin-delay contract retained from the donor board setup.
proc revx_require {label collection count} {
    set n [get_collection_size $collection]
    if {$n != $count} { error "REVX_SDC required $label count=$n expected=$count" }
    return $collection
}
set revx_sdram_source [revx_require sdram_pll_pin [get_pins -compatibility_mode {emu|pll|pll_inst|altera_pll_i|general[1].gpll~PLL_OUTPUT_COUNTER|divclk}] 1]
set revx_sdram_port [revx_require sdram_clock_port [get_ports {SDRAM_CLK}] 1]
create_generated_clock -name SDRAM_CLK -source $revx_sdram_source $revx_sdram_port
set revx_dq [revx_require sdram_data [get_ports {SDRAM_DQ[*]}] 16]
set_input_delay -clock SDRAM_CLK -max 6.0 $revx_dq
set_input_delay -clock SDRAM_CLK -min 2.5 $revx_dq
set revx_outputs [get_ports {SDRAM_A* SDRAM_BA* SDRAM_D* SDRAM_CKE SDRAM_n*}]
if {[get_collection_size $revx_outputs] == 0} { error "REVX_SDC no SDRAM outputs" }
set_output_delay -clock SDRAM_CLK -max 1.5 $revx_outputs
set_output_delay -clock SDRAM_CLK -min -0.8 $revx_outputs
# No borrowed read-capture multicycle. Measure controller launch/capture paths
# before introducing any physically justified exception.
# (2026-09-10 measurement: the burst-lane capture closed by DESIGN -- an
# enable-free stage-1 register that Quartus maps to the IOE; no SDC change.)

# The core and its CE-qualified boundaries update only on the /3 cpu_ce phase, so
# a value launched from one CE flop reaches another CE flop only on the next
# cpu_ce edge = 3 clk_sys later (setup 3 / hold 2). The LAUNCH registers capture
# core commands on cpu_ce (or, for the io_write_boundary one-shots, force their
# off-CE value to 0 independent of the command), so they are valid multicycle
# DESTINATIONS from the CE core -- never sources back into it:
#   u_mif             a_q/sz_q/we_q/srt_q/f_q  (external-memory command launch; unused wd_q optimized away),
#                     p_addr0/p_addr1/p_be0/p_be1/p_wsh0/p_wsh1/p_nmask0/p_nmask1/
#                     p_rmw/p_straddle  (per-beat bus fields precomputed at launch:
#                     the deep size/align barrel-shift + byte-lane cone becomes a
#                     CE-core -> launch path, not a launch -> bus full-rate path)
#   u_io_write_boundary  wr_valid / wr_status_guard  (I/O write command one-shots)
#   u_cpu             io_rdata_req_valid_q      (I/O read request valid)
#   u_cpu             setcdp_we_q / setcdp_convdp_q  ('020 SETCDP CONVDP side-write)
# io_rdata_req_valid_q also changes ONLY on cpu_ce after its clear was CE-qualified,
# so it is additionally a valid multicycle SOURCE into the CE core
# (io_rdata_req_valid_q -> move_mem_cmd_wdata_q); that single-source direction gets
# its own setup 3 / hold 2.  u_mif response/bus-FSM registers, io_regs, video,
# synchronizers and reset launches stay one cycle. The JSON/source proof and
# generated collector are checked in prepare and before map; the fitted audit
# records every member and every boundary.
source quartus/revx_cpu_ce.tcl
set revx_ce_contract [revx_ce::collect]
set revx_ce_registers [dict get $revx_ce_contract ce]
set_multicycle_path -setup 3 -from $revx_ce_registers -to $revx_ce_registers
set_multicycle_path -hold 2 -from $revx_ce_registers -to $revx_ce_registers
set revx_launch_regs [get_registers {*tms34010_mem_if:u_mif|a_q* *tms34010_mem_if:u_mif|sz_q* *tms34010_mem_if:u_mif|we_q* *tms34010_mem_if:u_mif|srt_q* *tms34010_mem_if:u_mif|f_q* *tms34010_mem_if:u_mif|p_addr0* *tms34010_mem_if:u_mif|p_addr1* *tms34010_mem_if:u_mif|p_be0* *tms34010_mem_if:u_mif|p_be1* *tms34010_mem_if:u_mif|p_wsh0* *tms34010_mem_if:u_mif|p_wsh1* *tms34010_mem_if:u_mif|p_nmask0* *tms34010_mem_if:u_mif|p_nmask1* *tms34010_mem_if:u_mif|p_rmw* *tms34010_mem_if:u_mif|p_straddle* *tms34010_io_write_boundary:u_io_write_boundary|wr_valid *tms34010_io_write_boundary:u_io_write_boundary|wr_status_guard *tms34010_core:u_cpu|io_rdata_req_valid_q *tms34010_core:u_cpu|setcdp_we_q *tms34010_core:u_cpu|setcdp_convdp_q*}]
if {[get_collection_size $revx_launch_regs] == 0} { error "REVX_SDC no launch registers" }
set_multicycle_path -setup 3 -from $revx_ce_registers -to $revx_launch_regs
set_multicycle_path -hold 2 -from $revx_ce_registers -to $revx_launch_regs
set revx_launch_io_read [get_registers {*tms34010_core:u_cpu|io_rdata_req_valid_q}]
if {[get_collection_size $revx_launch_io_read] == 0} { error "REVX_SDC no io-read launch register" }
set_multicycle_path -setup 3 -from $revx_launch_io_read -to $revx_ce_registers
set_multicycle_path -hold 2 -from $revx_launch_io_read -to $revx_ce_registers
