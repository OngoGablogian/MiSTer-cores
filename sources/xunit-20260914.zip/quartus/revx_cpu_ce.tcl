# Generated from revx_cpu_ce.json by revx_ce_contract.py; verified before map.
namespace eval revx_ce {
  variable families [dict create \
    {} {blmove_align_err_q blmove_bits_q div_dvd_sign_q div_dvs_sign_q drav_cmd_size_q drav_cmd_srt_q drav_cmd_valid_q drav_cmd_wdata_q drav_cmd_we_q drav_color_q drav_dest_q drav_inside_q drav_linear_q drav_phase_q drav_pixel_mask drav_pmask_q drav_ppop_q drav_processed_q drav_rd_q drav_rs_q drav_srt_q drav_transparent_q drav_w_q dsjs_delay_q fetch_inflight_q fill_addr_q fill_color_q fill_daddr_raw_q fill_dest_q fill_dptch_q fill_dx_q fill_dy_q fill_row_base_q fill_srt_row_start_q fill_srt_rows_left_q fill_srt_span_bits_q fill_srt_word_addr_q fill_srt_words_left_q fill_substep_q fill_w1_q fill_w2_q fill_wend_q fill_win_en_q fill_wstart_q fill_x_q fill_y_q gfx_timing_daddr_raw_q gfx_timing_offset_q gfx_timing_saddr_raw_q illegal_q imm2_hi_q imm2_lo_q imm_hi_q imm_lo_q instr_word_q instruction_active_q int_is_nmi_q int_push_q int_vec_q io_is_io_q io_rdata_q io_rdata_req_q line_a_q line_aborted_q line_b_q line_color_q line_count_q line_d_q line_daddr_q line_dest_q line_inc1_q line_inc2_q line_initial_count_q line_last_inside_q line_offset_q line_substep_q line_wend_q line_wstart_q mem_op_step mm_mask_q mm_mem_cmd_addr_q mm_mem_cmd_valid_q mm_mem_cmd_wdata_q mm_mem_cmd_we_q mm_rp_q move_data_q move_mem_cmd_addr_q move_mem_cmd_size_q move_mem_cmd_valid_q move_mem_cmd_wdata_q move_mem_cmd_we_q mpy_product_q mv_load_data_q pair_wb_step pblt_color0_q pblt_color1_q pblt_dptch_q pblt_dst_addr_q pblt_dst_pix_q pblt_dst_row_q pblt_dst_xy_raw_q pblt_dx_q pblt_dy_q pblt_sptch_q pblt_src_addr_q pblt_src_pix_q pblt_src_row_q pblt_substep_q pblt_w1_q pblt_w2_q pblt_wend_q pblt_win_en_q pblt_wstart_q pblt_x_q pblt_y_q pix_dest_q pixt_clip_out_q pixt_inside_q pixt_ptr_q pixt_wend_q pixt_wstart_q popped_pc_q popped_st_q prev_wb_nop_q srt_fill_q srt_idx srt_rdata_q srt_word_base srt_wr_phase state_q timing_interrupt_q} \
    {tms34010_pc:u_pc} {pc_q} \
    {tms34010_regfile:u_regfile} {a_regs b_regs sp_q} \
    {tms34010_status_reg:u_status_reg} {st_q} \
    {tms34010_divider:u_divider} {divisor_q dvd_lo_q iter_q ovf_q quot_q rem_q st_q} \
    {tms34010_blmove:u_blmove} {align_q bits_q done_o dst_q src_q st_q word_q chunk_q} \
    {tms34010_gfx_cycle_counter:u_gfx_cycle_counter} {acc_q binary_q bpp_shift_q busy cycles done dptch_q dst_addr_q dx_q fill_q needs_dest_q op_timing_q overflow reverse_q rows_left_q sptch_q src_addr_q state_q yreverse_q} \
    {tms34010_io_cpu_config:u_io_cpu_config} {control convdp convsp dpyctl pmask psize} \
    {tms34010_io_cpu_status:u_io_cpu_status} {hstctlh hstctlh_write_bridge intenb intenb_write_bridge intpend intpend_write_bridge} \
    {tms34010_io_write_boundary:u_io_write_boundary} {wr_addr wr_data wr_size wr_mask wr_data_sh wr_display_hi wr_display_pair}]
  variable full_local {io_rdata_req_valid_q wvp_set_q setcdp_we_q setcdp_convdp_q}
  variable state_aliases [dict create]
  dict set state_aliases {|drav_phase_q} {00 01 10 11}
  dict set state_aliases {|pblt_substep_q} {00 01 10}
  dict set state_aliases {|state_q} {000000 000001 000010 000011 000100 000101 000110 000111 001000 001001 001010 001011 001100 001101 001110 001111 010000 010001 010010 010011 010100 010101 010110 010111 011000 011001 011010 011011 011100 011101 011110 011111 100000 100001 100010 100011 100100 100101 100110 100111 101000 101001 101010 101011 101101 101110 101111 110000 110001 GFX_RETIRE_STATE}
  dict set state_aliases {tms34010_divider:u_divider|st_q} {00 01 10}
  dict set state_aliases {tms34010_blmove:u_blmove|st_q} {0000 0001 0010 0011 0100 0101 0110 0111 1000}
  dict set state_aliases {tms34010_gfx_cycle_counter:u_gfx_cycle_counter|state_q} {00 01 10}
}

proc revx_ce::resolve_names {label names} {
    # foreach_in_collection yields object IDs (reg_123), not collections.
    # Resolve the reviewed full-name list once, then prove exact membership;
    # never pass those object IDs to add/remove_from_collection as filters.
    # Quartus 17 natural-bus naming is on by default: do not double-escape
    # literal array brackets. Every duplicate is explicitly in names already.
    set collection [get_registers -no_duplicates -nowarn $names]
    set resolved [list]
    foreach_in_collection reg $collection {
        lappend resolved [get_node_info -name $reg]
    }
    if {[lsort -unique $names] ne [lsort -unique $resolved] ||
        [llength $names] != [get_collection_size $collection]} {
        error "RevX CE: name resolution changed $label membership"
    }
    return $collection
}
proc revx_ce::collect {} {
    variable families
    variable full_local
    variable state_aliases
    set cpu [get_registers -nowarn {*tms34010_core:u_cpu|*}]
    if {[get_collection_size $cpu] == 0} { error "RevX CE: missing actual CPU" }
    set ce_names [list]
    set full_names [list]
    set members [list]
    set counts [dict create]
    set marker {tms34010_core:u_cpu|}
    foreach_in_collection reg $cpu {
        set name [get_node_info -name $reg]
        set offset [string first $marker $name]
        if {$offset < 0} { error "RevX CE: malformed CPU register $name" }
        set relative [string range $name [expr {$offset + [string length $marker]}] end]
        set parts [split $relative {|}]
        set hierarchy [join [lrange $parts 0 end-1] {|}]
        set leaf [lindex $parts end]
        # Bit/array selectors and recognized duplicates retain their source
        # stem. Dot-state labels must occur in that exact stem's map-proven
        # state encoding table; numeric dots are not generally allowed.
        # Physical-synthesis register aliases inherit their origin's CE
        # classification: strip the tool-appended trailing tokens (~DUPLICATE(_n),
        # _OTERM<digits>, _ITERM<digits>) a duplicated/retimed/output-terminal copy
        # carries, from the LEAF before splitting stem/selector, repeatedly so a
        # composed/chained alias reduces to its origin name. Stripping pre-split is
        # required: on a no-selector (1-bit) register the underscore token would
        # otherwise be absorbed into the greedy stem match (wr_mask[6]_OTERM1481~DUPLICATE
        # at 1fc583ce fit.rpt:9426; _OTERM<n>_OTERM<m> chains). Every other spelling
        # fails closed below. Loop terminates: each strip shortens the string.
        set base_leaf $leaf
        while {[regsub -nocase {(~DUPLICATE(_[0-9]+)?|_OTERM[0-9]+|_ITERM[0-9]+|_NEW_REG[0-9]+)$} $base_leaf {} base_leaf]} {}
        if {![regexp {^([A-Za-z_][A-Za-z0-9_]*)(.*)$} $base_leaf -> stem base_suffix]} {
            error "RevX CE: unknown register spelling $name"
        }
        set alias_ok [regexp {^(\[[0-9]+\])*$} $base_suffix]
        set state_key "${hierarchy}|${stem}"
        if {[string index $base_suffix 0] eq "." && [dict exists $state_aliases $state_key]} {
            set alias_ok [expr {[lsearch -exact [dict get $state_aliases $state_key] \
                                       [string range $base_suffix 1 end]] >= 0}]
        }
        if {!$alias_ok} {
            # Full-rate child logic can contain tool-specific RAM/shift atoms;
            # it remains outside the exception regardless of its spelling.
            if {![string match {tms34010_io_regs:u_io_regs|*} $relative]} {
                error "RevX CE: unclassified alias $name"
            }
        }
        set kind full
        if {[dict exists $families $hierarchy] &&
            [lsearch -exact [dict get $families $hierarchy] $stem] >= 0} {
            set kind ce
            lappend ce_names $name
            dict incr counts $hierarchy
        } elseif {($hierarchy eq "" && [lsearch -exact $full_local $stem] >= 0) ||
                  $hierarchy eq "tms34010_io_write_boundary:u_io_write_boundary" ||
                  [string match {tms34010_io_regs:u_io_regs|*} $relative]} {
            lappend full_names $name
        } else {
            error "RevX CE: register has no reviewed eligibility or exclusion: $name"
        }
        lappend members [list $kind $hierarchy $stem $name]
    }
    foreach hierarchy [list {} {tms34010_pc:u_pc} {tms34010_regfile:u_regfile} \
                        {tms34010_status_reg:u_status_reg} \
                        {tms34010_io_cpu_config:u_io_cpu_config} \
                        {tms34010_io_cpu_status:u_io_cpu_status}] {
        if {![dict exists $counts $hierarchy] || [dict get $counts $hierarchy] == 0} {
            error "RevX CE: required architectural family absent: $hierarchy"
        }
    }
    if {[llength $full_names] == 0} { error "RevX CE: missing full-rate boundary exclusions" }
    set ce [revx_ce::resolve_names ce $ce_names]
    set full [revx_ce::resolve_names full $full_names]
    if {[get_collection_size $ce] + [get_collection_size $full] != [get_collection_size $cpu]} {
        error "RevX CE: incomplete/overlapping fitted membership"
    }
    set outside [remove_from_collection [get_registers {*}] $ce]
    return [dict create ce $ce full $full outside $outside members $members counts $counts]
}
