#!/usr/bin/env python3
# preflight_revx.py -- RevX build preflight (invoked by quartus/preflight_revx.sh).
# Source checks (count printed at the end), including synthesis-branch RAM shapes, the
# deployed IO-only route, and the TMS_IS_34020 sv2v/QSF define-seam assertion (check 7).
# Physical inference and timing still require the exact prepared Quartus run.
import os, re, sys, ast, operator

ROOT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
EMU  = os.path.join(ROOT, "Arcade-RevX.sv")
TOP  = os.path.join(ROOT, "rtl", "revx", "revx_top.sv")
QIP  = os.path.join(ROOT, "quartus", "Arcade-RevX.files.qip")
QSF  = os.path.join(ROOT, "quartus", "Arcade-RevX.qsf")
QPF  = os.path.join(ROOT, "quartus", "Arcade-RevX.qpf")

def read(p):
    with open(p, encoding="utf-8", errors="replace") as f: return f.read()

def strip_line_comments(txt):
    return "\n".join(re.sub(r"//.*$", "", ln) for ln in txt.splitlines())

fails = []
ran = []
def check(name, ok, detail=""):
    ran.append(name)
    print(("  OK  " if ok else " FAIL ") + name + ((" -- " + detail) if detail and not ok else ""))
    if not ok: fails.append(name)

# ---------------------------------------------------------------- CHECK 1: status reads <= CONF_STR
emu = read(EMU); top = read(TOP)
src_nc = strip_line_comments(emu) + "\n" + strip_line_comments(top)
read_bits = set()
for m in re.finditer(r"status\[(\d+)\s*:\s*(\d+)\]", src_nc):
    hi, lo = int(m.group(1)), int(m.group(2)); read_bits.update(range(min(hi,lo), max(hi,lo)+1))
for m in re.finditer(r"status\[(\d+)\]", src_nc):
    read_bits.add(int(m.group(1)))

# CONF_STR entries -> covered bits.  Bracket style O[H:L]/O[N] (with any P<d>/H<d>/D<d> prefix),
# and legacy O<1-2 hex>/T<hex>/R<hex>.
conf_bits = set()
# isolate the CONF_STR block (comment-stripped, so a `};` inside a // comment can't end it early)
emu_nc = strip_line_comments(emu)
cm = re.search(r"localparam\s+CONF_STR\s*=\s*\{(.*?)\};", emu_nc, re.S)
conf = cm.group(1) if cm else emu_nc
for m in re.finditer(r"O\[(\d+)\s*:\s*(\d+)\]", conf):
    hi, lo = int(m.group(1)), int(m.group(2)); conf_bits.update(range(min(hi,lo), max(hi,lo)+1))
for m in re.finditer(r"O\[(\d+)\]", conf):
    conf_bits.add(int(m.group(1)))
# legacy: a string token starting with O/T/R then hex digits then , or ;
for m in re.finditer(r'"[A-Z]?\d*O([0-9A-Fa-f]{1,2})[,;]', conf):
    d = m.group(1)
    if len(d) == 1: conf_bits.add(int(d, 16))
    else:
        a, b = int(d[0], 16), int(d[1], 16); conf_bits.update(range(min(a,b), max(a,b)+1))
for m in re.finditer(r'"T([0-9A-Fa-f])[,;]', conf): conf_bits.add(int(m.group(1), 16))
for m in re.finditer(r'"R([0-9A-Fa-f])[,;]', conf): conf_bits.add(int(m.group(1), 16))

missing = sorted(b for b in read_bits if b not in conf_bits)
check("(1) every status[N] read has a CONF_STR entry",
      not missing, "read bits with no OSD entry: " + str(missing))
print("      status reads=%s ; CONF_STR bits=%s" % (sorted(read_bits), sorted(conf_bits)))

# ---------------------------------------------------------------- CHECK 2: instantiations resolve
# defined modules = every `module <name>` in the qip-listed files + the sys chassis + pll.
qip = read(QIP)
qip_files = [os.path.normpath(os.path.join(ROOT, "quartus", p))
             for p in re.findall(r"SYSTEMVERILOG_FILE\s+(\S+)", qip)]
defined = set()
for p in qip_files:
    if os.path.exists(p):
        for m in re.finditer(r"^\s*module\s+([A-Za-z_]\w*)", read(p), re.M): defined.add(m.group(1))
# sys chassis + IP modules the emu binds (provided by sys.qip / pll.qip in the qsf)
for d in [os.path.join(ROOT, "sys"), os.path.join(ROOT, "rtl", "pll")]:
    if os.path.isdir(d):
        for fn in os.listdir(d):
            if fn.endswith((".sv", ".v")):
                for m in re.finditer(r"^\s*module\s+([A-Za-z_]\w*)", read(os.path.join(d, fn)), re.M):
                    defined.add(m.group(1))
defined.add("pll")  # Altera PLL megafunction (rtl/pll.qip)

KW = {"if","else","for","case","begin","end","always","always_ff","always_comb","assign","module",
      "endmodule","wire","reg","logic","localparam","parameter","generate","endgenerate","initial",
      "function","task","typedef","enum","struct","input","output","inout","genvar","integer","real",
      "posedge","negedge","default","casez","casex","unique","priority","return","while","repeat",
      "endcase","endfunction","endtask","signed","unsigned","automatic","static"}
# instantiations in the emu + revx_top: `modname [#(..)] instname (`
inst = set()
for src in (strip_line_comments(emu), strip_line_comments(top)):
    for m in re.finditer(r"^\s*([A-Za-z_]\w*)\s+(?:#\s*\([^;]*?\)\s*)?([A-Za-z_]\w*)\s*\(", src, re.M | re.S):
        name = m.group(1)
        if name not in KW: inst.add(name)
unresolved = sorted(n for n in inst if n not in defined)
check("(2) every module instantiated under the emu/revx_top resolves to a qip/sys file",
      not unresolved, "unresolved module instantiations: " + str(unresolved))

# ---------------------------------------------------------------- CHECK 3: QSF define set
qsf = read(QSF)
macros = set(re.findall(r'VERILOG_MACRO\s+"?([A-Za-z_]\w*)', qsf))
has_ddr3 = {"USE_DDR3_GFX", "USE_DDR3_DCS", "REVX_EMU_INTEG"} <= macros
no_bfm = "REVX_USE_BFM_CPU" not in macros
check("(3) QSF enables DDR3 gfx/DCS and real emu integration, with no shipped BFM",
      has_ddr3 and no_bfm,
      "macros=%s (USE_DDR3_GFX=%s, REVX_USE_BFM_CPU absent=%s)" % (sorted(macros), has_ddr3, no_bfm))

# ---------------------------------------------------------------- CHECK 4: output dir == revision
outdir = re.search(r"PROJECT_OUTPUT_DIRECTORY\s+(\S+)", qsf)
rev = re.search(r'PROJECT_REVISION\s*=\s*"?([A-Za-z0-9_\-]+)', read(QPF))
ok4 = bool(outdir and rev) and os.path.basename(outdir.group(1)) == rev.group(1)
check("(4) PROJECT_OUTPUT_DIRECTORY basename == PROJECT_REVISION",
      ok4, "outdir=%s revision=%s" % (outdir.group(1) if outdir else None, rev.group(1) if rev else None))

# ---------------------------------------------------------------- CHECK 5: RAM inference lint
# Incident 2026-09-07: the first map failed (Error 276003) because `revx_top.pal` (32768x16)
# was read combinationally -> Quartus built it from flops (Info 276007 "uninferred due to
# asynchronous read logic").  Rule (memory: async-read-explodes-bram-to-flops, quartus-ram-
# inference-is-silent): every unpacked array >= 1 Kbit must be read ONLY inside a clocked
# block and carry a ramstyle attribute.  Static heuristic; it FAILS on the pre-fix tree.
import glob
ram_fails = []

def synth_text(txt):
    """Keep the active DIAG synthesis branches; preserve line numbers for diagnostics."""
    defines = {"SYNTHESIS", "USE_DDR3_GFX", "USE_DDR3_DCS", "REVX_EMU_INTEG", "REVX_DIAG_BOOT",
               "REVX_FETCH_LB_BURST", "REVX_DATA_LB", "REVX_BLMOVE_BURST", "REVX_VRAM_LB"}
    stack, active, out = [], True, []
    for line in txt.splitlines():
        m = re.match(r"\s*`(ifdef|ifndef|elsif|else|endif|define|undef)\b\s*(\w+)?", line)
        if m:
            op, name = m.groups()
            if op in ("ifdef", "ifndef"):
                cond = (name in defines) == (op == "ifdef")
                stack.append([active, cond]); active = active and cond
            elif op == "elsif":
                parent, taken = stack[-1]; cond = not taken and name in defines
                stack[-1][1] |= cond; active = parent and cond
            elif op == "else":
                parent, taken = stack[-1]; active = parent and not taken; stack[-1][1] = True
            elif op == "endif": active = stack.pop()[0]
            elif active and op == "define": defines.add(name)
            elif active and op == "undef": defines.discard(name)
            out.append("")
        else: out.append(line if active else "")
    if stack: raise ValueError("unbalanced preprocessor branches")
    return "\n".join(out)

def constant(expr, env):
    """Evaluate only integer arithmetic in array dimensions, never Python source."""
    expr = re.sub(r"\d*'([hHdDbBoO])([0-9a-fA-F_]+)",
                  lambda m: str(int(m[2].replace('_',''), {'h':16,'d':10,'b':2,'o':8}[m[1].lower()])), expr)
    if '?' in expr:
        cond, choices = expr.split('?', 1); yes, no = choices.split(':', 1)
        return constant(yes if constant(cond, env) else no, env)
    expr = expr.replace('$clog2', 'clog2').strip()
    ops = {ast.Add:operator.add, ast.Sub:operator.sub, ast.Mult:operator.mul,
           ast.LShift:operator.lshift, ast.RShift:operator.rshift,
           ast.BitOr:operator.or_, ast.BitAnd:operator.and_, ast.FloorDiv:operator.floordiv}
    def ev(node):
        if isinstance(node, ast.Constant) and type(node.value) is int: return node.value
        if isinstance(node, ast.Name): return env[node.id]
        if isinstance(node, ast.BinOp) and type(node.op) in ops: return ops[type(node.op)](ev(node.left), ev(node.right))
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub): return -ev(node.operand)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'clog2' and len(node.args) == 1:
            return (ev(node.args[0])-1).bit_length()
        raise ValueError('unsupported constant expression')
    return ev(ast.parse(expr, mode='eval').body)

io_only = bool(re.search(r"revx_memsys\s*#\s*\(\s*\.IO_ONLY\(\s*(?:1|1'b1)\s*\)", synth_text(top)))
def scan_ram(path):
    txt = strip_line_comments(synth_text(read(path)))
    txt = re.sub(r"/\*.*?\*/", "", txt, flags=re.S)
    env = {}
    params = re.findall(r"\b(?:parameter|localparam)\s+(?:(?:int|integer|logic|bit|signed)\s+|\[[^\]]+\]\s*)*(\w+)\s*=\s*([^,;\n]+)", txt)
    for _ in range(len(params)+1):
        for name, expr in params:
            if os.path.basename(path) == 'revx_mem.sv' and io_only and name == 'IO_ONLY':
                env[name] = 1
                continue
            try: env[name] = constant(expr, env)
            except (ValueError, SyntaxError, KeyError): pass
        if os.path.basename(path) == 'revx_mem.sv' and io_only: env['IO_ONLY'] = 1
    array_re = r"(?:logic|reg|wire)\s*(?:signed\s*)?(?:\[([^\]]+):([^\]]+)\]\s*)?(\w+)\s*\[\s*([^\]]+):([^\]]+)\s*\]\s*;"
    for m in re.finditer(array_re, txt):
        name = m[3]
        try:
            hi, lo = (constant(m[1], env), constant(m[2], env)) if m[1] else (0, 0)
            a, b = constant(m[4], env), constant(m[5], env)
        except (ValueError, SyntaxError, KeyError):
            ram_fails.append('%s:%s unresolved array dimensions for %s' % (os.path.basename(path), txt[:m.start()].count('\n')+1, name))
            continue
        bits = (abs(hi - lo) + 1) * (abs(a - b) + 1)
        if bits < 1024: continue
        pre = txt[max(0, m.start() - 200):m.start()]
        has_attr = bool(re.search(r"\(\*[^*]*ram_?style[^*]*\*\)\s*$", pre))
        # a read = name[...] that is not the left-hand side of a write
        reads_async = []
        for r in re.finditer(r"\b%s\s*\[" % re.escape(name), txt):
            # skip the declaration and writes (name[..] <= / = on the lhs)
            after = txt[r.start():r.start() + 200]
            if re.match(r"\b%s\s*\[[^\]]*\]\s*(<=|=)[^=]" % re.escape(name), after): continue
            if r.start() == m.start(3): continue
            # find the enclosing block: look back for the nearest always/assign/function keyword
            back = txt[:r.start()]
            kw = list(re.finditer(r"\b(always_ff|always_comb|always_latch|always\s*@\s*\(\s*posedge|always\s*@|assign|function|task|initial)\b", back))
            enc = kw[-1].group(1) if kw else "?"
            if not (enc.startswith("always_ff") or enc.startswith("always") and "posedge" in enc):
                reads_async.append((txt[:r.start()].count("\n") + 1, enc))
        if reads_async or not has_attr:
            ram_fails.append("%s:%s %s (%d bits) attr=%s async_reads=%s" % (
                os.path.basename(path), txt[:m.start()].count("\n") + 1, name, bits, has_attr,
                ["line %d in %s" % x for x in reads_async][:3]))
for f in sorted(set(glob.glob(os.path.join(ROOT, "rtl", "revx", "*.sv")) +
                    glob.glob(os.path.join(ROOT, "rtl", "diag", "revx_*.sv")) +
                    [os.path.join(ROOT, "rtl", "sdram", "wolf_gfx_ddr_top.sv")])):
    scan_ram(f)
check("(5) RAM inference lint: every >=1 Kbit array read only in a clocked block and ramstyle-attributed",
      not ram_fails, " | ".join(ram_fails[:40]))
check("(6) synthesized peripheral route uses IO_ONLY=1", io_only)

# (7) The CPU core's 34020 mode is a package define (tms34010_pkg.sv `TMS_IS_34020,
# default 1'b0).  It must reach BOTH sides of the sv2v/Quartus define seam: the sv2v
# macro list in revx_build.py and the QSF VERILOG_MACRO set.  Builds 1-3 omitted it and
# shipped a 34010-mode core (BLMOVE = cold-boot instruction #14 folded to illegal ->
# the 2026-09-07 cabinet derail).  A define that only the sim runners pass is the
# "sim green, cab black" seam of DESIGN-RULES.md s.6.
_qdir = os.path.dirname(os.path.abspath(__file__))
_bp = read(os.path.join(_qdir, "revx_build.py"))
_m  = re.search(r"^MACROS\s*=\s*\[(.*?)\]", _bp, re.M | re.S)
_macros_ok = bool(_m) and "TMS_IS_34020=1'b1" in _m.group(1)
_qsf_ok = 'VERILOG_MACRO "TMS_IS_34020=1\'b1"' in read(os.path.join(_qdir, "Arcade-RevX.qsf"))
check("(7) TMS_IS_34020=1'b1 is in revx_build.py MACROS and the QSF VERILOG_MACRO set",
      _macros_ok and _qsf_ok, "sv2v list ok=%s, qsf ok=%s" % (_macros_ok, _qsf_ok))

print()
if fails:
    print("PREFLIGHT FAILED (%d/%d checks): %s" % (len(fails), len(ran), ", ".join(fails))); sys.exit(1)
print("PREFLIGHT PASSED: all %d checks green" % len(ran)); sys.exit(0)
