#!/usr/bin/env python3
"""Prepare immutable RevX inputs, verify them, and collect a released FIFO attempt.

No command in this helper launches Quartus. Source and generated products from
earlier attempts are never removed or overwritten. Game data is not collected.
"""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import uuid
from revx_ce_contract import validate as validate_ce
from revx_fifo_contract import bind_owner, collect_fifo, launcher_identity

REV = "Arcade-RevX"
QBIN = Path("C:/intelFPGA_lite/17.0/quartus/bin64")
PINS = {
    "quartus_map.exe": "3DFB729AF88E2EF6217EC6EA0DBAD305485814B84B46610A1CFD41EFF5DBCD45",
    "quartus_fit.exe": "D7C802E80E332AEF0D5D711077B033FE8BEB9E58A2302A3B3F2C5C8CCD7A0917",
    "quartus_sta.exe": "5CD28F77B246F2B1324D76E01D15575FD5AB8E9B9297284126701278B8E325A9",
    "quartus_asm.exe": "F49DBD0C9659AEA524E013B65F69C612B87D715256E904B10C8D7BEFF32FF6CF",
}
SV2V = Path("C:/tools/sv2v/sv2v-Windows/sv2v.exe")
SV2V_SHA = "1F3C2B96E212592E6F4A2ECFF3209F211277834540D8A9309ECEE50A45ADC699"
IVERILOG = Path("C:/iverilog/bin/iverilog.exe")
# TMS_IS_34020: the core's 34020 mode is a package-level define (rtl/tms34010/rtl/
# tms34010_pkg.sv:42-45, default 1'b0 = TMS34010).  The sim runners pass
# -DTMS_IS_34020=1'b1; this list feeds sv2v AND the generated QSF (plumbed twice, the
# sv2v/Quartus define seam).  Builds 1-3 (6a4a1c30, 15eea4a4, d0320523) omitted it and
# shipped a 34010-mode core: BLMOVE (cold-boot instruction #14) folded to illegal ->
# the cabinet-1 derail.  Never remove.
MACROS = ["USE_DDR3_GFX=1", "USE_DDR3_DCS=1", "REVX_EMU_INTEG=1", "TMS_IS_34020=1'b1",
          "REVX_FETCH_LB_BURST=1", "REVX_DATA_LB=1", "REVX_BLMOVE_BURST=1", "REVX_VRAM_LB=1"]
SOURCE_SUFFIXES = {".v", ".sv", ".svh", ".vh", ".vhd", ".qip", ".sdc", ".tcl", ".cmp", ".mif", ".hex"}


def sha(path):
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest().upper()


def write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def inside(root, relative):
    path = (root / relative).resolve(strict=True)
    if not path.is_relative_to(root.resolve()) or not path.is_file():
        raise RuntimeError(f"input escapes snapshot or is not a file: {relative}")
    return path


def run_logged(argv, cwd, log):
    with Path(log).open("wb") as output:
        p = subprocess.run([str(x) for x in argv], cwd=cwd, stdout=output, stderr=subprocess.STDOUT)
    if p.returncode:
        raise RuntimeError(f"check failed ({p.returncode}): {argv[0]}; retained log={log}")
    return {"argv": [str(x) for x in argv], "exit": p.returncode, "log_sha256": sha(log)}


def tool_manifest():
    tools = {}
    for name, expected in PINS.items():
        path = QBIN / name
        actual = sha(path)
        if actual != expected:
            raise RuntimeError(f"pinned tool mismatch: {path}")
        tools[name] = {"path": str(path), "sha256": actual}
    if sha(SV2V) != SV2V_SHA:
        raise RuntimeError("pinned sv2v mismatch")
    for name, path in (("sv2v.exe", SV2V), ("python.exe", Path(sys.executable)), ("iverilog.exe", IVERILOG)):
        tools[name] = {"path": str(path.resolve()), "sha256": sha(path)}
    return tools


def prepare(root, variant, strict=False, skip_simulation=False):
    if variant not in {"diag", "production"}:
        raise RuntimeError("variant must be diag or production")
    root = root.resolve(strict=True)
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run = root / "build_syn" / "runs" / f"{variant}_{stamp}_{uuid.uuid4().hex[:8]}"
    run.mkdir(parents=True, exist_ok=False)
    print(f"Preparing {run}", file=sys.stderr)
    try:
        tools = tool_manifest()
        fifo = launcher_identity()
        validate_ce(root)
        validate_gate_allowlist(root)
        qip = root / "quartus/Arcade-RevX.files.qip"
        listed = re.findall(r"^set_global_assignment -name SYSTEMVERILOG_FILE\s+(\S+)\s*$", qip.read_text(), re.M)
        if not listed:
            raise RuntimeError("empty authoritative QIP source list")
        ordered = [inside(root, Path("quartus") / name).relative_to(root) for name in listed]
        required = set(ordered)
        required.update(Path(x) for x in (
            "Arcade-RevX.sv", "quartus/Arcade-RevX.files.qip", "quartus/Arcade-RevX.qsf",
            "quartus/Arcade-RevX.qpf", "quartus/build_revx.sh", "quartus/enqueue_revx.sh",
            "quartus/revx_build.py", "quartus/revx_physical_gate.py", "quartus/revx_sta.tcl",
            "quartus/revx.sdc", "quartus/preflight_revx.py", "sim/revx_elab_stubs.v",
            "quartus/revx_ce_contract.py", "quartus/revx_cpu_ce.json", "quartus/revx_cpu_ce.tcl",
            "quartus/revx_fifo_contract.py", "quartus/revx_waiver.env", "quartus/revx_chassis.sdc",
            "rtl/pll.qip", "rtl/pll.v",
            "sim/run_revx_converted_boot.sh", "sim/tb_revx_top_boot.sv",
            "sim/sdram_model.sv", "sim/ddr3_avalon_model.sv", "sim/revx_illop_guard.sv",
        ))
        # Platform source/IP text only. Never copy a whole RTL tree, ROMs,
        # mame-gospel, releases, simulations, db, or previous generated products.
        for directory in (root / "sys", root / "rtl/pll"):
            required.update(p.relative_to(root) for p in directory.rglob("*")
                            if p.is_file() and p.suffix.lower() in SOURCE_SUFFIXES)
        original = {}
        for relative in sorted(required):
            source = inside(root, relative)
            before = sha(source)
            destination = run / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, destination)
            if sha(destination) != before or sha(source) != before:
                raise RuntimeError(f"source changed during capture: {relative}")
            original[relative.as_posix()] = before
        for name in ("logs", "receipts", "reports", "output_files/Arcade-RevX", "build_syn"):
            (run / name).mkdir(parents=True, exist_ok=True)
        # A new strict attempt must not silently inherit a former cabinet-test
        # waiver. Preserve that owner policy in the checkout and original hash
        # manifest; change only this freshly prepared attempt's policy input.
        if strict:
            (run / "quartus/revx_waiver.env").write_text(
                "# Strict performance qualification; no cabinet waiver.\n"
                "REVX_WAIVER=\nREVX_WAIVER_NS=0\n", encoding="utf-8", newline="\n")
        macros = MACROS + (["REVX_DIAG_BOOT=1"] if variant == "diag" else [])
        qsf = (run / "quartus/Arcade-RevX.qsf").read_text()
        old_constraint = "set_global_assignment -name SDC_FILE rtl/sdram.sdc"
        if qsf.count(old_constraint) != 1:
            raise RuntimeError("expected exactly one inherited SDRAM constraint assignment")
        qsf = qsf.replace(old_constraint, "set_global_assignment -name SDC_FILE quartus/revx.sdc")
        # Freeze date before synthesis; do not let the donor pre-flow hook
        # rewrite a manifest-bound input at midnight or launch quartus_sh first.
        qsf = re.sub(r"^set_global_assignment -name (?:PRE_FLOW_SCRIPT_FILE|VERILOG_MACRO|TIMEQUEST_MULTICORNER_ANALYSIS) .*\n?", "", qsf, flags=re.M)
        qsf += "\n# Prepared RevX variant and explicit industrial multicorner analysis.\n"
        qsf += "".join(f'set_global_assignment -name VERILOG_MACRO "{m}"\n' for m in macros)
        qsf += "set_global_assignment -name TIMEQUEST_MULTICORNER_ANALYSIS ON\n"
        (run / f"{REV}.qsf").write_text(qsf, encoding="utf-8", newline="\n")
        shutil.copyfile(run / f"quartus/{REV}.qpf", run / f"{REV}.qpf")
        (run / "build_id.v").write_text(f'`define BUILD_DATE "{stamp[2:8]}"\n', encoding="ascii")
        simulation_policy = "not-run-user-requested" if skip_simulation else "converted-coldboot-required"
        prep = {"started": now(), "variant": variant, "macros": macros,
                "simulation_policy": simulation_policy,
                "signoff_policy": "strict" if strict else "captured-checkout-policy", "checks": []}
        write_json(run / "receipts/cpu_ce_source.json", validate_ce(run))
        prep["checks"].append(run_logged([sys.executable, "quartus/preflight_revx.py", str(run)], run, run / "logs/preflight.log"))
        converted = run / "build_syn/revx_core.v"
        args = [str(SV2V), "-DSYNTHESIS"] + [f"-D{m}" for m in macros] + [str(run / rel) for rel in ordered]
        with converted.open("wb") as out, (run / "logs/sv2v.err").open("wb") as err:
            p = subprocess.run(args, cwd=run, stdout=out, stderr=err)
        if p.returncode or not converted.stat().st_size or (run / "logs/sv2v.err").stat().st_size:
            raise RuntimeError(f"sv2v failed; retained {run / 'logs/sv2v.err'}")
        prep["checks"].append({"argv": args, "exit": p.returncode, "output_sha256": sha(converted)})
        # One structural elaboration, exactly the conversion/variant used by map.
        # pll/arcade_video remain the existing documented chassis stubs.
        elab = [IVERILOG, "-g2012"] + [f"-D{m}" for m in macros]
        elab += [f"-I{run}", "-s", "emu", "-o", run / "receipts/emu_elaboration.vvp",
                 run / "Arcade-RevX.sv", converted, run / "sim/revx_elab_stubs.v", run / "sys/hps_io.sv"]
        prep["checks"].append(run_logged(elab, run, run / "logs/elaboration.log"))
        # Converted-netlist cold-boot gate: run the SAME 8000-row cold-boot PC diff as
        # sim/run_revx_top_boot.sh (bench tb_revx_top_boot, same models/ROM/golden/dedup/pass
        # criteria) on THIS run's build_syn/revx_core.v -- the exact file the fitter reads --
        # with NO TMS_IS_34020 define, plus the illegal-opcode-latch discriminator.  Elaboration
        # above only proves the converted netlist links; this proves the converted netlist BOOTS
        # in the mode it was baked in.  It is the check that would have caught cabinet-1: builds
        # 1-3 baked IS_34020=1'b0 (a 34010-mode core) while every sim runner passed the define
        # -> "sim green, cab black" (DESIGN-RULES.md s.6).  A 34010-mode conversion latches the
        # illegal-opcode latch at the cold-boot BLMOVE and this raises -> prepare fails before
        # ready.json is written.  ~45 s; uses the checkout's tracked bench/models/gospel with
        # this run's converted core.
        boot_gate = [Path("C:/Program Files/Git/bin/bash.exe"),
                     (run / "sim/run_revx_converted_boot.sh").as_posix(), run.as_posix(), root.as_posix()]
        if skip_simulation:
            # Explicit user run control: do not run a new simulator for the
            # timing-repair build. Conversion and structural elaboration above
            # are retained; this is not a claim that the boot gate passed.
            prep["checks"].append({"name": "converted-coldboot",
                "status": "NOT_RUN", "reason": "explicit --skip-simulation user request"})
        elif os.environ.get("REVX_PREP_SKIP_BOOT_GATE") == "1":
            raise RuntimeError("converted boot gate is mandatory; remove REVX_PREP_SKIP_BOOT_GATE")
        else:
            prep["checks"].append(run_logged(boot_gate, root, run / "logs/converted_boot_gate.log"))
        prep["completed"] = now()
        write_json(run / "receipts/prepare.json", prep)
        for relative, captured_hash in original.items():
            if sha(root / relative) != captured_hash:
                raise RuntimeError(f"checkout changed during preparation: {relative}; captured attempt retained")
        write_json(run / "receipts/source.json", {"checkout": str(root), "head": None,
                   "tracked_diff_sha256": None,
                   "identity_basis": "exact captured source hashes; Git metadata not collected",
                   "captured_files": original, "ordered_core_files": [p.as_posix() for p in ordered],
                   "staged_changes": ["RevX SDC", "frozen build ID; pre-flow hook removed", "explicit variant macros", "multicorner on"]
                       + (["strict signoff; cabinet waiver disabled in this attempt"] if strict else [])})
        inputs = sorted(required | {Path(f"{REV}.qsf"), Path(f"{REV}.qpf"), Path("build_id.v"),
                         Path("build_syn/revx_core.v"), Path("receipts/prepare.json"), Path("receipts/source.json")})
        inputs.append(Path("receipts/cpu_ce_source.json"))
        ready = {"schema": "revx-prepared/v1", "root": str(run), "created": now(), "variant": variant,
                 "signoff_policy": "strict" if strict else "captured-checkout-policy",
                 "simulation_policy": simulation_policy,
                 "macros": macros, "tools": tools, "fifo_launcher": fifo,
                 "inputs": {p.as_posix(): sha(run / p) for p in inputs},
                 "first_worker": str(QBIN / "quartus_map.exe"), "qualification": "prepared-source-only"}
        write_json(run / "ready.json", ready)
        verify(run)
        print(str(run))
    except Exception as exc:
        write_json(run / "prepare.failure.json", {"time": now(), "error": str(exc)})
        raise


def verify(run):
    run = run.resolve(strict=True)
    ready = json.loads((run / "ready.json").read_text())
    if ready.get("schema") != "revx-prepared/v1" or Path(ready["root"]).resolve() != run:
        raise RuntimeError("prepared receipt schema/root mismatch")
    if ready.get("fifo_launcher") != launcher_identity():
        raise RuntimeError("prepared shared FIFO launcher identity changed")
    for relative, expected in ready["inputs"].items():
        if sha(inside(run, relative)) != expected:
            raise RuntimeError(f"prepared input changed: {relative}")
    if validate_ce(run) != json.loads((run / "receipts/cpu_ce_source.json").read_text(encoding="utf-8")):
        raise RuntimeError("CPU CE source proof receipt differs from pinned snapshot")
    for name, identity in ready["tools"].items():
        if sha(identity["path"]) != identity["sha256"]:
            raise RuntimeError(f"prepared tool changed: {name}")
    print(f"Prepared input/tool identity verified: {run.name}", file=sys.stderr)


def validate_gate_allowlist(root):
    """PROCESS FIX (2026-09-10): the physical signoff gate's launch-endpoint
    allow-list (revx_physical_gate.py launch_stem) must match the SDC's
    $revx_launch_regs collector.  A launch-register addition that updates the SDC
    but not the gate (or vice versa) previously failed only at SIGN-OFF on the
    shared box after a full map/fit/sta -- e.g. f_q on diag_20260910T234133Z.
    This check runs at PREPARE (local) so the mismatch is caught for free."""
    sdc = (root / "quartus/revx.sdc").read_text(encoding="utf-8")
    gate = (root / "quartus/revx_physical_gate.py").read_text(encoding="utf-8")
    line = next((ln for ln in sdc.splitlines() if "set revx_launch_regs" in ln), None)
    if line is None:
        raise RuntimeError("gate allow-list check: no revx_launch_regs collector in SDC")
    sdc_stems = set(re.findall(r"\*\s*([\w:]+)\|([\w]+)(?=\s*\*)", line))
    gate_stems = set()
    # The gate's launch_stem uses regex alternations: parse each re.search literal
    # "hier\|(?:alt1|alt2...)" and take the leading word of every alternative.
    for match in re.finditer(r"(\w[\w:]*)\\\|\(\?:([^)]*)", gate):
        hier = match.group(1)
        for alt in match.group(2).split("|"):
            stem = re.match(r"[\w]+", alt.strip())
            if stem:
                gate_stems.add((hier, stem.group(0)))
    if sdc_stems != gate_stems:
        only_sdc = sorted(sdc_stems - gate_stems)
        only_gate = sorted(gate_stems - sdc_stems)
        raise RuntimeError(
            "physical gate launch allow-list diverges from the SDC launch collector "
            f"(sdc-only={only_sdc}, gate-only={only_gate}) -- update revx_physical_gate.py "
            "launch_stem AND revx.sdc together before preparing")
    return sorted(sdc_stems)


def resume_asm(root, run_arg):
    """RESUME-ASM (2026-09-10): re-arm a finished attempt whose map/fit/sta/constraints
    artifacts exist but whose signoff gate rejected on a GATE-SIDE policy artifact
    (e.g. a launch-endpoint allow-list lag) -- never a timing miss.  Refreshes the
    attempt's pipeline scripts from the live tree (the fixed gate), re-pins them in
    ready.json, and sets the resume_asm marker.  The fit db and the frozen source
    snapshot are untouched: the next ticket re-runs ONLY signoff + quartus_asm."""
    root = root.resolve(strict=True)
    run = Path(run_arg).resolve(strict=True)
    rbf = run / f"output_files/{REV}/{REV}.rbf"
    if rbf.is_file():
        raise RuntimeError("RBF already assembled; nothing to resume")
    if (run / "receipts/resume.asm").exists():
        ready_now = json.loads((run / "ready.json").read_text(encoding="utf-8"))
        if ready_now.get("resume_asm"):
            print(run)  # already armed: idempotent pass-through
            return
        raise RuntimeError("attempt has a resume marker but ready.json lacks resume_asm")
    lines = [ln.split("\t") for ln in (run / "receipts/stages.tsv").read_text().splitlines()]
    done = {ln[1] for ln in lines if len(ln) >= 2}
    if not {"map", "fit", "sta", "constraints"} <= done:
        raise RuntimeError(f"resume-asm requires completed map/fit/sta/constraints; have {sorted(done)}")
    ready = json.loads((run / "ready.json").read_text(encoding="utf-8"))
    for relative in ("quartus/revx_physical_gate.py", "quartus/revx_build.py",
                     "quartus/revx_fifo_contract.py", "quartus/build_revx.sh",
                     "quartus/revx_sta.tcl", "quartus/revx_ce_contract.py"):
        source = inside(root, relative)
        destination = run / relative
        shutil.copyfile(source, destination)
        if sha(destination) != sha(source):
            raise RuntimeError(f"resume script changed during capture: {relative}")
        key = relative.replace("\\", "/")
        if key not in ready["inputs"]:
            raise RuntimeError(f"resume script not in prepared inputs: {relative}")
        ready["inputs"][key] = sha(destination)
    ready["resume_asm"] = True
    write_json(run / "ready.json", ready)
    for stale in ("receipts/fifo_owner_at_start.txt", "receipts/physical.status",
                  "receipts/physical.started"):
        try:
            (run / stale).unlink()
        except FileNotFoundError:
            pass
    (run / "receipts/resume.asm").write_text(now() + "\n", encoding="ascii")
    print(f"Resume-asm armed: {run}", file=sys.stderr)
    print(run)


def collect(run, code):
    run = run.resolve(strict=True)
    fifo_proof = collect_fifo(run, code)
    evidence = {}
    for dirname in ("logs", "reports", "receipts", "output_files"):
        for p in (run / dirname).rglob("*"):
            if p.is_file() and p.name != "result.json":
                evidence[p.relative_to(run).as_posix()] = sha(p)
    evidence.update(fifo_proof["files"])
    physical = run / "receipts/physical.status"
    finished = physical.read_text().strip().split("\t") if physical.exists() else []
    rbf = run / f"output_files/{REV}/{REV}.rbf"
    pass_gate = run / "receipts/signoff.json"
    gate_result = json.loads(pass_gate.read_text()).get("result") if pass_gate.is_file() else None
    accepted = (code == 0 and fifo_proof["result"] == "PASS" and finished[-2:] == ["complete", "0"] and rbf.is_file()
                and gate_result in ("PASS", "WAIVER"))
    verdict = ("WAIVER" if gate_result == "WAIVER" else "PASS") if accepted else "FAIL"
    result = {"schema": "revx-attempt/v1", "collected": now(), "fifo_exit": code,
              "physical_status": finished, "result": verdict,
              "qualification": ({"PASS": "engineering-artifact-cabinet-unmeasured",
                                 "WAIVER": "engineering-artifact-cabinet-waiver"}[verdict]
                                if accepted else "failed-physical-attempt"),
              "ready_sha256": sha(run / "ready.json"), "evidence_sha256": evidence,
              "fifo_evidence": "receipts/fifo_evidence.json",
              "rbf": str(rbf) if accepted else None}
    write_json(run / "receipts/result.json", result)
    print(f"Attempt {result['result']}: {run / 'receipts/result.json'}")
    if code == 0 and not accepted:
        raise RuntimeError("zero FIFO exit lacked complete gated physical artifact")


if __name__ == "__main__":
    try:
        command, root, *args = sys.argv[1:]
        if command == "prepare":
            if not args or len(set(args[1:])) != len(args[1:]) or set(args[1:]) - {"--strict", "--skip-simulation"}:
                raise RuntimeError("usage: revx_build.py prepare ROOT diag|production [--strict] [--skip-simulation]")
            prepare(Path(root), args[0], strict="--strict" in args[1:],
                    skip_simulation="--skip-simulation" in args[1:])
        elif command == "verify": verify(Path(root))
        elif command == "resume-asm": resume_asm(Path(root), args[0])
        elif command == "bind-owner": bind_owner(Path(root))
        elif command == "collect": collect(Path(root), int(args[0]))
        else: raise RuntimeError("unknown operation")
    except Exception as exc:
        print(f"REVX FAIL: {exc}", file=sys.stderr)
        sys.exit(2)
