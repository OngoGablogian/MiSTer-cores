#!/usr/bin/env bash
# prebuild_check.sh -- run BEFORE spending a ~25 min Quartus slot on a shared box.
#
# Every check here is a doomed build that actually happened on 2026-07-27 across the four
# sibling core sessions (NARC/Z, Wolf/Open Ice, T/MK2, Y/Smash T.V.). None of them were
# design problems; all were avoidable in under a minute. Cost that day: 8+ wasted fits.
#
# USAGE
#   tools/prebuild_check.sh <MACRO_SET> <OUTNAME> [--deliverable]
#   e.g. tools/prebuild_check.sh 'DIAG_BOOT,USE_DDR3_VRAM' Arcade-NARC-DDR3-v7p-freeze --deliverable
#
# EXIT 0 = go.  EXIT 1 = a check FAILED, do not burn the slot.  EXIT 2 = needs a human answer.
#
# PORTING TO A SIBLING TREE: only the CONFIG block below is repo-specific.
set -u
# A non-login Git Bash launched from PowerShell inherits a Windows-first PATH.
# Keep the fail-closed checklist runnable from the same shell used to launch
# the production build.
export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"

# ----------------------------- CONFIG (edit per repo) -----------------------------
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ELAB_CMD="bash quartus/build_sv2v.sh"          # cheap elaboration that runs the production guards
FIT_SUMMARY="output_files/Arcade-SmashTV.fit.summary"
FIT_RPT="output_files/Arcade-SmashTV.fit.rpt"
RELEASE_DIR="releases"
LOCK=/tmp/fpga_quartus.lock
AUDIT_LOGS="build_syn/hw_narc_sound_timing.log build_syn/hw_narc_vram_timing.log build_syn/hw_narc_frontier_timing.log build_syn/hw_narc_dq_timing.log"
# ----------------------------------------------------------------------------------

MACROS="${1:-}"; OUTNAME="${2:-}"; MODE="${3:-}"
cd "$ROOT" || exit 1
FAIL=0; ASK=0
ok()   { printf '  \033[32mPASS\033[0m  %s\n' "$1"; }
bad()  { printf '  \033[31mFAIL\033[0m  %s\n' "$1"; FAIL=1; }
ask()  { printf '  \033[33mASK \033[0m  %s\n' "$1"; ASK=1; }
hdr()  { printf '\n== %s ==\n' "$1"; }

[ -n "$MACROS" ] && [ -n "$OUTNAME" ] || { echo "usage: $0 <MACRO_SET> <OUTNAME> [--deliverable]"; exit 2; }

# =====================================================================================
hdr "A. IS THIS THE ARTIFACT ANYONE WANTS?"
# WOLF shipped RC/RC2/RC3/RC4 with OPEN_ICE=1 -- correct for debugging the rink, carried
# straight into the deliverable. Four fits produced an Open-Ice-only image that would have
# been handed over as a seven-game master. Nothing in any test suite can catch this,
# because the suite tests what you built.
# THE FAILURE IS NOT "wrong macro", IT IS: the config that is convenient to ITERATE on is
# not automatically the config the DELIVERABLE needs. Ask it every time; the answer is
# situation-specific (NARC's debug macro set IS its reference config, deliberately).
echo "  macros = $MACROS"
echo "  output = $OUTNAME"
if [ "$MODE" = "--deliverable" ]; then
  ask "DELIVERABLE build: confirm this macro set is what the OWNER needs, not what you iterate with."
  ask "Confirm any runtime PROFILE/game-select is the shipping one, not a hardwired debug default."
else
  ok "measurement build (not flagged --deliverable); macro set not owner-critical"
fi

# =====================================================================================
hdr "B. WILL IT EVEN ELABORATE? (production guards)"
# NARC v7p died at sv2v exit 1 after waiting out someone else's fit: a config change
# (D_WRITE_FIFO 1->0) left a production guard still pinning the OLD value. Same repo had
# already lost builds to two stale grep guards (hval_q, fbq_ingress_ready) and to a
# rom_read rename. The guards are RIGHT to fire -- but find out in 20 s, not after a slot.
if [ -n "$ELAB_CMD" ]; then
  EXTRA=""; for m in ${MACROS//,/ }; do EXTRA="$EXTRA -D$m"; done
  if SV2V_EXTRA="$EXTRA" $ELAB_CMD >/tmp/prebuild_elab.log 2>&1; then
    ok "elaboration + production guards pass with THIS macro set"
  else
    bad "elaboration FAILED -- a production guard likely still pins the pre-change config:"
    sed -n '$p' /tmp/prebuild_elab.log | sed 's/^/        /'
    grep -oE "grep -Fq .*|test .*" /tmp/prebuild_elab.log | tail -2 | sed 's/^/        /'
  fi
fi

if [[ "$OUTNAME" == Arcade-NARC* ]]; then
  if bash "$ROOT/sim/run_ascal_timing.sh" >/tmp/prebuild_ascal.log 2>&1; then
    ok "scaler timing retiming, equivalence, and mutation gates pass"
  else
    bad "scaler timing gate FAILED:"
    tail -8 /tmp/prebuild_ascal.log | sed 's/^/        /'
  fi
fi

# =====================================================================================
hdr "C. DID YOU BREAK A GATE'S COLLECTIONS? (fail-closed, but wastes the slot)"
# NARC v7m: the fix worked (-0.119 -> +0.656) and the build still died, because inserting a
# register removed ALL paths for a DIFFERENT audited boundary and the gate errored with
# "boundary has no paths". The consequence was anticipated for one boundary and not for the
# others launching from the same registers. A zero-path boundary is a WASTED FIT, every time.
if git diff --name-only HEAD~1 2>/dev/null | grep -qE '\.sv$|\.v$'; then
  if git diff HEAD~1 -- '*.sv' '*.v' 2>/dev/null | grep -qE '^\+.*\breg\b|^\+.*always_ff|^\+.*<='; then
    ask "RTL added registers since HEAD~1. Any audit boundary whose -from/-to now has ZERO paths?"
    ask "  -> cheapest proof: run the audit Tcl against the EXISTING fitted netlist first (~20 s)."
  else
    ok "no new sequential elements since HEAD~1"
  fi
else
  ok "no RTL change since HEAD~1"
fi

# =====================================================================================
hdr "D. ARE YOU FITTING TO FIND YOUR OWN REGRESSION?"
# NARC spent hours diagnosing two failing families (rcw_data 1239 paths, win_s_q 1343 paths)
# and publicly called one "structural, needs re-architecture". BOTH were fallout from a
# pipeline stage NARC had added days earlier. Reverting it removed both.
# BEFORE fitting a fix, ask git whether YOU introduced the thing you are fixing.
if [ -n "${FAILING_SIGNALS:-}" ]; then
  for s in $FAILING_SIGNALS; do
    C=$(git log --oneline -S"$s" -- '*.sv' 2>/dev/null | head -3)
    [ -n "$C" ] && { echo "    $s introduced/touched by:"; echo "$C" | sed 's/^/        /'; }
  done
  ask "If a listed commit is YOURS and recent, try REVERTING before fitting a new fix."
else
  ask "Set FAILING_SIGNALS='sig1 sig2' to auto-blame the failing endpoints against git history."
fi

# =====================================================================================
hdr "E. CAN YOU LEARN THIS WITHOUT A FIT? (fail-fast audits hide the rest)"
# THE BIGGEST TIME SINK OF THE DAY. audit_boundary errors on the FIRST failing boundary, so
# NINE OF ELEVEN boundaries had never been evaluated -- every fit revealed exactly one
# blocker and the next was invisible behind it. If a previous FIT SUCCEEDED (only a post-fit
# audit failed), its netlist is still valid: run the later audits directly with
# `quartus_sta -t <audit>.tcl`, ~20 s-2 min each, and learn ALL remaining blockers at once.
if [ -f "$FIT_SUMMARY" ] && grep -q "Fitter Status : Successful" "$FIT_SUMMARY" 2>/dev/null; then
  ask "A SUCCESSFUL fitted netlist exists ($(stat -c %y "$FIT_SUMMARY" | cut -d. -f1))."
  ask "  -> run the LATER audits on it first; do not rediscover blockers one fit at a time."
  ask "  -> SDC-only changes need NO refit: audits read_sdc at run time."
else
  ok "no reusable fitted netlist (a fit is genuinely required)"
fi

# =====================================================================================
hdr "F. ONE VARIABLE PER FIT"
# A `git reset --hard` silently restored SEED 3 after it had been set to 5, which would have
# made the next fit a two-variable change against the measured baseline.
SEED=$(grep -oE "^set_global_assignment -name SEED [0-9]+" ./*.qsf 2>/dev/null | grep -oE '[0-9]+$' | head -1)
echo "  SEED = ${SEED:-<default>}"
ask "Is exactly ONE thing different vs the last MEASURED baseline (RTL *or* SDC *or* seed)?"
if [ -n "$(git status --porcelain --untracked-files=no 2>/dev/null)" ]; then
  bad "worktree DIRTY -- the fitted artifact will not be reproducible from any commit:"
  git status --short --untracked-files=no | head -5 | sed 's/^/        /'
else
  ok "worktree clean; build is reproducible from $(git rev-parse --short HEAD 2>/dev/null)"
fi

# =====================================================================================
hdr "G. IS THE BOX ACTUALLY FREE? (process, not lock file)"
# Three sessions misattributed a Quartus process in one day, because THREE of the four trees
# build a revision literally named `Arcade-SmashTV` (inherited from a common donor). The
# command line carries ZERO ownership information. Orphaned workers outlive their locks, so
# an empty lock dir does NOT mean a free box -- and a live process does not mean a live build.
QP=$(ps -W 2>/dev/null | awk 'tolower($0) ~ /quartus_(map|fit|sta|asm|cdb)/ {print $4}' | tr '\n' ' ')
if [ -n "${QP// /}" ]; then
  bad "Quartus RUNNING (WINPIDs: $QP) -- identify the OWNER by PARENT process, never by name:"
  echo "        Get-CimInstance Win32_Process -Filter \"ProcessId=<parent>\" | Select CommandLine" | sed 's/^/    /'
else
  ok "no Quartus process running"
fi
if [ -d "$LOCK" ]; then
  bad "lock HELD by: $(sed -n 2p "$LOCK/owner" 2>/dev/null || echo unknown) (pid $(head -1 "$LOCK/owner" 2>/dev/null))"
else
  ok "lock free"
fi
ask "Verify LIVENESS by CPU-TIME DELTA, not existence -- a wedged fit looks identical to a working one."

# =====================================================================================
hdr "H. IS YOUR OWN AUTOMATION ABOUT TO FIRE?"
# Y-unit reported "stood down" while an orphaned waiter kept polling and took NARC's slot.
# NARC then disarmed an auto-sweep, VERIFIED nothing was armed, and it launched anyway --
# the old watcher had already evaluated before the replacement existed.
# A DISARM IS ITSELF A RACE. Check the RESOURCE, never the TRIGGER.
W=$(ps -W 2>/dev/null | grep -icE "quartus_lock|build_hw|seedsweep|queued_build" || true)
[ "$W" -gt 0 ] && bad "$W build/lock helper process(es) already alive -- one of yours may fire" \
                || ok "no build/lock helpers armed"
ask "Killing a task wrapper does NOT kill the tree beneath it. Confirm by PROCESS, not by harness."

# =====================================================================================
hdr "I. WILL YOU BE ABLE TO TRUST THE RESULT?"
# quartus_sta EXITS 0 WHEN TIMING FAILS -- it reports slack, it does not judge it. Wolf's
# flow emitted a fresh, correctly-hashed, provenance-clean RBF that failed timing at -0.031.
# NARC reported a build as "exit 0" that exited 3, because the pipeline's status masked it.
# And stale audit logs returned well-formed slack numbers for a build that never ran them.
grep -qE "quartus_sta[\"']? +-t |check_timing|assemble_gate" quartus/build_hw.sh 2>/dev/null \
  && ok "build JUDGES timing (Tcl audit / gate), not bare quartus_sta exit code" \
  || bad "build appears to rely on quartus_sta's exit code -- it exits 0 on a failing design"
grep -qE "PIPESTATUS|run_stage" quartus/build_hw.sh 2>/dev/null \
  && ok "stage exit codes captured without pipeline masking" \
  || bad "stage exits may be masked by a pipe -- capture \$? BEFORE any | tee/grep/tail"
if [ -f "$RELEASE_DIR/$OUTNAME.rbf" ]; then
  bad "an RBF for THIS name already exists -- delete it, or a failed build leaves a stale one"
  ls -la --time-style=full-iso "$RELEASE_DIR/$OUTNAME.rbf" | sed 's/^/        /'
else
  ok "no pre-existing RBF at the target name"
fi
for L in $AUDIT_LOGS; do
  [ -f "$L" ] && echo "    stale-log warning: $L is $(( ($(date +%s) - $(stat -c %Y "$L")) / 60 )) min old"
done
ask "After the build: compare RBF mtime to the FIT REPORT's, by DATE not clock time."

# =====================================================================================
hdr "J. RUNNING FROM AN IMMUTABLE SNAPSHOT?"
# Bash reads scripts INCREMENTALLY by byte offset. Editing one mid-run makes the running
# shell resume at the old offset in the new bytes -- mid-token. T-unit's corrupted control
# flow fell into a stale-lock breaker and destroyed WOLF's live lock. `bash -n` PASSES:
# it validates the file on disk, not the process already executing.
ask "Launch from a COPY (cp to /tmp) so an edit cannot reach the live run. Protection by construction."

# =====================================================================================
printf '\n===============================================================\n'
if [ "$FAIL" -ne 0 ]; then
  printf '  \033[31mDO NOT BUILD\033[0m -- a mechanical check failed above.\n'; printf '===============================================================\n'; exit 1
fi
if [ "$ASK" -ne 0 ]; then
  printf '  \033[33mANSWER THE ASK ITEMS\033[0m, then build. Mechanical checks passed.\n'
  printf '===============================================================\n'; exit 2
fi
printf '  \033[32mCLEAR TO BUILD\033[0m\n'; printf '===============================================================\n'; exit 0
