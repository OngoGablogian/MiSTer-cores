project_open Arcade-SmashTV -revision Arcade-SmashTV
# Slow 1100mV -40C corner is NARC's worst-setup corner (emu|pll divclk TNS -36.749)
create_timing_netlist -model slow -temperature -40 -voltage 1100
read_sdc
update_timing_netlist
puts "===== WORST SETUP PATHS (slow 1100mV -40C corner) ====="
report_timing -setup -npaths 25 -detail summary -stdout
puts "===== WORST SETUP PATH FULL DETAIL ====="
report_timing -setup -npaths 1 -detail full_path -stdout
project_close
