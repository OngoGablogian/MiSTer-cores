# Pure path-classification policy shared by report_narc_frontier.tcl and its
# non-Quartus unit test. Keep this file free of Quartus commands.

# NARC passes HQ2X=0. No negative path in the Hq2x hierarchy is acceptable:
# disabled logic must either optimize away or meet timing.
#
# The former Blend exception was invalid: df_rule -> i30 is genuinely
# single-cycle because Blend.clk_en is Hq2x.ce_in, Hq2x.ce_in is
# scandoubler.ce_x4i, and NARC's /6 pixel cadence gives ce_x4i a minimum gap of
# one clk_sys cycle.
#
# The former pattern-formation exception was invalid for the same reason.
# Prev/Curr/Next/cyc and nextpatt/pattern share `if(ce_in)`, but ce_in can assert
# on adjacent clk_sys edges. A shared enable is not a multicycle proof.
proc is_allowed_hq2x_residual {from_name to_name} {
  return 0
}

# ---------------------------------------------------------------------------
# ACCEPTANCE (NOT an exception). This class is deliberately separate from
# Hq2x because it does not meet a multicycle contract.
#
# The ascal path was checked rather than assumed:
#   - LATCH side has NO enable. o_div(0)/o_dir(0) are assigned at
#     sys/ascal.vhd:2547-2548 inside HSCAL:PROCESS(o_clk) (:2527), whose body is
#     a bare `IF rising_edge(o_clk)` (:2531). The sibling output-domain
#     processes OSWEEP and VSCAL do open with `IF o_ce='1'`.
#   - LAUNCH side changes every clock. o_hacc (Scalaire:PROCESS, :1864, also
#     ungated) steps unconditionally in WHEN sCOPY once o_dshi hits 0
#     (:2233-2244).
#   - The result is consumed: dir_v lands in o_hfrac(1) every cycle (:2610)
#     with o_copyv(0) asserted in the same state (:2249-2251).
#
# It remains a bounded acceptance because it is vendored cosmetic interpolation
# logic, the measured overshoot is 2.1% of a 6.732 ns period, and every observed
# instance is at Slow -40C or Slow 0C. If this class appears at 85C/100C it must
# reject.
proc is_accepted_vendored_ascal_cold_corner {from_name to_name label} {
  if {$label ne "Slow 1100mV -40C" && $label ne "Slow 1100mV 0C"} { return 0 }
  if {[string first "ascal:ascal|" $from_name] < 0
      || [string first "ascal:ascal|" $to_name] < 0} { return 0 }
  if {[string first {|o_hacc[} $from_name] < 0} { return 0 }
  return [expr {[string first {|o_div[} $to_name] >= 0
                || [string first {|o_dir[} $to_name] >= 0}]
}
