#!/usr/bin/env bash
# Fast, non-Quartus contract test for quartus/build_hw.sh.
#
# This exercises --check-config only. The DUT exits before sv2v, generated files,
# or any Quartus executable. The NARC production macro must enter as arg1 because
# that is the only channel build_hw.sh forwards to BOTH the sv2v blob and the
# Quartus-native Arcade-SmashTV.sv.
set -u
export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/quartus/build_hw.sh"
BUILD_ID_GEN="$ROOT/tools/generate_build_id.sh"
RUNBOOK="$ROOT/BUILD-RUNBOOK.md"
VRAM_AUDIT="$ROOT/quartus/report_narc_vram_timing.tcl"
DDR_RUNNER="$ROOT/sim/run_ddr3.sh"
BEAM_RUNNER="$ROOT/sim/run_beamerase.sh"
ASCAL_RUNNER="$ROOT/sim/run_ascal_timing.sh"
ASCAL_TEST="$ROOT/sim/test_ascal_timing.py"
HISCORE_TB="$ROOT/sim/tb_narc_hiscore_pipeline.sv"
T="${TMPDIR:-/tmp}/narc_build_contract.$$"
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT

fail() {
  echo "RESULT: FAIL -- $*" >&2
  exit 1
}

run_expect_rc() {
  local expect="$1" label="$2"
  shift 2
  set +e
  "$@" >"$T/$label.log" 2>&1
  local rc=$?
  set -e
  if [[ "$rc" -ne "$expect" ]]; then
    sed 's/^/  /' "$T/$label.log" >&2
    fail "$label returned $rc, expected $expect"
  fi
}

set -e

run_expect_rc 2 narc_no_macro \
  bash "$BUILD" - Arcade-NARC-config-probe --check-config
grep -Fq "arg1 does not define USE_DDR3_VRAM" "$T/narc_no_macro.log" \
  || fail "no-macro rejection did not name the arg1 contract"

run_expect_rc 0 narc_arg \
  bash "$BUILD" USE_DDR3_VRAM Arcade-NARC-config-probe --check-config
grep -Fq "CONFIG_OK output=Arcade-NARC-config-probe macro=USE_DDR3_VRAM" "$T/narc_arg.log" \
  || fail "canonical NARC argument form was not accepted"

run_expect_rc 0 narc_multi_arg \
  bash "$BUILD" DIAG_BOOT,USE_DDR3_VRAM Arcade-NARC-config-probe --check-config
grep -Fq "CONFIG_OK output=Arcade-NARC-config-probe macro=DIAG_BOOT USE_DDR3_VRAM" \
  "$T/narc_multi_arg.log" || fail "comma-separated NARC macro set was not accepted"

run_expect_rc 0 narc_sound_prodreset_arg \
  bash "$BUILD" DIAG_BOOT,DIAG_SOUND_PRODRESET,USE_DDR3_VRAM Arcade-NARC-config-probe --check-config
grep -Fq "CONFIG_OK output=Arcade-NARC-config-probe macro=DIAG_BOOT DIAG_SOUND_PRODRESET USE_DDR3_VRAM" \
  "$T/narc_sound_prodreset_arg.log" || fail "production-reset sound diagnostic macro set was not accepted"
grep -Fq '*" DIAG_SOUND_PRODRESET "*) export SV2V_EXTRA=' "$BUILD" \
  || fail "DIAG_SOUND_PRODRESET is not forwarded to the sv2v compilation channel"

run_expect_rc 2 narc_env_only \
  env SV2V_EXTRA=-DUSE_DDR3_VRAM bash "$BUILD" - Arcade-NARC-config-probe --check-config
grep -Fq "SV2V_EXTRA alone is insufficient" "$T/narc_env_only.log" \
  || fail "environment-only rejection did not name the split compilation channels"

run_expect_rc 0 donor_no_macro \
  bash "$BUILD" - Arcade-SmashTV-config-probe --check-config
grep -Fq "CONFIG_OK output=Arcade-SmashTV-config-probe macro=-" "$T/donor_no_macro.log" \
  || fail "donor no-macro configuration regressed"

grep -Fq "./tools/prebuild_check.sh USE_DDR3_VRAM Arcade-NARC-v7x" "$RUNBOOK" \
  || fail "runbook prebuild command does not carry the NARC production macro"
grep -Fq "./quartus/build_hw.sh USE_DDR3_VRAM Arcade-NARC-v7x" "$RUNBOOK" \
  || fail "runbook build command does not carry the NARC production macro"
if grep -Eq 'build_hw\.sh[[:space:]]+(-|""|'\'''\''|\$EMPTY)[[:space:]]+Arcade-NARC' "$RUNBOOK"; then
  fail "runbook contains a no-macro NARC build command"
fi

grep -Fq 'set bfill_pipe_data_regs [get_registers {' "$VRAM_AUDIT" \
  || fail "VRAM audit does not collect the registered refill boundary"
grep -Fq 'audit_to "snoop_merge_to_refill_pipeline" $bfill_pipe_data_regs' "$VRAM_AUDIT" \
  || fail "VRAM audit does not time the merge-to-refill-register half"
grep -Fq 'audit_boundary "refill_pipeline_to_row_cache_data" $bfill_pipe_data_regs $row_cache_data_regs' \
  "$VRAM_AUDIT" || fail "VRAM audit does not time the refill-register-to-BRAM half"
if grep -Fq 'audit_to "snoop_merge_to_row_cache_data" $row_cache_data_regs' "$VRAM_AUDIT"; then
  fail "VRAM audit still uses the stale one-hop refill boundary"
fi

grep -Fq -- '-Ptb_vram_ddr_bfill_red.DSB=1 -Ptb_vram_ddr_bfill_red.DWF=1' \
  "$DDR_RUNNER" || fail "B-fill runner does not gate the production DSB=1/DWF=1 tuple"
grep -Fq -- '-Ptb_vram_ddr_xdiff.DSB=1 -Ptb_vram_ddr_xdiff.DWF=1' \
  "$DDR_RUNNER" || fail "cross-diff runner does not gate the production DSB=1/DWF=1 tuple"
grep -Fq -- '-Ptb_vram_ddr_fbcombine.DSB=1 -Ptb_vram_ddr_fbcombine.DWF=1' \
  "$DDR_RUNNER" || fail "write-combine runner does not gate the production DSB=1/DWF=1 tuple"
grep -Fq "parameter bit DWF = 1'b1" "$HISCORE_TB" \
  || fail "high-score physical pipeline does not default to production FIFO-on"
grep -Fq '.D_WRITE_FIFO(DWF)' "$HISCORE_TB" \
  || fail "high-score physical pipeline does not drive the selected FIFO tuple"
grep -Fq -- '-Ptb_narc_hiscore_pipeline.DWF=0' "$DDR_RUNNER" \
  || fail "high-score runner does not execute the retired FIFO-off mutation"
grep -Fq 'RESULT: BLIT-BUDGET FAIL -- 15 of 15 blits' "$DDR_RUNNER" \
  || fail "high-score runner does not require the FIFO-off per-blit mutation to fail"
grep -Fq -- '-DMUT_A_FLUSH_LIVE_DECIDE' "$DDR_RUNNER" \
  || fail "DDR runner does not execute the v7v live-request flush mutation"
grep -Fq \
  'RESULT: PASS -- A dirty-beat conflict is decided after request registration and resumes only after flush.' \
  "$DDR_RUNNER" || fail "DDR runner does not require the registered A-flush mechanism to pass"
grep -Fq \
  'RESULT: FAIL -- A dirty-beat conflict bypassed or did not complete the registered flush path.' \
  "$DDR_RUNNER" || fail "DDR runner does not require the v7v A-flush mutation to fail"
grep -Fq 'T="${TMPDIR:-/tmp}/narc-beamerase.$$"' "$BEAM_RUNNER" \
  || fail "beam-erase runner does not isolate concurrent .vvp products"
grep -Fq "trap 'rm -rf \"\$T\"' EXIT" "$BEAM_RUNNER" \
  || fail "beam-erase runner does not clean its isolated temporary product"
grep -Fq -- '-DMUT_ERASE_NO_ARM_REPLAY' "$BEAM_RUNNER" \
  || fail "beam-erase runner does not execute the v11 arm-edge mutation"
grep -Fq 'P0045 FAIL arm row' "$BEAM_RUNNER" \
  || fail "beam-erase runner does not require the exact missed arm row"
grep -Fq 'bash "$ROOT/sim/run_ascal_timing.sh"' "$ROOT/tools/prebuild_check.sh" \
  || fail "prebuild does not run the scaler timing/equivalence gate"
grep -Fq -- '--mutation counter-live' "$ASCAL_RUNNER" \
  || fail "scaler runner does not execute the live-counter mutation"
grep -Fq -- '--mutation line-bypass' "$ASCAL_RUNNER" \
  || fail "scaler runner does not execute the line-buffer bypass mutation"
grep -Fq 'counter-live mutation restores the increment/compare/mux feedback cone' \
  "$ASCAL_TEST" || fail "scaler gate does not reject the live counter cone"
grep -Fq 'line-bypass mutation reconnects the split BRAM output directly to pixel selection' \
  "$ASCAL_TEST" || fail "scaler gate does not reject the BRAM bypass cone"

BUILD_ID_DATE=991231 bash "$BUILD_ID_GEN" "$T/build_id.v" >"$T/build_id.log"
grep -Fxq '`define BUILD_DATE "991231"' "$T/build_id.v" \
  || fail "clean-snapshot build-id generator emitted the wrong Verilog include"
run_expect_rc 2 build_id_bad \
  env BUILD_ID_DATE=bad bash "$BUILD_ID_GEN" "$T/build_id_bad.v"

echo "RESULT: PASS -- NARC requires arg1 USE_DDR3_VRAM; env-only is rejected; donor remains unchanged"
