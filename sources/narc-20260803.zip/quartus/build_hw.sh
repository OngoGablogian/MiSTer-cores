#!/usr/bin/env bash
# build_hw.sh — full HW build (sv2v -> quartus map/fit/sta/asm -> releases/<name>.rbf).
#   ./build_hw.sh [VERILOG_MACRO|-] [OUTNAME] [--resume-after-fit|--check-config]
# Multiple macros may be separated by commas as well as spaces.  The comma form
# is intentionally PowerShell/Git-Bash safe (native argument forwarding can
# otherwise split a quoted value before bash sees it).
# e.g.  ./build_hw.sh DIAG_SDRAM=1 Arcade-SmashTV_diag     (SDRAM loopback diagnostic)
#       ./build_hw.sh "" Arcade-SmashTV_stocksdram          (normal core -- SMASH TV DONOR ONLY)
#       ./build_hw.sh - Arcade-SmashTV_stocksdram           (same, PowerShell-safe)
#
# *** NARC IS NOT "NO MACRO". READ THIS BEFORE COPYING AN EXAMPLE ABOVE. ***
#       ./build_hw.sh USE_DDR3_VRAM Arcade-NARC-<name>      (NARC: the normal core)
# The two `""`/`-` examples are INHERITED FROM THE SMASH TV DONOR, where no macro really is the
# normal build. For NARC it is not: VRAM lives in HPS DDR3, and without USE_DDR3_VRAM the core
# builds the SDRAM VRAM path, stv_vram_ddr_top is never instantiated, and the narc_vram_timing
# audit rejects on SEVEN empty register collections -- AFTER the full ~21-minute fit. That
# happened on 2026-07-28 by copying the "(normal core)" example above. The guard below now
# refuses it in one second; this comment exists so the next reader does not need the guard.
set -e
# A non-login Git Bash launched from PowerShell inherits a Windows-first PATH.
# Put Git's POSIX tools first so dirname/bash/grep/tail resolve deterministically.
export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
QBIN=/c/intelFPGA_lite/17.0/quartus/bin64
REV=Arcade-SmashTV
MACRO="${1:-}"
MACRO="${MACRO//,/ }"
OUTNAME="${2:-Arcade-SmashTV}"
RESUME="${3:-}"
[ "$MACRO" = "-" ] && MACRO=""
# ---- GUARD: a NARC-named target REQUIRES the DDR3 VRAM path ---------------------------------
# 2026-07-28: a 21-minute fit was burned by launching `build_hw.sh - Arcade-NARC-v7u`, i.e. with NO
# macro. Without USE_DDR3_VRAM the core builds the SDRAM VRAM path, stv_vram_ddr_top is never
# instantiated, and SEVEN of the narc_vram_timing audit's register collections come back size 0
# ("NARC_VRAM_REJECT empty_collection=..."). The audit then fails for a reason that has nothing to
# do with timing, after the whole fit has been paid for.
# The macro must reach BOTH the sv2v blob (SV2V_EXTRA) and the Quartus-native Arcade-SmashTV.sv.
# Arg1 is the canonical interface: it is forwarded to both channels below. A pre-set
# SV2V_EXTRA reaches only the blob; accepting that alone can compile incompatible core/top port
# lists. Fail in one second instead of twenty-one minutes.
if [[ "$OUTNAME" == Arcade-NARC* ]]; then
  if [[ " $MACRO " != *" USE_DDR3_VRAM "* ]]; then
    echo "ERROR: $OUTNAME is a NARC target but arg1 does not define USE_DDR3_VRAM." >&2
    echo "       The NARC timing audits assume stv_vram_ddr_top; without the macro they measure" >&2
    echo "       an absent module and reject on empty collections after a full fit." >&2
    echo "       SV2V_EXTRA alone is insufficient: Arcade-SmashTV.sv is compiled directly by Quartus." >&2
    echo "       Correct: $0 USE_DDR3_VRAM $OUTNAME" >&2
    exit 2
  fi
fi

if [[ -n "$RESUME" && "$RESUME" != "--resume-after-fit" && "$RESUME" != "--check-config" ]]; then
  echo "ERROR: unsupported build mode: $RESUME" >&2
  exit 1
fi

# NARC's cabinet-proven direct-CAS SDRAM controller requires the independently
# fitted -4036 ps pin-clock phase. The inherited WIP Smash TV tree carries a
# -4557 ps dq_r experiment; compiling that phase with sdram_stock_shipped gives
# a real fast/-40C hold failure on every SDRAM_DQ lane. Fail before sv2v/Quartus
# instead of allowing a misleading *-p4036.rbf filename to hide the wrong PLL.
if [[ "$OUTNAME" == Arcade-NARC* ]]; then
  NARC_PLL="$ROOT/rtl/pll/pll_0002.v"
  if ! grep -Fq '.phase_shift1("-4036 ps")' "$NARC_PLL"; then
    echo "ERROR: NARC build requires pll outclk_1 phase_shift1 = -4036 ps: $NARC_PLL" >&2
    exit 1
  fi
  echo "NARC SDRAM phase guard: -4036 ps"
fi

# Non-destructive contract probe used by quartus/test_narc_build_contract.sh. This exits before
# sv2v, generated files, queue interaction, or any Quartus executable.
if [[ "$RESUME" == "--check-config" ]]; then
  echo "CONFIG_OK output=$OUTNAME macro=${MACRO:--}"
  exit 0
fi

# build_id.v is intentionally ignored because it carries the build date. The
# Quartus PRE_FLOW hook generates it only for `quartus_sh --flow compile`, while
# this controlled flow invokes quartus_map directly. Generate it explicitly so
# a clean clone or detached worktree is a complete build input.
bash "$ROOT/tools/generate_build_id.sh" "$ROOT/build_id.v"

# run_stage NAME LOGFILE -- CMD... : run a Quartus stage to its own log and ABORT on a real tool
# failure (non-zero exit). Previously each stage was `... | tee log | grep | tail`, whose pipe exit
# was tail's (always 0) -> a crashed/killed fitter was SILENTLY ignored and the STALE prior rbf got
# copied as if the build succeeded (bit an fp3fixdiag build 2026-07-09).
run_stage() {
  local name="$1" log="$2" rc; shift 2
  echo "=== $name ${MACRO:+(macro $MACRO)} ==="
  if "$@" > "$log" 2>&1; then
    :
  else
    rc=$?
    echo "!!! $name FAILED (exit $rc) -- tail of $log:"
    tail -20 "$log"
    exit "$rc"
  fi
  # This is display-only. A successful stage is allowed to have no lines that
  # match the compact summary filter (quartus_map is one such case).
  grep -iE "slack is|Was (successful|unsuccessful)|Error \(|NARC_(SOUND|VRAM|FRONTIER|DQ)" "$log" | tail -5 || true
}

export SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
# DIAG_BOOT also changes the sv2v'd zunit_top: it inserts the two-word physical
# SDRAM readback gate. Quartus-only --verilog_macro flags cannot reach the
# already-generated core blob, so forward this one macro explicitly.
case " $MACRO " in
  *" DIAG_BOOT "*) export SV2V_EXTRA="${SV2V_EXTRA:-} -DDIAG_BOOT" ;;
esac
# DIAG_SOUND_PRODRESET is the production-reset cabinet sound discriminator
# nested under DIAG_BOOT. It removes the diagnostic reset hold; the current cut
# adds only two read-only vector audits inside the existing sound stagger. The
# macro must reach the sv2v'd zunit_top as well as Arcade-SmashTV.sv.
case " $MACRO " in
  *" DIAG_SOUND_PRODRESET "*) export SV2V_EXTRA="${SV2V_EXTRA:-} -DDIAG_SOUND_PRODRESET" ;;
esac
# DIAG_ROMCHKSUM likewise changes the sv2v'd zunit_top (the U41/U23 sweep audit) --
# same "sv2v-only, Quartus can't reach the blob" reason as DIAG_BOOT above.
case " $MACRO " in
  *" DIAG_ROMCHKSUM "*) export SV2V_EXTRA="${SV2V_EXTRA:-} -DDIAG_ROMCHKSUM" ;;
esac
# USE_DDR3_VRAM moves VRAM/scanout to HPS DDR3 (SDRAM keeps CPU/gfx/prog/sound). It changes
# BOTH the sv2v'd core (zunit_top gains ddram_* ports, arb VRAM channel tied off) AND the
# emu (Arcade-SmashTV.sv wires DDRAM_* from the core). Forward to sv2v so the core blob's
# port list matches the emu's --verilog_macro view; without this the two disagree on ddram_*.
case " $MACRO " in
  *" USE_DDR3_VRAM "*) export SV2V_EXTRA="${SV2V_EXTRA:-} -DUSE_DDR3_VRAM" ;;
esac
cd "$ROOT"
MACROARG=()
# $MACRO may be several space-separated names (e.g. "DIAG_BOOT DIAG_SPLASHCAP") -> one
# --verilog_macro flag per name (Quartus does not accept a combined string).
for m in $MACRO; do MACROARG+=(--verilog_macro="$m"); done
if [[ "$RESUME" == "--resume-after-fit" ]]; then
  FIT_SUMMARY="$ROOT/output_files/$REV.fit.summary"
  MAP_REPORT="$ROOT/output_files/$REV.map.rpt"
  CORE_BLOB="$ROOT/build_syn/smashtv_core.v"
  if [[ "$OUTNAME" != Arcade-NARC* ||
        " $MACRO " != *" DIAG_BOOT "* ||
        " $MACRO " != *" USE_DDR3_VRAM "* ]]; then
    echo "ERROR: fit resume is restricted to a DIAG_BOOT+USE_DDR3_VRAM NARC build" >&2
    exit 1
  fi
  if [[ ! -f "$FIT_SUMMARY" || ! -f "$MAP_REPORT" || ! -f "$CORE_BLOB" ||
        ! "$FIT_SUMMARY" -nt "$MAP_REPORT" ||
        ! "$FIT_SUMMARY" -nt "$CORE_BLOB" ]]; then
    echo "ERROR: no fresh successful fitted NARC netlist is available to resume" >&2
    exit 1
  fi
  if ! grep -Fq "Fitter Status : Successful" "$FIT_SUMMARY"; then
    echo "ERROR: no fresh successful fitted NARC netlist is available to resume" >&2
    exit 1
  fi
  echo "=== resume: fresh successful NARC fitted netlist ==="
else
  echo "=== sv2v ==="
  bash "$ROOT/quartus/build_sv2v.sh"
  run_stage quartus_map build_syn/hw_map.log "$QBIN/quartus_map" $REV -c $REV "${MACROARG[@]}"
  run_stage quartus_fit build_syn/hw_fit.log "$QBIN/quartus_fit" $REV -c $REV
fi
if [[ "$OUTNAME" == Arcade-NARC* ]]; then
  # Quartus 17's default STA exit behavior is not stable enough to serve as the
  # NARC allowlist gate: v7d returned nonzero at "timing not met" before the
  # classifiers ran, while earlier Hq2x-negative fits returned zero.  These
  # stronger NARC Tcl audits create their own fitted timing netlists and
  # explicitly error on an empty collection, any
  # sound-ROM/deadline/audio-mixer boundary violation, a missing/violating DDR
  # shadow-response boundary, a missing DQ lane, or nonpositive DQ setup/hold at
  # any of the eight PVT conditions. The frontier audit classifies every global
  # setup violation at all eight corners. NARC disables HQ2x, so no negative
  # Hq2x path is accepted; disabled logic must optimize away or close. Do this before assembly/copy so a
  # timing-rejected image can never be published under the requested name.
  run_stage narc_sound_timing build_syn/hw_narc_sound_timing.log \
    "$QBIN/quartus_sta" -t "$ROOT/quartus/report_narc_sound_timing.tcl"
  run_stage narc_vram_timing build_syn/hw_narc_vram_timing.log \
    "$QBIN/quartus_sta" -t "$ROOT/quartus/report_narc_vram_timing.tcl"
  run_stage narc_frontier_timing build_syn/hw_narc_frontier_timing.log \
    "$QBIN/quartus_sta" -t "$ROOT/quartus/report_narc_frontier.tcl"
  run_stage narc_sdram_dq_timing build_syn/hw_narc_dq_timing.log \
    "$QBIN/quartus_sta" -t "$ROOT/quartus/report_narc_sdram_dq_input.tcl"
else
  run_stage quartus_sta build_syn/hw_sta.log "$QBIN/quartus_sta" $REV -c $REV
fi
run_stage quartus_asm build_syn/hw_asm.log "$QBIN/quartus_asm" $REV -c $REV

# only reached if every stage's tool exit was 0 (fitter actually produced a placed+routed design)
mkdir -p releases
cp -v "output_files/$REV.rbf" "releases/$OUTNAME.rbf"
echo "=== done: releases/$OUTNAME.rbf ==="
