// syn_yunit_core.sv — Phase-5 fit-risk harness (donor baseline).
// Measures the DONOR Y-unit datapath BRAM/M10K/DSP footprint the Z-unit replaces:
// yunit_memsys (yunit_mem + yunit_dma) + yunit_palram (video-side palette M10K).
// TMS34010 core omitted (identical in both units; cancels in the delta; see
// syn_zunit_core.sv). CPU memory interface exposed to top pins so the memsys RAMs
// are observable and retained. Resource-estimate harness only, NOT the emu.
`default_nettype none
module syn_yunit_core (
  input  logic        clk,
  input  logic        rst,
  input  logic        mem_req,
  input  logic        mem_we,
  input  logic [31:0] mem_addr,
  input  logic  [5:0] mem_size,
  input  logic [31:0] mem_wdata,
  output logic [31:0] mem_rdata,
  output logic        mem_ack,
  input  logic [63:0] inputs,
  input  logic  [7:0] src_data,
  output logic        src_req,
  output logic [23:0] src_addr,
  input  logic        src_ack,
  output logic  [7:0] snd_select,
  output logic        snd_trig,
  output logic        snd_reset,
  output logic        int1,
  output logic        blit_busy,
  input  logic        scan_req,
  input  logic [17:0] scan_addr,
  output logic [15:0] scan_data,
  output logic        scan_ack,
  output logic [24:0] vsd_addr,
  output logic [15:0] vsd_din,
  output logic  [1:0] vsd_be,
  output logic        vsd_rd,
  output logic        vsd_wr,
  input  logic [15:0] vsd_dout,
  input  logic        vsd_ack,
  output logic        cpu_gfx_rd,
  output logic [23:0] cpu_gfx_raddr,
  input  logic [15:0] cpu_gfx_rdata,
  input  logic        cpu_gfx_rack,
  input  logic [12:0] pal_raddr,
  output logic [15:0] pal_rdata
);
  logic        palv_we_a, palv_we_b;
  logic [12:0] palv_aa, palv_ba;
  logic [15:0] palv_awd, palv_bwd;
  logic        dbg_dma_we;
  logic  [3:0] dbg_dma_addr;
  logic [15:0] dbg_dma_wdata;

  yunit_memsys u_sys (
    .clk(clk), .rst(rst),
    .mem_req(mem_req), .mem_we(mem_we), .mem_addr(mem_addr), .mem_size(mem_size),
    .mem_wdata(mem_wdata), .mem_rdata(mem_rdata), .mem_ack(mem_ack),
    .src_req(src_req), .src_addr(src_addr), .src_data(src_data), .src_ack(src_ack),
    .inputs(inputs), .int1(int1),
    .snd_select(snd_select), .snd_trig(snd_trig), .snd_reset(snd_reset),
    .erase_start(1'b0), .erase_row0(9'd0), .erase_lines(10'd0), .erase_busy(),
    .blit_busy(blit_busy),
    .dbg_dma_we(dbg_dma_we), .dbg_dma_addr(dbg_dma_addr), .dbg_dma_wdata(dbg_dma_wdata),
    .cpu_gfx_rd(cpu_gfx_rd), .cpu_gfx_raddr(cpu_gfx_raddr),
    .cpu_gfx_rdata(cpu_gfx_rdata), .cpu_gfx_rack(cpu_gfx_rack),
    .scan_req(scan_req), .scan_addr(scan_addr), .scan_data(scan_data), .scan_ack(scan_ack),
    .vsd_addr(vsd_addr), .vsd_din(vsd_din), .vsd_be(vsd_be), .vsd_rd(vsd_rd), .vsd_wr(vsd_wr),
    .vsd_dout(vsd_dout), .vsd_ack(vsd_ack),
    .palv_we_a(palv_we_a), .palv_aa(palv_aa), .palv_awd(palv_awd),
    .palv_we_b(palv_we_b), .palv_ba(palv_ba), .palv_bwd(palv_bwd));

  yunit_palram #(.AW(13)) u_pal (
    .clk(clk), .rst(rst),
    .we_a(palv_we_a), .aa(palv_aa), .awd(palv_awd),
    .we_b(palv_we_b), .ba(palv_ba), .bwd(palv_bwd),
    .raddr(pal_raddr), .rdata(pal_rdata));
endmodule
`default_nettype wire
