#!/usr/bin/env bash
# build_sv2v_fit.sh — Phase-5 fit-risk measurement (WORKER hw_fit task).
#
#   (default | datapath)  sv2v the Z-unit datapath AND the donor Y-unit datapath
#                         it replaces, plus both thin synth tops -> build_syn/fit_core.v
#                         (quartus_map fit_zunit / fit_yunit estimate per top).
#   sound                 sv2v the NET-NEW dual-6809 narc_sound_board closure +
#                         the thin syn_sound_core top -> build_syn/fit_sound.v
#                         (quartus_map fit_sound estimates M10K/DSP; sound ROMs held
#                         EXTERNAL via top pins, hc55564 CVSD blackboxed — no BRAM
#                         inflation). Full jt51 (NOT the JT51_ONLYTIMERS shim).
#
# Resource-estimate harness only — nothing wired into emu.
set -e
export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"
SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TARGET="${1:-datapath}"
mkdir -p "$ROOT/build_syn"

if [ "$TARGET" = "sound" ]; then
  OUT="$ROOT/build_syn/fit_sound.v"
  SV=( "$ROOT/rtl/sound/narc_sound_pkg.sv" )
  # full jt51 (vendored YM2151, instantiated AS-IS — real HW cost, no ONLYTIMERS shim)
  while IFS= read -r f; do SV+=("$f"); done \
    < <(find "$ROOT/rtl/sound/jt51/hdl" -maxdepth 1 -name '*.v' | sort)
  # 6809 core (Verilog, shared master/slave)
  SV+=( "$ROOT/rtl/sound/williams_cvsd/mc6809is.v" )
  # hc55564 CVSD decoder BLACKBOXED (VHDL core externalized — no CVSD logic/RAM here)
  SV+=( "$ROOT/rtl/sound/sim/hc55564_stub.v" )
  # net-new board pieces
  SV+=( "$ROOT/rtl/sound/narc_sound_bank.sv" \
        "$ROOT/rtl/sound/narc_sound_latch.sv" \
        "$ROOT/rtl/sound/narc_sound_board.sv" )
  # thin synth top
  SV+=( "$ROOT/quartus/syn_sound_core.sv" )
  echo "sv2v[sound]: ${#SV[@]} SV/V files -> $OUT"
  "$SV2V" -DSYNTHESIS "${SV[@]}" > "$OUT"
  echo "  $(wc -l < "$OUT") lines"
  exit 0
fi

# ---- default: Z-unit vs donor Y-unit datapath ------------------------------
OUT="$ROOT/build_syn/fit_core.v"
SV=( "$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/zunit/zunit_pkg.sv" \
     "$ROOT/rtl/zunit/narc_fb_beat_fifo.sv" \
     "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SV+=("$f"); done \
  < <(find "$ROOT/rtl/tms34010/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
# donor Y-unit datapath closure
SV+=( "$ROOT/rtl/yunit/yunit_mem.sv" "$ROOT/rtl/yunit/yunit_dma.sv" \
      "$ROOT/rtl/yunit/yunit_memsys.sv" "$ROOT/rtl/yunit/yunit_palram.sv" )
# Z-unit datapath closure
SV+=( "$ROOT/rtl/zunit/zunit_mem.sv" "$ROOT/rtl/zunit/zunit_dma.sv" \
      "$ROOT/rtl/zunit/zunit_memsys.sv" "$ROOT/rtl/zunit/zunit_video.sv" )
# shared VRAM-in-SDRAM + DDR3 modules (active path = vram_sdram_top under USE_SDRAM_VRAM)
SV+=( "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
      "$ROOT/rtl/yunit/vram_sdram_scanout.sv" \
      "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" )
# thin synth tops
SV+=( "$ROOT/quartus/syn_zunit_core.sv" "$ROOT/quartus/syn_yunit_core.sv" )

echo "sv2v: ${#SV[@]} SV files -> $OUT"
"$SV2V" -DSYNTHESIS "${SV[@]}" > "$OUT"
echo "  $(wc -l < "$OUT") lines"
