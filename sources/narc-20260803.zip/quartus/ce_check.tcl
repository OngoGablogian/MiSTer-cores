# ce_check.tcl — multi-corner check: confirm NO failing path is on a CPU/overlay node.
project_open Arcade-SmashTV -revision Arcade-SmashTV
create_timing_netlist
set conds [get_available_operating_conditions]
foreach oc $conds {
  set_operating_conditions $oc
  create_timing_netlist
  read_sdc
  update_timing_netlist
  puts "==== corner $oc ===="
  foreach_in_collection pth [get_timing_paths -setup -npaths 2 -detail path_only] {
    puts "  setup slack=[get_path_info $pth -slack]  to=[get_node_info [get_path_info $pth -to] -name]"
  }
  foreach_in_collection pth [get_timing_paths -hold -npaths 1 -detail path_only] {
    puts "  hold  slack=[get_path_info $pth -slack]  to=[get_node_info [get_path_info $pth -to] -name]"
  }
}
project_close
