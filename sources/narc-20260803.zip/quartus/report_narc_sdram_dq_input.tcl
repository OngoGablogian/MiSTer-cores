# Enumerate every external SDRAM_DQ lane's setup and hold path at all eight
# Cyclone V operating conditions. A valid NARC p4036 fit produces 16 paths per
# check/corner and zero violations; this catches a mislabeled p4557 build that
# the whole-design setup frontier (normally Hq2x) does not expose.
project_open Arcade-SmashTV -revision Arcade-SmashTV

proc audit_dq {check label dq_ports dq_regs} {
  if {$check eq "setup"} {
    set paths [get_timing_paths -setup -from $dq_ports -to $dq_regs -npaths 16 -nworst 1]
  } else {
    set paths [get_timing_paths -hold -from $dq_ports -to $dq_regs -npaths 16 -nworst 1]
  }
  set n [get_collection_size $paths]
  if {$n != 16} {
    error "NARC DQ $label $check expected 16 lanes, found $n"
  }

  set worst 1.0e9
  foreach_in_collection path $paths {
    set slack [get_path_info -slack $path]
    if {$slack < $worst} {
      set worst $slack
    }
  }
  puts "NARC_DQ_AUDIT $label $check paths=$n worst=$worst"
  if {$worst <= 0.0} {
    error "NARC DQ $label $check violation: worst=$worst"
  }
}

foreach {model temp label} {
  slow 100  "Slow 1100mV 100C"
  slow -40  "Slow 1100mV -40C"
  slow 85   "Slow 1100mV 85C"
  slow 0    "Slow 1100mV 0C"
  fast -40  "Fast 1100mV -40C"
  fast 0    "Fast 1100mV 0C"
  fast 85   "Fast 1100mV 85C"
  fast 100  "Fast 1100mV 100C"
} {
  create_timing_netlist -model $model -temperature $temp -voltage 1100
  read_sdc
  update_timing_netlist

  set dq_ports [get_ports {SDRAM_DQ[*]}]
  set dq_regs  [get_registers {*sdram_stock_shipped:u_sdram|data[*]}]
  audit_dq setup $label $dq_ports $dq_regs
  puts "===== $label DQ SETUP (16 lanes) ====="
  report_timing -setup -from $dq_ports -to $dq_regs -npaths 16 -nworst 1 -detail summary -stdout
  audit_dq hold $label $dq_ports $dq_regs
  puts "===== $label DQ HOLD (16 lanes) ====="
  report_timing -hold -from $dq_ports -to $dq_regs -npaths 16 -nworst 1 -detail summary -stdout

  delete_timing_netlist
}

project_close
