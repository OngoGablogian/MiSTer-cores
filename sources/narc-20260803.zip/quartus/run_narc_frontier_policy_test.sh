#!/usr/bin/env bash
# Run the pure-Tcl frontier-policy gate and prove it kills the former broad
# Hq2x Blend exception. No Quartus project or timing netlist is opened.
set -u
export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEST="$ROOT/quartus/test_narc_frontier_policy.tcl"
TCLSH="${TCLSH:-}"

if [[ -z "$TCLSH" ]]; then
  for c in tclsh /c/intelFPGA_lite/17.0/quartus/bin64/tclsh.exe; do
    if command -v "$c" >/dev/null 2>&1; then
      TCLSH="$c"
      break
    fi
  done
fi
[[ -n "$TCLSH" ]] || { echo "RESULT: FAIL -- tclsh not found (set TCLSH)" >&2; exit 1; }

echo "== production policy =="
"$TCLSH" "$TEST" || exit 1

echo
echo "== broad-Blend mutant: MUST fail =="
set +e
MUT_OUT="$("$TCLSH" "$TEST" --mutant-blend 2>&1)"
MUT_RC=$?
set -e
printf '%s\n' "$MUT_OUT"
[[ "$MUT_RC" -ne 0 ]] || {
  echo "RESULT: FAIL -- broad-Blend mutant passed" >&2
  exit 1
}
printf '%s\n' "$MUT_OUT" | grep -Fq "FAIL Hq2x Blend df_rule-to-i30" || {
  echo "RESULT: FAIL -- mutant died for the wrong reason" >&2
  exit 1
}

echo
echo "RESULT: PASS -- production policy is green and the broad-Blend mutant is killed"
