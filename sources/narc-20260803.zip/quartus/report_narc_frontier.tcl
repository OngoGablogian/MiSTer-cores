# Fail-closed whole-design timing classifier for NARC production fits.
#
# Quartus' normal STA exits zero even when timing is violated. Inspect every
# negative setup endpoint (not merely the worst 25) at all eight PVT conditions.
# NARC passes HQ2X=0, so every negative Hq2x path rejects: disabled logic must
# optimize away or meet timing. The only bounded acceptance is the independently
# characterized vendored ascal class at its two documented cold corners.
# Require globally positive hold.
source [file join [file dirname [info script]] narc_frontier_policy.tcl]

project_open Arcade-SmashTV -revision Arcade-SmashTV

set MAX_VIOLATED_PATHS 100000
set any_failed 0

foreach {model temp label} {
  slow 100  "Slow 1100mV 100C"
  slow -40  "Slow 1100mV -40C"
  slow 85   "Slow 1100mV 85C"
  slow 0    "Slow 1100mV 0C"
  fast -40  "Fast 1100mV -40C"
  fast 0    "Fast 1100mV 0C"
  fast 85   "Fast 1100mV 85C"
  fast 100  "Fast 1100mV 100C"
} {
  create_timing_netlist -model $model -temperature $temp -voltage 1100
  read_sdc
  update_timing_netlist

  set worst_setup_paths [get_timing_paths -setup -npaths 1]
  if {[get_collection_size $worst_setup_paths] != 1} {
    error "NARC frontier $label has no global setup path"
  }
  set worst_setup 1.0e9
  foreach_in_collection path $worst_setup_paths {
    set worst_setup [get_path_info -slack $path]
  }

  set violated [get_timing_paths -setup -less_than_slack 0.0 -npaths $MAX_VIOLATED_PATHS]
  set violated_n [get_collection_size $violated]
  if {$violated_n >= $MAX_VIOLATED_PATHS} {
    error "NARC frontier $label reached the $MAX_VIOLATED_PATHS-path audit limit"
  }

  set allowed_n 0
  set accepted_ascal_n 0
  set rejected_n 0
  foreach_in_collection path $violated {
    set slack [get_path_info -slack $path]
    set from_name [get_node_info -name [get_path_info $path -from]]
    set to_name [get_node_info -name [get_path_info $path -to]]
    if {[is_allowed_hq2x_residual $from_name $to_name]} {
      incr allowed_n
    } elseif {[is_accepted_vendored_ascal_cold_corner $from_name $to_name $label]} {
      # counted and PRINTED separately -- an acceptance must stay visible in
      # every report, not vanish into an "allowed" tally.
      incr accepted_ascal_n
      puts "NARC_FRONTIER_ACCEPTED_ASCAL $label slack=$slack from=$from_name to=$to_name"
    } else {
      incr rejected_n
      puts "NARC_FRONTIER_REJECT $label slack=$slack from=$from_name to=$to_name"
    }
  }
  puts "NARC_FRONTIER_SETUP $label worst=$worst_setup violated=$violated_n allowed_hq2x=$allowed_n accepted_ascal=$accepted_ascal_n rejected=$rejected_n"
  report_timing -setup -npaths 25 -detail summary -stdout
  if {$rejected_n != 0} {
    set any_failed 1
    puts "NARC_FRONTIER_CORNER_FAIL $label reason=unaccepted_setup count=$rejected_n"
  }

  set worst_hold_paths [get_timing_paths -hold -npaths 1]
  if {[get_collection_size $worst_hold_paths] != 1} {
    error "NARC frontier $label has no global hold path"
  }
  set worst_hold 1.0e9
  set hold_from ""
  set hold_to ""
  foreach_in_collection path $worst_hold_paths {
    set worst_hold [get_path_info -slack $path]
    set hold_from [get_node_info -name [get_path_info $path -from]]
    set hold_to [get_node_info -name [get_path_info $path -to]]
  }
  puts "NARC_FRONTIER_HOLD $label worst=$worst_hold from=$hold_from to=$hold_to"
  report_timing -hold -npaths 1 -detail summary -stdout
  if {$worst_hold <= 0.0} {
    set any_failed 1
    puts "NARC_FRONTIER_CORNER_FAIL $label reason=nonpositive_hold slack=$worst_hold"
  }

  delete_timing_netlist
}

if {$any_failed} {
  error "NARC frontier audit failed one or more PVT conditions"
}

project_close
