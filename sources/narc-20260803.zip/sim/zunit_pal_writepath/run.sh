#!/usr/bin/env bash
# Palette WRITE-PATH gate (iverilog, no licence). See tb header.
#   base       : frozen rtl -> expected FAIL until the bit-12 tap fold is removed
#   unfoldmut  : tap fold removed (palv_aa/palv_ba carry all 13 bits) -> expected PASS
# The frozen rtl is NEVER modified; the variant is a throwaway copy in build/.
set -e
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
export PATH="/c/iverilog/bin:$PATH"
DIR="$ROOT/sim/zunit_pal_writepath"
PKG="$ROOT/rtl/zunit/zunit_pkg.sv"
MEM="$ROOT/rtl/zunit/zunit_mem.sv"
VID="$ROOT/rtl/zunit/zunit_video.sv"
PALQ="$ROOT/rtl/zunit/narc_pal_wr_queue.sv"
TB="$DIR/tb_zunit_pal_writepath.sv"
BUILD="$DIR/build"
mkdir -p "$BUILD"

UNFOLD="$BUILD/zunit_mem_unfold.sv"
python - "$MEM" "$UNFOLD" <<'PY'
import sys
src, out = sys.argv[1], sys.argv[2]
txt = open(src, encoding="utf-8").read()
a = "palv_we_a <= pal_awe;  palv_aa <= {1'b0, pal_aa[11:0]};  palv_awd <= pal_awd;\n    palv_we_b <= pal_bwe;  palv_ba <= {1'b0, pal_ba[11:0]};  palv_bwd <= pal_bwd;"
b = "palv_we_a <= pal_awe;  palv_aa <= pal_aa;  palv_awd <= pal_awd;\n    palv_we_b <= pal_bwe;  palv_ba <= pal_ba;  palv_bwd <= pal_bwd;"
assert txt.count(a) == 1, f"anchor count {txt.count(a)}"
open(out, "w", encoding="utf-8").write(txt.replace(a, b))
print("unfold variant generated")
PY

build_run () {  # $1=label $2=memfile
  local out="$BUILD/tb_$1.vvp"
  echo "=== $1 ==="
  iverilog -g2012 -DUSE_HW_RAM -s tb_zunit_pal_writepath -o "$out" "$PKG" "$2" "$VID" "$PALQ" "$TB"
  ( cd "$DIR" && vvp "$out" )
}

BASE_LOG="$(build_run base   "$MEM")";    echo "$BASE_LOG"
UNF_LOG="$(build_run unfold  "$UNFOLD")"; echo "$UNF_LOG"

echo
echo "================= ACCEPTANCE ================="
echo "$BASE_LOG" | grep -E "CASE A|CASE B|RESULT" || true
echo "---"
echo "$UNF_LOG"  | grep -E "CASE A|CASE B|RESULT" || true
