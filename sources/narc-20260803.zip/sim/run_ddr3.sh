#!/usr/bin/env bash
# run_ddr3.sh — VRAM->DDR3 iverilog gates (no license needed). Both expect "RESULT: PASS".
#   P0 loopback : agent + FAITHFUL f2sdram oracle, 9 assertions + mutation coverage.
#   P1 xdiff    : DDR3 VRAM subsystem bit-exact vs the proven SDRAM-backed vram_sdram_top.
#   ./run_ddr3.sh
set -e
# Keep the regression runnable from PowerShell's non-login Git Bash, whose
# inherited Windows-first PATH otherwise omits dirname/grep/sort.
export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
T="${TMPDIR:-/tmp}"
PY="${PYTHON:-python}"

echo "== P0 loopback =="
iverilog -g2012 -o "$T/tb_vram_ddr.vvp" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_vram_ddr_loopback.sv"
vvp "$T/tb_vram_ddr.vvp" | grep -iE "RESULT|\[tb\]|main model"

echo "== P1 cross-diff (DDR3 vs SDRAM golden) =="
iverilog -g2012 -o "$T/tb_vram_ddr_xdiff.vvp" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/sim/sdram_model.sv" "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_vram_ddr_xdiff.sv"
vvp "$T/tb_vram_ddr_xdiff.vvp" | grep -iE "RESULT|MISMATCH|FAIL"

echo "== A-lane registered dirty-beat flush: ordering + timing-boundary mechanism =="
AFLUSH_SRC=("$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_vram_ddr_acost.sv")
iverilog -g2012 -s tb_vram_ddr_acost -o "$T/tb_vram_ddr_acost.vvp" "${AFLUSH_SRC[@]}"
AFLUSH_OUT="$(vvp "$T/tb_vram_ddr_acost.vvp")"
printf '%s\n' "$AFLUSH_OUT" | grep -iE "flush mechanism|RESULT"
printf '%s\n' "$AFLUSH_OUT" | grep -Fq \
  "RESULT: PASS -- A dirty-beat conflict is decided after request registration and resumes only after flush."

echo "== A-lane live-request flush MUTATION: mechanism gate MUST fail =="
iverilog -g2012 -DMUT_A_FLUSH_LIVE_DECIDE -s tb_vram_ddr_acost \
  -o "$T/tb_vram_ddr_acost_live.vvp" "${AFLUSH_SRC[@]}"
AFLUSH_LIVE_OUT="$(vvp "$T/tb_vram_ddr_acost_live.vvp")"
printf '%s\n' "$AFLUSH_LIVE_OUT" | grep -iE "flush mechanism|RESULT"
printf '%s\n' "$AFLUSH_LIVE_OUT" | grep -Fq \
  "RESULT: FAIL -- A dirty-beat conflict bypassed or did not complete the registered flush path."

echo "== B-fill D coherence: D writes while B fills a new scan row (RECOVERED from donor) =="
# v7k: NARC's fork had LOST sim/tb_vram_ddr_bfill_red.sv entirely. The property --
# D-write coherence while B fills a new scan row -- was shipping UNVERIFIED here
# while being verified in the donor. RUNG-3 drift running the other way, and
# invisible because I was grepping tb_vram_bsnoop.sv: different bench, different
# property, and the failure string does not appear there at all.
# It discriminates properly, unlike the generic FAIL C2 my tb_vram_bsnoop arming
# produced: -DMUT_BFILL_NOLOCK yields THREE NAMED mechanism REDs (A cache-vs-DDR,
# B row-tag write-through, C early-ACK) rather than one undifferentiated failure.
# Its own TEST-INVALID path is the model to copy elsewhere: on a missing
# precondition it neither passes nor fails silently, it declares itself ungraded.
BFILL_SRC=("$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" "$ROOT/sim/tb_vram_ddr_bfill_red.sv")
iverilog -g2012 -s tb_vram_ddr_bfill_red -o "$T/tb_bfill.vvp" "${BFILL_SRC[@]}"
BFILL_OUT="$(vvp "$T/tb_bfill.vvp")"
printf '%s\n' "$BFILL_OUT" | grep -iE "RESULT|RED|INVALID"
printf '%s\n' "$BFILL_OUT" | grep -Fq "RESULT: PASS -- B-fill D coherence"

echo "== B-fill row-lock MUTATION: MUT_BFILL_NOLOCK MUST fail =="
iverilog -g2012 -DMUT_BFILL_NOLOCK -s tb_vram_ddr_bfill_red \
  -o "$T/tb_bfill_mut.vvp" "${BFILL_SRC[@]}"
BFILL_MUT_OUT="$(vvp "$T/tb_bfill_mut.vvp")"
printf '%s\n' "$BFILL_MUT_OUT" | grep -iE "RESULT|RED|INVALID"
printf '%s\n' "$BFILL_MUT_OUT" | grep -Fq "RESULT: FAIL -- B-fill D coherence"

echo "== B-fill D coherence in retired FIFO-off config (DSB=1, DWF=0) =="
iverilog -g2012 -s tb_vram_ddr_bfill_red \
  -Ptb_vram_ddr_bfill_red.DSB=1 -Ptb_vram_ddr_bfill_red.DWF=0 \
  -o "$T/tb_bfill_prod.vvp" "${BFILL_SRC[@]}"
BFILL_PROD_OUT="$(vvp "$T/tb_bfill_prod.vvp")"
printf '%s\n' "$BFILL_PROD_OUT" | grep -iE "RESULT|RED|INVALID"
printf '%s\n' "$BFILL_PROD_OUT" | grep -Fq "RESULT: PASS -- B-fill D coherence"

echo "== B-fill D coherence in NARC's PRODUCTION config (DSB=1, DWF=1) =="
# v7l 2026-07-27: the arms above originally proved only the DONOR config. The
# production arm used to be impossible to run -- the bench reported
#     [B-FILL A] TEST-INVALID: A/D prework not present before miss wb/d=1/0
# and the property went unverified in that configuration for the whole v7 series.
# Root cause was THREE BENCH defects, not RTL. All three were invisible in the donor:
#   1. blit_px dropped the write outright. With D_WRITE_FIFO=1, fb_ack is
#      skd_ingress_ready (stv_vram_ddr_top.sv:1229) and is COMBINATIONALLY high at the
#      negedge fb_we is raised, so `while(!fb_ack)` never ran its body and `fb_we=0`
#      executed in the SAME delta -- a zero-width pulse no posedge ever sampled, so
#      skd_push (:1230) never fired. Fixed with a do-while that always crosses an edge
#      with fb_we HELD, which is what the RTL itself assumes (:1489-1492, "the dma holds
#      addr/data until ack"). The donor's d_fb_ack is not combinationally ready, which is
#      the only reason the bug never showed there.
#   2. fb_ack_count counted the READY LEVEL (288 acks for 4 writes under DWF).
#      `fb_we && fb_ack` is ALSO wrong -- it drops the 3 PARKED requests the donor acks
#      after fb_we falls (measured 10-vs-13). Now counts the DUT own `accept` event
#      (:1493, "one ack per request"), which is correct in BOTH configs.
#   3. park_seen watched b_fill_lock, which is the park mechanism ONLY when DWF=0
#      (fb_fill_park = D_WRITE_FIFO ? fb_fill_park_fifo : b_fill_lock, :1344).
# MECHANISM WITNESSES ADAPTED, NOT DROPPED. park_seen / accept_during_lock / "never
# enters B_DRAIN" describe the donor blanket-park barrier. The FIFO path deliberately
# overlaps by row (fb_fill_park_fifo = b_fill_active && fb_req && fb_beat[15:7]==fill_row,
# :1338), so those three legitimately do not hold. They are REPLACED by the invariant
# that actually carries coherence and is checkable in both configs: a D write to the row
# being filled is NEVER accepted during the fill (accept_samerow_in_fill == 0).
# MEASURED under DWF=1 and reported, not asserted: park_seen=0, B_DRAIN 67 cycles of
# which 29 fall inside the fill. The 29 contradict the BSNOOP "fill never blocks in
# B_DRAIN" claim -- PERFORMANCE-relevant, NOT a coherence defect (all four data checks
# pass). Left as a reported metric so a regression stays visible without asserting a
# bound that has never been justified.
#
# WARNING -- WHAT THIS ARM STILL DOES NOT PROVE. DO NOT DELETE.
#   - Case A does not EXERCISE the snoop race in the FIFO-on config. Measured by forcing
#     the merge to garbage (bsn_lane = 16'hDEAD): case B goes RED in both configs, but
#     case A still PASSES at DSB=1/DWF=1 with original=a000 rescan=a000 DDR=a000 -- the D
#     write reaches DDR before the fill reads it, so the overlay is not load-bearing
#     there. A stale-base mutant survives for the same reason. Case B is the only arm
#     whose assertion discriminates the merge. To genuinely close this, case A needs the
#     D write held IN FLIGHT (unflushed) across the fill under DWF=1.
#   - MUT_BFILL_NOLOCK kills here (errors=1) only via the near-tautological
#     lock_seen/invalidate_seen witness -- 0 named data REDs, versus 3 in the donor.
#   - DSB=0 DWF=1 still FAILS (2). That combination is not production, so it is
#     recorded rather than gated.
iverilog -g2012 -s tb_vram_ddr_bfill_red \
  -Ptb_vram_ddr_bfill_red.DSB=1 -Ptb_vram_ddr_bfill_red.DWF=1 \
  -o "$T/tb_bfill_fifo.vvp" "${BFILL_SRC[@]}"
BFILL_FIFO_OUT="$(vvp "$T/tb_bfill_fifo.vvp")"
printf '%s\n' "$BFILL_FIFO_OUT" | grep -iE "RESULT|RED|INVALID|FIFO-MECH"
printf '%s\n' "$BFILL_FIFO_OUT" | grep -Fq "RESULT: PASS -- B-fill D coherence"

echo "== P1b cross-diff in retired FIFO-off config (DSB=1, DWF=0) =="
# v7h: the P1 arm above instantiates stv_vram_ddr_top at DEFAULTS -- the DONOR
# configuration. NARC production uses D_SHADOW_RMW_BYPASS=1 + D_WRITE_FIFO=1
# (rtl/zunit/zunit_mem.sv:874-877), so for the entire v7 series the ONLY
# bit-exact oracle we had was proving a build we do not ship.
# MEASURED 2026-07-27, isolated by parameter:
#     DSB=0 DWF=0 (donor)      PASS
#     DSB=0 DWF=1 (FIFO only)  PASS   <- the new write FIFO is clean
#     DSB=1 DWF=0              FAIL 5 mismatches
#     DSB=1 DWF=1 (production)  FAIL 4 mismatches
# RESOLVED 2026-07-27 (v7i). The "shadow RMW bypass drops lanes" reading of those
# numbers was WRONG, and the RTL needed no change. Root cause was a HARNESS
# quiescence gap in fb_write()'s drain loop (sim/tb_vram_ddr_xdiff.sv:153):
# D_SHADOW_RMW_BYPASS also enables DPARTBURST (stv_vram_ddr_top.sv:1157), which
# makes D_MRG append the merged beat to the run buffer rb instead of writing it
# straight to DDR. The drain waited on wc_mask/dst/fbq_empty but not rb_cnt, so
# it exited while the correct merged beat was still in rb_data[] and chk_entry
# peeked u_ddrm.mem[] mid-flight. Every real consumer IS rb-coherent (A is
# admitted only on !d_busy :1715, B merges rb_data :1411-1422, C is gated on
# !d_busy :1734) -- only the TB's raw backing-store peek was not.
# The fix completes the drain with rb_cnt, making it a strict superset of the
# DUT's own d_busy/fb_busy predicate (:1171-1178). All four arms now PASS.
# Anti-weakening (measured): with the completed drain, injecting a zeroed shadow
# merge base at :1341 -> FAIL 27; injecting a real lane drop into the rb append
# at :1360 -> FAIL 16. The oracle still kills the failure class it was reporting.
# Still true and still load-bearing: do NOT "fix" any future RED here by
# disabling the bypass. DSB=0 regresses the blit budget to 13/15 over, worst
# 3.15x, which reinstates the cabinet slideshow.
iverilog -g2012 -s tb_vram_ddr_xdiff \
  -Ptb_vram_ddr_xdiff.DSB=1 -Ptb_vram_ddr_xdiff.DWF=0 \
  -o "$T/tb_vram_ddr_xdiff_prod.vvp" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/sim/sdram_model.sv" "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_vram_ddr_xdiff.sv"
vvp "$T/tb_vram_ddr_xdiff_prod.vvp" | grep -iE "RESULT|MISMATCH|FAIL"
vvp "$T/tb_vram_ddr_xdiff_prod.vvp" | grep -Fq \
  "RESULT: PASS -- DDR3 VRAM subsystem bit-exact vs SDRAM golden (CPU RMW + fb + autoerase, 4:1 packing)."

echo "== P1c cross-diff in NARC's PRODUCTION config (DSB=1, DWF=1) =="
iverilog -g2012 -s tb_vram_ddr_xdiff \
  -Ptb_vram_ddr_xdiff.DSB=1 -Ptb_vram_ddr_xdiff.DWF=1 \
  -o "$T/tb_vram_ddr_xdiff_fifo.vvp" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/sim/sdram_model.sv" "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_vram_ddr_xdiff.sv"
vvp "$T/tb_vram_ddr_xdiff_fifo.vvp" | grep -iE "RESULT|MISMATCH|FAIL"
vvp "$T/tb_vram_ddr_xdiff_fifo.vvp" | grep -Fq \
  "RESULT: PASS -- DDR3 VRAM subsystem bit-exact vs SDRAM golden (CPU RMW + fb + autoerase, 4:1 packing)."

echo "== BSNOOP bounded/coherent scanout fill under a sustained framebuffer stream =="
BSNOOP_SRC=("$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_vram_bsnoop.sv")
iverilog -g2012 -s tb_vram_bsnoop -o "$T/tb_vram_bsnoop.vvp" "${BSNOOP_SRC[@]}"
BSNOOP_OUT="$(vvp "$T/tb_vram_bsnoop.vvp")"
printf '%s\n' "$BSNOOP_OUT" | grep -iE "C1 miss|RESULT|FAIL"
printf '%s\n' "$BSNOOP_OUT" | grep -Fq \
  "RESULT: PASS -- BSNOOP bounded fill + in-flight coherency."

echo "== NARC FIFO BSNOOP: bounded miss, cached-row drain and same-edge miss/write =="
iverilog -g2012 -s tb_vram_bsnoop \
  -Ptb_vram_bsnoop.DWF=1 -Ptb_vram_bsnoop.PUB_DELAY=512 \
  -o "$T/tb_vram_bsnoop_fifo.vvp" "${BSNOOP_SRC[@]}"
BSNOOP_FIFO_OUT="$(vvp "$T/tb_vram_bsnoop_fifo.vvp")"
printf '%s\n' "$BSNOOP_FIFO_OUT" | grep -iE "C1 miss|C3 FIFO|C4 FIFO|RESULT|FAIL"
printf '%s\n' "$BSNOOP_FIFO_OUT" | grep -Fq \
  "OK  C3 FIFO cached-row hit drain: a207"
printf '%s\n' "$BSNOOP_FIFO_OUT" | grep -Fq \
  "OK  C4 FIFO same-edge miss+push: a300"
printf '%s\n' "$BSNOOP_FIFO_OUT" | grep -Fq \
  "RESULT: PASS -- BSNOOP bounded fill + in-flight coherency."

echo "== NARC shadow generation: second POR invalidates/refills; donor valid map clears =="
iverilog -g2012 -s tb_narc_ddr3_shadow_por \
  -o "$T/tb_narc_ddr3_shadow_por.vvp" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_narc_ddr3_shadow_por.sv"
SHADOW_POR_OUT="$(vvp "$T/tb_narc_ddr3_shadow_por.vvp")"
printf '%s\n' "$SHADOW_POR_OUT" | grep -iE "RESULT|FAIL"
printf '%s\n' "$SHADOW_POR_OUT" | grep -Fq \
  "RESULT: PASS -- generation-tag shadow invalidates on second POR, refills, and FIFO-off legacy bulk-clear remains"

echo "== BSNOOP old-wait MUTATION: B_DRAIN/proof mechanisms MUST fail =="
iverilog -g2012 -DMUT_NO_BSNOOP -s tb_vram_bsnoop \
  -o "$T/tb_vram_bsnoop_old.vvp" "${BSNOOP_SRC[@]}"
BSNOOP_OLD_OUT="$(vvp "$T/tb_vram_bsnoop_old.vvp")"
printf '%s\n' "$BSNOOP_OLD_OUT" | grep -iE "B_DRAIN|proof poll|RESULT"
# MEASURED 2026-07-27 on the FIFO/generation-tag tree: this mutant still kills
# BOTH mechanism monitors ("B_DRAIN entered" AND "B issued a publication proof
# poll").  A timeout-tolerant form was briefly introduced here; it was reverted
# because it is unnecessary and strictly weaker -- accepting a bare timeout as
# an alternative death would let a future change that merely HANGS scanout pass
# as though it had reproduced the specific old-wait mechanisms.  Require both.
printf '%s\n' "$BSNOOP_OLD_OUT" | grep -Fq "FAIL C1 mechanism: B_DRAIN entered"
printf '%s\n' "$BSNOOP_OLD_OUT" | grep -Fq \
  "FAIL C1 mechanism: B issued a publication proof poll"

echo "== BSNOOP no-merge MUTATION: in-flight sprite pixels MUST fail =="
iverilog -g2012 -DMUT_NO_BMERGE -s tb_vram_bsnoop \
  -o "$T/tb_vram_bsnoop_nomerge.vvp" "${BSNOOP_SRC[@]}"
BSNOOP_NOMERGE_OUT="$(vvp "$T/tb_vram_bsnoop_nomerge.vvp")"
printf '%s\n' "$BSNOOP_NOMERGE_OUT" | grep -iE "FAIL C2|RESULT"
printf '%s\n' "$BSNOOP_NOMERGE_OUT" | grep -Fq \
  "FAIL C2 col0 (in-flight full beat): got=b000 exp=a100"
printf '%s\n' "$BSNOOP_NOMERGE_OUT" | grep -Fq \
  "FAIL C2 col4 (combiner partial): got=b004 exp=a104"

echo "== BSNOOP direct-to-BRAM MUTATION: registered refill commit MUST fail =="
iverilog -g2012 -DMUT_BFILL_UNPIPE -s tb_vram_bsnoop \
  -o "$T/tb_vram_bsnoop_unpipe.vvp" "${BSNOOP_SRC[@]}"
BSNOOP_UNPIPE_OUT="$(vvp "$T/tb_vram_bsnoop_unpipe.vvp")"
printf '%s\n' "$BSNOOP_UNPIPE_OUT" | grep -iE "BFILL pipeline|RESULT"
printf '%s\n' "$BSNOOP_UNPIPE_OUT" | grep -Fq \
  "FAIL BFILL pipeline mechanism:"

if [[ "${NARC_SKIP_RASTER:-0}" != 1 ]]; then
  echo "== BSNOOP row-lock MUTATION: live req_row instead of latched fill_row MUST fail =="
# ARMED 2026-07-27. This mutant existed in the RTL but NO RUNNER HAD EVER EXECUTED IT.
# That mattered: a reviewer conditioned sign-off of the BSNOOP merge repair on
# "MUT_BFILL_NOLOCK must still FAIL", against a mutant nothing had ever run --
# i.e. coherency-critical scanout merge logic approved on a guard that was never
# armed. An unreferenced mutation define reads as coverage in the RTL and survives
# review because reviewers see the ifdef and assume a runner exists.
# Condition (b) verified before arming: run standalone it kills with 6 stale
# sprite pixels, so it discriminates rather than merely existing. The kill is
# asserted in the SAME invocation that reports the baseline PASS above, so a
# green line can never inherit a kill from an earlier run.
# Mechanism (distinct from MUT_NO_BMERGE): B uses the LIVE req_row rather than the
# row latched for the whole atomic fill, so a vblank retarget mid-fill labels the
# fill with the wrong row.
iverilog -g2012 -DMUT_BFILL_NOLOCK -s tb_vram_bsnoop \
  -o "$T/tb_vram_bsnoop_nolock.vvp" "${BSNOOP_SRC[@]}"
BSNOOP_NOLOCK_OUT="$(vvp "$T/tb_vram_bsnoop_nolock.vvp")"
printf '%s\n' "$BSNOOP_NOLOCK_OUT" | grep -iE "FAIL C2|RESULT"
printf '%s\n' "$BSNOOP_NOLOCK_OUT" | grep -Fq \
  "FAIL C2 col0 (in-flight full beat): got=b000 exp=a100"
printf '%s\n' "$BSNOOP_NOLOCK_OUT" | grep -Fq \
  "FAIL C2 col4 (combiner partial): got=b004 exp=a104"

echo "== P1.9d raster integration (REAL video chain: prefetch loader -> B scanout + C erase) =="
  iverilog -g2012 -o "$T/tb_vram_ddr_raster.vvp" \
    "$ROOT/rtl/pkg/yunit_pkg.sv" \
    "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
    "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
    "$ROOT/rtl/yunit/yunit_video.sv" "$ROOT/rtl/yunit/yunit_scanline.sv" "$ROOT/rtl/yunit/yunit_video_top.sv" \
    "$ROOT/sim/ddr3_avalon_model.sv" "$ROOT/sim/tb_vram_ddr_raster.sv"
  vvp "$T/tb_vram_ddr_raster.vvp" | grep -iE "RESULT|FAIL|beam-lock|issue counts|sentinel"
  # headroom: 2-3x cab-realistic DDR contention must still erase every row every frame
  vvp "$T/tb_vram_ddr_raster.vvp" +busy=20 +rlat=12 | grep -iE "RESULT|FAIL"
else
  echo "== P1.9d raster integration skipped after an independently recorded normal+stress PASS =="
fi

echo "== RAMCHECK full-stack (yunit_mem R_VRAM decode -> field engine -> DDR3, real self-test geometry) =="
iverilog -g2012 -DUSE_HW_RAM -DUSE_SDRAM_VRAM -DUSE_DDR3_VRAM -DYM_EXT_RD -o "$T/tb_yunit_vramcheck.vvp" \
  "$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/rtl/yunit/yunit_mem.sv" "$ROOT/rtl/yunit/yunit_palram.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" "$ROOT/sim/tb_yunit_vramcheck.sv" 2>/dev/null
vvp "$T/tb_yunit_vramcheck.vvp" | grep -iE "RESULT|FAIL"

echo "== NARC registered RAM/PAL/CMOS geometry + end-of-region masking =="
iverilog -g2012 -DUSE_HW_RAM -DTEST_ZUNIT -DUSE_EXT_ROM -DUSE_EXT_GFX \
  -s tb_yunit_hwram \
  -o "$T/tb_zunit_hwram.vvp" \
  "$ROOT/rtl/zunit/zunit_pkg.sv" "$ROOT/rtl/zunit/zunit_mem.sv" \
  "$ROOT/sim/tb_yunit_hwram.sv"
NARC_HWRAM_OUT="$(cd "$ROOT/sim" && vvp "$T/tb_zunit_hwram.vvp")"
printf '%s\n' "$NARC_HWRAM_OUT" | grep -iE "PASS|FAIL"
printf '%s\n' "$NARC_HWRAM_OUT" | grep -Fq \
  "== tb_yunit_hwram PASS (clocked BRAM engine == field contract, 17 reads)"

echo "== W-THRU2 production fb write-combine (DSB=1, DWF=1): content + cost + coherency + redraw-fits-in-frame =="
FBC_SRC=("$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/yunit/vram_sdram.sv" \
  "$ROOT/rtl/yunit/vram_sdram_top.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" "$ROOT/sim/tb_vram_ddr_fbcombine.sv")
iverilog -g2012 -Ptb_vram_ddr_fbcombine.DSB=1 -Ptb_vram_ddr_fbcombine.DWF=1 \
  -o "$T/tb_vram_ddr_fbcombine.vvp" "${FBC_SRC[@]}"
FBC_OUT="$(vvp "$T/tb_vram_ddr_fbcombine.vvp")"
printf '%s\n' "$FBC_OUT" | grep -iE "RESULT|FAIL|COST over|clk/px"
printf '%s\n' "$FBC_OUT" | grep -Fq \
  "RESULT: PASS -- fb write-combine: content + cost + coherency + redraw-fits-in-frame."
# MUTATION coverage: -DPERF_NO_FBCOMBINE disables the same-beat combine (every pixel a partial RMW).
# The cost + redraw-fits gates MUST then FAIL (proving the gate exercises the combine AND that the
# uncombined cost reproduces the attract watchdog condition). Coherency + content stay green.
echo "== fb write-combine MUTATION (-DPERF_NO_FBCOMBINE): cost/redraw gates MUST fail (coverage) =="
iverilog -g2012 -DPERF_NO_FBCOMBINE \
  -Ptb_vram_ddr_fbcombine.DSB=1 -Ptb_vram_ddr_fbcombine.DWF=1 \
  -o "$T/tb_vram_ddr_fbcombine_mut.vvp" "${FBC_SRC[@]}"
vvp "$T/tb_vram_ddr_fbcombine_mut.vvp" | grep -iE "RESULT|COST FAIL|REDRAW FAIL"

echo "== NARC MAME high-score source workload: bank-1 page map + streaming cache =="
NARC_SRC_HS=("$ROOT/rtl/sdram/yunit_src_cache.sv" \
  "$ROOT/rtl/sdram/yunit_sdram_adapter.sv" \
  "$ROOT/rtl/sdram/sdram_stock_shipped.sv" \
  "$ROOT/sim/tb_narc_src_cache_hiscore.sv")
iverilog -g2012 -DUSE_DDR3_VRAM -s tb_narc_src_cache_hiscore \
  -o "$T/tb_narc_src_cache_hiscore.vvp" "${NARC_SRC_HS[@]}"
NARC_SRC_HS_OUT="$(vvp "$T/tb_narc_src_cache_hiscore.vvp")"
printf '%s\n' "$NARC_SRC_HS_OUT" | grep -iE "NARC-HISCORE|RESULT|FAIL"
printf '%s\n' "$NARC_SRC_HS_OUT" | grep -Fq \
  "RESULT: PASS -- NARC MAME high-score source workload cached, bank-isolated and >2x faster."

echo "== NARC source old-map MUTATION: burst data + physical-bank proof MUST fail =="
iverilog -g2012 -s tb_narc_src_cache_hiscore \
  -o "$T/tb_narc_src_cache_hiscore_oldmap.vvp" "${NARC_SRC_HS[@]}"
NARC_SRC_OLD_OUT="$(vvp "$T/tb_narc_src_cache_hiscore_oldmap.vvp")"
printf '%s\n' "$NARC_SRC_OLD_OUT" | grep -iE "FAIL NARC-SRC cache byte|FAIL NARC-SRC physical route|RESULT"
printf '%s\n' "$NARC_SRC_OLD_OUT" | grep -Fq "FAIL NARC-SRC cache byte=0058b4"
printf '%s\n' "$NARC_SRC_OLD_OUT" | grep -Fq \
  "FAIL NARC-SRC physical route any_bank1=1 direct_b1=0 direct_b0=1"

echo "== NARC audio: unsigned CVSD normalization + mono MAME weights + saturation =="
NARC_AUDIO_SRC=("$ROOT/rtl/sound/narc_audio_mix.sv" "$ROOT/sim/tb_narc_audio_mix.sv")
iverilog -g2012 -s tb_narc_audio_mix -o "$T/tb_narc_audio_mix.vvp" "${NARC_AUDIO_SRC[@]}"
NARC_AUDIO_OUT="$(vvp "$T/tb_narc_audio_mix.vvp")"
printf '%s\n' "$NARC_AUDIO_OUT" | grep -iE "RESULT|FAIL"
printf '%s\n' "$NARC_AUDIO_OUT" | grep -Fq \
  "RESULT: PASS -- NARC audio normalized, mono and saturating."

echo "== NARC audio old-mix MUTATION: sign flip/stereo split/wrap MUST fail =="
iverilog -g2012 -DMUT_NARC_AUDIO_OLD_MIX -s tb_narc_audio_mix \
  -o "$T/tb_narc_audio_mix_old.vvp" "${NARC_AUDIO_SRC[@]}"
NARC_AUDIO_OLD_OUT="$(vvp "$T/tb_narc_audio_mix_old.vvp")"
printf '%s\n' "$NARC_AUDIO_OLD_OUT" | grep -iE "FAIL NARC-AUDIO|RESULT"
printf '%s\n' "$NARC_AUDIO_OLD_OUT" | grep -Fq \
  "FAIL NARC-AUDIO CVSD above bit15 boundary"
printf '%s\n' "$NARC_AUDIO_OLD_OUT" | grep -Fq \
  "FAIL NARC-AUDIO positive saturation"

echo "== NARC YM2151: exact 3,579,545 Hz enable from 96 MHz =="
NARC_YMCLK_SRC=("$ROOT/rtl/sound/narc_ym_clock_en.sv" "$ROOT/sim/tb_narc_ym_clock_en.sv")
iverilog -g2012 -s tb_narc_ym_clock_en -o "$T/tb_narc_ym_clock_en.vvp" \
  "${NARC_YMCLK_SRC[@]}"
NARC_YMCLK_OUT="$(vvp "$T/tb_narc_ym_clock_en.vvp")"
printf '%s\n' "$NARC_YMCLK_OUT" | grep -iE "RESULT|FAIL"
printf '%s\n' "$NARC_YMCLK_OUT" | grep -Fq \
  "RESULT: PASS -- NARC YM clock 3,579,545 Hz exact-average"

echo "== NARC YM old-donor-rate MUTATION: 3,562,500 Hz MUST fail =="
iverilog -g2012 -DMUT_NARC_YM_DONOR -s tb_narc_ym_clock_en \
  -o "$T/tb_narc_ym_clock_en_old.vvp" "${NARC_YMCLK_SRC[@]}"
NARC_YMCLK_OLD_OUT="$(vvp "$T/tb_narc_ym_clock_en_old.vvp")"
printf '%s\n' "$NARC_YMCLK_OLD_OUT" | grep -iE "FAIL NARC-YM rate|RESULT"
printf '%s\n' "$NARC_YMCLK_OLD_OUT" | grep -Fq \
  "FAIL NARC-YM rate: got 35625 pulses, expected 35795"

echo "== NARC 6809 clock: exact 2 MHz with full ROM access window =="
NARC_6809CLK_SRC=("$ROOT/rtl/sound/narc_6809_clock_en.sv" \
  "$ROOT/sim/tb_narc_6809_clock_en.sv")
iverilog -g2012 -s tb_narc_6809_clock_en \
  -o "$T/tb_narc_6809_clock_en.vvp" "${NARC_6809CLK_SRC[@]}"
NARC_6809CLK_OUT="$(vvp "$T/tb_narc_6809_clock_en.vvp")"
printf '%s\n' "$NARC_6809CLK_OUT" | grep -iE "PASS|FAIL"
printf '%s\n' "$NARC_6809CLK_OUT" | grep -Fq \
  "PASS: NARC 6809 E=2MHz; hidden latency free"

echo "== NARC 6809 early-stall MUTATION: hidden latency MUST slow E and fail =="
iverilog -g2012 -DMUT_SND_EARLY_STALL -s tb_narc_6809_clock_en \
  -o "$T/tb_narc_6809_clock_en_mut.vvp" "${NARC_6809CLK_SRC[@]}"
set +e
NARC_6809CLK_MUT_OUT="$(vvp "$T/tb_narc_6809_clock_en_mut.vvp" 2>&1)"
NARC_6809CLK_MUT_RC=$?
set -e
printf '%s\n' "$NARC_6809CLK_MUT_OUT" | grep -iE "FAIL|FATAL"
test "$NARC_6809CLK_MUT_RC" -ne 0
printf '%s\n' "$NARC_6809CLK_MUT_OUT" | grep -Fq \
  "FAIL: hidden 30-clock ROM latency changed E period to 78"

echo "== NARC sound-ROM demand timing: core-visible ROM reads + 16-bit word cache =="
NARC_SND_TIM_SRC=("$ROOT/rtl/zunit/zunit_snd_rom.sv" \
  "$ROOT/sim/tb_narc_snd_rom_timing.sv")
iverilog -g2012 -s tb_narc_snd_rom_timing \
  -o "$T/tb_narc_snd_rom_timing.vvp" "${NARC_SND_TIM_SRC[@]}"
NARC_SND_TIM_OUT="$(vvp "$T/tb_narc_snd_rom_timing.vvp")"
printf '%s\n' "$NARC_SND_TIM_OUT" | grep -iE "PASS|FAIL|FATAL"
printf '%s\n' "$NARC_SND_TIM_OUT" | grep -Fq \
  "PASS: tb_narc_snd_rom_timing requests=6"

echo "== NARC sound-ROM MUTATIONS: inherited always-fetch and byte cache MUST fail =="
for MUT in MUT_SND_ALWAYS_FETCH MUT_SND_BYTE_TAG; do
  iverilog -g2012 "-D$MUT" -s tb_narc_snd_rom_timing \
    -o "$T/tb_narc_snd_rom_timing_mut.vvp" "${NARC_SND_TIM_SRC[@]}"
  set +e
  NARC_SND_TIM_MUT_OUT="$(vvp "$T/tb_narc_snd_rom_timing_mut.vvp" 2>&1)"
  NARC_SND_TIM_MUT_RC=$?
  set -e
  printf '%s\n' "$NARC_SND_TIM_MUT_OUT" | grep -iE "FAIL|FATAL"
  test "$NARC_SND_TIM_MUT_RC" -ne 0
  case "$MUT" in
    MUT_SND_ALWAYS_FETCH)
      printf '%s\n' "$NARC_SND_TIM_MUT_OUT" | grep -Fq \
        "FAIL: non-ROM address churn stalled E/Q"
      ;;
    MUT_SND_BYTE_TAG)
      printf '%s\n' "$NARC_SND_TIM_MUT_OUT" | grep -Fq \
        "FAIL: adjacent byte in cached word stalled"
      ;;
  esac
done

echo "== NARC sound-ROM end-to-end MRA demux + adversarial SDRAM seam =="
NARC_SND_SEAM_SRC=("$ROOT/rtl/zunit/zunit_pkg.sv" \
  "$ROOT/rtl/zunit/zunit_download.sv" \
  "$ROOT/rtl/zunit/zunit_snd_rom.sv" \
  "$ROOT/sim/tb_narc_snd_rom_seam.sv")
iverilog -g2012 -s tb_narc_snd_rom_seam \
  -o "$T/tb_narc_snd_rom_seam.vvp" "${NARC_SND_SEAM_SRC[@]}"
NARC_SND_SEAM_OUT="$(vvp "$T/tb_narc_snd_rom_seam.vvp")"
printf '%s\n' "$NARC_SND_SEAM_OUT" | grep -iE \
  "region map|download:|e_cycles=|PASS|FAIL"
printf '%s\n' "$NARC_SND_SEAM_OUT" | grep -Fq \
  "PASS: tb_narc_snd_rom_seam"

echo "== NARC real sound firmware: SDRAM seam vs direct-ROM board + MAME YM prefix =="
"$PY" "$ROOT/sim/narc_sound_smoke/make_hex.py"
NARC_JT51=()
while IFS= read -r f; do NARC_JT51+=("$f"); done \
  < <(find "$ROOT/rtl/sound/jt51/hdl" -maxdepth 1 -name '*.v' | sort)
NARC_SND_BOOT_SRC=("$ROOT/rtl/sound/narc_sound_pkg.sv" \
  "${NARC_JT51[@]}" \
  "$ROOT/rtl/sound/williams_cvsd/mc6809is.v" \
  "$ROOT/rtl/sound/sim/hc55564_stub.v" \
  "$ROOT/rtl/sound/narc_sound_bank.sv" \
  "$ROOT/rtl/sound/narc_sound_latch.sv" \
  "$ROOT/rtl/sound/narc_6809_clock_en.sv" \
  "$ROOT/rtl/sound/narc_ym_clock_en.sv" \
  "$ROOT/rtl/sound/narc_sound_board.sv" \
  "$ROOT/rtl/zunit/zunit_snd_rom.sv" \
  "$ROOT/sim/tb_narc_sound_sdram_boot.sv")
iverilog -g2012 -DJT51_ONLYTIMERS -s tb_narc_sound_sdram_boot \
  -o "$T/tb_narc_sound_sdram_boot.vvp" "${NARC_SND_BOOT_SRC[@]}"
NARC_SND_BOOT_OUT="$(cd "$ROOT" && vvp "$T/tb_narc_sound_sdram_boot.vvp")"
printf '%s\n' "$NARC_SND_BOOT_OUT" | grep -iE "PASS|FAIL|FATAL"
printf '%s\n' "$NARC_SND_BOOT_OUT" | grep -Fq \
  "PASS: SDRAM sound boot matches first 16 MAME YM writes"

echo "== NARC AVMA ROM qualifier MUTATION: real firmware differential MUST fail =="
iverilog -g2012 -DJT51_ONLYTIMERS -DMUT_SND_USE_AVMA \
  -s tb_narc_sound_sdram_boot \
  -o "$T/tb_narc_sound_sdram_boot_avma.vvp" "${NARC_SND_BOOT_SRC[@]}"
set +e
NARC_SND_BOOT_MUT_OUT="$(cd "$ROOT" && \
  vvp "$T/tb_narc_sound_sdram_boot_avma.vvp" 2>&1)"
NARC_SND_BOOT_MUT_RC=$?
set -e
printf '%s\n' "$NARC_SND_BOOT_MUT_OUT" | grep -iE "FAIL|FATAL"
test "$NARC_SND_BOOT_MUT_RC" -ne 0
printf '%s\n' "$NARC_SND_BOOT_MUT_OUT" | grep -Fq \
  "FAIL: master execution diverged seam=38b7 ref=3800"

echo "== NARC DMA control: trigger interval + MAME pace + COMMAND stop/refire =="
NARC_DMA_CTL_SRC=("$ROOT/rtl/zunit/zunit_pkg.sv" \
  "$ROOT/rtl/zunit/zunit_dma.sv" "$ROOT/sim/tb_zunit_dma_control.sv")
iverilog -g2012 -s tb_zunit_dma_control -o "$T/tb_zunit_dma_control.vvp" \
  "${NARC_DMA_CTL_SRC[@]}"
NARC_DMA_CTL_OUT="$(vvp "$T/tb_zunit_dma_control.vvp")"
printf '%s\n' "$NARC_DMA_CTL_OUT" | grep -iE "ZDMA-CTRL|RESULT|FAIL"
printf '%s\n' "$NARC_DMA_CTL_OUT" | grep -Fq \
  "RESULT: PASS -- NARC DMA trigger, MAME pace, stop and refire semantics."

echo "== NARC DMA control MUTATIONS: each removed mechanism MUST fail =="
for MUT in MUT_ZDMA_NOTRIG MUT_ZDMA_NOPACE MUT_ZDMA_NOSTOP MUT_ZDMA_NO_STOP_ABORT; do
  iverilog -g2012 "-D$MUT" -s tb_zunit_dma_control \
    -o "$T/tb_zunit_dma_control_mut.vvp" "${NARC_DMA_CTL_SRC[@]}"
  NARC_DMA_CTL_MUT_OUT="$(vvp "$T/tb_zunit_dma_control_mut.vvp")"
  printf '%s\n' "$NARC_DMA_CTL_MUT_OUT" | grep -iE "ZDMA-CTRL|RESULT"
  printf '%s\n' "$NARC_DMA_CTL_MUT_OUT" | grep -Fq \
    "RESULT: FAIL -- NARC DMA control errors="
done

echo "== NARC DMA bare GO-while-busy: the UNDOCUMENTED arm, pinned as ABSORBED =="
# zunit_dma.sv's COMMAND-write chain has a fourth, silent arm: bit15 SET while
# state != S_IDLE and abort_r == 0 and pend_trig == 0 takes no branch, so the
# trigger is absorbed. DMA.DOC "DMA GO bit - Bit 15" and DIAG/DMASYS.INC:31-38
# both leave that collision undefined, and MAME cannot arbitrate it
# (midyunit_v.cpp:517-519 draws synchronously inside dma_w, so its blits are
# atomic). This gate does not claim the behaviour is transcribed -- it PINS it
# so it can never change silently, and the four mutants below are the competing
# readings that must all stay dead.
NARC_DMA_BAREGO_SRC=("$ROOT/rtl/zunit/zunit_pkg.sv" \
  "$ROOT/rtl/zunit/zunit_dma.sv" "$ROOT/sim/tb_zunit_dma_bare_refire.sv")
iverilog -g2012 -s tb_zunit_dma_bare_refire \
  -o "$T/tb_zunit_dma_bare_refire.vvp" "${NARC_DMA_BAREGO_SRC[@]}"
NARC_DMA_BAREGO_OUT="$(vvp "$T/tb_zunit_dma_bare_refire.vvp")"
printf '%s\n' "$NARC_DMA_BAREGO_OUT" | grep -iE "ZDMA-BAREGO|RESULT|FAIL"
printf '%s\n' "$NARC_DMA_BAREGO_OUT" | grep -Fq \
  "RESULT: PASS -- NARC DMA bare GO-while-busy collision pinned: absorbed, running blit intact, one completion, no false idle."
# Coverage self-check, independent of the TB's own assertion A: the arm must
# really have been entered, mid-draw AND during the S_DONE pace hold. A gate
# that quietly stops reaching the arm must not be able to report PASS.
printf '%s\n' "$NARC_DMA_BAREGO_OUT" | grep -Eq \
  "ZDMA-BAREGO case1 arm\(state=[1-6] busy=1 abort=0 pend=0\)"
printf '%s\n' "$NARC_DMA_BAREGO_OUT" | grep -Fq \
  "ZDMA-BAREGO case2 arm(state=6 busy=1 abort=0 pend=0)"

echo "== NARC DMA bare GO MUTATIONS: every competing reading MUST fail =="
for MUT in MUT_ZDMA_BAREGO MUT_ZDMA_BAREGO_ABORT MUT_ZDMA_BAREGO_STOP \
           MUT_ZDMA_LIVEPAL; do
  iverilog -g2012 "-D$MUT" -s tb_zunit_dma_bare_refire \
    -o "$T/tb_zunit_dma_bare_refire_mut.vvp" "${NARC_DMA_BAREGO_SRC[@]}"
  NARC_DMA_BAREGO_MUT_OUT="$(vvp "$T/tb_zunit_dma_bare_refire_mut.vvp")"
  printf '%s\n' "$NARC_DMA_BAREGO_MUT_OUT" | grep -iE "ZDMA-BAREGO|RESULT"
  printf '%s\n' "$NARC_DMA_BAREGO_MUT_OUT" | grep -Fq \
    "RESULT: FAIL -- NARC DMA bare GO collision errors="
done

echo "== NARC exact MAME high-score batch in PRODUCTION config (DSB=1, DWF=1) =="
"$PY" "$ROOT/sim/prep_narc_hiscore_gfx.py"
NARC_HS_PIPE_SRC=("$ROOT/rtl/zunit/zunit_pkg.sv" \
  "$ROOT/rtl/zunit/zunit_dma.sv" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/yunit_src_cache.sv" \
  "$ROOT/rtl/sdram/yunit_sdram_adapter.sv" \
  "$ROOT/rtl/sdram/sdram_stock_shipped.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_narc_hiscore_pipeline.sv")
iverilog -g2012 -DUSE_DDR3_VRAM -s tb_narc_hiscore_pipeline \
  -o "$T/tb_narc_hiscore_pipeline.vvp" "${NARC_HS_PIPE_SRC[@]}"
NARC_HS_PIPE_OUT="$(cd "$ROOT" && vvp "$T/tb_narc_hiscore_pipeline.vvp")"
printf '%s\n' "$NARC_HS_PIPE_OUT" | grep -iE "NARC-HISCORE-PIPE|RESULT|FAIL"
printf '%s\n' "$NARC_HS_PIPE_OUT" | grep -Fq \
  "RESULT: PASS -- exact NARC high-score batch meets MAME time through physical SDRAM + DDR3 with scan traffic."
printf '%s\n' "$NARC_HS_PIPE_OUT" | grep -Fq \
  "RESULT: BLIT-BUDGET PASS -- all 15 blits retire within 4*width*height clocks."
printf '%s\n' "$NARC_HS_PIPE_OUT" | grep -Eq \
  "NARC-HISCORE-FBQ max=64/64 full-pop-push=[1-9][0-9]*"

echo "== NARC high-score FIFO-off MUTATION: per-blit process budget MUST fail =="
iverilog -g2012 -DUSE_DDR3_VRAM -s tb_narc_hiscore_pipeline \
  -Ptb_narc_hiscore_pipeline.DWF=0 \
  -o "$T/tb_narc_hiscore_pipeline_fifo_off.vvp" "${NARC_HS_PIPE_SRC[@]}"
NARC_HS_PIPE_FIFO_OFF_OUT="$(cd "$ROOT" && vvp "$T/tb_narc_hiscore_pipeline_fifo_off.vvp")"
printf '%s\n' "$NARC_HS_PIPE_FIFO_OFF_OUT" | grep -iE "NARC-HISCORE-PIPE|RESULT|FAIL"
printf '%s\n' "$NARC_HS_PIPE_FIFO_OFF_OUT" | grep -Fq \
  "RESULT: BLIT-BUDGET FAIL -- 15 of 15 blits exceed 4*width*height clocks;"
printf '%s\n' "$NARC_HS_PIPE_FIFO_OFF_OUT" | grep -Fq \
  "RESULT: FAIL -- NARC high-score physical pipeline errors=15"

echo "== NARC production high-score no-shadow-bypass MUTATION: MAME budget MUST fail =="
iverilog -g2012 -DUSE_DDR3_VRAM -DMUT_NO_DSHWBYPASS \
  -s tb_narc_hiscore_pipeline -o "$T/tb_narc_hiscore_pipeline_mut.vvp" \
  "${NARC_HS_PIPE_SRC[@]}"
NARC_HS_PIPE_MUT_OUT="$(cd "$ROOT" && vvp "$T/tb_narc_hiscore_pipeline_mut.vvp")"
printf '%s\n' "$NARC_HS_PIPE_MUT_OUT" | grep -iE "NARC-HISCORE-PIPE|RESULT|FAIL"
printf '%s\n' "$NARC_HS_PIPE_MUT_OUT" | grep -Fq \
  "RESULT: BLIT-BUDGET FAIL --"
printf '%s\n' "$NARC_HS_PIPE_MUT_OUT" | grep -Eq \
  "^FAIL NARC-BLIT-BUDGET glyph"
printf '%s\n' "$NARC_HS_PIPE_MUT_OUT" | grep -Fq \
  "RESULT: FAIL -- NARC high-score physical pipeline errors="

# NARC beam-locked AUTOERASE CONTRACT (real 512x400 raster + the C erase engine + the game's
# own GAMERASE=1/2 interrupt schedule), plus its donor-256-row-cap mutation kill and the
# bulk-sweep cost probe. Called from HERE so the gate cannot become an orphan: the P1.9d
# raster gate above runs the DONOR yunit_video_top (512x256) and is structurally blind to
# NARC display rows 256..399 -- exactly the drift that shipped the unerased bottom third.
if [[ "${NARC_SKIP_RASTER:-0}" != 1 ]]; then
  echo "== NARC beam-locked autoerase contract (512x400 raster, GAMERASE=1/2 + mutation) =="
  BEAM_OUT="$("$ROOT/sim/run_beamerase.sh")"
  printf '%s\n' "$BEAM_OUT" | grep -E "^\[beam\] (PASS|FAIL|MEASURED)|^\[bulk\]|^RESULT|^MUTANT"
  printf '%s\n' "$BEAM_OUT" | grep -Fq \
    "RESULT: beam-locked autoerase contract GREEN on production RTL, mutant killed."
else
  echo "== NARC beam-locked autoerase contract skipped (NARC_SKIP_RASTER=1) =="
fi

echo "RESULT: PASS -- full NARC DDR3, DMA, scanout, coherency, reset, and audio regression suite."
