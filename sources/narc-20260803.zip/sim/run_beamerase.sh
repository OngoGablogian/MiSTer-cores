#!/usr/bin/env bash
# run_beamerase.sh — NARC beam-locked autoerase contract gate (iverilog; no licence).
#
# Runs the PRODUCTION NARC video+VRAM chain (zunit_video_top 512x400 -> stv_vram_ddr_top's
# beam-locked C erase engine -> the faithful DDR3 oracle) against the hardware contract
# transcribed from MAME 0.280 midyunit_v.cpp:534-559 and NARC's own interrupt schedule.
#
#   ./run_beamerase.sh          production RTL + the MUTANT coverage proof
#   MUT_ONLY=1 ./run_beamerase.sh   mutant only
#
# Two scenarios per build:
#   GAMERASE=1  arm @SCOREINT(107), disarm @EOSINT(427)  -> status rows 0..79 preserved,
#               play area 80..399 erased every frame
#   GAMERASE=2  arm @SCOREINT(107), disarm @HSINT(257)   -> band stops mid-screen
#
# P0033 BASE SWEEP (added 2026-07-30, see the section near the bottom):
#   tb_zunit_beamerase.sv hardwires .dpystrt(16'hFFFC) (display base 0) and models the AUTOERAS
#   disarm as instantaneous, so it cannot see a base-relative or blanking-window defect at all.
#   tb_zunit_beamerase_base.sv adds +base=N / +isrlat=N and this runner sweeps
#   base in {0,40,80} x isrlat in {0,4000}. -DMUT_BEAMERASE_ABS_ROW0 restores the pre-fix
#   absolute-row-0 anchoring + always-armed trigger and MUST go RED at base=80.
# P0045 ARM EDGE (added after the v11 cabinet reject): +armlat=1000 lands the
#   AUTOERAS write after the prefetch edge. The exact first target row must still
#   issue and erase; -DMUT_ERASE_NO_ARM_REPLAY restores v11 and must miss it.
#
# MUTATION (the discrimination proof, run in the SAME invocation as the pass):
#   -DMUT_BEAMERASE_DONOR_ROWS restores the inherited Y-unit 256-displayed-row cap in
#   stv_vram_ddr_top's goal latch. GAMERASE=1 MUST then go RED on rows 256..395.
set -e
export PATH="/c/iverilog/bin:/usr/local/bin:/usr/bin:/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
# Keep independently launched full regressions from recompiling the same .vvp
# beneath one another. A collided image can terminate before the mutation's
# mechanism checks even when both source trees are identical.
T="${TMPDIR:-/tmp}/narc-beamerase.$$"
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT

SRC=(
  "$ROOT/rtl/pkg/yunit_pkg.sv"
  "$ROOT/rtl/zunit/zunit_pkg.sv"
  "$ROOT/rtl/yunit/vram_sdram.sv"
  "$ROOT/rtl/yunit/vram_sdram_top.sv"
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv"
  "$ROOT/rtl/sdram/stv_vram_ddr_top.sv"
  "$ROOT/rtl/zunit/zunit_video.sv"
  "$ROOT/rtl/yunit/yunit_scanline.sv"
  "$ROOT/rtl/zunit/zunit_video_top.sv"
  "$ROOT/sim/ddr3_avalon_model.sv"
  "$ROOT/sim/tb_zunit_beamerase.sv"
)

run_case () {   # $1 = vvp image, $2 = gamerase, $3 = label
  echo "-- $3 : GAMERASE=$2"
  vvp "$1" "+gamerase=$2" | grep -E "^\[beam\]|^RESULT"
}

if [[ "${MUT_ONLY:-0}" != 1 ]]; then
  echo "== BUILD: production RTL =="
  iverilog -g2012 -s tb_zunit_beamerase -o "$T/tb_zunit_beamerase.vvp" "${SRC[@]}"
  PROD1="$(vvp "$T/tb_zunit_beamerase.vvp" +gamerase=1)"
  printf '%s\n' "$PROD1" | grep -E "^\[beam\]|^RESULT"
  PROD2="$(vvp "$T/tb_zunit_beamerase.vvp" +gamerase=2)"
  printf '%s\n' "$PROD2" | grep -E "^\[beam\]|^RESULT"
  # HEADROOM: 400 displayed rows is 1.5625x the donor's 256 rows of erase traffic. The same
  # 2-3x-cab-realistic DDR contention profile the raster gate uses must still complete every
  # row every frame, beam-locked. (Same numbers as run_ddr3.sh's stress raster run.)
  echo "-- stress DDR profile (busy=20 rlat=12): 400-row erase must still fit the frame"
  PROD3="$(vvp "$T/tb_zunit_beamerase.vvp" +gamerase=1 +busy=20 +rlat=12)"
  printf '%s\n' "$PROD3" | grep -E "^\[beam\] (PASS|FAIL|MEASURED|continuity|rows checked)|^RESULT"
  # BLITTER COST: every C transaction fences new D ingress, so 1.5625x more erase rows has to
  # be paid for by someone. Measure the D-lane latency under the full 400-row erase load.
  echo "-- blitter (D-lane) latency under the 400-row erase load"
  PROD4="$(vvp "$T/tb_zunit_beamerase.vvp" +gamerase=1 +hammer=1)"
  printf '%s\n' "$PROD4" | grep -E "^\[beam\] (PASS|FAIL|MEASURED|rows checked)|^RESULT"
  printf '%s\n' "$PROD4" | grep -Fq "RESULT: PASS" || { echo "GATE RED: GAMERASE=1 hammer"; PROD_RED=1; }
  printf '%s\n' "$PROD1" | grep -Fq "RESULT: PASS" || { echo "GATE RED: GAMERASE=1"; PROD_RED=1; }
  printf '%s\n' "$PROD2" | grep -Fq "RESULT: PASS" || { echo "GATE RED: GAMERASE=2"; PROD_RED=1; }
  printf '%s\n' "$PROD3" | grep -Fq "RESULT: PASS" || { echo "GATE RED: GAMERASE=1 stress"; PROD_RED=1; }
fi

echo
echo "== MUTATION -DMUT_BEAMERASE_DONOR_ROWS (donor 256-row cap): GAMERASE=1 MUST go RED =="
iverilog -g2012 -DMUT_BEAMERASE_DONOR_ROWS -s tb_zunit_beamerase \
  -o "$T/tb_zunit_beamerase_mut.vvp" "${SRC[@]}"
MUT1="$(vvp "$T/tb_zunit_beamerase_mut.vvp" +gamerase=1)"
printf '%s\n' "$MUT1" | grep -E "^\[beam\] ROW 25[6-9]|^\[beam\] FAIL|^\[beam\] CONTINUITY|^\[beam\] rows checked|^RESULT"
# The mutant must die with the SPECIFIC mechanism (the displayed rows past the donor cap are
# left unerased), not merely with "some failure": a bare non-PASS would also be satisfied by a
# timeout or a compile-order accident. Three independent signatures are required.
printf '%s\n' "$MUT1" | grep -Fq "RESULT: FAIL" \
  || { echo "COVERAGE FAILURE: the donor-cap mutant PASSED -- the gate does not discriminate" >&2; exit 1; }
printf '%s\n' "$MUT1" | grep -Fq "ROW 256 WRONG (must be ERASED)" \
  || { echo "COVERAGE FAILURE: mutant died, but not on the first row past the donor cap" >&2; exit 1; }
# 400 displayed rows - 256 donor cap = 144, minus the 4 band-edge rows 396..399 = 140 exactly.
printf '%s\n' "$MUT1" | grep -Fq "FAIL (c/d): 140 of 503 hard-checked rows violate the autoerase band" \
  || { echo "COVERAGE FAILURE: mutant died with the wrong row count (expected exactly 140)" >&2; exit 1; }
printf '%s\n' "$MUT1" | grep -Fq "FAIL: 140 must-erase rows under-issued (engine not continuous)" \
  || { echo "COVERAGE FAILURE: mutant content died but the issue-count monitor did not" >&2; exit 1; }
echo "MUTANT KILLED with the expected mechanism: exactly 140 displayed rows past the 256-row donor cap left unerased and never issued."

echo
echo "== P0033 BASE SWEEP: the erase window must be DISPLAY-BASE-RELATIVE and VISIBLE-ONLY =="
# WHY THIS EXISTS.  Everything above hardwires .dpystrt(16'hFFFC) -- display base 0 -- and models
# the AUTOERAS disarm as an INSTANTANEOUS function of the line counter.  Neither holds on the
# cabinet:
#   * MEASURED (mame-trace/narc_erase_hud.txt): NARC drives DPYSTRT=0FAFC (base 80) for ~380
#     frames at every wave start (SCORDPYS, NARCBGND.ASM:64-65) and then scrolls it 79->0.
#     MAME's erasable set is autoerase_line(params->rowaddr - 1) with rowaddr DPYSTRT-derived
#     (tms34010.cpp:1035/1152, midyunit_v.cpp:554) => ABSOLUTE rows base-1 .. base+399.
#   * The disarm is a CPU ISR (DIRQ1) that lands INSIDE line 427, while the scanout prefetcher
#     re-primes at the START of 427 -- so the engine is still armed when a blanking-only row
#     transition arrives.  MAME cannot produce that goal at all (autoerase_line is reachable
#     only from scanline_update, midyunit_v.cpp:538/554).
# +isrlat=N models that ISR latency in clocks; +base=N sets DPYSTRT = 0xFFFC ^ (N<<4).
# base=0 / isrlat=0 reproduces the hardwired gate above, so this sweep STRICTLY CONTAINS it.
BASE_SRC=( "${SRC[@]}" ); BASE_SRC[${#BASE_SRC[@]}-1]="$ROOT/sim/tb_zunit_beamerase_base.sv"

run_base () {   # $1 = image, $2 = base, $3 = isrlat, $4 = expect (PASS|FAIL)
  local out
  out="$(vvp "$1" +gamerase=1 "+base=$2" "+isrlat=$3")"
  printf '%s\n' "$out" | grep -E "^\[beam\] (ROW|CONTINUITY|FAIL|PASS \(c/d\)|rows checked)|^RESULT" | head -8
  if [[ "$4" == PASS ]]; then
    printf '%s\n' "$out" | grep -Fq "RESULT: PASS" \
      || { echo "GATE RED: base=$2 isrlat=$3 (expected PASS)"; BASE_RED=1; }
  else
    printf '%s\n' "$out" | grep -Fq "RESULT: FAIL" \
      || { echo "COVERAGE FAILURE: base=$2 isrlat=$3 PASSED under the mutant" >&2; exit 1; }
  fi
}

if [[ "${MUT_ONLY:-0}" != 1 ]]; then
  echo "-- BUILD: production RTL (base-relative TB)"
  iverilog -g2012 -s tb_zunit_beamerase_base -o "$T/tb_base.vvp" "${BASE_SRC[@]}"
  for B in 0 40 80; do
    for L in 0 4000; do
      echo "-- base=$B isrlat=$L"
      run_base "$T/tb_base.vvp" "$B" "$L" PASS
    done
  done
  echo "-- P0041 recovery: SRT invalidate + one A-side source write-through"
  P0041_PROD="$(vvp "$T/tb_base.vvp" +gamerase=1 +base=0 +isrlat=0 +p0041=1)"
  printf '%s\n' "$P0041_PROD" | grep -E "^\[beam\] (P0041|PASS P0041|FAIL P0041|ROW|FAIL \(c/d\))|^RESULT"
  printf '%s\n' "$P0041_PROD" | grep -Fq "PASS P0041 recovery" \
    || { echo "GATE RED: P0041 recovery case did not prove full-row recovery"; BASE_RED=1; }
  printf '%s\n' "$P0041_PROD" | grep -Fq "RESULT: PASS" \
    || { echo "GATE RED: P0041 recovery case failed production RTL"; BASE_RED=1; }

  echo "-- P0045 delayed DIRQ2 arm: exact first-row replay"
  P0045_PROD="$(vvp "$T/tb_base.vvp" +gamerase=1 +base=0 +isrlat=0 +armlat=1000 +frames=2)"
  printf '%s\n' "$P0045_PROD" | grep -E "^\[beam\] (PASS P0045|FAIL P0045|P0045 FAIL)|^RESULT"
  printf '%s\n' "$P0045_PROD" | grep -Fq "PASS P0045 arm-edge replay" \
    || { echo "GATE RED: P0045 exact delayed-arm row was not proved"; BASE_RED=1; }
  printf '%s\n' "$P0045_PROD" | grep -Fq "RESULT: PASS" \
    || { echo "GATE RED: P0045 delayed-arm production case failed"; BASE_RED=1; }
fi

echo
echo "== MUTATION -DMUT_ERASE_NO_ARM_REPLAY (v11 waits for the next prefetch) =="
iverilog -g2012 -DMUT_ERASE_NO_ARM_REPLAY -s tb_zunit_beamerase_base \
  -o "$T/tb_arm_replay_mut.vvp" "${BASE_SRC[@]}"
P0045_MUT="$(vvp "$T/tb_arm_replay_mut.vvp" +gamerase=1 +base=0 +isrlat=0 +armlat=1000 +frames=2)"
printf '%s\n' "$P0045_MUT" | grep -E "^\[beam\] (PASS P0045|FAIL P0045|P0045 FAIL)|^RESULT"
printf '%s\n' "$P0045_MUT" | grep -Fq "P0045 FAIL arm row" \
  || { echo "COVERAGE FAILURE: v11 mutation did not miss the exact delayed-arm row" >&2; exit 1; }
printf '%s\n' "$P0045_MUT" | grep -Fq "FAIL P0045 arm-edge replay" \
  || { echo "COVERAGE FAILURE: v11 mutation lacked the dedicated P0045 verdict" >&2; exit 1; }
printf '%s\n' "$P0045_MUT" | grep -Fq "RESULT: FAIL" \
  || { echo "COVERAGE FAILURE: v11 mutation passed the delayed-arm case" >&2; exit 1; }
echo "ARM_REPLAY MUTANT KILLED: the v11 behavior misses the cabinet boundary row."

echo
echo "== MUTATION -DMUT_SRCWT_VALIDATES (one source beat falsely validates the complete row) =="
iverilog -g2012 -DMUT_SRCWT_VALIDATES -s tb_zunit_beamerase_base \
  -o "$T/tb_srcwt_mut.vvp" "${BASE_SRC[@]}"
P0041_MUT="$(vvp "$T/tb_srcwt_mut.vvp" +gamerase=1 +base=0 +isrlat=0 +p0041=1)"
printf '%s\n' "$P0041_MUT" | grep -E "^\[beam\] (P0041|PASS P0041|FAIL P0041|ROW|FAIL \(c/d\))|^RESULT" | head -20
printf '%s\n' "$P0041_MUT" | grep -Fq "FAIL P0041 recovery" \
  || { echo "COVERAGE FAILURE: MUT_SRCWT_VALIDATES did not corrupt the recovered erased row" >&2; exit 1; }
printf '%s\n' "$P0041_MUT" | grep -Fq "in 508/512 entries" \
  || { echo "COVERAGE FAILURE: MUT_SRCWT_VALIDATES died with the wrong stale-beat signature" >&2; exit 1; }
printf '%s\n' "$P0041_MUT" | grep -Fq "RESULT: FAIL" \
  || { echo "COVERAGE FAILURE: MUT_SRCWT_VALIDATES passed the dedicated recovery case" >&2; exit 1; }
echo "SRCWT_VALIDATES MUTANT KILLED: the recovered erased row exposes the partially valid source cache."

echo
echo "== MUTATION -DMUT_BEAMERASE_ABS_ROW0 (pre-P0033 absolute-row-0 + always-armed trigger) =="
# Restores EXACTLY the shipped-v9 behavior: er_base forced to 0 and the blanking gate removed.
# base=0/isrlat=0 must STILL pass (that is why the shipped gate never saw this); every other
# corner must die.  Two independent signatures are required, one per failure mode:
#   base=80 isrlat=0    -> the bottom 80 displayed rows (absolute 400..478) are never erased
#   base=80 isrlat=4000 -> the engine erases absolute rows 0.. (the HUD) DURING blanking
iverilog -g2012 -DMUT_BEAMERASE_ABS_ROW0 -s tb_zunit_beamerase_base \
  -o "$T/tb_base_mut.vvp" "${BASE_SRC[@]}"
echo "-- mutant base=0 isrlat=0 (must STILL pass -- proves the mutant is not a blunt breakage)"
run_base "$T/tb_base_mut.vvp" 0 0 PASS
echo "-- mutant base=80 isrlat=0 (must die: bottom rows never erased)"
run_base "$T/tb_base_mut.vvp" 80 0 FAIL
echo "-- mutant base=80 isrlat=4000 (must die: HUD erased during blanking)"
run_base "$T/tb_base_mut.vvp" 80 4000 FAIL
echo "ABS_ROW0 MUTANT KILLED at base=80 on both isrlat corners, while base=0/isrlat=0 still passes."

echo
echo "== COST PROBE: the NON-shipping USE_SDRAM_VRAM bulk sweep (measurement, for the handoff) =="
iverilog -g2012 -s tb_zunit_bulkerase_cost -o "$T/tb_zunit_bulkerase_cost.vvp" \
  "$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/sim/sdram_model.sv" "$ROOT/sim/tb_zunit_bulkerase_cost.sv"
BULK="$(vvp "$T/tb_zunit_bulkerase_cost.vvp")"
printf '%s\n' "$BULK" | grep -E "^\[bulk\]|^RESULT"
printf '%s\n' "$BULK" | grep -Fq "RESULT: PASS" \
  || { echo "COST PROBE FAILED" >&2; exit 1; }

if [[ "${BASE_RED:-0}" == 1 ]]; then
  echo
  echo "RESULT: GATE RED -- the P0033 base sweep failed on production RTL."
  exit 1
fi
if [[ "${PROD_RED:-0}" == 1 ]]; then
  echo
  echo "RESULT: GATE RED against the current production RTL (see the ROW ... WRONG lines above)."
  exit 1
fi
echo
echo "RESULT: beam-locked autoerase contract GREEN on production RTL, mutant killed."
