#!/usr/bin/env python3
"""Byte-diff the RTL (zunit_dma.sv) POST frame-buffer window against MAME 0.280's
captured POST window, for every real attract blit.  NO tolerance.

Oracle  = mame-trace/goldens/narc_blit_capture.txt (frozen MAME real blits).
DUT out = dut.txt (ordered FB writes dumped by tb_zunit_dma_realblit.sv).

The expected-window construction and the PRE/POST 16-bit-entry addressing are
taken verbatim from replay_diff.replay_one: exp[y][x-x0] with the identical rect
bound (x0<=x<=x1 and y0<=y<=y1), compared over y in range(y0,y1+1) against
post[y].  The ONLY substitution vs replay_diff is the write source: the RTL's
actual FB writes replace dma_golden.dma_blit's writes -- so this gate diffs the
RTL against the real MAME capture, not against the Python golden.

A DUT write outside the captured rect, or a DUT gfx fetch outside the captured
span (oob flag from the TB), is a HARD FAIL (same contract as replay_diff).

Prints "<pass>/<n> byte-exact"; exit 0 iff every blit is byte-exact (and n==NBLITS
matches the golden replay's count).
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
GOLDEN_DIR = os.path.abspath(os.path.join(
    HERE, "..", "..", "..", "mame-trace", "blitter_golden"))
sys.path.insert(0, GOLDEN_DIR)
from replay_diff import parse_capture, DEFAULT  # noqa: E402

CAP = os.environ.get("CAPTURE", DEFAULT)
DUT = os.path.join(HERE, "dut.txt")
FB_AW = 18                      # zunit_pkg FB_ADDR_W; ty = addr>>9, tx = addr&0x1FF


def parse_dut(path):
    """Return list of blits, each = {"oob": bool, "wr": [(tx,ty,val), ...]}."""
    blits = []
    cur = None
    with open(path) as f:
        for line in f:
            p = line.split()
            if not p:
                continue
            if p[0] == "BLIT":
                # BLIT <c> <nwr> <oob>
                cur = {"oob": p[3] != "0", "wr": []}
                blits.append(cur)
            else:
                addr = int(p[0], 16)
                val = int(p[1], 16)
                tx = addr & 0x1FF
                ty = (addr >> 9) & 0x1FF
                cur["wr"].append((tx, ty, val))
    return blits


def diff_one(cap, dut):
    """Return list of mismatch strings (empty = byte-exact)."""
    x0, y0, x1, y1 = cap["rect"]
    errs = []
    if dut["oob"]:
        return ["  HARD FAIL: DUT fetched gfx byte outside captured span"]

    # expected post = pre + DUT writes (write order; later writes win) -- the
    # exact exp construction / addressing from replay_diff.replay_one.
    exp = {y: list(row) for y, row in cap["pre"].items()}
    for tx, ty, val in dut["wr"]:
        if not (x0 <= tx <= x1 and y0 <= ty <= y1):
            return [f"  HARD FAIL: DUT wrote ({tx},{ty}) outside captured rect "
                    f"({x0},{y0})-({x1},{y1})"]
        exp[ty][tx - x0] = val & 0xFFFF

    for y in range(y0, y1 + 1):
        got = cap["post"][y]
        want = exp[y]
        for i, (w, g) in enumerate(zip(want, got)):
            if w != g:
                errs.append(f"  ({x0 + i},{y}): rtl {w:04X} != mame {g:04X}")
                if len(errs) >= 8:
                    errs.append("  ... (truncated)")
                    return errs
    return errs


def main():
    caps = parse_capture(CAP)
    duts = parse_dut(DUT)
    if len(caps) != len(duts):
        print(f"FAIL: blit count mismatch capture={len(caps)} dut={len(duts)}")
        return 1

    n = len(caps)
    npass = 0
    for cap, dut in zip(caps, duts):
        errs = diff_one(cap, dut)
        cmd = cap["regs"][0]
        tag = "OK " if not errs else "FAIL"
        print(f"[{tag}] blit n={cap['meta']['n']} CMD={cmd:04X} "
              f"key={cap['meta']['key']} rect={cap['rect']}")
        if errs:
            print("\n".join(errs))
        else:
            npass += 1

    print(f"\n{npass}/{n} byte-exact")
    ok = (npass == n and n >= 6)
    print("GATE: " + ("PASS -- RTL POST windows byte-exact vs MAME real blits"
                      if ok else "FAIL"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
