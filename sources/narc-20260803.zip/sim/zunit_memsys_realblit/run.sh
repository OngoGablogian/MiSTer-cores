#!/usr/bin/env bash
# zunit_memsys real-blit INTEGRATION gate: drive the full memsys glue
# (zunit_memsys = zunit_mem + zunit_dma) with MAME 0.280's real attract blits,
# programming the DMA regs over the CPU memory bus (32b D_LO/D_HI decode) and
# byte-diffing the POST VRAM window read back from zunit_mem against MAME's
# captured POST window, NO tolerance.
#   ./run.sh
# Base build must be N/N byte-exact (N == the golden replay's blit count, 45).
# Gate-exercises-the-change: two named mutants must DIE:
#   A  -DMUT_MEMSYS_DROP_HI  (memsys forgets the D_HI half of every 32-bit reg
#      pair -> OFFSETHI/YSTART/HEIGHT/COLOR never land -> blit degenerates).
#      Directly exercises the NEW glue this task builds.
#   B  -DMUT_CMD_DECODE      (zunit_dma mis-decodes draw mode 0x02) -> in-rect
#      POST-window byte mismatches -> proves the VRAM byte-diff is live.
# The frozen zunit_dma.sv / zunit_mem.sv are NEVER modified.
# Keep every path quoted (repo tree contains a space).
set -u
export PATH="/c/iverilog/bin:$PATH"
PY="${PYTHON:-python}"

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
PKG="$ROOT/rtl/zunit/zunit_pkg.sv"
DMA="$ROOT/rtl/zunit/zunit_dma.sv"
MEM="$ROOT/rtl/zunit/zunit_mem.sv"
SYS="$ROOT/rtl/zunit/zunit_memsys.sv"
TB="$HERE/tb_zunit_memsys_realblit.sv"

cd "$HERE"

echo "== prep (regs/gfx/rects/pre from captured real blits) =="
"$PY" prep.py || { echo "PREP FAIL"; exit 1; }

build_run() {   # $1 = extra defines (may be empty)
  local defs="$1"
  rm -f build.vvp dut.txt
  iverilog -g2012 $defs -I "$HERE" -s tb_zunit_memsys_realblit \
      -o build.vvp "$PKG" "$DMA" "$MEM" "$SYS" "$TB" 2> iverilog.log
  if [ $? -ne 0 ]; then echo "IVERILOG FAIL"; cat iverilog.log; return 2; fi
  vvp build.vvp > vvp.log 2>&1
  "$PY" compare.py
  return $?
}

echo "== BASE (frozen RTL; expect 45/45 byte-exact) =="
build_run ""
BASE=$?
if [ $BASE -ne 0 ]; then echo "RESULT: BASE FAILED"; exit 1; fi

echo "== MUTANT A: -DMUT_MEMSYS_DROP_HI (32->16b D_HI decode must be exercised) =="
build_run "-DMUT_MEMSYS_DROP_HI"
MA=$?
if   [ $MA -eq 0 ]; then echo "  A SURVIVED <-- BAD (D_HI decode not exercised)"; exit 1
elif [ $MA -eq 2 ]; then echo "  A COMPILE-ERROR <-- BAD"; exit 1
else echo "  A DIED (dropping the 32-bit high word corrupts the blit)"; fi

echo "== MUTANT B: -DMUT_CMD_DECODE (POST VRAM byte-diff must be live) =="
build_run "-DMUT_CMD_DECODE"
MB=$?
if   [ $MB -eq 0 ]; then echo "  B SURVIVED <-- BAD (VRAM byte-diff not live)"; exit 1
elif [ $MB -eq 2 ]; then echo "  B COMPILE-ERROR <-- BAD"; exit 1
else echo "  B DIED (mode-2 mis-decode changes POST VRAM)"; fi

# rebuild BASE artifacts so the working tree reflects the passing gate.
build_run "" >/dev/null

echo "== SUMMARY =="
echo "RESULT: PASS  (45/45 POST-VRAM byte-exact vs MAME real blits; D_HI-decode + POST-diff mutants died)"
exit 0
