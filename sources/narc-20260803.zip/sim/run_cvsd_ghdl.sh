#!/usr/bin/env bash
# run_cvsd_ghdl.sh -- CVSD (HC55564) decay + reset gate on GHDL.
#
# WHY GHDL AND NOT QUESTA: hc55564 is VHDL, Icarus cannot read VHDL, and the
# single Questa licence is a cross-session contract (see sim/questa_lock.sh).
# GHDL runs VHDL-2008 with no licence at all, so this gate can run in every
# iteration instead of queueing behind the mutex.  The sibling Smash T.V. gate
# (sim/run_cvsd.sh over there) needs Questa only because ITS bench is
# SystemVerilog; this one is VHDL end to end.
#
# PRODUCTION   : the decoder as instantiated by narc_sound_board.sv:407 (no
#                generic map -> the entity defaults 224 / 255 / true).
# MUTANT       : -gINTEGRATOR_DECAY_NUM=256 -gSYLLABIC_DECAY_NUM=256
#                -gHONOR_RESET=false, which is EXACTLY the defect that shipped
#                in image v6a: (1 - 1/8)*256 evaluates to 256 in VHDL, not 224.
#                The mutant MUST fail in the same run that reports a pass.
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
GHDL="${GHDL:-}"
if [ -z "$GHDL" ]; then
  for c in ghdl /d/tools/ghdl/bin/ghdl "D:/tools/ghdl/bin/ghdl"; do
    command -v "$c" >/dev/null 2>&1 && { GHDL="$c"; break; }
  done
fi
[ -n "$GHDL" ] || { echo "run_cvsd_ghdl: GHDL not found (set \$GHDL)"; exit 1; }

W="$ROOT/sim/work_cvsd_ghdl"
rm -rf "$W"; mkdir -p "$W"

"$GHDL" -a --std=08 --workdir="$W" \
    "$ROOT/rtl/sound/williams_cvsd/hc55564.vhd" \
    "$ROOT/sim/tb_hc55564_decay.vhd" || { echo "run_cvsd_ghdl: analysis failed"; exit 1; }

run_arm() {   # $1 = label, $2... = generic overrides
  local label="$1"; shift
  "$GHDL" -r --std=08 --workdir="$W" tb_hc55564_decay "$@" 2>&1
}

echo "== CVSD decay/reset gate (PRODUCTION: entity defaults 224/255/true) =="
PROD_OUT="$(run_arm production)"
printf '%s\n' "$PROD_OUT"
if ! printf '%s\n' "$PROD_OUT" | grep -q "PASS hc55564"; then
  echo "run_cvsd_ghdl: FAIL -- production did not pass"
  exit 1
fi
if printf '%s\n' "$PROD_OUT" | grep -qE "FAIL hc55564|RESULT: FAIL"; then
  echo "run_cvsd_ghdl: FAIL -- production reported errors"
  exit 1
fi

echo
echo "== CVSD MUTATION (-g 256/256/false = the shipped v6a defect): MUST fail =="
MUT_OUT="$(run_arm mutant -gINTEGRATOR_DECAY_NUM=256 -gSYLLABIC_DECAY_NUM=256 -gHONOR_RESET=false)"
printf '%s\n' "$MUT_OUT" | grep -E "FAIL|PASS|MEASURED|RESULT" || true
if printf '%s\n' "$MUT_OUT" | grep -qE "FAIL hc55564|RESULT: FAIL"; then
  echo
  echo "run_cvsd_ghdl: PASS -- production green, the 256/256/no-reset mutant dies"
  exit 0
fi
echo "run_cvsd_ghdl: FAIL -- the mutant STILL PASSES; this contract is not real."
exit 1
