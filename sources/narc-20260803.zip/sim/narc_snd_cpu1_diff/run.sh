#!/usr/bin/env bash
# run.sh -- iverilog-only slave-6809 (cpu1) PER-INSTRUCTION diff vs the MAME
# 0.280 :narcsnd:cpu1 golden. NO Questa (mc6809is + jt51 are Verilog; hc55564
# VHDL blackboxed). Builds the gate + a MUTANT_INIT_CC build that MUST die.
# Overall exit 0 only when gate=PASS AND mutant=FAIL.
#
# Unlike cpu0, the slave never touches the jt51/YM2151, so there is NO YM-busy-
# poll timing artifact, and the captured golden takes ZERO interrupts (fully
# self-driven: reset init + ROM-checksum walk). The standalone DUT is therefore
# expected to reproduce the golden bit-exact to golden exhaustion (deep lockstep).
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
SND="$ROOT/rtl/sound"
IVL="${IVERILOG:-/c/iverilog/bin/iverilog}"
VVP="${VVP:-/c/iverilog/bin/vvp}"

cd "$HERE"
mkdir -p build
python make_hex.py
# pack the golden (default: full 150000 = golden exhaustion; arg overrides).
NPACK="${NPACK:-150000}"
python pack_golden.py "$NPACK"
# pack the CVSD digit-stream golden (slave HC55516 bit-bang writes).
python pack_cvsd.py

JT51=()
while IFS= read -r f; do JT51+=("$f"); done < <(find "$SND/jt51/hdl" -maxdepth 1 -name '*.v' | sort)

build_run() { # $1=extra defines  $2=label  $3=out vvp
  "$IVL" -g2012 -DJT51_ONLYTIMERS $1 -o "build/$3" -s tb_snd_cpu1_diff \
    -I "$HERE" \
    "$SND/narc_sound_pkg.sv" \
    "${JT51[@]}" \
    "$SND/williams_cvsd/mc6809is.v" \
    "$SND/sim/hc55564_stub.v" \
    "$SND/narc_sound_bank.sv" \
    "$SND/narc_sound_latch.sv" \
    "$SND/narc_sound_board.sv" \
    "$HERE/tb_snd_cpu1_diff.sv"
  echo "===== $2 ====="
  "$VVP" "build/$3"
}

GATE_LOG="$(build_run "" "GATE (faithful per-instruction diff)" diff.vvp)"
echo "$GATE_LOG"
MUT_LOG="$(build_run "-DMUTANT_INIT_CC" "MUTANT (wrong CC init bit)" diff_mut.vvp)"
echo "$MUT_LOG"

gate_pass=$(echo "$GATE_LOG" | grep -c "^RESULT: PASS" || true)
mut_pass=$( echo "$MUT_LOG"  | grep -c "^RESULT: PASS" || true)
frontier=$(echo "$GATE_LOG" | sed -n 's/^FRONTIER: bit-exact=\([0-9]*\).*/\1/p' | tail -1)
mut_front=$(echo "$MUT_LOG" | sed -n 's/^FRONTIER: bit-exact=\([0-9]*\).*/\1/p' | tail -1)

# ---- CVSD digit-stream gate (slave HC55516 bit-bang, williamssound.cpp:493-494) --
# The slave reaches its self-driven CVSD idle loop at instr ~1.45M, so each CVSD run
# is ~13 min on iverilog. Set NARC_CVSD_SKIP=1 to skip (the per-instruction gate above
# still runs). MUTANT_CVSD_DIGIT inverts the codec digit -> MUST die at the first CLR.
cvsd_pass=1; cvsd_mut_pass=0
if [ "${NARC_CVSD_SKIP:-0}" != "1" ]; then
  CV_LOG="$(build_run "-DCVSD_STREAM" "CVSD-GATE (slave digit-stream diff)" cvsd.vvp)"
  echo "$CV_LOG"
  CVM_LOG="$(build_run "-DCVSD_STREAM -DMUTANT_CVSD_DIGIT" "CVSD-MUTANT (inverted digit)" cvsd_mut.vvp)"
  echo "$CVM_LOG"
  cvsd_pass=$(echo "$CV_LOG"  | grep -c "^RESULT: PASS" || true)
  cvsd_mut_pass=$(echo "$CVM_LOG" | grep -c "^RESULT: PASS" || true)
  cvsd_front=$(echo "$CV_LOG" | sed -n 's/^FRONTIER: cvsd bit-exact=\([0-9]*\).*/\1/p' | tail -1)
fi

echo "================================================================"
if [ "$gate_pass" -ge 1 ] && [ "$mut_pass" -eq 0 ] && \
   [ "$cvsd_pass" -ge 1 ] && [ "$cvsd_mut_pass" -eq 0 ]; then
  echo "CPU1-DIFF: PASS  (bit-exact per-instruction to golden exhaustion vs"
  echo "                  :narcsnd:cpu1 golden, wrong-CC mutant DIES;"
  echo "                  CVSD digit-stream bit-exact vs slave golden, inverted-digit mutant DIES)"
  exit 0
fi
if [ "$cvsd_mut_pass" -ne 0 ]; then echo "MACHINERY FAIL: CVSD mutant did NOT die"; exit 1; fi
if [ "${NARC_CVSD_SKIP:-0}" != "1" ] && [ "$cvsd_pass" -lt 1 ]; then
  echo "CVSD-GATE: bit_exact=$cvsd_front (short of target) -- measured slave-CVSD frontier"
fi
# machinery-proven partial: mutant MUST die (proves the diff discriminates), gate
# bit-exact to a measured frontier. A frontier short of target is reported, NOT
# fudged -- and for the slave (no YM env artifact, zero golden interrupts) any
# frontier is a genuine slave divergence to be characterized two-sided (DUT vs
# MAME), never tolerance-absorbed.
echo "CPU1-DIFF: gate_bit_exact=$frontier  mutant_dies=$([ "$mut_pass" -eq 0 ] && echo yes || echo NO)"
if [ "$mut_pass" -ne 0 ]; then echo "MACHINERY FAIL: mutant did NOT die"; exit 1; fi
echo "PARTIAL: bit-exact to instr $frontier; mutant dies at instr $mut_front."
exit 2
