#!/usr/bin/env python3
# make_hex.py -- extract the NARC slave sound ROMs (rev2 u35/u36/u37/u38, 64KB
# each) from narc.zip into $readmemh hex files for the cpu1 per-instruction diff.
# Gospel: midyunit.cpp:1456-1465 region "narcsnd:cpu1" (slave sound CPU):
#   u35 @0x10000 (+reload 0x20000), u36 @0x30000 (+reload 0x40000),
#   u37 @0x50000 (+reload 0x60000), u38 @0x70000 (+reload 0x80000);
#   slaveupper base rom[0x8C000]=u38[0xC000] (williamssound.cpp:561),
#   reset vec rom[0x8FFFE:F]=u38[0xFFFE:F]=C7EE (== golden seq0 PC).
import zipfile, os
Z   = "D:/deck/fpga/NARC/roms/narc.zip"
OUT = os.path.join(os.path.dirname(__file__), "build")
ROMS = {"rev2_narc_sound_rom_u35.u35": "narc_snd_u35.hex",
        "rev2_narc_sound_rom_u36.u36": "narc_snd_u36.hex",
        "rev2_narc_sound_rom_u37.u37": "narc_snd_u37.hex",
        "rev2_narc_sound_rom_u38.u38": "narc_snd_u38.hex"}
os.makedirs(OUT, exist_ok=True)
z = zipfile.ZipFile(Z); names = set(z.namelist())
for src, dst in ROMS.items():
    key = src if src in names else next(n for n in names if n.endswith("/" + src))
    data = z.read(key)
    assert len(data) == 0x10000, f"{src}: expected 64KB, got {len(data)}"
    with open(f"{OUT}/{dst}", "w") as f:
        f.write("\n".join(f"{b:02x}" for b in data))
    print(f"{key} -> {OUT}/{dst}  reset_vec={data[0xFFFE]:02x}{data[0xFFFF]:02x}")
print("done")
