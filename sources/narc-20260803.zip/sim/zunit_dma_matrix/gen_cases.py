#!/usr/bin/env python3
"""Generate the zunit_dma cross-diff matrix + the dma_golden.py per-pixel VRAM
oracle for every case.

Cross-diff pair (both transcribed BLIND from the same gospel, independently):
  RTL  = rtl/zunit/zunit_dma.sv          (from midyunit_v.cpp + DMA.DOC)
  gold = mame-trace/blitter_golden/dma_golden.py  (from midyunit_v.cpp + DMA.DOC)

Emits (into this dir):
  gfx.hex          synthetic zero-containing 8bpp source, GFX_N bytes ($readmemh)
  cases.hex        NCASES*10 register words, row-major ($readmemh, flat)
  matrix_meta.svh  localparams NCASES / GFX_N / GFX_MASK for the TB
  golden.txt       per-case ordered VRAM write list from dma_golden.dma_blit

Matrix: 16 modes x flipX x flipY x 5 clip scenarios = 320 cases, which INCLUDES
the acceptance-required edges that pin the 0.280 dead-source-advance quirk
two-sidedly:  ypos<0 (top),  non-flip xpos<0 (left),  flip xpos>=512 (right).
"""
import os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
GOLDEN_DIR = r"D:/deck/fpga/NARC/mame-trace/blitter_golden"
sys.path.insert(0, GOLDEN_DIR)
import dma_golden  # noqa: E402

GFX_N    = 0x4000
GFX_MASK = GFX_N - 1

# ---- synthetic 8bpp source (zeros for the transparency modes, full 8-bit
# nonzero values for the 8bpp copy modes; all-zero stretch at the top). --------
gfx = [0] * GFX_N
for i in range(GFX_N):
    if i >= 0x3000:      gfx[i] = 0
    elif i % 3 == 0:     gfx[i] = 0
    else:
        v = (i * 7 + 3) & 0xFF
        gfx[i] = v if v else 1

def gfx_read(o):
    return gfx[o & GFX_MASK]

def u16(v):
    return v & 0xFFFF

# ---- case builder ------------------------------------------------------------
# Fixed source base with headroom for the flipX rewind: gfxoffset =
# 0x02000000 + BASE_BITS ; byte offset after normalize = BASE_BITS>>3.
BASE_BITS = 0x4000          # -> byte offset 0x800
OFFHI     = (0x02000000 + BASE_BITS) >> 16          # 0x0200
OFFLO     = (0x02000000 + BASE_BITS) & 0xFFFF       # 0x4000
PAL, COL  = 0x12, 0x34

def scenario(sc, flipx):
    """Return (rowbytes, xstart, ystart, width, height) for clip scenario sc.
    Chosen so the branch actually executes for the given flip direction."""
    W, H = 24, 6
    if sc == 0:                      # no clip
        return (0, 100, 50, W, H)
    if sc == 1:                      # top clip: ypos<0 (both flips)
        return (0, 100, -3, W, H)
    if sc == 2:                      # left/right edge (the quirk-pinning cases)
        if not flipx:
            return (0, -5, 60, W, H)         # non-flip xpos<0  (dma_w:493)
        else:
            # xpos0 = xs+W-1 = 528 >= 512 -> right clip; leaves W-17=7 drawn
            # (dma_w:504-508). A non-degenerate flip right-clip so the dead
            # source-advance at :507 is exercised two-sidedly.
            return (0, 505, 60, W, H)        # flip xpos>=512   (dma_w:504)
    if sc == 3:                      # bottom clip: ypos+height>512
        return (0, 120, 509, W, H)
    # sc == 4: far edge
    if not flipx:
        return (0, 500, 70, W, H)            # non-flip xpos+width>512 (dma_w:499)
    else:
        return (0,   0, 70, W, H)            # flip xpos0-width<0      (dma_w:510)

cases = []      # each = list of 10 reg words
for mode in range(16):
    for flipx in (0, 1):
        for flipy in (0, 1):
            for sc in range(5):
                rb, xs, ys, w, h = scenario(sc, flipx)
                # flipY exercises a negative row stride (bit5 itself is inert in
                # MAME dma_draw; the negative ROWBYTES does the vertical work).
                if flipy:
                    rb = -0x100
                cmd = 0x8000 | (flipy << 5) | (flipx << 4) | mode
                regs = [0]*10
                regs[0] = u16(cmd)
                regs[1] = u16(rb)
                regs[2] = u16(OFFLO)
                regs[3] = u16(OFFHI)
                regs[4] = u16(xs)
                regs[5] = u16(ys)
                regs[6] = u16(w)
                regs[7] = u16(h)
                regs[8] = u16(PAL)
                regs[9] = u16(COL)
                cases.append(regs)

NCASES = len(cases)

# ---- run the golden per case, capture ordered VRAM writes --------------------
gold_lines = []
for c, regs in enumerate(cases):
    writes = []
    def vram_write(x, y, val, _w=writes):
        addr = ((y & 0x1FF) * 512 + (x & 0x1FF)) & 0x3FFFF
        _w.append((addr, val & 0xFFFF))
    dma_golden.dma_blit(regs, gfx_read, vram_write)
    gold_lines.append("CASE %d %d" % (c, len(writes)))
    for a, d in writes:
        gold_lines.append("%05X %04X" % (a, d))

# ---- write artifacts ---------------------------------------------------------
with open(os.path.join(HERE, "gfx.hex"), "w") as f:
    f.write("\n".join("%02X" % b for b in gfx) + "\n")

with open(os.path.join(HERE, "cases.hex"), "w") as f:
    for regs in cases:
        f.write("\n".join("%04X" % r for r in regs) + "\n")

with open(os.path.join(HERE, "matrix_meta.svh"), "w") as f:
    f.write("// AUTO-GENERATED by gen_cases.py -- do not edit.\n")
    f.write("localparam int NCASES   = %d;\n" % NCASES)
    f.write("localparam int GFX_N    = 'h%X;\n" % GFX_N)
    f.write("localparam int GFX_MASK = 'h%X;\n" % GFX_MASK)

with open(os.path.join(HERE, "golden.txt"), "w") as f:
    f.write("\n".join(gold_lines) + "\n")

print("gen_cases: NCASES=%d GFX_N=0x%X golden writes=%d"
      % (NCASES, GFX_N, sum(1 for l in gold_lines if " " in l and not l.startswith("CASE"))))
