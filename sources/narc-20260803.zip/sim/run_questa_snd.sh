#!/usr/bin/env bash
# Compile + run the Williams CVSD sound-board sim (mixed VHDL/Verilog, Questa).
#   ./run_questa_snd.sh [tb_snd_board] [+ARGS...]
set -e
TB="${1:-tb_snd_board}"; shift || true
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SND="$ROOT/rtl/sound"

for d in /c/altera/*/questa_fse/win64 /c/altera_pro/*/questa_fse/win64; do
  [ -x "$d/vlog.exe" ] && { VLOG="$d/vlog"; VCOM="$d/vcom"; VSIM="$d/vsim"; VLIB="$d/vlib"; break; }
done
[ -n "$VLOG" ] || { echo "Questa not found"; exit 1; }
unset LM_LICENSE_FILE MGLS_LICENSE_FILE

cd "$ROOT/sim"
rm -rf work_snd; "$VLIB" work_snd >/dev/null

# jt51 (Verilog): top + everything it pulls in (hdl/*.v, no filter/deprecated).
JT51=()
while IFS= read -r f; do JT51+=("$f"); done < <(find "$SND/jt51/hdl" -maxdepth 1 -name '*.v' | sort)

"$VLOG" -quiet -work work_snd "${JT51[@]}" \
  "$SND/williams_cvsd/mc6809is.v" \
  "$SND/smashtv_snd_rom.sv" \
  "$ROOT/sim/$TB.sv"

"$VCOM" -2008 -quiet -work work_snd \
  "$SND/williams_cvsd/gen_ram.vhd" \
  "$SND/williams_cvsd/hc55564.vhd" \
  "$SND/williams_cvsd/pia6821.vhd" \
  "$SND/williams_cvsd/williams_cvsd_board.vhd"

echo "running $TB ..."
"$VSIM" -c -quiet -work work_snd -do "run -all; quit -f" "$TB" "$@" 2>&1 | grep -vE "^# (Loading|//|\*\* Note)"
