#!/usr/bin/env bash
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/sim/build"
mkdir -p "$OUT"
export PATH="/c/iverilog/bin:$PATH"

echo "=== BASE (real narc.zip U41/U23 bytes, no mutation) ==="
iverilog -g2012 -DSIM_NO_ALTERA -s tb_zunit_rom_chksum_audit \
  -o "$OUT/tb_zunit_rom_chksum_audit.vvp" \
  "$ROOT/rtl/zunit/zunit_rom_chksum_audit.sv" \
  "$ROOT/sim/tb_zunit_rom_chksum_audit.sv"
(cd "$ROOT/sim" && vvp "$OUT/tb_zunit_rom_chksum_audit.vvp")

echo ""
echo "=== MUTANT (block5 byte corrupted -- must isolate to w2, not w1) ==="
iverilog -g2012 -DSIM_NO_ALTERA -DMUT_CORRUPT_BLOCK5 -s tb_zunit_rom_chksum_audit \
  -o "$OUT/tb_zunit_rom_chksum_audit_mut.vvp" \
  "$ROOT/rtl/zunit/zunit_rom_chksum_audit.sv" \
  "$ROOT/sim/tb_zunit_rom_chksum_audit.sv"
(cd "$ROOT/sim" && vvp "$OUT/tb_zunit_rom_chksum_audit_mut.vvp")

echo ""
echo "RESULT: zunit_rom_chksum_audit gate PASS (base bit-exact vs real ROM checksums; mutant isolated)"
