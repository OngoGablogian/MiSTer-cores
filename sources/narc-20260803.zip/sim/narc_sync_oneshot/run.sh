#!/usr/bin/env bash
# run.sh - iverilog-only 74LS123 audio_sync one-shot auto-clear + read() readback
# gate (G4 last sound sub-gate). NO Questa. hc55564 VHDL blackboxed via
# rtl/sound/sim/hc55564_stub.v; jt51 built with JT51_ONLYTIMERS. The board's two
# 6809s + jt51 are frozen (clock-enables 0); the audio_sync one-shot clear path
# (os_m/os_s -> sync_clr/mask -> narc_sound_latch &=~mask) is REAL RTL.
#
# Three builds:
#   (1) gate                      -> RESULT: PASS (F1..F4 vs independent golden)
#   (2) MUTANT_DROP_SYNC_CLEAR    -> RESULT: FAIL (one-shot never clears; MUST die)
#   (3) MUTANT_WRONG_SHIFT        -> RESULT: FAIL (read() misread; MUST die)
# Overall exit 0 only when gate=PASS AND both mutants=FAIL.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
SND="$ROOT/rtl/sound"
IVL="${IVERILOG:-/c/iverilog/bin/iverilog}"
VVP="${VVP:-/c/iverilog/bin/vvp}"

cd "$HERE"
mkdir -p build

JT51=()
while IFS= read -r f; do JT51+=("$f"); done < <(find "$SND/jt51/hdl" -maxdepth 1 -name '*.v' | sort)

build_run() { # $1 = extra defines, $2 = label, $3 = out vvp
  "$IVL" -g2012 -DJT51_ONLYTIMERS $1 -o "build/$3" -s tb_narc_sync_oneshot \
    "$SND/narc_sound_pkg.sv" \
    "${JT51[@]}" \
    "$SND/williams_cvsd/mc6809is.v" \
    "$SND/sim/hc55564_stub.v" \
    "$SND/narc_sound_bank.sv" \
    "$SND/narc_sound_latch.sv" \
    "$SND/narc_sound_board.sv" \
    "$HERE/tb_narc_sync_oneshot.sv"
  echo "===== $2 ====="
  "$VVP" "build/$3"
}

GATE_LOG="$(build_run "" "GATE (one-shot auto-clear + read() readback)" os.vvp)"
echo "$GATE_LOG"
MUT1_LOG="$(build_run "-DMUTANT_DROP_SYNC_CLEAR" "MUTANT (drop sync-clear)" os_mut1.vvp)"
echo "$MUT1_LOG"
MUT2_LOG="$(build_run "-DMUTANT_WRONG_SHIFT" "MUTANT (wrong read() shift)" os_mut2.vvp)"
echo "$MUT2_LOG"

gate_pass=$(echo "$GATE_LOG" | grep -c "^RESULT: PASS" || true)
mut1_pass=$(echo "$MUT1_LOG" | grep -c "^RESULT: PASS" || true)
mut2_pass=$(echo "$MUT2_LOG" | grep -c "^RESULT: PASS" || true)

echo "================================================================"
if [ "$gate_pass" -ge 1 ] && [ "$mut1_pass" -eq 0 ] && [ "$mut2_pass" -eq 0 ]; then
  echo "G4-ONESHOT: PASS  (gate PASS; drop-sync-clear mutant DIES; wrong-shift mutant DIES)"
  exit 0
else
  echo "G4-ONESHOT: FAIL  (gate=$gate_pass drop_mut=$mut1_pass shift_mut=$mut2_pass)"
  exit 1
fi
