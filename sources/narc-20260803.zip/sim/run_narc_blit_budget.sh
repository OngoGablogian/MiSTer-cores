#!/usr/bin/env bash
# run_narc_blit_budget.sh -- PER-BLIT duration gate for the NARC high-score batch.
#
# WHAT IT ASSERTS
#   Every INDIVIDUAL blit of MAME 0.280's exact frame-1802 high-score batch (one
#   235x40 mode-C clear + the 14 mode-8 glyphs) must retire within
#       4 * width * height  clocks
#   MAME arms its DMA timer for 41 ns * width * height per dma_draw()
#   (mame-gospel/midyunit_v.cpp:523). At 96 MHz that is 3.936 clk/px, so the
#   4 clk/px budget used here is a rounded-UP, strictly-generous restatement.
#
# WHY PER BLIT
#   Each high-score glyph is drawn by a forked process whose lifetime IS its
#   blit duration (CLONE_OURSELVES -> GETPRC, NARC/NARCSPRY.ASM). If blits take
#   longer than the pace the game assumes, processes retire slower than they are
#   created, the fixed pool drains monotonically, and GETPRC eventually finds
#   NO_ONE_HOME -> freeze. The cabinet symptom is exactly that: the top rows
#   draw at speed, then it degrades to a slideshow, then it freezes.
#
# WHY THE OLD GATE MISSED IT
#   tb_narc_hiscore_pipeline compared only the BATCH TOTAL against MAME's
#   56,869 clocks. The single 38,867-clock background fill subsidises the
#   glyphs, so the batch passes with every glyph individually over budget --
#   it would still pass with glyphs at 2x. It measures the wrong quantity.
#
# THIS GATE IS NOT NEGOTIABLE
#   No tolerance term, no excluded blit, no averaging, no plusarg, no `ifdef.
#   The ONLY acceptable way to turn it green is to make the hardware faster.
#
# STATUS: production D_WRITE_FIFO path must stay GREEN here before Quartus.
#
#   ./sim/run_narc_blit_budget.sh
# Exit 0 only when every blit is inside budget.
set -eu
export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PY="${PYTHON:-python}"

# Unique work dir per invocation: the shared .vvp names collide across
# concurrently running agents.
T="$(mktemp -d "${TMPDIR:-/tmp}/narc_blit_budget.XXXXXX")"
trap 'rm -rf "$T"' EXIT

"$PY" "$ROOT/sim/prep_narc_hiscore_gfx.py"

SRC=("$ROOT/rtl/zunit/zunit_pkg.sv" \
  "$ROOT/rtl/zunit/zunit_dma.sv" \
  "$ROOT/rtl/zunit/narc_fb_beat_fifo.sv" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/yunit_src_cache.sv" \
  "$ROOT/rtl/sdram/yunit_sdram_adapter.sv" \
  "$ROOT/rtl/sdram/sdram_stock_shipped.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_narc_hiscore_pipeline.sv")

echo "== NARC per-blit budget: 4*width*height clocks, every blit, no exceptions =="
iverilog -g2012 -DUSE_DDR3_VRAM -s tb_narc_hiscore_pipeline \
  -o "$T/tb_narc_blit_budget.vvp" "${SRC[@]}"
OUT="$(cd "$ROOT" && vvp "$T/tb_narc_blit_budget.vvp")"

printf '%s\n' "$OUT" | grep -E \
  "NARC-HISCORE-PIPE|NARC-HISCORE-FBQ|NARC-HISCORE-GLYPH|NARC-BLIT-BUDGET|^FAIL|^RESULT"

# The verdict must be present at all -- a TB that silently stopped emitting it
# is itself a gate failure, not a pass.
if ! printf '%s\n' "$OUT" | grep -Eq "^RESULT: BLIT-BUDGET (PASS|FAIL)"; then
  echo "GATE ERROR: tb_narc_hiscore_pipeline emitted no BLIT-BUDGET verdict." >&2
  exit 2
fi

# Behaviour must still be byte-exact and the batch scoreboards intact; a speed
# change that drops a pixel or a source byte is a FAIL even if timing improves.
for MUST in \
  "src=2580/2580" \
  "writes=11029/11029" ; do
  if ! printf '%s\n' "$OUT" | grep -Fq "$MUST"; then
    echo "GATE ERROR: scoreboard regression, missing '$MUST'." >&2
    exit 2
  fi
done
if printf '%s\n' "$OUT" | grep -Eq "^FAIL HISCORE"; then
  echo "GATE ERROR: high-score pipeline correctness regressed." >&2
  exit 2
fi
if ! printf '%s\n' "$OUT" | grep -Fq \
  "RESULT: PASS -- exact NARC high-score batch meets MAME time through physical SDRAM + DDR3 with scan traffic."; then
  echo "GATE ERROR: high-score pipeline did not emit its exact correctness PASS." >&2
  exit 2
fi
if ! printf '%s\n' "$OUT" | grep -Eq \
  "^NARC-HISCORE-FBQ max=64/64 full-pop-push=[1-9][0-9]*$"; then
  echo "GATE ERROR: production FIFO full-turn coverage was not witnessed." >&2
  exit 2
fi

if printf '%s\n' "$OUT" | grep -Fq "RESULT: BLIT-BUDGET PASS"; then
  echo "RESULT: PASS -- every NARC high-score blit retires within 4*w*h clocks."
  exit 0
fi

echo "RESULT: FAIL -- NARC per-blit budget exceeded (see FAIL NARC-BLIT-BUDGET lines above)." >&2
exit 1
