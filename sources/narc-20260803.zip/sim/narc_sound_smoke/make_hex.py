#!/usr/bin/env python3
# make_hex.py — extract the NARC master sound ROMs (rev2 u4/u5, 64KB each) from
# the user's narc.zip into $readmemh hex files for the master-6809 boot smoke.
#
# Gospel: midyunit.cpp:1449-1454 ROM_START(narc), region "narcsnd:cpu0" (0x90000):
#   u4 @ 0x50000 (0x10000) + RELOAD @ 0x60000
#   u5 @ 0x70000 (0x10000) + RELOAD @ 0x80000
# masterupper base = rom[0x8C000]  (williamssound.cpp:547) -> u5[0xC000..0xFFFF];
# reset vector 0xFFFE/0xFFFF -> rom[0x8FFFE/0x8FFFF] = u5[0xFFFE/0xFFFF].
import zipfile
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
NARC = REPO.parent
Z = NARC / "roms" / "narc.zip"
OUT = Path(__file__).resolve().parent / "build"
ROMS = {
    "rev2_narc_sound_rom_u4.u4": "narc_snd_u4.hex",
    "rev2_narc_sound_rom_u5.u5": "narc_snd_u5.hex",
    # slave cpu1 (midyunit.cpp:1456-1464), region "narcsnd:cpu1" (0x90000):
    #   u35 @0x10000 +reload 0x20000 ; u36 @0x30000 +reload 0x40000
    #   u37 @0x50000 +reload 0x60000 ; u38 @0x70000 +reload 0x80000
    # slaveupper base = rom[0x8C000] (williamssound.cpp:561) -> u38[0xC000..0xFFFF];
    # reset vector 0xFFFE/0xFFFF -> rom[0x8FFFE/0x8FFFF] = u38[0xFFFE/0xFFFF].
    "rev2_narc_sound_rom_u35.u35": "narc_snd_u35.hex",
    "rev2_narc_sound_rom_u36.u36": "narc_snd_u36.hex",
    "rev2_narc_sound_rom_u37.u37": "narc_snd_u37.hex",
    "rev2_narc_sound_rom_u38.u38": "narc_snd_u38.hex",
}
OUT.mkdir(parents=True, exist_ok=True)
z = zipfile.ZipFile(Z)
names = set(z.namelist())
for src, dst in ROMS.items():
    # narc.zip stores rev2 roms at top level; tolerate a subdir prefix too.
    key = src if src in names else next(n for n in names if n.endswith("/" + src))
    data = z.read(key)
    assert len(data) == 0x10000, f"{src}: expected 64KB, got {len(data)}"
    with open(OUT / dst, "w") as f:
        f.write("\n".join(f"{b:02x}" for b in data))
    if dst.endswith("u5.hex") or dst.endswith("u38.hex"):
        who = "u5" if dst.endswith("u5.hex") else "u38"
        print(f"{key} ({len(data)} bytes) -> {OUT}/{dst}  "
              f"reset_vec {who}[FFFE:FFFF]={data[0xFFFE]:02x}{data[0xFFFF]:02x}")
    else:
        print(f"{key} ({len(data)} bytes) -> {OUT}/{dst}")

# ---------------------------------------------------------------------------
# G4-rung-1: extract the master->YM2151 write oracle from the Phase-1 sound
# gospel (mame-trace/goldens/narc_attract_sound_stream.txt). Each Y| line is a
# master 6809 write into the jt51 bus:
#   Y|<idx>|f=..|t=..|PC=..|A=2000|REG|D=14|r=14   (A=2000 REG => a0=0, address)
#   Y|<idx>|f=..|t=..|PC=..|A=2001|DAT|D=30|r=14   (A=2001 DAT => a0=1, data)
# Oracle contract: bit-exact on (a0 REG/DAT + D). We emit the FIRST N writes as
# whitespace-token $readmemh pairs (a0 byte, then D byte) into ym_gospel.mem.
# NO cherry-picking: strictly the leading contiguous Y| prefix, in stream order.
GOSPEL = NARC / "mame-trace" / "goldens" / "narc_attract_sound_stream.txt"
NGOSPEL = 24  # emit leading 24 Y| writes; the TB gate requires the first >=16 exact
toks = []
n = 0
with open(GOSPEL) as g:
    for line in g:
        if not line.startswith("Y|"):
            continue
        parts = line.strip().split("|")
        # parts: ['Y', idx, 'f=3', 't=..', 'PC=..', 'A=2000', 'REG'/'DAT', 'D=14', 'r=14']
        rd = parts[6]                       # REG or DAT
        assert rd in ("REG", "DAT"), f"bad r/d token {rd!r} in: {line!r}"
        a0 = 0 if rd == "REG" else 1
        # cross-check A field agrees with REG/DAT (never trust one alone)
        aval = int(parts[5].split("=")[1], 16)
        assert (aval & 1) == a0, f"A/REG-DAT mismatch: {line!r}"
        dval = int(parts[7].split("=")[1], 16)
        toks.append(f"{a0:02x}")
        toks.append(f"{dval:02x}")
        n += 1
        if n >= NGOSPEL:
            break
assert n == NGOSPEL, f"gospel had only {n} Y| writes (< {NGOSPEL})"
with open(OUT / "ym_gospel.mem", "w") as f:
    f.write("\n".join(toks) + "\n")
print(f"ym_gospel.mem: {NGOSPEL} master->YM writes  first=(a0={toks[0]},D={toks[1]})")
print("done")
