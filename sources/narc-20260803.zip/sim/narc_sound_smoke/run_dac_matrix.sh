#!/usr/bin/env bash
# ============================================================================
# run_dac_matrix.sh — G4 AD7224 DAC1/DAC2 per-command write-stream matrix.
# ----------------------------------------------------------------------------
# The DAC half of the G4 sound gate (sibling of run_ym_matrix.sh). For EACH
# distinct attract host command it:
#   (1) segments the committed gospel sound stream on the SAME L| latch
#       boundaries used by the YM matrix (the global line index is monotonic
#       across L|/Y|/D1|/D2|, so a DAC write's command membership is exactly the
#       L| span it falls in), splitting per channel:
#         D1| = master AD7224 (dac1, williamssound.cpp:477)
#         D2| = slave  AD7224 (dac2, williamssound.cpp:496)
#       and classifies each channel (gen_dac_cmd_sig.py, over the FULL span):
#         CONTENT (uniq>1) = a real PCM waveform  -> bit-exact leading prefix
#         IDLE:VV (uniq==1) = DAC held at const VV -> every DUT write must == VV
#                             (run-LENGTH is a real-time idle-refresh artifact,
#                              the DAC analog of the YM timer-ack COUNT strip)
#         EMPTY   (n==0)   = CPU never touches DAC -> DUT must emit 0
#   (2) injects the command into narc_sound_board via the 34010 write() path,
#       runs both 6809s, captures the master->dac1 / slave->dac2 write byte
#       streams, and applies the per-channel verdict bit-exact (zero tolerance).
#
# Distinct attract host commands (from the 28 L| latch writes in the gospel):
#   irq_00  IRQ 0x00 (attract song load): DAC1 EMPTY, DAC2 IDLE:80 (slave silence)
#   irq_a2  IRQ 0xA2 (narc-rap voice)    : DAC1 EMPTY, DAC2 IDLE:80
#   irq_98  IRQ 0x98 (narc-rap voice)    : DAC1 CONTENT (256-byte master voice,
#                                          the DAC discriminator), DAC2 IDLE:80
#   nmi_00  NMI 0x00                     : DAC1 EMPTY, DAC2 IDLE:80
# (bootinit's slave DAC2 diagnostic ramp is a real-time-DEEP boot event, gospel
#  f>=105 ~1.9 s in; reported separately, not part of the injected-command gate.)
#
# A DAC address-decode MUTANT (+define+MUTANT_DAC_DECODE) re-derives the 0x3000
# decode with a WRONG iosel nibble -> the capture misses the DAC region -> the
# irq_98 voice diff fails (mutant dies), proving the gate exercises the decode.
# The gospel is re-segmented from the committed stream every run; determinism
# (run2==run1) is checked below. No committed golden / shared-core file is touched.
# ============================================================================
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
SND="$ROOT/rtl/sound"
IVL="${IVERILOG:-/c/iverilog/bin/iverilog}"
VVP="${VVP:-/c/iverilog/bin/vvp}"

cd "$HERE"
python make_hex.py >/dev/null

# ---- (1) deterministic segmentation of the committed gospel -----------------
mkdir -p build/dacsigs build/dacsigs2
python gen_dac_cmd_sig.py build/dacsigs  256 >/dev/null
python gen_dac_cmd_sig.py build/dacsigs2 256 >/dev/null
DET=FAIL
if diff -rq build/dacsigs build/dacsigs2 >/dev/null 2>&1; then DET=PASS; fi
echo "regen determinism (run2==run1): $DET"

# manifest columns: key_channel  mode  n  idleval(hex)  sha16
mfield() { awk -v k="$1" -v c="$2" '$1==k{print $(c)}' build/dacsigs/dacsig_manifest.txt; }
mcode()  { case "$(mfield "$1" 2)" in empty) echo 0;; content) echo 1;; idle) echo 2;; *) echo -1;; esac; }
mn()     { mfield "$1" 3; }
miv()    { mfield "$1" 4; }

# ---- build gate + mutant vvp images -----------------------------------------
JT51=()
while IFS= read -r f; do JT51+=("$f"); done < <(find "$SND/jt51/hdl" -maxdepth 1 -name '*.v' | sort)
SRC=("$SND/narc_sound_pkg.sv" "${JT51[@]}" "$SND/williams_cvsd/mc6809is.v" \
     "$SND/sim/hc55564_stub.v" "$SND/narc_sound_bank.sv" "$SND/narc_sound_latch.sv" \
     "$SND/narc_sound_board.sv" "$HERE/tb_narc_dac_cmd_matrix.sv")
"$IVL" -g2012 -DJT51_ONLYTIMERS                    -o build/dacmx.vvp     -s tb_narc_dac_cmd_matrix "${SRC[@]}"
"$IVL" -g2012 -DJT51_ONLYTIMERS -DMUTANT_DAC_DECODE -o build/dacmx_mut.vvp -s tb_narc_dac_cmd_matrix "${SRC[@]}"

# ---- run one command; echo the DACMX verdict + capture hidden-RAM touches ---
LAST_HID=""     # full hidden-RAM report line from the most recent run_cmd
run_cmd() { # $1 vvp  $2 label  $3 injword  $4 cmdkey
  local key="$4" m1 n1 m2 n2 iv2 out v hw
  m1=$(mcode "${key}_d1"); n1=$(mn "${key}_d1")
  m2=$(mcode "${key}_d2"); n2=$(mn "${key}_d2"); iv2=$(miv "${key}_d2")
  out="$("$VVP" "build/$1.vvp" +LABEL=$2 +INJWORD=$3 \
        +M1=$m1 +N1=$n1 +S1="build/dacsigs/dacsig_${key}_d1.txt" \
        +M2=$m2 +N2=$n2 +IV2=$iv2 +S2="build/dacsigs/dacsig_${key}_d2.txt" 2>&1)"
  v="$(printf '%s\n' "$out" | grep -E '^DACMX' | tail -1)"
  hw="$(printf '%s\n' "$out" | grep -E 'hidden-RAM' | head -1)"
  LAST_HID="$hw"
  hw="$(printf '%s\n' "$hw" | grep -oE 'writes=[0-9]+ reads=[0-9]+ .*')"
  printf '%s | hiddenRAM %s\n' "${v:-DACMX: FAIL(no-verdict)}" "$hw"
}

echo "================ GATE (faithful 0x3000 DAC decode) ================"
R_I00=$(run_cmd dacmx irq00 fd00 irq_00)
R_IA2=$(run_cmd dacmx irqa2 fda2 irq_a2)
R_I98=$(run_cmd dacmx irq98 fd98 irq_98); HID98="$LAST_HID"
R_N00=$(run_cmd dacmx nmi00 fe00 nmi_00)
printf "  irq_00 : %s\n  irq_a2 : %s\n  irq_98 : %s\n  nmi_00 : %s\n" \
  "$R_I00" "$R_IA2" "$R_I98" "$R_N00"

echo "================ MUTANT (wrong DAC iosel decode) ================"
# discriminating command: irq_98 (rich 256-byte master DAC1 voice prefix)
M_I98=$(run_cmd dacmx_mut mut_irq98 fd98 irq_98)
echo "  irq_98 mutant: $M_I98"

# ---- verdict ---------------------------------------------------------------
pass=0
for v in "$R_I00" "$R_IA2" "$R_I98" "$R_N00"; do
  case "$v" in "DACMX: PASS"*) pass=$((pass+1));; esac
done
# hidden-RAM exercised: irq_98 must show non-zero master overlay writes
HIDW98="$(printf '%s' "$R_I98" | grep -oE 'writes=[0-9]+' | grep -oE '[0-9]+')"
HIDOK=FAIL; [ "${HIDW98:-0}" -gt 0 ] 2>/dev/null && HIDOK=PASS
MUTDIES=FAIL; case "$M_I98" in "DACMX: PASS"*) ;; *) MUTDIES=PASS;; esac
echo "================================================================"
echo "hidden-RAM(0xCDFF-CE29) overlay exercised (irq_98 master writes=$HIDW98): $HIDOK"
if [ "$pass" -eq 4 ] && [ "$MUTDIES" = PASS ] && [ "$DET" = PASS ] && [ "$HIDOK" = PASS ]; then
  echo "G4-DAC-MATRIX: PASS  (4/4 injected cmds DAC1+DAC2 bit-exact incl A2/98,"
  echo "                      irq_98 master voice 256B bit-exact, DAC-decode mutant"
  echo "                      DIES, hidden-RAM overlay exercised, regen deterministic)"
  exit 0
else
  echo "G4-DAC-MATRIX: FAIL  (cmds_pass=$pass/4 mutant_dies=$MUTDIES det=$DET hidden=$HIDOK)"
  exit 1
fi
