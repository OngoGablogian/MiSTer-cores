#!/usr/bin/env bash
# ============================================================================
# run_ym_matrix.sh — G4 full YM2151 per-command write-stream matrix (iverilog).
# ----------------------------------------------------------------------------
# Closes G4 beyond rung-1 (one cmd) to the FULL matrix of distinct attract host
# commands. For EACH distinct command it:
#   (1) segments the committed gospel sound stream
#       (mame-trace/goldens/narc_attract_sound_stream.txt) on L| latch
#       boundaries into that command's YM signature (gen_ym_cmd_sig.py; the async
#       YM-timer-ack pair REG0x14/DAT0x15 stripped -- see the TB header for the
#       doctrine rationale), and
#   (2) injects the command into narc_sound_board via the 34010 write() path,
#       runs both 6809s to quiescence, reduces the produced master->jt51 write
#       stream to (addr,val) pairs (timer-ack stripped), and diffs it bit-exact,
#       in order, against the gospel signature (zero mismatch).
#
# Distinct attract host commands (from the 28 L| latch writes in the gospel):
#   bootinit  self-init (no host cmd)                -> 14:30 10:ff 11:00
#   irq_00    IRQ cmd 0x00 (attract song load)       -> e0..ff /0f key-off
#   irq_a2    IRQ cmd 0xA2 (narc-rap voice)          -> 08:07 27:c7 ...
#   irq_98    IRQ cmd 0x98 (narc-rap voice, distinct)-> 08:07 27:f2 ...
#   nmi_00    NMI cmd 0x00                           -> (no YM signature)
#
# A YM a0/address-decode MUTANT (+define+MUTANT_SWAP_REGDAT) must fail the diff.
# The gospel is NOT committed as a per-command golden -- it is re-segmented from
# the committed stream every run; determinism (run2==run1) is checked below.
# No committed golden or shared-core file is touched.
# ============================================================================
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
SND="$ROOT/rtl/sound"
IVL="${IVERILOG:-/c/iverilog/bin/iverilog}"
VVP="${VVP:-/c/iverilog/bin/vvp}"
GOSPEL="D:/deck/fpga/NARC/mame-trace/goldens/narc_attract_sound_stream.txt"

cd "$HERE"
python make_hex.py >/dev/null

# ---- (1) deterministic segmentation of the committed gospel -----------------
mkdir -p build/sigs build/sigs2
python gen_ym_cmd_sig.py build/sigs  32 >/dev/null
python gen_ym_cmd_sig.py build/sigs2 32 >/dev/null
# run2 == run1 determinism (compare the per-command signature manifests + files)
DET=FAIL
if diff -q build/sigs/ymsig_manifest.txt build/sigs2/ymsig_manifest.txt >/dev/null \
   && diff -rq build/sigs build/sigs2 --exclude=ymsig_manifest.txt >/dev/null 2>&1; then
  DET=PASS
fi
echo "regen determinism (run2==run1): $DET"

# per-command signature pair counts (from the manifest)
nsig_of() { awk -v k="$1" '$1==k{print $2}' build/sigs/ymsig_manifest.txt; }

# ---- build the gate + mutant vvp images -------------------------------------
JT51=()
while IFS= read -r f; do JT51+=("$f"); done < <(find "$SND/jt51/hdl" -maxdepth 1 -name '*.v' | sort)
build_vvp() { # $1 defines  $2 out
  "$IVL" -g2012 -DJT51_ONLYTIMERS $1 -o "build/$2" -s tb_narc_ym_cmd_matrix \
    "$SND/narc_sound_pkg.sv" "${JT51[@]}" \
    "$SND/williams_cvsd/mc6809is.v" "$SND/sim/hc55564_stub.v" \
    "$SND/narc_sound_bank.sv" "$SND/narc_sound_latch.sv" "$SND/narc_sound_board.sv" \
    "$HERE/tb_narc_ym_cmd_matrix.sv"
}
build_vvp ""                       ymmx.vvp
build_vvp "-DMUTANT_SWAP_REGDAT"   ymmx_mut.vvp

# ---- run one command through a vvp image; echo the YMMX verdict -------------
run_cmd() { # $1 vvp  $2 label  $3 injword  $4 bootinit  $5 sigkey
  local n out v
  n="$(nsig_of "$5")"
  out="$("$VVP" "build/$1.vvp" +LABEL=$2 +INJWORD=$3 +BOOTINIT=$4 +NSIG=$n \
        +SIG="build/sigs/ymsig_$5.txt" 2>&1)"
  v="$(printf '%s\n' "$out" | grep -E '^YMMX' | tail -1)"
  [ -n "$v" ] && printf '%s' "$v" || printf 'YMMX: FAIL(no-verdict)'
}

echo "================ GATE (faithful a0 decode) ================"
G_BOOT=$(run_cmd ymmx bootinit 0000 1 bootinit)
G_I00=$(run_cmd  ymmx irq00    fd00 0 irq_00)
G_IA2=$(run_cmd  ymmx irqa2    fda2 0 irq_a2)
G_I98=$(run_cmd  ymmx irq98    fd98 0 irq_98)
G_N00=$(run_cmd  ymmx nmi00    fe00 0 nmi_00)
printf "  bootinit : %s\n  irq_00   : %s\n  irq_a2   : %s\n  irq_98   : %s\n  nmi_00   : %s\n" \
  "$G_BOOT" "$G_I00" "$G_IA2" "$G_I98" "$G_N00"

echo "================ MUTANT (swap a0 REG/DAT decode) ================"
# discriminating command: irq_00 (rich e0..ff signature) must FAIL under the mutant
M_I00=$(run_cmd ymmx_mut mut_irq00 fd00 0 irq_00)
echo "  irq_00 mutant: $M_I00"

# ---- verdict ---------------------------------------------------------------
pass=0
for v in "$G_BOOT" "$G_I00" "$G_IA2" "$G_I98" "$G_N00"; do
  [ "$v" = "YMMX: PASS" ] && pass=$((pass+1))
done
echo "================================================================"
if [ "$pass" -eq 5 ] && [ "$M_I00" != "YMMX: PASS" ] && [ "$DET" = "PASS" ]; then
  echo "G4-YM-MATRIX: PASS  (5/5 distinct cmds bit-exact incl A2/98,"
  echo "                     a0 REG/DAT mutant DIES on irq_00, regen deterministic)"
  exit 0
else
  echo "G4-YM-MATRIX: FAIL  (gates_pass=$pass/5 mutant='$M_I00' det=$DET)"
  exit 1
fi
