#!/usr/bin/env python3
# Deterministic segmenter -> per-command AD7224 DAC1/DAC2 write SIGNATURES.
# Sibling of gen_ym_cmd_sig.py: the SAME L| span walk (the global line index is
# monotonic across L|/Y|/D1|/D2|, so a DAC write's command membership is exactly
# the L| span it falls inside), but instead of reducing YM REG/DAT pairs it
# collects the ordered DAC WRITE BYTES per span, split by channel:
#   D1| = master AD7224 (dac1, 0x3000, williamssound.cpp:477)
#   D2| = slave  AD7224 (dac2, 0x3000, williamssound.cpp:496)
# The leading SIG_MAX bytes per channel are the command-semantic prefix (bit-exact
# oracle for the DUT). Rationale (doctrine, mirrors the YM matrix header): the DAC
# byte VALUES are the command-semantic content (the played PCM waveform, read
# linearly from ROM by the command handler -> deterministic regardless of when the
# command is injected). The stream LENGTH per span is a real-time boundary artifact
# (how long until the next L| command / the idle-center run-length) -- the exact
# analog of the YM timer-ack COUNT. So the gate matches a BOUNDED leading prefix
# bit-exact (zero tolerance), NOT the full real-time run-length. This is event-
# anchoring, NOT tolerance-absorbing a written byte.
#
# SPAN rule (identical to gen_ym_cmd_sig.py): an interrupt-asserting latch
# (D8==0 NMI or D9==0 IRQ) starts/selects a span keyed by cmd; a RESET latch
# (D10==0) ends the active span; deassert (FFxx) keeps the current span open;
# boot self-init ("bootinit") = writes before the first assert; FIRST span per
# distinct key is kept (revisits keep appending until the SIG_MAX cap).
import sys, hashlib

G       = "D:/deck/fpga/NARC/mame-trace/goldens/narc_attract_sound_stream.txt"
OUT     = sys.argv[1] if len(sys.argv) > 1 else "."
SIG_MAX = int(sys.argv[2]) if len(sys.argv) > 2 else 256   # bytes kept per channel

def is_assert(w): return ((w>>8)&1)==0 or ((w>>9)&1)==0
def is_reset(w):  return ((w>>10)&1)==0
def keyname(w):
    cmd=w&0xff
    return (f"nmi_{cmd:02x}" if ((w>>8)&1)==0 else f"irq_{cmd:02x}")

def newspan(): return dict(d1=[], d2=[], closed=False)
spans={}; order=[]
cur="bootinit"; spans[cur]=newspan(); order.append(cur)
seen_assert=False

def feed(span, ch, d):
    if span is None or span["closed"]: return
    arr = span["d1"] if ch=='1' else span["d2"]
    if len(arr) < SIG_MAX:
        arr.append(d)
    if len(span["d1"])>=SIG_MAX and len(span["d2"])>=SIG_MAX:
        span["closed"]=True

with open(G) as fh:
    for line in fh:
        c0=line[0]
        if c0=='D':
            ch=line[1]                     # '1' master / '2' slave
            s=spans.get(cur)
            if s is not None:
                d=int(line.rstrip("\n").split("D=")[-1],16)
                feed(s,ch,d)
        elif c0=='L':
            p=line.rstrip("\n").split("|")
            w=None
            for tok in p:
                if tok.startswith("D="): w=int(tok.split("=")[1],16); break
            if not seen_assert and not is_assert(w):
                cur="bootinit"; continue
            if is_reset(w):
                cur=None
            elif is_assert(w):
                seen_assert=True
                k=keyname(w)
                if k not in spans:
                    spans[k]=newspan(); order.append(k); cur=k
                else:
                    cur=k
            else:
                pass                       # deassert: keep current span

# classify each channel per command (uniq computed over the FULL span, so the
# idle/content decision cannot be fooled by a truncated prefix):
#   EMPTY   (n==0)            : the CPU never touches this DAC -> DUT must emit 0.
#   IDLE:VV (n>0, uniq==1)    : the CPU holds the DAC at the constant value VV
#                              (0x80 slave silence / 0x00 master-off). The run-
#                              LENGTH is a real-time idle-refresh artifact (the
#                              DAC analog of the YM timer-ack COUNT) -> the gate
#                              requires only that every DUT write on this channel
#                              == VV (no count), NOT the real-time run-length.
#   CONTENT (n>0, uniq>1)     : a real PCM waveform -> the leading prefix is the
#                              bit-exact command-semantic oracle (require the DUT
#                              produce >= len bytes, all matching).
manifest=[]
for k in order:
    s=spans[k]
    for ch in ('d1','d2'):
        seq=s[ch]
        uniq=set(seq)
        if len(seq)==0:
            mode="empty"; ival=0
        elif len(uniq)==1:
            mode="idle"; ival=seq[0]
        else:
            mode="content"; ival=0
        body="".join(f"{b:02x}\n" for b in seq)
        path=f"{OUT}/dacsig_{k}_{ch}.txt"
        open(path,"w").write(body)
        h=hashlib.sha256(body.encode()).hexdigest()[:16]
        manifest.append((f"{k}_{ch}", mode, len(seq), ival, h))
    shown1=" ".join(f"{b:02x}" for b in s['d1'][:16])
    shown2=" ".join(f"{b:02x}" for b in s['d2'][:16])
    print(f"{k:10s} d1 n={len(s['d1']):3d} [{shown1}]")
    print(f"{'':10s} d2 n={len(s['d2']):3d} [{shown2}]")
# manifest columns: key_channel  mode  n  idleval(hex)  sha16
open(f"{OUT}/dacsig_manifest.txt","w").write(
    "".join(f"{k} {m} {n} {v:02x} {h}\n" for k,m,n,v,h in manifest))
print("done")
