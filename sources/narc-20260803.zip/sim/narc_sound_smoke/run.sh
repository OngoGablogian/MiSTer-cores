#!/usr/bin/env bash
# run.sh — iverilog-only master-6809 -> YM2151 write gate (G4-rung-1).
# NO Questa. hc55564 VHDL blackboxed via rtl/sound/sim/hc55564_stub.v.
# jt51 built with JT51_ONLYTIMERS (timers + busy, no FM/phrom/exprom) — the
# master only needs the YM register bus + busy poll + FIRQ.
#
# Runs TWO builds:
#   (1) the gate     -> master->jt51 writes must equal the gospel Y| prefix on
#                       (a0 REG/DAT + D) for the first >=16 writes (RESULT: PASS)
#   (2) MUTANT_SWAP_REGDAT -> swaps the a0 REG/DAT decode at the tap; MUST FAIL
#                             (mutant dies), proving the gate exercises a0.
# Overall exit 0 only when gate=PASS AND mutant=FAIL.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
SND="$ROOT/rtl/sound"
IVL="${IVERILOG:-/c/iverilog/bin/iverilog}"
VVP="${VVP:-/c/iverilog/bin/vvp}"

cd "$HERE"
python make_hex.py

# jt51 top-level hdl (maxdepth 1), same set the Questa snd runner uses
JT51=()
while IFS= read -r f; do JT51+=("$f"); done < <(find "$SND/jt51/hdl" -maxdepth 1 -name '*.v' | sort)

build_run() { # $1 = extra defines, $2 = label, $3 = out vvp
  "$IVL" -g2012 -DJT51_ONLYTIMERS $1 -o "build/$3" -s tb_narc_sound_smoke \
    "$SND/narc_sound_pkg.sv" \
    "${JT51[@]}" \
    "$SND/williams_cvsd/mc6809is.v" \
    "$SND/sim/hc55564_stub.v" \
    "$SND/narc_sound_bank.sv" \
    "$SND/narc_sound_latch.sv" \
    "$SND/narc_sound_board.sv" \
    "$HERE/tb_narc_sound_smoke.sv"
  echo "===== $2 ====="
  "$VVP" "build/$3"
}

GATE_LOG="$(build_run "" "GATE (faithful decode)" smoke.vvp)"
echo "$GATE_LOG"
MUT_LOG="$(build_run "-DMUTANT_SWAP_REGDAT" "MUTANT (swap REG/DAT decode)" smoke_mut.vvp)"
echo "$MUT_LOG"
# rung-2 mutant: inject 0xFFA2 (D9=1) => master IRQ never asserts => 0xA2 unread
# => no dispatch => RUNG2 must FAIL (mutant dies). Rung-1/slave unaffected here.
MUT2_LOG="$(build_run "-DMUTANT_NO_IRQ" "MUTANT (no master IRQ on inject)" smoke_mut2.vvp)"
echo "$MUT2_LOG"

gate_pass=$(echo "$GATE_LOG" | grep -c "^RESULT: PASS" || true)     # rung-1
mut_pass=$(echo  "$MUT_LOG"  | grep -c "^RESULT: PASS" || true)     # rung-1 mutant
slv_pass=$(echo  "$GATE_LOG" | grep -c "^SLAVE-BOOT: PASS" || true) # slave boot
r2_pass=$(echo   "$GATE_LOG" | grep -c "^RUNG2: PASS" || true)      # rung-2
r2_mut_pass=$(echo "$MUT2_LOG" | grep -c "^RUNG2: PASS" || true)    # rung-2 mutant

echo "================================================================"
if [ "$gate_pass" -ge 1 ] && [ "$mut_pass" -eq 0 ] && [ "$slv_pass" -ge 1 ] \
   && [ "$r2_pass" -ge 1 ] && [ "$r2_mut_pass" -eq 0 ]; then
  echo "G4-RUNG-2: PASS  (YM gate PASS, REG/DAT mutant DIES, SLAVE boots,"
  echo "                  host cmd 0xA2 -> IRQ -> command_r dispatch PASS, NO-IRQ mutant DIES)"
  exit 0
else
  echo "G4-RUNG-2: FAIL  (gate=$gate_pass regdat_mut=$mut_pass slv=$slv_pass r2=$r2_pass no_irq_mut=$r2_mut_pass)"
  exit 1
fi
