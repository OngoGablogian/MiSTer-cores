#!/usr/bin/env bash
set -euo pipefail
export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
T="${TMPDIR:-/tmp}/tb_narc_crt_adjust.vvp"
iverilog -g2012 -s tb_narc_crt_adjust -o "$T" \
  "$ROOT/rtl/crt_adjust.sv" "$ROOT/sim/tb_narc_crt_adjust.sv"
OUT="$(vvp "$T")"
printf '%s\n' "$OUT"
grep -Fq "TEST_RESULT: PASS" <<<"$OUT"

echo "== unsafe -8 SYNCSHIFT boundary (must die) =="
TM="${TMPDIR:-/tmp}/tb_narc_crt_adjust_mut.vvp"
iverilog -g2012 -DMUT_CRT_HPOS_UNSAFE -s tb_narc_crt_adjust -o "$TM" \
  "$ROOT/rtl/crt_adjust.sv" "$ROOT/sim/tb_narc_crt_adjust.sv"
MOUT="$(vvp "$TM")"
printf '%s\n' "$MOUT"
if grep -Fq "TEST_RESULT: PASS" <<<"$MOUT"; then
  echo "MUTANT-CHECK: FAIL -- unsafe -8 boundary survived"
  exit 1
fi
grep -Eq "shifted HSync overlaps active (video|capture)|bank flipped during active capture" <<<"$MOUT"
echo "MUTANT-CHECK: PASS -- -8 crosses adjusted active video; menu boundary -7 is discriminating"

echo "== unlatched HPOS selector (must die) =="
TL="${TMPDIR:-/tmp}/tb_narc_crt_adjust_unlatched.vvp"
iverilog -g2012 -DMUT_CRT_HPOS_UNLATCHED -s tb_narc_crt_adjust -o "$TL" \
  "$ROOT/rtl/crt_adjust.sv" "$ROOT/sim/tb_narc_crt_adjust.sv"
set +e
OL="$(vvp "$TL" 2>&1)"
RCL=$?
set -e
printf '%s\n' "$OL"
if [ "$RCL" -ne 0 ] || ! grep -Fq "TEST_RESULT: FAIL" <<<"$OL" ||
   ! grep -Fq "HPOS tap changed mid-line" <<<"$OL"; then
  echo "MUTANT-CHECK: FAIL -- unlatched HPOS selector survived"
  exit 1
fi
echo "MUTANT-CHECK: PASS -- mid-line HPOS change kills the unlatched selector"
