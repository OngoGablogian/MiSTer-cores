#!/usr/bin/env bash
# Run a yunit_top system testbench in Questa under SYNTHESIS (real CPU + SDRAM
# controller + behavioral MT48LC16M16 + video + palette + VHDL sound board).
#   ./run_top.sh [tb_yunit_top_boot] [+PLUSARGS...]
set -e
TB="${1:-tb_yunit_top_boot}"; shift || true
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"; SND="$ROOT/rtl/sound"

for d in /c/altera/*/questa_fse/win64 /c/altera_pro/*/questa_fse/win64; do
  [ -x "$d/vlog.exe" ] && { VLOG="$d/vlog"; VCOM="$d/vcom"; VSIM="$d/vsim"; VLIB="$d/vlib"; break; }
done
[ -n "$VLOG" ] || { echo "Questa not found"; exit 1; }
unset LM_LICENSE_FILE MGLS_LICENSE_FILE

cd "$ROOT/sim"
rm -rf work_top; "$VLIB" work_top >/dev/null

SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SRC+=( "$ROOT/rtl/pkg/yunit_pkg.sv"
       "$ROOT/rtl/yunit/yunit_mem.sv" "$ROOT/rtl/yunit/yunit_dma.sv"
       "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv"
       "$ROOT/rtl/yunit/vram_sdram_scanout.sv"
       "$ROOT/rtl/yunit/yunit_memsys.sv"
       "$ROOT/rtl/yunit/yunit_video.sv" "$ROOT/rtl/yunit/yunit_scanline.sv"
       "$ROOT/rtl/yunit/yunit_video_top.sv" "$ROOT/rtl/yunit/yunit_palram.sv"
       "$ROOT/rtl/sdram/yunit_sdram_arb.sv" "$ROOT/rtl/sdram/sdram_stock.sv" "$ROOT/rtl/sdram/yunit_sdram_adapter.sv"
       "$ROOT/rtl/yunit/yunit_gfx_unpack.sv"
       "$ROOT/rtl/yunit/yunit_mem_cdc.sv" "$ROOT/rtl/yunit/yunit_top.sv"
       "$ROOT/sim/sdram_chip.sv" "$ROOT/sim/sdram_chip_ca.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$SND/jt51/hdl" -maxdepth 1 -name '*.v' | sort)
SRC+=( "$SND/williams_cvsd/mc6809is.v" "$SND/smashtv_snd_rom.sv" "$ROOT/sim/$TB.sv" )

"$VLOG" -sv -quiet -svinputport=var +define+SYNTHESIS +define+SIM_NO_ALTERA ${EXTRA_DEFINES:-} -work work_top "${SRC[@]}"
"$VCOM" -2008 -quiet -work work_top \
  "$SND/williams_cvsd/gen_ram.vhd" "$SND/williams_cvsd/hc55564.vhd" \
  "$SND/williams_cvsd/pia6821.vhd" "$SND/williams_cvsd/williams_cvsd_board.vhd"

echo "running $TB ..."
"$VSIM" -c -quiet -work work_top -do "run -all; quit -f" "$TB" "$@" 2>&1 \
  | grep -viE "^# (Loading|//|\*\* Note)" | grep -iE "\[|==|error|fatal|preload"
