#!/usr/bin/env python3
"""Extract MAME frame 1214's complete 240-blit high-score-table burst.

The checked-in capture is the authoritative MAME 0.280 command stream. This
mechanical conversion keeps the SystemVerilog testbench independent of text
parsing and fails closed if the captured scene count or geometry changes.
"""

from __future__ import annotations

import re
from pathlib import Path


FRAME = 1214
EXPECTED_BLITS = 240
FIELDS = ("CMD", "RB", "OFLO", "OFHI", "X", "Y", "W", "H", "PAL", "COL")


def main() -> int:
    repo = Path(__file__).resolve().parents[1]
    source = repo / "build_sim" / "narc_hiscore_dma_commands.txt"
    output = repo / "build_sim" / "narc_hiscore_scene.hex"
    if not source.is_file():
        raise SystemExit(f"FATAL: MAME command capture is absent: {source}")

    records: list[str] = []
    max_source_end = 0
    for line in source.read_text(encoding="ascii").splitlines():
        if not line.startswith("B|") or f"|f={FRAME}|" not in line:
            continue
        values: dict[str, int] = {}
        for field in FIELDS:
            match = re.search(rf"(?:^|\|){field}=([0-9A-Fa-f]{{4}})(?:\||$)", line)
            if match is None:
                raise SystemExit(f"FATAL: missing {field} in captured command: {line}")
            values[field] = int(match.group(1), 16)
        records.append("".join(f"{values[field]:04X}" for field in FIELDS))

        if (values["CMD"] & 0xF) < 0xC:
            source_base = (
                (((values["OFHI"] << 16) | values["OFLO"]) - 0x0200_0000) >> 3
            )
            max_source_end = max(
                max_source_end, source_base + values["W"] * values["H"]
            )

    if len(records) != EXPECTED_BLITS:
        raise SystemExit(
            f"FATAL: frame {FRAME} has {len(records)} blits; expected {EXPECTED_BLITS}"
        )
    if max_source_end > 0x9000:
        raise SystemExit(
            f"FATAL: scene source reaches {max_source_end:#x}; "
            "extend the checked graphics prefix"
        )

    output.write_text("\n".join(records) + "\n", encoding="ascii")
    print(
        f"{output}: {len(records)} MAME blits from frame {FRAME}, "
        f"source-end={max_source_end:#x}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
