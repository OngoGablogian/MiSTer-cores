#!/usr/bin/env bash
# zunit_memsys -> zunit_video END-TO-END gate (NARC Phase-3 blits->frame milestone).
#
# Drives the FULL ordered MAME-0.280 attract blit stream onto MAME's T0 canvas through
# the real memsys glue (CPU bus 0x01A00000 -> D_LO/D_HI decode -> zunit_dma -> fb write
# -> zunit_mem BRAM VRAM), dumps the RTL end-of-frame VRAM, then RENDERS that VRAM
# through zunit_video with the coherent frozen-T1 palette and diffs the RGB888 frame
# vs BOTH oracles over the DMA-written set D mapped to the visible 512x400:
#   - MAME's coherent T1 ref PNG (mame-trace/goldens/narc_accum_ref.png), and
#   - the blind video_golden.py render of MAME's T1 VRAM (independent agreement).
# NO tolerance over D. The non-DMA (SRT scroll-copy) residual is measured + reported,
# never absorbed. This is the ONLY gate that spans the memsys-BRAM-layout <-> video-read
# seam (hi=palette-select / lo=pixel word must match zunit_video's unpack). PC-diff is
# blind to scanout; this proves it.
#
# Gate-exercises-the-change (mutant must DIE; oracle set D is ALWAYS the full golden
# stream, never mutated):
#   DROP  --drop N   omit the golden's heaviest last-writer blit from the RTL drive ->
#                    its final pixels revert -> D-region RGB mismatch (FAILS).
#   6BPP             render the (unmutated) DUT VRAM through the donor 6bpp pen mask
#                    (PEN_MASK=0x0FFF). MEASURED for THIS frame: max D pen = 0x0ED7
#                    (< 0x1000), so the 6bpp mask is inert over D -> reported, the DROP
#                    mutant is the discriminator (acceptance: "6bpp OR dropped-blit").
# Frozen RTL (rtl/zunit + rtl/tms34010) is NEVER modified; verification only.
# Quote every path (repo trees may contain a space).
set -u
export PATH="/c/iverilog/bin:$PATH"
PY="${PYTHON:-python}"

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
ACC="$ROOT/sim/zunit_memsys_accum"
PKG="$ROOT/rtl/zunit/zunit_pkg.sv"
DMA="$ROOT/rtl/zunit/zunit_dma.sv"
MEM="$ROOT/rtl/zunit/zunit_mem.sv"
SYS="$ROOT/rtl/zunit/zunit_memsys.sv"
VID="$ROOT/rtl/zunit/zunit_video.sv"
ATB="$ACC/tb_zunit_memsys_accum.sv"
VTB="$ROOT/sim/zunit_video_matrix/tb_zunit_video.sv"
PAL="$ROOT/../mame-trace/goldens/narc_accum_palette.hex"

cd "$HERE"

# ---- build the RTL end-of-frame VRAM for a given prep-drive (prep args in $1) --------
# prep_accum + accum TB live in $ACC; run vvp with cwd=$ACC so its $readmemh/dump land
# there, then copy the dumped VRAM here under the name in $2.
build_dut() {   # $1 = prep args (may be empty), $2 = dest vram name
    ( cd "$ACC" && "$PY" prep_accum.py $1 >/dev/null ) || { echo "PREP FAIL"; return 2; }
    rm -f "$HERE/accum.vvp"
    iverilog -g2012 -I "$ACC" -s tb_zunit_memsys_accum \
        -o "$HERE/accum.vvp" "$PKG" "$DMA" "$MEM" "$SYS" "$ATB" 2> "$HERE/iverilog_accum.log"
    [ $? -eq 0 ] || { echo "IVERILOG(accum) FAIL"; cat "$HERE/iverilog_accum.log"; return 2; }
    ( cd "$ACC" && vvp "$HERE/accum.vvp" > "$HERE/vvp_accum.log" 2>&1 )
    cp "$ACC/dut_vram.hex" "$HERE/$2"
}

# ---- build the zunit_video renderer (base + 6bpp mutant) ----------------------------
build_vid() {   # $1 = extra defines, $2 = vvp name
    rm -f "$2"
    iverilog -g2012 $1 -s tb_zunit_video -o "$2" "$PKG" "$VID" "$VTB" 2> "$HERE/iverilog_vid.log"
    [ $? -eq 0 ] || { echo "IVERILOG(video) FAIL"; cat "$HERE/iverilog_vid.log"; return 2; }
}

render() {      # $1 = video vvp, $2 = vram.hex, $3 = out rgb.hex
    vvp "$1" +VRAM="$HERE/$2" +PAL="$PAL" +OUT="$HERE/$3" > "$HERE/vvp_vid.log" 2>&1
}

echo "== build zunit_video renderers (base 8bpp + 6bpp mutant) =="
build_vid ""          vid_base.vvp || { echo "RESULT: BUILD FAILED"; exit 1; }
build_vid "-DMUT_6BPP" vid_mut.vvp  || { echo "RESULT: BUILD FAILED"; exit 1; }

echo "== BASE: drive full ordered stream -> RTL VRAM -> zunit_video -> RGB =="
build_dut "" dut_vram.hex || { echo "RESULT: BUILD FAILED"; exit 1; }
render "$HERE/vid_base.vvp" dut_vram.hex e2e_rtl.hex
echo "-- BASE compare (RTL RGB vs MAME ref PNG AND video_golden(T1) over set D) --"
"$PY" compare_e2e.py e2e_rtl.hex
BASE=$?
if [ $BASE -ne 0 ]; then echo "RESULT: BASE FAILED"; exit 1; fi

echo "-- BASE full-frame G3 (whole 512x400 vs ref PNG; residual must be SRT strip T0!=T1) --"
"$PY" compare_e2e_full.py e2e_rtl.hex
BASEF=$?
if [ $BASEF -ne 0 ]; then echo "RESULT: BASE FULL-FRAME FAILED"; exit 1; fi

echo "== MUTANT 6BPP: render BASE DUT VRAM through donor 6bpp pen mask (0x0FFF) =="
render "$HERE/vid_mut.vvp" dut_vram.hex e2e_6bpp.hex
"$PY" compare_e2e.py e2e_6bpp.hex > m6.log 2>&1
M6=$?
D6="$(grep 'combined d_D' m6.log | head -1)"
if [ $M6 -ne 0 ]; then echo "  6BPP DIED ($D6)";
else echo "  6BPP INERT over D ($D6) -- MEASURED: max D pen 0x0ED7 < 0x1000, mask 0x0FFF "\
          "changes no D pixel; DROP mutant is the discriminator (acceptance: 6bpp OR drop)"; fi

echo "== MUTANT DROP: omit the heaviest last-writer blit from the RTL drive =="
DROP="$("$PY" "$ACC/pick_drop.py")"
build_dut "--drop $DROP" dut_vram_drop.hex || { echo "RESULT: BUILD FAILED"; exit 1; }
render "$HERE/vid_base.vvp" dut_vram_drop.hex e2e_drop.hex
"$PY" compare_e2e.py e2e_drop.hex > mDrop.log 2>&1
MD=$?
tail -2 mDrop.log
if [ $MD -eq 0 ]; then echo "  DROP SURVIVED <-- BAD (memsys->video seam not exercised)"; exit 1
else echo "  DROP DIED (dropping blit $DROP corrupts the rendered frame over D)"; fi

# rebuild BASE artifacts so the working tree reflects the passing gate
echo "== rebuild BASE artifacts =="
build_dut "" dut_vram.hex >/dev/null
render "$HERE/vid_base.vvp" dut_vram.hex e2e_rtl.hex
"$PY" compare_e2e.py e2e_rtl.hex >/dev/null 2>&1 || { echo "REBUILD BASE FAILED"; exit 1; }

echo "== SUMMARY =="
echo "RESULT: PASS  (RTL memsys VRAM rendered through zunit_video is RGB bit-exact vs"
echo "              MAME accum ref PNG AND video_golden(T1) over the DMA set D, d_D=0;"
echo "              FULL 512x400 G3: every residual pixel positively inside the SRT strip"
echo "              (T0_vram!=T1_vram), unexplained=0; DROP mutant died; 6bpp measured-inert;"
echo "              non-DMA SRT residual measured+bounded two-sided, not absorbed)"
exit 0
