#!/usr/bin/env bash
# run_intpend_gate.sh -- INTPEND read-only + write-zero-to-clear semantics.
# Runs BOTH arms in ONE invocation so a green can never inherit a kill from an
# earlier run (the standard agreed across the Wolf/Y/T sessions).
set -e
export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
SRC=("$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" \
     "$ROOT/rtl/tms34010/rtl/io/tms34010_io_regs.sv" \
     "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv" \
     "$ROOT/sim/tb_tms34010_intpend_rmw.sv")

echo "== INTPEND semantics: production must PASS =="
iverilog -g2012 -s tb_tms34010_intpend_rmw -o "$T/p.vvp" "${SRC[@]}" 2>/dev/null
OUT="$(vvp "$T/p.vvp")"
printf '%s\n' "$OUT" | grep -iE "PASS|FAIL|RESULT"
printf '%s\n' "$OUT" | grep -Fq "PASS: tb_tms34010_intpend_rmw"

echo "== INTPEND MUTATION (-DMUT_IO_INTPEND_WHOLE_WRITE): unmasked store MUST fail =="
iverilog -g2012 -DMUT_IO_INTPEND_WHOLE_WRITE -s tb_tms34010_intpend_rmw -o "$T/m.vvp" "${SRC[@]}" 2>/dev/null
MOUT="$(vvp "$T/m.vvp")"
printf '%s\n' "$MOUT" | grep -iE "FAIL|RESULT"
# require the two load-bearing kills by name, not just "some failure"
printf '%s\n' "$MOUT" | grep -Fq "FAIL: X1P STUCK after read-modify-write with LINT1 high"
printf '%s\n' "$MOUT" | grep -Fq "FAIL: intpend_o X1P stuck: pending view asserts INT1 with the pin low"
echo "RESULT: PASS -- INTPEND contract proven (production green, mutant killed, same run)."
