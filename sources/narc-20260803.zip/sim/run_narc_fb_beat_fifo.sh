#!/usr/bin/env bash
set -eu
export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
T="$(mktemp -d "${TMPDIR:-/tmp}/narc_fb_beat_fifo.XXXXXX")"
trap 'rm -rf "$T"' EXIT

iverilog -g2012 -s tb_narc_fb_beat_fifo \
  -o "$T/tb_narc_fb_beat_fifo.vvp" \
  "$ROOT/rtl/zunit/narc_fb_beat_fifo.sv" \
  "$ROOT/sim/tb_narc_fb_beat_fifo.sv"
OUT="$(cd "$ROOT" && vvp "$T/tb_narc_fb_beat_fifo.vvp")"
printf '%s\n' "$OUT"
printf '%s\n' "$OUT" | grep -Fq \
  "RESULT: BEAT-FIFO PASS -- merge, newest-lane, order, full backpressure, fence spill, and flush hold are exact."
