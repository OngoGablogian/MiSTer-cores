#!/usr/bin/env bash
# zunit_download acceptance gate (iverilog + blind Python cross-model).
#   1. gen_stream.py     : rebuild the faithful "Narc (rev 7.00).mra" byte stream.
#   2. tb_zunit_download : replay it through zunit_download, dump SDRAM word-writes.
#   3. cross_check.py    : assert the writes reconstruct program-flat @ROMW_BASE and
#                          gfx-flat @GFXW_BASE byte-exact vs a from-scratch
#                          init_gfxrom(8) de-interleave of narc.zip; zero sound/PLA
#                          byte in the gfx/prog SDRAM ranges.
set -e
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
export PATH="/c/iverilog/bin:$PATH"
DIR="$ROOT/sim/zunit_download"
PKG="$ROOT/rtl/zunit/zunit_pkg.sv"
DL="$ROOT/rtl/zunit/zunit_download.sv"
TB="$DIR/tb_zunit_download.sv"
cd "$DIR"

echo "== 1. gen_stream.py =="
python gen_stream.py

echo "== 2. iverilog build + run =="
iverilog -g2012 -s tb_zunit_download -o tb.vvp "$PKG" "$DL" "$TB"
vvp tb.vvp

echo "== 3. cross_check.py =="
python cross_check.py
