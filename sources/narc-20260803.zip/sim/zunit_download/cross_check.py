#!/usr/bin/env python3
# cross_check.py — INDEPENDENT (blind) oracle for zunit_download.
#
# Rebuilds the expected SDRAM byte image DIRECTLY from roms/narc.zip using the
# gospel transforms (NOT from the RTL, NOT from gen_stream's MRA parse):
#   * program-flat @ ROMW_BASE : LOAD16_BYTE interleave of the 4 rev7 game ROMs
#                                (midyunit.cpp:1467-1470), 34010 little-endian.
#   * gfx-flat     @ GFXW_BASE : init_gfxrom(8) 4-way quadrant byte de-interleave
#                                (midyunit_m.cpp:284-292): flat[4k+q]=raw[q*chunk+k].
# Then reads the TB's emitted SDRAM word-writes (writes.txt) and asserts, byte-exact:
#   (1) every write word-addr lies in the gfx range [0,GFX_WORDS) or the program
#       range [ROMW_BASE,ROMW_BASE+PROG_WORDS) — nothing else (=> zero sound/PLA
#       or gfx-gap byte spilled into the gfx/prog SDRAM ranges);
#   (2) the reconstructed gfx bytes == blind init_gfxrom(8) flat[0:0x3C0000];
#   (3) the reconstructed program bytes == blind LE16 program image;
#   (4) exact write counts (gfx 0x3C0000 byte-lane writes + prog 0x40000 word writes).
# NEVER weaken: no tolerance, no skipped byte.
import os, sys, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ZIP  = "D:/deck/fpga/NARC/roms/narc.zip"
WRITES = os.path.join(HERE, "writes.txt")

# SDRAM word map (zunit_pkg: SDRAM_GFXW_BASE / SDRAM_ROMW_BASE / geometry)
GFXW_BASE  = 0x000000
GFX_WORDS  = 0x1E0000            # 3.75 MB populated / 2
ROMW_BASE  = 0x1E0000
PROG_WORDS = 0x040000           # 512 KB / 2
GFX_BYTES  = GFX_WORDS  * 2     # 0x3C0000
PROG_BYTES = PROG_WORDS * 2     # 0x080000
# D1 sound region (zunit_pkg: SDRAM_SNDW_BASE / SND_IMAGE_*). Master image then slave.
VRAM_WORDS = 0x040000
SNDW_BASE  = GFX_WORDS + PROG_WORDS + VRAM_WORDS   # 0x260000
SND_IMAGE_BYTES = 0x090000
SND_IMAGE_WORDS = SND_IMAGE_BYTES // 2             # 0x048000
SND_BYTES  = 2 * SND_IMAGE_BYTES                   # 0x120000

def build_program(z):
    # ROM_LOAD16_BYTE pairs: u42/u41 = EVEN(low), u24/u23 = ODD(high)
    u42=z.read("rev7_narc_game_rom_u42.u42"); u24=z.read("rev7_narc_game_rom_u24.u24")
    u41=z.read("rev7_narc_game_rom_u41.u41"); u23=z.read("rev7_narc_game_rom_u23.u23")
    assert len(u42)==len(u24)==len(u41)==len(u23)==0x20000
    def il(lo,hi):
        b=bytearray(len(lo)*2); b[0::2]=lo; b[1::2]=hi; return bytes(b)
    prog = il(u42,u24)+il(u41,u23)           # 0x80000 bytes, little-endian words
    assert len(prog)==PROG_BYTES
    return prog

def build_gfx_flat(z):
    order=[("u94","u80"),("u76","u62"),("u58","u44"),("u40","u26")]  # 4 quadrant blocks
    raw=bytearray(0x800000)
    for qi,(top,_) in enumerate(order):
        base=qi*0x200000
        top_n=int(top[1:])
        for k in range(15):
            n=top_n-k
            d=z.read("rev2_narc_image_rom_u%d.u%d"%(n,n))
            assert len(d)==0x10000, (n,len(d))
            raw[base+k*0x10000:base+(k+1)*0x10000]=d
    chunk=0x800000//4                        # 0x200000
    flat=bytearray(0x800000)
    for i in range(0,0x800000,4):
        for q in range(4):
            flat[i+q]=raw[q*chunk + i//4]
    return bytes(flat[:GFX_BYTES])           # populated contiguous span

def build_sound(z):
    # MRA sound regions, transcribed from the <part> list (which mirrors MAME's
    # narcsnd:cpu0/cpu1 ROM_REGIONs including the deliberate "reload" duplicates --
    # the fixed-upper window at 0x8C000 lives inside the SECOND u5/u38 copy).
    def blk(*names):
        out=bytearray()
        for n in names:
            if n is None: out += b"\x00"*0x10000
            else:
                d=z.read(n); assert len(d)==0x10000,(n,len(d)); out+=d
        return bytes(out)
    master = b"\x00"*0x50000 + blk("rev2_narc_sound_rom_u4.u4","rev2_narc_sound_rom_u4.u4",
                                   "rev2_narc_sound_rom_u5.u5","rev2_narc_sound_rom_u5.u5")
    slave  = b"\x00"*0x10000 + blk("rev2_narc_sound_rom_u35.u35","rev2_narc_sound_rom_u35.u35",
                                   "rev2_narc_sound_rom_u36.u36","rev2_narc_sound_rom_u36.u36",
                                   "rev2_narc_sound_rom_u37.u37","rev2_narc_sound_rom_u37.u37",
                                   "rev2_narc_sound_rom_u38.u38","rev2_narc_sound_rom_u38.u38")
    assert len(master)==SND_IMAGE_BYTES and len(slave)==SND_IMAGE_BYTES
    return master, slave

def main():
    z=zipfile.ZipFile(ZIP)
    prog=build_program(z)
    gfx =build_gfx_flat(z)
    snd_m,snd_s=build_sound(z)

    # expected SDRAM byte image (absolute SDRAM byte address -> value)
    exp={}
    for b in range(GFX_BYTES):  exp[GFXW_BASE*2 + b]      = gfx[b]
    for b in range(PROG_BYTES): exp[ROMW_BASE*2 + b]      = prog[b]
    for b in range(SND_IMAGE_BYTES): exp[SNDW_BASE*2 + b]                   = snd_m[b]
    for b in range(SND_IMAGE_BYTES): exp[SNDW_BASE*2 + SND_IMAGE_BYTES + b] = snd_s[b]

    # reconstruct from the TB dump
    recon={}
    n_gfx_w=0; n_prog_w=0; n_snd_w=0; n_lines=0
    oor=[]
    with open(WRITES) as f:
        for ln in f:
            ln=ln.strip()
            if not ln: continue
            a,d,be=ln.split()
            a=int(a,16); d=int(d,16); be=int(be)
            n_lines+=1
            if GFXW_BASE<=a<GFXW_BASE+GFX_WORDS: n_gfx_w+=1
            elif ROMW_BASE<=a<ROMW_BASE+PROG_WORDS: n_prog_w+=1
            elif SNDW_BASE<=a<SNDW_BASE+2*SND_IMAGE_WORDS: n_snd_w+=1
            else: oor.append((a,d,be))
            if be & 1: recon[2*a]   = d & 0xFF
            if be & 2: recon[2*a+1] = (d>>8)&0xFF

    ok=True
    def check(cond,msg):
        nonlocal ok
        print(("  [PASS] " if cond else "  [FAIL] ")+msg); ok&=bool(cond)

    print("=== zunit_download cross-model ===")
    print("write lines=%d  gfx-range=%d  prog-range=%d  snd-range=%d  out-of-range=%d"
          %(n_lines,n_gfx_w,n_prog_w,n_snd_w,len(oor)))

    check(len(oor)==0,
          "no write outside gfx[0,0x%X)/prog[0x%X,0x%X)/snd[0x%X,0x%X) (zero PLA/gap spill)"
          %(GFX_WORDS,ROMW_BASE,ROMW_BASE+PROG_WORDS,SNDW_BASE,SNDW_BASE+2*SND_IMAGE_WORDS))
    if oor: print("      first OOR:", ["0x%X"%x[0] for x in oor[:4]])

    check(n_gfx_w==GFX_BYTES,  "gfx byte-lane writes == 0x%X"%GFX_BYTES)
    check(n_prog_w==PROG_WORDS,"program word writes  == 0x%X"%PROG_WORDS)
    check(n_snd_w==SND_BYTES,  "sound byte-lane writes == 0x%X (2 x 0x%X images)"
          %(SND_BYTES,SND_IMAGE_BYTES))

    # byte-exact + key-set-exact
    check(set(recon.keys())==set(exp.keys()),
          "reconstructed byte-set == expected byte-set (%d bytes)"%len(exp))
    # locate first diff (bounded report)
    diff=None
    for k in exp:
        if recon.get(k)!=exp[k]: diff=k; break
    check(diff is None,
          "byte-exact vs blind init_gfxrom(8)+LE16 program+MRA sound images"
          + ("" if diff is None else " (first diff @0x%X exp=%02X got=%s)"
             %(diff,exp[diff],("%02X"%recon[diff]) if diff in recon else "--")))

    print("\nRESULT: %s"%("PASS" if ok else "FAIL"))
    sys.exit(0 if ok else 1)

if __name__=="__main__":
    main()
