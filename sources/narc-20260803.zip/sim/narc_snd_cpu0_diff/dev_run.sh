#!/usr/bin/env bash
# dev_run.sh -- single stable-command build+run helper for the cpu0 diff harness
# so the iterative loop needs only ONE permission grant. Usage:
#   ./dev_run.sh                 # build+run GATE only (fast frontier check)
#   ./dev_run.sh full            # build+run GATE + CC mutant + YM-busy mutant
# Exits 0 always (measurement tool); prints the FRONTIER line(s).
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
SND="$ROOT/rtl/sound"
IVL="${IVERILOG:-/c/iverilog/bin/iverilog}"
VVP="${VVP:-/c/iverilog/bin/vvp}"
cd "$HERE"
mkdir -p build
python make_hex.py    >/dev/null 2>&1
python pack_golden.py "${NPACK:-30000}" >/dev/null 2>&1

JT51=()
while IFS= read -r f; do JT51+=("$f"); done < <(find "$SND/jt51/hdl" -maxdepth 1 -name '*.v' | sort)

build_run() { # $1=extra defines  $2=label  $3=out
  "$IVL" -g2012 -DJT51_ONLYTIMERS -DNARC_SIM_YM_BUSY_SHIM $1 -o "build/$3" -s tb_snd_cpu0_diff -I "$HERE" \
    "$SND/narc_sound_pkg.sv" "${JT51[@]}" \
    "$SND/williams_cvsd/mc6809is.v" "$SND/sim/hc55564_stub.v" \
    "$SND/narc_sound_bank.sv" "$SND/narc_sound_latch.sv" "$SND/narc_sound_board.sv" \
    "$HERE/tb_snd_cpu0_diff.sv" 2>&1 | sed 's/^/[iverilog] /'
  echo "===== $2 ====="
  timeout 600 "$VVP" "build/$3" 2>&1 | grep -E "MISMATCH|FIELD|RESULT|FRONTIER|reason|WEDGE|TIMEOUT" | sed 's/^/  /'
}

if [ "${1:-}" = "probe" ]; then
  "$IVL" -g2012 -DJT51_ONLYTIMERS -DNARC_SIM_YM_BUSY_SHIM -DYM_PROBE \
    -o build/diff_probe.vvp -s tb_snd_cpu0_diff -I "$HERE" \
    "$SND/narc_sound_pkg.sv" "${JT51[@]}" \
    "$SND/williams_cvsd/mc6809is.v" "$SND/sim/hc55564_stub.v" \
    "$SND/narc_sound_bank.sv" "$SND/narc_sound_latch.sv" "$SND/narc_sound_board.sv" \
    "$HERE/tb_snd_cpu0_diff.sv" 2>&1 | sed 's/^/[iverilog] /'
  echo "===== PROBE ====="
  timeout 600 "$VVP" build/diff_probe.vvp 2>&1 | grep -E "YMW|YMIRQ|MISMATCH|FRONTIER" | sed 's/^/  /'
  exit 0
fi

build_run "" "GATE" diff.vvp
if [ "${1:-}" = "full" ]; then
  build_run "-DMUTANT_INIT_CC"  "MUTANT_CC (must FAIL)"      diff_mut.vvp
  build_run "-DMUTANT_YM_BUSY"  "MUTANT_YM_BUSY (must FAIL)" diff_mut2.vvp
fi
exit 0
