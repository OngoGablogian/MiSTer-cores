#!/usr/bin/env bash
# run.sh -- iverilog-only master-6809 (cpu0) PER-INSTRUCTION diff vs the MAME
# 0.280 :narcsnd:cpu0 golden. NO Questa (mc6809is + jt51 are Verilog; hc55564
# VHDL blackboxed). Builds the gate + two MUTANT builds that MUST die.
# Overall exit 0 only when gate reaches its measured frontier AND both mutants
# FAIL (the diff is proven register-bit- and busy-model-sensitive).
#
# GATE DEFINES: -DNARC_SIM_YM_BUSY_SHIM turns on the SIM-ONLY MAME-faithful
# YM2151 master-visible model in narc_sound_board.sv (busy bit7 + Timer A/B
# overflow flags + FIRQ line, all transcribed from MAME 0.280 ymfm -- NOT tuned
# to the golden). jt51 stays instantiated AS-IS; the shim only overrides what the
# master reads/senses. The shim is INERT for synthesis and every other TB (they
# do not set the define), so G0a and the shared-board suite are untouched.
#
# MEASURED FRONTIER (this build): bit-exact through instruction 29006.
#   * 0..28904  : plain 6809 execution (no YM interaction that moves the trace).
#   * 28905     : first YM2151 BUSY poll. jt51 alone (32-cen_p1 busy) expired too
#                 early -> DUT read 0x00 where MAME read 0x80. FIXED by the
#                 MAME-faithful 64-YM-clock busy model (ymfm write_data ->
#                 set_busy_end(32*clock_prescale=2)=64; ymfm_mame from_ticks =>
#                 64 device input clocks). Advanced the frontier 28905 -> 28977.
#   * 28976     : first YM2151 Timer-A FIRQ. jt51's irq_n is sample-quantized
#                 (~3 6809 instrs late); the MAME-faithful Timer-A model (ymfm
#                 update_timer period=(1024-CLKA)*OPERATORS(32)*prescale(2) YM
#                 clocks = (1024-1020)*64 = 256; flag+auto-reload; IRQ=~flag)
#                 fires it at the exact overflow. Advanced 28977 -> 29006 and
#                 reproduces the FIRST periodic FIRQ bit-exact.
#   * 29006     : second periodic Timer-A FIRQ. RESIDUAL -- and it is NOT a
#                 peripheral-model bug. The Timer-A period is EXACTLY 256 cen_fm
#                 (measured overflow-to-overflow) = the datasheet/ymfm value, and
#                 no faithful period can put BOTH the 1st and 2nd overflow in the
#                 correct instruction window against the DUT's OWN instruction
#                 boundaries (that requires ~252, contradicting 256). The DUT
#                 executes the FIRQ handler+loop (~29 instrs, incl. one FIRQ
#                 entry) in ~4 cen_fm (~2 E-cycles) FEWER than MAME per period,
#                 so the periodic FIRQ recognition drifts one instruction late by
#                 the 2nd FIRQ. That is a mc6809is-vs-MAME-m6809 6809 CORE
#                 cycle-timing difference (most likely the FIRQ-entry cycle count
#                 / interrupt-sync), exposed only now because the FIRST FIRQ of
#                 the whole boot is at 28976. Reaching PC-saturation (~29675)
#                 needs the borrowed core made cycle-exact with MAME's m6809 for
#                 interrupt entry -- OUT of scope here (core is instantiate-as-is)
#                 and NOT maskable by tuning the YM period (that would be
#                 fitting-to-oracle). Reported as the measured frontier, not fudged.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
SND="$ROOT/rtl/sound"
IVL="${IVERILOG:-/c/iverilog/bin/iverilog}"
VVP="${VVP:-/c/iverilog/bin/vvp}"

cd "$HERE"
mkdir -p build
python make_hex.py
# pack the golden (default: 30000; the golden saturates at ~29675 so this covers
# the >=29675 target). Compare-target = NGOLD.
NPACK="${NPACK:-30000}"
python pack_golden.py "$NPACK"

JT51=()
while IFS= read -r f; do JT51+=("$f"); done < <(find "$SND/jt51/hdl" -maxdepth 1 -name '*.v' | sort)

build_run() { # $1=extra defines  $2=label  $3=out vvp
  "$IVL" -g2012 -DJT51_ONLYTIMERS -DNARC_SIM_YM_BUSY_SHIM $1 -o "build/$3" \
    -s tb_snd_cpu0_diff -I "$HERE" \
    "$SND/narc_sound_pkg.sv" \
    "${JT51[@]}" \
    "$SND/williams_cvsd/mc6809is.v" \
    "$SND/sim/hc55564_stub.v" \
    "$SND/narc_sound_bank.sv" \
    "$SND/narc_sound_latch.sv" \
    "$SND/narc_sound_board.sv" \
    "$HERE/tb_snd_cpu0_diff.sv"
  echo "===== $2 ====="
  "$VVP" "build/$3"
}

GATE_LOG="$(build_run "" "GATE (MAME-faithful busy + Timer-A FIRQ shim)" diff.vvp)"
echo "$GATE_LOG"
# discriminator 1: wrong CC init bit -> the compare must die at instruction 0.
MUT_LOG="$(build_run "-DMUTANT_INIT_CC" "MUTANT (wrong CC init bit)" diff_mut.vvp)"
echo "$MUT_LOG"
# discriminator 2: too-short YM2151 busy seed -> the master's $2001 poll reads
# not-busy on its first read -> reintroduces the ~28905 busy-poll divergence.
MUT2_LOG="$(build_run "-DMUTANT_YM_BUSY" "MUTANT (wrong YM busy seed)" diff_mut2.vvp)"
echo "$MUT2_LOG"

gate_pass=$(echo "$GATE_LOG" | grep -c "^RESULT: PASS" || true)
mut_pass=$( echo "$MUT_LOG"  | grep -c "^RESULT: PASS" || true)
mut2_pass=$(echo "$MUT2_LOG" | grep -c "^RESULT: PASS" || true)
frontier=$( echo "$GATE_LOG" | sed -n 's/^FRONTIER: bit-exact=\([0-9]*\).*/\1/p' | tail -1)
mut_front=$( echo "$MUT_LOG"  | sed -n 's/^FRONTIER: bit-exact=\([0-9]*\).*/\1/p' | tail -1)
mut2_front=$(echo "$MUT2_LOG" | sed -n 's/^FRONTIER: bit-exact=\([0-9]*\).*/\1/p' | tail -1)
echo "CC-MUTANT   frontier=$mut_front  (expect 0; wrong CC init caught immediately)"
echo "BUSY-MUTANT frontier=$mut2_front (expect ~28905; wrong busy seed reintroduces the poll divergence)"

echo "================================================================"
# both mutants MUST die (proves the diff discriminates register bits AND the
# MAME-faithful busy model). If the gate reaches the >=29675 target it is a full
# PASS; otherwise the measured frontier is reported (NOT fudged) and the run is a
# machinery-proven PARTIAL as long as both mutants died.
if [ "$mut_pass" -ne 0 ] || [ "$mut2_pass" -ne 0 ]; then
  echo "MACHINERY FAIL: a mutant did NOT die (cc_dies=$([ "$mut_pass" -eq 0 ] && echo yes || echo NO) busy_dies=$([ "$mut2_pass" -eq 0 ] && echo yes || echo NO))"
  exit 1
fi
if [ "$gate_pass" -ge 1 ]; then
  echo "CPU0-DIFF: PASS  (bit-exact per-instruction to target vs :narcsnd:cpu0"
  echo "                  golden; wrong-CC and wrong-YM-busy mutants both DIE)"
  exit 0
fi
echo "CPU0-DIFF: gate_bit_exact=$frontier  cc_mutant_dies=yes  busy_mutant_dies=yes"
echo "PARTIAL: bit-exact to instr $frontier. Busy shim (28905->28977) and Timer-A"
echo "FIRQ shim (28977->29006) are MAME-faithful and validated; the residual at"
echo "$frontier is a mc6809is-vs-MAME-m6809 6809 CORE cycle-timing difference on the"
echo "periodic Timer-A FIRQ recognition (NOT a peripheral model; not maskable"
echo "without fitting-to-oracle or making the borrowed core cycle-exact)."
exit 2
