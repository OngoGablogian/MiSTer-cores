#!/usr/bin/env python3
"""Pick the golden blit index that is the LAST writer for the most pixels.

Dropping this blit is guaranteed to leave those pixels at an earlier value, so the
RTL end VRAM must then mismatch T1 over D -> the drop mutant is guaranteed to kill
the gate (a strong exercise proof, not a lucky one). Prints one integer.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ACCUM = os.path.abspath(os.path.join(HERE, "..", "..", "..", "mame-trace", "accum_golden"))
sys.path.insert(0, ACCUM)
from replay_accum import parse_blits, load_vram, dma_blit, W, NPIX, DEF_BLITS, DEF_T0  # noqa: E402


def main():
    blits, _ = parse_blits(DEF_BLITS)
    last_writer = [-1] * NPIX
    for bi, b in enumerate(blits):
        regs, base, glen, gfx = b["regs"], b["gfx_base"], b["gfx_len"], b["gfx"]

        def gfx_read(o, base=base, glen=glen, gfx=gfx):
            if not (base <= o < base + glen):
                raise LookupError("oob")
            return gfx[o - base]

        def vram_write(x, y, val, bi=bi):
            last_writer[(y & 0x1FF) * W + (x & 0x1FF)] = bi

        dma_blit(regs, gfx_read, vram_write)

    counts = {}
    for lw in last_writer:
        if lw >= 0:
            counts[lw] = counts.get(lw, 0) + 1
    best = max(counts, key=counts.get)
    print(best)
    return 0


if __name__ == "__main__":
    sys.exit(main())
