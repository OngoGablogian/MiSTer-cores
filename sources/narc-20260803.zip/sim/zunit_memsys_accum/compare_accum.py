#!/usr/bin/env python3
"""Byte-diff the zunit_memsys RTL END-OF-FRAME VRAM against MAME 0.280's T1,
over the SAME DMA-written set D that replay_accum.py masks. NO tolerance.

Oracle triple = mame-trace/goldens/narc_accum_{blits.txt,t0_vram.hex,t1_vram.hex}
RTL out       = dut_vram.hex (full 512x512 end VRAM from tb_zunit_memsys_accum.sv)

Set D is built by the IDENTICAL code path replay_accum.py uses: the independent
blind golden dma_blit (blitter_golden/, transcribed from DMA.DOC + midyunit_v.cpp,
never from RTL) is run over the full ordered golden stream onto T0, and D = the
set of pixels it WRITES (`written`). This is byte-for-byte the same mask
replay_accum computes -- we import its parser + golden, we do not re-derive D.

Gate (DESIGN-RULES.md 5, no tolerance): PASS iff, over D, RTL_end == T1 for EVERY word.
The non-DMA residual {p : golden_fb[p] != T1[p] AND p not in D} is the SRT/CPU
delta -- out of scope for the DMA-accumulation claim; it is MEASURED and REPORTED
(count + capture's SRT/CPUW taps), NEVER absorbed by tolerance and NEVER allowed
to touch the D-region bit-exact check.

Oracle-consistency guard (never weaken): if the golden's own accumulation is not
bit-exact over D (replay_accum's own d_mismatch != 0), the triple is inconsistent
-> HARD FAIL (do not silently pass off a broken oracle).

Exit 0 = PASS.  Usage: python compare_accum.py [dut_vram.hex]
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ACCUM = os.path.abspath(os.path.join(HERE, "..", "..", "..", "mame-trace", "accum_golden"))
sys.path.insert(0, ACCUM)
from replay_accum import (parse_blits, load_vram, dma_blit,  # noqa: E402
                          W, NPIX, DEF_BLITS, DEF_T0, DEF_T1)

DUT = os.path.join(HERE, sys.argv[1] if len(sys.argv) > 1 else "dut_vram.hex")


def build_golden():
    """Recompute (written=D, golden_fb) EXACTLY as replay_accum.main does."""
    blits, meta = parse_blits(DEF_BLITS)
    fb = load_vram(DEF_T0)
    written = bytearray(NPIX)

    for b in blits:
        regs, base, glen, gfx = b["regs"], b["gfx_base"], b["gfx_len"], b["gfx"]

        def gfx_read(o, base=base, glen=glen, gfx=gfx):
            if not (base <= o < base + glen):
                raise LookupError(f"golden fetched gfx {o:#x} outside span")
            return gfx[o - base]

        def vram_write(x, y, val):
            idx = (y & 0x1FF) * W + (x & 0x1FF)
            fb[idx] = val & 0xFFFF
            written[idx] = 1

        dma_blit(regs, gfx_read, vram_write)
    return blits, meta, fb, written


def main():
    blits, meta, gfb, written = build_golden()
    t1 = load_vram(DEF_T1)
    t0 = load_vram(DEF_T0)

    rtl = load_vram(DUT)  # load_vram enforces exactly NPIX words

    # --- oracle-consistency guard: golden accumulation must be bit-exact over D
    g_d = g_dmis = 0
    for idx in range(NPIX):
        if written[idx]:
            g_d += 1
            if gfb[idx] != t1[idx]:
                g_dmis += 1
    if g_dmis != 0:
        print(f"ORACLE-INCONSISTENT: golden fb != T1 over {g_dmis}/{g_d} D pixels "
              f"(broken oracle triple; NOT tolerated)")
        return 1

    # --- the RTL gate: RTL_end == T1 over D (identical mask), no tolerance ------
    d_total = d_mismatch = 0
    d_fail = []
    for idx in range(NPIX):
        if written[idx]:
            d_total += 1
            if rtl[idx] != t1[idx]:
                d_mismatch += 1
                if len(d_fail) < 12:
                    y, x = divmod(idx, W)
                    d_fail.append(f"  D-MISMATCH ({x},{y}): rtl {rtl[idx]:04X} != T1 {t1[idx]:04X}")

    # --- non-DMA residual (measured + reported, never tolerance-absorbed) -------
    resid = [idx for idx in range(NPIX) if gfb[idx] != t1[idx] and not written[idx]]
    cpuw, srt = meta.get("cpuw"), meta.get("srt_seen")

    print(f"blits(golden)={len(blits)}  DMA-written pixels D={d_total}")
    print(f"RTL D-region mismatches vs T1 = {d_mismatch}  "
          f"(0 => RTL accumulation bit-exact over every DMA-written pixel)")
    print(f"non-DMA residual (golden_fb!=T1, pixel NOT in D)={len(resid)}  "
          f"[out of scope: SRT/CPU writers -- measured, NOT tolerated into D]")
    print(f"capture: CPU-direct vram_w writes={cpuw}, DPYCTL.SRT seen={srt}")
    for s in d_fail:
        print(s)
    for idx in resid[:6]:
        y, x = divmod(idx, W)
        print(f"  RESID ({x},{y}): T0 {t0[idx]:04X} -> T1 {t1[idx]:04X}")

    ok = (len(blits) >= 6 and d_total > 0 and d_mismatch == 0)
    print("GATE: " + ("PASS -- RTL T0->T1 accumulation bit-exact over the golden "
                      "DMA-written set D; non-DMA residual measured+reported"
                      if ok else "FAIL"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
