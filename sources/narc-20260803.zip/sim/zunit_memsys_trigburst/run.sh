#!/usr/bin/env bash
# NARC discriminating gate for the DMA trigger-collision stall (cont.25 / donor
# 323472c), ported to the Z-unit fork. BASE must PASS; the -DMUT_NO_TRIGSTALL
# mutant (reverts the zunit_memsys D_IDLE stall) must DIE (collide-and-drop).
# The frozen zunit_dma.sv / zunit_mem.sv are NEVER modified.
# Keep every path quoted (repo tree contains a space).
set -u
export PATH="/c/iverilog/bin:$PATH"

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
PKG="$ROOT/rtl/zunit/zunit_pkg.sv"
DMA="$ROOT/rtl/zunit/zunit_dma.sv"
MEM="$ROOT/rtl/zunit/zunit_mem.sv"
SYS="$ROOT/rtl/zunit/zunit_memsys.sv"
TB="$HERE/tb_zunit_memsys_trigburst.sv"

cd "$HERE"

if [ ! -f "$ROOT/sim/build/narc_maindata.hex" ]; then
  echo "MISSING $ROOT/sim/build/narc_maindata.hex (build it via the memsys gates' prep)"; exit 1
fi

build_run() {   # $1 = extra defines (may be empty)
  local defs="$1"
  rm -f build.vvp
  iverilog -g2012 $defs -I "$HERE" -s tb_zunit_memsys_trigburst \
      -o build.vvp "$PKG" "$DMA" "$MEM" "$SYS" "$TB" 2> iverilog.log
  if [ $? -ne 0 ]; then echo "IVERILOG FAIL"; cat iverilog.log; return 2; fi
  vvp build.vvp > vvp.log 2>&1
  grep -q "^PASS: tb_zunit_memsys_trigburst" vvp.log
  return $?
}

echo "== BASE (expect PASS) =="
build_run ""
if [ $? -ne 0 ]; then echo "RESULT: BASE FAILED"; tail -8 vvp.log; exit 1; fi
grep -E "^\[trigburst\]|^ok\(0\)|^PASS" vvp.log

echo "== MUTANT -DMUT_NO_TRIGSTALL (expect FAIL / die) =="
build_run "-DMUT_NO_TRIGSTALL"
if [ $? -eq 0 ]; then echo "RESULT: MUTANT DID NOT DIE (stall not exercised)"; exit 1; fi
echo "  MUT_NO_TRIGSTALL : DIED (caught)"; grep -E "^\[trigburst\]|^FAIL" vvp.log | head -6

echo "== SUMMARY =="
echo "RESULT: PASS  (base all-4-blits full pixel count; trigger-collision-stall revert died)"
