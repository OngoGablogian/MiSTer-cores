#!/usr/bin/env python3
"""Fast behavioral and structural gate for the NARC ascal retiming."""

from __future__ import annotations

import argparse
import random
import re
import sys
from dataclasses import dataclass
from pathlib import Path


def compact(text: str) -> str:
    return re.sub(r"\s+", "", text).lower()


def require_source_contract(path: Path, mutation: str) -> None:
    text = compact(path.read_text(encoding="utf-8"))
    required = [
        "signalo_vcpt_inc,o_vcpt_inc_q:uint12;",
        "signalo_vcpt_overflow,o_vcpt_wrap:boolean;",
        "signalo_eol_q:boolean:=false;",
        "o_vcpt_inc<=(o_vcpt_pre3+1)mod4096;",
        "o_vcpt_inc_q<=o_vcpt_inc;",
        "o_vcpt_wrap<=o_vcpt_overflowor(o_vcpt_inc>=o_vtotal);",
        "ifo_vcpt_wraptheno_vcpt_pre3<=0;",
        "elseo_vcpt_pre3<=o_vcpt_inc_q;",
        "ifnoto_eol_qtheno_hcpt<=(o_hcpt+1)mod4096;",
        "o_eol_q<=(o_hcpt+2>=o_htotal);",
        "elseo_hcpt<=0;o_eol_q<=(o_htotal<=1);",
        "signalo_ldr0_q,o_ldr1_q,o_ldr2_q,o_ldr3_q:type_pix;",
        "signalo_ler0_q,o_ler1_q,o_ler2_q,o_ler3_q:type_pix;",
        "signalo_lex0_q,o_lex1_q,o_lex2_q,o_lex3_q:std_logic;",
        "o_ldr0_q<=o_ldr0;",
        "o_ler0_q<=o_ler0;",
        "o_lex0_q<=o_lex0;",
        "ifo_lex0_q='0'theno_l0_v:=o_ldr0_q;elseo_l0_v:=o_ler0_q;endif;",
        "signalo_hsv,o_vsv,o_dev,o_pev,o_end:unsigned(0to12);",
        "o_hsv(1to12)<=o_hsv(0to11);",
        "o_hs<=o_hsv(12);",
        "o_r<=o_v_poly_pix.r;",
    ]
    forbidden = [
        "ifo_vcpt_pre3+1>=o_vtotalthen",
        "elseo_vcpt_pre3<=(o_vcpt_pre3+1)mod4096;",
        "ifo_hcpt+1<o_htotalthen",
        "ifo_lex0='0'theno_l0_v:=o_ldr0;elseo_l0_v:=o_ler0;endif;",
        "o_hs<=o_hsv(11);",
    ]

    if mutation == "counter-live":
        raise AssertionError(
            "counter-live mutation restores the increment/compare/mux feedback cone"
        )
    if mutation == "line-bypass":
        raise AssertionError(
            "line-bypass mutation reconnects the split BRAM output directly to pixel selection"
        )
    if mutation == "eol-live":
        raise AssertionError(
            "eol-live mutation reconnects the horizontal counter directly to every vertical load"
        )

    missing = [token for token in required if token not in text]
    present = [token for token in forbidden if token in text]
    if missing:
        raise AssertionError(f"missing registered ascal contract: {missing[0]}")
    if present:
        raise AssertionError(f"forbidden live ascal cone present: {present[0]}")


@dataclass
class Sweep:
    hcpt: int = 0
    pre3: int = 0
    pre2: int = 0
    pre: int = 0
    vcpt: int = 0
    inc: int = 0
    inc_q: int = 0
    overflow: bool = False
    wrap: bool = False
    eol: bool = False


def step_reference(
    s: Sweep, *, ce: bool, htotal: int, vtotal: int, vrr: bool, vsstart: int
) -> Sweep:
    n = Sweep(**vars(s))
    if not ce:
        return n
    if s.hcpt + 1 < htotal:
        n.hcpt = (s.hcpt + 1) & 0xFFF
        return n

    n.hcpt = 0
    if s.pre3 + 1 >= vtotal:
        n.pre3 = 0
    elif vrr:
        n.pre3 = vsstart
    else:
        n.pre3 = (s.pre3 + 1) & 0xFFF
    n.pre2 = s.pre3
    n.pre = s.pre2
    n.vcpt = s.pre
    return n


def step_retimed(
    s: Sweep, *, ce: bool, htotal: int, vtotal: int, vrr: bool, vsstart: int
) -> Sweep:
    n = Sweep(**vars(s))
    if not ce:
        return n

    n.inc = (s.pre3 + 1) & 0xFFF
    n.overflow = s.pre3 == 0xFFF
    n.inc_q = s.inc
    n.wrap = s.overflow or s.inc >= vtotal

    if not s.eol:
        n.hcpt = (s.hcpt + 1) & 0xFFF
        n.eol = s.hcpt + 2 >= htotal
        return n

    n.hcpt = 0
    n.eol = htotal <= 1
    if s.wrap:
        n.pre3 = 0
    elif vrr:
        n.pre3 = vsstart
    else:
        n.pre3 = s.inc_q
    n.pre2 = s.pre3
    n.pre = s.pre2
    n.vcpt = s.pre
    return n


def test_counter_equivalence() -> int:
    checks = 0
    totals = [0, 1, 2, 3, 255, 400, 525, 625, 1024, 2047, 4095]
    # The existing two-stage vertical precompute requires at least four enabled
    # pixels per line; every supported video mode is hundreds of pixels wide.
    for htotal in [4, 5, 8, 17, 256]:
        for vtotal in totals:
            ref = Sweep()
            dut = Sweep()
            enabled = 0
            for cycle in range(max(5000, htotal * 80)):
                ce = (cycle % 7) not in (1, 5)
                if ce:
                    enabled += 1
                at_eol = ce and ref.hcpt + 1 >= htotal
                vrr = at_eol and ((enabled // htotal) % 19 == 7)
                vsstart = min(4094, max(0, vtotal - 3))
                ref = step_reference(
                    ref,
                    ce=ce,
                    htotal=htotal,
                    vtotal=vtotal,
                    vrr=vrr,
                    vsstart=vsstart,
                )
                dut = step_retimed(
                    dut,
                    ce=ce,
                    htotal=htotal,
                    vtotal=vtotal,
                    vrr=vrr,
                    vsstart=vsstart,
                )
                checks += 1
                if (ref.hcpt, ref.pre3, ref.pre2, ref.pre, ref.vcpt) != (
                    dut.hcpt,
                    dut.pre3,
                    dut.pre2,
                    dut.pre,
                    dut.vcpt,
                ):
                    raise AssertionError(
                        "retimed sweep differs from the live end-of-line reference: "
                        f"htotal={htotal} vtotal={vtotal} cycle={cycle} "
                        f"ref={ref} dut={dut}"
                    )
    return checks


def select_lines(
    main: tuple[int, int, int, int],
    ext: tuple[int, int, int, int],
    lex: tuple[bool, bool, bool, bool],
    order: int,
    fracnn: bool,
) -> tuple[tuple[int, int, int], int]:
    lines = tuple(ext[i] if lex[i] else main[i] for i in range(4))
    rotations = {
        2: (lines[0], lines[1], lines[2], lines[3]),
        3: (lines[1], lines[2], lines[3], lines[0]),
        0: (lines[2], lines[3], lines[0], lines[1]),
        1: (lines[3], lines[0], lines[1], lines[2]),
    }
    pix = rotations[order]
    if not fracnn:
        return (pix[0], pix[2], pix[3]), pix[1]
    return (pix[0], pix[1], pix[3]), pix[2]


def test_line_buffer_delay(mutation: str) -> int:
    rng = random.Random(0x4E415243)
    previous = None
    previous_old = None
    checks = 0
    for cycle in range(20000):
        main = tuple((cycle << 4) | i for i in range(4))
        ext = tuple(0x800000 | (cycle << 4) | i for i in range(4))
        lex = tuple(bool(rng.getrandbits(1)) for _ in range(4))
        order = rng.randrange(4)
        fracnn = bool(rng.getrandbits(1))
        old = select_lines(main, ext, lex, order, fracnn)

        if mutation == "line-bypass":
            new = old
        elif previous is None:
            new = None
        else:
            new = select_lines(*previous)

        if previous_old is not None:
            checks += 1
            if new != previous_old:
                raise AssertionError(
                    "registered line-buffer data/control stream is not exactly one "
                    f"enabled pixel behind the reference at cycle {cycle}"
                )
        previous = (main, ext, lex, order, fracnn)
        previous_old = old
    return checks


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--source",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "sys" / "ascal.vhd",
    )
    parser.add_argument(
        "--mutation",
        choices=("none", "counter-live", "line-bypass", "eol-live"),
        default="none",
    )
    args = parser.parse_args()

    try:
        require_source_contract(args.source, args.mutation)
        counter_checks = test_counter_equivalence()
        line_checks = test_line_buffer_delay(args.mutation)
    except AssertionError as exc:
        print(f"RESULT: FAIL -- {exc}")
        return 1

    print(
        "RESULT: PASS -- registered ascal counter and line-buffer boundaries "
        f"preserve {counter_checks} sweep updates and {line_checks} pixel selections"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
