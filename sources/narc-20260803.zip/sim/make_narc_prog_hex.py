#!/usr/bin/env python3
# make_narc_prog_hex.py — build the NARC (Z-unit, rev 7.00) 34010 program ROM
# $readmemh image for the boot-smoke sim (sim/tb_narc_boot.sv).
#
# GEOMETRY (cited): the 34010 program lives in the "maindata" region
# 0xFF800000-0xFFFFFFFF (= 0x100000 bytes, 16-bit LE). Only the top 512 KB is
# populated on NARC — MAME midyunit.cpp:1466-1470 (ROM_REGION16_LE 0x100000):
#     ROM_LOAD16_BYTE( u42, 0x80000, 0x20000 )   even bytes (LE low), words 0x40000..0x5FFFF
#     ROM_LOAD16_BYTE( u24, 0x80001, 0x20000 )   odd  bytes (LE high)
#     ROM_LOAD16_BYTE( u41, 0xC0000, 0x20000 )   even bytes,           words 0x60000..0x7FFFF
#     ROM_LOAD16_BYTE( u23, 0xC0001, 0x20000 )   odd  bytes
# So the CPU sees 16-bit words at region-word 0x40000..0x7FFFF (byte 0x80000+).
# That is the Z-unit delta vs the donor Y-unit (Smash T.V. program at 0xFFE00000
# = region-word 0x60000); NARC program base = 0xFFC00000 = region-word 0x40000.
#
# The sim's yunit_mem holds ROM_WORDS words starting at region-word ROM_PROG_OFF
# (= 0x40000 for NARC), so rom[i] must be the word at maindata byte (0x80000+2*i):
#     rom[i]              = u42[i]              | u24[i]              << 8   (i < 0x20000)
#     rom[i + 0x20000]    = u41[i]              | u23[i]              << 8   (i < 0x20000)
# Output: 0x40000 (512 KB / 2) lines, one 16-bit word each (4 hex digits, lower).
# rom[0x3FFFE..0x3FFFF] hold the reset vector dword @0xFFFFFFE0 = 0xFFF6E000
# (the DINT that the maincpu executes first; MAME's debugger trace omits it, so
# the boot PC golden's first line is the following SETF @0xFFF6E010).
#
# Usage:  python3 sim/make_narc_prog_hex.py    (run from repo root)
import zipfile, os, sys

ZIP = "D:/deck/fpga/NARC/roms/narc.zip"
OUT = "sim/build"
OUT_HEX = os.path.join(OUT, "narc_maindata.hex")

# rev 7.00 game ROMs (top-level members of narc.zip). even=low byte, odd=high byte.
EVEN_LO = ["rev7_narc_game_rom_u42.u42", "rev7_narc_game_rom_u41.u41"]  # words 0..0x1FFFF, 0x20000..0x3FFFF
ODD_HI  = ["rev7_narc_game_rom_u24.u24", "rev7_narc_game_rom_u23.u23"]

def main():
    z = zipfile.ZipFile(ZIP)
    names = set(z.namelist())
    for n in EVEN_LO + ODD_HI:
        if n not in names:
            sys.exit("FATAL: %s not in %s" % (n, ZIP))
    words = []
    for lo_name, hi_name in zip(EVEN_LO, ODD_HI):
        lo = z.read(lo_name)
        hi = z.read(hi_name)
        if len(lo) != 0x20000 or len(hi) != 0x20000:
            sys.exit("FATAL: %s/%s expected 128KB, got %d/%d"
                     % (lo_name, hi_name, len(lo), len(hi)))
        for i in range(0x20000):
            words.append(lo[i] | (hi[i] << 8))
    assert len(words) == 0x40000, len(words)   # 512 KB / 2 = 0x40000 words

    os.makedirs(OUT, exist_ok=True)
    with open(OUT_HEX, "w", newline="\n") as f:
        f.write("\n".join("%04x" % w for w in words))
        f.write("\n")

    # Self-check: reset vector dword @0xFFFFFFE0. Region byte 0xFFFFC -> region
    # word 0x7FFFE -> rom index 0x7FFFE-0x40000 = 0x3FFFE. LE dword = w[3FFFE] |
    # w[3FFFF]<<16. Masked &~0xF -> boot PC. MAME loads 0xFFF6E000 (DINT).
    vec = words[0x3FFFE] | (words[0x3FFFF] << 16)
    boot_pc = vec & 0xFFFFFFF0
    print("%s: %d words (512KB)" % (OUT_HEX, len(words)))
    print("reset vector @0xFFFFFFE0 = %08X  -> boot PC %08X (expect FFF6E000)"
          % (vec, boot_pc))
    if boot_pc != 0xFFF6E000:
        sys.exit("FATAL: reset vector %08X != expected FFF6E000 (interleave wrong)" % boot_pc)

if __name__ == "__main__":
    main()
