#!/usr/bin/env bash
# questa_lock.sh — single-instance guard + orphan reaper + real pass/fail check
# for the UMK3 Questa runners.  SOURCE this (do not execute):  . "$(dirname "$0")/questa_lock.sh"
#
# WHY: Questa FSE 25.1std on this box is NODELOCKED to ONE concurrent vsim. A
# second vsim dies with "an instance of QuestaSim is already running with a
# nodelocked license". A timed-out/kill-9'd runner leaves its vsim GRANDCHILD
# alive, orphaned, still holding the single license -> the next run cannot check
# it out. The autopilot loop is STRICTLY SEQUENTIAL: there is never a legitimate
# concurrent vsim, so once we hold the lock, any pre-existing vsim is by
# definition an orphan and is safe to reap.
#
# Provides three functions:
#   questa_acquire            — atomically take the lock (mkdir); steal if the
#                               holder PID is dead or the lock is stale (>30 min);
#                               bounded-wait otherwise; then reap orphan tools.
#                               Returns non-zero if it truly cannot acquire
#                               (runner must then report BLOCKED, not fake-pass).
#   questa_release            — drop the lock + kill OUR OWN Questa children.
#                               Wire via `trap questa_release EXIT`.
#   questa_check_result FILE RE — inspect the vsim logfile; non-zero (with a
#                               clear FAIL/LICENSE-ERROR line) on license error,
#                               "Error loading design", "Errors: [1-9]", a TB
#                               FAIL, or absence of the expected PASS token.
#
# Idempotent + safe to source from all runners. Pure bash. No external deps
# beyond coreutils + Windows taskkill (already on PATH in git-bash).

# Guard against double-sourcing (idempotent).
if [ -n "${QUESTA_LOCK_SH_SOURCED:-}" ]; then return 0 2>/dev/null || true; fi
QUESTA_LOCK_SH_SOURCED=1

# ---- config ----------------------------------------------------------------
# Fixed absolute lock path. Prefer a POSIX tmp dir: $TMPDIR is empty in this
# git-bash and $TMP is a backslashed Windows path (unsafe for mkdir), so fall
# back to /tmp which exists here. The path is FIXED so every runner contends on
# the same lock regardless of cwd.
_ql_tmp="${TMPDIR:-}"
case "$_ql_tmp" in ""|*\\*) _ql_tmp="/tmp";; esac   # reject empty or backslashed
QUESTA_LOCK_DIR="${QUESTA_LOCK_DIR:-$_ql_tmp/umk3_questa.lock}"
QUESTA_LOCK_PIDFILE="$QUESTA_LOCK_DIR/pid"
QUESTA_LOCK_STALE_SECS="${QUESTA_LOCK_STALE_SECS:-1800}"   # 30 min
QUESTA_LOCK_WAIT_SECS="${QUESTA_LOCK_WAIT_SECS:-120}"      # bounded wait before giving up
QUESTA_LOCK_POLL_SECS="${QUESTA_LOCK_POLL_SECS:-3}"
# Windows tools that hold/consume the nodelocked license.
QUESTA_TOOLS="vsim vish vopt vlog vlib vcom vsimk vsimsa"
# Whether THIS shell currently owns the lock (so release only rmdir's our own).
_QL_HELD=0

# taskkill by Windows PID; no-op cleanly if $1 empty / process already gone.
_ql_taskkill_winpid() {
  local wp="$1"
  [ -n "$wp" ] || return 0
  taskkill //PID "$wp" //F >/dev/null 2>&1 || true
}

# Echo the WINPIDs (real Windows PIDs, col 4 of `ps -W`) of every live Questa
# tool process. `taskkill //PID` needs the WINPID, NOT the msys PID.
_ql_questa_winpids() {
  local pat
  pat="$(echo "$QUESTA_TOOLS" | tr ' ' '|')"
  # ps -W columns: PID PPID PGID WINPID TTY UID STIME COMMAND
  ps -W 2>/dev/null | grep -iE "/($pat)\.exe|\\\\($pat)\.exe|[ /\\]($pat)\.exe" \
    | awk '{print $4}' | grep -E '^[0-9]+$' || true
}

# Reap every live Questa tool process (orphans). SAFE only while we hold the
# lock — the sequential loop guarantees no legitimate concurrent vsim exists.
_ql_reap_all() {
  local wp any=0
  for wp in $(_ql_questa_winpids); do
    _ql_taskkill_winpid "$wp"; any=1
  done
  [ "$any" = 1 ] && echo "questa_lock: reaped orphan Questa process(es)" >&2
  return 0
}

# Is a Windows PID currently alive? (tasklist filter; empty output => dead.)
_ql_winpid_alive() {
  local wp="$1"
  [ -n "$wp" ] || return 1
  tasklist //FI "PID eq $wp" //NH 2>/dev/null | grep -qE "[a-zA-Z]" && return 0
  return 1
}

# Age (seconds) of the lock dir; large number if it does not exist.
_ql_lock_age() {
  local now mtime
  now="$(date +%s 2>/dev/null || echo 0)"
  if [ -d "$QUESTA_LOCK_DIR" ]; then
    mtime="$(stat -c %Y "$QUESTA_LOCK_DIR" 2>/dev/null || echo 0)"
    echo $(( now - mtime ))
  else
    echo 999999999
  fi
}

# Read the holder pid, RETRYING briefly: mkdir is atomic but the winner writes
# its pid a few instructions LATER, so a loser that reads the pidfile in that
# window sees it empty. Retry ~1s to close that write-race before concluding
# "no pid" (a genuine crash between mkdir and the pid write).
_ql_read_holder() {
  local h="" i=0
  while [ "$i" -lt 5 ]; do
    h="$(cat "$QUESTA_LOCK_PIDFILE" 2>/dev/null || true)"
    [ -n "$h" ] && { printf '%s' "$h"; return 0; }
    sleep 0.2
    i=$(( i + 1 ))
  done
  printf ''    # genuinely empty after retries
  return 0
}

# Try one atomic mkdir; on success record our pid + mark held.
_ql_try_mkdir() {
  if mkdir "$QUESTA_LOCK_DIR" 2>/dev/null; then
    echo "$$" > "$QUESTA_LOCK_PIDFILE" 2>/dev/null || true
    _QL_HELD=1
    return 0
  fi
  return 1
}

# Steal the lock: forcibly remove the dir and re-create it for us.
_ql_steal() {
  echo "questa_lock: stealing stale/dead lock $QUESTA_LOCK_DIR" >&2
  rm -rf "$QUESTA_LOCK_DIR" 2>/dev/null || true
  _ql_try_mkdir
}

# questa_acquire — take the single-instance lock, then reap orphan tools.
# Steal rules (safety-first — NEVER kill a legitimate live run):
#   * holder shell DEAD (or empty pidfile after retry) -> steal immediately; a
#     post-acquire reap clears any orphan vsim it left holding the license.
#   * holder shell ALIVE -> a run is in progress: WAIT (bounded), then BLOCKED.
#     Do NOT steal on age alone — the ONLY age-steal is when the lock is old AND
#     no Questa tool is actually running (the holder PID was reused by an
#     unrelated process), which cannot describe a live sim.
questa_acquire() {
  local waited=0 holder holder_winpid age qpids
  while : ; do
    if _ql_try_mkdir; then
      break
    fi
    # Lock is held by someone. Read the pid with a retry to close the
    # mkdir->pid-write race, then decide: steal (dead/broken/stale) or wait.
    holder="$(_ql_read_holder)"
    age="$(_ql_lock_age)"
    qpids="$(_ql_questa_winpids)"
    # The pidfile holds an msys PID ($$). Map it to a WINPID to test liveness.
    holder_winpid=""
    if [ -n "$holder" ]; then
      holder_winpid="$(ps -W 2>/dev/null | awk -v p="$holder" '$1==p {print $4}' | head -1)"
    fi
    if [ -n "$holder" ] && [ -n "$holder_winpid" ] && _ql_winpid_alive "$holder_winpid"; then
      # Holder shell is ALIVE => a run is in progress. Never steal it, EXCEPT the
      # stale-PID-reuse case: old lock AND no Questa tool actually running.
      if [ "$age" -gt "$QUESTA_LOCK_STALE_SECS" ] && [ -z "$qpids" ]; then
        echo "questa_lock: stale lock (age ${age}s, holder alive but NO Questa running — pid reused) — stealing" >&2
        _ql_steal && break
      fi
      # else: legitimate run in progress -> fall through to bounded wait.
    else
      # Holder shell is DEAD or the pidfile stayed empty (crashed pre-write).
      # Safe to steal; the post-acquire reap clears any orphan vsim it left.
      echo "questa_lock: holder pid='${holder:-?}' dead/absent — stealing" >&2
      _ql_steal && break
    fi
    if [ "$waited" -ge "$QUESTA_LOCK_WAIT_SECS" ]; then
      echo "questa_lock: BLOCKED — could not acquire $QUESTA_LOCK_DIR after ${waited}s (holder pid=$holder alive; a Questa run is in progress)" >&2
      return 1
    fi
    echo "questa_lock: waiting for Questa lock (holder pid=$holder, ${waited}/${QUESTA_LOCK_WAIT_SECS}s) ..." >&2
    sleep "$QUESTA_LOCK_POLL_SECS"
    waited=$(( waited + QUESTA_LOCK_POLL_SECS ))
  done
  # We hold the lock now. Any pre-existing Questa process is an orphan -> reap.
  _ql_reap_all
  echo "questa_lock: acquired $QUESTA_LOCK_DIR (pid $$)" >&2
  return 0
}

# questa_release — reap our OWN interrupted vsim (orphan prevention) + drop the
# lock, but ONLY if we still own it. If another shell stole the lock from us
# (pidfile no longer $$), do NOT reap (that would kill the new holder's live
# vsim) and do NOT rmdir (that is the new holder's dir). Wire via
# `trap questa_release EXIT`. Safe to call when we never acquired.
# NOTE: _ql_reap_all kills EVERY live Questa tool by WINPID, not just our
# descendants — that is correct under the strictly-sequential model (at our
# release any live vsim is ours or an orphan) and is gated by the ownership
# check below so it never fires while another shell legitimately holds the lock.
questa_release() {
  local rc=$?
  if [ "$_QL_HELD" = 1 ]; then
    if [ "$(cat "$QUESTA_LOCK_PIDFILE" 2>/dev/null || echo x)" = "$$" ]; then
      _ql_reap_all                                   # our run's vsim, if it was interrupted
      rm -rf "$QUESTA_LOCK_DIR" 2>/dev/null || true
      echo "questa_lock: released $QUESTA_LOCK_DIR" >&2
    else
      echo "questa_lock: lock no longer ours (stolen) — not reaping/removing" >&2
    fi
    _QL_HELD=0
  fi
  return $rc
}

# questa_check_result <logfile> <PASS-regex>
# Propagate vsim's REAL pass/fail. Non-zero (with a clear line) if the log shows
# a license error / "Error loading design" / "Errors: [1-9]" / a TB FAIL, or if
# the expected PASS token is ABSENT. A silent success on a verifier is the worst
# failure mode — this is the guard against it.
questa_check_result() {
  local log="$1" pass_re="$2"
  if [ -z "$log" ] || [ ! -f "$log" ]; then
    echo "questa_check_result: FAIL — no vsim logfile ('$log')" >&2
    return 3
  fi
  # 1) License checkout failure (the nodelock symptom).
  if grep -qiE "license checkout .*disallowed|nodelocked license|Invalid license|cannot checkout|License checkout failed|already running with a nodelocked" "$log"; then
    echo "questa_check_result: LICENSE-ERROR — Questa could not check out the nodelocked license (orphan vsim holding it?)" >&2
    return 4
  fi
  # 2) Elaboration / fatal failure. Anchor to Questa's real error markers
  #    ('# ** Error:' / '# ** Fatal:') and the elaboration-load message. Do NOT
  #    match a bare 'vsim-' — that substring appears in BENIGN success notes like
  #    '# ** Note: (vsim-3812) Design is being optimized', which would fail a real
  #    PASS. Genuine elaboration errors also raise the Errors:N summary (step 3).
  if grep -qiE "Error loading design|^# \*\* Fatal|^# \*\* Error" "$log"; then
    echo "questa_check_result: FAIL — vsim reported an elaboration/fatal error" >&2
    return 5
  fi
  # 3) Non-zero error count from vsim's summary line ("Errors: N, Warnings: M, ...").
  #    Anchor on the trailing ", Warnings:" that ONLY the real error count carries, so the
  #    "Suppressed Errors: N" tail on the SAME line (N>0 when files are compiled with
  #    -suppress) does not false-trip this via a bare "Errors: N" substring match.
  if grep -qiE "Errors:[[:space:]]*[1-9][0-9]*,[[:space:]]*Warnings:" "$log"; then
    echo "questa_check_result: FAIL — vsim summary shows a non-zero error count" >&2
    return 6
  fi
  # 4) A TB-emitted FAIL.
  if grep -qE "\bFAIL\b" "$log"; then
    echo "questa_check_result: FAIL — the testbench emitted FAIL" >&2
    return 7
  fi
  # 5) Expected PASS token must be present (absence = not a real pass).
  if [ -n "$pass_re" ] && ! grep -qE "$pass_re" "$log"; then
    echo "questa_check_result: FAIL — expected PASS token /$pass_re/ absent from vsim log" >&2
    return 8
  fi
  echo "questa_check_result: PASS" >&2
  return 0
}
