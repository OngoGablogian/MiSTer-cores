`timescale 1ns/1ps
`default_nettype none
// =============================================================================
// zunit_snd_rom.sv — SDRAM read agent for the two NARC sound 6809s (D1 seam).
//
// WHY THIS EXISTS (the seam is NOT a plain wire-up)
// narc_snd_cpu consumes `rom_data` COMBINATIONALLY at the cen_e bus commit:
//     assign di = ... in_romall ? rom_data : ...;
// and mc6809is has no stall/wait input. SDRAM has variable, contended latency
// (a 512-beat scanout burst owns the controller for ~520 core clocks). So the
// ROM byte for the CURRENT offset must already be latched when cen_e fires, and
// when it is not, the only correct move is to WITHHOLD cen_e/cen_q until it is —
// i.e. stretch the 6809's E clock, the hardware equivalent of a wait state.
//
// The caller presents `ready` to the E/Q deadline generator, which stretches
// only an overdue falling-E edge. It must NOT gate the FM (YM2151) accumulator:
// freezing that would jitter audio pitch. Stretching E only under true overdue
// contention preserves normal authored cadence; freezing the FM clock would not.
//
// FETCH QUALIFICATION: only a core-visible ROM read (RnW & ROM select) may hold
// ready low or issue SDRAM work. AVMA is deliberately excluded: this borrowed
// mc6809is consumes D on some ROM-addressed states where AVMA is low. RAM, IO
// and writes advance at the native 2 MHz rate. Each lane caches a complete
// 16-bit SDRAM word, so sequential even/odd bytes share one transaction.
//
// LAYOUT: master image then slave image, each SND_IMAGE_WORDS words at SNDW_BASE
// (zunit_pkg; written byte-lane-wise by zunit_download from MRA stream 0x880000).
// =============================================================================
module zunit_snd_rom #(
  parameter int SD_AW       = 25,
  parameter logic [SD_AW-1:0] SNDW_BASE   = '0,
  parameter int IMAGE_WORDS = 32'h048000
)(
  input  wire        clk,
  input  wire        rst,

  // per-6809 flat byte offsets (combinational, from narc_sound_bank)
  input  wire [19:0] mst_offset,
  input  wire        mst_read,
  output wire [7:0]  mst_data,
  input  wire [19:0] slv_offset,
  input  wire        slv_read,
  output wire [7:0]  slv_data,

  // 1 = every lane currently reading ROM holds its current word
  output wire        ready,

  // SDRAM arbiter channel (req held until ack)
  output wire        snd_rd,
  output wire [SD_AW-1:0] snd_addr_w,
  input  wire [15:0] snd_data,
  input  wire        snd_ack,

  // observability: clk_sys cycles spent waiting on a true ROM read and the
  // number of bounded watchdog re-arms of an unacknowledged request
  output reg  [31:0] stall_clks,
  output reg  [31:0] wd_rearms
);
  // ---- input pipeline (TIMING, measured) -------------------------------------
  // mst_offset/slv_offset arrive straight out of narc_sound_bank's 20-bit three-term
  // offset adder, whose cone starts at the mc6809is address registers. Feeding that
  // combinationally into the fetch-address mux made this the WORST path in the whole
  // design at -2.154 ns (the first fit of this seam; under the old 8'h00 stub the adder
  // fed nothing and was optimized away, which is why it never showed up before).
  //
  // So the offsets are registered before anything else uses them, and ALL comparison and
  // fetch logic runs off the registered copy. Correctness relies on a property of the
  // 6809 bus, not on luck: the address is stable for the whole E cycle (~48 core clocks
  // at 2 MHz E off a ~96 MHz clk), so a registered copy converges long before cen_e is
  // allowed to fire. `stable` proves that convergence rather than assuming it --
  // a new SDRAM request cannot issue until two consecutive samples agree. A
  // tagged cache hit may of course satisfy `ready` immediately.
  reg  [19:0] off_r1 [0:1];
  reg  [19:0] off_r2 [0:1];
  reg         read_r1 [0:1];
  reg         read_r2 [0:1];
  always @(posedge clk) begin
    if (rst) begin
      // reset the pipeline explicitly: an X here would propagate through `stable`
      // into `ready` and gate the E divider on an unknown for the first clocks.
      off_r1[0] <= 20'd0; off_r2[0] <= 20'd1;   // deliberately UNEQUAL -> stable=0 out of reset
      off_r1[1] <= 20'd0; off_r2[1] <= 20'd1;
      read_r1[0] <= 1'b0; read_r2[0] <= 1'b0;
      read_r1[1] <= 1'b0; read_r2[1] <= 1'b0;
    end else begin
      off_r1[0] <= mst_offset;  off_r2[0] <= off_r1[0];
      off_r1[1] <= slv_offset;  off_r2[1] <= off_r1[1];
      read_r1[0] <= mst_read;    read_r2[0] <= read_r1[0];
      read_r1[1] <= slv_read;    read_r2[1] <= read_r1[1];
    end
  end
  wire stable0 = (off_r1[0] == off_r2[0]);
  wire stable1 = (off_r1[1] == off_r2[1]);

  // ---- per-lane coherency state ---------------------------------------------
  reg  [18:0] cur_word [0:1];
  reg  [15:0] cur_dat  [0:1];
  reg         cur_byte [0:1]; // discriminating byte-tag mutation state
  reg         cur_val [0:1];

`ifdef MUT_SND_ALWAYS_FETCH
  // Recreate the inherited always-fetch seam. The timing test must kill this.
  wire demand0 = 1'b1;
  wire demand1 = 1'b1;
  wire sampled_read0 = 1'b1;
  wire sampled_read1 = 1'b1;
`else
  wire demand0 = mst_read;
  wire demand1 = slv_read;
  wire sampled_read0 = read_r1[0] & read_r2[0];
  wire sampled_read1 = read_r1[1] & read_r2[1];
`endif

  // Register the converged request before it reaches the fetch FSM.  The first
  // fitted v7 image exposed why this stage is load-bearing: checking mst_read /
  // mst_offset again in the FSM-enable expression rebuilt a one-cycle path from
  // the mc6809is address-next cone through the ROM/hidden-RAM decode and three
  // cache-control LUTs into off_q (-1.284 ns).  A bus address is held for the
  // whole E period, so two matching registered samples are the authoritative
  // request.  If the live CPU moves on while another lane owns SDRAM, an older
  // qualified word may harmlessly fill the tagged cache; live_word below can
  // never publish it for the new address.
  reg  [19:0] cand_off [0:1];
  reg         cand_valid [0:1];
  always @(posedge clk) begin
    if (rst) begin
      cand_off[0] <= 20'd0; cand_valid[0] <= 1'b0;
      cand_off[1] <= 20'd0; cand_valid[1] <= 1'b0;
    end else begin
      cand_off[0] <= off_r2[0];
      cand_off[1] <= off_r2[1];
      cand_valid[0] <= sampled_read0 & stable0;
      cand_valid[1] <= sampled_read1 & stable1;
    end
  end

  wire [19:0] req_off [0:1];
  assign req_off[0] = cand_off[0];
  assign req_off[1] = cand_off[1];
  wire [18:0] req_word [0:1];
  assign req_word[0] = req_off[0][19:1];
  assign req_word[1] = req_off[1][19:1];

  wire word_match0 = cur_val[0] & (cur_word[0] == req_word[0]);
  wire word_match1 = cur_val[1] & (cur_word[1] == req_word[1]);
  wire live_word0  = cur_val[0] & (cur_word[0] == mst_offset[19:1]);
  wire live_word1  = cur_val[1] & (cur_word[1] == slv_offset[19:1]);

`ifdef MUT_SND_BYTE_TAG
  // Recreate the old byte-wide cache: an adjacent byte in the same SDRAM word
  // incorrectly misses and forces a duplicate transaction.
  wire cache_match0 = word_match0 & (cur_byte[0] == req_off[0][0]);
  wire cache_match1 = word_match1 & (cur_byte[1] == req_off[1][0]);
  wire live0 = live_word0 & (cur_byte[0] == mst_offset[0]);
  wire live1 = live_word1 & (cur_byte[1] == slv_offset[0]);
`else
  wire cache_match0 = word_match0;
  wire cache_match1 = word_match1;
  wire live0 = live_word0;
  wire live1 = live_word1;
`endif

  // What to FETCH is decided from the registered copy (keeps the bank adder out of the
  // fetch-address path, which is what blew timing).
  wire need0 = cand_valid[0] & ~cache_match0;
  wire need1 = cand_valid[1] & ~cache_match1;

  // A non-ROM cycle is always ready. A ROM cycle is ready only when the live
  // word is cached; this is the hardware wait-state seam for the current bus.
  assign ready = (~demand0 | live0) & (~demand1 | live1);

  assign mst_data = mst_offset[0] ? cur_dat[0][15:8] : cur_dat[0][7:0];
  assign slv_data = slv_offset[0] ? cur_dat[1][15:8] : cur_dat[1][7:0];

  // ---- fetch FSM: master lane first, then slave ------------------------------
  // One outstanding read. The offset is LATCHED at issue, so if the 6809 moves on
  // mid-fetch the result still lands against the offset it was requested for and
  // `need` simply reasserts for the new one (no stale byte can be published).
  reg         busy;
  reg         lane_q;        // lane of the in-flight read
  reg  [19:0] off_q;         // offset of the in-flight read
  wire        pick = need0 ? 1'b0 : 1'b1;
  wire [19:0] pick_off = need0 ? req_off[0] : req_off[1];

  // P0043: WATCHDOG RE-ARM. `busy` is single-outstanding with no timeout: once set,
  // `ready` stays low until snd_ack, and narc_6809_clock_en freezes its phase counter
  // whenever an E edge is due and rom_ready is low -- so a request that is never
  // acknowledged stops BOTH 6809s permanently and the board is silent for the rest of
  // the session. That is what makes cabinet audio a coin flip between builds (v9
  // worked, v10 was silent with NO sound-path change).
  //
  // If a request has been outstanding for WD_MAX clocks, drop snd_rd for one clock and
  // re-assert it. This RE-ISSUES the same address -- it never abandons the fetch and
  // never fabricates data, so a slow-but-alive memory system is unaffected (it just
  // sees the request again) while a LOST request now recovers instead of wedging.
  // WD_MAX is far beyond any legitimate service time: a 6809 E period is 48 clocks and
  // the lane has ~48 clocks of slack per period, so 4096 clocks means the request is
  // gone, not queued.
  localparam int WD_MAX = 4096;
  logic [12:0] wd_cnt;
  logic        wd_gap;          // 1-clock request drop, then re-assert
  assign snd_rd     = busy && !wd_gap;
  assign snd_addr_w = SNDW_BASE + SD_AW'(lane_q ? IMAGE_WORDS : 0)
                                + SD_AW'(off_q[19:1]);

  always @(posedge clk) begin
    if (rst) begin
      busy <= 1'b0; lane_q <= 1'b0; off_q <= 20'd0;
      cur_val[0] <= 1'b0; cur_val[1] <= 1'b0;
      cur_word[0] <= 19'd0; cur_word[1] <= 19'd0;
      cur_byte[0] <= 1'b0; cur_byte[1] <= 1'b0;
      cur_dat[0] <= 16'h0000; cur_dat[1] <= 16'h0000;
      stall_clks <= 32'd0;
      wd_cnt <= 13'd0; wd_gap <= 1'b0; wd_rearms <= 32'd0;
    end else begin
      if (!ready) stall_clks <= stall_clks + 32'd1;

      // P0043 watchdog: count only while a request is genuinely outstanding.
      wd_gap <= 1'b0;
`ifndef MUT_SNDROM_NO_WATCHDOG
      if (!busy || snd_ack) begin
        wd_cnt <= 13'd0;
      end else if (wd_cnt == WD_MAX[12:0]) begin
        wd_cnt   <= 13'd0;
        wd_gap   <= 1'b1;                      // re-issue the SAME address next clock
        wd_rearms <= wd_rearms + 32'd1;
      end else begin
        wd_cnt <= wd_cnt + 13'd1;
      end
`endif

      if (!busy) begin
        if (need0 | need1) begin
          busy   <= 1'b1;
          lane_q <= pick;
          off_q  <= pick_off;
        end
      end else if (snd_ack) begin
        busy               <= 1'b0;
        cur_word[lane_q]   <= off_q[19:1];
        cur_byte[lane_q]   <= off_q[0];
        cur_dat[lane_q]    <= snd_data;
        cur_val[lane_q]    <= 1'b1;
      end
    end
  end
endmodule
`default_nettype wire
