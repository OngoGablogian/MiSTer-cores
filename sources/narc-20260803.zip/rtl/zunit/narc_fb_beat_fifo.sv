// narc_fb_beat_fifo.sv -- NARC-only elastic framebuffer ingress.
//
// The Rev-1 DMA produces one complete 16-bit framebuffer entry at a time, but
// the DDR3 bridge stores four adjacent entries in one 64-bit beat.  Buffering
// raw pixels therefore spends 34 RAM bits per pixel.  This queue first merges
// adjacent writes into {beat address, lane mask, 64-bit data} records, then
// replays their valid lanes in order to the existing, fully coherent DDR3
// writer.  It changes storage density only: addresses, data, ordering, flush,
// and downstream acknowledgement semantics are preserved.
`timescale 1ns/1ps
`default_nettype none

module narc_fb_beat_fifo #(
  parameter integer DEPTH = 16384
)(
  input  logic        clk,
  input  logic        rst,

  input  logic        in_we,
  input  logic [17:0] in_addr,
  input  logic [15:0] in_data,
  input  logic        in_allow,
  output logic        in_ack,
  input  logic        in_flush,

  output logic        out_we,
  output logic [17:0] out_addr,
  output logic [15:0] out_data,
  input  logic        out_ack,
  output logic        out_flush,
  input  logic        out_busy,

  output logic        pending,
  output logic        busy
);
  localparam integer AW = $clog2(DEPTH);
  localparam [1:0] O_IDLE=2'd0, O_LOAD=2'd1, O_SEND=2'd2;

  // One record is four framebuffer pixels in one DDR3 beat.
  (* ramstyle="M10K" *) logic [83:0] qmem [0:DEPTH-1];
  logic [AW:0] wptr, rptr;
  wire q_empty = (wptr == rptr);
  wire q_full  = (wptr[AW] != rptr[AW]) &&
                 (wptr[AW-1:0] == rptr[AW-1:0]);

  logic        acc_valid;
  logic [15:0] acc_beat;
  logic [3:0]  acc_mask;
  logic [63:0] acc_data;
  logic        flush_pending;
  logic        acc_flush_pending;
  wire [15:0] in_beat = in_addr[17:2];
  wire [1:0]  in_lane = in_addr[1:0];
  wire        in_same = acc_valid && (acc_beat == in_beat);
  wire        in_take = in_we && in_allow &&
                        (!acc_valid || in_same || !q_full);
  wire        push_old = in_take && acc_valid && !in_same;
  // Retain a flush that arrived while qmem was full. An ownership fence also
  // spills immediately so CPU/erase cannot wait behind an unqueued partial
  // beat. Production DMA supplies in_flush at S_DONE.
  wire        push_flush = acc_valid && !q_full &&
                           ((!in_we && (in_flush || acc_flush_pending)) ||
                            !in_allow);

  assign in_ack = in_take;

  logic [1:0]  ost;
  logic [15:0] send_beat;
  logic [3:0]  send_mask;
  logic [63:0] send_data;
  wire [1:0] send_lane = send_mask[0] ? 2'd0 :
                         send_mask[1] ? 2'd1 :
                         send_mask[2] ? 2'd2 : 2'd3;
  wire send_last = (send_mask == (4'b0001 << send_lane));

  assign out_we   = (ost == O_SEND) && (send_mask != 4'd0);
  assign out_addr = {send_beat, send_lane};
  assign out_data = send_data[{send_lane, 4'b0000} +: 16];

  wire local_empty = q_empty && !acc_valid && (ost == O_IDLE);
  assign out_flush = flush_pending && local_empty;
  assign pending = !local_empty || flush_pending;
  assign busy = pending || out_busy;

  always_ff @(posedge clk) begin
    if (rst) begin
      wptr <= '0;
      rptr <= '0;
      acc_valid <= 1'b0;
      acc_beat <= 16'd0;
      acc_mask <= 4'd0;
      acc_data <= 64'd0;
      acc_flush_pending <= 1'b0;
      ost <= O_IDLE;
      send_beat <= 16'd0;
      send_mask <= 4'd0;
      send_data <= 64'd0;
      flush_pending <= 1'b0;
    end else begin
      if (in_flush)
        flush_pending <= 1'b1;
      if (out_flush && !out_busy)
        flush_pending <= 1'b0;
      if (in_flush && acc_valid && q_full)
        acc_flush_pending <= 1'b1;
      if (push_flush)
        acc_flush_pending <= 1'b0;

      // Flush the completed accumulator into the compact queue either when
      // the next pixel changes beats or when DMA enters its completion hold.
      if (push_old || push_flush) begin
        qmem[wptr[AW-1:0]] <= {acc_beat, acc_mask, acc_data};
        wptr <= wptr + 1'b1;
      end

      if (in_take) begin
        if (!acc_valid || !in_same) begin
          acc_valid <= 1'b1;
          acc_beat <= in_beat;
          acc_mask <= (4'b0001 << in_lane);
          acc_data <= ({48'd0, in_data} << {in_lane, 4'b0000});
        end else begin
          acc_mask[in_lane] <= 1'b1;
          acc_data[{in_lane, 4'b0000} +: 16] <= in_data;
        end
      end else if (push_flush) begin
        acc_valid <= 1'b0;
        acc_mask <= 4'd0;
      end

      case (ost)
        O_IDLE: if (!q_empty) ost <= O_LOAD;
        O_LOAD: begin
          // Registered M10K read; the entry is stable until all valid lanes
          // have completed the existing downstream fb_ack handshake.
          {send_beat, send_mask, send_data} <= qmem[rptr[AW-1:0]];
          ost <= O_SEND;
        end
        O_SEND: if (out_we && out_ack) begin
          if (send_last) begin
            send_mask <= 4'd0;
            rptr <= rptr + 1'b1;
            ost <= O_IDLE;
          end else begin
            send_mask[send_lane] <= 1'b0;
          end
        end
        default: ost <= O_IDLE;
      endcase
    end
  end

`ifndef SYNTHESIS
  initial begin
    if (DEPTH < 2 || (DEPTH & (DEPTH-1)) != 0)
      $fatal(1, "narc_fb_beat_fifo DEPTH must be a power of two >= 2");
  end
`endif
endmodule

`default_nettype wire
