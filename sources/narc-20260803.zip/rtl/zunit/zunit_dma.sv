// zunit_dma.sv — Williams Z-unit (NARC, 1988) Rev-1 sprite DMA blitter.
//
// BLIND transcription from the two gospels ONLY (never from the donor
// yunit_dma RTL semantics, never from dma_golden.py):
//   register set + trigger  : mame-gospel/midyunit_v.cpp:422-435 (dma_w)
//   register unpack          : midyunit_v.cpp:456-462
//   flip / rowbytes setup    : midyunit_v.cpp:464-478 (!m_yawdim_dma; narc
//                              sets m_yawdim_dma=0, midyunit_v.cpp:98-106)
//   Y / X clipping            : midyunit_v.cpp:480-512
//   source normalize          : midyunit_v.cpp:514-518
//   per-pixel 16 draw modes    : midyunit_v.cpp:262-360 (dma_draw)
//   overrun guard              : midyunit_v.cpp:290-291
//   completion IRQ (ext line 0) : midyunit_v.cpp:370-374 (dma_callback)
//   DMA.DOC "Revision 1 DMA — Description and Use" (companion to Z-UNIT.DOC):
//   10 registers, control bits b0-b5 + GO b15, clip/flip equations.
//
// Z-UNIT DELTA vs the Y-unit donor (zunit_pkg.sv, ATTACK-PLAN §3):
//   * 8bpp pixel path — the frame buffer stores {palette-high[7:0], pixel[7:0]}
//     as a 16-bit word (identical store shape to the donor; the WIDTH of the
//     pen is 8 bits here so the full source byte lands). The 8bpp pen_map
//     (i & 0x1fff, PALETTE_MASK_8BIT, midyunit_v.cpp:102-105) is applied at
//     SCANOUT (zunit_video), NOT in the DMA — the DMA writes the raw
//     {palette,pixel} word exactly as MAME's dma_draw does.
//   * dest clip 0..511 both axes (DMA_CLIP_MAX, midyunit_v.cpp:487/499/506-508).
//
// DELIBERATE MAME-0.280 QUIRK (replicated, NOT "fixed"): dma_w computes
// clip-stage source advances into m_dma_state.offset at :484/:496/:507 but
// then UNCONDITIONALLY overwrites m_dma_state.offset := gfxoffset-0x02000000
// at :518 before dma_draw. Net 0.280 behavior: clipping shrinks the window and
// moves the destination but NEVER advances the source pointer. This RTL never
// advances the source on clip — the observable MAME behavior.
//
// HW-FIT (architect's second job): clocked multi-cycle FSM, single-port source
// fetch (ONE byte/pixel, no async multi-read window), single-port frame-buffer
// write — the donor's fit-proven Cyclone-V shape (no scaler; Rev-1 engine).
// fb_ack lets the SDRAM/DDR3 write path self-pace the blitter.
//
// Constant bit/part-selects are hoisted to continuous-assign wires (Icarus
// miscompiles constant selects inside always).

`default_nettype none

module zunit_dma
  import zunit_pkg::*;
(
  input  logic        clk,
  input  logic        rst,          // sync, active-high

  // CPU register interface (blitter reg index 0..15).
  input  logic        reg_we,
  input  logic  [3:0] reg_addr,
  input  logic [15:0] reg_wdata,
  output logic [15:0] reg_rdata,     // dma_r (midyunit_v.cpp:384-386)

  // Unpacked-gfx source read: 1 byte/pixel at linear byte index src_addr.
  output logic        src_req,
  output logic [23:0] src_addr,
  input  logic  [7:0] src_data,
  input  logic        src_ack,

  // Frame-buffer write: 16-bit word at word index (ty*512 + tx).
  output logic        fb_we,
  output logic [FB_ADDR_W-1:0] fb_addr,
  output logic [15:0] fb_wdata,
  input  logic        fb_ack,        // write accepted; tie 1'b1 for 1-cycle BRAM
  output logic        fb_flush,      // all pixels accepted: drain DDR3 write-combine now

  // Status
  output logic        busy,          // COMMAND bit15 as the CPU reads it
  output logic        blit_irq,      // -> ext int line 0 (midyunit_v.cpp:373)
  output logic [15:0] dma_palette    // DMA_PALETTE reg -> zunit_mem vram byte-lane
);

  // ---- Register file (midyunit_v.cpp:425 COMBINE_DATA) ------------------
  logic [15:0] regf [DMA_NREGS];
  logic        busy_r;

  wire [15:0] cmd_reg    = regf[DMA_COMMAND];
  wire        flipx_w    = cmd_reg[DMA_CMD_FLIPX_BIT];       // command & 0x10
  wire [3:0]  mode_w     = cmd_reg[DMA_CMD_MODE_HI:DMA_CMD_MODE_LO];
  wire [7:0]  pal_lo     = regf[DMA_PALETTE][7:0];
  wire [7:0]  col_lo     = regf[DMA_COLOR][7:0];
  wire        wdata_trig = reg_wdata[DMA_CMD_TRIG_BIT];

  assign busy        = busy_r;
  assign dma_palette = regf[DMA_PALETTE];
  // CPU poll of COMMAND sees live busy in bit15; else direct read-back.
  assign reg_rdata = (reg_addr == DMA_COMMAND) ? {busy_r, cmd_reg[14:0]}
                                               : regf[reg_addr];

  // ---- FSM --------------------------------------------------------------
  typedef enum logic [2:0] {
    S_IDLE, S_TRIG, S_SETUP, S_ROW, S_FETCH, S_WRITE, S_DONE
  } state_t;
  state_t state, state_n;

  // MAME's dma_w draws immediately but reports completion 41 ns per clipped
  // pixel later (midyunit_v.cpp:523). At 96 MHz, four clocks/pixel is 41.67 ns.
  // The engine may take longer under real source/fb backpressure, so S_DONE
  // waits for max(engine completion, this floor).
  logic [25:0] pace_cnt;
  logic        pace_arm;

  // A COMMAND write with bit 15 clear changes the CPU-visible busy bit
  // immediately but does not cancel MAME's already-drawn pixels or its pending
  // completion timer. Our blit is multi-cycle, so it continues in the
  // background. If a GO arrives before that drain lands, preserve one pending
  // launch instead of dropping the queue head.
  logic        abort_r;
  logic        pend_trig;

  // Latched, clipped blit parameters (set at S_SETUP).
  logic  [3:0]        mode_c;
  logic               flipx_c;
  logic               readmode_c;
  logic signed [31:0] width_c, height_c;
  logic signed [31:0] xpos_c, ypos_c;
  logic signed [31:0] rowbytes_c;
  logic [15:0]        pal16_c, color16_c;

  // Running blit state.
  logic signed [31:0] row_i, col_i, tx;
  logic        [8:0]  ty;
  logic signed [31:0] cur_off, o_ptr;
  logic        [7:0]  px;

  // ---- Combinational clip/flip setup (dma_w :456-518) -------------------
  logic signed [31:0] rb_in, xs_in, ys_in;
  logic        [15:0] w_in, h_in;
  logic        [31:0] gfxoff0, gfxoff1, gfxoff2;
  logic signed [31:0] rb_adj, xpos0;
  logic signed [31:0] ypos1, height1a, height1;
  logic signed [31:0] xpos_f, width_f;
  logic signed [31:0] offbytes_c;

  always_comb begin
    rb_in   = $signed(regf[DMA_ROWBYTES]);        // :456 (int16_t)
    xs_in   = $signed(regf[DMA_XSTART]);          // :457 (int16_t)
    ys_in   = $signed(regf[DMA_YSTART]);          // :458 (int16_t)
    w_in    = regf[DMA_WIDTH];                    // :459 uint16
    h_in    = regf[DMA_HEIGHT];                   // :460 uint16
    gfxoff0 = {regf[DMA_OFFSETHI], regf[DMA_OFFSETLO]};  // :465

    // flip-X (command & 0x10) — !m_yawdim_dma path (:468-476)
`ifdef MUT_FLIPX_REWIND
    // MUTANT (flipX rewind): rewind by width*8 instead of (width-1)*8.
    gfxoff1 = flipx_w ? (gfxoff0 - ({16'd0, w_in} << 3)) : gfxoff0;
`else
    gfxoff1 = flipx_w ? (gfxoff0 - (({16'd0, w_in} - 32'd1) << 3)) : gfxoff0; // :470
`endif
    rb_adj  = flipx_w ? ((rb_in - $signed({16'd0, w_in}) + 32'sd3) & ~32'sd3)  // :471
                      : ((rb_in + $signed({16'd0, w_in}) + 32'sd3) & ~32'sd3); // :478
    xpos0   = flipx_w ? (xs_in + $signed({16'd0, w_in}) - 32'sd1) : xs_in;     // :475

    // Y clipping (:481-488). Source NOT advanced (dead store overwritten :518).
    if (ys_in < 0) begin
      height1a = $signed({16'd0, h_in}) + ys_in;   // height -= -ypos  (:483)
      ypos1    = 32'sd0;                             // :485
    end else begin
      height1a = $signed({16'd0, h_in});
      ypos1    = ys_in;
    end
    if ((ypos1 + height1a) > 32'sd512) height1 = 32'sd512 - ypos1;  // :487-488
    else                               height1 = height1a;

    // X clipping (:490-512). Source NOT advanced (dead store overwritten :518).
    if (!flipx_w) begin
`ifdef MUT_CLIP
      // MUTANT (clip): drop the left (xpos<0) clamp — xpos stays negative, tx
      // underflows the row. Must die on non-flip xpos<0 cases.
      begin width_f = $signed({16'd0, w_in}); xpos_f = xpos0; end
`else
      if (xpos0 < 0) begin width_f = $signed({16'd0, w_in}) + xpos0; xpos_f = 32'sd0; end // :495-497
      else           begin width_f = $signed({16'd0, w_in});         xpos_f = xpos0;  end
`endif
      if ((xpos_f + width_f) > 32'sd512) width_f = 32'sd512 - xpos_f; // :499-500
    end else begin
      if (xpos0 >= 32'sd512) begin width_f = $signed({16'd0, w_in}) - (xpos0 - 32'sd511); xpos_f = 32'sd511; end // :506-508
      else                   begin width_f = $signed({16'd0, w_in});                      xpos_f = xpos0;    end
      if ((xpos_f - width_f) < 0) width_f = xpos_f;                  // :510-511
    end

    // source normalize (:515-518): the ONLY thing that survives to draw.
    gfxoff2    = (gfxoff1 < 32'h0200_0000) ? (gfxoff1 + 32'h0200_0000) : gfxoff1; // :515-516
    offbytes_c = ($signed(gfxoff2) - 32'sh0200_0000) >>> 3;         // :518 then :268 (bit->byte)

`ifdef MUT_SRC_ADVANCE
    // MUTANT (source-advance): "fix" the 0.280 quirk by honoring the clip
    // source advances (:484 Y, :496 X-left) that MAME actually discards. Must
    // die on ypos<0 / non-flip xpos<0 cases.
    if (ys_in < 0)
      offbytes_c = offbytes_c + ((-ys_in) * rb_adj);       // dead store :484
    if (!flipx_w && xpos0 < 0)
      offbytes_c = offbytes_c + (-xpos0);                  // dead store :496
    if (flipx_w && xpos0 >= 32'sd512)
      offbytes_c = offbytes_c + (xpos0 - 32'sd511);        // dead store :507
`endif
  end

  wire        readmode_w = (mode_w >= 4'h1) && (mode_w <= 4'hB);  // modes that fetch source

  // ---- Per-pixel draw decision (dma_draw :294-357) ----------------------
  // pal16_u/color16_u normally alias the S_SETUP-latched copies. The mutation
  // below swaps in the LIVE register-file values, i.e. a Rev-1 shape with no
  // shadow registers, where reprogramming DMA_PALETTE/DMA_COLOR mid-blit
  // corrupts the running draw. tb_zunit_dma_bare_refire.sv MUST fail there.
`ifdef MUT_ZDMA_LIVEPAL
  wire [15:0] pal16_u   = {pal_lo, 8'h00};
  wire [15:0] color16_u = {pal_lo, col_lo};
`else
  wire [15:0] pal16_u   = pal16_c;
  wire [15:0] color16_u = color16_c;
`endif
  logic        pix_we;
  logic [15:0] pix_data;
  always_comb begin
    pix_we   = 1'b0;
    pix_data = 16'h0000;
    unique case (mode_c)
      4'h0: ;                                                       // :296 nothing
`ifdef MUT_CMD_DECODE
      // MUTANT (cmd-decode): mode 0x02 (non-0 only) mis-decoded as write-all.
      4'h1: begin pix_we = (px == 8'd0); pix_data = pal16_u;               end
      4'h2: begin pix_we = 1'b1;         pix_data = pal16_u | {8'd0, px};  end
`else
      4'h1: begin pix_we = (px == 8'd0); pix_data = pal16_u;               end // :299
      4'h2: begin pix_we = (px != 8'd0); pix_data = pal16_u | {8'd0, px};  end // :305
`endif
      4'h3: begin pix_we = 1'b1;         pix_data = pal16_u | {8'd0, px};  end // :314
      4'h4, 4'h5: begin pix_we = (px == 8'd0); pix_data = color16_u;       end // :319
      4'h6, 4'h7: begin pix_we = 1'b1; pix_data = (px == 8'd0) ? color16_u : (pal16_u | {8'd0, px}); end // :326
      4'h8, 4'ha: begin pix_we = (px != 8'd0); pix_data = color16_u;       end // :335
      4'h9, 4'hb: begin pix_we = 1'b1; pix_data = (px != 8'd0) ? color16_u : (pal16_u | {8'd0, px}); end // :342
      default:    begin pix_we = 1'b1; pix_data = color16_u;               end // :351 0xC..0xF
    endcase
  end

  // overrun guard (dma_draw :290): row's OWN base, gates S_ROW only.
  wire row_overrun_g = ($unsigned(cur_off) >= 32'h0600_0000) && (mode_c < 4'hC);

  wire [8:0]  tx9     = tx[8:0];
  wire [8:0]  ty_next = ypos_c[8:0] + row_i[8:0];

  // ---- next-state -------------------------------------------------------
`ifdef MUT_ZDMA_NOPACE
  wire dma_done_ok = 1'b1;
`else
  // pace_cnt is loaded three clocks after GO (registered clip dimensions and
  // multiply) and S_DONE reports one clock after the terminal comparison.
  // Compensate those four pipeline clocks so the externally visible
  // completion remains anchored at GO + 4*clipped_width*clipped_height.
  wire dma_done_ok = (pace_cnt <= 26'd4);
`endif

  always_comb begin
    state_n = state;
    unique case (state)
      S_IDLE:  if (reg_we && reg_addr == DMA_COMMAND && wdata_trig)
`ifdef MUT_ZDMA_NOTRIG
                 state_n = S_SETUP;
`else
                 state_n = S_TRIG;
`endif
`ifndef MUT_ZDMA_NOSTOP
               else if (pend_trig) state_n = S_TRIG;
`endif
      // COMMAND is the one DMA register written at the trigger edge. Keep a
      // full cycle between that write and the large clip/setup cone: the SDC
      // grants regf->S_SETUP two cycles and real hardware must receive both.
      S_TRIG:  state_n = S_SETUP;
      S_SETUP: if (height1 <= 0 || width_f <= 0) state_n = S_DONE; else state_n = S_ROW;
`ifndef MUT_ZDMA_NO_STOP_ABORT
      // v7r: a COMMAND write with bit15=0 is a DOCUMENTED STOP and must actually
      // stop the draw. Two primary sources, and MAME agrees on the observable:
      //   DOC/DMA2.DOC:75-76  "IN THE OLD DMA, THIS WOULD KILL THE TRANSFER SO
      //                        THAT IT COULD NOT BE RESTARTED"
      //   DIAG/DMASYS.INC:33  "0=STOP DMA  (WRITE)"
      // and midyunit_v.cpp:434-435 returns before drawing anything further, so
      // after a STOP MAME has bit15=0 AND ZERO pixels still landing. Before this
      // change we matched only the first half: busy_r cleared at :361 while the
      // engine kept writing the framebuffer (the comment there conceded it).
      //
      // WHY THAT WAS A REAL BUG, not a latent one. GAME-REACHABLE every wave:
      //   NARCBGND.ASM:191 WAVEBACK "CALLA DMAHALT ;STOP THE DMA"  (no busy poll,
      //   no DMAQWAIT, no DINT) -> NARC1.ASM:1682 "MOVE A0,@DMACTRL,W".
      // The game then spins DMAWAIT (NARC1.ASM:1645-1650) which FALLS THROUGH
      // IMMEDIATELY because we had already cleared busy_r, so MYOINITG reprograms
      // the register file and fires a fresh GO (NARC1.ASM:947-958 "MOVI DMACAL,A5
      // / MOVE A5,-*A0,W ;GO!") WHILE THE ABORTED BLIT IS STILL WRITING THE
      // FRAMEBUFFER. That ordering is impossible in MAME (dma_draw is synchronous,
      // so a STOP always lands with zero pixels remaining) -- which is exactly why
      // no amount of MAME blit-capture could ever have found it.
      //
      // Aborted at a CLEAN BOUNDARY: S_WRITE only leaves after any in-flight
      // fb handshake completes, so no transaction is stranded and at most ONE
      // further pixel lands. S_DONE is entered normally, so the completion IRQ
      // still fires -- MAME does NOT cancel its timer on a STOP (dma_w returns at
      // :435 without touching m_dma_timer; :526 adjust; :371-373 ASSERT_LINE), and
      // the existing refire-supersede suppression at :429-435 is unchanged.
      S_ROW:   if (abort_r)              state_n = S_DONE;
               else if (row_i >= height_c) state_n = S_DONE;
               else if (row_overrun_g)    state_n = S_ROW;
               else                       state_n = S_FETCH;
      S_FETCH: if (!readmode_c)  state_n = S_WRITE;
               else if (src_ack) state_n = S_WRITE;
      S_WRITE: if (pix_we && !fb_ack) state_n = S_WRITE;   // finish the handshake first
               else if (abort_r)        state_n = S_DONE;  // v7r documented STOP
               else if (col_i >= (width_c - 32'sd1)) state_n = S_ROW;
               else state_n = S_FETCH;
`else
      // MUTANT: pre-v7r behaviour -- STOP clears busy_r but the draw runs on.
      S_ROW:   if (row_i >= height_c)     state_n = S_DONE;
               else if (row_overrun_g)    state_n = S_ROW;
               else                       state_n = S_FETCH;
      S_FETCH: if (!readmode_c)  state_n = S_WRITE;
               else if (src_ack) state_n = S_WRITE;
      S_WRITE: if (pix_we && !fb_ack) state_n = S_WRITE;
               else if (col_i >= (width_c - 32'sd1)) state_n = S_ROW;
               else state_n = S_FETCH;
`endif
      S_DONE:  if (dma_done_ok) state_n = S_IDLE;
      default: state_n = S_IDLE;
    endcase
`ifdef MUT_ZDMA_BAREGO_ABORT
    // MUTATION (bare GO restarts the engine): the reading in which the write
    // re-triggers immediately, tearing down the running blit and re-entering
    // setup with the freshly programmed registers. This is the reading that
    // real Rev-1 silicon would come closest to if the GO write also re-armed
    // the sequencer. tb_zunit_dma_bare_refire.sv MUST fail here.
    if ((state != S_IDLE) && reg_we && (reg_addr == DMA_COMMAND) &&
        wdata_trig && !abort_r && !pend_trig)
      state_n = S_TRIG;
`endif
  end

  assign src_req  = (state == S_FETCH) && readmode_c;
  assign src_addr = o_ptr[23:0];
  // The framebuffer request is a held level for the entire S_WRITE state.
  // Driving it from the already-registered pixel/position state avoids the
  // old extra registered-output bubble (one dead clock before the receiver
  // could even see each pixel) while keeping address/data stable until ack.
  assign fb_we    = (state == S_WRITE) && pix_we;
  assign fb_addr  = {ty, tx9};
  assign fb_wdata = pix_data;
  // Flush as soon as every pixel has been accepted, overlapping the DDR3
  // drain with the remaining MAME pace hold. A busy-falling-edge flush is too
  // late once S_DONE is deliberately held for the timer floor.
  assign fb_flush = (state == S_DONE);

  // ---- registers --------------------------------------------------------
  integer i;
  always_ff @(posedge clk) begin
    if (rst) begin
      state    <= S_IDLE;
      blit_irq <= 1'b0;
      busy_r   <= 1'b0;
      pace_cnt <= 26'd0;
      pace_arm <= 1'b0;
      abort_r <= 1'b0;
      pend_trig <= 1'b0;
      for (i = 0; i < DMA_NREGS; i = i + 1) regf[i] <= 16'h0000;
    end else begin
      state <= state_n;

      // COMBINE_DATA + CLEAR_LINE on COMMAND write (midyunit_v.cpp:425/433).
      if (reg_we) begin
        regf[reg_addr] <= reg_wdata;
        if (reg_addr == DMA_COMMAND) begin
          blit_irq <= 1'b0;                         // :433 CLEAR_LINE
`ifdef MUT_ZDMA_NOSTOP
          // Mutation: original Z-unit behavior. STOP is ignored in flight and
          // a refire outside IDLE is silently lost.
          if (state == S_IDLE) busy_r <= wdata_trig;
`else
          if (state == S_IDLE) begin
            busy_r <= wdata_trig;
          end else if (wdata_trig && (abort_r || pend_trig)) begin
            pend_trig <= 1'b1;
            busy_r    <= 1'b1;
`ifdef MUT_ZDMA_BAREGO
          end else if (wdata_trig) begin
            // MUTATION (bare GO honoured): the competing reading of the
            // UNDOCUMENTED "write GO=1 while GO/BUSY already reads 1"
            // collision -- queue the trigger instead of absorbing it into the
            // already-set flop. tb_zunit_dma_bare_refire.sv MUST fail here.
            pend_trig <= 1'b1;
            busy_r    <= 1'b1;
`endif
`ifdef MUT_ZDMA_BAREGO_STOP
          end else if (wdata_trig) begin
            // MUTATION (bare GO clears busy): the reading in which the write
            // re-arms the GO/BUSY flop from zero, so the CPU-visible busy bit
            // momentarily drops mid-blit. That false idle is exactly what
            // would let a DMAWAIT poll fall through while pixels are still in
            // flight. tb_zunit_dma_bare_refire.sv MUST fail here.
            busy_r <= 1'b0;
            if (state_n != S_IDLE) abort_r <= 1'b1;
`endif
          end else if (!wdata_trig) begin
            // COMBINE_DATA + dma_r in MAME make bit15 read zero at this write;
            // the current multi-cycle draw still finishes in the background.
            busy_r <= 1'b0;
            if (state_n != S_IDLE) abort_r <= 1'b1;
          end
`endif
        end
      end

      // Load from the registered clipped dimensions one cycle after S_SETUP,
      // keeping the multiply off the clip cone. Negative/fully-clipped
      // dimensions were clamped to zero in S_SETUP.
      pace_arm <= (state == S_SETUP);
      if (pace_arm)
        pace_cnt <= ({14'd0, width_c[11:0]} * {14'd0, height_c[11:0]}) << 2;
      else if (pace_cnt != 26'd0)
        pace_cnt <= pace_cnt - 26'd1;

`ifndef MUT_ZDMA_NOSTOP
      if (abort_r && (state_n == S_IDLE))
        abort_r <= 1'b0;

      // A preserved launch leaves IDLE through S_TRIG on this edge.
      if ((state == S_IDLE) && pend_trig) begin
        pend_trig <= 1'b0;
        busy_r    <= 1'b1;
      end
`endif

      unique case (state)
        S_SETUP: begin
          mode_c     <= mode_w;
          flipx_c    <= flipx_w;
          readmode_c <= readmode_w;
          width_c    <= (width_f  <= 32'sd0) ? 32'sd0 : width_f;
          height_c   <= (height1  <= 32'sd0) ? 32'sd0 : height1;
          xpos_c     <= xpos_f;
          ypos_c     <= ypos1;
          rowbytes_c <= rb_adj;
          pal16_c    <= {pal_lo, 8'h00};            // :461
          color16_c  <= {pal_lo, col_lo};           // :462 (pal | color)
          row_i      <= 32'sd0;
          cur_off    <= offbytes_c;                 // :268 byte offset
        end

        S_ROW: begin
          ty    <= ty_next;                          // (ypos+y) & 0x1ff (:283)
          tx    <= xpos_c;                           // :278
          col_i <= 32'sd0;
          o_ptr <= cur_off;                          // o = offset (:280)
          if (row_i < height_c) begin
            cur_off <= cur_off + rowbytes_c;         // offset += rowbytes (:284)
            row_i   <= row_i + 32'sd1;
          end
        end

        S_FETCH: begin
          if (readmode_c && src_ack) px <= src_data; // base[o]
        end

        S_WRITE: begin
          if (!pix_we || fb_ack) begin
            tx    <= tx + (flipx_c ? -32'sd1 : 32'sd1); // tx += dx (:264)
            col_i <= col_i + 32'sd1;
            if (readmode_c) o_ptr <= o_ptr + 32'sd1;    // base[o++]
          end
        end

        S_DONE: if (dma_done_ok) begin
`ifndef MUT_ZDMA_NOSTOP
          if (pend_trig ||
              (reg_we && reg_addr == DMA_COMMAND && wdata_trig && abort_r)) begin
            // MAME has one adjustable timer: a new GO supersedes the previous
            // deadline, so do not emit an obsolete completion IRQ between the
            // serialised hardware draws.
            busy_r   <= 1'b1;
            blit_irq <= 1'b0;
          end else begin
`endif
            busy_r   <= 1'b0;                        // &= ~0x8000 (:372)
            blit_irq <= 1'b1;                        // ASSERT_LINE (:373)
`ifndef MUT_ZDMA_NOSTOP
          end
`endif
        end

        default: ;
      endcase
    end
  end

endmodule

`default_nettype wire
