#!/usr/bin/env python3
"""Compute the EXPECTED w0/w1/w2 sweep-checksum values that
zunit_rom_chksum_audit.sv should report for the real U41/U23 program-ROM
pair, straight from narc.zip -- independent of any RTL or simulation.

U23 is the odd/high byte of the {u41,u23} interleave pair (gospel
midyunit.cpp:1470: u23 @ maindata byte 0xC0001, u41 @ 0xC0000). This script
reads both parts directly from the zip, interleaves them the same way the
MRA/download path does (low=u41[i], high=u23[i] for each i), and reproduces
zunit_rom_chksum_audit's exact algorithm (per-word XOR/sum of the high byte,
8 sub-block XORs) so the printed hex can be compared word-for-word against
what a cab flash reads back on-screen.

Usage: python compute_u23_chksum.py [path/to/narc.zip]
"""
import sys, zipfile, os

ZIP = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
    os.path.dirname(__file__), "..", "..", "..", "..", "roms", "narc.zip")

U41_NAME = "rev7_narc_game_rom_u41.u41"
U23_NAME = "rev7_narc_game_rom_u23.u23"
NBLK = 8

def main():
    z = zipfile.ZipFile(ZIP)
    u41 = z.read(U41_NAME)   # 0x20000 bytes, low byte of each word
    u23 = z.read(U23_NAME)   # 0x20000 bytes, high byte of each word
    assert len(u41) == 0x20000, len(u41)
    assert len(u23) == 0x20000, len(u23)

    n = len(u41)
    blkwords = n // NBLK
    hi_xor = 0; lo_xor = 0; hi_sum = 0
    block_xor = [0] * NBLK

    for i in range(n):
        hi = u23[i]; lo = u41[i]
        hi_xor ^= hi
        lo_xor ^= lo
        hi_sum = (hi_sum + hi) & 0xFFFF
        block_xor[i // blkwords] ^= hi

    w0 = (hi_xor << 24) | (lo_xor << 16) | hi_sum
    w1 = (block_xor[3] << 24) | (block_xor[2] << 16) | (block_xor[1] << 8) | block_xor[0]
    w2 = (block_xor[7] << 24) | (block_xor[6] << 16) | (block_xor[5] << 8) | block_xor[4]

    print("=== expected zunit_rom_chksum_audit output (from real narc.zip U41/U23) ===")
    print(f"u41 CRC32 = {__import__('zlib').crc32(u41):08x}  (gospel want 3903191f)")
    print(f"u23 CRC32 = {__import__('zlib').crc32(u23):08x}  (gospel want 7a316582)")
    print(f"words swept = {n} (0x{n:X})")
    print(f"w0 (hi_xor|lo_xor|hi_sum16) = {w0:08X}")
    print(f"w1 (block3|block2|block1|block0) = {w1:08X}")
    print(f"w2 (block7|block6|block5|block4) = {w2:08X}")
    print(f"block_xor[0..7] = {[f'{b:02X}' for b in block_xor]}")
    print()
    print("Compare against the cab overlay's w0/w1/w2 rows. A mismatch ISOLATES")
    print("the divergence to one of the 8 blocks (each 0x4000 words = 16KB of U23),")
    print("i.e. maindata byte range [0xC0001 + block*0x4000*2, +0x8000) (odd/high lane).")

if __name__ == "__main__":
    main()
