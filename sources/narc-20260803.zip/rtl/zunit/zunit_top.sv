// zunit_top.sv — Williams Z-unit (NARC, 1988) synthesizable core assembly.
//
// FORK of yunit/yunit_top.sv (Smash T.V. Y-unit donor). This is the core BELOW the
// Template_MiSTer chassis: it composes the Z-unit blocks into one top —
//
//   tms34010_core  <-> zunit_memsys  (CPU + DMA blitter + Z-unit memory map)
//   zunit_memsys   <-> zunit_video_top (VRAM scanout -> pen_map8 -> palette -> RGB)
//   zunit_memsys.int1 -> tms34010_core.lint1_in (P0016 DMA-done LINT1)
//
// SDRAM CHASSIS (director graft, SYNTHESIS-gated `ZT_SDRAM_CHASSIS`): the donor
//   arbiter/adapter structure is retained, with a NARC-local shipped controller
//   and VRAM-only page-burst scanout repair —
//     yunit_sdram_arb + yunit_sdram_adapter + sdram_stock_shipped : all core SDRAM traffic
//       (VRAM word channel, CPU gfx/ROM read, blitter src byte read, ioctl ROM
//        download) onto one MT48LC16M16 16-bit word port.
//     ioctl download FIFO (P0020 512-deep) : absorbs the hps_io round-trip latency
//        so no ROM byte is dropped (donor +IOLSTRESS proof).
//   Baked in: P0020 (512-deep FIFO) + P0022 (sdram_por: the SDRAM/download subsystem
//   inits + captures on TRUE power-on, surviving RESET held high across the download).
//   The SDRAM word map (gfx/prog/VRAM bases + gfx/ROM split) comes ENTIRELY from
//   zunit_pkg (SDRAM_*W_BASE / SDRAM_GFX_BYTES), derived from the NARC populated
//   geometry — NO donor magic numbers (donor bases were 6bpp-planar-sized).
//   NARC gfx is FLAT (4-way quadrant byte-interleave done host-side by the MRA), so
//   there is NO planar->flat unpack pass (the donor yunit_gfx_unpack is NOT grafted);
//   the download writes flat gfx words directly.
//   DEFERRED (own later slices): dual-6809 sound board, the video-RGB emu pin surface,
//   and the M2 fb page-burst WRITE (bwr_*) lane. VRAM stays on the SDRAM word channel
//   here; the DDR3 row-cache lane is the M2 slice.
//
// SIM (no SYNTHESIS): the chassis is NOT instantiated. zunit_top keeps its deferred
//   seams (src_*/vsd_*/cpu_gfx_*) as external ports so sim/tb_narc_boot_top can drive
//   a behavioral sdram_model + gfx responder and the boot PC stream stays bit-exact.
//
// CLOCKING (P0019, inherited from yunit_top, M1 CONFIRMED/CLOSED):
//   `clk` (~96 MHz) runs the CPU / memory / SDRAM / video logic on a SINGLE clock; the
//   CPU advances on a 1-in-4 clock-enable (cpu_ce = clk/4 = 24 MHz) — NO async clk_cpu,
//   NO async CDC. `ce_pix` (16 MHz Z-unit dot) gates the raster; the 34010's internal
//   video counters get ce_pix/2 (= 8 MHz, pixels_per_clock=2, midyunit.cpp:1265) so
//   DPYINT fires at the real frame rate, not the dot rate.
//
// HW-FIT (architect ratification): yunit_top's proven core+memsys+video+SDRAM topology
//   transfers to zunit (measured 91-94% M10K, fits Cyclone V 5CSEBA6). Only the SDRAM
//   map geometry differs — sourced from zunit_pkg. The fb burst-WRITE lane and the DDR3
//   VRAM graft are separate later slices via the exposed seams.
//
// BOOT EQUIVALENCE: in the sim build (chassis absent) wrapping zunit_memsys in this top
//   leaves the CPU boot PC stream bit-exact vs the memsys-direct tb_narc_boot golden —
//   cpu_ce only SLOWS the CPU (the fetch SEQUENCE is rate-invariant); the video counters
//   + int1 are inert in the boot window. Proven by sim/tb_narc_boot_top.

`default_nettype none

// Mirror zunit_memsys's synthesis auto-defines so the guarded seam wiring here
// matches the ports zunit_memsys actually exposes for the same build.
`ifdef SYNTHESIS
  `ifndef USE_EXT_GFX
    `define USE_EXT_GFX
  `endif
  `ifndef USE_EXT_ROM
    `define USE_EXT_ROM
  `endif
  `ifndef USE_HW_VRAM
  `ifndef USE_SDRAM_VRAM
    `define USE_SDRAM_VRAM
  `endif
  `endif
  `ifndef USE_HW_RAM
    `define USE_HW_RAM
  `endif
  // The SDRAM chassis (arb + adapter + sdram_stock_shipped + ioctl FIFO) is instantiated
  // in EVERY synthesizable build -- it carries CPU/gfx/prog ROM + sound, which live in SDRAM
  // regardless of where VRAM lives. Under USE_DDR3_VRAM only the VRAM/scanout lane moves to
  // HPS DDR3 (served inside zunit_memsys by stv_vram_ddr_top); the chassis's VRAM channel is
  // then tied off at the arbiter. This mirrors the sim-proven yunit_top arrangement
  // (yunit_sdram_arb + stv_vram_ddr_top coexisting, tb_yunit_ddr3game).
  `ifndef ZT_SDRAM_CHASSIS
    `define ZT_SDRAM_CHASSIS
  `endif
  // NET-NEW dual-6809 sound board: instantiated ONLY in the synthesizable build
  // (sim/tb_narc_boot_top does not define SYNTHESIS, so the board stays OUT of the
  // boot PC-diff — it is a pure sink and must not feed the CPU fetch stream).
  `ifndef ZT_SOUND
    `define ZT_SOUND
  `endif
`endif
`ifdef USE_EXT_GFX
  `define ZT_EXT_RD
`endif
`ifdef USE_EXT_ROM
  `ifndef ZT_EXT_RD
    `define ZT_EXT_RD
  `endif
`endif

module zunit_top
  import zunit_pkg::*;
  import tms34010_pkg::*;
#(
  parameter ROM_HEX = "narc_maindata.hex",
  parameter int ROM_PROG_OFF = 32'h40000,  // NARC program @0xFFC00000 (region-word 0x40000)
  // CPU clock-enable divider: /4 = 24 MHz (M1 CONFIRMED, the shipping default). A boot
  // sim may override to 1 (full-rate cpu_ce) for speed — the CPU fetch SEQUENCE is
  // rate-invariant, only the clocks-per-fetch change.
  parameter int CPU_CE_DIV = 4
)(
  input  logic        clk,        // core clock (memory + SDRAM + video logic), ~96 MHz
  input  logic        ce_pix,     // pixel-clock enable (16 MHz Z-unit dot)
  input  logic        rst,        // core reset (active high)

  input  logic [63:0] inputs,     // {DSW, IN2, IN1, IN0}, active-low

`ifdef ZT_SDRAM_CHASSIS
  // ================= SDRAM CHASSIS (synthesizable) =========================
  // P0022 power-on reset for the PERSISTENT SDRAM/download subsystem. LOW during any
  // ROM download (which follows PLL lock), so the capture path keeps running even if
  // the framework holds RESET high across the download.
  input  logic        sdram_por,
  // ioctl ROM download -> SDRAM word writes. The MRA/loader presents a linear WORD
  // address matching the SDRAM layout (gfx @SDRAM_GFXW_BASE, prog @SDRAM_ROMW_BASE).
  input  logic        ioctl_download,  // held high during ROM load (holds the CPU in reset)
  input  logic        ioctl_wr,
  input  logic [24:0] ioctl_addr,      // SDRAM word address
  input  logic [15:0] ioctl_dout,
  input  logic [1:0]  ioctl_be,        // byte lane(s): 11=full word, 01/10=interleaved ROM
  output logic        ioctl_wait,
  // SDRAM (MT48LC16M16) pins. NOTE: SDRAM_CLK is NOT a port — the emu forwards it from
  // the phase-shifted PLL output directly to the pin (matches rtl/sdram.sdc general[1]).
  inout  wire  [15:0] SDRAM_DQ,
  output logic [12:0] SDRAM_A,
  output logic [1:0]  SDRAM_BA,
  output logic        SDRAM_DQML, SDRAM_DQMH,
  output logic        SDRAM_nCS, SDRAM_nRAS, SDRAM_nCAS, SDRAM_nWE,
  output logic        SDRAM_CKE,
`ifdef USE_DDR3_VRAM
  // VRAM-in-DDR3 coexists with the SDRAM chassis: SDRAM keeps CPU/gfx/prog/sound,
  // scanout + CPU field RMW + blitter fb move to HPS DDR3 (f2h_sdram1). sdram_por is
  // already a chassis port above, so it is NOT redeclared here.
  output logic [28:0] ddram_addr,
  output logic [7:0]  ddram_burstcnt,
  output logic        ddram_rd,
  output logic        ddram_we,
  output logic [63:0] ddram_din,
  output logic [7:0]  ddram_be,
  input  logic        ddram_busy,
  input  logic [63:0] ddram_dout,
  input  logic        ddram_dout_ready,
`endif
`else
  // ================= DEFERRED SEAMS (sim / functional) =====================
  // blitter source read (unpacked gfx ROM / SDRAM)
  output logic        src_req,
  output logic [23:0] src_addr,
  input  logic  [7:0] src_data,
  input  logic        src_ack,
`ifdef ZT_EXT_RD
  // CPU gfx/ROM external read (prog+gfx in SDRAM)
  output logic        cpu_gfx_rd,
  output logic [23:0] cpu_gfx_raddr,
  input  logic [15:0] cpu_gfx_rdata,
  input  logic        cpu_gfx_rack,
`endif
`ifdef USE_SDRAM_VRAM
`ifdef USE_DDR3_VRAM
  input  logic        sdram_por,
  output logic [28:0] ddram_addr,
  output logic [7:0]  ddram_burstcnt,
  output logic        ddram_rd,
  output logic        ddram_we,
  output logic [63:0] ddram_din,
  output logic [7:0]  ddram_be,
  input  logic        ddram_busy,
  input  logic [63:0] ddram_dout,
  input  logic        ddram_dout_ready,
`else
  // VRAM SDRAM word channel (external controller)
  output logic [24:0] vsd_addr,
  output logic [15:0] vsd_din,
  output logic [1:0]  vsd_be,
  output logic        vsd_rd,
  output logic        vsd_wr,
  input  logic [15:0] vsd_dout,
  input  logic        vsd_ack,
`endif
`endif
`endif  // ZT_SDRAM_CHASSIS

  // ---- sound latch -> williams_narc_sound_device (decoded observ. outputs) ----
  output logic [7:0]  snd_select,
  output logic        snd_trig,
  output logic        snd_reset,

`ifdef ZT_SOUND
  // ---- sound ROM read seam (D1 RESOLVED: SDRAM @SDRAM_SNDW_BASE, NOT BRAM) ----
  // The 2 x 576 KB sound images stay OFF the M10K budget (donor whole-core ~93%).
  // The seam is now CLOSED INTERNALLY by zunit_snd_rom against the SDRAM arbiter's
  // snd_* channel, so the *_rom_data lanes are no longer emu-level inputs; the
  // offsets remain as observability outputs.
  output logic [19:0] mst_rom_offset,
  output logic [19:0] slv_rom_offset,
  output logic [31:0] snd_rom_stall_clks,   // clk_sys cycles stretching an overdue E edge
`endif

  // ---- NARC sound-board MAME-weighted, normalized, saturating mono mix ----------
  output logic signed [15:0] audio_l, audio_r,

  // ---- video out --------------------------------------------------------------
  output logic [7:0]  vid_r, vid_g, vid_b,
  output logic        hsync, vsync, hblank, vblank, de,
  output logic        rgb_valid,

  // ---- observability / debug --------------------------------------------------
  output logic [31:0] pc_dbg,
  output logic        illegal_dbg,
  output logic        int1_dbg,       // DMA-done LINT1 (blit-queue pump)
  output logic        blit_busy,
  output logic        erase_busy,
  output logic        vblank_irq,
  output logic        dbg_dma_we,
  output logic  [3:0] dbg_dma_addr,
  output logic [15:0] dbg_dma_wdata,

  // ---- P0020/P0022 ioctl-download audit taps (cab bring-up, observability only) ----
  //   fifo_accepted : # download words pushed into the FIFO (climbing = capture alive)
  //   fifo_dropped  : # download words DROPPED on FIFO-full (P0020: MUST stay 0)
  //   rst_during_dl : sticky P0022 latch — core reset overlapped ioctl_download (POR domain)
  output logic [31:0] fifo_accepted,
  output logic [31:0] fifo_dropped,
  output logic        rst_during_dl,

  // ---- P0022 FIRST-FETCH latch (§6 first-flash disproof; observability only) ------
  //   dbg_ff_addr  : the CPU's first READ-ack address after core reset deasserts —
  //                  the reset-vector fetch @0xFFFFFFE0 (TRAP_VECTOR_BASE).
  //   dbg_ff_data  : the word the CPU RECEIVES on that fetch — the real reset PC read
  //                  out of program ROM over SDRAM. NONZERO = real-ROM-over-SDRAM;
  //                  0 = read-0 / a P0022 capture-path freeze. THE disproof the P0020
  //                  accepted/dropped taps could not give (they prove bytes LANDED in
  //                  SDRAM, not that the CPU READ them back).
  //   dbg_ff_valid : sticky — set once the first read-ack is captured.
  // Lives in the sdram_por power-on domain (P0022) so it survives the core reset.
  output logic [31:0] dbg_ff_addr,
  output logic [31:0] dbg_ff_data,
  output logic        dbg_ff_valid,

  // DIAG_BOOT direct physical readback of the final two program-ROM words.
  // This bypasses the CPU/CDC/CGFX path and separates SDRAM storage/capture
  // from what the CPU later receives at its reset-vector fetch.
  output logic [31:0] dbg_rb_data,
  output logic        dbg_rb_valid,

  // DIAG_ROMCHKSUM (self-contained, independent of DIAG_BOOT): full-range
  // sweep-checksum of the U41/U23 program-ROM pair (cabinet self-test shows
  // U23 red; see rtl/zunit/zunit_rom_chksum_audit.sv + tools/compute_u23_chksum.py
  // for the root-cause hypothesis + offline golden). Raw facts only, no
  // embedded expected value -- compare against the offline-computed golden.
  output logic [31:0] dbg_cksum_w0,
  output logic [31:0] dbg_cksum_w1,
  output logic [31:0] dbg_cksum_w2,
  output logic        dbg_cksum_valid,

`ifdef DIAG_BOOT
  // ---- DIAG_BOOT SOUND-CAMPAIGN instruments (SPEC 29.4 item 2, 2026-07-30) ----
  // Cab discriminators for the v7y+ total silence: do the sound-ROM bytes LAND
  // in SDRAM, and do the 6809s RUN? Every offline sound surface is exonerated
  // (tb_narc_snd_realchain), so these measure ON silicon. DIAG_BOOT-only
  // ports: without the macro the production port list (and the sv2v blob) is
  // byte-identical.
  //   dbg_snd_cksum_w0/valid : zunit_rom_chksum_audit sweep of the SOUND
  //     region (SWEEP_BASE=SDRAM_SNDW_BASE, SWEEP_WORDS=2*SND_IMAGE_WORDS),
  //     serialized after the reset-vector readback on the shared audit port.
  //   dbg_snd_lo_sum : supplemental LOW-lane 16-bit sum over the same sweep.
  //     The RELOADed sound images self-cancel the audit's hi/lo XORs (every
  //     ROM byte appears twice), leaving the HI-lane sum as w0's only content
  //     field -- the low lane needs its own sum or it goes unchecked.
  //   dbg_snd_ff_* : the master 6809's first ACKNOWLEDGED ROM fetch after
  //     snd_board_rst release. The borrowed 6809 commonly advances to the LOW
  //     vector byte before this full-rate observer fires, so a healthy capture
  //     is 0x8FFFF/0x60 (the older cabinet diagnostic measured exactly that).
  //   dbg_snd_pa_* : first physical sound-channel acknowledgement, before the
  //     CPU-facing cache. The address is reduced locally to an exact-match bit
  //     for 0x2A7FFF; the full returned word remains visible (healthy 0x60C0).
  //   dbg_snd_land_* : byte writes actually acknowledged at that physical word;
  //     healthy seen=11 and merged data=0x60C0.
  //   dbg_snd_gap_clks : clk cycles from rst_sys fall to snd_board_rst fall,
  //     saturating 16-bit (~43 = 0x2B per tb_narc_ym_clock_en_longrst).
  output logic [31:0] dbg_snd_cksum_w0,
  output logic        dbg_snd_cksum_valid,
  output logic [15:0] dbg_snd_lo_sum,
  output logic [19:0] dbg_snd_ff_offset,
  output logic [7:0]  dbg_snd_ff_data,
  output logic        dbg_snd_ff_valid,
  output logic [15:0] dbg_snd_gap_clks,
  output logic [15:0] dbg_snd_req_count,
  output logic [15:0] dbg_snd_ack_count,
  output logic [31:0] dbg_snd_wd_rearms,
  output logic [15:0] dbg_snd_cmd_count,
  output logic [15:0] dbg_snd_audio_changes,
  output logic [15:0] dbg_snd_pa_data,
  output logic        dbg_snd_pa_valid,
  output logic        dbg_snd_pa_addr_match,
  output logic [15:0] dbg_snd_land_data,
  output logic [1:0]  dbg_snd_land_seen,
`endif

  // ---- NARC DIAG_BOOT liveness taps (observers only) -------------------------
  output logic        dbg_core_rst_o,
  output logic        dbg_sdram_ready_o,
  output logic        dbg_unp_done_o,
  output logic        dbg_cpu_req_o,
  output logic        dbg_mem_ack_o,
  output logic        dbg_cpu_ce_o
);

  // ---- core reset: hold CPU/memory/video until SDRAM init + ROM download done -----
  // In the chassis build the CPU must wait for the SDRAM power-up init (sdram_ready)
  // and the ROM download; sdram/arb/ioctl run on sdram_por so init proceeds while the
  // core is held. In the sim build there is no chassis -> core_rst is just `rst`.
`ifdef ZT_SDRAM_CHASSIS
  logic sdram_ready;
  // P0033 (SPEC section 28.3 item 1, sound-ROM delivery audit 2026-07-30): the
  // landing FIFO can still hold up to 512 queued SDRAM writes + one in-flight
  // when hps_io drops ioctl_download — and the TAIL of the stream is the slave
  // 6809 sound image including its vector table. Releasing the core (and so,
  // ~18 us later, the sound board) while those writes drain raced the 6809s'
  // first vector fetch against the last landings. DIAG_BOOT builds were
  // accidentally immune (~dbg_rb_valid holds until fifo_empty && !fifo_hold);
  // production now holds the same way. Drain progress runs on sdram_por, not
  // core_rst, so the hold always clears (the P0020 design invariant).
  logic dl_drain_busy;
  // P0046: POST-DRAIN SETTLE (the v8b cabinet clue, finished).
  // P0033 already holds the core until the landing FIFO is empty with nothing in flight. That
  // is NOT what the sound-working v8b image did. Its DIAG_BOOT core_rst carried an extra
  // `~dbg_rb_valid` term, so the core was additionally held until a READ had completed through
  // the arbiter/adapter/controller/pins AFTER the drain. Measured on the cabinet: v8b (extra
  // hold) played sound and its master 6809 first-fetch returned the correct 0x60; v13, which
  // deliberately restored the bare production boundary and changed nothing else, read FFFF at
  // the same word -- while a full sound-region checksum sweep on v8b (43847998, exact) had
  // already proved the bytes in SDRAM are byte-correct. Storage is not the variable; the
  // release boundary is. So production now holds the same way the working image did.
  // BOUNDED: a download that never happens, or an audit that never completes, must not hold
  // the core forever -- the settle times out ~1.4 ms after the drain and releases anyway
  // (fail-open, and the timer lives in the sdram_por domain so it always progresses: the P0020
  // invariant). Gate: sim/run_narc_boot_release.sh.
  logic boot_settle_busy;
  logic boot_settle_to;      // settle watchdog expired -> release regardless
`ifdef DIAG_BOOT
`ifdef DIAG_SOUND_PRODRESET
  // Passive sound diagnostic: preserve the release image reset boundary exactly -- which now
  // INCLUDES the P0046 settle, since that is what production does.
  wire  core_rst = rst | ~sdram_ready | ioctl_download | dl_drain_busy | boot_settle_busy;
`else
  wire  core_rst = rst | ~sdram_ready | ioctl_download | dl_drain_busy | ~dbg_rb_valid;
`endif
`else
  wire  core_rst = rst | ~sdram_ready | ioctl_download | dl_drain_busy | boot_settle_busy;
`endif
`else
  wire  core_rst = rst;
`endif

  // ---- reset synchronizer into clk (single-clock domain) ----------------------
  logic rst_sys_m, rst_sys;
  always_ff @(posedge clk) begin rst_sys_m <= core_rst; rst_sys <= rst_sys_m; end

  // ---- CPU clock-enable: clk/CPU_CE_DIV (default /4 = 24 MHz, M1 CONFIRMED) -----
  logic [7:0] ce_div;
  always_ff @(posedge clk) if (rst) ce_div <= 8'd0;
                           else     ce_div <= (ce_div >= CPU_CE_DIV-1) ? 8'd0 : ce_div + 8'd1;
  wire cpu_ce = (ce_div == 8'd0);

  // ---- 34010 video-counter enable = ce_pix/2 (pixels_per_clock=2) --------------
  logic ce_pix_ph;
  always_ff @(posedge clk) if (rst_sys) ce_pix_ph <= 1'b0; else if (ce_pix) ce_pix_ph <= ~ce_pix_ph;
  wire ce_pix_cnt = ce_pix & ce_pix_ph;   // 8 MHz counter enable = every 2nd 16 MHz dot

  // ---- CPU <-> memsys interface -----------------------------------------------
  logic cpu_req, cpu_we; logic [ADDR_WIDTH-1:0] cpu_addr; logic [FIELD_SIZE_WIDTH-1:0] cpu_size;
  logic [DATA_WIDTH-1:0] cpu_wdata, cpu_rdata; logic cpu_ack;
  core_state_t state_w; instr_word_t instr_w;

  // Additive-only hardware observability. NARC performs no donor planar-ROM
  // unpack pass, so its equivalent completion gate is permanently satisfied.
  assign dbg_core_rst_o = core_rst;
`ifdef ZT_SDRAM_CHASSIS
  assign dbg_sdram_ready_o = sdram_ready;
`else
  assign dbg_sdram_ready_o = 1'b1;
`endif
`ifdef ZT_SDRAM_CHASSIS
`ifdef DIAG_BOOT
  // Lane 2 becomes an exact download-integrity gate for NARC: 0x40000 program
  // word writes + 0x3C0000 populated gfx byte writes, with no FIFO drops, and
  // both direct reset-vector readback transactions completed.
  // Expected SDRAM word-write count for a complete ROM download. NOT a magic constant:
  // 0x400000 gfx+prog PLUS 0x120000 sound byte-lane writes (the D1 sound seam, 82b4b95)
  // = 0x520000, matching sim/zunit_download's asserted total. The old hard-coded
  // 0x400000 predated the sound seam and made this lane read RED on a HEALTHY cab
  // (observed 2026-07-25: pip 3 red, everything else green) -- an instrument bug that
  // also forced the overlay status bar red via the same stale threshold in the emu.
  localparam logic [31:0] DL_EXPECT_WRITES = 32'h0040_0000 + 32'h0012_0000;  // 0x520000
  assign dbg_unp_done_o = dbg_rb_valid && (fifo_accepted == DL_EXPECT_WRITES) && !(|fifo_dropped);
`else
  assign dbg_unp_done_o = 1'b1;
`endif
`else
  assign dbg_unp_done_o = 1'b1;
`endif
  assign dbg_cpu_req_o  = cpu_req;
  assign dbg_mem_ack_o  = cpu_ack;
  assign dbg_cpu_ce_o   = cpu_ce;
  logic int1;

  // RAW 0x01E00000 latch seam from memsys -> narc_sound_board (D8=NMI_N, D9=IRQ_N).
  logic        snd_latch_wr;
  logic [15:0] snd_latch_wdata;

  logic cpu_srt;
  // P0031: live DPYSTRT tap -> frame-latched scanout base (SPEC section 28.1).
  // The coined criminal intro displays from VRAM row 80 (DPYSTRT=FAFC); a
  // fixed row-0 scanout shows the stale previous screen + a shifted image
  // (cabinet-measured v8a rejection, EVIDENCE-NARC-V8A "Cabinet qualification
  // result"). NARC holds DPYCTL=F010 (ORG=0, DUDATE=16) in every captured
  // window, so the exercised rule is row0 = (DPYSTRT ^ 0xFFFC) >> 4
  // (tms34010.cpp display machine as derived in video_golden.py; verified
  // pixel-exact against MAME's snapshot at both FFFC->row0 and FAFC->row80).
  logic [15:0] dpystrt;
  tms34010_core #(.EXTERNAL_SRT(1'b1)) u_core (
    .clk(clk), .ce_cpu(cpu_ce), .ce_pix(ce_pix_cnt), .rst(rst_sys),
    .mem_req(cpu_req), .mem_we(cpu_we), .mem_addr(cpu_addr), .mem_size(cpu_size),
    .mem_wdata(cpu_wdata), .mem_srt(cpu_srt),
    .mem_rdata(cpu_rdata), .mem_ack(cpu_ack),
    .state_o(state_w), .pc_o(pc_dbg), .instr_word_o(instr_w),
    .illegal_opcode_o(illegal_dbg), .dpystrt_o(dpystrt), .lint1_in(int1));

  // memsys-side interface (clk); fed by the CDC's memsys side. The CDC's cpu-side FSM
  // is gated by cpu_ce so the 2-phase handshake is single-clock (STA times every path).
  logic mem_req, mem_we, mem_srt; logic [ADDR_WIDTH-1:0] mem_addr; logic [FIELD_SIZE_WIDTH-1:0] mem_size;
  logic [DATA_WIDTH-1:0] mem_wdata, mem_rdata; logic mem_ack;

  yunit_mem_cdc #(.AW(ADDR_WIDTH), .DW(DATA_WIDTH), .SW(FIELD_SIZE_WIDTH)) u_memcdc (
    .clk_cpu(clk), .ce_cpu(cpu_ce), .rst_cpu(rst_sys),
    .c_req(cpu_req), .c_we(cpu_we), .c_srt(cpu_srt),
    .c_addr(cpu_addr), .c_size(cpu_size), .c_wdata(cpu_wdata),
    .c_ack(cpu_ack), .c_rdata(cpu_rdata),
    .clk_sys(clk), .rst_sys(rst_sys),
    .m_req(mem_req), .m_we(mem_we), .m_srt(mem_srt),
    .m_addr(mem_addr), .m_size(mem_size), .m_wdata(mem_wdata),
    .m_rdata(mem_rdata), .m_ack(mem_ack));

  // ---- memsys external channels ----------------------------------------------
  // In the chassis build these are internal wires to the arbiter; in the sim build
  // src_*/vsd_*/cpu_gfx_* are top-level deferred-seam ports (declared above).
`ifdef ZT_SDRAM_CHASSIS
  logic        src_req;  logic [23:0] src_addr;  logic [7:0]  src_data;  logic src_ack;
  logic        cpu_gfx_rd; logic [23:0] cpu_gfx_raddr; logic [15:0] cpu_gfx_rdata; logic cpu_gfx_rack;
  logic [24:0] vsd_addr; logic [15:0] vsd_din, vsd_dout; logic [1:0] vsd_be;
  logic        vsd_rd, vsd_wr, vsd_ack;
`endif

  // ---- video subsystem: scanout read lane + palette + RGB ---------------------
  // The synthesized NARC chassis inserts a one-row page cache directly between
  // video and the NARC-local SDRAM burst port. Functional simulations retain
  // the original scan_* seam and their existing ideal-memory goldens.
  logic        video_scan_req; logic [17:0] video_scan_addr;
  logic [15:0] video_scan_data; logic video_scan_ack;
  logic        mem_scan_req; logic [17:0] mem_scan_addr;
  logic [15:0] mem_scan_data; logic mem_scan_ack;
  logic        vpal_we; logic [12:0] vpal_waddr; logic [15:0] vpal_wdata;
  // P0033: raster state for the beam-locked autoerase engine inside stv_vram_ddr_top.
  logic [8:0]  video_disp_base; logic video_disp_vblank;

  zunit_video_top u_video (
    .clk(clk), .rst(rst_sys), .ce_pix(ce_pix),
    .dpystrt(dpystrt),                        // P0031: live DPYSTRT tap (frame-latched inside)
    .pal_we(vpal_we), .pal_waddr(vpal_waddr), .pal_wdata(vpal_wdata),
    .scan_req(video_scan_req), .scan_addr(video_scan_addr),
    .scan_data(video_scan_data), .scan_ack(video_scan_ack),
    .vid_r(vid_r), .vid_g(vid_g), .vid_b(vid_b),
    .hsync(hsync), .vsync(vsync), .hblank(hblank), .vblank(vblank), .de(de),
    .rgb_valid(rgb_valid), .vblank_irq(vblank_irq),
    .disp_base(video_disp_base), .disp_vblank(video_disp_vblank));

`ifdef ZT_SDRAM_CHASSIS
  logic scan_brd_req; logic [24:0] scan_brd_addr; logic [9:0] scan_brd_len;
  logic [15:0] scan_brd_dout; logic scan_brd_dvalid, scan_brd_done;
`ifdef USE_DDR3_VRAM
  // Production builds always retain ZT_SDRAM_CHASSIS for program/GFX/sound.
  // That must not select the old SDRAM scan cache when VRAM itself moved to
  // DDR3: doing so leaves the real DDR3 scan port tied idle while the raster
  // reads an unwritten SDRAM VRAM window. Route video to the memsys DDR3 lane.
  assign mem_scan_req    = video_scan_req;
  assign mem_scan_addr   = video_scan_addr;
  assign video_scan_data = mem_scan_data;
  assign video_scan_ack  = mem_scan_ack;

  // The SDRAM page-burst port formerly belonged to scanout and is free once
  // VRAM moves to DDR3. NARC's Rev-1 blitter consumes one sequential GFX byte
  // per read-mode pixel; serving that stream through the arbiter's lowest-
  // priority single-word port makes each pixel pay a full ACTIVATE/CAS trip.
  // The high-score assembly forks every glyph at once, so that slowdown fills
  // the process pool and exactly produces the observed "first rows, then
  // slideshow/missing rows" failure. Reuse the donor-proven streaming cache,
  // but hook it only in this NARC DDR3 branch.
  yunit_src_cache #(.GFXW_BASE(SDRAM_GFXW_BASE[23:0])) u_narc_src_cache (
    .clk(clk), .rst(rst_sys),
    .src_req(src_req), .src_addr(src_addr), .src_data(src_data), .src_ack(src_ack),
    .brd_req(scan_brd_req), .brd_addr(scan_brd_addr), .brd_len(scan_brd_len),
    .brd_dout(scan_brd_dout), .brd_dvalid(scan_brd_dvalid), .brd_done(scan_brd_done));
`else
  // NARC's cabinet-proven shipped SDRAM layout is intentionally retained for
  // program/GFX. VRAM alone lives in bank 1 with col=word[8:0], allowing this
  // cache to fill a 512-word row through one page-mode burst. This removes the
  // 5,650-clock single-beat row fetch from the 4,044-clock raster deadline.
  vram_sdram_scanout #(.VRAM_WBASE(SDRAM_VRAMW_BASE)) u_narc_scan_cache (
    .clk(clk), .rst(rst_sys),
    .scan_req(video_scan_req), .scan_addr(video_scan_addr),
    .scan_data(video_scan_data), .scan_ack(video_scan_ack),
    .brd_req(scan_brd_req), .brd_addr(scan_brd_addr), .brd_len(scan_brd_len),
    .brd_dout(scan_brd_dout), .brd_dvalid(scan_brd_dvalid), .brd_done(scan_brd_done));
  assign mem_scan_req  = 1'b0;
  assign mem_scan_addr = 18'd0;
`endif
`elsif USE_SDRAM_VRAM
  assign mem_scan_req   = video_scan_req;
  assign mem_scan_addr  = video_scan_addr;
  assign video_scan_data = mem_scan_data;
  assign video_scan_ack  = mem_scan_ack;
`else
  // Functional VRAM build: memsys exposes no scanout port -> feed the video black.
  assign mem_scan_req   = 1'b0;
  assign mem_scan_addr  = 18'd0;
  assign video_scan_data = 16'h0000;
  assign video_scan_ack  = 1'b1;
`endif

  // ---- palette write-tap serializer: dual port (palv_a/palv_b) -> single pal_we -
`ifdef USE_HW_RAM
  logic        palv_we_a, palv_we_b;
  logic [12:0] palv_aa,   palv_ba;
  logic [15:0] palv_awd,  palv_bwd;
  // P0039b: palette writes are serialized by narc_pal_wr_queue (extracted so
  // the acceptance gate instantiates the REAL logic instead of a transcribed
  // copy). Up to two writes arrive per clock; only one retires. The former
  // single-slot merge here silently DROPPED the surplus.
  logic pal_q_ovf;
  narc_pal_wr_queue u_pal_wr_q (
    .clk(clk), .rst(rst_sys),
    .we_a(palv_we_a), .addr_a(palv_aa), .data_a(palv_awd),
    .we_b(palv_we_b), .addr_b(palv_ba), .data_b(palv_bwd),
    .pal_we(vpal_we), .pal_waddr(vpal_waddr), .pal_wdata(vpal_wdata),
    .ovf_o(pal_q_ovf));
`else
  assign vpal_we = 1'b0; assign vpal_waddr = 13'd0; assign vpal_wdata = 16'd0;
`endif

  // P0032 (SPEC section 28.2): merge the sound board's talkback readback into
  // IN1[10] (strobe = audio_sync bit) / IN2[7:0] (talkback byte) — the gospel
  // CUSTOM input fields (midyunit.cpp:289,305). v8a shipped these as harness
  // constants (talkback_rd unconnected) — cabinet-rejected. Builds without
  // ZT_SOUND (the boot PC-diff sims) keep the harness inputs verbatim.
  logic [63:0] inputs_merged;
`ifdef ZT_SOUND
  logic [15:0] snd_talkback;
  narc_talkback_merge u_tbmerge (
    .inputs_ext(inputs), .talkback_rd(snd_talkback),
    .inputs_merged(inputs_merged));
`else
  assign inputs_merged = inputs;
`endif

  // ---- memsys: CPU + DMA blitter + Z-unit memory map --------------------------
  zunit_memsys #(.ROM_HEX(ROM_HEX), .ROM_PROG_OFF(ROM_PROG_OFF)) u_sys (
    .clk(clk), .rst(rst_sys),
    .mem_req(mem_req), .mem_we(mem_we), .mem_srt(mem_srt),
    .mem_addr(mem_addr), .mem_size(mem_size),
    .mem_wdata(mem_wdata), .mem_rdata(mem_rdata), .mem_ack(mem_ack),
    .src_req(src_req), .src_addr(src_addr), .src_data(src_data), .src_ack(src_ack),
    .inputs(inputs_merged), .int1(int1),   // P0032: talkback merged into IN1/IN2
    .snd_select(snd_select), .snd_trig(snd_trig), .snd_reset(snd_reset),
    .snd_wr(snd_latch_wr), .snd_wdata(snd_latch_wdata),
    // autoerase: frame-paced sweep at vblank (gated internally by CONTROL bit4).
    .erase_start(vblank_irq), .erase_row0(9'd0), .erase_lines(10'(SCR_V_VIS_EN - SCR_V_VIS_ST)),
    .erase_busy(erase_busy), .blit_busy(blit_busy),
    .dbg_dma_we(dbg_dma_we), .dbg_dma_addr(dbg_dma_addr), .dbg_dma_wdata(dbg_dma_wdata)
`ifdef ZT_EXT_RD
    , .cpu_gfx_rd(cpu_gfx_rd), .cpu_gfx_raddr(cpu_gfx_raddr),
      .cpu_gfx_rdata(cpu_gfx_rdata), .cpu_gfx_rack(cpu_gfx_rack)
`endif
`ifdef USE_SDRAM_VRAM
    , .scan_req(mem_scan_req), .scan_addr(mem_scan_addr),
      .scan_data(mem_scan_data), .scan_ack(mem_scan_ack)
`ifdef USE_DDR3_VRAM
    , .sdram_por(sdram_por)
    , .scan_disp_base(video_disp_base), .scan_vblank(video_disp_vblank)
    , .ddram_addr(ddram_addr), .ddram_burstcnt(ddram_burstcnt), .ddram_rd(ddram_rd), .ddram_we(ddram_we)
    , .ddram_din(ddram_din), .ddram_be(ddram_be)
    , .ddram_busy(ddram_busy), .ddram_dout(ddram_dout), .ddram_dout_ready(ddram_dout_ready)
`else
    , .vsd_addr(vsd_addr), .vsd_din(vsd_din), .vsd_be(vsd_be), .vsd_rd(vsd_rd), .vsd_wr(vsd_wr)
    , .vsd_dout(vsd_dout), .vsd_ack(vsd_ack)
`endif
`endif
`ifdef USE_HW_RAM
    , .palv_we_a(palv_we_a), .palv_aa(palv_aa), .palv_awd(palv_awd)
    , .palv_we_b(palv_we_b), .palv_ba(palv_ba), .palv_bwd(palv_bwd)
`endif
  );

  assign int1_dbg = int1;

  // =====================================================================
  // P0022 FIRST-FETCH latch — additive OBSERVER on the CPU read seam.
  // Captures {cpu_addr, cpu_rdata} of the CPU's FIRST read-ack (cpu_ack & ~cpu_we)
  // after the core reset deasserts. That first read is the 34010 reset-vector fetch
  // (CORE_RESET_VEC: mem_addr = TRAP_VECTOR_BASE 0xFFFFFFE0, MEM_SIZE_32) — its data
  // is the reset PC the CPU reads out of program ROM. On silicon this is the §6
  // "what did the CPU RECEIVE on its first fetch" disproof: nonzero+correct = real
  // ROM over SDRAM; zero = read-0 / a P0022 capture freeze.
  //
  // Reset domain = the sdram_por power-on domain (P0022), NOT the core reset, so the
  // captured value SURVIVES the held-high RESET across ioctl_download. The CPU is
  // held in rst_sys while core_rst is high, so it issues NO read-ack during reset —
  // the first captured ack is inherently the post-reset reset-vector fetch. Pure
  // observer: it reads cpu_* and drives no datapath (remove it -> boot byte-identical).
`ifdef ZT_SDRAM_CHASSIS
  wire ff_por = sdram_por;         // P0022 persistent power-on domain
`elsif USE_DDR3_VRAM
  wire ff_por = sdram_por;         // DDR3-VRAM slice also carries a por
`else
  wire ff_por = rst;               // sim/functional: only reset source (deasserts once at boot)
`endif
  wire ff_read_ack = cpu_ack & ~cpu_we;
  // cpu_ack, cpu_addr, and cpu_rdata belong to the ce_cpu domain: the CDC
  // presents a response for a complete ce_cpu interval, and the core consumes
  // it on the following ce_cpu edge. Sample the observer on that same edge.
  // Besides matching the transaction semantics, this prevents an observer-only
  // full-rate endpoint from imposing a false 96 MHz path through CPU decode.
  always_ff @(posedge clk) if (cpu_ce !== 1'b0) begin
    if (ff_por) begin
      dbg_ff_valid <= 1'b0;
      dbg_ff_addr  <= 32'd0;
      dbg_ff_data  <= 32'd0;
`ifdef FF_CAPTURE_DEFEAT
    // MUTATION-TEST knob (§5): defeat the first-fetch capture. The boot TB's
    // first-fetch check MUST FAIL under +define+FF_CAPTURE_DEFEAT — proving the
    // gate exercises the capture (would fail if the capture were reverted).
    end else if (1'b0 && !dbg_ff_valid && ff_read_ack) begin
`else
    end else if (!dbg_ff_valid && ff_read_ack) begin
`endif
      dbg_ff_valid <= 1'b1;
      dbg_ff_addr  <= cpu_addr;
      dbg_ff_data  <= cpu_rdata;
    end
  end

`ifndef ZT_SDRAM_CHASSIS
  // Sim / functional build has no ioctl-download chassis -> the P0020/P0022 taps have
  // nothing to observe; tie them off (drive to 0) so the outputs are never dangling.
  assign fifo_accepted = 32'd0;
  assign fifo_dropped  = 32'd0;
  assign rst_during_dl = 1'b0;
  assign dbg_rb_data   = 32'd0;
  assign dbg_rb_valid  = 1'b1;
  assign dbg_cksum_w0    = 32'd0;
  assign dbg_cksum_w1    = 32'd0;
  assign dbg_cksum_w2    = 32'd0;
  assign dbg_cksum_valid = 1'b0;
`ifdef DIAG_BOOT
  assign dbg_snd_cksum_w0    = 32'd0;
  assign dbg_snd_cksum_valid = 1'b0;
  assign dbg_snd_lo_sum      = 16'd0;
  assign dbg_snd_pa_data     = 16'd0;
  assign dbg_snd_pa_valid    = 1'b0;
  assign dbg_snd_pa_addr_match = 1'b0;
  assign dbg_snd_land_data   = 16'd0;
  assign dbg_snd_land_seen   = 2'b00;
`endif
`endif

`ifdef DIAG_BOOT
`ifndef ZT_SOUND
  // No sound board in this build -> the sound-campaign 6809 instruments have
  // nothing to observe; tie them off so the DIAG_BOOT ports are never dangling.
  assign dbg_snd_ff_offset = 20'd0;
  assign dbg_snd_ff_data   = 8'd0;
  assign dbg_snd_ff_valid  = 1'b0;
  assign dbg_snd_gap_clks  = 16'd0;
  assign dbg_snd_req_count = 16'd0;
  assign dbg_snd_ack_count = 16'd0;
  assign dbg_snd_wd_rearms = 32'd0;
  assign dbg_snd_cmd_count = 16'd0;
  assign dbg_snd_audio_changes = 16'd0;
`endif
`endif

`ifdef ZT_SDRAM_CHASSIS
`ifndef DIAG_BOOT
  // Normal release image does not insert the diagnostic readback transaction.
  assign dbg_rb_data  = 32'd0;
  assign dbg_rb_valid = 1'b1;
`endif
`ifndef DIAG_ROMCHKSUM
  // Normal release image does not insert the diagnostic checksum sweep.
  assign dbg_cksum_w0    = 32'd0;
  assign dbg_cksum_w1    = 32'd0;
  assign dbg_cksum_w2    = 32'd0;
  assign dbg_cksum_valid = 1'b0;
`endif
`endif

  // =====================================================================
  // SDRAM CHASSIS (synthesizable): arb + adapter + shipped controller + ioctl FIFO.
  // Program/GFX mapping comes from zunit_pkg; VRAM-only page placement is below.
  // =====================================================================
`ifdef ZT_SDRAM_CHASSIS
  logic [24:0] sd_addr; logic [15:0] sd_din, sd_dout; logic [1:0] sd_be; logic sd_rd, sd_wr, sd_ack;
  logic        iol_ack;

  // ---- ioctl SDRAM-write path + HPS backpressure FIFO (P0020, 512-deep) --------
  // hps_io does NOT gate its byte stream on ioctl_wait (the ARM polls with a many-clk
  // round trip), and sdram_stock writes each ROM byte slowly, so many bytes arrive
  // during the backpressure latency. A 512-deep FIFO absorbs the round trip; ioctl_wait
  // asserts at a high-water mark leaving headroom for still-in-flight bytes.
  localparam int IOL_AW  = 9;                       // 512-deep
  localparam int IOL_HWM = 256;                     // wait high-water mark
  logic [42:0] iol_fifo [0:(1<<IOL_AW)-1];          // {addr[24:0], din[15:0], be[1:0]}
  logic [IOL_AW:0] iol_wp, iol_rp;
  wire  [IOL_AW:0] iol_occ   = iol_wp - iol_rp;
  wire             iol_full  = (iol_occ == (1<<IOL_AW));
  wire             iol_empty = (iol_wp == iol_rp);
  logic        iol_hold;
  logic [24:0] iol_addr_r; logic [15:0] iol_din_r; logic [1:0] iol_be_r;
  always_ff @(posedge clk) begin
    if (sdram_por) begin iol_wp <= '0; iol_rp <= '0; iol_hold <= 1'b0; end
    else begin
      if (ioctl_wr && !iol_full) begin
        iol_fifo[iol_wp[IOL_AW-1:0]] <= {ioctl_addr, ioctl_dout, ioctl_be};
        iol_wp <= iol_wp + 1'b1;
      end
      // DRAIN: free the live slot on ack; (re)load it from the FIFO whenever it is free.
      if (iol_hold && iol_ack) iol_hold <= 1'b0;
      if ((!iol_hold || (iol_hold && iol_ack)) && !iol_empty) begin
        {iol_addr_r, iol_din_r, iol_be_r} <= iol_fifo[iol_rp[IOL_AW-1:0]];
        iol_hold <= 1'b1;
        iol_rp   <= iol_rp + 1'b1;
      end
    end
  end
  assign ioctl_wait = (iol_occ >= IOL_HWM[IOL_AW:0]);

`ifdef DIAG_BOOT
  // Passive download-side half of the cabinet discriminator. Observe only
  // writes that the real IOL/SDRAM path ACKNOWLEDGED at the master reset-vector
  // word; do not generate traffic and do not participate in reset release.
  localparam logic [24:0] SND_MST_VEC_WORD = SDRAM_SNDW_BASE + 25'h047FFF;
  always_ff @(posedge clk) begin
    if (sdram_por) begin
      dbg_snd_land_data <= 16'd0;
      dbg_snd_land_seen <= 2'b00;
    end else if (iol_hold && iol_ack && (iol_addr_r == SND_MST_VEC_WORD)) begin
      if (iol_be_r[0]) begin
        dbg_snd_land_data[7:0] <= iol_din_r[7:0];
        dbg_snd_land_seen[0]   <= 1'b1;
      end
      if (iol_be_r[1]) begin
        dbg_snd_land_data[15:8] <= iol_din_r[15:8];
        dbg_snd_land_seen[1]    <= 1'b1;
      end
    end
  end
`endif

  // P0033: core stays in reset until the landing FIFO and its in-flight slot
  // are quiescent (see the core_rst block).
`ifdef MUT_NO_DRAIN_HOLD
  // MUTATION (sim-only, must die in the drain gate): the rejected v8a
  // behavior — the core releases at ioctl_download fall with writes in flight.
  assign dl_drain_busy = 1'b0;
`else
  assign dl_drain_busy = !iol_empty || iol_hold;
`endif

  // ---- P0020/P0022 download audit tap (pure observer; does NOT touch the FIFO) -----
  // Counts accepted/dropped pushes off the SAME (ioctl_wr, iol_full) the FIFO sees, and
  // latches the P0022 held-reset-across-download condition in the sdram_por domain so it
  // survives the core reset. Drives the top-level observability taps (DIAG_BOOT overlay).
  zunit_iol_audit u_iol_audit (
    .clk(clk), .por(sdram_por),
    .ioctl_wr(ioctl_wr), .iol_full(iol_full),
    .ioctl_download(ioctl_download), .core_rst(rst),
    .accepted(fifo_accepted), .dropped(fifo_dropped), .rst_during_dl(rst_during_dl));
  wire [15:0] iol_dout;

  // ---- P0046 settle watchdog (see the core_rst block) --------------------------
  // Starts only once the download is over and the FIFO is quiescent, so the seconds-long
  // hps_io delivery can never consume it. ~131k clocks = ~1.4 ms at 96 MHz, against a settle
  // that legitimately takes tens of clocks. Runs on sdram_por, never on core_rst.
  logic [17:0] boot_settle_cnt;
  wire         bs_drained = ~ioctl_download & iol_empty & ~iol_hold;
  always_ff @(posedge clk) begin
    if (sdram_por)                 boot_settle_cnt <= 18'd0;
    else if (!bs_drained)          boot_settle_cnt <= 18'd0;
    else if (!boot_settle_cnt[17]) boot_settle_cnt <= boot_settle_cnt + 18'd1;
  end
`ifdef MUT_NO_BOOT_SETTLE
  // Mutation (sim-only): satisfy the settle immediately, i.e. the pre-P0046 release boundary
  // that the v13 cabinet image had. The boot-release gate must die on this.
  assign boot_settle_to = 1'b1;
`else
  assign boot_settle_to = boot_settle_cnt[17];
`endif

  // DIAG_BOOT: after the real download FIFO is completely drained, read the
  // final two program words directly through the same arbiter/adapter/controller
  // that touched the pins. Hold the CPU in reset until both reads complete.
  // Expected result for NARC rev 7.00 is FFF6E000.
`ifdef DIAG_ROMCHKSUM
  // Self-contained diagnostic build, mutually exclusive with DIAG_BOOT (its own
  // uniquely-named RBF/MRA pair -- never combined into the DIAG_BOOT overlay).
  // Chain: (1) the SAME proven 2-word reset-vector readback as DIAG_BOOT, as a
  // sanity check that the audit port itself functions; then (2) once that is
  // valid, hand the single-outstanding audit port to the full U41/U23 sweep.
  // dbg_rb_data/valid are NOT driven here (this build never defines DIAG_BOOT,
  // so the `ifndef DIAG_BOOT tie-off above already ties them to 0/1 safely).
  localparam logic [24:0] RB_VEC_LO = SDRAM_ROMW_BASE + SDRAM_PROG_WORDS - 2;
  localparam logic [24:0] RB_VEC_HI = SDRAM_ROMW_BASE + SDRAM_PROG_WORDS - 1;
  logic ck_rb_iol_rd, ck_sw_iol_rd;
  logic [24:0] ck_rb_iol_addr, ck_sw_iol_addr;
  logic [31:0] ck_rb_data; logic ck_rb_valid;
  zunit_boot_readback_audit #(.VEC_LO_ADDR(RB_VEC_LO), .VEC_HI_ADDR(RB_VEC_HI)) u_ck_rb_audit (
    .clk(clk), .por(sdram_por), .sdram_ready(sdram_ready),
    .ioctl_download(ioctl_download), .fifo_empty(iol_empty), .fifo_hold(iol_hold),
    .iol_ack(iol_ack), .iol_dout(iol_dout), .iol_rd(ck_rb_iol_rd), .iol_addr(ck_rb_iol_addr),
    .data(ck_rb_data), .valid(ck_rb_valid));
  // SWEEP_BASE = SDRAM_ROMW_BASE + SDRAM_PROG_WORDS/2 (the u41/u23 pair occupies
  // the upper half of the 512KB program's word range; u42/u24 occupy the lower
  // half). SWEEP_WORDS = SDRAM_PROG_WORDS/2 (128K words = the pair's full span).
  zunit_rom_chksum_audit #(
    .SWEEP_BASE(SDRAM_ROMW_BASE + (SDRAM_PROG_WORDS >> 1)),
    .SWEEP_WORDS(int'(SDRAM_PROG_WORDS >> 1)), .NBLK(8)
  ) u_ck_sweep (
    .clk(clk), .por(sdram_por), .sdram_ready(sdram_ready && ck_rb_valid),
    .ioctl_download(ioctl_download), .fifo_empty(iol_empty), .fifo_hold(iol_hold),
    .iol_ack(iol_ack), .iol_dout(iol_dout), .iol_rd(ck_sw_iol_rd), .iol_addr(ck_sw_iol_addr),
    .w0(dbg_cksum_w0), .w1(dbg_cksum_w1), .w2(dbg_cksum_w2), .w3(), .valid(dbg_cksum_valid));
  // single-outstanding audit port: rb_audit owns it until valid, then the sweep does.
  wire        audit_iol_rd   = ck_rb_valid ? ck_sw_iol_rd   : ck_rb_iol_rd;
  wire [24:0] audit_iol_addr = ck_rb_valid ? ck_sw_iol_addr : ck_rb_iol_addr;
  // P0046: this self-contained checksum build owns the audit port for its own sweep and does
  // not gate release on it (its core_rst is the DIAG_BOOT-less production expression).
  assign boot_settle_busy = 1'b0;
`ifdef DIAG_BOOT
  // DIAG_ROMCHKSUM+DIAG_BOOT is an invalid combined build (dbg_rb_valid is not
  // driven here while the DIAG_BOOT core_rst gate waits on it); tie the
  // sound-campaign checksum ports so the combo at least elaborates
  // deterministically instead of leaving DIAG_BOOT ports dangling.
  assign dbg_snd_cksum_w0    = 32'd0;
  assign dbg_snd_cksum_valid = 1'b0;
  assign dbg_snd_lo_sum      = 16'd0;
`endif
`elsif DIAG_BOOT
`ifdef DIAG_SOUND_PRODRESET
  // Third cabinet discriminator.  Preserve the production core-reset expression
  // above, but read the master sound reset-vector word twice after the real
  // landing FIFO drains.  This requester is read-only and completes during the
  // existing ~18 us sound-board stagger; dbg_rb_valid does NOT gate core_rst in
  // DIAG_SOUND_PRODRESET.  Comparing this IOL-channel result with the first
  // G_SND completion separates stored content from a stale/clobbered run-time
  // read without a full checksum sweep or an extra reset hold.
  logic snd_rb_iol_rd;
  logic [24:0] snd_rb_iol_addr;
  logic [31:0] snd_rb_raw_data;
  zunit_boot_readback_audit #(
    .VEC_LO_ADDR(SND_MST_VEC_WORD), .VEC_HI_ADDR(SND_MST_VEC_WORD)
  ) u_snd_rb_audit (
    .clk(clk), .por(sdram_por), .sdram_ready(sdram_ready),
    .ioctl_download(ioctl_download), .fifo_empty(iol_empty), .fifo_hold(iol_hold),
    .iol_ack(iol_ack), .iol_dout(iol_dout),
    .iol_rd(snd_rb_iol_rd), .iol_addr(snd_rb_iol_addr),
    .data(snd_rb_raw_data), .valid(dbg_rb_valid));
  // Keep the cabinet-visible route narrow.  Exporting both raw 16-bit reads
  // coincided with the placement-sensitive sound-ROM-to-6809 path moving from
  // positive v13 margin to a -0.556 ns v14 fit.  These local comparisons preserve
  // every discriminator: first read matches the acknowledged landing word,
  // second read matches it, and both reads match each other.  All remaining
  // bits are constants and disappear during synthesis.
  assign dbg_rb_data = {
    (snd_rb_raw_data[15:0]  == dbg_snd_land_data),
    (snd_rb_raw_data[31:16] == dbg_snd_land_data),
    (snd_rb_raw_data[31:16] == snd_rb_raw_data[15:0]),
    29'd0
  };
  assign dbg_snd_cksum_w0     = 32'd0;
  assign dbg_snd_cksum_valid  = 1'b0;
  assign dbg_snd_lo_sum       = 16'd0;
  wire        audit_iol_rd    = snd_rb_iol_rd;
  wire [24:0] audit_iol_addr  = snd_rb_iol_addr;
  // P0046 in the PRODRESET diagnostic: this build exists to mirror the release image, so its
  // already-present post-drain readback now gates release exactly as production's does.
  assign boot_settle_busy = ~(dbg_rb_valid | boot_settle_to);
`else
  localparam logic [24:0] RB_VEC_LO = SDRAM_ROMW_BASE + SDRAM_PROG_WORDS - 2;
  localparam logic [24:0] RB_VEC_HI = SDRAM_ROMW_BASE + SDRAM_PROG_WORDS - 1;
  logic rb_iol_rd;
  logic [24:0] rb_iol_addr;
  zunit_boot_readback_audit #(.VEC_LO_ADDR(RB_VEC_LO), .VEC_HI_ADDR(RB_VEC_HI)) u_rb_audit (
    .clk(clk), .por(sdram_por), .sdram_ready(sdram_ready),
    .ioctl_download(ioctl_download), .fifo_empty(iol_empty), .fifo_hold(iol_hold),
    .iol_ack(iol_ack), .iol_dout(iol_dout), .iol_rd(rb_iol_rd), .iol_addr(rb_iol_addr),
    .data(dbg_rb_data), .valid(dbg_rb_valid));
  // SOUND-REGION sweep (SPEC 29.4 item 2, instrument 1): a SECOND
  // zunit_rom_chksum_audit instance parameterized at the sound region --
  // SWEEP_BASE = SDRAM_SNDW_BASE (0x260000), SWEEP_WORDS = 2*SND_IMAGE_WORDS
  // = 0x90000 words (master image = blocks 0-3, slave image = blocks 4-7).
  // The audit port is single-outstanding-shared, so the sweep is SERIALIZED
  // after the reset-vector readback: its sdram_ready is gated on dbg_rb_valid
  // and the port mux below hands over on the same flag (the proven
  // DIAG_ROMCHKSUM two-stage ownership pattern; rb_audit drops iol_rd on the
  // same edge valid rises, and the sweep's first request issues >=1 clk later).
  // EXPECTED (offline golden rtl/zunit/tools/compute_snd_chksum.py, straight
  // from narc.zip): w0 = 00007998 (the hi/lo XOR bytes are 00 by construction
  // -- every ROM appears twice via RELOAD -- so the HI-lane sum 7998 is w0's
  // only content field), supplemental low-lane sum dbg_snd_lo_sum = 4384.
  logic sc_iol_rd;
  logic [24:0] sc_iol_addr;
  zunit_rom_chksum_audit #(
    .SWEEP_BASE(SDRAM_SNDW_BASE),
    .SWEEP_WORDS(2 * SND_IMAGE_WORDS),
    .NBLK(8)
  ) u_snd_sweep (
    .clk(clk), .por(sdram_por), .sdram_ready(sdram_ready && dbg_rb_valid),
    .ioctl_download(ioctl_download), .fifo_empty(iol_empty), .fifo_hold(iol_hold),
    .iol_ack(iol_ack), .iol_dout(iol_dout), .iol_rd(sc_iol_rd), .iol_addr(sc_iol_addr),
    .w0(dbg_snd_cksum_w0), .w1(), .w2(), .w3(), .valid(dbg_snd_cksum_valid));
  // Supplemental LOW-lane 16-bit sum: pure observer on the shared audit port
  // while the sweep owns it (after dbg_rb_valid, before dbg_snd_cksum_valid --
  // the download FIFO is drained by then, so every iol_ack in that window is
  // one sweep read beat; the rb_audit's own final ack lands while
  // dbg_rb_valid is still 0 and is correctly excluded).
  always_ff @(posedge clk) begin
    if (sdram_por) dbg_snd_lo_sum <= 16'd0;
    else if (dbg_rb_valid && !dbg_snd_cksum_valid && iol_ack)
      dbg_snd_lo_sum <= dbg_snd_lo_sum + {8'd0, iol_dout[7:0]};
  end
  // P0046: this branch's core_rst already carries ~dbg_rb_valid, which IS the settle.
  assign boot_settle_busy = 1'b0;
  wire        audit_iol_rd   = dbg_rb_valid ? sc_iol_rd   : rb_iol_rd;
  wire [24:0] audit_iol_addr = dbg_rb_valid ? sc_iol_addr : rb_iol_addr;
`endif
`else
  // ---- P0046 PRODUCTION post-drain settle -------------------------------------
  // The release image now performs the same completed-read-after-drain the sound-working v8b
  // diagnostic performed as a side effect, using the same audit module and the same two
  // program-ROM vector words. Its data is not exported anywhere: the only thing consumed is
  // "a read completed", which is precisely the property that differed between the image that
  // played sound and the image that did not.
  localparam logic [24:0] BS_VEC_LO = SDRAM_ROMW_BASE + SDRAM_PROG_WORDS - 2;
  localparam logic [24:0] BS_VEC_HI = SDRAM_ROMW_BASE + SDRAM_PROG_WORDS - 1;
  logic        bs_iol_rd;
  logic [24:0] bs_iol_addr;
  logic [31:0] bs_data;
  logic        bs_valid;
  zunit_boot_readback_audit #(.VEC_LO_ADDR(BS_VEC_LO), .VEC_HI_ADDR(BS_VEC_HI)) u_boot_settle (
    .clk(clk), .por(sdram_por), .sdram_ready(sdram_ready),
    .ioctl_download(ioctl_download), .fifo_empty(iol_empty), .fifo_hold(iol_hold),
    .iol_ack(iol_ack), .iol_dout(iol_dout),
    .iol_rd(bs_iol_rd), .iol_addr(bs_iol_addr),
    .data(bs_data), .valid(bs_valid));
  assign boot_settle_busy = ~(bs_valid | boot_settle_to);
  wire        audit_iol_rd   = bs_iol_rd;
  wire [24:0] audit_iol_addr = bs_iol_addr;
`endif

  // NARC gfx is flat (host-side quadrant interleave) -> NO planar->flat unpack pass.

  // Sound-ROM SDRAM channel (driven by zunit_snd_rom under ZT_SOUND; tied off otherwise).
  logic                  snd_rom_rd;
  logic [SDRAM_AW-1:0]   snd_rom_addr_w;
  logic [15:0]           snd_rom_data_w;
  logic                  snd_rom_ack;
`ifndef ZT_SOUND
  assign snd_rom_rd     = 1'b0;
  assign snd_rom_addr_w = '0;
`endif

  yunit_sdram_arb #(
    .SD_AW(SDRAM_AW), .GFXW_BASE(SDRAM_GFXW_BASE), .ROMW_BASE(SDRAM_ROMW_BASE),
    .VRAMW_BASE(SDRAM_VRAMW_BASE), .GFX_BYTES(SDRAM_GFX_BYTES)
  ) u_arb (
    .clk(clk), .rst(sdram_por),                 // P0022: persistent SDRAM subsystem -> POR
`ifdef USE_DDR3_VRAM
    // VRAM lives in DDR3 (zunit_memsys drives ddram_* directly) -> no VRAM traffic reaches
    // the SDRAM arbiter. Tie its VRAM channel off; the vsd_* locals stay unused. Mirrors
    // yunit_top's USE_DDR3_VRAM tie-off. The shipped controller's page-burst scanout is
    // likewise inert in this build (nothing drives brd_*).
    .vsd_addr(25'd0), .vsd_din(16'd0), .vsd_be(2'd0), .vsd_rd(1'b0), .vsd_wr(1'b0),
    .vsd_dout(), .vsd_ack(),
`else
    .vsd_addr(vsd_addr), .vsd_din(vsd_din), .vsd_be(vsd_be), .vsd_rd(vsd_rd), .vsd_wr(vsd_wr),
    .vsd_dout(vsd_dout), .vsd_ack(vsd_ack),
`endif
    .cgfx_rd(cpu_gfx_rd), .cgfx_addr(cpu_gfx_raddr), .cgfx_data(cpu_gfx_rdata), .cgfx_ack(cpu_gfx_rack),
`ifdef USE_DDR3_VRAM
    // The source cache owns src_data/src_ack and the controller burst port.
    // Bypass the arbiter's old one-word-per-pixel source lane.
    .src_rd(1'b0), .src_addr(24'd0), .src_data(), .src_ack(),
`else
    .src_rd(src_req), .src_addr(src_addr), .src_data(src_data), .src_ack(src_ack),
`endif
    .iol_rd(audit_iol_rd), .iol_wr(iol_hold),
    .iol_addr(audit_iol_rd ? audit_iol_addr : iol_addr_r), .iol_din(iol_din_r),
    .iol_be(iol_be_r), .iol_dout(iol_dout), .iol_ack(iol_ack),
    .snd_rd(snd_rom_rd), .snd_addr_w(snd_rom_addr_w),
    .snd_data(snd_rom_data_w), .snd_ack(snd_rom_ack),
    .sd_addr(sd_addr), .sd_din(sd_din), .sd_be(sd_be), .sd_rd(sd_rd), .sd_wr(sd_wr),
    .sd_dout(sd_dout), .sd_ack(sd_ack));

`ifdef DIAG_BOOT
  // Passive read-side half: latch the first sound-channel completion exactly
  // where it leaves the arbiter, before zunit_snd_rom caches or byte-selects it.
  always_ff @(posedge clk) begin
    if (sdram_por) begin
      dbg_snd_pa_data       <= 16'd0;
      dbg_snd_pa_valid      <= 1'b0;
      dbg_snd_pa_addr_match <= 1'b0;
    end else if (!dbg_snd_pa_valid && snd_rom_ack) begin
      dbg_snd_pa_data       <= snd_rom_data_w;
      dbg_snd_pa_valid      <= 1'b1;
      dbg_snd_pa_addr_match <= (snd_rom_addr_w == SND_MST_VEC_WORD);
    end
  end
`endif

  // ---- shipped SDRAM controller + NARC-only VRAM row burst --------------------
  logic [24:0] ctl_addr; logic [15:0] ctl_din, ctl_dout; logic [1:0] ctl_wtbt;
  logic        ctl_rd, ctl_we, ctl_ready_raw;

  yunit_sdram_adapter u_sdadapt (
    .clk(clk), .rst(sdram_por),
    .sd_addr(sd_addr), .sd_din(sd_din), .sd_be(sd_be), .sd_rd(sd_rd), .sd_wr(sd_wr),
    .sd_dout(sd_dout), .sd_ack(sd_ack), .sdram_ready(sdram_ready),
    .ctl_addr(ctl_addr), .ctl_din(ctl_din), .ctl_wtbt(ctl_wtbt),
    .ctl_rd(ctl_rd), .ctl_we(ctl_we), .ctl_dout(ctl_dout),
    // Do not hide a completed single-beat read while a scan burst is pending.
    // Both ports share u_sdram.data; delaying the adapter ack until brd_req drops
    // lets the burst overwrite the CPU/program result with its final VRAM word.
    // u_sdram serializes the physical commands itself: ready goes low while the
    // burst owns the pins, so later requests wait and any prequeued request is
    // serviced only after the bounded burst closes.
    .ctl_ready(ctl_ready_raw));

  // NARC uses an isolated copy of the cab-proven shipped-UMK3 single-beat
  // controller. The later Smash TV page-map/read-register branch returned a
  // zero reset vector on this hardware and remains untouched in sdram_stock.
  sdram_stock_shipped #(
    .VRAM_BBASE(SDRAM_VRAMW_BASE << 1),
    .VRAM_BYTES(SDRAM_VRAM_WORDS << 1),
    .GFX_BBASE(SDRAM_GFXW_BASE << 1),
    .GFX_BYTES(SDRAM_GFX_WORDS << 1)
  ) u_sdram (
    .init(sdram_por), .clk(clk),
    .addr(ctl_addr), .din(ctl_din), .wtbt(ctl_wtbt), .we(ctl_we), .rd(ctl_rd),
    .dout(ctl_dout), .ready(ctl_ready_raw),
    .brd_req(scan_brd_req), .brd_addr(scan_brd_addr), .brd_len(scan_brd_len),
    .brd_dout(scan_brd_dout), .brd_dvalid(scan_brd_dvalid), .brd_done(scan_brd_done),
    .SDRAM_DQ(SDRAM_DQ), .SDRAM_A(SDRAM_A), .SDRAM_BA(SDRAM_BA),
    .SDRAM_DQML(SDRAM_DQML), .SDRAM_DQMH(SDRAM_DQMH),
    .SDRAM_nCS(SDRAM_nCS), .SDRAM_nRAS(SDRAM_nRAS), .SDRAM_nCAS(SDRAM_nCAS),
    .SDRAM_nWE(SDRAM_nWE), .SDRAM_CKE(SDRAM_CKE));
`endif  // ZT_SDRAM_CHASSIS

  // =====================================================================
  // NET-NEW dual-6809 SOUND BOARD (synthesizable). The 34010 latch @0x01E00000
  // is a pure SINK into this board — the board never drives the CPU fetch stream
  // (talkback is read-only and unread in the boot window), so the boot PC-diff is
  // unaffected (sim omits SYNTHESIS -> this whole block is absent).
  // =====================================================================
`ifdef ZT_SOUND
  // ---- power-on / board reset: MAME machine_reset() pulses reset_write(1)->(0)
  //      (midyunit_m.cpp:609-610). Tie both the device power-on reset and the
  //      board halt line to the synchronized core reset: the board is held while
  //      the core is held (download/SDRAM-init/reset) and runs once the CPU runs.
  //      NOTE (gospel): narc_sound_w (midyunit_m.cpp:647) calls ONLY write(data);
  //      it does NOT drive reset_write from the latch — D10 is unwired in 0.280.
  logic snd_board_rst;
  wire snd_rom_ready;
  wire [31:0] snd_fetch_wait_clks;
  wire [31:0] snd_wd_rearms;
  logic       cen_e, cen_q;

  // Exact 2 MHz MC6809E cadence (MAME NARC_MASTER_CLOCK/4). A new ROM address
  // has one complete 48-clk_sys bus window; only a word still missing at the
  // next falling-E deadline stretches that edge. This preserves authored music
  // and CVSD/DAC sequencing while retaining a lossless SDRAM wait state.
  narc_6809_clock_en #(
    .CLK_HZ(CLK_SYS_HZ),
    .CPU_HZ(SND_6809_E_HZ)
  ) u_6809_clock_en (
    .clk(clk), .rst(snd_board_rst), .rom_ready(snd_rom_ready),
    .cen_e(cen_e), .cen_q(cen_q), .stall_clks(snd_rom_stall_clks)
  );

  // YM2151: NARC has its own 3.579545 MHz crystal (MAME NARC_FM_CLOCK), not
  // the donor board's 12 MHz * 152/512 approximation (3.562500 MHz). Generate
  // the exact rational average directly from the 96 MHz system clock.
  logic       cen_fm, cen_fm_p1;
  narc_ym_clock_en #(
    .CLK_HZ(CLK_SYS_HZ),
    .YM_HZ(SND_YM2151_HZ)
  ) u_ym_clock_en (
    .clk(clk), .rst(rst_sys),
    .cen_fm(cen_fm), .cen_fm_p1(cen_fm_p1),
    .sound_rst(snd_board_rst)
  );

  // ---- sound-ROM SDRAM read agent (D1) ----------------------------------------
  wire mst_rom_read, slv_rom_read;
  wire [7:0] mst_rom_data, slv_rom_data;   // seam closed internally (no longer emu inputs)
  zunit_snd_rom #(
    .SD_AW(SDRAM_AW), .SNDW_BASE(SDRAM_SNDW_BASE), .IMAGE_WORDS(SND_IMAGE_WORDS)
  ) u_snd_rom (
    .clk(clk), .rst(snd_board_rst),
    .mst_offset(mst_rom_offset), .mst_read(mst_rom_read), .mst_data(mst_rom_data),
    .slv_offset(slv_rom_offset), .slv_read(slv_rom_read), .slv_data(slv_rom_data),
    .ready(snd_rom_ready),
    .snd_rd(snd_rom_rd), .snd_addr_w(snd_rom_addr_w),
    .snd_data(snd_rom_data_w), .snd_ack(snd_rom_ack),
    .stall_clks(snd_fetch_wait_clks), .wd_rearms(snd_wd_rearms));

`ifdef DIAG_BOOT
  // ---- SOUND-CAMPAIGN instruments 3+4 (SPEC 29.4 item 2, 2026-07-30) ---------
  // Pure observers on the mst_*/reset seams; drive nothing.
  //
  // Instrument 3: MASTER-6809 FIRST-FETCH latch. Captures {offset, data} of
  // the first master ROM read the seam ACKNOWLEDGES after snd_board_rst
  // releases. "Acknowledged" = mst_rom_read together with snd_rom_ready:
  // ready with demand0 (mst_rom_read) high implies live0, i.e. the cached
  // SDRAM word matches the LIVE master offset and mst_rom_data is the real
  // delivered byte (zunit_snd_rom.sv ready/live derivation). Healthy cab =
  // the 6809 reset-vector fetch: offset 0x8FFFE, data C0 (= u5[0xFFFE], the
  // vector HIGH byte; vector word C060 -- offline golden
  // rtl/zunit/tools/compute_snd_chksum.py and sim/narc_sound_smoke/make_hex.py).
  // data 00 = sound ROM never landed / snd read path broken; never valid =
  // the master 6809 never issued a ROM fetch (dead CPU / wedged E).
  // Lives in the ff_por power-on domain (P0022 pattern, like dbg_ff_*).
  logic snd_ff_armed;
  logic snd_rd_d;
  always_ff @(posedge clk) begin
    if (ff_por) begin
      dbg_snd_ff_valid  <= 1'b0;
      dbg_snd_ff_offset <= 20'd0;
      dbg_snd_ff_data   <= 8'd0;
      snd_ff_armed      <= 1'b0;
      dbg_snd_req_count <= 16'd0;
      dbg_snd_ack_count <= 16'd0;
      snd_rd_d          <= 1'b0;
    end else if (snd_board_rst) begin
      snd_ff_armed <= 1'b1;             // the board has been through its reset
      snd_rd_d     <= 1'b0;
    end else begin
      snd_rd_d <= snd_rom_rd;
      if (snd_rom_rd && !snd_rd_d && dbg_snd_req_count != 16'hFFFF)
        dbg_snd_req_count <= dbg_snd_req_count + 16'd1;
      if (snd_rom_ack && dbg_snd_ack_count != 16'hFFFF)
        dbg_snd_ack_count <= dbg_snd_ack_count + 16'd1;
      if (snd_ff_armed && !dbg_snd_ff_valid && mst_rom_read && snd_rom_ready) begin
        dbg_snd_ff_valid  <= 1'b1;
        dbg_snd_ff_offset <= mst_rom_offset;
        dbg_snd_ff_data   <= mst_rom_data;
      end
    end
  end
  assign dbg_snd_wd_rearms = snd_wd_rearms;

  // Instrument 4: RESET-RELEASE GAP counter -- clk cycles from rst_sys falling
  // to snd_board_rst falling, saturating at 16 bits. First interval only, in
  // the POR domain so it survives later core resets.
  // tb_narc_ym_clock_en_longrst measures ~43 (0x2B); a large/saturated value
  // on the cab would contradict that sim (the 29.2 mechanism-2 axis).
  logic gap_run, gap_done;
  logic rst_sys_d1;
  always_ff @(posedge clk) begin
    if (ff_por) begin
      dbg_snd_gap_clks <= 16'd0;
      gap_run <= 1'b0; gap_done <= 1'b0; rst_sys_d1 <= 1'b1;
    end else begin
      rst_sys_d1 <= rst_sys;
      if (!gap_done) begin
        if (!gap_run) begin
          if (rst_sys_d1 && !rst_sys) gap_run <= 1'b1;
        end else if (!snd_board_rst) begin
          gap_done <= 1'b1;
        end else if (dbg_snd_gap_clks != 16'hFFFF) begin
          dbg_snd_gap_clks <= dbg_snd_gap_clks + 16'd1;
        end
      end
    end
  end
`endif  // DIAG_BOOT

  // ---- board audio outputs ----------------------------------------------------
  wire signed [15:0] snd_ym_l, snd_ym_r;
  wire        [7:0]  snd_dac1_level, snd_dac2_level;
  wire        [15:0] snd_cvsd;

  narc_sound_board u_snd (
    .clk            (clk),
    .rst_pon        (snd_board_rst),
    .cen_e          (cen_e),
    .cen_q          (cen_q),
    .cen_fm         (cen_fm),
    .cen_fm_p1      (cen_fm_p1),
    // 34010 latch @0x01E00000 -> write(): raw word, D8=NMI_N, D9=IRQ_N.
    .ext_wr         (snd_latch_wr),
    .ext_wdata      (snd_latch_wdata),
    .reset_in       (snd_board_rst),        // machine_reset() halt line (power-on pulse)
    .talkback_rd    (snd_talkback),         // P0032: -> IN1[10]/IN2[7:0] via u_tbmerge
    .sound_int_state(),
    // sound ROM read seam -> D1 SDRAM/DDR3 lane (top pins; NOT BRAM).
    .mst_rom_offset (mst_rom_offset),
    .mst_rom_read   (mst_rom_read),
    .mst_rom_data   (mst_rom_data),
    .slv_rom_offset (slv_rom_offset),
    .slv_rom_read   (slv_rom_read),
    .slv_rom_data   (slv_rom_data),
    // audio
    .ym_left        (snd_ym_l),
    .ym_right       (snd_ym_r),
    .dac1_level     (snd_dac1_level),
    .dac2_level     (snd_dac2_level),
    .dac1_sample    (),
    .dac2_sample    (),
    .cvsd_sample    (snd_cvsd)
  );

  narc_audio_mix u_audio_mix (
    .clk(clk), .rst(snd_board_rst),
    .ym_l(snd_ym_l), .ym_r(snd_ym_r),
    .dac1_u(snd_dac1_level), .dac2_u(snd_dac2_level), .cvsd_u(snd_cvsd),
    .audio_l(audio_l), .audio_r(audio_r)
  );
`ifdef DIAG_BOOT
  // Passive downstream discriminator. Count 34010 sound commands, then count
  // PCM changes since the most recent command. A coin with cmd>0/audio>0 proves
  // the chain reached the final core audio pins; cmd>0/audio=0 localizes silence
  // inside the board/mixer rather than the ROM request path.
  logic signed [15:0] dbg_audio_l_d, dbg_audio_r_d;
  always_ff @(posedge clk) begin
    if (ff_por) begin
      dbg_snd_cmd_count     <= 16'd0;
      dbg_snd_audio_changes <= 16'd0;
      dbg_audio_l_d         <= 16'sd0;
      dbg_audio_r_d         <= 16'sd0;
    end else begin
      dbg_audio_l_d <= audio_l;
      dbg_audio_r_d <= audio_r;
      if (snd_latch_wr) begin
        if (dbg_snd_cmd_count != 16'hFFFF)
          dbg_snd_cmd_count <= dbg_snd_cmd_count + 16'd1;
        dbg_snd_audio_changes <= 16'd0;
      end else if (!snd_board_rst &&
                   ((audio_l != dbg_audio_l_d) || (audio_r != dbg_audio_r_d)) &&
                   dbg_snd_audio_changes != 16'hFFFF) begin
        dbg_snd_audio_changes <= dbg_snd_audio_changes + 16'd1;
      end
    end
  end
`endif
`else
  assign audio_l = 16'sd0;
  assign audio_r = 16'sd0;
`endif  // ZT_SOUND

endmodule

`default_nettype wire
