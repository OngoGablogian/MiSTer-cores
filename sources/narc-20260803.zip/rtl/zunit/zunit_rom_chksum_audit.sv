// DIAG_ROMCHKSUM-only physical SDRAM full-range checksum sweep.
//
// Motivation: the Williams factory self-test (DIAG/ROMCHIPS.ASM) checksums each
// physical program-ROM chip individually via a bit-field walk (WIDTH=8,
// INTERLEAVE=16) over its FULL populated range -- e.g. U23 (high byte of the
// u41/u23 pair) spans bit-address 0xFFE00008..0xFFFFFFF8, a full 128 KB. On
// cab this test reports U23 red while U41/U24/U42 report green, even though
// the top of that exact same range (the reset vector, at the very end of the
// u41/u23 span) is independently confirmed correct by both the direct
// physical-SDRAM readback (zunit_boot_readback_audit) and the CPU's own
// 3.54M-instruction bit-exact boot trace. So a whole-chip data/mapping fault
// is implausible; the more likely explanation is a fault localized to a
// small part of U23's 128 KB that boot code never happens to touch.
//
// This module sweeps the ENTIRE u41/u23 physical SDRAM word range
// [SDRAM_ROMW_BASE+SDRAM_PROG_WORDS/2 .. SDRAM_ROMW_BASE+SDRAM_PROG_WORDS-1]
// and reports per-block XOR checksums of the U23 byte (bits [15:8] of each
// word) plus a global XOR/sum, split into NBLK sub-blocks so a single cab
// flash localizes any divergence to a block rather than only "pass/fail".
// It reports RAW computed facts only (screen-as-logic-analyzer doctrine) --
// no expected-value table is embedded in hardware. The matching expected
// checksums are computed OFFLINE from the real ROM bytes
// (rtl/zunit/tools/compute_u23_chksum.py) and compared by hand/script after
// a cab read, exactly mirroring the existing readback-audit pattern.
//
// It is an audit requester only; it is absent from normal builds.
`timescale 1ns/1ps
`default_nettype none
module zunit_rom_chksum_audit #(
  parameter logic [24:0] SWEEP_BASE  = 25'h200000,  // u41/u23 word base (SDRAM_ROMW_BASE + PROG_WORDS/2)
  parameter int          SWEEP_WORDS = 25'h20000,   // 0x20000 words = 128K words = 256KB combined pair
  parameter int          NBLK        = 8            // sub-blocks for localization (must divide SWEEP_WORDS)
)(
  input  logic        clk,
  input  logic        por,
  input  logic        sdram_ready,
  input  logic        ioctl_download,
  input  logic        fifo_empty,
  input  logic        fifo_hold,
  input  logic        iol_ack,
  input  logic [15:0] iol_dout,
  output logic        iol_rd,
  output logic [24:0] iol_addr,
  // packed report: w0={hi_xor,lo_xor,hi_sum16}, w1=block_xor[3:0] (blocks 0-3),
  // w2=block_xor[7:4] (blocks 4-7), w3={done,16'b0,word_count[14:0]} (progress/done)
  output logic [31:0] w0,
  output logic [31:0] w1,
  output logic [31:0] w2,
  output logic [31:0] w3,
  output logic        valid
);
  localparam int BLKWORDS = SWEEP_WORDS / NBLK;
  localparam int CNTW     = $clog2(SWEEP_WORDS + 1);

  typedef enum logic [1:0] {WAIT_DL, SWEEP, GAP, DONE} state_t;
  state_t state;
  logic dl_seen;

  logic [CNTW-1:0] word_idx;   // 0 .. SWEEP_WORDS-1, current word being fetched
  logic [7:0]      hi_xor, lo_xor;
  logic [15:0]     hi_sum;
  logic [7:0]      block_xor [0:NBLK-1];
  int              blk;       // which block word_idx currently falls in (combinational)

  always_comb blk = int'(word_idx) / BLKWORDS;

  always_ff @(posedge clk) begin
    if (por) begin
      state <= WAIT_DL; dl_seen <= 1'b0; iol_rd <= 1'b0; iol_addr <= 25'd0;
      word_idx <= '0; hi_xor <= 8'd0; lo_xor <= 8'd0; hi_sum <= 16'd0; valid <= 1'b0;
      for (int i = 0; i < NBLK; i++) block_xor[i] <= 8'd0;
    end else begin
      if (ioctl_download) dl_seen <= 1'b1;
      case (state)
        WAIT_DL: if (dl_seen && !ioctl_download && fifo_empty && !fifo_hold && sdram_ready) begin
          iol_addr <= SWEEP_BASE; iol_rd <= 1'b1; state <= SWEEP;
        end
        SWEEP: if (iol_ack) begin
          hi_xor <= hi_xor ^ iol_dout[15:8];
          lo_xor <= lo_xor ^ iol_dout[7:0];
          hi_sum <= hi_sum + {8'd0, iol_dout[15:8]};
          block_xor[blk] <= block_xor[blk] ^ iol_dout[15:8];
          iol_rd <= 1'b0;
          if (word_idx == CNTW'(SWEEP_WORDS - 1)) begin
            state <= DONE;
          end else begin
            word_idx <= word_idx + 1'b1;
            state    <= GAP;
          end
        end
        GAP: begin
          // word_idx was already incremented in SWEEP's NBA to the NEXT index we want
          // -- do not add 1 again (that skipped a word every step and read one word
          // past the sweep range at the end; caught by the real-ROM checksum
          // cross-check + the trace TB, not by iverilog or a self-consistency check).
          iol_addr <= SWEEP_BASE + 25'(word_idx); iol_rd <= 1'b1; state <= SWEEP;
        end
        default: begin iol_rd <= 1'b0; valid <= 1'b1; state <= DONE; end
      endcase
    end
  end

  always_comb begin
    w0 = {hi_xor, lo_xor, hi_sum};
    w1 = {block_xor[3], block_xor[2], block_xor[1], block_xor[0]};
    w2 = {block_xor[7], block_xor[6], block_xor[5], block_xor[4]};
    w3 = {valid, 15'd0, 1'b0, word_idx[CNTW-1:0]};
  end
endmodule
`default_nettype wire
