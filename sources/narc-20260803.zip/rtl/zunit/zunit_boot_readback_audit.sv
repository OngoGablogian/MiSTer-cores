`default_nettype none
// =============================================================================
// zunit_boot_readback_audit.sv — direct PHYSICAL-SDRAM readback of the 34010
// reset vector, after the ROM download completes.
//
// RECONSTRUCTED 2026-07-25: the original was never committed (only the build-list
// reference was, in 4ef9643) and was lost in a branch switch. Rebuilt to the exact
// contract fixed by its two instantiations in zunit_top (DIAG_BOOT / DIAG_ROMCHKSUM)
// and to the PROVEN iol_* request/ack protocol of its sibling zunit_rom_chksum_audit
// (same ports, same handshake, same WAIT_DL gating) so the two behave identically on
// the shared boot-audit SDRAM channel.
//
// WHAT IT PROVES (screen-as-logic-analyzer, §6): what is PHYSICALLY IN SDRAM at the
// reset-vector words, read back through the real arbiter/controller path — as opposed
// to what the download demux THOUGHT it wrote (dl_vec_stream) or what the CPU received
// on its first fetch (ff_data). The emu compares all three; a mismatch localizes the
// break to write-side vs read-side vs CPU-fetch.
//
// It reports RAW READ BYTES ONLY — no expected value is baked in, so it cannot lie by
// comparing against a stale constant (the failure mode that made the 2026-07-25 diag
// report RED on a healthy cab). Interpretation lives in the emu, next to the taps it
// is compared against.
//
// VEC_LO_ADDR/VEC_HI_ADDR are WORD addresses; the 34010 reset vector is the last two
// words of the program image (zunit_top passes SDRAM_ROMW_BASE + SDRAM_PROG_WORDS-2/-1).
// data = {word@VEC_HI, word@VEC_LO} = the little-endian 32-bit reset PC.
// =============================================================================
module zunit_boot_readback_audit #(
  parameter logic [24:0] VEC_LO_ADDR = 25'h21FFFE,   // low  word of the reset vector
  parameter logic [24:0] VEC_HI_ADDR = 25'h21FFFF    // high word of the reset vector
)(
  input  logic        clk,
  input  logic        por,              // P0022 power-on domain (survives held core reset)
  input  logic        sdram_ready,
  input  logic        ioctl_download,
  input  logic        fifo_empty,       // download FIFO drained
  input  logic        fifo_hold,        // download FIFO still presenting a write
  input  logic        iol_ack,
  input  logic [15:0] iol_dout,
  output logic        iol_rd,
  output logic [24:0] iol_addr,
  output logic [31:0] data,             // {hi_word, lo_word} as physically read
  output logic        valid             // sticky: both words have been read back
);
  // Same gating as the sibling: wait until a download has actually HAPPENED and fully
  // drained (dl_seen && !ioctl_download && fifo_empty && !fifo_hold && sdram_ready)
  // before issuing a read, so the audit can never race the loader for the channel.
  typedef enum logic [2:0] {WAIT_DL, RD_LO, GAP, RD_HI, DONE} state_t;
  state_t state;
  logic   dl_seen;

  always_ff @(posedge clk) begin
    if (por) begin
      state <= WAIT_DL; dl_seen <= 1'b0; iol_rd <= 1'b0; iol_addr <= 25'd0;
      data <= 32'd0; valid <= 1'b0;
    end else begin
      if (ioctl_download) dl_seen <= 1'b1;
      case (state)
        WAIT_DL: if (dl_seen && !ioctl_download && fifo_empty && !fifo_hold && sdram_ready) begin
          iol_addr <= VEC_LO_ADDR; iol_rd <= 1'b1; state <= RD_LO;
        end
        RD_LO: if (iol_ack) begin
          data[15:0] <= iol_dout;        // low word as physically stored
          iol_rd     <= 1'b0;
          state      <= GAP;
        end
        // one idle cycle between requests: the arbiter is grant-held with an
        // inter-command bubble, and the sibling uses the same GAP step.
        GAP: begin
          iol_addr <= VEC_HI_ADDR; iol_rd <= 1'b1; state <= RD_HI;
        end
        RD_HI: if (iol_ack) begin
          data[31:16] <= iol_dout;       // high word as physically stored
          iol_rd      <= 1'b0;
          valid       <= 1'b1;           // sticky from here
          state       <= DONE;
        end
        default: begin iol_rd <= 1'b0; state <= DONE; end
      endcase
    end
  end
endmodule
`default_nettype wire
