#!/usr/bin/env bash
# CORE-2 SRT acceptance gate (Icarus Verilog).
#   sv2v-converts the REAL tms34010 core to Verilog, compiles it with the
#   instruction-driven SRT testbench, runs, and greps TEST_RESULT.
# Regenerate the vector-derived preload first (idempotent):
#   python <repo>/goldens/narc_srt_derive.py   (rebuilds narc_srt_vector.json)
#   then this script's gen step rebuilds srt_src.hex / srt_params.vh.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
CORE="$(cd "$HERE/../.." && pwd)"                 # rtl/tms34010
REPO="$(cd "$CORE/../.." && pwd)"                 # repo root
SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
export PATH="/c/iverilog/bin:$PATH"

# 1) vector -> hex + params (derives strictly from the golden vector JSON)
python - "$HERE" "$REPO/goldens/narc_srt_vector.json" <<'PY'
import json,os,sys
here,vec=sys.argv[1],sys.argv[2]
v=json.load(open(vec))
ROW=v['row_words']; sidx=v['src_word_index']; didx=v['dst_word_index']
init={int(k):val for k,val in v['vram_initial'].items()}
exp={int(k):val for k,val in v['vram_expected'].items()}
src=[init.get(sidx+i,0) for i in range(ROW)]
for i in range(ROW):
    assert exp.get(didx+i,0)==src[i] and exp.get(sidx+i,0)==src[i]
open(os.path.join(here,'srt_src.hex'),'w').write("".join(f"{w&0xFFFF:04x}\n" for w in src))
open(os.path.join(here,'srt_params.vh'),'w').write(
    f"localparam integer SRT_ROW={ROW};\n"
    f"localparam integer SRC_WIDX={sidx};\n"
    f"localparam integer DST_WIDX={didx};\n"
    f"localparam [31:0] A2_SRC=32'd{v['setup']['A2_src_bitaddr']};\n"
    f"localparam [31:0] A1_DST=32'd{v['setup']['A1_dst_bitaddr']};\n"
    f"localparam [31:0] A4_REG=32'd{v['setup']['A4_reg_data']};\n"
    f"localparam [31:0] DPYCTL_V=32'd{v['setup']['DPYCTL']};\n")
print(f"gen: ROW={ROW} src={sidx} dst={didx}")
PY

# 2) sv2v-convert the real core (no -DSYNTHESIS: keep sim behaviour)
SV=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SV+=("$f"); done \
  < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
echo "sv2v: ${#SV[@]} core files -> core_syn.v"
"$SV2V" "${SV[@]}" > "$HERE/core_syn.v"

# 3) compile + run BASE (real RTL) -> must PASS
iverilog -g2012 -s tb_narc_srt -o "$HERE/srt.vvp" \
  -I "$HERE" "$HERE/core_syn.v" "$HERE/tb_narc_srt.v"
cd "$HERE"
vvp srt.vvp | tee srt.log | grep -iE "TEST_RESULT|FAIL:" || { echo "no TEST_RESULT printed"; exit 1; }
grep -q "TEST_RESULT: PASS" srt.log
echo "BASE: PASS"

# 4) MUTANT (gate-discrimination proof): drop the external raw-command
#    sideband. The memory then performs only a normal single-field access and
#    the 1024-entry golden MUST fail.
echo "=== mutant MUT_SRT_EXT_CMD (must DIE) ==="
"$SV2V" -DMUT_SRT_EXT_CMD "${SV[@]}" > "$HERE/core_mut.v"
iverilog -g2012 -s tb_narc_srt -o "$HERE/srt_mut.vvp" \
  -I "$HERE" "$HERE/core_mut.v" "$HERE/tb_narc_srt.v"
vvp "$HERE/srt_mut.vvp" > "$HERE/srt_mut.log" 2>&1 || true
grep -iE "TEST_RESULT|FAIL:" "$HERE/srt_mut.log" || true
if grep -q "TEST_RESULT: PASS" "$HERE/srt_mut.log"; then
  echo "MUTANT-CHECK: FAIL -- mutant PASSED; gate does NOT discriminate the SRT row copy"
  exit 1
fi
echo "MUTANT-CHECK: OK -- base PASS + mutant dies (gate discriminates external raw SRT command)"
