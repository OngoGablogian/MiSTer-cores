#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# MOVB *Rs(SOffset),*Rd(DOffset) (0xBC00-0xBDFF) acceptance gate — Icarus.
#
#   BASE     : the real RTL must PASS tb_movb_off_m2m.
#   MUTANT 1 : MUT_MOVBNONO_NOT_BYTE — decode drops force_byte, so the move
#                                      uses ST.FS instead of the fixed 8.
#   MUTANT 2 : MUT_MOVBNONO_BE_LEGAL — decode matches on top6 instead of top7,
#                                      so the RESERVED half 0xBE00-0xBFFF
#                                      (MAME `illop`) also decodes.
#
# Both mutants MUST die. A mutant that passes means the gate does not
# discriminate the forced byte field / the reserved-encoding boundary.
# -----------------------------------------------------------------------------
set -uo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
CORE="$(cd "$HERE/../.." && pwd)"
SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
export PATH="/c/iverilog/bin:$PATH"

OUT="$HERE/work"
mkdir -p "$OUT"
TB="tb_movb_off_m2m"

SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRC+=("$f"); done \
  < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SRC+=( "$CORE/sim/models/sim_memory_model.sv" "$CORE/sim/tb/${TB}.sv" )

run_variant() {           # $1 = tag, $2... = sv2v defines
  local tag="$1"; shift
  "$SV2V" "$@" "${SRC[@]}" > "$OUT/${TB}_${tag}.v" || return 2
  iverilog -g2012 -s "$TB" -o "$OUT/${TB}_${tag}.vvp" "$OUT/${TB}_${tag}.v" \
      > "$OUT/${TB}_${tag}.iv.log" 2>&1 || return 2
  ( cd "$OUT" && vvp "$OUT/${TB}_${tag}.vvp" ) > "$OUT/${TB}_${tag}.log" 2>&1
  grep -q "TEST_RESULT: PASS" "$OUT/${TB}_${tag}.log"
}

echo "=== BASE (real RTL) — must PASS ==="
if run_variant base; then
  echo "BASE: PASS"
else
  grep -iE "TEST_RESULT|FAIL:" "$OUT/${TB}_base.log" | head -20
  echo "BASE: FAIL"; exit 1
fi

rc=0
for mut in MUT_MOVBNONO_NOT_BYTE MUT_MOVBNONO_BE_LEGAL; do
  echo "=== mutant $mut — must DIE ==="
  if run_variant "$mut" "-D$mut"; then
    echo "MUTANT-CHECK: FAIL — $mut PASSED; the gate does not discriminate it"
    rc=1
  else
    grep -m3 -iE "TEST_RESULT|FAIL:" "$OUT/${TB}_${mut}.log" | sed 's/^/      /'
    echo "MUTANT-CHECK: OK — $mut dies"
  fi
done

[ $rc -eq 0 ] && echo "GATE: base PASS + both mutants die"
exit $rc
