#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# MOVE *Rs(SOffset),*Rd+ (0xD000-0xD3FF) acceptance gate — Icarus Verilog.
#
#   BASE     : the real RTL must PASS tb_move_off_ni.
#   MUTANT 1 : MUT_OFFNI_NO_WB    — decode drops the dest-pointer writeback,
#                                   so Rd is never post-incremented.
#   MUTANT 2 : MUT_OFFNI_FIXED32  — the writeback steps Rd by a hardcoded 32
#                                   instead of the F-selected field size.
#
# Both mutants MUST die. A mutant that passes means the gate does not
# discriminate the post-increment / field-size semantics of MOVE_NO_NI.
# -----------------------------------------------------------------------------
set -uo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
CORE="$(cd "$HERE/../.." && pwd)"
SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
export PATH="/c/iverilog/bin:$PATH"

OUT="$HERE/work"
mkdir -p "$OUT"
TB="tb_move_off_ni"

SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRC+=("$f"); done \
  < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SRC+=( "$CORE/sim/models/sim_memory_model.sv" "$CORE/sim/tb/${TB}.sv" )

run_variant() {           # $1 = tag, $2... = sv2v defines
  local tag="$1"; shift
  "$SV2V" "$@" "${SRC[@]}" > "$OUT/${TB}_${tag}.v" || return 2
  iverilog -g2012 -s "$TB" -o "$OUT/${TB}_${tag}.vvp" "$OUT/${TB}_${tag}.v" \
      > "$OUT/${TB}_${tag}.iv.log" 2>&1 || return 2
  ( cd "$OUT" && vvp "$OUT/${TB}_${tag}.vvp" ) > "$OUT/${TB}_${tag}.log" 2>&1
  grep -q "TEST_RESULT: PASS" "$OUT/${TB}_${tag}.log"
}

echo "=== BASE (real RTL) — must PASS ==="
if run_variant base; then
  echo "BASE: PASS"
else
  grep -iE "TEST_RESULT|FAIL:" "$OUT/${TB}_base.log" | head -20
  echo "BASE: FAIL"; exit 1
fi

rc=0
for mut in MUT_OFFNI_NO_WB MUT_OFFNI_FIXED32; do
  echo "=== mutant $mut — must DIE ==="
  if run_variant "$mut" "-D$mut"; then
    echo "MUTANT-CHECK: FAIL — $mut PASSED; the gate does not discriminate it"
    rc=1
  else
    grep -m3 -iE "TEST_RESULT|FAIL:" "$OUT/${TB}_${mut}.log" | sed 's/^/      /'
    echo "MUTANT-CHECK: OK — $mut dies"
  fi
done

[ $rc -eq 0 ] && echo "GATE: base PASS + both mutants die"
exit $rc
