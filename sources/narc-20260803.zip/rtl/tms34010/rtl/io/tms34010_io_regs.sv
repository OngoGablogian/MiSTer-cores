// -----------------------------------------------------------------------------
// tms34010_io_regs.sv
//
// On-chip memory-mapped I/O register file for the TMS34010.
//
// Per the 1988 User's Guide Figure 6-1 (page 6-3), the GSP has 32 internal
// 16-bit registers occupying the bit-address range 0xC0000000-0xC00001FF.
// Each register sits at a 0x10-bit-aligned address (16 bits apart). The CPU
// (and, on real silicon, the host) reaches them through the ordinary
// bit-addressed memory interface; an address decodes to I/O space when its
// two MSBs are 11 and bits[29:9] are 0. The register index is addr[8:4].
//
// "All I/O registers ... are cleared to 0 at reset" (UG §6, Reset). The one
// documented exception concerns the HLT bit's dependence on the HCS pin of
// the host interface, which this FPGA reimplementation does not yet model;
// resetting every register to 0 is therefore correct here.
//
// Scope (Task 0081 — foundation; P00xx — live video counters):
//   - Plain read/write storage for the control/graphics registers that the
//     instruction set reads (PSIZE, PMASK, CONVSP, CONVDP, CONTROL, DPYCTL, ...).
//   - HCOUNT/VCOUNT are now the LIVE horizontal/vertical counters from u_video
//     (read-only on silicon; see the rdata mux). REFCNT/DPYADR remain plain
//     storage; INTPEND bits are software-clear with device set-on-event (DI/WV).
//
// Port shape:
//   - Synchronous active-high reset (assumption A0003), all registers -> 0.
//   - One synchronous write port (req & we & is_io).
//   - One combinational (async) read port. The 32x16 array is tiny (512
//     bits) and async read keeps this composable with the core's existing
//     register-style reads; FPGA maps it to flops + a 32:1 mux.
//   - `is_io` tells the caller whether `addr` decoded as I/O space, so the
//     surrounding memory fabric can route reads/writes here vs. external RAM.
//
// Spec source:
//   third_party/TMS34010_Info/docs/ti-official/1988_TI_TMS34010_Users_Guide.pdf
//   Figure 6-1 (I/O Register Memory Map), §6 "I/O Registers".
// -----------------------------------------------------------------------------

`default_nettype none
module tms34010_io_regs
  import tms34010_pkg::*;
(
  input  wire logic                  clk,
  input  wire logic                  rst,

  input  wire logic                  req,      // access strobe
  input  wire logic                  we,       // 1 = write, 0 = read
  input  wire logic [ADDR_WIDTH-1:0] addr,     // full 32-bit bit-address
  // SHARED-P0038: the access FIELD SIZE. On the TMS34010 the size of a memory
  // access is NOT encoded in the address -- it lives in ST (FS0/FS1), is set by
  // SETF, and is STICKY across accesses (1988 UG §6 / §13 field semantics). I/O
  // registers are reached by the ordinary bit-addressed field path, so this
  // module cannot commit a correct write without it. Threaded from the core's
  // `mem_size` (the same value the external memory model uses).
  input  wire logic [FIELD_SIZE_WIDTH-1:0] size, // field width in bits (1..32; 0 unused)
  input  wire logic [DATA_WIDTH-1:0] wdata,    // field value, RIGHT-JUSTIFIED (low
                                               // bits; hi bits span into idx+1)

  // Pixel-clock ENABLE for the video-timing counters (u_video). Threaded from
  // the emu (Arcade-SmashTV.sv ce_pix = 96 MHz / 12 = 8 MHz) through the core.
  // Left UNCONNECTED by legacy unit TBs -> u_video defaults to full rate (its
  // own `ce === 1'b0` guard), so those TBs are unaffected.
  input  wire logic                  ce_pix,

  output logic [15:0]           rdata,    // selected register (0 if not I/O)
  output logic                  is_io,    // addr decodes to I/O space

  // Dedicated taps for the graphics datapath (combinational views of the
  // stored registers). More can be added (PMASK/CONTROL) as the graphics ops
  // that need them land.
  output logic [15:0]           psize_o,  // PSIZE: pixel size in bits (1..16)
  output logic [15:0]           convdp_o, // CONVDP: XY->linear dest pitch shift
  output logic [15:0]           convsp_o, // CONVSP: XY->linear source pitch shift
  output logic [15:0]           control_o,// CONTROL: PPOP[14:10], PBV/PBH, W, T(bit5)
  output logic [15:0]           pmask_o,  // PMASK: plane mask (1 bit = plane masked)
  output logic [15:0]           intenb_o, // INTENB: maskable-interrupt enables
  output logic [15:0]           intpend_o,// INTPEND: maskable-interrupt pending bits
  output logic [15:0]           dpystrt_o,// P0024: DPYSTRT (display start) — double-buffer page tap
  output logic [15:0]           dpyctl_o, // CORE-2: DPYCTL — bit 11 (SRT) gates PIXT shift-register transfer
  output logic [15:0]           hstctlh_o,// HSTCTLH: host control (NMI/NMIM in bits 8/9)
  input  wire logic                  nmi_clear,// 1-cycle: clear HSTCTLH.NMI (device took NMI)
  input  wire logic                  wvp_set,  // 1-cycle: set INTPEND.WV (window violation)
  // P0016: external interrupt pin LINT1 (level). Per the 1988 UG §8.3 the
  // INTPEND.X1P bit REFLECTS the pin level (it is not a latch and cannot be
  // cleared by writing INTPEND) -- so it is OR-mirrored into the INTPEND view
  // (both the dedicated intpend_o tap and CPU reads of the register).
  input  wire logic                  lint1_in
);

  // I/O-space decode: two MSBs = 11 and bits[29:9] = 0 (range C0000000-
  // C00001FF). The register index is addr[8:4].
  logic [IO_REG_IDX_W-1:0] idx;
  assign is_io = (addr[ADDR_WIDTH-1:ADDR_WIDTH-2] == 2'b11)
              && (addr[ADDR_WIDTH-3:IO_REG_IDX_W+4] == '0);
  assign idx   = addr[IO_REG_IDX_W+3 : 4];

  // Register storage.
  logic [15:0] io_reg [0:IO_REG_COUNT-1];

  // ---------------------------------------------------------------------------
  // Display-interrupt source + live video counters (P0012 + P00xx).
  // The vendored `tms34010_video` block generates DPYINT_PULSE (a 1-clock strobe
  // at the start of the scan line == DPYINT) from the video-timing registers.
  // Wire it here where all the timing registers already live. It is clocked by
  // the io_regs clk and gated by ce_pix (the dot-clock enable) so DPYINT fires
  // ONCE PER FRAME at the DPYINT scan line -- matching real HW / MAME -- instead
  // of at the core clock (the fork-inherited bug: ~12x too fast, which derailed
  // NBA/UMK3 init before the RAM interrupt-dispatch table is built).
  // hcount/vcount are the LIVE counters and are returned on CPU reads of
  // HCOUNT/VCOUNT (see the rdata mux): NBA display_blank spins on VCOUNT
  // (BB.ASM #nxt: `move *VCOUNT,a0; jrz` waits for VCOUNT to leave 0) and hangs
  // forever if the read returns a dead/stored 0.
  // ---------------------------------------------------------------------------
  logic        dpyint_pulse;
  logic [15:0] vid_hcount, vid_vcount;
  logic        vid_hs_unused, vid_vs_unused, vid_hb_unused, vid_vb_unused, vid_bl_unused;

  tms34010_video u_video (
    .clk         (clk),
    .rst         (rst),
    .ce          (ce_pix),   // dot-clock enable: HCOUNT/dot, VCOUNT/line, DPYINT/frame
    .hesync      (io_reg[IO_IDX_HESYNC]),
    .heblnk      (io_reg[IO_IDX_HEBLNK]),
    .hsblnk      (io_reg[IO_IDX_HSBLNK]),
    .htotal      (io_reg[IO_IDX_HTOTAL]),
    .vesync      (io_reg[IO_IDX_VESYNC]),
    .veblnk      (io_reg[IO_IDX_VEBLNK]),
    .vsblnk      (io_reg[IO_IDX_VSBLNK]),
    .vtotal      (io_reg[IO_IDX_VTOTAL]),
    .dpyint      (io_reg[IO_IDX_DPYINT]),
    .hcount      (vid_hcount),
    .vcount      (vid_vcount),
    .hsync       (vid_hs_unused),
    .vsync       (vid_vs_unused),
    .hblank      (vid_hb_unused),
    .vblank      (vid_vb_unused),
    .blank       (vid_bl_unused),
    .dpyint_pulse(dpyint_pulse)
  );

  // Async read: the selected register, or 0 when the address is not in
  // I/O space (so a non-I/O read contributes nothing to a merged read bus).
  // P0016: CPU reads of INTPEND see the live LINT1 pin mirrored into X1P.
  // The `=== 1'b1` makes an UNCONNECTED pin (legacy TBs: 'z) read as not
  // asserted in sim; synthesis treats it as plain equality.
  logic lint1_lvl;
  assign lint1_lvl = (lint1_in === 1'b1);
  // HCOUNT/VCOUNT are READ-ONLY-ish counters on real silicon (1988 UG Fig 6-1;
  // memory_map.md marks them "read-only on silicon"): a CPU read returns the
  // LIVE horizontal/vertical counter, not the stored io_reg. NBA display_blank
  // spins on VCOUNT (BB.ASM #nxt) and MAME returns a live, sweeping VCOUNT; a
  // dead/stored 0 hangs the spin. Writes still fall through to io_reg[idx] (dead
  // storage for these two indices) -- harmless, and matches MAME, where the
  // stored write does not feed the computed read.
  //
  // SHARED-P0038 (read half): a sub-word read must return the ADDRESSED bits,
  // right-justified -- exactly what the external memory model does
  // (sim_memory_model.sv: `mem_rdata <= (win >> boff) & rmask`). Returning
  // io_reg[idx] unshifted made `MOVE @INTENB+DIP,Rd` with SETF 1,0,0 read bit 0
  // instead of bit 10. Fields that are NOT wholly contained in the addressed
  // 16-bit register keep the prior unshifted behaviour (no multi-register read
  // span is implemented; unused by the Z-unit title set).
  logic        field_contained;
  logic [15:0] selected_rdata;
  assign field_contained = size >= FIELD_SIZE_WIDTH'(1)
                        && size <= FIELD_SIZE_WIDTH'(16)
                        && ({2'b00, addr[3:0]} + size <= FIELD_SIZE_WIDTH'(16));
  always_comb begin
    selected_rdata = io_reg[idx];
    if (idx == IO_IDX_VCOUNT)
      selected_rdata = vid_vcount;
    else if (idx == IO_IDX_HCOUNT)
      selected_rdata = vid_hcount;
    else if (idx == IO_IDX_INTPEND)
      selected_rdata = io_reg[idx] | (16'(lint1_lvl) << INT_X1_BIT);
  end
  // MUT_IO_NO_FIELD reinstates the exact pre-P0038 behaviour (full-width
  // unmasked store, unshifted sub-word read) so the gate can prove the imported
  // TB actually KILLS the defect rather than merely passing the fixed RTL.
`ifdef MUT_IO_NO_FIELD
  assign rdata = !is_io ? 16'h0 : selected_rdata;
`else
  assign rdata = !is_io ? 16'h0
               : field_contained ? (selected_rdata >> addr[3:0])
               : selected_rdata;
`endif

  // ---------------------------------------------------------------------------
  // SHARED-P0038 (write half). I/O locations use bit-addressed FIELD semantics.
  // A field wholly within one 16-bit register uses the contained path: the
  // written bits land at `addr[3:0]` and everything else in the register is
  // PRESERVED. Midway display ISRs depend on this --
  //     DIRQ  SETF 1,0,0            ; field 0 = ONE bit
  //           MOVE Rs,@INTENB+DIP   ; -> @C000011Ah, i.e. bit 10 of INTENB
  // With the old full-width unmasked store, INTENB took the raw low 16 bits of
  // whatever register the game used: it could CLEAR DIE (T-unit's NBA Jam
  // never-starts bug -- got 0001, want 0400) or SPURIOUSLY ENABLE X1E/X2E/HIE/WVE
  // (T-unit measured Judge Dredd's `MOVE SP,@C0000111h` giving INTENB=0xFFF0).
  //
  // A field whose bits CROSS the 16-bit boundary (FS>16) writes io_reg[idx] (its
  // low bits) AND io_reg[idx+1] (its high bits). That single-boundary span is
  // what a register-aligned FS=32 CRTC block copy (SETF 20h; MOVE *B0+,*B2+ to
  // C0000000+) needs. A >2-register field (offset+size>32) is not implemented.
  //
  // Fields of size<=16 that are unaligned enough to cross the boundary keep their
  // exact prior behaviour (whole-register store), so no measured Z-unit access
  // changes: the MAME 0.280 `narc` census over 77M instructions saw 5,917 I/O
  // writes and 51,306 reads, ZERO narrow and ZERO non-word-aligned. This fix is
  // correctness-by-construction for the SHARED core, not a live-bug repair here.
  // ---------------------------------------------------------------------------
  logic        io_span;                 // field crosses idx -> idx+1
  logic [5:0]  io_lo_bits;              // field bits landing in io_reg[idx] (1..16)
  logic [15:0] io_write_mask, io_write_data;   // -> io_reg[idx]
  logic [15:0] io_hi_mask,    io_hi_data;      // -> io_reg[idx+1] (span only)
  always_comb begin
    io_lo_bits = 6'd16 - {2'b00, addr[3:0]};
`ifdef MUT_IO_NO_FIELD
    // pre-P0038: `io_reg[idx] <= wdata` -- full width, no mask, no bit offset.
    io_span       = 1'b0;
    io_write_mask = 16'hFFFF;
    io_write_data = wdata[15:0];
    io_hi_mask    = 16'h0;
    io_hi_data    = 16'h0;
`else
    io_span = is_io
            && (size > FIELD_SIZE_WIDTH'(16))
            && (({2'b00, addr[3:0]} + size) <= FIELD_SIZE_WIDTH'(32));
    // low register (io_reg[idx])
    io_write_mask = field_contained ? ((17'h1FFFF >> (17 - size)) << addr[3:0])
                  : io_span         ? (16'hFFFF << addr[3:0])
                  :                    16'hFFFF;
    io_write_data = (field_contained || io_span) ? 16'(wdata[15:0] << addr[3:0])
                                                 :  wdata[15:0];
    // high register (io_reg[idx+1]): the (size-io_lo_bits) field bits above the
    // boundary, right-justified at bit 0.
    io_hi_mask = io_span ? (16'hFFFF >> (6'd16 - (size - io_lo_bits))) : 16'h0;
    io_hi_data = io_span ? 16'(wdata >> io_lo_bits)                    : 16'h0;
`endif
  end

  // Dedicated graphics taps.
  assign psize_o   = io_reg[IO_IDX_PSIZE];
  assign convdp_o  = io_reg[IO_IDX_CONVDP];
  assign convsp_o  = io_reg[IO_IDX_CONVSP];
  assign control_o = io_reg[IO_IDX_CONTROL];
  assign dpystrt_o = io_reg[IO_IDX_DPYSTRT];  // P0024
  assign dpyctl_o  = io_reg[IO_IDX_DPYCTL];   // CORE-2: SRT gate lives in bit 11
  assign pmask_o   = io_reg[IO_IDX_PMASK];
  assign intenb_o  = io_reg[IO_IDX_INTENB];
  // P0016: X1P mirrors the LINT1 pin level into the pending view.
  assign intpend_o = io_reg[IO_IDX_INTPEND] | (16'(lint1_lvl) << INT_X1_BIT);
  assign hstctlh_o = io_reg[IO_IDX_HSTCTLH];

  // Synchronous write + reset. The reset loop is bounded (32 iterations) and
  // fully unrollable, so synthesis treats it as parallel resets.
  always_ff @(posedge clk) begin
    if (rst) begin
      for (int i = 0; i < IO_REG_COUNT; i++) begin
        io_reg[i] <= 16'h0;
      end
    end else begin
      if (req && we && is_io) begin
        // INTPEND is NOT an ordinary register: X1P/X2P/HIP are read-only and WV/DI
        // are write-zero-to-clear (gospel tms34010.cpp:1348-1356). An unmasked store
        // let the standard handler idiom -- read INTPEND (which correctly ORs in the
        // live LINT1 pin at :150-151), clear one bit, write back -- LATCH a stuck X1P
        // that never tracks the pin again, asserting INT1 forever via :164.
        //
        // SHARED-P0038 note on the INTPEND arm: the write-zero-to-clear mask is
        // INTERSECTED with io_write_mask, so bits OUTSIDE the written field are
        // untouchable. This is a DELIBERATE DIVERGENCE from gospel: MAME's
        // io_register_w (tms34010.cpp:1247-1256) takes mem_mask but then does a
        // full-word `IOREG(offset) = data` and tests raw `data`, so on a genuine
        // sub-word write whose field EXCLUDES WV/DI it would read 0 in those
        // positions and SPURIOUSLY CLEAR them. Matches the Wolf/Y-unit forks.
        // For FS=16 at offset 0 the intersection is a no-op and this reduces
        // EXACTLY to the previous `intpend_apply_cpu_write(io_reg[idx], wdata)`.
        if (idx == IO_IDX_INTPEND) begin
`ifdef MUT_IO_INTPEND_WHOLE_WRITE
          io_reg[idx] <= (io_reg[idx] & ~io_write_mask)     // the pre-fix defect
                       | (io_write_data & io_write_mask);   // (unmasked store), for the gate
`else
          io_reg[IO_IDX_INTPEND] <=
              io_reg[IO_IDX_INTPEND]
              & (io_write_data | ~(INTPEND_W0C_MASK & io_write_mask));
`endif
        end else begin
          io_reg[idx] <= (io_reg[idx] & ~io_write_mask)
                       | (io_write_data & io_write_mask);
        end
        // Cross-boundary span: also land the high bits in the next register.
        // Guard idx+1 in range (idx==31 has no successor; never a CRTC target).
        if (io_span && (idx != IO_REG_IDX_W'(IO_REG_COUNT-1))) begin
          // SHARED-P0016 SPAN HOLE (found by the Y-unit session): the direct
          // write above honours INTPEND's read-only / write-zero-to-clear mask,
          // but an unmasked span would let a 32-bit field write at INTENB
          // (idx 0x11) land its high half on INTPEND (idx 0x12) and SET the
          // read-only X1P/X2P/HIP bits -- the exact defect the mask exists to
          // prevent, reached by the other door. Same mask when the span TARGET
          // is INTPEND.
          if ((idx + IO_REG_IDX_W'(1)) == IO_IDX_INTPEND) begin
            io_reg[IO_IDX_INTPEND] <=
                io_reg[IO_IDX_INTPEND]
                & (io_hi_data | ~(INTPEND_W0C_MASK & io_hi_mask));
          end else begin
            io_reg[idx + IO_REG_IDX_W'(1)] <=
                (io_reg[idx + IO_REG_IDX_W'(1)] & ~io_hi_mask)
              | (io_hi_data & io_hi_mask);
          end
        end
      end else if (nmi_clear) begin
        // The device automatically clears HSTCTLH.NMI when it takes the NMI
        // (1988 UG §8). A normal I/O write takes precedence (the else-if order):
        // simultaneous host write + take is a don't-care corner.
        io_reg[IO_IDX_HSTCTLH][HSTCTL_NMI_BIT] <= 1'b0;
      end else if (wvp_set) begin
        // The graphics engine sets INTPEND.WV on a window violation (1988 UG
        // §7.10). Like nmi_clear, this is a device-internal set, lower priority
        // than a host/program I/O write.
        io_reg[IO_IDX_INTPEND][INT_WV_BIT] <= 1'b1;
      end
      // Display interrupt (P0012): set INTPEND.DI at the DPYINT scan line.
      // Independent of the else-if chain above so a coincident I/O write to a
      // DIFFERENT register cannot drop the frame's DI. A same-cycle write to
      // INTPEND itself: this bit-select assign wins for bit DI (set-dominant),
      // matching the device-sets / software-clears model (the handler clears DI
      // by writing INTPEND). dpyint_pulse is a ce-gated one-clock strobe (once
      // per frame), so it never fights RETI.
      // Gate on a programmed raster (VTOTAL != 0) so the reset state (all timing
      // regs 0 -> pulse whenever ce fires) doesn't spam INTPEND.DI before the
      // game sets up video. Harmless while IE=0, but keep it clean.
      if (dpyint_pulse && io_reg[IO_IDX_VTOTAL] != 16'h0) begin
        io_reg[IO_IDX_INTPEND][INT_DI_BIT] <= 1'b1;
      end
    end
  end

endmodule : tms34010_io_regs

`default_nettype wire
