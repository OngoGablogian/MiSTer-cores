// NARC-local copy of the stock MiSTer SDRAM controller behavior shipped and
// cabinet-proven by Arcade-UMK3. Program/GFX retain that exact mapping and
// direct-CAS capture. NARC VRAM alone is placed in otherwise-unused bank 1 with
// a 512-word page-friendly row layout; the brd_* port can therefore fetch one
// scanline with one ACTIVATE. Keep this isolated from the later WIP Smash TV
// whole-memory row-map/read-register experiment in sdram_stock.sv.
//
// Original: Copyright (c) 2015-2019 Sorgelig. GNU GPLv3.
// Program/GFX single-beat behavior remains upstream-equivalent. NARC-local
// additions are the isolated VRAM bank mapping and bounded scanline burst.
`default_nettype none
module sdram_stock_shipped #(
   parameter [24:0] VRAM_BBASE = 25'h0440000,
   parameter [24:0] VRAM_BYTES = 25'h0080000,
   parameter [24:0] GFX_BBASE  = 25'h0000000,
   parameter [24:0] GFX_BYTES  = 25'h0000000
)
(
   input             init,
   input             clk,
   inout      [15:0] SDRAM_DQ,
   output reg [12:0] SDRAM_A,
   output reg        SDRAM_DQML,
   output reg        SDRAM_DQMH,
   output reg  [1:0] SDRAM_BA,
   output            SDRAM_nCS,
   output            SDRAM_nWE,
   output            SDRAM_nRAS,
   output            SDRAM_nCAS,
   output            SDRAM_CKE,
   input       [1:0] wtbt,
   input      [24:0] addr,
   output     [15:0] dout,
   input      [15:0] din,
   input             we,
   input             rd,
   output reg        ready,

   // NARC scanout burst. brd_addr is a BYTE address within the VRAM region,
   // brd_len is 1..512 words and must not cross a 512-word scanline boundary.
   input             brd_req,
   input      [24:0] brd_addr,
   input      [9:0]  brd_len,
   output     [15:0] brd_dout,
   output reg        brd_dvalid,
   output reg        brd_done
);

localparam BURST_LENGTH         = 3'b000;
localparam ACCESS_TYPE          = 1'b0;
localparam CAS_LATENCY          = 3'd2;
localparam OP_MODE              = 2'b00;
localparam NO_WRITE_BURST       = 1'b1;
localparam MODE                 = {3'b000, NO_WRITE_BURST, OP_MODE, CAS_LATENCY, ACCESS_TYPE, BURST_LENGTH};
localparam sdram_startup_cycles = 14'd12100;
localparam cycles_per_refresh   = 14'd780;
localparam startup_refresh_max  = 14'b11111111111111;

localparam [2:0] CMD_NOP          = 3'b111;
localparam [2:0] CMD_ACTIVE       = 3'b011;
localparam [2:0] CMD_READ         = 3'b101;
localparam [2:0] CMD_WRITE        = 3'b100;
localparam [2:0] CMD_PRECHARGE    = 3'b010;
localparam [2:0] CMD_AUTO_REFRESH = 3'b001;
localparam [2:0] CMD_LOAD_MODE    = 3'b000;

typedef enum {
  STATE_STARTUP,
  STATE_OPEN_1, STATE_OPEN_2,
  STATE_IDLE, STATE_IDLE_1, STATE_IDLE_2, STATE_IDLE_3,
  STATE_IDLE_4, STATE_IDLE_5, STATE_IDLE_6, STATE_IDLE_7,
  STATE_BR_ACT, STATE_BR_RD, STATE_BR_DRAIN, STATE_BR_PRE
} state_t;

reg  [2:0]  command;
reg  [13:0] refresh_count = startup_refresh_max - sdram_startup_cycles;
reg  [24:0] save_addr;
reg  [15:0] data;
reg         old_we, old_rd;
reg  [CAS_LATENCY:0] data_ready_delay;
reg  [15:0] new_data;
reg  [1:0]  new_wtbt;
reg         new_we;
reg         new_rd;
reg         save_we = 1'b1;
state_t     state = STATE_STARTUP;
reg  [15:0] sb_data;      // single-beat holding snapshot (fabric; see `dout` note)
reg         sb_cap;       // one-shot: `data` was just captured -> copy it in fabric next clk
reg  [15:0] sdram_dq_out;
reg         sdram_dq_oe;
// NARC-only page burst. In the SDR framebuffer build it reads the dedicated
// bank-1 VRAM rows. In the DDR3 framebuffer build that bank is free, so the
// GFX region is placed there in a page-friendly layout and the same burst port
// feeds the blitter source cache. Program and sound ROM remain on the shipped
// bank-0 map and retain the cabinet-proven direct-CAS capture path.
reg         old_brd, new_brd;
reg  [12:0] brd_row;
reg  [1:0]  brd_bank;
reg  [8:0]  brd_col;
reg  [9:0]  brd_i, brd_len_l;
reg  [CAS_LATENCY:0] brd_vdelay;
wire        brd_issue = (state == STATE_BR_RD) && (brd_i < brd_len_l);
wire [24:0] save_vram_rel = save_addr - VRAM_BBASE;
wire        save_is_vram = (save_addr >= VRAM_BBASE) &&
                           (save_addr < (VRAM_BBASE + VRAM_BYTES));
wire [24:0] brd_vram_rel = brd_addr - VRAM_BBASE;
wire        save_is_gfx = (GFX_BYTES != 0) &&
                          (save_addr >= GFX_BBASE) &&
                          (save_addr < (GFX_BBASE + GFX_BYTES));
wire [24:0] save_gfx_rel = save_addr - GFX_BBASE;
wire [24:0] brd_gfx_rel  = brd_addr - GFX_BBASE;

assign SDRAM_DQ   = sdram_dq_oe ? sdram_dq_out : 16'bZ;
assign SDRAM_CKE  = 1'b1;
assign SDRAM_nCS  = 1'b0;
assign SDRAM_nRAS = command[2];
assign SDRAM_nCAS = command[1];
assign SDRAM_nWE  = command[0];
// P0044: DQM HAS ITS OWN REGISTER. It used to be aliased onto SDRAM_A[12:11]:
//   assign {SDRAM_DQMH,SDRAM_DQML} = SDRAM_A[12:11];
// which is only correct because A[12:11] happen to be zero on the cycle a READ is issued.
// SDRAM_A carries the ROW during ACTIVATE and the whole tRCD gap, and the shipped map's row
// is word[12:0] -- so for every address whose word[12:11] are set, the part sees DQM ASSERTED
// on the two cycles before each READ. DQM read latency is two clocks, so nominally that masks
// the cycles just before the data beat and the design survives on exactly ONE cycle of margin.
// Lose that one cycle to clock phase, skew, or a capture-epoch error and the part answers the
// read with Hi-Z, which the FPGA's weak pull-ups read back as FFFF -- address-dependent, on
// exactly the words whose row bits are set, and invisible to any model that ignores DQM.
// The sound master reset-vector word 0x2A7FFF has row = 0x1FFF, i.e. BOTH bits set.
// A[12:11] are don't-care to the part during READ/WRITE (column is A[8:0], A10 is
// auto-precharge), so nothing needs them. Driving DQM from a dedicated register that is 0
// except in the write beat removes the coupling entirely.
// Gate: sim/tb_narc_snd_maxrate_land.sv (nominal + the one-cycle DQM skew corner).
reg [1:0] dqm_r = 2'b00;
assign {SDRAM_DQMH,SDRAM_DQML} = dqm_r;
// Single-beat results are presented from sb_data, a HOLDING register snapshotted at
// capture time -- NOT from the shared `data` capture register.
//
// WHY (measured, tb_narc_scanline_phasesweep): `data` is written by BOTH the single-beat
// capture and every burst beat (brd_vdelay[0]). A single-beat read whose result had landed
// in `data` but had not yet been consumed by the adapter would have `ready` forced low by
// the burst start (STATE_IDLE), sit out the whole 512-beat burst, then see `ready` return
// at STATE_BR_PRE and sample `data` -- which by then held the burst's LAST VRAM word. That
// is the cabinet-rejected scanline-v1 class ("the burst overwrites the shared DQ-capture
// register and returns its last VRAM word to the CPU"); the v2 ready-serialization fixed
// the command ordering but NOT this register reuse. The phase sweep reproduces it
// deterministically at burst offsets 2..7 (got=03ff/05ff/07ff... = {row,col=511}).
//
// This does NOT add a second DQ capture bank -- the IOE concern that motivated sharing
// `data` in the first place. sb_data copies the ALREADY-CAPTURED `data` value in fabric,
// so exactly one register still samples SDRAM_DQ and the cabinet-proven program-ROM
// capture path is untouched. brd_dout keeps reading `data` directly.
//
// IOE DISCIPLINE (why the copy is one clock LATE, not same-cycle): the first attempt at
// this fix (7d909ca) wrote `sb_data <= SDRAM_DQ` in the same cycle as `data`. That is
// logically identical but PHYSICALLY REJECTED -- two registers sampling the same pin
// cannot both live in that pin's sole IOE input register, the fitter pushed one into
// fabric, and DQ setup went to -3.759 ns. Here sb_data's D input is `data` (fabric), so
// SDRAM_DQ still fans out to exactly one register. `ready` is asserted in the SAME cycle
// as the sb_data copy (one clock later than the raw capture), because the adapter samples
// dout on the first cycle of ready (yunit_sdram_adapter.sv A_WAIT). Timing is unchanged
// relative to the burst: with the single-beat capture landing during the STATE_IDLE_5..1
// countdown, ready is still visible before STATE_IDLE, so a burst cannot pre-empt it.
assign dout = save_addr[0] ? {sb_data[7:0], sb_data[15:8]} : sb_data;
// Reuse the exact cabinet-proven DQ capture bank for burst data. Creating a
// second 16-bit DQ register bank would compete for each pin's sole IOE input
// register and could displace the already-closed program-ROM capture path.
assign brd_dout = data;

always @(posedge clk) begin
  sdram_dq_oe <= 1'b0;
  // P0044: DQM idles LOW and is raised for exactly the masked write beat (below). A read is
  // therefore never preceded by an asserted mask, whatever the row bits happen to be.
  dqm_r  <= 2'b00;
  command <= CMD_NOP;
  refresh_count <= refresh_count + 1'b1;

  data_ready_delay <= {1'b0, data_ready_delay[CAS_LATENCY:1]};
  sb_cap <= 1'b0;
  if(data_ready_delay[0]) begin data <= SDRAM_DQ; sb_cap <= 1'b1; end
  // Fabric copy, one clock after capture. Reads the PRE-write value of `data` if a burst
  // beat happens to write `data` in this same cycle (nonblocking), so the single-beat
  // result cannot be clobbered.
  if(sb_cap) begin sb_data <= data; ready <= 1'b1; end

  // Stream capture uses the same direct-CAS DQ sampling epoch as the
  // cabinet-proven single-beat read above, extended to one valid per READ.
  brd_dvalid <= 1'b0;
  brd_done   <= 1'b0;
  brd_vdelay <= {brd_issue, brd_vdelay[CAS_LATENCY:1]};
  if(brd_vdelay[0]) begin
    brd_dvalid <= 1'b1;
    data       <= SDRAM_DQ;
  end

  case(state)
    STATE_STARTUP: begin
      SDRAM_A  <= 0;
      SDRAM_BA <= 0;
      if(refresh_count == startup_refresh_max-31) begin
        command <= CMD_PRECHARGE; SDRAM_A[10] <= 1'b1; SDRAM_BA <= 2'b00;
      end
      if(refresh_count == startup_refresh_max-23) command <= CMD_AUTO_REFRESH;
      if(refresh_count == startup_refresh_max-15) command <= CMD_AUTO_REFRESH;
      if(refresh_count == startup_refresh_max-7) begin
        command <= CMD_LOAD_MODE; SDRAM_A <= MODE;
      end
      if(!refresh_count) begin
        state <= STATE_IDLE; ready <= 1'b1; refresh_count <= 0;
      end
    end
    STATE_IDLE_7: state <= STATE_IDLE_6;
    STATE_IDLE_6: state <= STATE_IDLE_5;
    STATE_IDLE_5: state <= STATE_IDLE_4;
    STATE_IDLE_4: state <= STATE_IDLE_3;
    STATE_IDLE_3: state <= STATE_IDLE_2;
    STATE_IDLE_2: state <= STATE_IDLE_1;
    STATE_IDLE_1: begin
      state <= STATE_IDLE;
      if(refresh_count > cycles_per_refresh) begin
        state <= STATE_IDLE_7; command <= CMD_AUTO_REFRESH; refresh_count <= 0;
      end
    end
    STATE_IDLE: begin
      // ============================ LOAD-BEARING -- DO NOT GATE ON TRAFFIC ====================
      // This unconditional test is what keeps NARC out of a whole failure class. Refresh here is
      // a PEER of traffic, not a side effect of it: refresh_count increments every clock (:157)
      // with no we/rd term, and this branch sits ABOVE the (new_brd) and (new_rd|new_we) arms
      // below, so refresh always wins and fires with ZERO bus activity.
      //
      // WHY IT MATTERS HERE SPECIFICALLY. Our ioctl loader leaves large spans driving neither we
      // nor rd: zunit_download.sv:78 (gfx_pop discards each GFX quadrant's zero tail) and
      // :103/:109 (PLA tail unrouted) produce FOUR contiguous 1,114,112-byte dead ranges at
      // stream [0x170000,0x280000), [0x370000,0x480000), [0x570000,0x680000), [0x770000,0x880000)
      // plus [0x9A0000,0x9A0500) -- 4.25 MB of a 9.63 MB download during which the SDRAM sees no
      // command at all, while already-staged program ROM sits in DRAM against a ~64 ms retention
      // budget. The largest single gap is 66-530 ms depending on the hps_io byte rate.
      // So: the exposure window IS present in this tree. It is harmless ONLY because refresh does
      // not depend on the window being closed. Re-gate this line on (new_rd|new_we) -- the shape
      // a traffic-coupled PHY naturally has -- and NARC acquires a silent ROM-corruption bug that
      // presents as a boot hang. The Sega Model 1 session shipped exactly that defect and traced
      // it (their PHY advanced its refresh FSM only inside a command pass).
      //
      // MEASURED + MUTATION-PROVEN (doctrine 5): with we=rd=brd_req tied off forever, this DUT
      // issues 128 AUTO_REFRESH in 200,000 idle clocks, max gap 1563. Re-gating this line on
      // (new_rd|new_we) drops that to ZERO -- the check discriminates the exact property.
      //
      // (Separate, NOT a claim: that 1563-clock idle interval is ~2.08x the MT48LC16M16 nominal
      // tREFI of 750 clocks at 96 MHz, and cycles_per_refresh=780 (:56) is sized for 100 MHz.
      // This is inherited stock MiSTer behaviour, identical in sdram_stock.sv:67/165 and shipped
      // in many cab-proven cores including this one. Recorded, not changed, no evidence of harm.)
      // =======================================================================================
      if(refresh_count > (cycles_per_refresh<<1)) state <= STATE_IDLE_1;
      // Do not begin a 512-cycle page read with refresh already due. The
      // burst itself is shorter than one 780-clock refresh interval.
      else if(new_brd && refresh_count > cycles_per_refresh) begin
        state <= STATE_IDLE_7; command <= CMD_AUTO_REFRESH; refresh_count <= 0;
      end
      else if(new_brd) begin
        // The normal-port ready level must be low for the physical burst.
        // This prevents a newly arriving adapter request from mistaking the
        // changing shared data register for a completed single-beat result.
        // A read that completed before this state was entered has already had
        // several clocks of visible ready and is acknowledged normally.
        ready <= 1'b0; new_brd <= 1'b0; brd_i <= 10'd0;
        state <= STATE_BR_ACT; command <= CMD_ACTIVE;
        SDRAM_A <= brd_row; SDRAM_BA <= brd_bank;
      end
      else if(new_rd | new_we) begin
        new_we <= 1'b0; new_rd <= 1'b0; save_we <= new_we;
        state <= STATE_OPEN_1; command <= CMD_ACTIVE;
`ifdef USE_DDR3_VRAM
        // VRAM is off-chip DDR3 in this build. Put only NARC's GFX image in the
        // now-free SDRAM bank 1 with col=word[8:0], so sequential sprite bytes
        // share an open row. The CPU GFX window and boot downloader use this
        // same mapping; program/sound accesses take the unchanged branch below.
        if(save_is_gfx) begin
          SDRAM_A <= {4'd0,save_gfx_rel[22:10]};
          SDRAM_BA <= 2'b01;
        end else begin
          SDRAM_A <= save_addr[13:1];
          SDRAM_BA <= save_addr[24:23];
        end
`else
        if(save_is_vram) begin
          SDRAM_A <= {4'd0,save_vram_rel[18:10]};
          SDRAM_BA <= 2'b01;
        end else begin
          SDRAM_A <= save_addr[13:1]; SDRAM_BA <= save_addr[24:23];
        end
`endif
      end
    end
    STATE_OPEN_1: state <= STATE_OPEN_2;
    STATE_OPEN_2: begin
`ifdef USE_DDR3_VRAM
      if(save_is_gfx)
        SDRAM_A <= {save_we & (new_wtbt ? ~new_wtbt[1] : ~save_addr[0]),
                    save_we & (new_wtbt ? ~new_wtbt[0] :  save_addr[0]),
                    2'b10, save_gfx_rel[9:1]};
      else
`endif
      SDRAM_A <= {save_we & (new_wtbt ? ~new_wtbt[1] : ~save_addr[0]),
                  save_we & (new_wtbt ? ~new_wtbt[0] :  save_addr[0]),
                  2'b10, save_is_vram ? save_vram_rel[9:1] : save_addr[22:14]};
      if(save_we) begin
        command <= CMD_WRITE;
        // Same mask the A[12:11] alias used to carry, now on the dedicated pins. DQM write
        // latency is zero, so it is driven in the same cycle as the command and the data.
        dqm_r <= {new_wtbt ? ~new_wtbt[1] : ~save_addr[0],
                  new_wtbt ? ~new_wtbt[0] :  save_addr[0]};
        sdram_dq_out <= new_wtbt ? new_data : {new_data[7:0], new_data[7:0]};
        sdram_dq_oe <= 1'b1;
        ready <= 1'b1; state <= STATE_IDLE_2;
      end else begin
        command <= CMD_READ;
        data_ready_delay[CAS_LATENCY] <= 1'b1;
        state <= STATE_IDLE_5;
      end
    end
    // One open bank-1 row is one complete 512-word NARC VRAM scanline.
    // READ commands are issued back-to-back with A10=0 (no auto-precharge),
    // then the row is explicitly precharged after the final CAS result.
    STATE_BR_ACT: state <= STATE_BR_RD;
    STATE_BR_RD: begin
      if(brd_i < brd_len_l) begin
        command <= CMD_READ;
        SDRAM_A <= {4'b0000,brd_col};
        brd_col <= brd_col + 9'd1;
        brd_i   <= brd_i + 10'd1;
      end else state <= STATE_BR_DRAIN;
    end
    STATE_BR_DRAIN: if(brd_vdelay == 0) begin
      command <= CMD_PRECHARGE; SDRAM_A[10] <= 1'b1; SDRAM_BA <= brd_bank;
      state <= STATE_BR_PRE;
    end
    STATE_BR_PRE: begin
      brd_done <= 1'b1; state <= STATE_IDLE;
      // If the adapter queued one normal command just before the burst took
      // ownership, keep ready low until that command is physically serviced.
      // Otherwise reopen the normal port after the burst/precharge completes.
      if(!(new_rd | new_we)) ready <= 1'b1;
    end
    default: state <= STATE_IDLE;
  endcase

  if(init) begin
    state <= STATE_STARTUP;
    refresh_count <= startup_refresh_max - sdram_startup_cycles;
    new_brd <= 1'b0; brd_vdelay <= 0;
  end

  old_we <= we;
  if(we & ~old_we) begin
    save_addr <= addr;
    {ready, new_we, new_data, new_wtbt} <= {1'b0, 1'b1, din, wtbt};
  end

  old_rd <= rd;
  if(rd & ~old_rd) begin
    save_addr <= addr;
    if(!(ready & ~save_we & (save_addr[24:1] == addr[24:1])))
      {ready, new_rd} <= {1'b0, 1'b1};
  end

  old_brd <= brd_req;
  if(brd_req & ~old_brd) begin
`ifdef USE_DDR3_VRAM
    // Source-cache burst: the DDR3 build's bank-1 GFX layout is contiguous
    // across the SDRAM column field.
    brd_row   <= {4'd0,brd_gfx_rel[22:10]};
    brd_bank  <= 2'b01;
    brd_col   <= brd_gfx_rel[9:1];
`else
    brd_row   <= {4'd0,brd_vram_rel[18:10]};
    brd_bank  <= 2'b01;
    brd_col   <= brd_vram_rel[9:1];
`endif
    brd_len_l <= brd_len;
    new_brd   <= 1'b1;
  end
end

endmodule
`default_nettype wire
