// hc55564_stub.v — iverilog-ONLY blackbox stub for the VHDL CVSD decoder
// (rtl/sound/williams_cvsd/hc55564.vhd). iverilog cannot parse VHDL, so this
// port-matched empty shell lets the SystemVerilog elaboration gate close.
// The REAL hc55564 (VHDL) is used for Questa/Quartus elaboration — this stub
// is NEVER added to files.qip or any Questa run.
`default_nettype none
module hc55564 (
    input  wire        clk,
    input  wire        cen,
    input  wire        rst,
    input  wire        bit_in,
    output wire [15:0] sample_out
);
    assign sample_out = 16'h0000; // blackbox: no behavior in the elab gate
endmodule
`default_nettype wire
