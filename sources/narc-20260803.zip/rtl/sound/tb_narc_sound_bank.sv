`timescale 1ns/1ps
`default_nettype none
// Dual-transcription matrix TB: drives narc_sound_bank (DUT) against the
// independent Python golden vectors. Byte-exact or FAIL. Covers all 16 banks
// x {window base, mid, top, upper, extra-upper, top-upper} for master+slave
// (master==slave by gospel: same offset equation, different physical region).
module tb_narc_sound_bank;
    reg  [3:0]  bank;
    reg  [15:0] cpu_addr;
    wire [19:0] rom_offset;
    wire        rom_sel, upper_sel;

    narc_sound_bank dut(.bank(bank), .cpu_addr(cpu_addr),
                        .rom_offset(rom_offset), .rom_sel(rom_sel), .upper_sel(upper_sel));

    integer fd, r, errors, checks;
    reg [31:0] g_bank, g_addr, g_off, g_rsel, g_usel;
    integer which; // 0=master 1=slave (identical expectation)

    initial begin : main
        errors = 0; checks = 0;
        for (which = 0; which < 2; which = which + 1) begin
            fd = $fopen("vectors.txt", "r");
            if (fd == 0) begin $display("FAIL: cannot open vectors.txt"); $finish; end
            while (!$feof(fd)) begin
                r = $fscanf(fd, "%h %h %h %d %d\n", g_bank, g_addr, g_off, g_rsel, g_usel);
                if (r == 5) begin
                    bank = g_bank[3:0]; cpu_addr = g_addr[15:0]; #1;
                    checks = checks + 1;
                    if (rom_sel !== g_rsel[0] || upper_sel !== g_usel[0] ||
                        (g_rsel[0] && (rom_offset !== g_off[19:0]))) begin
                        errors = errors + 1;
                        if (errors <= 12)
                          $display("MISMATCH [%s] bank=%1x addr=%04x | off dut=%05x exp=%05x | rsel %b/%b usel %b/%b",
                                   which?"slave":"master", bank, cpu_addr,
                                   rom_offset, g_off[19:0], rom_sel, g_rsel[0], upper_sel, g_usel[0]);
                    end
                end
            end
            $fclose(fd);
        end
        $display("checks=%0d errors=%0d", checks, errors);
        if (errors == 0) $display("RESULT: PASS");
        else             $display("RESULT: FAIL");
        $finish;
    end
endmodule
`default_nettype wire
