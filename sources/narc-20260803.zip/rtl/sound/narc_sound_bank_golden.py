#!/usr/bin/env python
# Independent blind golden for the NARC sound ROM bank decoder.
# Transcribed directly from williamssound.cpp:539-561 -- NOT from any RTL/pkg.
#
#   offset = 0x8000*(bank&1) + 0x10000*((bank>>3)&1) + 0x20000*((bank>>1)&3)
#   banked window 0x4000-0xbfff -> rom[0x10000 + offset + (addr-0x4000)]
#   fixed upper   0xc000-0xffff -> rom[0x10000+0x4000+0x8000+0x10000+0x20000*3
#                                       + (addr-0xc000)]
import sys

UPPER_BASE = 0x10000 + 0x4000 + 0x8000 + 0x10000 + 0x20000 * 3  # 0x8C000

def golden(bank, addr):
    off = 0x8000 * (bank & 1) + 0x10000 * ((bank >> 3) & 1) + 0x20000 * ((bank >> 1) & 3)
    if 0x4000 <= addr <= 0xbfff:
        return (0x10000 + off + (addr - 0x4000), 1, 0)
    if addr >= 0xc000:
        return (UPPER_BASE + (addr - 0xc000), 1, 1)
    return (0, 0, 0)  # not ROM

# address classes per acceptance: window base, mid, top, upper-fixed (+extra)
ADDRS = [0x4000, 0x8000, 0xbfff, 0xc000, 0xe000, 0xffff]

def main():
    with open(sys.argv[1], "w") as f:
        for bank in range(16):
            for addr in ADDRS:
                offv, rsel, usel = golden(bank, addr)
                f.write(f"{bank:x} {addr:04x} {offv:05x} {rsel} {usel}\n")

if __name__ == "__main__":
    main()
