# SDRAM I/O timing (MT48LC16M16, ~96 MHz). The PLL hierarchy emu|pll|pll_inst|
# altera_pll_i matches this core (emu instantiates `pll pll`); general[1] = outclk_1
# = clk_sdram (the phase-shifted pin clock), general[0] = outclk_0 = clk_sys.
create_generated_clock -name SDRAM_CLK \
  -source [get_pins -compatibility_mode {emu|pll|pll_inst|altera_pll_i|general[1].gpll~PLL_OUTPUT_COUNTER|divclk}] \
  [get_ports {SDRAM_CLK}]

# data access delay (tAC): MT48LC16M16 CAS2 tAC = 6.0 ns (matches jtframe's proven
# MiSTer/MiST SDRAM constraint; Tecmo's extra +0.5 was over-conservative).
set_input_delay -clock SDRAM_CLK -max 6.0 [get_ports {SDRAM_DQ[*]}]

# data output hold time (tOH)
set_input_delay -clock SDRAM_CLK -min 2.5 [get_ports {SDRAM_DQ[*]}]

# data input setup time (tIS)
set_output_delay -clock SDRAM_CLK -max 1.5 [get_ports {SDRAM_A* SDRAM_BA* SDRAM_D* SDRAM_CKE SDRAM_n*}]

# data input hold time (tIH)
set_output_delay -clock SDRAM_CLK -min -0.8 [get_ports {SDRAM_A* SDRAM_BA* SDRAM_D* SDRAM_CKE SDRAM_n*}]

# use proper edges for the timing calculations
set_multicycle_path -setup -end \
  -rise_from [get_clocks {SDRAM_CLK}] \
  -rise_to [get_clocks {emu|pll|pll_inst|altera_pll_i|general[0].gpll~PLL_OUTPUT_COUNTER|divclk}] 2

# Clock domains (PLL outputs): general[0]=clk_sys 96, [1]=clk_sdram 96, [2]=clk_snd 12,
# [3]=clk_cpu 24 (LEGACY, UNUSED since P0019). *** The CPU no longer runs on general[3]. ***
# ROOT CAUSE of the black screen: the old design ran the CPU on a separate clk_cpu (general[3])
# and declared it ASYNCHRONOUS, so STA never timed the CPU<->memsys crossing (yunit_mem_cdc);
# the fitter routed those paths freely and they failed on real silicon while passing zero-delay
# sim. FIX (P0019): run the CPU on clk_sys (general[0]) gated by a 1-in-4 clock-enable (cpu_ce),
# so the whole CPU<->memsys interface is a SINGLE-CLOCK path STA times natively -- no async CDC.
# general[3] now clocks nothing; keeping it in a group is vacuous but harmless. clk_snd
# (general[2], 12 MHz) keeps its own domain (its sound-latch CDC is separate).
set_clock_groups -asynchronous \
  -group [get_clocks [list \
     {emu|pll|pll_inst|altera_pll_i|general[0].gpll~PLL_OUTPUT_COUNTER|divclk} \
     {emu|pll|pll_inst|altera_pll_i|general[1].gpll~PLL_OUTPUT_COUNTER|divclk} \
     {emu|pll|pll_inst|altera_pll_i|general[3].gpll~PLL_OUTPUT_COUNTER|divclk} ]] \
  -group [get_clocks {emu|pll|pll_inst|altera_pll_i|general[2].gpll~PLL_OUTPUT_COUNTER|divclk}]

# ---- CPU clock-enable multicycle (P0019) ------------------------------------------------
# Every CPU-domain flop is gated by cpu_ce (pulses 1-in-4 clk_sys), so a value launched from a
# CPU flop is captured by another CPU flop only on the next cpu_ce edge = 4 clk_sys later.
# The cpu_ce domain spans THREE instances, all enumerated below (validated live against the
# fitted netlist with quartus/ce_check.tcl -> 5287 registers, worst CPU slack -12.5 -> pass):
#   1. the whole core + submodules  = *tms34010_core:u_core|*   (pc/regfile/divider/status_reg
#      are children of u_core, so this one pattern covers them)
#   2. the yunit_mem_cdc CPU-side FSM (NOT the sys-side, which runs full-rate every clk)
#   3. the legacy derail block in yunit_top plus zunit_top's first-fetch observer. The
#      latter captures cpu_addr/cpu_rdata only inside `if (cpu_ce !== 1'b0)`, so its
#      long combinational inputs come straight off the core but have the same four-cycle
#      launch/capture contract. Keep the current zunit_top patterns explicit: omitting
#      them creates a false one-cycle instr_word_q -> dbg_ff_* path (~-13 ns).
# NOTE: use ONE-LINE get_registers (space-separated patterns). A backslash-continuation INSIDE
# the {} braces is a Tcl trap -- it mangles the pattern list so nothing matches (that was the
# first-build -12.5ns miss). Entity:instance names are the post-sv2v Quartus form; a wrong
# pattern matches nothing and fails LOUDLY as a setup violation.
set cpu_regs [get_registers {*tms34010_core:u_core|* *u_memcdc|cst* *u_memcdc|req_tgl* *u_memcdc|c_ack* *u_memcdc|c_rdata* *u_memcdc|ackt_sync* *u_memcdc|p_we* *u_memcdc|p_srt* *u_memcdc|p_addr* *u_memcdc|p_size* *u_memcdc|p_wdata* *yunit_top:yunit_top|rd_cnt* *yunit_top:yunit_top|ack_q* *yunit_top:yunit_top|d_started* *yunit_top:yunit_top|d_prevpc* *yunit_top:yunit_top|dbg_derailed* *yunit_top:yunit_top|dbg_culprit_pc* *yunit_top:yunit_top|dbg_culprit_instr* *yunit_top:yunit_top|dbg_derail_pc* *zunit_top:zunit_top|dbg_ff_addr* *zunit_top:zunit_top|dbg_ff_data* *zunit_top:zunit_top|dbg_ff_valid*}]
set_multicycle_path -setup 4 -from $cpu_regs -to $cpu_regs
set_multicycle_path -hold  3 -from $cpu_regs -to $cpu_regs
# int1 (DMA-done LINT1 = u_dma|blit_irq): a HELD interrupt level from the full-rate memsys domain
# into the CPU (I wired it straight in, replacing the old clk_cpu synchronizer). It is stable >> 4
# clk_sys between service events, so relax the crossing INTO the cpu_ce domain.
set_multicycle_path -setup 4 -from [get_registers {*u_dma|blit_irq*}] -to $cpu_regs
set_multicycle_path -hold  3 -from [get_registers {*u_dma|blit_irq*}] -to $cpu_regs
# DIAG_BOOT overlay: a slow diagnostic display whose pixel datapath is ce_pix-gated (1-in-12) and
# whose inputs are stable/slow core+derail signals. Relax ALL paths INTO it. Safe because a
# multicycle is an ANALYSIS directive only (flops still capture every clk); the sole 1-cycle-real
# paths inside it (the toggle-detect ORs) are trivial and cannot hide a real violation. In the
# production (non-DIAG) build u_diag2 does not exist and this matches nothing (harmless).
set_multicycle_path -setup 3 -to [get_registers {*smashtv_diag2_overlay:u_diag2|*}]
set_multicycle_path -hold  2 -to [get_registers {*smashtv_diag2_overlay:u_diag2|*}]

# yunit_mem field-engine (RAM/PAL/CMOS) BRAM writes are MULTICYCLE by the FSM: the
# CPU address a_q is latched in M_IDLE and the write happens in M_HFIN, always 3
# states later (M_ACK->M_HR1->M_HR2->M_HFIN), with a_q stable throughout. So the
# a_q -> field-BRAM address/we combinational chain (region decode + hidx adder +
# hval compare, ~12.5 ns) has >=2 whole clk_sys periods available, not 1. Scoped to
# the ram/pal/nvram BRAM cells only (NOT mem_rdata, which is single-cycle). Safe:
# a wrong -to pattern matches nothing and the violation simply persists.
set_multicycle_path -setup -end 2 \
  -from [get_registers {*u_sys|u_mem|a_q[*]}] \
  -to   [get_registers {*u_sys|u_mem|ram_rtl_0* *u_sys|u_mem|pal_rtl_0* *u_sys|u_mem|nvram_rtl_0*}]
set_multicycle_path -hold -end 1 \
  -from [get_registers {*u_sys|u_mem|a_q[*]}] \
  -to   [get_registers {*u_sys|u_mem|ram_rtl_0* *u_sys|u_mem|pal_rtl_0* *u_sys|u_mem|nvram_rtl_0*}]

# The autoerase VRAM sweep is a background op that HOLDS its SDRAM request for many
# cycles (grant-held arbiter), so er_row is stable well before the phy latches the
# address. Scoped from er_row ONLY (NOT the real-time scanout, whose scan_addr
# changes every word), so relaxing er_row -> SDRAM_A is safe.
set_multicycle_path -setup -end 2 \
  -from [get_registers {*u_vram_sdram|er_row[*]}] -to [get_registers {*u_phy|SDRAM_A[*]}]
set_multicycle_path -hold -end 1 \
  -from [get_registers {*u_vram_sdram|er_row[*]}] -to [get_registers {*u_phy|SDRAM_A[*]}]

# DMA blitter setup clipping: regf (WIDTH/HEIGHT/XSTART/YSTART/...) -> width_f/height1
# -> the S_SETUP state decision + width_c/height_c latch (~12 ns). The CPU programs the
# blit registers over many SLOW accesses (24 MHz through yunit_mem_cdc, each access is
# >=8 clk_sys cycles) BEFORE the DMA_COMMAND trigger. zunit_dma/yunit_dma both
# insert S_TRIG, so COMMAND itself also receives the full two-cycle
# regf -> S_SETUP launch/capture interval licensed here.
# Scoped from regf to the S_SETUP-latched targets only (the per-pixel draw counters
# use REGISTERED width_c/height_c, not regf, so they are unaffected / single-cycle).
set_multicycle_path -setup -end 2 \
  -from [get_registers {*u_sys|u_dma|regf[*][*]}] \
  -to   [get_registers {*u_sys|u_dma|state* *u_sys|u_dma|width_c[*] *u_sys|u_dma|height_c[*]}]
set_multicycle_path -hold -end 1 \
  -from [get_registers {*u_sys|u_dma|regf[*][*]}] \
  -to   [get_registers {*u_sys|u_dma|state* *u_sys|u_dma|width_c[*] *u_sys|u_dma|height_c[*]}]

# ---- sound-board 6809 cen-enable multicycle (P0019 analog for the dual-6809) ----------
# Both mc6809is cores (master u_cpu + slave u_cpu) advance ONLY on the ~2 MHz E/Q clock-
# enables (fallE_en=cen_e / fallQ_en=cen_q), generated in zunit_top:466-478 off snd_cen12
# (=clk/8). Every core register updates only inside `if(fallE_en)`/`if(fallQ_en)` blocks
# (mc6809is.v:571,584 + the main state case), so a value launched from a 6809 flop is
# captured by another 6809 flop no sooner than the NEXT cen edge. Derivation of the min
# gap: snd_cen12 every 8 clk; cen_e/cen_q only fire on the snd_encnt==1 tick (every 16 clk);
# divcnt sequence 0->1->2 means the tightest consecutive-enable spacing is cen_q->cen_e =
# 16 clk_sys (cen_e->cen_q = 32). So the real single-cen window is 16 clk; -setup 8 is
# strictly conservative (< 16 => never a false pass), matching the proven cpu_ce P0019
# pattern and honoring M1-CLOSED (no clock surgery). Both u_cpu cores run on clk_sys, so
# these are single-clock (same-domain) paths STA times natively; the worst-setup frontier
# (u_master|u_cpu|Inst1[4]->cc[2], -7.552 ns single-cycle) lives entirely here.
# BOARD-LEVEL cen-anchored sound sources feeding the dual-6809 di-mux that LEAKED PAST
# the u_cpu-only pattern above and dominated the whole-design worst-setup list (baselined
# 2026-07-21 on the fitted Arcade-SmashTV db): master hidden-RAM `hid`~NNN -> u_cpu|cc[2]
# = -3.524 (#1), slave `ram` altsyncram ram_rtl_0 PORT_B_WRITE_ENABLE_REG -> u_cpu|cc[2]
# = -3.472 (#2), plus many more hid/ram->cc/NMIMask. These are the SAME cen-gated class as
# the u_cpu flops -- fold them INTO $snd_regs so the -setup 8 / -hold 7 relax covers the
# board_src->6809 (and cen-gated reverse) paths. SOURCE-VERIFIED cen_e-gated per guardrail
# (narc_sound_board.sv): every board write strobe is wr_stb = cen_e & ~rnw (:362) --
#   hid  write :396 (HIDDEN_RAM && wr_stb && in_hidden), 43B => 344 inferred regs (*hid*);
#   ram  write :387 (wr_stb & in_ram), 8KB => altsyncram ram_rtl_0 (both cpus);
#   bank write :369/:372 (bank_wr = io_wr & ..., io_wr = wr_stb & in_io :364).
# ram_q (:388) clocks every clk_sys BUT reads ram[addr] with `addr` a cen-gated 6809 output,
# so its VALUE only transitions ~1 clk after a cen edge and is then stable ~15 clk before the
# next cen-gated 6809 capture -- the identical held-value argument as the u_latch crossing
# below; Quartus MERGED ram_q into the ram_rtl_0 sync-read output register (no standalone
# ram_q reg), so *ram_rtl_0* covers it. NO functional relaxation: flops still capture every
# clk; -setup 8 < the 16-clk min cen gap is strictly conservative (matches the u_cpu block).
# Slave `hid` is optimized away (HIDDEN_RAM=0 => 0 regs). `bank` folds into other cells post-
# fit (0 standalone regs, and it feeds only rom_offset, never u_cpu|cc); its patterns match
# nothing today and are kept for directive-completeness + future-proofing (harmless per :78).
# ONE-LINE get_registers (the backslash-in-braces Tcl trap, :52). Video u_scan/tms 96MHz
# paths are DELIBERATELY EXCLUDED (the genuine remaining Fmax frontier, e.g. #4 u_video|hc[1]
# -> u_scan|vram_rdata[12] = -3.417).
set snd_regs [get_registers {*u_snd|u_master|u_cpu|* *u_snd|u_slave|u_cpu|* *u_snd|*u_master|hid* *u_snd|*u_master|*ram_rtl_0* *u_snd|*u_slave|*ram_rtl_0* *u_snd|*u_master|*bank* *u_snd|*u_slave|*bank*}]
set_multicycle_path -setup 8 -from $snd_regs -to $snd_regs
set_multicycle_path -hold  7 -from $snd_regs -to $snd_regs
# Sound-ROM deadline handshake: narc_6809_clock_en replaces the inherited
# snd_encnt/snd_divcnt divider. A 6809 address may change on E or Q; the tightest
# source-change -> next falling-E deadline is Q-at-phase-31 to E-at-phase-47 =
# 16 clk_sys edges. rom_ready affects phase/cen_e/cen_q only at that e_due
# deadline. Use four cycles (< 16) for this exact source -> deadline-generator
# crossing, separately from the eight-cycle 6809-to-6809 constraint above.
# Keep the module-qualified patterns: the old zunit_top-level cen patterns matched
# zero registers after the clock generator became its own module.
set snd_tick_regs [get_registers {*narc_6809_clock_en:u_6809_clock_en|phase* *narc_6809_clock_en:u_6809_clock_en|cen_e* *narc_6809_clock_en:u_6809_clock_en|cen_q*}]
set_multicycle_path -setup 4 -from $snd_regs -to $snd_tick_regs
set_multicycle_path -hold  3 -from $snd_regs -to $snd_tick_regs
# sound-latch-in crossing: narc_sound_latch (u_latch) runs full-rate clk_sys and is written
# by the 34010's 0x01E00000 write() strobe (ext_wr, narc_sound_latch.sv:119). Its outputs --
# the held command byte r_latch/r_latch2 and the interrupt lines r_nmi/r_irq/r_firq -- feed
# the 6809 di-mux and interrupt inputs (cen domain). Each is a HELD level, stable >> 16 clk
# between service events (the CPU is NMI/IRQ'd, then reads the latch many cen cycles later),
# exactly the int1 blit_irq crossing pattern above. Relax the crossing INTO the cen domain.
set_multicycle_path -setup 8 -from [get_registers {*u_snd|u_latch|*}] -to $snd_regs
set_multicycle_path -hold  7 -from [get_registers {*u_snd|u_latch|*}] -to $snd_regs
# v7m: jt51 TIMER FLAGS -> 6809, the SAME held-level-into-the-cen-domain shape as u_latch above.
# MEASURED on the v7l netlist by the frontier audit at Slow 1100mV 100C: the worst violation in
# the entire design is
#   jt51:u_ym|jt51_timers:u_timers|jt51_timer:timer_B|flag -> narc_snd_cpu:u_master|mc6809is|cc[2]
#   slack -0.515  (four times worse than the sound-ROM boundary, many paths in the family)
# LEGITIMACY, by the same test that made me REJECT an exception for off_r1: the DESTINATION must be
# genuinely cen-gated. It is -- mc6809is.v:584-621, `cc <= cc_nxt;` sits inside `if(fallE_en)`,
# as do every other CPU state register. And the SOURCE is a HELD LEVEL: flag_a/flag_b are set on
# timer overflow and cleared ONLY by the handler's $14 RESET write (narc_sound_board.sv:288,297,
# 305-306), i.e. stable for many cen cycles between service events, exactly like r_latch/r_nmi
# above. By contrast off_r1 loads UNCONDITIONALLY every clk_sys, which is why relaxing THAT would
# have been threshold weakening and this is not.
# SCOPED NARROWLY on purpose: the timers submodule only, NOT all of jt51. An exception whose match
# set is a superset of its justification is the over-broad failure T-unit hit today.
set jt51_timer_regs [get_registers {*u_snd|u_ym|u_timers|* *u_snd|*jt51_timers*|*}]
set_multicycle_path -setup 8 -from $jt51_timer_regs -to $snd_regs
set_multicycle_path -hold  7 -from $jt51_timer_regs -to $snd_regs
# v7n: the v7m bus-capture registers -> the 6809's own state, SAME cen-gated-destination shape.
# MEASURED on the v7n netlist: 260 of the 266 rejected cc/NMIMask paths launch from bus_addr_q,
# worst -0.473 (bus_addr_q[0] -> u_slave|mc6809is|cc[0]). Mechanism: bus_addr_q -> narc_sound_bank
# -> zunit_snd_rom.ready -> narc_6809_clock_en -> cen_e, and cen_e gates EVERY mc6809is state
# register (mc6809is.v:584-646). So the ROM wait-state loop closes back into the CPU.
# LEGITIMATE by the same test used to REJECT an exception for off_r1: the DESTINATION is genuinely
# cen-gated (cc <= cc_nxt lives inside `if(fallE_en)`), and the SOURCE is stable for the whole
# 48-clk E period, being a registered copy of an address the CPU holds all cycle.
# IMPORTANT -- this deliberately does NOT relax the deadline path. narc_6809_clock_en is not
# matched by $snd_regs, so bus_addr_q -> phase/cen_e stays SINGLE-CYCLE (measured +1.723 there,
# it does not need help). Only the CPU-internal destination is relaxed, which is the one that
# actually has the cen gate.
set buscap_regs [get_registers {*u_snd|*u_master|bus_addr_q* *u_snd|*u_slave|bus_addr_q* *u_snd|*u_master|bsel_q* *u_snd|*u_slave|bsel_q* *u_snd|*u_master|rom_read_q* *u_snd|*u_slave|rom_read_q*}]
set_multicycle_path -setup 8 -from $buscap_regs -to $snd_regs
set_multicycle_path -hold  7 -from $buscap_regs -to $snd_regs

# ---- jt51 (YM2151) FM cen-enable multicycle (P0019 analog for the FM synth pipeline) ----
# The jt51 FM synthesis datapath advances ONLY on the fractional FM enables cen_fm/cen_fm_p1
# (jt51 ports .cen/.cen_p1, wired at narc_sound_board.sv:155-159 from cen_fm/cen_fm_p1). Those
# enables are generated by the 152/512 fractional accumulator in zunit_top:481-505 off snd_cen12
# (=clk_sys/8, zunit_top:459-460). DERIVATION of the 16-clk min gap: cen_fm can only pulse on a
# snd_cen12 tick (every 8 clk); when it fires fm_cnt := fm_cnt+152-512, and since the reset branch
# caps fm_cnt<=663 the post-fire value is <=303, so next tick 303+152=455 < 512 => cen_fm CANNOT
# fire on the adjacent tick => min consecutive-enable spacing = 2 ticks = 16 clk_sys (cen_fm_p1 is
# half-rate => 32 clk). -setup 8 (< 16) is strictly conservative, matching the proven cpu_ce/6809
# P0019 pattern; no clock surgery (M1 CLOSED). Both are single-clock (clk_sys) paths STA times
# natively; the whole-design worst-setup frontier lived here: -5.046 ns
# (u_snd|u_ym|jt51_lfo:u_lfo|pm[6] -> u_snd|u_ym|jt51_pg:u_pg|keycode_II[12]).
#
# *** VERIFICATION (guardrail: relax ONLY genuinely cen-gated flops; the architect's premise
# "all jt51 flops are cen-gated" was tested against the jt51 source and REFUTED) ***
# NOT every jt51 flop is cen-gated. The bus-write register INTERFACE updates on the CPU write
# strobe, NOT on cen: `write = !cs_n && !wr_n` is a HELD LEVEL (jt51.v:271), so the mmr
# memory_mapped_registers block (jt51_mmr.v:131, `else ... if(write)`) and the channel/operator
# config file (jt51_reg_ch.v:77, gated by up_rl/up_kc/... strobes) re-fire on MANY consecutive
# clk_sys edges while the 6809 holds the bus low, and lfo_up_latch (jt51_lfo.v:92) is SET by
# lfo_up at full clk rate. Those flops have REAL single-cycle reg->reg decode paths; a blanket
# {*u_snd|u_ym|*} relax would be a FALSE PASS (weakening). So snd_regs2 = the whole jt51 MINUS
# that bus-write interface. NOTE (source-verified, jt51_reg_ch.v:67-100): reg_ch holds BOTH the
# cen-gated per-slot working outputs rl/fb_II/con/kc/kf/ams_VII/pms (line 67 `if(cen)`, the FM
# read side -- these STAY IN, e.g. the pms[*] frontier source) AND the bus-gated config STORAGE
# arrays reg_rl[]/reg_fb[]/reg_con[]/reg_kc[]/reg_kf[]/reg_ams[]/reg_pms[] (line 77, up_* strobes
# -- these are EXCLUDED). So exclude ONLY the `reg_*[]` arrays, not the working outputs. Kept set
# is source-verified cen-gated: pg/eg/op/acc/noise/timers/sh/phrom/exprom/kon/csr_op(=jt51_sh)/
# reg-own(reg.v:112,152 `if(cen)`)/reg_ch-working/lfo-datapath. Excluded bus flops: mmr's own
# config regs (held `write`), reg_ch reg_*[] arrays (up_*), lfo_up_latch (full-rate set).
set jt51_all    [get_registers {*u_snd|*u_ym|*}]
set jt51_mmr_st [get_registers {*u_snd|*u_ym|jt51_mmr:u_mmr|*}]
set jt51_reg_st [get_registers {*u_snd|*u_ym|jt51_mmr:u_mmr|*jt51_reg:*}]
set jt51_mmrown [remove_from_collection $jt51_mmr_st $jt51_reg_st]
set jt51_regch  [get_registers {*u_snd|*u_ym|*jt51_reg_ch:*|reg_*}]
set jt51_upltch [get_registers {*u_snd|*u_ym|*jt51_lfo:*lfo_up_latch*}]
set jt51_bus    [add_to_collection [add_to_collection $jt51_mmrown $jt51_regch] $jt51_upltch]
set snd_regs2   [remove_from_collection $jt51_all $jt51_bus]
set_multicycle_path -setup 8 -from $snd_regs2 -to $snd_regs2
set_multicycle_path -hold  7 -from $snd_regs2 -to $snd_regs2
# 6809-domain YM bus writes crossing INTO jt51 (held-level): the master 6809 drives
# cs_n/wr_n/a0/din to the YM (narc_sound_board.sv:155-172) off its ~2 MHz E/Q enables, holding
# the level stable for a full bus cycle (>> 16 clk_sys) before jt51's bus interface latches it --
# the same held-level pattern as the u_latch crossing above. Relax the master-6809 -> jt51
# bus-interface crossing (into the NON-cen bus flops we deliberately excluded from snd_regs2).
set_multicycle_path -setup 8 -from [get_registers {*u_snd|*u_master|*u_cpu|*}] -to $jt51_bus
set_multicycle_path -hold  7 -from [get_registers {*u_snd|*u_master|*u_cpu|*}] -to $jt51_bus

# ---- scanline VRAM readout ce_pix multicycle (P0019 analog for the pixel datapath) ------
# The sole remaining whole-design setup frontier is the raster-counter -> scanline-line-buffer
# read path: u_video|hc[*]/vc[*] (zunit_video_top.sv:86-100, the else-if(ce_pix) raster counter)
# -> u_scan|vram_rdata[*] (yunit_scanline.sv:41, `always_ff @(posedge clk) if (ce_pix) vram_rdata
# <= ... lb{0,1}[req_col]`). BOTH endpoints advance ONLY on ce_pix (the 1-in-6 pixel-clock enable,
# CE_DIV=6, 16 MHz dot off 96 MHz clk_sys), so a value launched from hc/vc is captured by
# vram_rdata no sooner than the NEXT ce_pix edge = 6 clk_sys later. The combinational chain is the
# active-region/column compute feeding the line-buffer read mux (req_col index into lb0/lb1),
# analyzed at 1 clk today (the -3.417 ns #4 frontier: u_video|hc[1] -> u_scan|vram_rdata[12]).
# -setup 4 (< 6) is strictly conservative -> never a false pass; mirrors the proven cpu_ce (:57)
# and sound-cen (:146) P0019 multicycles. NO clock surgery (M1 CLOSED), NO RTL/pipeline change --
# a multicycle is an ANALYSIS directive only (flops still capture every clk_sys). SCOPED to the
# ce_pix readout ONLY (hc/vc -> vram_rdata); the full-rate SDRAM line-buffer FILL path in
# yunit_scanline (lb0/lb1 writes from scan_*) is DELIBERATELY NOT relaxed. ONE-LINE get_registers
# (the backslash-in-braces Tcl trap, :52); a wrong pattern matches nothing and fails LOUDLY.
set_multicycle_path -setup 4 -from [get_registers {*u_video|hc[*] *u_video|vc[*]}] -to [get_registers {*u_scan|vram_rdata[*]}]
set_multicycle_path -hold  3 -from [get_registers {*u_video|hc[*] *u_video|vc[*]}] -to [get_registers {*u_scan|vram_rdata[*]}]

# ---------------------------------------------------------------------------
# NARC-P0036 (ported verbatim in mechanism from WOLF-P0036, wolf-crt/rtl/sdram.sdc:133-166,
# itself ported from TUNIT-P0036, tunit/rtl/tunit.sdc:640-666)
#
# The shared sys/ ascal->HDMI cone is this family's chronic timing decider and it does NOT
# move with core logic. NARC v20 (production, P0048 erase fix) was rejected with ALL 24
# failing frontier paths in ascal:ascal|i_pix.g at Slow 0C -0.427, while NARC's own audited
# boundaries were healthy (VRAM min +0.304, sound passing outright). T-unit measured the same
# cone flat across three variants of DIFFERENT SIZE, so it is not capacity and removing logic
# does not fix it -- it is the fitter stopping at "barely fails" because the domain is at its
# effort floor.
#
# Seed roulette is explicitly NOT the remedy here: wolf measured seed 4 -0.038 and seed 3
# -0.373 on the SAME source, and quartus_fit --seed persists back into the .qsf and breaks
# artifact provenance.
#
# Remedy: during quartus_fit ONLY, add setup uncertainty on paths latched by the HDMI divclk
# so the annealer sees the domain failing by ~0.3 ns and keeps working it. quartus_sta does
# NOT take this branch -- sign-off runs the TRUE constraints, bit-identical to every previous
# NARC build, so the four post-fit audits are NOT weakened. A build still only ships if the
# real check passes.
#
# Value 0.300 is T-unit's ratified production figure (their run 4 closed 164/164 outright).
# HONEST CAVEAT FOR NARC: our gap is -0.427, LARGER than the -0.038 wolf validated it against.
# 0.300 may not be sufficient here. It is used anyway because it is the borrowed, measured
# value; T-unit measured 0.450 starting to raid the core domain (-0.168), and guessing upward
# on a first attempt would be exactly the seed-roulette reasoning this comment rejects.
# ---------------------------------------------------------------------------
if {[info exists ::TimeQuestInfo(nameofexecutable)] &&
    $::TimeQuestInfo(nameofexecutable) eq "quartus_fit"} {
  set narc_hdmi_clk [get_clocks -nowarn {*pll_hdmi*counter[0]*divclk}]
  if {[get_collection_size $narc_hdmi_clk] == 0} {
    post_message -type info "NARC HDMI fitter overconstraint: clock not found, skipped"
  } else {
    post_message -type info "NARC HDMI fitter overconstraint: +0.300 ns setup uncertainty (fit only)"
    set_clock_uncertainty -setup -to $narc_hdmi_clk -add 0.300
  }
}
