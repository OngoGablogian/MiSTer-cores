// vram_sdram.sv — Phase 6 W1f: CPU VRAM field access (byte-lane / videobank) sequenced
// over a SINGLE 16-bit SDRAM req/ack channel. This is the USE_HW_VRAM CPU path with the
// 2-port BRAM backing replaced by ONE latency-tolerant SDRAM port (srg320 ch2-style).
// The byte-lane MATH is copied verbatim from yunit_mem's proven vram_w/vram_r engine —
// only the memory access is serialized + wait-on-ack (any SDRAM latency works).
//
//   VRAM read : gather the covered plane words (up to 3: a 32-bit field at boff>0 spans
//               words widx..widx+2) -> 48-bit window -> rdata = (window >> boff) & mask.
//   VRAM write (RMW): gather old entries -> merge the field at boff into the 48-bit plane
//               window -> scatter back per byte-lane (videobank fold per entry).
//     sz<=8 : 1 entry fast path (ea = (widx<<1)+boff[3])
//     else  : 2*(1+(boff+sz-1)/16) entries -- FULL unaligned/straddling field support
//             (the RAMCHECK red-chip fix; the old code assumed aligned 1-2-word fields)
//
// One access per `req` pulse; `done` pulses when complete (rdata valid for reads).
`timescale 1ns/1ps
`default_nettype none
module vram_sdram #(
  parameter int VRAMW     = 32'h40000,        // VRAM entries (512x512)
  parameter int SD_AW     = 21,               // SDRAM word-address width
  parameter [SD_AW-1:0] VRAM_BASE = '0,       // VRAM word base in SDRAM
  // P1 (cont.22): when 1, general-path (sz>8) writes use the SDRAM per-byte write mask (DQM)
  // instead of a read-modify-write. Each 16-bit entry holds two plane bytes; a plane write only
  // touches ONE byte lane, and the field usually fills whole bytes. So: SKIP the pre-read of any
  // entry whose plane byte is FULLY covered by the field (its merged byte is then pure field bits,
  // no old dependency), and mask the write to the plane lane (vb=0 -> hi byte only, be=2'b10; vb=1
  // -> both bytes, be=2'b11, hi=palette). The other plane's byte is preserved by DQM, not by an
  // RMW read. Provably bit-identical to the full RMW (proven by the vram_sdram_acost cross-diff
  // vs BE_WRITE=0). DDR3 could NOT do this (f2h drops per-byte BE) — this is the whole SDRAM win.
  // Default 0 = legacy full-RMW behavior. Boundary/sub-byte entries still RMW-read.
  parameter bit BE_WRITE  = 1'b0
)(
  input  logic         clk,
  input  logic         rst,
  // field-access request (latched on req while idle)
  input  logic         req,                   // 1-cycle start pulse
  input  logic         we,                    // 1=write (RMW), 0=read
  input  logic [27:0]  widx,                  // 34010 VRAM word index (= addr[31:4], WB_VRAM=0)
  input  logic [3:0]   boff,                  // bit offset within the word
  input  logic [5:0]   sz,                    // field width (bits)
  input  logic [31:0]  wd,                    // write data
  input  logic         videobank,             // plane select (CONTROL bit5)
  input  logic [15:0]  dma_palette,           // blitter palette reg (folded into writes)
  output logic [31:0]  rdata,                 // read result (valid at done)
  output logic         done,                  // 1-cycle completion strobe
  output logic         active,                // 1 while an access is in progress (for arbitration)
  // single-word SDRAM channel (req held until ack)
  output logic [SD_AW-1:0] sd_addr,
  output logic [15:0]  sd_din,
  output logic [1:0]   sd_be,
  output logic         sd_rd,
  output logic         sd_wr,
  input  logic [15:0]  sd_dout,
  input  logic         sd_ack
);
  // latched request
  logic        we_l, vb_l; logic [27:0] wi; logic [3:0] bo; logic [5:0] szl;
  logic [31:0] wd_l; logic [15:0] pal_l;

  // entry geometry (from the latched request). Word k of the field window = wi+k,
  // entries 2(wi+k) / 2(wi+k)+1. A field of sz bits at bit offset bo covers words
  // wi .. wi + (bo+sz-1)/16 — up to THREE 16-bit words (sz=32 at bo>0), i.e. 6 entries.
  //
  // GENERAL FIELD SEMANTICS (the "RAM CHIPS BAD" red-set fix, cab 2026-07-10): the old
  // code assumed reads fit ONE word ("never straddles, measured" — true only of the
  // boot-era trace) and multi-word writes were WORD-ALIGNED (no bo shift at all). The
  // game's VRAM self-test (DIAG.ASM RAMCHECK, INTERLEAVE=32 fields at bit-lane offsets
  // 4..28) violates both: every mid-word 32-bit field spans 3 words. Cab evidence:
  // exactly those chips red (U10/11/12/14/28/29/30/32), word-aligned ones green —
  // 12/12. MAME never sees unaligned fields only because ITS 34010 core splits them
  // into aligned word accesses internally; OUR core hands the raw field to the memsys,
  // so the fold happens here: GATHER the covered plane words -> 48-bit window ->
  // extract (reads) or merge-at-bo + SCATTER back per byte-lane (writes).
  wire [17:0] ea = (wi << 1) + {17'd0, bo[3]};
  wire vea_v = ((wi<<1)+{27'd0,bo[3]}) < VRAMW;
  function automatic logic [17:0] went(input [2:0] i);   // entry addr of window entry i
    went = ((wi + {26'd0, i[2:1]}) << 1) + {17'd0, i[0]};
  endfunction
  function automatic logic wentv(input [2:0] i);         // entry validity
    wentv = (((wi + {26'd0, i[2:1]}) << 1) + {17'd0, i[0]}) < VRAMW;
  endfunction

  // captured old entry values (window entries 0..5 = words wi, wi+1, wi+2)
  logic [15:0] o0, o1, o2, o3, o4, o5;
  wire [7:0] oea = bo[3] ? o1[7:0] : o0[7:0];
  // plane-byte window: word k of the field stream, per videobank (MAME vram_r byte lanes)
  wire [15:0] pw0 = vb_l ? {o1[7:0], o0[7:0]} : {o1[15:8], o0[15:8]};
  wire [15:0] pw1 = vb_l ? {o3[7:0], o2[7:0]} : {o3[15:8], o2[15:8]};
  wire [15:0] pw2 = vb_l ? {o5[7:0], o4[7:0]} : {o5[15:8], o4[15:8]};
  wire [47:0] win48 = {pw2, pw1, pw0};
  wire [47:0] rmask = (48'd1 << szl) - 48'd1;
  // write merge: field inserted at bo into the 48-bit plane window
  wire [47:0] merged48 = (win48 & ~(rmask << bo)) | (({16'h0, wd_l} & rmask) << bo);
  // scattered new entry values, byte-lane folded per entry (MAME vram_w: the written
  // plane gets the merged byte; videobank=1 also folds dma_palette into the other plane,
  // videobank=0 preserves the old pixel byte)
  function automatic logic [15:0] nent(input [2:0] i);
    logic [7:0] nb, ob;
    nb = merged48[{2'd0,i}*8 +: 8];                      // merged plane byte for entry i
    case (i) 3'd0: ob=o0[7:0]; 3'd1: ob=o1[7:0]; 3'd2: ob=o2[7:0];
             3'd3: ob=o3[7:0]; 3'd4: ob=o4[7:0]; default: ob=o5[7:0]; endcase
    if (vb_l) nent = {(i[0] ? pal_l[15:8] : pal_l[7:0]), nb};
    else      nent = {nb, ob};
  endfunction
  wire [15:0] vnewea = vb_l ? {(bo[3]?pal_l[15:8]:pal_l[7:0]), wd_l[7:0]} : {wd_l[7:0], oea};

  // words covered by the field: 1 + (bo+sz-1)/16 (>8-bit fields; 8-bit = 1 entry path)
  wire [5:0] lastbit = {2'd0, bo} + szl - 6'd1;
  wire [2:0] nwords  = 3'd1 + {1'b0, lastbit[5:4]};
  wire [2:0] nents   = {nwords[1:0], 1'b0};              // 2 entries per word

  // access plan: reads first (gather old bytes — needed for reads AND the RMW merge),
  // then writes. 8-bit writes keep the single-entry fast path.
  wire is8 = we_l & (szl<=6'd8);
  wire [2:0] nread  = is8 ? 3'd1 : nents;
  wire [2:0] nwrite = we_l ? (is8 ? 3'd1 : nents) : 3'd0;

  function automatic logic [17:0] raddr(input [2:0] i);
    if (is8) raddr = ea; else raddr = went(i);
  endfunction
  function automatic logic rvalid(input [2:0] i);
    if (is8) rvalid = vea_v; else rvalid = wentv(i);
  endfunction
  function automatic logic [17:0] waddr(input [2:0] i);
    if (is8) waddr = ea; else waddr = went(i);
  endfunction
  function automatic logic [15:0] wdata(input [2:0] i);
    if (is8) wdata = vnewea; else wdata = nent(i);
  endfunction
  function automatic logic wvalid(input [2:0] i);
    if (is8) wvalid = vea_v; else wvalid = wentv(i);
  endfunction

  // P1: entry i's plane byte occupies field-window bits [8i, 8i+8). It needs an RMW read ONLY
  // if the field [bo, bo+sz) does NOT fully cover those 8 bits (a boundary / sub-byte lane).
  // Fully-covered lanes get pure field bits from the merge -> no old dependency -> skip the read.
  function automatic logic wr_read(input [2:0] i);
    logic [7:0] blo, bhi, flo, fhi;
    blo = {5'd0, i} << 3;                    // 8*i
    bhi = blo + 8'd8;
    flo = {4'd0, bo};
    fhi = flo + {2'd0, szl};
    wr_read = !((flo <= blo) && (fhi >= bhi));
  endfunction
  // per-write byte-enable for the plane lane (general path only): vb=0 writes the hi byte, vb=1
  // writes both (lo=plane, hi=palette). is8 keeps the legacy full-word write.
  wire [1:0] be_wr = (BE_WRITE && !is8) ? (vb_l ? 2'b11 : 2'b10) : 2'b11;

  typedef enum logic [1:0] { S_IDLE, S_RD, S_WR, S_FIN } st_t;
  st_t st; logic [2:0] idx;    // 0..4 (nread/nwrite can be 4) — MUST be 3-bit to exit the loop
  assign active = (st != S_IDLE);

  always_ff @(posedge clk) begin
    if (rst) begin
      st <= S_IDLE; done <= 1'b0; sd_rd <= 1'b0; sd_wr <= 1'b0; idx <= 3'd0;
    end else begin
      done <= 1'b0;
      case (st)
        S_IDLE: begin
          sd_rd <= 1'b0; sd_wr <= 1'b0;
          if (req) begin
            we_l<=we; wi<=widx; bo<=boff; szl<=sz; wd_l<=wd; vb_l<=videobank; pal_l<=dma_palette;
            idx <= 3'd0;
            st  <= S_RD;                       // every access starts by reading (RMW / read)
          end
        end
        S_RD: begin
          if (idx >= nread) begin              // reads done
            sd_rd <= 1'b0;
            if (we_l) begin idx <= 3'd0; st <= S_WR; end
            else st <= S_FIN;
          end else if (!rvalid(idx) ||         // OOB entry -> reads as 0, skip
                       (BE_WRITE && we_l && !is8 && !wr_read(idx))) begin  // P1: fully-covered write lane -> no RMW read
            case (idx) 3'd0:o0<=16'h0; 3'd1:o1<=16'h0; 3'd2:o2<=16'h0;
                       3'd3:o3<=16'h0; 3'd4:o4<=16'h0; default:o5<=16'h0; endcase
            idx <= idx + 3'd1;
          end else if (sd_ack) begin           // captured this entry
            case (idx) 3'd0:o0<=sd_dout; 3'd1:o1<=sd_dout; 3'd2:o2<=sd_dout;
                       3'd3:o3<=sd_dout; 3'd4:o4<=sd_dout; default:o5<=sd_dout; endcase
            sd_rd <= 1'b0;
            idx <= idx + 3'd1;
          end else begin
            sd_addr <= VRAM_BASE + raddr(idx); sd_be <= 2'b00; sd_rd <= 1'b1;
          end
        end
        S_WR: begin
          if (idx >= nwrite) begin
            sd_wr <= 1'b0; st <= S_FIN;
          end else if (!wvalid(idx)) begin     // OOB entry -> drop the write
            idx <= idx + 3'd1;
          end else if (sd_ack) begin
            sd_wr <= 1'b0; idx <= idx + 3'd1;
          end else begin
            sd_addr <= VRAM_BASE + waddr(idx); sd_din <= wdata(idx); sd_be <= be_wr; sd_wr <= 1'b1;
          end
        end
        S_FIN: begin
          rdata <= 32'(((win48 >> bo) & rmask));   // field extract from the 48b gathered window
          done  <= 1'b1;
          st    <= S_IDLE;
        end
        default: st <= S_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
