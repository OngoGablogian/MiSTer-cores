// vram_sdram_top.sv — Phase 6 W1f: the whole VRAM-in-SDRAM subsystem behind ONE 16-bit
// SDRAM channel. Multiplexes the VRAM accessors — CPU field RMW (vram_sdram), the blitter
// fb write (fire-and-forget -> given an fb_ack so the blitter self-paces), and (added next)
// the autoerase row-copy — via a grant-held transaction arbiter. Swaps in for yunit_mem's
// 2-port BRAM VRAM engine once proven. Priority: CPU field > fb write (they are time-
// disjoint in practice — the CPU polls, not draws, during blits).
`timescale 1ns/1ps
`default_nettype none
module vram_sdram_top #(
  parameter int VRAMW     = 32'h40000,
  parameter int SD_AW     = 21,
  parameter [SD_AW-1:0] VRAM_BASE = '0,
  parameter bit BE_WRITE  = 1'b0,            // P1: CPU-lane per-byte SDRAM writes (RMW-kill); see vram_sdram
  // ---- dead-branch elision (v7g, 2026-07-26) --------------------------------
  // A caller that hard-ties a port off makes the matching engine UNREACHABLE, but
  // Quartus 17 does not sweep it: er_row/er_x have no reset, so the autoerase
  // counters survive and their combinational {er_row,er_x} -> sd_addr fanin keeps
  // contending for placement in the consumer's address mux. On the DDR3 path that
  // cost 105 of v7f's 140 rejected setup endpoints (er_row -> a_addr/a_start),
  // all of them in logic that can never execute. These parameters let such a
  // caller elide the branch structurally. ALL DEFAULT ON: every existing
  // instantiation (yunit_mem, zunit_mem, and the SDR fallback) is bit-identical
  // and untouched. Only a caller that ALREADY ties the port to a constant may
  // turn one off, which makes the elision behavior-preserving by construction.
  parameter bit HAS_ERASE = 1'b1,            // autoerase row-copy sweep (erase_start)
  parameter bit HAS_FBW   = 1'b1,            // blitter framebuffer write port (fb_we)
  parameter bit HAS_SCAN  = 1'b1             // video scanout read channel (scan_req)
)(
  input  logic         clk,
  input  logic         rst,
  // CPU field access (passthrough to vram_sdram)
  input  logic         req,
  input  logic         we,
  input  logic         srt,
  input  logic [27:0]  widx,
  input  logic [3:0]   boff,
  input  logic [5:0]   sz,
  input  logic [31:0]  wd,
  input  logic         videobank,
  input  logic [15:0]  dma_palette,
  output logic [31:0]  rdata,
  output logic         done,
  // blitter framebuffer write (fire req; wait for fb_ack before the next)
  input  logic         fb_we,
  input  logic [17:0]  fb_addr,
  input  logic [15:0]  fb_wdata,
  output logic         fb_ack,
  // autoerase sweep trigger (frame-paced); caller gates on the CONTROL /autoerase enable
  input  logic         erase_start,
  input  logic [8:0]   erase_row0,
  input  logic [9:0]   erase_lines,
  output logic         erase_busy,
  // video scanout READ channel (highest priority = real-time). The video module owns the
  // line-buffer + row-burst sequencing (W3) and drives this raw read channel.
  input  logic         scan_req,       // read request (held until scan_ack)
  input  logic [17:0]  scan_addr,      // VRAM entry to read
  output logic [15:0]  scan_data,      // read data (valid at scan_ack)
  output logic         scan_ack,
  // shared single-word SDRAM channel
  output logic [SD_AW-1:0] sd_addr,
  output logic [15:0]  sd_din,
  output logic [1:0]   sd_be,
  output logic         sd_rd,
  output logic         sd_wr,
  input  logic [15:0]  sd_dout,
  input  logic         sd_ack
);
  // per-requester ack routing (declared up-front — Questa requires declaration-before-use).
  wire srt_i = (srt === 1'b1);
  logic c_ack_i, f_ack_i, ae_ack_i, srt_ack_i;
  // ---- CPU field engine ----
  logic [SD_AW-1:0] c_addr; logic [15:0] c_din; logic [1:0] c_be; logic c_rd, c_wr, c_active;
  logic [31:0] cpu_rdata; logic cpu_done;
  vram_sdram #(.VRAMW(VRAMW), .SD_AW(SD_AW), .VRAM_BASE(VRAM_BASE), .BE_WRITE(BE_WRITE)) u_cpu (
    .clk(clk), .rst(rst), .req(req && !srt_i), .we(we), .widx(widx), .boff(boff), .sz(sz),
    .wd(wd), .videobank(videobank), .dma_palette(dma_palette), .rdata(cpu_rdata), .done(cpu_done),
    .active(c_active),
    .sd_addr(c_addr), .sd_din(c_din), .sd_be(c_be), .sd_rd(c_rd), .sd_wr(c_wr),
    .sd_dout(sd_dout), .sd_ack(c_ack_i));

  // Raw SRT fallback for SDR-backed and simulation configurations. Production
  // DDR3 uses stv_vram_ddr_top's burst engine.
  logic [15:0] srt_buf [0:1023];
  logic [15:0] srt_q, srt_first;
  logic [17:0] srt_base;
  logic [10:0] srt_idx;
  logic srt_done, srt_we_q, srt_armed;
  localparam [2:0] SR_IDLE=3'd0, SR_RD=3'd1, SR_ST_SETTLE=3'd2, SR_WR=3'd3;
  logic [2:0] srst;
  wire srt_rd_req = (srst == SR_RD);
  wire srt_wr_req = (srst == SR_WR);
  always_ff @(posedge clk) begin
    srt_q <= srt_buf[srt_idx[9:0]];
    if (rst) begin
      srst<=SR_IDLE; srt_idx<=11'd0; srt_base<=18'd0;
      srt_done<=1'b0; srt_we_q<=1'b0; srt_armed<=1'b1; srt_first<=16'd0;
    end else begin
      srt_done <= 1'b0;
      if (!req || !srt_i) srt_armed <= 1'b1;
      case (srst)
        SR_IDLE: if (req && srt_i && srt_armed) begin
          srt_armed<=1'b0;
          srt_base <= {widx[16:0],boff[3]};
          srt_idx  <= 11'd0;
          srt_we_q <= we;
          srst     <= we ? SR_ST_SETTLE : SR_RD;
        end
        SR_RD: if (srt_ack_i) begin
          srt_buf[srt_idx[9:0]] <= sd_dout;
          if (srt_idx==11'd0) srt_first<=sd_dout;
          if (srt_idx==11'd1023) begin srt_done<=1'b1; srst<=SR_IDLE; end
          else srt_idx<=srt_idx+11'd1;
        end
        SR_ST_SETTLE: srst<=SR_WR;
        SR_WR: if (srt_ack_i) begin
          if (srt_idx==11'd1023) begin srt_done<=1'b1; srst<=SR_IDLE; end
          else begin srt_idx<=srt_idx+11'd1; srst<=SR_ST_SETTLE; end
        end
        default: srst<=SR_IDLE;
      endcase
    end
  end
  assign done  = cpu_done | srt_done;
  assign rdata = srt_done ? (srt_we_q ? 32'd0 : {16'd0,srt_first}) : cpu_rdata;

  // ---- blitter fb writer: buffer ONE fb_we (on its RISING edge — the blitter now HOLDS
  // fb_we while waiting for fb_ack, so edge-detect avoids re-latching the same write),
  // write it, ack ----
  logic [17:0] f_a; logic [15:0] f_d; logic f_pending, fb_we_d;
  generate if (HAS_FBW) begin : g_fbw
  always_ff @(posedge clk) begin
    if (rst) begin f_pending <= 1'b0; fb_ack <= 1'b0; fb_we_d <= 1'b0; end
    else begin
      fb_ack  <= 1'b0;
      fb_we_d <= fb_we;
      if (!f_pending) begin
        if (fb_we & ~fb_we_d) begin f_a <= fb_addr; f_d <= fb_wdata; f_pending <= 1'b1; end
      end else if (f_ack_i) begin
        f_pending <= 1'b0; fb_ack <= 1'b1;
      end
    end
  end
  end else begin : g_no_fbw                  // caller ties fb_we off: unreachable
    assign f_a = 18'd0; assign f_d = 16'd0; assign f_pending = 1'b0;
    assign fb_we_d = 1'b0; assign fb_ack = 1'b0;
  end endgenerate

  // ---- autoerase: row-copy sweep (src row 510|parity -> dst row; skip rows 510/511) ----
  // Per entry: read src -> write dst, over SDRAM (2 transactions). Frame-paced background;
  // lowest arbiter priority (yields to CPU field + fb write).
  localparam logic [1:0] AE_IDLE=2'd0, AE_RD=2'd1, AE_WR=2'd2, AE_ADV=2'd3;
  logic [1:0] ae; logic er_run; logic [8:0] er_row, er_x; logic [9:0] er_left; logic [15:0] er_data;
  wire [17:0] ae_src = {8'hFF, er_row[0], er_x};
  wire [17:0] ae_dst = {er_row, er_x};
  wire ae_skip = (er_row == 9'd510) || (er_row == 9'd511);
  wire ae_rd_req = (ae == AE_RD) & ~ae_skip;
  wire ae_wr_req = (ae == AE_WR);
  assign erase_busy = er_run;
  generate if (HAS_ERASE) begin : g_ae
  always_ff @(posedge clk) begin
    if (rst) begin ae <= AE_IDLE; er_run <= 1'b0; end
    else case (ae)
      AE_IDLE: if (erase_start && erase_lines != 10'd0) begin
                 er_run <= 1'b1; er_row <= erase_row0 - 9'd1; er_x <= 9'd0;
                 er_left <= erase_lines + 10'd1; ae <= AE_RD;
               end
      AE_RD:   if (ae_skip)        ae <= AE_ADV;              // never erase the pattern rows
               else if (ae_ack_i) begin er_data <= sd_dout; ae <= AE_WR; end
      AE_WR:   if (ae_ack_i)       ae <= AE_ADV;              // dst written
      AE_ADV:  begin
                 if (er_x == 9'd511) begin
                   er_x <= 9'd0; er_row <= er_row + 9'd1; er_left <= er_left - 10'd1;
                   if (er_left <= 10'd1) begin er_run <= 1'b0; ae <= AE_IDLE; end
                   else ae <= AE_RD;
                 end else begin er_x <= er_x + 9'd1; ae <= AE_RD; end
               end
      default: ae <= AE_IDLE;
    endcase
  end
  end else begin : g_no_ae                   // caller ties erase_start off: unreachable
    assign ae = AE_IDLE; assign er_run = 1'b0; assign er_row = 9'd0;
    assign er_x = 9'd0;  assign er_left = 10'd0; assign er_data = 16'd0;
  end endgenerate

  // ---- grant-held transaction arbiter (scanout > CPU field > fb > autoerase) ----
  // scanout is highest = real-time (must deliver pixels every line); its per-line traffic
  // is bounded (one row) so it can't starve the others. All non-scanout requesters can
  // wait (CPU/blitter stall gracefully; autoerase is background).
  // An elided engine can never request; stating it here folds its arbiter branch and
  // its leg of the sd_addr mux even before constant propagation reaches the counters.
  wire cpu_req  = c_rd | c_wr;
  wire fb_req   = HAS_FBW   & f_pending;
  wire ae_req   = HAS_ERASE & (ae_rd_req | ae_wr_req);
  wire srt_req_i = srt_rd_req | srt_wr_req;
  wire scan_req_i = HAS_SCAN & scan_req;
  logic [2:0] gnt; logic gnt_held; logic [2:0] gnt_r; logic bubble;
  always_comb begin
    if (gnt_held)      gnt = gnt_r;
    else if (bubble)   gnt = 3'd0;     // 1-cycle gap: drops sd_rd/sd_wr so the next
`ifdef SIM_CPU_PRIORITY
    else if (cpu_req)  gnt = 3'd2;     // measure-first probe (sim-only): CPU VRAM above scanout
    else if (scan_req_i) gnt = 3'd1;
    else if (srt_req_i) gnt = 3'd5;
`else
    else if (scan_req_i) gnt = 3'd1;     //   transaction gets a clean rising edge (the
    else if (srt_req_i) gnt = 3'd5;
    else if (cpu_req)  gnt = 3'd2;     //   model edge-accepts; back-to-back rd->wr would
`endif
    else if (fb_req)   gnt = 3'd3;     //   otherwise keep (rd|wr) high and stall)
    else if (ae_req)   gnt = 3'd4;
    else               gnt = 3'd0;
  end
  always_ff @(posedge clk) begin
    if (rst) begin gnt_held <= 1'b0; gnt_r <= 3'd0; bubble <= 1'b0; end
    else begin
      bubble <= 1'b0;
      if (!gnt_held) begin
        if (!bubble && gnt != 3'd0) begin gnt_held <= 1'b1; gnt_r <= gnt; end
      end else if (sd_ack) begin
        gnt_held <= 1'b0; bubble <= 1'b1;   // transaction done -> gap -> re-arbitrate
      end
    end
  end

  // ---- route the granted requester to the shared SDRAM port; ack back to it only ----
  always_comb begin
    sd_addr = '0; sd_din = 16'h0; sd_be = 2'b00; sd_rd = 1'b0; sd_wr = 1'b0;
    c_ack_i = 1'b0; f_ack_i = 1'b0; ae_ack_i = 1'b0; srt_ack_i = 1'b0; scan_ack = 1'b0;
    case (gnt)
      3'd1: begin                        // scanout read (highest priority)
        sd_addr = VRAM_BASE + {{(SD_AW-18){1'b0}}, scan_addr}; sd_be = 2'b00; sd_rd = scan_req_i;
        scan_ack = sd_ack;
      end
      3'd2: begin                        // CPU field
        sd_addr = c_addr; sd_din = c_din; sd_be = c_be; sd_rd = c_rd; sd_wr = c_wr;
        c_ack_i = sd_ack;
      end
      3'd3: begin                        // fb write (full-word)
        sd_addr = VRAM_BASE + {{(SD_AW-18){1'b0}}, f_a}; sd_din = f_d; sd_be = 2'b11; sd_wr = f_pending;
        f_ack_i = sd_ack;
      end
      3'd4: begin                        // autoerase: read src / write dst (full-word)
        if (ae_rd_req) begin sd_addr = VRAM_BASE + {{(SD_AW-18){1'b0}}, ae_src}; sd_be = 2'b00; sd_rd = 1'b1; end
        else           begin sd_addr = VRAM_BASE + {{(SD_AW-18){1'b0}}, ae_dst}; sd_din = er_data; sd_be = 2'b11; sd_wr = 1'b1; end
        ae_ack_i = sd_ack;
      end
      3'd5: begin                        // raw SRT entry
        sd_addr = VRAM_BASE + {{(SD_AW-18){1'b0}}, (srt_base + srt_idx[9:0])};
        sd_be = 2'b11;
        if (srt_rd_req) sd_rd = 1'b1;
        else begin sd_din = srt_q; sd_wr = 1'b1; end
        srt_ack_i = sd_ack;
      end
      default: ;
    endcase
  end
  assign scan_data = sd_dout;            // valid at scan_ack

`ifndef SYNTHESIS
  // v7g: eliding an engine is only sound because the caller HAS ALREADY tied that
  // port to a constant, which is a claim about the instantiation, not this file.
  // Check it instead of asserting it: any TB that drives a disabled port dies here
  // rather than silently losing an erase sweep / fb write / scanout read. Costs
  // nothing in synthesis and holds across every existing instantiation.
  always @(posedge clk) if (!rst) begin
    if (!HAS_ERASE && erase_start)
      $fatal(1, "vram_sdram_top: erase_start asserted with HAS_ERASE=0 (engine elided)");
    if (!HAS_FBW && fb_we)
      $fatal(1, "vram_sdram_top: fb_we asserted with HAS_FBW=0 (engine elided)");
    if (!HAS_SCAN && scan_req)
      $fatal(1, "vram_sdram_top: scan_req asserted with HAS_SCAN=0 (engine elided)");
  end
`endif
endmodule
`default_nettype wire
